// FILE PATH: backend/src/config/database.js
import { Sequelize } from 'sequelize';
import dotenv from 'dotenv';

dotenv.config();

// BizTrack has always used DATABASE_URL; keep that working so the existing .env
// does not need to change. DB_* variables (EduTrack style) are accepted too.
const common = {
  dialect: 'postgres',
  logging: process.env.SQL_LOG === '1' ? console.log : false,
  pool: { max: 20, min: 0, acquire: 30000, idle: 300000 },
  // Existing BizTrack tables mostly use snake_case columns and manage their own
  // created_at/updated_at (updated_at via a DB trigger), so models opt in per table.
  define: { timestamps: false, underscored: true, freezeTableName: true },
  dialectOptions: {
    keepAlive: true,
    statement_timeout: Number(process.env.STATEMENT_TIMEOUT_MS) || 120000,
    ...(process.env.DB_SSL === 'true' ? { ssl: { require: true, rejectUnauthorized: false } } : {}),
  },
};

const sequelize = process.env.DATABASE_URL
  ? new Sequelize(process.env.DATABASE_URL, common)
  : new Sequelize(
      process.env.DB_NAME || 'biztrack',
      process.env.DB_USER || 'postgres',
      process.env.DB_PASSWORD || 'postgres',
      { ...common, host: process.env.DB_HOST || 'localhost', port: process.env.DB_PORT || 5432 },
    );

export const testConnection = async () => {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connection established successfully.');
    return true;
  } catch (error) {
    console.error('❌ Unable to connect to the database:', error.message);
    return false;
  }
};

export default sequelize;
