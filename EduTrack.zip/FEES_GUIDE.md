# Fees & Payments — Guide

Replaces the old "Coming Soon" placeholder with a working module, following
the same simple, consistent pattern as Exams & Grades.

## How it works

### 1. Fees → **Fee Structures** (`/fees`)
Admin/Principal define what each class owes per academic year — e.g.
"Tuition Fee", "Uniform Fee" — each with an amount, frequency (one-time,
monthly, quarterly, annually — informational, doesn't affect the balance
math), and the class it applies to. Standard CRUD list with stat cards and
filters, same look as Exams/Subjects/Staff.

### 2. **Record Payment** (`/fees/record`)
Pick a student (by class → section → student), see their running balance
in the sidebar, pick which fee item the payment is for (or leave it as a
general payment), enter the amount/method/date, and save. Redirects
straight to a printable receipt.

### 3. **Fee Status** (`/fees/status`)
- **Staff**: pick a class (+ section) → a matrix of every student's
  Expected / Paid / Balance / Status (Paid, Partial, Unpaid), with
  campus-wide totals at the top. Click **View** on any row for that
  student's full breakdown and payment history.
- **Parent**: sees each linked child with their current balance directly —
  tap one to see the same breakdown.

### 4. Payment Receipt (`/fees/receipt/:id`)
A formal, printable receipt — school letterhead, receipt number, amount in
words, payment method, signature lines — opened automatically right after
recording a payment, or from a student's payment history.

## Access control
Fee Structures and the class-wide Fee Status matrix are staff-only
(admin/principal/accountant). A student's fee summary and receipts can be
viewed by staff, the student themselves, or their linked parent — same
rule as Exam report cards.

## How to test

The seed script now creates 4 fee items (Tuition, Uniform, Examination,
Lunch) for **Form I, II and III**, plus realistic payment history — about
40% of students fully paid, 40% partially paid, 20% unpaid — so Fee Status
has real variety to look at immediately after `npm run seed`.

1. Log in as admin → **Fees** → confirm the 12 seeded fee items appear
   (4 items × 3 classes), each showing the right amount and class.
2. **Fees → Fee Status** → pick Form I → **View Status** — confirm you see
   a mix of "Paid", "Partial", and "Unpaid" badges, and that the totals
   at the top add up correctly.
3. Click **View** on a "Partial" student — confirm the breakdown shows
   which fee items are still outstanding, and their payment history lists
   the payments already made.
4. Click **View** on a payment to open its receipt → **Print** — confirm
   it looks like a real receipt (letterhead, receipt number, amount in
   words).
5. **Fees → Record Payment** → pick an "Unpaid" student from Form II →
   record a payment for one fee item → confirm it redirects to a new
   receipt, and that Fee Status now shows them as "Partial" or "Paid".
6. Log in as a **parent** account linked to a seeded student → **Fees** →
   confirm you only see your own child(ren)'s balance, not the whole
   class.
7. Try opening another family's receipt URL directly while logged in as
   that parent — confirm you get a "not allowed" message.

## What's still a placeholder
Expenses and Payroll (also under Finance in the sidebar) are a different
feature — school-side spending and staff salaries, not student fees — and
are unchanged. Library, Transport, Hostel, Reports/Analytics,
Notifications, and Messages are also still placeholders.
