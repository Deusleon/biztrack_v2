# Timetable — Guide (rebuilt from scratch)

The Timetable module was completely rebuilt — every old file removed and
replaced — because the previous version (even after being simplified once
already) kept causing confusion and bugs. This version follows one rule:
**manual editing is always the reliable path; auto-fill is just a
convenience on top of it.**

## What changed

**7 database models -> 3.** Gone: TimetableVersion (draft/publish
workflow), TimeSlot (a separate table just to describe periods), Room,
SubjectAllocationRule, TimetableRule (a JSON rule engine), Teacher
Availability. In their place:

- **TimetableSettings** — one row per campus: what the school week looks
  like. The period grid itself (what time each period starts/ends, where
  breaks fall) is computed from this instantly — there's no separate
  table to keep in sync with it anymore.
- **ClassSubject** — "this class studies this subject N times a week,
  usually taught by this teacher." The only planning input Auto-Fill needs.
- **TimetableEntry** — one placed lesson: a class+section, a day, a
  period number, a subject, optionally a teacher. No draft/published
  version concept — a class's timetable is just its current entries,
  edited directly, the same way a real printed timetable works.

**5 pages -> 2.**
- **Timetable -> Setup** (`/timetable/setup`) — two tabs: School Week, and
  Class Subjects. Admin/Principal only.
- **Timetable** (`/timetable`) — the grid itself, with three view modes
  (Class / All Classes / Teacher). Anyone can view; Admin, Principal, and
  Teacher can edit.

**No more auto-generation algorithm that can fail mysteriously.**
Building a timetable now means clicking a period cell and picking a
subject — always works, always predictable, exactly like filling in an
Excel sheet. **Auto-Fill** is a genuinely simple helper: it only touches
empty cells, spreads each subject across different days, and avoids
double-booking a teacher who's assigned elsewhere at the same time. It
tells you plainly if it couldn't place everything (e.g. "not enough free
periods for Chemistry (2 short)") instead of failing silently.

**Explicitly removed for simplicity** (Rooms, Saturday classes, and
draft/publish versioning added complexity without enough day-to-day value
for most schools):
- Room assignment per lesson
- Saturday as a teaching day
- Draft vs. published timetable versions

**Kept, and improved after reviewing a real school's printed timetable:**
- Tea break / lunch break placement
- **Double periods** — real schools very commonly teach a subject as two
  consecutive periods, not one. The Grid's cell editor has a one-click
  "Double period" checkbox that fills the current *and* next period with
  the same subject/teacher in one save. Auto-Fill and the seed demo data
  now do this by default too.
- **Separate school week per education level** — Primary/O-Level and
  A-Level each get their own TimetableSettings (period count, length,
  start time can all differ), selected automatically from whichever
  class you're viewing.
- **End-of-day activities** — a fixed non-academic slot (or several) at
  the end of each day, configured once per level — e.g. Monday =
  Cleanliness, Friday = Mosque / Debate / Sport & Games — shown as extra
  row(s) at the bottom of the grid, exactly like a real printed
  timetable's trailing columns.
- Friday half-day
- Auto-Fill

## How it works

### 0. Pick an Education Level
At the top of Setup, choose Primary, O-Level, or A-Level — everything below (School Week, Class Subjects) applies to that level only. Switch levels any time; each keeps its own settings.

### 1. Timetable -> Setup -> School Week
One form: day start time, minutes per period, periods per day
(Monday-Thursday), periods on Friday, and where the tea/lunch breaks
fall, and the end-of-day activity label(s) for each day (type your own or
pick a preset — Cleanliness, Subject Clubs, Religion, Mosque, Debate,
Sport & Games...). Save — the period grid is ready immediately, shown as
a preview right on the page.

### 2. Timetable -> Setup -> Class Subjects
Pick a class. Tick every subject it studies, set periods/week for each,
and optionally lock in a teacher. Save. Repeat for each class. That's the
only information Auto-Fill needs.

### 3. Timetable -> Class View
Pick a class and section. Click any period cell to assign a subject (only
subjects configured in Step 2 are offered) and, optionally, a teacher. If it's a
double period, tick the checkbox to fill the next period too — saves
immediately. Click Auto-Fill Empty Periods to have it fill in
whatever's still blank using the weekly counts from Step 2. Clear All
wipes the section's timetable to start over.

### 4. Timetable -> All Classes / Teacher View
All Classes — pick an education level and a day, see every class's
timetable for that day side by side, like a printed school master
timetable (read-only). Teacher View
— pick a teacher, see their personal week across every class they teach
(read-only).

## How to test

The seed script creates the school week, class-subject assignments for
every class (Form I-VI), and an already Auto-Filled timetable for Form I
(all 3 sections) so there's something real to open immediately.

1. Log in as admin -> Timetable -> Class View -> Form I, Section A ->
   confirm periods are filled in with subjects and teachers, mostly in
   pairs (double periods) the way a real timetable reads.
2. Timetable -> All Classes -> pick Monday -> confirm Form I's three
   sections show correctly alongside each other.
3. Timetable -> Teacher View -> pick a teacher who teaches Form I ->
   confirm their periods match what's shown in Class View.
4. Click an empty-looking period cell (or click a filled one to change
   it) -> pick a subject -> Save -> confirm it appears immediately.
5. Timetable -> Setup -> Class Subjects -> pick Form II -> tick a few
   subjects with periods/week -> Save Subjects.
6. Timetable -> Class View -> Form II, Section A -> Auto-Fill Empty
   Periods -> confirm periods get placed and the message tells you
   clearly how many.
7. Try Auto-Fill again on the same section -> confirm it reports "every
   subject got its full weekly count" and doesn't double-place anything
   (Auto-Fill never touches already-filled cells).
8. Assign the same teacher to two different classes at overlapping
   periods (via manual entry) -> confirm the second save is rejected with
   a clear "already teaching X at this time" message.
9. Timetable -> Setup -> School Week -> reduce "Periods per day" below a
   number some class currently uses -> save -> confirm the now-invalid
   periods are quietly removed from every timetable instead of being left
   dangling.

10. Timetable -> Setup -> pick "A-Level" -> School Week -> change the
    start time or period count and Save -> switch back to "O-Level" ->
    confirm its settings are untouched (each level's schedule is
    independent).
11. Timetable -> Setup -> School Week -> set Friday's activities to
    "Mosque", "Debate", "Sport & Games" (three separate entries) ->
    Save -> Timetable -> Class View -> confirm all three appear as
    trailing rows under Friday.
12. Click an empty period cell -> pick a subject -> tick "Double period"
    -> Save -> confirm both this period and the next are filled with the
    same subject/teacher in one action.
