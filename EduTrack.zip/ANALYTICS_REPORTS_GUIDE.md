# Analytics & Reports — Guide

Two closing features that pull together everything already built,
rather than adding new modules.

## Setup note

This added `recharts` as a new frontend dependency (no charting library
existed before). Run `npm install` in `frontend/` before starting the
dev server for the first time after this update.

## Analytics (`/analytics`)

One live dashboard, four sections:

- Overview -- active students, staff, classes, pending leave requests.
- Academic -- attendance rate (last 30 days), a 14-day attendance trend
  line chart, and the latest completed exam's average score.
- Financial -- fees collected year-to-date (with collection rate vs
  expected), this month's expenses, the latest paid payroll period, and
  an expense-by-category pie chart.
- Operations -- transport, library, hostel, and inventory at a glance,
  plus an occupancy bar chart (Transport vs Hostel).

Everything is computed live from the database on each page load -- no
caching, no stale numbers. Restricted to Admin/Principal.

## Reports (`/reports`)

Four report types, each: pick it, optionally adjust the date/year filter,
preview on screen, then Download PDF or Download Excel. Files are
generated in the browser (matching how Exam result exports already
work) -- no report is stored on the server.

- Financial Summary -- Income vs Expenses vs Payroll, month by month for
  a chosen year.
- Fee Collection -- expected vs collected vs outstanding, per class.
- Attendance Summary -- attendance rate per class over a date range
  (defaults to the last 30 days).
- Enrollment -- student counts per class, split by gender.

Restricted to Admin/Principal/Accountant.

## How to test

1. Log in as admin -> Analytics -> confirm all four sections load with
   real numbers (not zeros, given the seed data from every prior module).
2. Confirm the attendance line chart and expense pie chart render.
3. Reports -> Financial Summary -> confirm January 2026 shows income
   (fee payments), the payroll expense, and other January expenses.
4. Download PDF and Download Excel on Financial Summary -> confirm both
   files open correctly and match the on-screen preview.
5. Reports -> Fee Collection -> confirm Form I A (or whichever class has
   a fee structure) shows a sensible collection rate.
6. Reports -> Attendance Summary -> adjust the date range -> Refresh ->
   confirm the rows update to match.
