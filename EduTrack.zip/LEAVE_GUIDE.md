# Leave — Guide

Two-step approval leave/excuse requests for both staff and students.

## How approvers are resolved

- Staff: Step 1 = their `reports_to` (set per staff member — see Staff ->
  Edit). If not set, falls back straight to the Principal. Step 2 = the
  Principal.
- Student: Step 1 = their class's Class Teacher. If the class has no
  Class Teacher assigned, falls back to the Principal. Step 2 = the
  Principal.
- If Step 1 *is* the Principal (no distinct manager set), the request is
  auto-finalized at Step 1 -- no pointless "approve your own approval"
  second step.

## How it works

### My Leave (`/leave`)
Request leave/an excuse, see your own requests and their status, cancel
a still-pending one. Staff additionally see their leave balance cards
(days remaining this year, per type).

### Approvals (`/leave/approvals`)
Anyone who is a Step 1 or Step 2 approver for at least one pending
request sees it here -- approve or reject with an optional comment.
Rejecting at either step ends the request immediately; approving at Step
1 moves it to Step 2.

### Setup (`/leave/setup`) -- HR/Admin/Principal only
Leave Types -- create types (Annual, Sick, Study, Excuse/Absence...), who
they apply to (staff/student/both), and whether they draw from a yearly
day balance. Staff Balances -- view and adjust any staff member's
allocated days per type per year.

## How to test

1. Log in as a teacher whose `reports_to` isn't set -> Leave -> Request
   Leave -> Annual Leave, a few days -> confirm it shows "Awaiting [the
   Principal's name]".
2. Log in as Principal -> Leave -> Approvals -> confirm the request
   appears -> Approve -> confirm the request auto-finalizes (no Step 2,
   since the Principal was already Step 1) and the balance decreases.
3. Log in as a student -> Leave -> Request an Excuse/Absence -> confirm
   it routes to their class teacher.
4. Log in as that class teacher -> Approvals -> Approve -> confirm it now
   shows "Step 2 of 2" awaiting the Principal.
5. Try requesting more days than remaining balance -> confirm it's
   blocked with a clear message.
6. Leave -> Setup -> Staff Balances -> pick a staff member -> adjust
   their Annual Leave allocation -> confirm it reflects on their My Leave
   balance card.
