# EduTrack - Enterprise School Management System

EduTrack is a comprehensive, multi-tenant school management system designed for multi-campus educational institutions. Built with modern web technologies, it provides a complete solution for managing all aspects of school operations.

## 🌟 Features

### Core Modules
- **Multi-Tenancy**: Support for multiple schools/institutions in a single deployment
- **Multi-Campus Management**: Manage multiple campuses within an organization
- **Student Management**: Complete student profiles, admissions, and records management
- **Attendance Tracking**: Daily attendance marking with reports and analytics
- **Academic Management**: Classes, sections, subjects, and timetables
- **Exams & Grading**: Comprehensive exam scheduling and grade management
- **Learning Management System (LMS)**: Course materials and assignments
- **Fees & Accounting**: Fee collection, invoicing, and financial management
- **HR & Payroll**: Staff management and payroll processing
- **Library Management**: Book cataloging and circulation
- **Transport Management**: Route planning and GPS tracking
- **Hostel Management**: Room allocation and management
- **Inventory Management**: Asset and resource tracking
- **Discipline Tracking**: Behavior monitoring and reporting
- **Communication**: SMS, Email, and in-app messaging
- **Parent Portal**: Parent access to student information
- **Student Portal**: Student access to academic information
- **Analytics & Reports**: Comprehensive reporting and data visualization

### Technical Features
- **Role-Based Access Control (RBAC)**: Granular permissions for different user roles
- **Audit Logs**: Complete activity tracking for compliance
- **Security**: JWT authentication, password encryption, input validation
- **Scalability**: Designed to handle growth in users and data
- **API-First Architecture**: RESTful API for integrations
- **Mobile-Ready**: Responsive design for mobile and tablet devices

## 🏗️ Architecture

### Tech Stack

**Frontend:**
- React 18 with Vite
- React Router for navigation
- Axios for API calls
- Context API for state management
- Modern CSS for styling

**Backend:**
- Node.js with Express.js
- PostgreSQL database with Sequelize ORM
- JWT for authentication
- bcrypt for password hashing
- Express Validator for input validation
- Helmet for security headers
- CORS for cross-origin requests
- Morgan for logging

## 📦 Project Structure

```
EduTrack/
├── frontend/                 # React frontend application
│   ├── src/
│   │   ├── components/      # Reusable UI components
│   │   ├── contexts/        # React contexts (Auth, etc.)
│   │   ├── pages/           # Page components
│   │   ├── services/        # API service functions
│   │   ├── utils/           # Utility functions
│   │   ├── App.jsx          # Main App component
│   │   └── main.jsx         # Entry point
│   ├── package.json
│   └── vite.config.js
│
├── backend/                  # Node.js backend application
│   ├── src/
│   │   ├── config/          # Configuration files
│   │   ├── controllers/     # Route controllers
│   │   ├── middleware/      # Custom middleware
│   │   ├── models/          # Sequelize models
│   │   ├── routes/          # API routes
│   │   ├── services/        # Business logic
│   │   ├── utils/           # Utility functions
│   │   └── server.js        # Server entry point
│   ├── .env.example         # Environment variables template
│   └── package.json
│
└── README.md
```

## 🚀 Getting Started

### Prerequisites
- Node.js (v18 or higher)
- PostgreSQL (v12 or higher)
- npm or yarn

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/Deusleon/EduTrack.git
cd EduTrack
```

2. **Set up the Backend**
```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your database credentials and other settings
npm run dev
```

3. **Set up the Frontend**
```bash
cd frontend
npm install
cp .env.example .env
# Edit .env if needed
npm run dev
```

4. **Database Setup**
- Create a PostgreSQL database
- Update the database credentials in `backend/.env`
- The application will automatically create tables on first run

### Default Environment Configuration

**Backend (.env)**
```env
PORT=5000
NODE_ENV=development
DB_HOST=localhost
DB_PORT=5432
DB_NAME=edutrack
DB_USER=postgres
DB_PASSWORD=postgres
JWT_SECRET=your_super_secret_jwt_key_change_in_production
```

**Frontend (.env)**
```env
VITE_API_URL=http://localhost:5000/api/v1
```

## 🔐 User Roles

The system supports the following user roles:
- **Super Admin**: Full system access across all tenants
- **Admin**: Full access within a tenant
- **Principal**: Campus-level administration
- **Teacher**: Class and student management
- **Student**: Access to personal academic information
- **Parent**: Access to their child's information
- **Accountant**: Financial management
- **Librarian**: Library management
- **HR**: Staff management
- **Transport Manager**: Transport management
- **Hostel Warden**: Hostel management

## 📡 API Endpoints

### Authentication
- `POST /api/v1/auth/register` - Register new user
- `POST /api/v1/auth/login` - User login
- `GET /api/v1/auth/me` - Get current user
- `PUT /api/v1/auth/profile` - Update profile
- `PUT /api/v1/auth/change-password` - Change password

### Students
- `GET /api/v1/students` - Get all students
- `POST /api/v1/students` - Create student
- `GET /api/v1/students/:id` - Get student by ID
- `PUT /api/v1/students/:id` - Update student
- `DELETE /api/v1/students/:id` - Delete student

### Attendance
- `POST /api/v1/attendance/mark` - Mark attendance
- `POST /api/v1/attendance/bulk-mark` - Bulk mark attendance
- `GET /api/v1/attendance` - Get attendance records
- `GET /api/v1/attendance/report` - Get attendance report

## 🔒 Security Features

- **Password Encryption**: Bcrypt hashing for all passwords
- **JWT Authentication**: Secure token-based authentication
- **Input Validation**: Server-side validation of all inputs
- **SQL Injection Prevention**: Sequelize ORM parameterized queries
- **XSS Prevention**: Input sanitization
- **CORS Configuration**: Controlled cross-origin requests
- **Helmet.js**: Security headers
- **Rate Limiting**: Protection against brute force attacks
- **Audit Logs**: Complete activity tracking

## 📱 Multi-Tenant Architecture

EduTrack uses a multi-tenant architecture where:
- Each school/institution is a separate tenant
- Data is isolated per tenant
- Users belong to a specific tenant
- Super admins can manage multiple tenants
- Each tenant can have multiple campuses

## 🎨 Frontend Features

- Responsive design for all screen sizes
- Modern and intuitive user interface
- Role-based UI rendering
- Real-time data updates
- Client-side routing
- Form validation
- Error handling
- Loading states

## 🛠️ Development

### Running Tests
```bash
# Backend tests
cd backend
npm test

# Frontend tests
cd frontend
npm test
```

### Building for Production
```bash
# Backend
cd backend
npm start

# Frontend
cd frontend
npm run build
```

## 📝 License

This project is licensed under the ISC License.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📧 Support

For support, email support@edutrack.com or open an issue in the repository.

## 🙏 Acknowledgments

- React Team for the amazing framework
- Express.js for the robust backend framework
- PostgreSQL for the reliable database
- All open-source contributors

---

**Built with ❤️ for educational institutions worldwide**
