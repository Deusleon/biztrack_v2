# EduTrack Setup & Deployment Guide

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Local Development Setup](#local-development-setup)
3. [Database Setup](#database-setup)
4. [Environment Configuration](#environment-configuration)
5. [Running the Application](#running-the-application)
6. [Production Deployment](#production-deployment)
7. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** (v18 or higher) - [Download](https://nodejs.org/)
- **PostgreSQL** (v12 or higher) - [Download](https://www.postgresql.org/download/)
- **npm** or **yarn** (comes with Node.js)
- **Git** - [Download](https://git-scm.com/)

---

## Local Development Setup

### 1. Clone the Repository

```bash
git clone https://github.com/Deusleon/EduTrack.git
cd EduTrack
```

### 2. Install Backend Dependencies

```bash
cd backend
npm install
```

### 3. Install Frontend Dependencies

```bash
cd ../frontend
npm install
```

---

## Database Setup

### 1. Install PostgreSQL

Download and install PostgreSQL from the official website.

### 2. Create Database

Open PostgreSQL command line or use a GUI tool like pgAdmin:

```sql
CREATE DATABASE edutrack;
CREATE USER edutrack_user WITH ENCRYPTED PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE edutrack TO edutrack_user;
```

### 3. Test Connection

```bash
psql -U edutrack_user -d edutrack -h localhost
```

---

## Environment Configuration

### Backend Configuration

1. Navigate to the backend directory:
```bash
cd backend
```

2. Copy the example environment file:
```bash
cp .env.example .env
```

3. Edit `.env` file with your configuration:

```env
# Server Configuration
PORT=5000
NODE_ENV=development

# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=edutrack
DB_USER=edutrack_user
DB_PASSWORD=your_password

# JWT Configuration
JWT_SECRET=your_super_secret_jwt_key_change_in_production
JWT_EXPIRE=7d
JWT_REFRESH_SECRET=your_super_secret_refresh_key
JWT_REFRESH_EXPIRE=30d

# Email Configuration (for Gmail)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=your_app_password
EMAIL_FROM=noreply@edutrack.com

# SMS Configuration (Twilio example)
SMS_PROVIDER=twilio
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=+1234567890

# Payment Gateway (Stripe example)
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key

# File Upload
MAX_FILE_SIZE=10485760
UPLOAD_PATH=./uploads

# Frontend URL
FRONTEND_URL=http://localhost:5173

# Session Configuration
SESSION_SECRET=your_session_secret

# Rate Limiting
RATE_LIMIT_WINDOW=15
RATE_LIMIT_MAX_REQUESTS=100
```

### Frontend Configuration

1. Navigate to the frontend directory:
```bash
cd ../frontend
```

2. Copy the example environment file:
```bash
cp .env.example .env
```

3. Edit `.env` file:

```env
VITE_API_URL=http://localhost:5000/api/v1
```

---

## Running the Application

### Using Demo Data (Recommended for First Run)

1. **Seed the Database** (creates demo data):
```bash
cd backend
npm run seed
```

This will create:
- Demo tenant (Demo School)
- Demo campus (Main Campus)
- Sample users (super admin, admin, principal, teacher)
- Sample classes and sections
- Sample subjects

Demo Login Credentials:
- **Super Admin**: superadmin@edutrack.com / Admin@123
- **School Admin**: admin@demoschool.com / Admin@123
- **Principal**: principal@demoschool.com / Principal@123
- **Teacher**: teacher@demoschool.com / Teacher@123

### Start Backend Server

```bash
cd backend
npm run dev
```

The backend API will be available at: `http://localhost:5000`

### Start Frontend Development Server

In a new terminal:

```bash
cd frontend
npm run dev
```

The frontend will be available at: `http://localhost:5173`

### Verify Installation

1. Open browser and go to `http://localhost:5173`
2. You should see the EduTrack login page
3. Login with demo credentials
4. Explore the dashboard

---

## Production Deployment

### Backend Deployment

#### 1. Prepare for Production

Update `.env` file:
```env
NODE_ENV=production
PORT=5000
# Update all other values with production credentials
```

#### 2. Build and Start

```bash
cd backend
npm start
```

#### 3. Using Process Manager (PM2)

Install PM2:
```bash
npm install -g pm2
```

Start application:
```bash
pm2 start src/server.js --name edutrack-api
pm2 save
pm2 startup
```

### Frontend Deployment

#### 1. Build for Production

```bash
cd frontend
npm run build
```

This creates optimized files in the `dist` directory.

#### 2. Serve Static Files

Option A - Using a static file server:
```bash
npm install -g serve
serve -s dist -p 3000
```

Option B - Using nginx:
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /path/to/frontend/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### Database Migration (Production)

For production, you may want to use migrations instead of `sync`:

1. Install Sequelize CLI:
```bash
npm install -g sequelize-cli
```

2. Initialize migrations:
```bash
sequelize init
```

3. Create migrations from models
4. Run migrations:
```bash
sequelize db:migrate
```

### Environment Variables in Production

Never commit `.env` files. Use:
- **Heroku**: Config vars in dashboard
- **AWS**: Systems Manager Parameter Store or Secrets Manager
- **Docker**: Environment variables in docker-compose or Kubernetes secrets
- **DigitalOcean**: App Platform environment variables

---

## Docker Deployment (Optional)

### 1. Create Dockerfile for Backend

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 5000
CMD ["npm", "start"]
```

### 2. Create docker-compose.yml

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:14-alpine
    environment:
      POSTGRES_DB: edutrack
      POSTGRES_USER: edutrack_user
      POSTGRES_PASSWORD: your_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  backend:
    build: ./backend
    ports:
      - "5000:5000"
    environment:
      NODE_ENV: production
      DB_HOST: postgres
      DB_PORT: 5432
      DB_NAME: edutrack
      DB_USER: edutrack_user
      DB_PASSWORD: your_password
    depends_on:
      - postgres

  frontend:
    build: ./frontend
    ports:
      - "3000:80"
    depends_on:
      - backend

volumes:
  postgres_data:
```

### 3. Run with Docker Compose

```bash
docker-compose up -d
```

---

## SSL/HTTPS Setup

### Using Let's Encrypt with Certbot

```bash
sudo apt-get update
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

---

## Troubleshooting

### Database Connection Issues

**Error**: "Unable to connect to the database"

**Solutions**:
1. Verify PostgreSQL is running:
   ```bash
   sudo service postgresql status
   ```

2. Check database credentials in `.env`

3. Test connection manually:
   ```bash
   psql -U edutrack_user -d edutrack -h localhost
   ```

4. Check PostgreSQL logs:
   ```bash
   sudo tail -f /var/log/postgresql/postgresql-14-main.log
   ```

### Port Already in Use

**Error**: "Port 5000 is already in use"

**Solutions**:
1. Find process using the port:
   ```bash
   lsof -i :5000
   ```

2. Kill the process:
   ```bash
   kill -9 <PID>
   ```

3. Or change port in `.env` file

### Module Not Found Errors

**Error**: "Cannot find module 'xyz'"

**Solutions**:
1. Delete node_modules and reinstall:
   ```bash
   rm -rf node_modules package-lock.json
   npm install
   ```

2. Clear npm cache:
   ```bash
   npm cache clean --force
   ```

### CORS Errors

**Error**: "Access to XMLHttpRequest blocked by CORS policy"

**Solutions**:
1. Verify `FRONTEND_URL` in backend `.env` matches frontend URL
2. Check CORS configuration in `src/server.js`
3. For development, you can temporarily allow all origins (NOT for production):
   ```javascript
   app.use(cors({ origin: '*' }));
   ```

### Email Not Sending

**Solutions**:
1. For Gmail, enable "Less secure app access" or use App Password
2. Check SMTP credentials in `.env`
3. Verify firewall allows outbound SMTP traffic
4. Check email service logs

### Frontend Build Errors

**Solutions**:
1. Clear cache:
   ```bash
   rm -rf node_modules .vite dist
   npm install
   ```

2. Check Node.js version:
   ```bash
   node --version
   ```

---

## Performance Optimization

### Backend

1. **Enable Compression**:
   ```bash
   npm install compression
   ```
   
   Add to server.js:
   ```javascript
   import compression from 'compression';
   app.use(compression());
   ```

2. **Add Redis for Caching**:
   ```bash
   npm install redis
   ```

3. **Database Indexing**: Ensure all foreign keys and frequently queried fields are indexed

### Frontend

1. **Code Splitting**: Vite handles this automatically
2. **Lazy Loading**: Use dynamic imports for routes
3. **Image Optimization**: Use WebP format and lazy loading
4. **CDN**: Serve static assets from CDN

---

## Backup and Recovery

### Database Backup

```bash
# Create backup
pg_dump -U edutrack_user -d edutrack > backup_$(date +%Y%m%d).sql

# Restore backup
psql -U edutrack_user -d edutrack < backup_20240101.sql
```

### Automated Backups

Create a cron job:
```bash
crontab -e
```

Add:
```
0 2 * * * pg_dump -U edutrack_user -d edutrack > /backups/edutrack_$(date +\%Y\%m\%d).sql
```

---

## Monitoring

### Application Monitoring

1. **PM2 Monitoring**:
   ```bash
   pm2 monit
   ```

2. **Logs**:
   ```bash
   pm2 logs edutrack-api
   ```

### Database Monitoring

```sql
-- Active connections
SELECT * FROM pg_stat_activity;

-- Database size
SELECT pg_size_pretty(pg_database_size('edutrack'));
```

---

## Security Checklist

- [ ] Change all default passwords
- [ ] Use strong JWT secrets
- [ ] Enable HTTPS in production
- [ ] Set up firewall rules
- [ ] Regular security updates
- [ ] Enable audit logging
- [ ] Implement rate limiting
- [ ] Use environment variables for secrets
- [ ] Regular database backups
- [ ] Keep dependencies updated

---

## Support

For issues and questions:
- GitHub Issues: https://github.com/Deusleon/EduTrack/issues
- Email: support@edutrack.com
- Documentation: See README.md and API_DOCUMENTATION.md

---

**Last Updated**: December 2024

## Subscription payments (ClickPesa)

Schools pay for EduTrack under **Settings group → Subscription**. The payment is a
mobile-money prompt (USSD push) handled by ClickPesa. The server needs these
environment variables, otherwise checkout answers *"Payments are not configured on
this server. Set CLICKPESA_CLIENT_ID and CLICKPESA_API_KEY."*

| Variable | Required | What it is |
| --- | --- | --- |
| `CLICKPESA_CLIENT_ID` | yes | Client ID from the ClickPesa dashboard (Developers / API keys) |
| `CLICKPESA_API_KEY` | yes | API key from the same page |
| `CLICKPESA_BASE_URL` | no | Only if ClickPesa gives you another address. Default `https://api.clickpesa.com` |
| `CLICKPESA_WEBHOOK_SECRET` | no | If set, the webhook must send the same value in `x-clickpesa-signature` or `x-webhook-secret` |

**Where to set them on cPanel:** *Setup Node.js App → open the backend app → Environment
variables → Add variable* (once per variable) → **Save** → **Restart**. Alternatively put
them in the `.env` file in the backend folder, then restart. They are read when the
server starts, so a restart is always needed.

**Webhook:** register `https://<your-backend-domain>/api/v1/webhooks/clickpesa` in the
ClickPesa dashboard. The webhook only says *which* invoice to look at. The server then
asks ClickPesa directly whether it was paid, so a forged call cannot switch a school on.
If the webhook is missed, the school's payment is still picked up when the Subscription
page polls the invoice status.

**Check the credentials** (platform super admin only):

```
POST /api/v1/subscription/gateway/test
```

It exchanges the credentials for a token and says plainly if something is wrong.

**Testing without paying:** `npm run seed:subscription -- list` shows ready-made states
(trial, active, expiring, grace, expired, cancelled) and a `pending` invoice that
`simulate-paid` completes. See `backend/src/utils/seedSubscriptionTestData.js`.

### Subscription lock and `DEVELOPER_EMAILS`

When a school's subscription expires (past its grace period) or is cancelled, every API area
answers 402 and the app shows only the **Subscription** page until a payment is confirmed.
This applies to every account of the school, **including a `super_admin`**. Only the platform
developer is exempt: a `super_admin` whose email is listed in `DEVELOPER_EMAILS`. Set that
variable (comma-separated) or nobody is exempt.

### Invoices and receipts

Seller details printed on invoices and receipts come from the frontend `.env`:
`VITE_COMPANY_NAME`, `VITE_COMPANY_ADDRESS`, `VITE_SUPPORT_PHONE`, `VITE_SUPPORT_EMAIL`,
`VITE_COMPANY_WEBSITE` and `VITE_COMPANY_TIN`. Blank values are left out. Rebuild the frontend
after changing them.

### Upgrading to this release

1. **Migration:** run `npm run db:migrate` in the backend. It adds `subscriptions.reminders_sent`
   (the record of which expiry reminders were already sent). Display settings need no migration.
2. **New packages:** run `npm install` in the backend (`jspdf`, `jspdf-autotable`, `qrcode` produce the
   invoice and receipt PDFs that are emailed).
3. **Set** `FRONTEND_URL` (the address people open EduTrack at) and the `PLATFORM_*` details in the
   backend environment, then restart. See `backend/.env.example`.
4. **Frontend:** rebuild. Optionally set `VITE_COMPANY_ADDRESS`, `VITE_SUPPORT_PHONE` and `VITE_COMPANY_TIN`
   (printed on invoices and receipts downloaded in the browser). Keep them in step with the `PLATFORM_*`
   values so a PDF looks the same wherever it is made.

### Reminders, clean-up and the audit trail

A job runs hourly inside the backend. It emails each school's administrators 7 days and 3 days before the
subscription ends, on the day it ends, and when it locks (each once per paid period); it records the moment a
school locks; and it cancels invoices that stay unpaid for 30 days. Every one of these, plus payments confirmed,
failed attempts and whether each email was sent, is written to **Settings → Audit Log** under *Other actions*.
Set `SUBSCRIPTION_JOBS=off` to disable the job (for instance on a second server that shares the database).

A payment can be confirmed by the gateway's webhook, by the school's status check and by the pay page at almost
the same moment. The invoice is locked while it is applied, so the subscription is extended, audited and
emailed exactly once.

### Installing EduTrack as an app (PWA)

The frontend ships a web-app manifest and a service worker (`public/sw.js`). The service worker keeps only the
app's own screens; it never stores API responses or school data. After deploying:

- serve it over **HTTPS** (browsers only allow installing from a secure address);
- make sure `sw.js` and `manifest.webmanifest` are **not cached by the server for long**. On Apache/cPanel,
  for example: `<FilesMatch "^(sw\.js|manifest\.webmanifest|index\.html)$"> Header set Cache-Control "no-cache" </FilesMatch>`
  (otherwise a new release can take a day to be noticed);
- every build stamps a new id into `sw.js`, so users see "A new version of EduTrack is ready — Reload".

## Setting up a new production database

Use this for a real installation. It creates only what EduTrack needs to run: the subscription plans, the
first school with its campus, and its administrator. There is no demo data.

1. Create an empty PostgreSQL database and put its details in the backend `.env` (`DB_NAME`, `DB_USER`, …).
2. Build the tables: `npm run db:migrate`
3. Add the essentials. The administrator's password is **yours**; there is no default, and weak or well-known
   passwords are refused:

   ```
   SEED_SCHOOL_NAME="Your School Name" SEED_SCHOOL_EMAIL=info@yourschool.ac.tz \
   SEED_ADMIN_EMAIL=admin@yourschool.ac.tz SEED_ADMIN_PASSWORD='a-long-password-2026' \
   npm run seed:production
   ```

   Optional: `SEED_SCHOOL_PHONE`, `SEED_SCHOOL_ADDRESS`, `SEED_SCHOOL_CITY`, `SEED_CAMPUS_NAME`,
   `SEED_ADMIN_FIRST_NAME`, `SEED_ADMIN_LAST_NAME`, and `SEED_DEVELOPER_EMAIL` + `SEED_DEVELOPER_PASSWORD`
   to also create the platform developer's login (then add that email to `DEVELOPER_EMAILS`).
4. Start the backend and sign in. Every login created this way must choose a new password at first sign-in.

It is safe to run again: it only adds what is missing and never changes or deletes anything. Run it with only
the plans (no `SEED_SCHOOL_NAME`) to add a plan later.

**Development only:** `npm run seed:dev` (also `npm run seed`) builds a full demo school with hundreds of
students; `npm run db:empty` wipes the database to a bare school. Both **erase everything** and refuse to run
when `NODE_ENV=production` unless `I_UNDERSTAND_THIS_ERASES_ALL_DATA=yes` is set.

## Sender IDs: school and system

Each gateway has two senders (Settings → Messages, platform developer only):

| | SMS | Email |
| --- | --- | --- |
| School messages: everything people send from Messages, and notices such as admissions, payments, results | **Sender ID** | **From Email / From Name** |
| System messages: password-reset codes and subscription invoices, receipts and reminders | **System Sender ID** | **System From Email / System From Name** |

If a system sender is left empty, the school's sender is used. Without a school email gateway, system emails
use `EMAIL_FROM_SYSTEM` if set, otherwise `EMAIL_FROM`. If a school's own mail server cannot send a subscription
email, the platform's mail server is tried. Both SMS Sender IDs must already be registered with your SMS provider.

## Invoice numbers

Invoice numbers come from a database sequence, so a number is never issued twice, even after invoices are
deleted (`npm run db:migrate` creates it; a database built another way creates it on first use). Cancelled
invoices older than 90 days are removed automatically; admins can also clean up from the Subscription page.
