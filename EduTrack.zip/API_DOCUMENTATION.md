# EduTrack API Documentation

## Base URL
```
http://localhost:5000/api/v1
```

## Authentication

All authenticated endpoints require a JWT token in the Authorization header:
```
Authorization: Bearer <token>
```

---

## Authentication Endpoints

### Register User
**POST** `/auth/register`

Create a new user account.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "Password123",
  "first_name": "John",
  "last_name": "Doe",
  "role": "teacher",
  "tenant_id": "uuid",
  "phone": "+1234567890"
}
```

**Response:**
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "id": "uuid",
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "role": "teacher",
    "tenant_id": "uuid",
    "token": "jwt_token"
  }
}
```

### Login
**POST** `/auth/login`

Authenticate user and receive JWT token.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "Password123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "id": "uuid",
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "role": "teacher",
    "tenant_id": "uuid",
    "token": "jwt_token"
  }
}
```

### Get Current User
**GET** `/auth/me`

Get currently authenticated user's information.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "role": "teacher",
    "tenant_id": "uuid"
  }
}
```

### Update Profile
**PUT** `/auth/profile`

Update user profile information.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "first_name": "John",
  "last_name": "Doe",
  "phone": "+1234567890",
  "avatar": "https://example.com/avatar.jpg"
}
```

### Change Password
**PUT** `/auth/change-password`

Change user password.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "current_password": "OldPassword123",
  "new_password": "NewPassword123"
}
```

---

## Student Endpoints

### Get All Students
**GET** `/students`

Get list of all students with pagination and filters.

**Headers:**
```
Authorization: Bearer <token>
```

**Query Parameters:**
- `campus_id` (optional): Filter by campus
- `class_id` (optional): Filter by class
- `section_id` (optional): Filter by section
- `status` (optional): Filter by status (active, inactive, graduated, transferred, expelled)
- `page` (optional, default: 1): Page number
- `limit` (optional, default: 10): Items per page

**Response:**
```json
{
  "success": true,
  "count": 100,
  "totalPages": 10,
  "currentPage": 1,
  "data": [
    {
      "id": "uuid",
      "admission_number": "STU001",
      "user": {
        "first_name": "Alice",
        "last_name": "Johnson",
        "email": "alice@example.com"
      },
      "campus": {
        "id": "uuid",
        "name": "Main Campus"
      },
      "class": {
        "id": "uuid",
        "name": "Grade 1",
        "grade": "1"
      },
      "section": {
        "id": "uuid",
        "name": "Section A"
      }
    }
  ]
}
```

### Create Student
**POST** `/students`

Create a new student.

**Headers:**
```
Authorization: Bearer <token>
```

**Required Roles:** super_admin, admin, principal

**Request Body:**
```json
{
  "email": "student@example.com",
  "password": "Password123",
  "first_name": "Alice",
  "last_name": "Johnson",
  "admission_number": "STU001",
  "campus_id": "uuid",
  "date_of_birth": "2010-05-15",
  "gender": "female",
  "blood_group": "O+",
  "address": "123 Street",
  "city": "City",
  "state": "State",
  "country": "Country",
  "postal_code": "12345",
  "admission_date": "2024-01-01",
  "class_id": "uuid",
  "section_id": "uuid",
  "parent_id": "uuid",
  "phone": "+1234567890",
  "emergency_contact": "+9876543210",
  "medical_info": {
    "allergies": [],
    "medications": []
  }
}
```

### Get Student by ID
**GET** `/students/:id`

Get detailed information about a specific student.

**Headers:**
```
Authorization: Bearer <token>
```

### Update Student
**PUT** `/students/:id`

Update student information.

**Headers:**
```
Authorization: Bearer <token>
```

**Required Roles:** super_admin, admin, principal

### Delete Student
**DELETE** `/students/:id`

Soft delete a student (sets status to inactive).

**Headers:**
```
Authorization: Bearer <token>
```

**Required Roles:** super_admin, admin, principal

---

## Attendance Endpoints

### Mark Attendance
**POST** `/attendance/mark`

Mark attendance for a single student.

**Headers:**
```
Authorization: Bearer <token>
```

**Required Roles:** super_admin, admin, principal, teacher

**Request Body:**
```json
{
  "student_id": "uuid",
  "class_id": "uuid",
  "section_id": "uuid",
  "date": "2024-01-15",
  "status": "present",
  "remarks": "Optional remarks"
}
```

**Status values:** present, absent, late, excused, half_day

### Bulk Mark Attendance
**POST** `/attendance/bulk-mark`

Mark attendance for multiple students at once.

**Headers:**
```
Authorization: Bearer <token>
```

**Required Roles:** super_admin, admin, principal, teacher

**Request Body:**
```json
{
  "class_id": "uuid",
  "section_id": "uuid",
  "date": "2024-01-15",
  "attendance_records": [
    {
      "student_id": "uuid1",
      "status": "present"
    },
    {
      "student_id": "uuid2",
      "status": "absent",
      "remarks": "Sick leave"
    }
  ]
}
```

### Get Attendance
**GET** `/attendance`

Get attendance records with filters.

**Headers:**
```
Authorization: Bearer <token>
```

**Query Parameters:**
- `class_id` (optional): Filter by class
- `section_id` (optional): Filter by section
- `student_id` (optional): Filter by student
- `date_from` (optional): Start date
- `date_to` (optional): End date
- `status` (optional): Filter by status
- `page` (optional, default: 1): Page number
- `limit` (optional, default: 10): Items per page

### Get Attendance Report
**GET** `/attendance/report`

Get attendance summary/report.

**Headers:**
```
Authorization: Bearer <token>
```

**Query Parameters:**
- `student_id` (optional): Filter by student
- `class_id` (optional): Filter by class
- `section_id` (optional): Filter by section
- `date_from` (optional): Start date
- `date_to` (optional): End date

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "student_id": "uuid",
      "total_days": 100,
      "present_days": 95,
      "absent_days": 3,
      "late_days": 2,
      "student": {
        "user": {
          "first_name": "Alice",
          "last_name": "Johnson"
        }
      }
    }
  ]
}
```

---

## Error Responses

All endpoints may return the following error responses:

### 400 Bad Request
```json
{
  "success": false,
  "message": "Validation error",
  "errors": [
    {
      "field": "email",
      "message": "Please provide a valid email"
    }
  ]
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "message": "Not authorized to access this route"
}
```

### 403 Forbidden
```json
{
  "success": false,
  "message": "User role 'student' is not authorized to access this route"
}
```

### 404 Not Found
```json
{
  "success": false,
  "message": "Resource not found"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "message": "Server Error"
}
```

---

## User Roles

The system supports the following user roles with different permissions:

- **super_admin**: Full system access across all tenants
- **admin**: Full access within a tenant
- **principal**: Campus-level administration
- **teacher**: Class and student management
- **student**: Access to personal academic information
- **parent**: Access to their child's information
- **accountant**: Financial management
- **librarian**: Library management
- **hr**: Staff management
- **transport_manager**: Transport management
- **hostel_warden**: Hostel management

---

## Rate Limiting

API requests are rate-limited to prevent abuse:
- Window: 15 minutes
- Max requests: 100 per window

---

## Pagination

List endpoints support pagination with the following query parameters:
- `page`: Page number (default: 1)
- `limit`: Items per page (default: 10, max: 100)

Paginated responses include:
```json
{
  "success": true,
  "count": 100,
  "totalPages": 10,
  "currentPage": 1,
  "data": [...]
}
```

---

## Notes

- All dates should be in ISO 8601 format (YYYY-MM-DD)
- UUIDs are used for all entity IDs
- Timestamps are automatically managed by the system
- All endpoints return JSON responses
- Multi-tenancy is enforced - users can only access data from their tenant
