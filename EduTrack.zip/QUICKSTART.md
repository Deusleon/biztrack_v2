# EduTrack Quick Start Guide

Get EduTrack up and running in 5 minutes!

## Prerequisites Check

Ensure you have installed:
- ✅ Node.js v18+ (`node --version`)
- ✅ PostgreSQL v12+ (`psql --version`)
- ✅ npm or yarn (`npm --version`)

## 🚀 Quick Start (5 minutes)

### Step 1: Clone & Install (2 minutes)

```bash
# Clone the repository
git clone https://github.com/Deusleon/EduTrack.git
cd EduTrack

# Install backend dependencies
cd backend
npm install

# Install frontend dependencies
cd ../frontend
npm install
```

### Step 2: Database Setup (1 minute)

```bash
# Open PostgreSQL and create database
psql -U postgres

# In psql:
CREATE DATABASE edutrack;
\q
```

### Step 3: Configure Environment (1 minute)

```bash
# Backend configuration
cd backend
cp .env.example .env

# Edit .env - Minimum required changes:
# DB_NAME=edutrack
# DB_USER=postgres
# DB_PASSWORD=your_postgres_password
# JWT_SECRET=your_secret_key_here
```

```bash
# Frontend configuration (optional, defaults work)
cd ../frontend
cp .env.example .env
```

### Step 4: Load Demo Data (30 seconds)

```bash
# From backend directory
cd backend
npm run seed
```

This creates:
- 1 Demo School (tenant)
- 1 Main Campus
- 4 Demo Users (super admin, admin, principal, teacher)
- 2 Classes with 2 sections
- 5 Subjects

### Step 5: Start the Application (30 seconds)

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
```

## 🎉 You're Ready!

Open your browser and visit: **http://localhost:5173**

### Login Credentials

Try these demo accounts:

| Role | Email | Password |
|------|-------|----------|
| Super Admin | superadmin@edutrack.com | Admin@123 |
| School Admin | admin@demoschool.com | Admin@123 |
| Principal | principal@demoschool.com | Principal@123 |
| Teacher | teacher@demoschool.com | Teacher@123 |

## 📱 What You Can Do Now

1. **Explore the Dashboard** - See all available modules
2. **Manage Students** - View the student management interface
3. **Track Attendance** - Check out the attendance system
4. **API Testing** - Try the API at http://localhost:5000

## 🔧 Troubleshooting

### Database Connection Error?
```bash
# Check PostgreSQL is running
sudo service postgresql status

# Verify credentials in .env file
cat backend/.env | grep DB_
```

### Port Already in Use?
```bash
# Backend (Port 5000)
lsof -i :5000
kill -9 <PID>

# Frontend (Port 5173)
lsof -i :5173
kill -9 <PID>
```

### Module Not Found?
```bash
# Reinstall dependencies
cd backend
rm -rf node_modules package-lock.json
npm install

# Same for frontend
cd ../frontend
rm -rf node_modules package-lock.json
npm install
```

## 📚 Next Steps

1. **Read the Full Documentation**
   - [README.md](README.md) - Complete overview
   - [API_DOCUMENTATION.md](API_DOCUMENTATION.md) - API reference
   - [DEPLOYMENT.md](DEPLOYMENT.md) - Production deployment

2. **Customize Your Installation**
   - Update tenant information
   - Add your school logo
   - Configure email/SMS services
   - Set up payment gateway

3. **Add Real Data**
   - Create your campuses
   - Add classes and sections
   - Import students
   - Set up fee structures

## 🛠️ Development Mode

### Backend Development
```bash
cd backend
npm run dev  # Auto-reload on changes
```

### Frontend Development
```bash
cd frontend
npm run dev  # Hot module reload
```

### Database Reset
```bash
cd backend
npm run seed      # Drops and recreates all tables WITH demo/fake data (~380 students, staff, etc.)
npm run db:empty  # Drops and recreates all tables EMPTY — just 1 tenant, 1 campus, and 2 logins (super admin + school admin), ready for real use/testing
```

⚠️ **Warning:** Both commands delete all existing data! Use `npm run db:empty` when you want to
start testing the real system from scratch instead of the demo dataset. It prints the login
credentials to the console when it finishes — change those passwords after your first login.
You can also override the school name/admin credentials via environment variables
(`SCHOOL_NAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, etc. — see the comment at the top of
`backend/src/utils/resetDatabase.js`).

## 📊 Default Configuration

| Service | Port | URL |
|---------|------|-----|
| Frontend | 5173 | http://localhost:5173 |
| Backend API | 5000 | http://localhost:5000 |
| Database | 5432 | localhost:5432 |

## 🔐 Security Note

The demo credentials are for development only. In production:
- Change all default passwords
- Update JWT secrets
- Use strong database passwords
- Enable HTTPS
- Configure proper CORS

## 💡 Tips

1. **Use Different Roles** - Login with different accounts to see role-based access
2. **Check API Responses** - Open browser DevTools to see API calls
3. **Monitor Logs** - Watch terminal output for debugging
4. **Database GUI** - Use pgAdmin or DBeaver to view database

## 🆘 Need Help?

- **Issues**: [GitHub Issues](https://github.com/Deusleon/EduTrack/issues)
- **Documentation**: See README.md and other docs
- **Email**: support@edutrack.com

## ✅ Verification Checklist

- [ ] Backend server running at http://localhost:5000
- [ ] Frontend running at http://localhost:5173
- [ ] Can access login page
- [ ] Can login with demo credentials
- [ ] Can see dashboard
- [ ] Can navigate to Students page
- [ ] Can navigate to Attendance page

If all checked, you're all set! 🎊

---

**Estimated Time**: 5 minutes
**Difficulty**: Easy
**Last Updated**: December 2024
