from dsl import *

def students_manage():
    return CH('students', 'Students', 'Academic › Students',
      'Everything about a student, from the first enquiry to graduation, lives under Academic. This chapter covers admitting students, finding them, keeping their records and handling online applications.',
      H2('Admitting one student'),
      OL(['Open **Students → Add Admission**.', 'Fill in **Personal Information**: First Name, Middle Name, Last Name, Date of Birth, Gender.',
          'Fill in **Academic Information**: Campus, Class / Grade, Section, Admission Number and Admission Date.',
          'Fill in **Address Information** and **Parent / Guardian Information**. Enter the parent\'s phone, and email if you have it.',
          'Under **Additional Options**, set **Transport Required** and **Hostel Required** if they apply.', 'Optionally add **Documents**, such as a medical clearance letter.', 'Click **Submit Admission**.']),
      P('The required fields are first name, last name, gender, date of birth, campus, admission date and admission number. If one is missing, the form tells you which.'),
      WARN('After saving, a **Student Admitted Successfully** window shows the student\'s login email and password. The password is stored scrambled and cannot be shown again. Copy it or share it with the family before you close the window.'),
      P('When a parent phone or email is entered, EduTrack sends an **Admission Completed** notice with the admission number and class. After saving you are told what happened: the notice was handed to the SMS gateway or email provider; it could not be sent (with the reason); no SMS gateway is active so nothing was sent; or the notice is switched off in Settings → Notifications.'),
      H2('Admitting many students at once, with a check first'),
      P('Use **Students → Bulk Upload**. EduTrack checks every row of your Excel file **before anything is saved**, so you see the problems while they are still easy to fix.'),
      OL(['**Step 1:** click **Download Template (.xlsx)**. The **Reference** sheet lists your exact Campus and Class names.',
          'Fill in the **Students** sheet, one student per row. Columns marked * are required: first name, last name, gender, date of birth, admission number, admission date and campus. Write dates as **YYYY-MM-DD**, for example 2019-03-27.',
          '**Step 2:** choose your filled file. EduTrack reads it and checks every row straight away.',
          '**Step 3: Check the File.** You see how many rows are **Ready**, how many have **errors**, and how many are **possible duplicates**, and the reason for every problem on the row it belongs to. Row numbers are the real Excel row numbers.',
          'Choose what to import (see below), then click **Admit N students** and confirm. A safety backup of the whole database is made first.']),
      TABLE(['What the check finds', 'What it means'], [
        ['Ready', 'The row will be admitted.'],
        ['Has errors', 'The row cannot be admitted. Missing name, gender or date; a date that is not a real date (such as 31 February); a birth date in the future; a campus, class or section that does not exist; an invalid parent email.'],
        ['Duplicates blocked', 'The admission number already belongs to a student in the school, or appears twice in the file.'],
        ['Possible duplicate', 'Nothing is wrong, but a student with the same name and date of birth already exists, or appears earlier in the file. These start **unticked**: you decide.'],
        ['Warnings', 'The row will still be imported, but look twice: an unusual age, no class given, or a parent contact without a parent name.'],
        ['Plan limit', 'If your subscription allows a limited number of students, rows beyond the limit are shown as errors.']], [4.2, 11.8]),
      UL(['Tick or untick rows in the table. Rows with errors cannot be ticked. Use the tabs **Ready**, **Possible duplicates** and **Errors** to focus.',
          '**Download the problems (Excel)** gives you a list of every row that needs fixing, with the reason, so you can correct your file and upload it again.',
          'Each row is saved on its own: one failing row never stops the rest. The results table then lists each student\'s admission number and a **Parent Notice** result.',
          'One upload can hold up to 500 students. Split larger files.']),
      TIP('Fix the errors in your Excel file and upload it again as often as you like. Nothing is saved until you click **Admit**.'),
      H2('Finding and managing students'),
      P('The Students page lists students with their Admission No., Class, Gender, Age and Status. Narrow the list with **Search** (name or admission number), **Campus**, **Class**, **Gender** and **Status**. Row actions: **View Details**, **Edit Student**, **Deactivate** (the student no longer attends; records are kept) and **Reactivate**. A student admitted without a class is still listed, with **No class set**, until a class is given.'),
      TABLE(['Student record tab', 'What it holds'], [
        ['Overview', 'Photo, class, key facts and quick figures.'], ['Details', 'Personal, address and parent or guardian information.'],
        ['Statistics', 'Attendance rate and academic figures.'], ['Attendance', 'A month-by-month calendar of present, absent, late, excused and half-day marks.'],
        ['Documents', 'Uploaded files such as certificates and letters, each with a Category and optional title.']], [4.2, 11.8]),
      P('To add or change the photo, click the pencil on the picture (JPG, PNG or WEBP, up to 2 MB). This is the photo printed on the student\'s ID card.'),
      H2('Common problems'),
      TABLE(['Problem', 'What to do'], [
        ['The admission number is rejected', 'It must be unique. Choose another one.'],
        ['A student is missing from the list', 'Check Status, Campus and the Academic year at the top of the page.'],
        ["The new student's password was not saved", 'It cannot be shown again. The family can use Forgot password? The code goes to the parent, so the parent\'s phone or email must be on the record.'],
        ['The upload says a class does not exist', 'The class name must match exactly. Check the Reference sheet, and the Academic year at the top.'],
        ['A login already exists for this admission number', 'An older record is still using it. Use a different admission number.']], [5.5, 10.5]))

def applications_promotion():
    return CH('applications', 'Online Applications and Promotion', 'Academic › Online Applications / Promotion',
      'Families can send an admission enquiry from the school website, and at the end of the year whole classes move up together.',
      H2('Online applications'),
      P('An enquiry from the school website appears in **Students → Online Applications** with a reference number.'),
      OL(['Use **Search** or the **Status** filter to find the application.', 'Click **View Details** to read the student and Parent / Guardian information.',
          'Click **Mark Contacted** once you have spoken to the family.', 'Click **Start Admission** to open the admission form, or **Decline** to close the application.']),
      H2('Promoting students to the next year'),
      OL(['Open **Promotion**. Choose the **Year Being Closed** and the **Year Being Opened**.',
          'For each class, set what happens to every student: **Promote**, **Repeat year** or **Graduate**. Only a final-year class can graduate.',
          'Click **Preview Promotion**. The counts **To Promote**, **To Graduate** and **Repeating** let you check before anything changes.', 'Confirm to apply it.']),
      WARN('Before a promotion runs, EduTrack makes a fresh tested backup of the whole database automatically, so a promotion can always be undone from the backup if something goes badly wrong. If that backup cannot be made, the promotion does not run and you are told why. You can also **revert** a promotion afterwards from the promotion history.'),
      P('A student who repeats stays in the same grade in the new year, so that grade must already exist as a class in the new year. For a single student who must move during the year, use **Individual Mid-Year Promotion**: pick the student, choose **Promote To** (and an optional Section), then click **Promote Now**.'),
      H2('Common problems'),
      TABLE(['Problem', 'What to do'], [
        ['A repeating student blocks promotion', 'Create the same grade as a class in the new year first.'],
        ['The promotion would not run and mentions a backup', 'The safety backup could not be made. Ask the system owner to check Settings → Database Backup.']], [5.5, 10.5]))

def students_view():
    return CH('students', 'Students (view only)', 'Academic › Students',
      'You can look up any student and open their record. Adding or changing students is done by the office.',
      H2('Finding a student'),
      P('The Students page lists students with their Admission No., Class, Gender, Age and Status. Narrow the list with **Search** (name or admission number), **Class**, **Gender** and **Status**. Click **View Details** to open a student.'),
      TABLE(['Student record tab', 'What it holds'], [
        ['Overview', 'Photo, class, key facts and quick figures.'], ['Details', 'Personal, address and parent or guardian information.'],
        ['Statistics', 'Attendance rate and academic figures.'], ['Attendance', 'A month-by-month calendar of present, absent, late, excused and half-day marks.']], [4.2, 11.8]),
      NOTE('Buttons to add, edit or deactivate a student, and the **Documents** tab, are not shown to you because your role does not include them. If a record needs correcting, tell the school office.'),
      H2('Common problems'),
      TABLE(['Problem', 'What to do'], [['A student is missing from the list', 'Check Status and the Academic year at the top of the page.']], [5.5, 10.5]))

def staff_manage(hr=False):
    return CH('staff', 'Staff', 'HR › Staff',
      'The Staff page holds every teacher and employee: their login, role, employment terms and documents. Staff pay, ID and bank details are visible only to people with permission to see them, usually administrators, principals and HR managers.',
      H2('Adding one staff member'),
      OL(['Open **HR → Staff** and choose to add a staff member.', 'Enter **First Name**, **Middle Name**, **Last Name**, **Email** and **Phone**. The email is their login.',
          'Choose their **Role**. It is not pre-selected, so pick what this person does at the school.', 'Fill in the personal details: Date of Birth, Gender, Marital Status, National ID (NIDA).',
          'Fill in the employment details: Campus, Employee Number, Department, Designation, Joining Date, Contract Type, Salary, Years of Experience and, for fixed-term staff, Contract End Date.',
          'Add the statutory and bank details: TIN Number, NSSF Number, Bank Name and Bank Account Number.', 'For teachers, choose their **Teaching Subjects**.',
          'Add Address, City and Country, and an **Emergency Contact**.', 'Save.']),
      P('The new person signs in with their email and the standard staff password, and is asked to choose their own the first time. Contract type can be Permanent, Contract or Part-Time. Status can be Active, Inactive, On Leave or Terminated.'),
      H2('Adding many staff at once, with a check first'),
      P('Use **Staff → Bulk Upload**. Like the student upload, every row is checked **before anything is saved**.'),
      OL(['Click **Download Template (.xlsx)**. The **Reference** sheet lists your exact Campus names and the Roles you can use.',
          'Fill in the **Staff** sheet, one person per row. Required: First Name, Last Name, **Email (login)**, **Role**, **Employee Number** and **Campus**. Write dates as YYYY-MM-DD.',
          'Choose your filled file. EduTrack checks it straight away and shows **Step 3: Check the File**.', 'Choose what to import and click **Add N staff**. A safety backup of the whole database is made first.']),
      TABLE(['What the check finds', 'What it means'], [
        ['Has errors', 'A missing name, email, role, employee number or campus; an email that is not valid; a role that does not exist or that you may not hand out; a date that is not a real date; a salary that is not a number; an unknown contract type.'],
        ['Duplicates blocked', 'The employee number, email or phone already belongs to someone, or appears twice in the file.'],
        ['Possible duplicate', 'The same national ID, or the same name and date of birth, already exists or appears earlier in the file. These start unticked: you decide.'],
        ['Warnings', 'The row will be imported, but look twice: no salary yet, an unusual age, or a fixed-term contract with no end date.']], [4.2, 11.8]),
      NOTE('Teaching subjects, documents and **Reports To** are added afterwards on each person\'s record (**Staff → Edit**), because they are chosen from lists. Every new person gets a login that must be changed at first sign-in.'),
      H2('Roles you can give'),
      P('Teacher, Principal, Admin, Accountant, Librarian, HR Manager, Transport Manager and Hostel Warden. A few rules keep the school safe:'),
      UL(['Administrators can give any staff role.', 'Principals and HR managers can change everyday roles such as teacher, accountant or librarian, but cannot give or take away **Admin** or **Principal**.',
          'Nobody can change their own role. Ask another administrator.', "A super admin's role cannot be changed from this screen."]),
      TIP('Every change, including a role change with the old and new value, is recorded in Settings → Audit Log.' if not hr else 'Every change, including a role change, is recorded in the audit log that administrators can read.'),
      H2('Finding and managing staff'),
      P('The list shows each Staff Member, their Role / Department, Campus and Status. Narrow it with **Search** (name or employee number), **Status**, **Campus** and **Contract Type**. Row actions: **View Details**, **Edit Staff**, **Deactivate** and **Reactivate**. Deactivating keeps all records but stops the person being treated as current staff.'),
      TABLE(['Staff record tab', 'What it holds'], [
        ['Overview', 'Name, email, phone, role, date of birth, gender, marital status, national ID, address and emergency contact.'],
        ['Employment', 'Campus, employee number, department, designation, who they report to, contract dates, TIN, NSSF and bank details.'],
        ['Statistics', "Figures about the person's work."], ['Timetable', 'The periods this person teaches.'],
        ['Leave', 'Leave Balances and Recent Requests.'], ['Documents', 'National ID copy, appointment letter, contract, certificates, CV and other files.']], [4.2, 11.8]),
      H2('Common problems'),
      TABLE(['Problem', 'What to do'], [
        ['The Role field is locked', 'Your own role does not allow changing roles, or you are looking at your own record. Ask an administrator.'],
        ['I cannot see salary or bank details', 'That needs the permission to see staff pay, ID and bank details.'],
        ['A new teacher has no timetable', 'Assign them to periods in Academic → Timetable.'],
        ['A leaver still appears', 'Choose Deactivate, or set Status to Terminated, then filter the list by Status.'],
        ['A staff upload row says the email is already registered', 'Each login must be unique. Use the person\'s own email, or find their existing record.']], [5.5, 10.5]))

def classes_setup():
    return CH('classes', 'Classes, Subjects and Timetable', 'Academic › Classes / Subjects / Timetable',
      'Set these up once at the start of each year and almost everything else follows: students are placed in classes, marks are entered by subject, and teachers see their periods. Do them in this order: Classes, then Subjects, then Timetable.',
      H2('Classes'),
      P('A class belongs to one campus and one academic year. It can be split into streams (sections) such as A, B, East or West.'),
      OL(['Open **Academic → Classes** and choose to add a class.', 'Choose the **Campus**.', 'Enter the **Class Name**, for example Class 5A or Form 3.',
          'Choose the **Education Level**, the **Grade** and the **Academic Year**.', 'Enter the **Capacity** and an optional description.', 'Leave **Status** as Active and save.']),
      P('Open a class with **View Details**. Use **Add Stream** to create a stream with a **Stream Name** and a **Capacity**, and assign a **Class Teacher** to it. The class page also shows Total Streams, Total Students, Capacity and Occupancy Rate. Row actions on the list: **View Details**, **Edit Class**, **Deactivate**, **Reactivate**.'),
      NOTE('Each academic year has its own set of classes. When a new year starts, create its classes before you promote students into them.'),
      H2('Subjects'),
      OL(['Open **Academic → Subjects** and choose to add a subject.', 'Enter the **Subject Name** and **Subject Code**, for example Mathematics and MATH101.', 'Enter the **Credits**, choose the **Campus** (or All Campuses), and add an optional description.', 'Choose **Compulsory** or **Elective**, then save.']),
      H2('Timetable'),
      P('The timetable has two parts: **Setup**, used by administrators and principals, and the grid itself, where administrators, principals and teachers place lessons. Everyone else can view it.'),
      OL(['**Describe the school week.** Open **Academic → Timetable → Setup**, choose the **Education Level**, then on the **School Week** tab enter when the day starts, the minutes per period, the periods per day (Mon–Thu) and on Friday, and the tea and lunch breaks. Click **Save School Week**.',
          '**Say what each class studies.** On the **Class Subjects** tab choose a **Class**, tick every subject it studies and set how many periods a week each gets. Optionally choose the usual teacher. Click **Save Subjects**.',
          '**Fill the grid.** Open **Timetable → Class View**, pick the Class and Section, and click a period cell to choose the Subject and Teacher. For a subject taught in two periods in a row, tick **Double period**. **Auto-Fill** fills empty cells only, spreads each subject across different days and avoids booking a teacher twice.']),
      P('**All Classes** shows every class at once, **Teacher View** shows one teacher\'s week (the quickest way to spot a clash), and **Export** saves a class timetable as a PDF.'),
      WARN('The **Clear** action empties a whole section\'s timetable. Use it only when you mean to start again.'),
      H2('Common problems'),
      TABLE(['Problem', 'What to do'], [
        ['A subject is not offered when I click a period', 'Add it to that class on the Class Subjects tab first.'],
        ['The class I need is missing', 'Check the Academic year at the top of the page. Classes belong to one year.'],
        ['A teacher is double-booked', 'Open Teacher View to find the clash, then move one lesson.'],
        ['Auto-Fill could not place everything', 'The message names the subject and how many periods are short. Add periods per day or reduce that subject\'s weekly periods.']], [5.5, 10.5]))

def timetable_teacher():
    return CH('timetable', 'Subjects and Timetable', 'Academic › Subjects / Timetable',
      'See what is taught, and see and arrange your own lessons.',
      H2('Subjects'),
      P('**Academic → Subjects** lists the subjects the school teaches, with their code, credits and whether they are compulsory or elective. Open one to see which classes take it. Adding or changing subjects is done by an administrator.'),
      H2('Timetable'),
      UL(['**Class View** shows one class\'s week. Pick the **Class** and **Section**.', '**Teacher View** shows one teacher\'s week. Choose yourself to see your own lessons, or a colleague to avoid a clash.', '**All Classes** shows every class at once.', '**Export** saves a class timetable as a PDF for printing.']),
      P('You can place and change individual lessons: in **Class View**, click a period cell, choose the **Subject** and, if you wish, the **Teacher**. For a subject taught in two periods in a row, tick **Double period**.'),
      NOTE('The school week setup (period length, breaks) and **Auto-Fill** are for administrators and principals. If your timetable looks wrong, tell them.'),
      TABLE(['Problem', 'What to do'], [['A subject is not offered when I click a period', 'It has not been added to that class. Ask an administrator.'], ['A teacher is double-booked', 'Open Teacher View to find the clash, then move one lesson.']], [5.5, 10.5]))

def timetable_student():
    return CH('timetable', 'Timetable', 'Academic › Timetable',
      'Your timetable shows which lesson is on in each period, every day of the week.',
      H2('Looking at your timetable'),
      OL(['Open **Timetable** in the menu.', 'Choose **Class View**, then pick your **Class** and **Section**.', 'Read across the week: each box is a period with its subject and teacher.']),
      P('Use **Export** to save the timetable as a PDF to print or keep on your phone.'),
      NOTE('You can look at the timetable but not change it. If something looks wrong, tell your class teacher.'))

def attendance():
    return CH('attendance', 'Attendance', 'Academic › Attendance',
      'Taking a class register takes about a minute. Everyone starts as present, so you only change the exceptions.',
      H2('Taking attendance'),
      OL(['Click **Take Attendance**.', 'Choose the **Attendance Date**, the **Class** and, if the class has streams, the **Section / Stream**.',
          'The student list appears with everyone marked **Present**. Change a student\'s status with the buttons **P**, **A**, **E**, **L** and **H**.', 'Add a note in **Remarks** if it helps, for example sick or family event.', 'Save. You are told how many students were saved.']),
      TABLE(['Button', 'Status', 'Use it when'], [['P', 'Present', 'The student is in school.'], ['A', 'Absent', 'The student is away without a reason.'], ['E', 'Excused', 'The student is away with a valid reason.'], ['L', 'Late', 'The student arrived after the register opened.'], ['H', 'Half Day', 'The student attended for only part of the day.']], [2, 3.5, 10.5]),
      TIP('To mark most of a class the same way, use **Mark all as** and then change the exceptions.'),
      UL(['Attendance cannot be taken for a **future date**.', 'It can only be taken for the **current calendar year**. A closed year cannot be back-filled.', 'If the class has sections, you must choose one before saving.']),
      H2('Reviewing attendance'),
      P('The main page, **Attendance Management**, lists each register that was taken: Date, Class / Section, Total, Present, Absent, Excused and Rate.'),
      OL(['Narrow the list with **Class**, **Section**, **Date From** and **Date To**, then click **Apply** (**Reset** clears the filters).', 'Open a register to see every student\'s status, Remarks, Marked By and Edited By.', 'Use **Export** to download the register as PDF or Excel.']),
      H2('Correcting a mistake'),
      OL(['Open the register and click edit on the student\'s row.', 'Choose the correct status.', 'Enter **Remarks**. They are required whenever you change a saved record, so the reason is kept.', 'Save. The row now shows who edited it.']),
      H2('Common problems'),
      TABLE(['Problem', 'What to do'], [
        ['No students appear', 'Check you chose the right class and section, and that students are placed in that class for the selected academic year.'],
        ['"Attendance can\'t be taken for a future date"', "Choose today's date or earlier."],
        ['A saved register needs a change', 'Edit the row and give a reason in Remarks.']], [5.5, 10.5]))

GRADES = TABLE(['Percentage', 'Grade'], [['75% and above', 'A'], ['65% to 74%', 'B'], ['45% to 64%', 'C'], ['30% to 44%', 'D'], ['Below 30%', 'F']], [6, 4])

REPORT_CARD = [
  H2('Report cards'),
  P('A report card shows one student\'s results for a whole term, with one row per subject. It does not matter which exam of the term you open it from: you always get the same term card.'),
  TABLE(['Column', 'What it shows'], [
    ['Test', 'The average of the student\'s results in every test of the term. A test is any exam in that term that is not a Final: Midterm, Quiz, Mock or Continuous Assessment.'],
    ['Exam', "The student's score in the term's Final exam, as a percentage. If the paper was not marked out of 100, the marks are shown underneath, for example 45/60."],
    ['Average', 'The average of the Test and Exam columns.'], ['Grade', 'The grade for that Average.'],
    ['Remark', 'Excellent, Good, Satisfactory, Needs Improvement or Fail.']], [3, 13]),
  P('Under the table, four boxes show the **Total Score**, the **Average**, the **Overall Grade** and the **Class Position**. Click **Print Report Card** to print it, or **Download PDF** to save it. All figures are percentages, so a quiz marked out of 10 and a test marked out of 100 count equally. A missing column shows a dash and is never counted as zero.'),
]

def exams(role_kind):
    """role_kind: 'admin' (creates exams too) or 'teacher'."""
    blocks = []
    if role_kind == 'admin':
        blocks += [H2('Creating an exam'), P('Administrators and principals create exams under **Examinations → Exams**.'),
          OL(['Choose to add an exam.', 'Enter the **Exam Name**, for example Midterm 2026.', 'Choose the **Type**: Midterm, Final, Mock, Quiz or Continuous Assessment.', 'Choose the **Term**, the **Start Date** and **End Date**, and the **Campus**.',
              'Under **Applicable Classes**, tick the classes that sit this exam.', 'Set the status (Draft, Scheduled, Ongoing or Completed), then save.']),
          TIP('Create the term\'s final paper with the exam type **Final**. The report card\'s Exam column is taken from it, and every exam of any other type in that term counts as a test.')]
    else:
        blocks += [NOTE('Exams are created by an administrator or the principal. Your part is entering marks and reading results.')]
    blocks += [H2('Entering marks'),
      OL(['On the exam\'s row, click **Enter Marks**.', 'Choose the **Class**, optionally the **Section**, and the **Subject**.', 'Set **Out of**, the maximum marks for this paper.',
          'Click **Load Students**. Every active student in that class appears with a box for their mark.', 'Type the marks. The **Grade** letter updates as you type.', 'Click **Save Marks**.']),
      P('It is safe to reopen and edit marks later. The page pre-fills what was already saved, and saving again updates the same records.'),
      H2('How grades are given'), GRADES,
      H2('Viewing results'),
      P('Open **Examinations → Results**, choose the **Exam**, **Class** and optionally **Section**, and view the mark sheet. It shows every student against every subject that has marks, with Total, Average, Grade and Position. Each row links to that student\'s report card.')]
    blocks += REPORT_CARD
    blocks += [H2('Term summary'), P('**Results → Term Summary** combines every exam in a term into one consolidated report per subject. Choose the **Term**, **Class** and optionally **Section**.'),
      H2('Common problems'),
      TABLE(['Problem', 'What to do'], [
        ['A student is missing from the marks list', 'Only active students placed in that class and section for the selected academic year appear.'],
        ['A grade looks wrong', 'Check the Out of value. Grades are worked out from marks as a percentage of it.'],
        ['The Exam column is empty on a report card', 'The term has no exam of type Final, or no marks are entered for it yet.'],
        ['The Test column is empty', 'The term has no exam other than the Final, or no test marks are entered for that subject.']], [5.5, 10.5])]
    return CH('exams', 'Exams, Results and Report Cards', 'Examinations › Exams / Results',
      'The flow has three steps: an administrator creates the exam, teachers enter marks, and then results and report cards are ready to view and print.', *blocks)

def results_portal(kind):
    child = kind == 'parent'
    return CH('results', 'Exams and Results', 'Examinations › Results' + ('' if child else ' / Exams'),
      ('See how your child is doing: every exam, every subject, and the full term report card.' if child else 'See your own results and your full term report card.'),
      H2('Opening a report card'),
      OL((['Open **Results** in the menu.', 'Choose a **Child**. It is selected for you if you have only one.', 'Choose an **exam** and open the report card.'] if child else
          ['Open **Results** (or **Exams**) in the menu.', 'You see the list of exams that have marks for you.', 'Open one to see your own report card.'])),
      *REPORT_CARD[1:],
      H2('How grades are given'), GRADES,
      NOTE(('Only you, the school staff and the student can open a report card. If a child\'s results do not appear, the child may not be linked to your account yet: ask the school office to link them on the student record.' if child else 'Only you and the school staff can open your report card.')),
      H2('Common problems'),
      TABLE(['Problem', 'What to do'], [
        (['A child\'s results do not appear', 'The child must be linked to your account on the student record. Ask the school office.'] if child else ['An exam is missing', 'Only exams that have marks entered for you are listed. Marks may not be in yet.']),
        ['The Exam column is empty', 'The final exam has not been marked yet. It will fill in once marks are entered.']], [5.5, 10.5]))
