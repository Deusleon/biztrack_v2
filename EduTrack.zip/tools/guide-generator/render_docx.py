import re, io, copy
from PIL import Image
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

NAVY = RGBColor(0x0A, 0x3C, 0x8C); GREEN = RGBColor(0x3A, 0x8F, 0x2E); MUTED = RGBColor(0x6B, 0x72, 0x80); INK = RGBColor(0x1F, 0x29, 0x37)
CALL = {'note': ('EEF4FF', '2563EB', 'NOTE'), 'tip': ('EEF9F0', '2F8F46', 'TIP'), 'warn': ('FFF5E6', 'D97706', 'WARNING')}
FONT = 'Calibri'

def shade(cell, hexfill):
    tcPr = cell._tc.get_or_add_tcPr(); shd = OxmlElement('w:shd'); shd.set(qn('w:val'), 'clear'); shd.set(qn('w:color'), 'auto'); shd.set(qn('w:fill'), hexfill); tcPr.append(shd)

def borders(cell, **edges):
    tcPr = cell._tc.get_or_add_tcPr(); b = OxmlElement('w:tcBorders')
    for edge in ('top', 'left', 'bottom', 'right'):
        e = OxmlElement(f'w:{edge}'); spec = edges.get(edge)
        if spec: e.set(qn('w:val'), 'single'); e.set(qn('w:sz'), str(spec[0])); e.set(qn('w:color'), spec[1])
        else: e.set(qn('w:val'), 'nil')
        b.append(e)
    tcPr.append(b)

def cell_margins(cell, top=60, bottom=60, left=110, right=110):
    tcPr = cell._tc.get_or_add_tcPr(); m = OxmlElement('w:tcMar')
    for k, v in (('top', top), ('left', left), ('bottom', bottom), ('right', right)):
        e = OxmlElement(f'w:{k}'); e.set(qn('w:w'), str(v)); e.set(qn('w:type'), 'dxa'); m.append(e)
    tcPr.append(m)

def runs(par, text, size=None, color=None, bold=None, italic=None):
    """**bold** and `code` into runs."""
    for part in re.split(r'(\*\*.+?\*\*|`.+?`)', str(text)):
        if not part: continue
        if part.startswith('**'): r = par.add_run(part[2:-2]); r.bold = True
        elif part.startswith('`'): r = par.add_run(part[1:-1]); r.font.name = 'Consolas'; r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Consolas')
        else: r = par.add_run(part); r.bold = bold
        if size: r.font.size = Pt(size)
        if color is not None and not part.startswith('`'): r.font.color.rgb = color
        if italic: r.italic = True
    return par

def para(doc_or_cell, text='', size=10.5, color=INK, after=6, before=0, align=None, bold=None, italic=None, keep_next=False):
    p = doc_or_cell.add_paragraph(); pf = p.paragraph_format; pf.space_after = Pt(after); pf.space_before = Pt(before); pf.line_spacing = 1.2
    if keep_next: pf.keep_with_next = True
    if align: p.alignment = align
    if text: runs(p, text, size=size, color=color, bold=bold, italic=italic)
    return p

def page_field(par):
    for t, txt in (('begin', None), (None, ' PAGE '), ('end', None)):
        r = par.add_run()
        if t: f = OxmlElement('w:fldChar'); f.set(qn('w:fldCharType'), t); r._r.append(f)
        else: i = OxmlElement('w:instrText'); i.set(qn('xml:space'), 'preserve'); i.text = txt; r._r.append(i)
        r.font.size = Pt(8.5); r.font.color.rgb = MUTED

def set_widths(table, widths_cm, total_cm):
    ws = [w * total_cm / sum(widths_cm) for w in widths_cm]
    table.autofit = False
    tblPr = table._tbl.tblPr; lay = OxmlElement('w:tblLayout'); lay.set(qn('w:type'), 'fixed'); tblPr.append(lay)
    for row in table.rows:
        for i, c in enumerate(row.cells): c.width = Cm(ws[i])

def spacer(doc, after=2):
    """A near-zero-height gap, so a trailing gap can never spill onto a page of its own."""
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(after); p.paragraph_format.space_before = Pt(0); p.paragraph_format.line_spacing = 1.0
    pPr = p._p.get_or_add_pPr(); rPr = OxmlElement('w:rPr'); sz = OxmlElement('w:sz'); sz.set(qn('w:val'), '4'); rPr.append(sz); pPr.append(rPr)
    return p

def data_table(doc, head, rows, widths, total):
    t = doc.add_table(rows=1 + len(rows), cols=len(head)); t.alignment = WD_TABLE_ALIGNMENT.CENTER
    thin = (4, 'D1D5DB')
    for ci, h in enumerate(head):
        c = t.rows[0].cells[ci]; shade(c, '0A3C8C'); borders(c, top=thin, left=thin, bottom=thin, right=thin); cell_margins(c)
        p = c.paragraphs[0]; p.paragraph_format.space_after = Pt(0); runs(p, h, size=9.5, color=RGBColor(255, 255, 255), bold=True)
    for ri, row in enumerate(rows, 1):
        for ci, v in enumerate(row):
            c = t.rows[ri].cells[ci]; borders(c, top=thin, left=thin, bottom=thin, right=thin); cell_margins(c)
            if ri % 2 == 0: shade(c, 'F3F6FB')
            p = c.paragraphs[0]; p.paragraph_format.space_after = Pt(0); runs(p, v, size=9.5, color=INK)
    # repeat header row, never split a row across pages
    trPr = t.rows[0]._tr.get_or_add_trPr(); h = OxmlElement('w:tblHeader'); h.set(qn('w:val'), 'true'); trPr.append(h)
    for row in t.rows:
        trPr = row._tr.get_or_add_trPr(); cs = OxmlElement('w:cantSplit'); cs.set(qn('w:val'), 'true'); trPr.append(cs)
    if len(rows) <= 12:  # a short table stays on one page
        for row in t.rows[:-1]:
            for c in row.cells:
                for pp in c.paragraphs: pp.paragraph_format.keep_with_next = True
    set_widths(t, widths or [1] * len(head), total)
    spacer(doc, 4)

def callout(doc, kind, text, total):
    fill, bar, label = CALL[kind]
    t = doc.add_table(rows=1, cols=1); t.alignment = WD_TABLE_ALIGNMENT.CENTER
    c = t.rows[0].cells[0]; shade(c, fill); borders(c, left=(24, bar)); cell_margins(c, 90, 90, 160, 140)
    p = c.paragraphs[0]; p.paragraph_format.space_after = Pt(1)
    r = p.add_run(label); r.bold = True; r.font.size = Pt(8.5); r.font.color.rgb = RGBColor.from_string(bar)
    q = c.add_paragraph(); q.paragraph_format.space_after = Pt(0); runs(q, text, size=10, color=INK)
    set_widths(t, [1], total)
    trPr = t.rows[0]._tr.get_or_add_trPr(); cs = OxmlElement('w:cantSplit'); cs.set(qn('w:val'), 'true'); trPr.append(cs)
    spacer(doc, 4)

def list_item(doc, marker, text, indent_cm=0.75):
    p = doc.add_paragraph(); pf = p.paragraph_format; pf.left_indent = Cm(indent_cm); pf.first_line_indent = Cm(-indent_cm); pf.space_after = Pt(3); pf.line_spacing = 1.2
    pf.tab_stops.add_tab_stop(Cm(indent_cm))
    r = p.add_run(marker + '\t'); r.bold = True; r.font.color.rgb = NAVY; r.font.size = Pt(10.5)
    runs(p, text, size=10.5, color=INK)

def blocks(doc, bl, total):
    for b in bl:
        k = b[0]
        if k == 'h2': doc.add_heading(b[1], level=2)
        elif k == 'p': para(doc, b[1])
        elif k == 'ul':
            for it in b[1]: list_item(doc, '•', it, 0.6)
            doc.paragraphs[-1].paragraph_format.space_after = Pt(8)
        elif k == 'ol':
            for i, it in enumerate(b[1], 1): list_item(doc, f'{i}.', it, 0.75)
            doc.paragraphs[-1].paragraph_format.space_after = Pt(8)
        elif k in ('note', 'tip', 'warn'): callout(doc, k, b[1], total)
        elif k == 'table': data_table(doc, b[1], b[2], b[3], total)

def h1(doc, text, new_page=True):
    h = doc.add_heading(text, level=1)
    if new_page: h.paragraph_format.page_break_before = True
    return h

def style_headings(doc):
    st = doc.styles
    n = st['Normal']; n.font.name = FONT; n.font.size = Pt(10.5); n.element.rPr.rFonts.set(qn('w:eastAsia'), FONT)
    for name, size, color, before, after in (('Heading 1', 22, NAVY, 0, 8), ('Heading 2', 13, NAVY, 14, 5), ('Title', 34, NAVY, 0, 6)):
        s = st[name]; s.font.name = FONT; s.font.size = Pt(size); s.font.bold = True; s.font.color.rgb = color
        s.element.rPr.rFonts.set(qn('w:ascii'), FONT); s.element.rPr.rFonts.set(qn('w:hAnsi'), FONT); s.element.rPr.rFonts.set(qn('w:eastAsia'), FONT)
        s.paragraph_format.space_before = Pt(before); s.paragraph_format.space_after = Pt(after)
        if name != 'Title': s.paragraph_format.keep_with_next = True


LIME = RGBColor(0xA7, 0xE5, 0x8F)
COPYRIGHT = '© 2026 EduTrack. All rights reserved. Not for redistribution.'
WATERMARK_OPACITY = 0.07

def tracking(run, pts):
    """Letter-spacing, like the cover of the original guide."""
    rPr = run._r.get_or_add_rPr(); sp = OxmlElement('w:spacing'); sp.set(qn('w:val'), str(int(pts * 20))); rPr.append(sp)

def faded_png(path, opacity):
    im = Image.open(path).convert('RGBA'); r, g, b, a = im.split(); im.putalpha(a.point(lambda v: int(v * opacity)))
    buf = io.BytesIO(); im.save(buf, 'PNG'); buf.seek(0); return buf

def add_watermark(header, logo_path, width_cm=13.5, cover=False):
    """The logo, very faint, centred on the page and BEHIND the text (anchored, behindDoc), so nothing is hidden."""
    par = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
    run = par.add_run(); run.add_picture(faded_png(logo_path, WATERMARK_OPACITY), width=Cm(width_cm))
    inline = run._r.xpath('.//wp:inline')[0]
    anchor = OxmlElement('wp:anchor')
    for k, v in (('distT', '0'), ('distB', '0'), ('distL', '0'), ('distR', '0'), ('simplePos', '0'), ('relativeHeight', '0'), ('behindDoc', '1'), ('locked', '1'), ('layoutInCell', '1'), ('allowOverlap', '1')): anchor.set(k, v)
    sp = OxmlElement('wp:simplePos'); sp.set('x', '0'); sp.set('y', '0'); anchor.append(sp)
    for axis, rel in (('positionH', 'page'), ('positionV', 'page')):
        pos = OxmlElement(f'wp:{axis}'); pos.set('relativeFrom', rel); al = OxmlElement('wp:align'); al.text = 'center' if axis == 'positionH' else ('bottom' if cover else 'center'); pos.append(al); anchor.append(pos)
    anchor.append(copy.deepcopy(inline.find(qn('wp:extent'))))
    ee = OxmlElement('wp:effectExtent')
    for k in ('l', 't', 'r', 'b'): ee.set(k, '0')
    anchor.append(ee); anchor.append(OxmlElement('wp:wrapNone'))
    for tag in ('wp:docPr', 'wp:cNvGraphicFramePr'): anchor.append(copy.deepcopy(inline.find(qn(tag))))
    anchor.append(copy.deepcopy(inline.find(qn('a:graphic'))))
    inline.getparent().replace(inline, anchor)

def render_docx(guide, path, assets):
    r = guide['role']; logo, emblem = assets['logo'], assets['emblem']
    doc = Document(); style_headings(doc)
    sec = doc.sections[0]; sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2); sec.top_margin = Cm(2.6); sec.bottom_margin = Cm(2.1); sec.header_distance = Cm(0.9)
    total = 17.0
    sec.different_first_page_header_footer = True

    # header on every page after the cover: logo mark + "EduTrack", and the guide name on the right; watermark behind the text
    hp = sec.header.paragraphs[0]; hp.paragraph_format.tab_stops.add_tab_stop(Cm(total), alignment=2)
    hp.add_run().add_picture(emblem, height=Cm(1.0))
    a = hp.add_run('  EduTrack'); a.bold = True; a.font.size = Pt(13); a.font.color.rgb = NAVY
    b = hp.add_run(f'\t\tEduTrack User Guide · {r["label"]}'); b.font.size = Pt(9.5); b.font.color.rgb = MUTED
    add_watermark(sec.header, logo)
    add_watermark(sec.first_page_header, logo, 8.0, cover=True)
    for ft in (sec.footer, sec.first_page_footer):
        fp = ft.paragraphs[0]; fp.paragraph_format.tab_stops.add_tab_stop(Cm(total), alignment=2)
        c = fp.add_run(guide['edition'] + '\t' + COPYRIGHT + '\t'); c.font.size = Pt(8.5); c.font.color.rgb = MUTED
        if ft is sec.footer: pg = fp.add_run('Page '); pg.font.size = Pt(9); pg.bold = True; pg.font.color.rgb = NAVY; page_field(fp)
    doc.core_properties.title = f'EduTrack User Guide — {r["label"]}'; doc.core_properties.author = 'EduTrack'; doc.core_properties.subject = f'User Guide for {r["for_text"]}'

    # cover: same design as the original guide, with the audience stated clearly
    para(doc, '', after=14)
    p = para(doc, '', align=WD_ALIGN_PARAGRAPH.CENTER, after=6); p.add_run().add_picture(logo, width=Cm(9.8))
    para(doc, 'Modern School Management System', size=13.5, color=GREEN, align=WD_ALIGN_PARAGRAPH.CENTER, after=34)
    band = doc.add_table(rows=1, cols=1); band.alignment = WD_TABLE_ALIGNMENT.CENTER; bc = band.rows[0].cells[0]; shade(bc, '0A3C8C'); borders(bc); cell_margins(bc, 380, 340, 200, 200)
    q = bc.paragraphs[0]; q.alignment = WD_ALIGN_PARAGRAPH.CENTER; q.paragraph_format.space_after = Pt(8)
    t = q.add_run('USER GUIDE'); t.bold = True; t.font.size = Pt(34); t.font.color.rgb = RGBColor(255, 255, 255); tracking(t, 7)
    q2 = bc.add_paragraph(); q2.alignment = WD_ALIGN_PARAGRAPH.CENTER; q2.paragraph_format.space_after = Pt(10)
    t2 = q2.add_run('FOR ' + r['for_caps']); t2.bold = True; t2.font.size = Pt(17); t2.font.color.rgb = LIME; tracking(t2, 3)
    q3 = bc.add_paragraph(); q3.alignment = WD_ALIGN_PARAGRAPH.CENTER; q3.paragraph_format.space_after = Pt(6)
    t3 = q3.add_run('How to Use EduTrack to Run Your School Day to Day'); t3.italic = True; t3.font.size = Pt(12); t3.font.color.rgb = RGBColor(255, 255, 255)
    set_widths(band, [1], total)
    bar = doc.add_table(rows=1, cols=1); bar.alignment = WD_TABLE_ALIGNMENT.CENTER; barc = bar.rows[0].cells[0]; shade(barc, '3A9A2E'); borders(barc)
    barc.paragraphs[0].paragraph_format.space_after = Pt(0); barc.paragraphs[0].add_run('').font.size = Pt(2); set_widths(bar, [1], total)
    trPr = bar.rows[0]._tr.get_or_add_trPr(); hh = OxmlElement('w:trHeight'); hh.set(qn('w:val'), '120'); hh.set(qn('w:hRule'), 'exact'); trPr.append(hh)
    para(doc, '', after=18)
    para(doc, guide['edition'], size=13.5, color=NAVY, align=WD_ALIGN_PARAGRAPH.CENTER, bold=True, after=3)
    para(doc, f'Prepared for EduTrack {r["for_text"]}', size=10, color=MUTED, align=WD_ALIGN_PARAGRAPH.CENTER)

    # about + glance
    h1(doc, 'About This Guide')
    para(doc, f'EduTrack helps run a school from one place. This guide is written for **{r["for_text"]}** and shows only what your role can do, step by step, using the same names you see on the screen. It does not cover technical operation (servers, databases, code).')
    doc.add_heading('How to read the boxes', level=2)
    callout(doc, 'note', 'Useful information to remember.', total); callout(doc, 'tip', 'A faster or better way of doing something.', total); callout(doc, 'warn', 'Something that can cause data loss or mistakes. Read it carefully.', total)
    para(doc, '**Bold text** is a button, tab, field or menu name exactly as it appears on screen. An arrow shows a menu path: **Help → User Guide** means open the Help group in the menu, then choose User Guide. Every chapter ends with the common problems and what to do about them.')
    h1(doc, guide['glance']['title'], new_page=False); blocks(doc, guide['glance']['blocks'], total)

    h1(doc, 'Contents')
    para(doc, 'Tip: open **View → Navigation Pane** in Word to jump to any chapter or section.', size=9.5, color=MUTED, italic=True, after=8)
    for i, ch in enumerate(guide['chapters'], 1):
        p = para(doc, '', after=3); rr = p.add_run(f'{i}   '); rr.bold = True; rr.font.color.rgb = GREEN; rr2 = p.add_run(ch['title']); rr2.font.color.rgb = NAVY; rr2.font.size = Pt(11)
    para(doc, '', after=2); para(doc, guide['quick']['title'], color=NAVY, size=11); para(doc, 'Glossary', color=NAVY, size=11)

    for i, ch in enumerate(guide['chapters'], 1):
        h = h1(doc, f'{i}   {ch["title"]}')
        t = doc.add_table(rows=1, cols=1); cc = t.rows[0].cells[0]; shade(cc, 'F3F6FB'); borders(cc); cell_margins(cc, 70, 70, 140, 140)
        pp = cc.paragraphs[0]; pp.paragraph_format.space_after = Pt(0); rr = pp.add_run('PATH   '); rr.bold = True; rr.font.size = Pt(8.5); rr.font.color.rgb = MUTED; runs(pp, ch['path'], size=9.5, color=INK); set_widths(t, [1], total)
        spacer(doc, 4); para(doc, ch['intro'], size=11, color=MUTED, after=8)
        blocks(doc, ch['blocks'], total)
    h1(doc, guide['quick']['title']); blocks(doc, guide['quick']['blocks'], total)
    h1(doc, guide['glossary']['title']); blocks(doc, guide['glossary']['blocks'], total)
    # The paragraph Word keeps after a final table must not push a blank page when the table ends at the bottom of one.
    last = doc.paragraphs[-1]
    if not last.text.strip():
        last.paragraph_format.space_after = Pt(0); last.paragraph_format.space_before = Pt(0); last.paragraph_format.line_spacing = Pt(1)
    doc.save(path)
