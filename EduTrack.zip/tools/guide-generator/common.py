from dsl import *

def start(role, staff=True):
    """Chapter 1 — signing in, finding your way around. Tailored to who is reading."""
    menu_rows = [[g, ', '.join(p)] for g, p in role['menu']]
    first = ("Staff sign in with their **email address**. Your starting password was given to you by the school; EduTrack asks you to choose your own the first time."
             if staff else
             "Your login details were given to your family when the student was admitted. The first time you sign in, EduTrack asks you to choose your own password.")
    blocks = [
        H2('Signing in'),
        OL(['Open your school\'s EduTrack address in a web browser.', 'Enter your **Email** and **Password**.', 'Click **Sign In**.']),
        P(first),
        NOTE('After several wrong passwords the account locks for a while. The number of attempts and the length of the lock are set by your administrator. Someone left idle for too long is signed out automatically, so save your work before you step away.'),
        H2('Your first sign-in: choose a new password'),
        OL(['Enter the starting password you were given as the **Current password**.',
            'Enter a **New password** and type it again to confirm. It needs at least 8 characters, with both letters and numbers, and it cannot be the starting password.',
            'You are signed out. Sign in again with the new password.']),
        H2('If you forget your password'),
        P('You do not need an administrator.'),
        OL(['On the sign-in page click **Forgot password?**', 'Enter the email address or phone number the page asks for.',
            'A 6-digit code is sent to you. It works once and expires after 15 minutes.', 'Enter the code and choose a new password, then sign in.']),
        UL((['A student\'s code goes to the student\'s **parent**, on the parent\'s email or phone, so the parent\'s contact details must be on the student record.'] if role['key'] in ('student', 'parent') else [])
           + ['After 5 wrong codes you must ask for a new one. Each new code cancels the old one.',
              'If no email or phone is recorded for you, no code can be sent. Ask the school office to add one.']),
        H2('Finding your way around'),
        P('Every page has the same three parts: the **menu** on the left, the **top bar** across the top, and the page itself. The menu shows only what your role allows, so it is shorter than the menu an administrator sees.'),
        TABLE(['Menu group', 'What you will see'], menu_rows, [3.2, 12.8]),
        NOTE('Your menu follows the permissions your school has given you. If your school changed them, your menu may show more or fewer items than the table above. Nothing is wrong: ask your administrator if you need access to something.'),
        H2('The top bar'),
    ]
    bar = ['**Academic year** chooses the school year whose records are shown. Switch it to look back at a past year. On a phone or tablet, tap the **sliders** icon to choose the academic year (and the campus, if you have it).',
           ('**Search** finds students, staff, classes, library books and contacts in one go. Type at least two letters and click a result.' if staff else '**Search** finds records you are allowed to see. Type at least two letters.') + ' On a phone or tablet, tap the **magnifier** icon.',
           'The **bell** shows your notifications. Each one shows how long ago it happened, such as 2 seconds ago or 3 days ago.',
           'Your **picture** opens the profile menu with **Settings**, **Profile** and **Logout**.']
    if role['key'] in ('super_admin', 'admin', 'principal'):
        bar.insert(0, '**Campus** chooses the campus whose records you are working with. Administrators and principals can switch it.')
    blocks += [UL(bar), TIP('If a student, class or payment seems to be missing, check the **Academic year** (and **Campus**, if you have it) before anything else. Changing either one changes what every page shows.')]
    blocks += [
        H2('Notifications'),
        P('The bell shows alerts such as a payment being recorded or exam marks being entered. Click a notification to mark it as read, or choose **View all notifications** for the full list. Hold the pointer over the time to see the exact date and time.'),
        H2('Your profile'),
        OL(['Open the profile menu and choose **Profile**.', 'Click the pencil on your picture to upload a photo (JPG, PNG or WEBP).',
            'Edit your **First Name**, **Middle Name**, **Last Name** and **Phone**, then click **Save Changes**.',
            'To change your password, enter your **Current Password**, then the **New Password** twice, and click **Change Password**. You stay signed in on this device and every other device is signed out.']),
        H2('Using EduTrack as an app'),
        P('EduTrack can be installed on a computer, phone or tablet so it opens in its own window from the desktop or home screen, like any other program. It still needs an internet connection and never keeps school records on your device.'),
        UL(['**Android** (Chrome, Edge, Samsung Internet): tap **Install** on the bar at the top of the screen, or open the browser menu (⋮) and choose **Install app**.',
            '**iPhone or iPad**: open EduTrack in Safari, tap **Share**, then **Add to Home Screen**, then **Add**.',
            '**Computer** (Chrome or Edge): use the install icon at the right end of the address bar, or the browser menu → **Install EduTrack**.']),
        P('An installed app has no browser bar, so it has its own **reload** button (a circular arrow) in the top bar. On an iPhone or iPad, pull the page down from the top to reload it.'),
        H2('Common problems'),
        TABLE(['Problem', 'What to do'], [
            ['The reset code does not arrive', 'Check your spam folder, wait a minute, then ask for a new code.'],
            ['A menu item is missing', 'Your role may not include it. Ask your administrator.'],
            ['A record you expect is not there', 'Check the academic year at the top of the page.'],
            ['You were signed out suddenly', 'You were idle past the limit, or you changed your password on another device.']], [5.5, 10.5]),
    ]
    return CH('start', 'Getting Started with EduTrack', 'Sign in · Top bar · Profile',
              'You can be signed in and working in under two minutes. This chapter covers signing in, choosing a password, finding your way around the screen and keeping your profile up to date.', *blocks)

def dashboard_full():
    return CH('dashboard', 'Dashboard', 'Main › Dashboard',
      'The Dashboard is your starting page. It answers one question: what needs my attention today?',
      H2('What it shows'),
      TABLE(['Part', 'What it shows'], [
        ['Active Students', 'Number of active students. Click it to open Students.'],
        ['Active Staff', 'Number of active staff.'],
        ['Attendance, 30 Days', 'Attendance rate over the last 30 days. It turns amber below 85%.'],
        ['Pending Leave Requests', 'Leave requests waiting for approval. Click it to open the approvals page.'],
        ['This term', 'The current term with its dates, the day you are on and days left.'],
        ["Today's highlights", 'Fees collected today, students absent today, staff on approved leave and new admissions.'],
        ['This year at a glance', 'Fee collection, expenses, outstanding fees and admissions, year to date.'],
        ['Shortcuts', 'One-click buttons for the tasks you do most, such as Add student, Mark attendance, Create exam, Send notice or View reports.']], [4.2, 11.8]),
      NOTE('The **This term** card needs the academic year to have terms. If it says no terms are set up, add them in Settings → Academic Year.'),
      H2('Common problems'),
      TABLE(['Problem', 'What to do'], [
        ['The figures look too low', 'Check the Campus and Academic year at the top of the page.'],
        ['The attendance rate shows a dash', 'No attendance has been marked in the last 30 days.']], [5.5, 10.5]))

def dashboard_personal(role):
    extra = {
      'parent': 'Under **My children** you see each of your children, with a link to open each one.',
      'student': '',
    }.get(role['key'], '')
    short = {
      'teacher': 'Take attendance, Enter marks, Request leave, See my payslips',
      'accountant': 'Record a fee payment, Send a message, Request leave, See my payslips',
      'librarian': 'Issue a book, Request leave, See my payslips',
      'hr': 'Add a staff member, Request leave, See my payslips',
      'transport_manager': 'Manage routes, Request leave, See my payslips',
      'hostel_warden': 'Manage rooms, Request leave, See my payslips',
      'student': 'Request leave, View results',
      'parent': 'View results, View fees',
    }.get(role['key'], '')
    return CH('dashboard', 'Your Dashboard', 'Main › Dashboard',
      'Everyone has a dashboard. Yours is a simple personal page built around what you do, so you see only what matters to you.',
      H2('What it shows'),
      UL([x for x in [extra, '**Shortcuts** offers the tasks your role allows' + (f', such as {short}' if short else '') + '.',
          '**Your modules** lists the parts of EduTrack you can open.', '**Latest notifications** shows your most recent alerts.'] if x]),
      NOTE('The full school Dashboard with statistics and charts is for administrators and principals. You do not need it, and nothing is missing from your account.'))

def leave_requester(role):
    student = role['key'] == 'student'
    approve = not student
    blocks = [
      H2('Requesting leave' if not student else 'Asking to be excused'),
      OL(['On **My Requests**, click **Request Leave**.',
          'Choose the **Leave Type**' + (', such as **Excuse/Absence**.' if student else ', such as Annual or Sick.'),
          'Choose the **Start Date** and **End Date**.', 'Write the **Reason**.', 'Click **Submit Request**.']),
      P('Your requests are listed with Type, Dates, Days, Status and **Approval**, which says who the request is waiting for. A request that is still pending can be withdrawn with **Cancel Request**.' + ('' if student else ' You also see balance cards showing the days you have left this year for each leave type.')),
      H2('Who approves your request'),
      TABLE(['Who asks', 'Step 1', 'Step 2'], [
        ['Staff member', 'Your manager, set as Reports To on your staff record. If none is set, the Principal.', 'The Principal'],
        ['Student', 'The class teacher of the student\'s class. If the class has none, the Principal.', 'The Principal']], [3.2, 9.3, 3.5]),
      P('If the first approver is the Principal, the request is finished at Step 1. Rejecting at either step ends the request straight away.'),
    ]
    if approve:
        who = 'a student of your class (if you are a class teacher), or a colleague who reports to you,' if role['key'] == 'teacher' else 'a colleague who reports to you'
        blocks += [H2('Approving requests (only if someone reports to you)'),
          P(f'When {who} sends a request, an **Approvals** tab appears. Open it (or use the notification), read the request, then click **Approve** or **Reject**. A short comment helps the person understand a rejection. You see this tab only when you are an approver for at least one pending request.')]
    blocks += [H2('Common problems'), TABLE(['Problem', 'What to do'], [
        ['I cannot choose a leave type', 'No type applies to you. Ask HR or an administrator to set one up.'],
        ['A request has been waiting a long time', 'Check the Approval column to see who must act, and remind them.']], [5.5, 10.5])]
    return CH('leave', 'Leave' if not student else 'Leave and Excuses', 'HR › Leave', 'Request time off and follow its approval in one place.' if not student else 'Ask for an absence to be excused and follow its approval.', *blocks)

def leave_manager():
    return CH('leave', 'Leave', 'HR › Leave',
      'Staff request leave and students request excuses in the same place, and each request goes to the right approver automatically. The page has up to four tabs: **My Requests**, **Approvals**, **Leave Types** and **Staff Balances**. You see only the tabs your role allows.',
      H2('Requesting leave'),
      OL(['On **My Requests**, click **Request Leave**.', 'Choose the **Leave Type**, the **Start Date** and **End Date**, and write the **Reason**.', 'Click **Submit Request**.']),
      P('A pending request can be withdrawn with **Cancel Request**. Balance cards show the days you have left this year for each type.'),
      H2('Who approves a request'),
      TABLE(['Requester', 'Step 1', 'Step 2'], [
        ['Staff member', 'Their manager, set as Reports To on the staff record. If none is set, the Principal.', 'The Principal'],
        ['Student', 'The class teacher of their class. If the class has none, the Principal.', 'The Principal']], [3.2, 9.3, 3.5]),
      P('If the first approver is the Principal, the request is finalised at Step 1. Rejecting at either step ends it straight away. Approving at Step 1 sends it on to Step 2.'),
      H2('Approving or rejecting'),
      OL(['Open the **Approvals** tab, or click **Pending Leave Requests** on the Dashboard.', 'Read the request.', 'Click **Approve** or **Reject**. Add a **Comment** if you wish. A short reason helps the person understand a rejection.']),
      H2('Setting up leave types and balances'),
      P('HR managers, administrators and principals set up leave.'),
      OL(['Open the **Leave Types** tab and add a type.', 'Enter the **Name**, for example Annual, Sick, Study or Excuse/Absence.', 'Choose **Applies To**: Staff, Student or Both.',
          'Enter **Default Days / Year** if this leave draws from a yearly balance.', 'Leave **Status** as Active and save. Use **Edit Type** or **Delete Type** to change one.']),
      P('Open **Staff Balances** and choose a **Staff Member** to see, for each leave type, the days Allocated, Used and Remaining. Click **Adjust** to change the allocation, for example to give extra days.'),
      H2('Common problems'),
      TABLE(['Problem', 'What to do'], [
        ['I cannot choose a leave type', 'No type applies to you. Add one with the right Applies To.'],
        ['There is no Approvals tab', 'You are not an approver for any pending request.'],
        ["A staff member's request skips straight to the Principal", 'No Reports To is set on their staff record. Set it under Staff → Edit.']], [5.5, 10.5]))

def payslips():
    return CH('payslips', 'My Payslips', 'Finance › Payroll',
      'Payroll is where your school pays staff. For you it is a private page showing only your own pay.',
      H2('Seeing your pay'),
      P('Open **Payroll** in the menu to see **My Payslips**: your own pay history, month by month. Open any month for the full breakdown: basic salary, allowances, deductions and net pay.'),
      NOTE('Nobody can see your payslip without payroll permission, and you cannot see anyone else\'s. If a month is missing or an amount looks wrong, speak to the person who runs payroll at your school (usually HR or the accountant).'))

def messages_view():
    return CH('messages', 'Messages (view only)', 'Communication › Messages',
      'Messages is how the school reaches parents and staff by SMS or email. With your role you can look at it, but not send.',
      H2('What you can open'),
      TABLE(['Tab', 'What it shows'], [
        ['Contacts', 'People the school can message: parents, staff, students and others.'],
        ['Groups', 'Saved groups of contacts, including groups that update themselves, such as all parents of one class.'],
        ['History', 'Every message sent, with its status and who received it.'],
        ['Templates', 'Messages saved so they do not have to be retyped.'],
        ['Info', 'The SMS balance.']], [3.5, 12.5]),
      NOTE('Sending a message, and adding or changing contacts, groups and templates, needs extra permission. If your work needs it, ask an administrator.'),
      P('When a message is sent, the History page shows a status for each person: **Pending** (handed to the provider), **Accepted** (the provider took it, delivery not yet confirmed), **Delivered** or **Failed** with the reason.'))

def help_chapter(role):
    return CH('help', 'Getting Help', 'Help › User Guide',
      'Most problems come from one of a few causes. Check these first, then use the support options at the end.',
      H2('Check these first'),
      OL(['**Academic year** (and Campus). Both are chosen at the top of the page and change what every page shows.',
          '**Your role and permissions.** A missing menu item or button means your role does not include it. Ask an administrator.',
          '**Filters.** A list may be filtered by status, class or date. Click **Reset** or choose **All**.',
          '**Refresh the page.** After a permission change, a refresh or a new sign-in loads it.']),
      H2('Getting help'),
      UL(['Open **Help → User Guide** in the menu to read or download this guide. It is written for your role, so it shows only what you can do.',
          'Open **Help** from the footer of any page for short articles on common tasks.',
          'If the answer is not there, use **Contact support**. Choose what it is about, write the subject and message, and click **Send by email**, or **Copy message** to send it another way.']),
      TIP('When you report a problem, say which page you were on, what you clicked and what the screen said. If you can, include the exact message shown in red.'))
