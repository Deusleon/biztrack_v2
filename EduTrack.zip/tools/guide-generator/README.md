# User-guide generator

The 11 role guides are built from one source, so the PDF and Word versions always say the same thing.

- **PDFs** go to `frontend/public/docs/guides/` — the ONLY files the app serves (users can download the PDF only).
- **Word masters** go to `tools/guide-generator/word-editable/` — they stay in the project for you to edit and are never offered for download.

Every page carries the EduTrack logo in the header, a faint logo watermark behind the text (opacity set by `WATERMARK_OPACITY`) and a copyright line.

- `common.py`, `academic.py`, `ops.py` — the chapters (plain Python, a tiny content format: `H2`, `P`, `UL`, `OL`, `NOTE`, `TIP`, `WARN`, `TABLE`).
- `roles.py` — each role: its menu, what it can / cannot do, its chapter list and quick-reference table.
- `render_pdf.py`, `render_docx.py` — the two renderers.

Rebuild all guides (or just some) after changing a feature or a chapter:

```bash
pip install reportlab python-docx pillow
python build.py                 # all 11 roles
python build.py teacher parent  # only these
```

The PDF uses the DejaVu Sans fonts (`/usr/share/fonts/truetype/dejavu/`; on Windows/macOS edit the path at the top of `render_pdf.py`).
If you only need a small wording fix, you can edit the `.docx` in `word-editable/` and export a PDF — but a PDF exported from Word has no
watermark, so put the final PDF through `python build.py` (change the text here first) before publishing it.

What each role sees is taken from `backend/src/utils/permissionCatalog.js` (the default permissions). If you change
those defaults, update `roles.py` (the `menu`, `can`, `cannot` lists) to match.
