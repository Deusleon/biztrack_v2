import sys, os
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import roles, render_pdf, render_docx
ASSETS = dict(logo=os.path.join(HERE, 'logo_guide.png'), emblem=os.path.join(HERE, 'emblem_guide.png'))
# PDFs are what the app serves to users. The editable Word masters are NOT in the public folder: they stay in the
# project (tools/guide-generator/word-editable) for you to edit, and are never downloadable from the app.
PDF_OUT = os.path.join(HERE, '..', '..', 'frontend', 'public', 'docs', 'guides')
DOCX_OUT = os.path.join(HERE, 'word-editable')
only = sys.argv[1:] or list(roles.ROLES)
for d in (PDF_OUT, DOCX_OUT): os.makedirs(d, exist_ok=True)
for key in only:
    g = roles.build_guide(key); name = f'EduTrack_User_Guide_{g["role"]["file"]}'
    render_pdf.render_pdf(g, f'{PDF_OUT}/{name}.pdf', ASSETS); render_docx.render_docx(g, f'{DOCX_OUT}/{name}.docx', ASSETS)
    print(f'{key:18} {len(g["chapters"]):2} chapters  pdf {os.path.getsize(f"{PDF_OUT}/{name}.pdf")//1024:4} KB  docx {os.path.getsize(f"{DOCX_OUT}/{name}.docx")//1024:4} KB')
