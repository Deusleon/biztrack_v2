import re, html, io
from PIL import Image
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak, Table, TableStyle, Image as RLImage, NextPageTemplate, Flowable)
from reportlab.platypus.tableofcontents import TableOfContents

# Carlito is the open font Lato (the typeface of the original guide) re-cut for documents.
C = '/usr/share/fonts/truetype/crosextra/'; D = '/usr/share/fonts/truetype/dejavu/'
for name, f in (('CL', 'Carlito-Regular'), ('CL-B', 'Carlito-Bold'), ('CL-I', 'Carlito-Italic'), ('CL-BI', 'Carlito-BoldItalic')): pdfmetrics.registerFont(TTFont(name, C + f + '.ttf'))
pdfmetrics.registerFont(TTFont('DV-M', D + 'DejaVuSansMono.ttf'))
pdfmetrics.registerFontFamily('CL', normal='CL', bold='CL-B', italic='CL-I', boldItalic='CL-BI')

NAVY_HEX = '#0A3C8C'; NAVY = colors.HexColor(NAVY_HEX); GREEN = colors.HexColor('#3A9A2E'); INK = colors.HexColor('#1F2937'); MUTED = colors.HexColor('#6B7280'); LINE = colors.HexColor('#D1D5DB'); SOFT = colors.HexColor('#F1F5FB'); LIME = colors.HexColor('#A7E58F')
CALL = {'note': (colors.HexColor('#EAF1FB'), colors.HexColor('#1F6FD1'), 'N O T E'), 'tip': (colors.HexColor('#E8F5EA'), colors.HexColor('#2F8F46'), 'T I P'), 'warn': (colors.HexColor('#FFF3E0'), colors.HexColor('#D97706'), 'W A R N I N G')}
WATERMARK_OPACITY = 0.07   # faint enough to read through, strong enough to show whose document this is
COPYRIGHT = '© 2026 EduTrack. All rights reserved. Not for redistribution.'

S = dict(
  body=ParagraphStyle('body', fontName='CL', fontSize=10.5, leading=15.5, textColor=INK, spaceAfter=7),
  h2=ParagraphStyle('h2', fontName='CL-B', fontSize=14, leading=18, textColor=NAVY, spaceBefore=14, spaceAfter=7, keepWithNext=1),
  chnum=ParagraphStyle('chnum', fontName='CL-B', fontSize=44, leading=48, textColor=GREEN),
  chtitle=ParagraphStyle('chtitle', fontName='CL-B', fontSize=25, leading=30, textColor=NAVY, spaceAfter=4),
  intro=ParagraphStyle('intro', fontName='CL', fontSize=11.5, leading=17, textColor=MUTED, spaceAfter=9),
  cell=ParagraphStyle('cell', fontName='CL', fontSize=9.8, leading=13.5, textColor=INK),
  cellh=ParagraphStyle('cellh', fontName='CL-B', fontSize=9.8, leading=13.5, textColor=colors.white),
  call=ParagraphStyle('call', fontName='CL', fontSize=10.3, leading=14.8, textColor=INK),
  path=ParagraphStyle('path', fontName='CL', fontSize=9.8, leading=13, textColor=INK),
  li=ParagraphStyle('li', fontName='CL', fontSize=10.5, leading=15.3, textColor=INK),
  toc0=ParagraphStyle('toc0', fontName='CL-B', fontSize=11.5, leading=18, textColor=NAVY, spaceBefore=4),
  toc1=ParagraphStyle('toc1', fontName='CL', fontSize=9.8, leading=13.5, textColor=INK, leftIndent=16),
)

def md(t, header=False):
    """**bold** (navy, like the original guide) and `code`, safely escaped."""
    t = html.escape(str(t), quote=False)
    t = re.sub(r'\*\*(.+?)\*\*', (r'<b>\1</b>' if header else rf'<b><font color="{NAVY_HEX}">\1</font></b>'), t)
    return re.sub(r'`(.+?)`', r'<font name="DV-M" size="9">\1</font>', t)

class Heading(Flowable):
    def __init__(self, text, level, key): super().__init__(); self.text, self.level, self.key = text, level, key; self.width = self.height = 0
    def wrap(self, aw, ah): return (0, 0)
    def draw(self): pass

def faded(path, opacity):
    im = Image.open(path).convert('RGBA'); r, g, b, a = im.split(); a = a.point(lambda v: int(v * opacity)); im.putalpha(a)
    buf = io.BytesIO(); im.save(buf, 'PNG'); buf.seek(0); return ImageReader(buf)

class Guide(BaseDocTemplate):
    def __init__(self, path, guide, assets, **kw):
        r = guide['role']; self.role, self.edition, self.assets = r, guide['edition'], assets
        super().__init__(path, pagesize=A4, leftMargin=2*cm, rightMargin=2*cm, topMargin=2.5*cm, bottomMargin=2.1*cm, title=f'EduTrack User Guide — {r["label"]}', author='EduTrack', subject=f'User Guide for {r["for_text"]}', creator='EduTrack', **kw)
        self.wm = faded(assets['logo'], WATERMARK_OPACITY); self.emblem = ImageReader(assets['emblem']); self.logo = ImageReader(assets['logo'])
        fr = Frame(self.leftMargin, self.bottomMargin, self.width, self.height, id='f', leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        self.addPageTemplates([PageTemplate('cover', [fr], onPage=self.cover), PageTemplate('main', [fr], onPage=self.chrome)])
    def watermark(self, c, cover=False):
        w, h = A4
        ww = 8.0*cm if cover else 13.5*cm; wh = ww * 587 / 640
        y = 0.9*cm if cover else (h - wh) / 2 - 0.4*cm   # on the cover it sits in the empty space below the text, so it never doubles the big logo
        c.drawImage(self.wm, (w - ww) / 2, y, width=ww, height=wh, mask='auto')   # drawn first, so every word sits on top of it
    def cover(self, c, d):
        w, h = A4; self.watermark(c, cover=True)
        lw = 9.8*cm; lh = lw * 587 / 640; top = h - 3.0*cm
        c.drawImage(self.logo, (w - lw) / 2, top - lh, width=lw, height=lh, mask='auto')
        c.setFillColor(GREEN); c.setFont('CL', 13.5); c.drawCentredString(w / 2, top - lh - 1.0*cm, 'Modern School Management System')
        bx, bw = 2*cm, w - 4*cm; by_top = top - lh - 3.6*cm; bh = 6.6*cm
        c.setFillColor(NAVY); c.rect(bx, by_top - bh, bw, bh, stroke=0, fill=1)
        c.setFillColor(GREEN); c.rect(bx, by_top - bh - 0.22*cm, bw, 0.22*cm, stroke=0, fill=1)
        c.saveState(); c.setFillColor(colors.white); t = c.beginText(); t.setFont('CL-B', 34); t.setCharSpace(7); tw = c.stringWidth('USER GUIDE', 'CL-B', 34) + 7 * 9
        t.setTextOrigin((w - tw) / 2 + 3.5, by_top - 2.35*cm); t.textOut('USER GUIDE'); c.drawText(t); c.restoreState()
        c.saveState(); c.setFillColor(LIME); t = c.beginText(); t.setFont('CL-B', 17); t.setCharSpace(3); label = 'FOR ' + self.role['for_caps']; tw = c.stringWidth(label, 'CL-B', 17) + 3 * len(label)
        t.setTextOrigin((w - tw) / 2 + 1.5, by_top - 3.7*cm); t.textOut(label); c.drawText(t); c.restoreState()
        c.setStrokeColor(LIME); c.setLineWidth(0.8); c.line(w / 2 - 1.2*cm, by_top - 4.15*cm, w / 2 + 1.2*cm, by_top - 4.15*cm)
        c.setFillColor(colors.white); c.setFont('CL-I', 12); c.drawCentredString(w / 2, by_top - 5.15*cm, 'How to Use EduTrack to Run Your School Day to Day')
        c.setFillColor(NAVY); c.setFont('CL-B', 13.5); c.drawCentredString(w / 2, by_top - bh - 1.5*cm, self.edition)
        c.setFillColor(MUTED); c.setFont('CL', 10); c.drawCentredString(w / 2, by_top - bh - 2.15*cm, f'Prepared for EduTrack {self.role["for_text"]}')
    def chrome(self, c, d):
        w, h = A4; self.watermark(c)
        c.saveState()
        eh = 1.0*cm; ew = eh * 320 / 198
        c.drawImage(self.emblem, 2*cm, h - 1.0*cm - eh, width=ew, height=eh, mask='auto')           # the logo on every page, as in the original guide
        c.setFont('CL-B', 13); c.setFillColor(NAVY); c.drawString(2*cm + ew + 0.15*cm, h - 1.0*cm - eh + 0.28*cm, 'EduTrack')
        c.setFont('CL', 9.5); c.setFillColor(MUTED); c.drawRightString(w - 2*cm, h - 1.0*cm - eh + 0.3*cm, f'EduTrack User Guide · {self.role["label"]}')
        c.setStrokeColor(LINE); c.setLineWidth(0.5); c.line(2*cm, 1.55*cm, w - 2*cm, 1.55*cm)
        c.setFont('CL', 9); c.setFillColor(MUTED); c.drawString(2*cm, 1.05*cm, self.edition)
        c.setFont('CL', 7.8); c.drawCentredString(w / 2, 1.05*cm, COPYRIGHT)
        c.setFont('CL-B', 9.5); c.setFillColor(NAVY); c.drawRightString(w - 2*cm, 1.05*cm, f'Page {d.page}')
        c.restoreState()
    def afterFlowable(self, f):
        if isinstance(f, Heading):
            self.canv.bookmarkPage(f.key); self.canv.addOutlineEntry(f.text, f.key, level=f.level, closed=f.level == 0)
            self.notify('TOCEntry', (f.level, f.text, self.page, f.key))

def callout(kind, text, width):
    bg, bar, label = CALL[kind]
    inner = Paragraph(f'<font name="CL-B" color="{bar.hexval().replace("0x", "#")}" size="8.4">{label}</font><br/>{md(text)}', S['call'])
    t = Table([[inner]], colWidths=[width])
    t.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,-1), bg), ('LINEBEFORE', (0,0), (0,-1), 3.5, bar), ('LEFTPADDING', (0,0), (-1,-1), 12), ('RIGHTPADDING', (0,0), (-1,-1), 10), ('TOPPADDING', (0,0), (-1,-1), 7), ('BOTTOMPADDING', (0,0), (-1,-1), 8)]))
    return t

def data_table(head, rows, widths, width):
    ws = [w * cm for w in (widths or [width / cm / len(head)] * len(head))]; ws = [w * width / sum(ws) for w in ws]
    data = [[Paragraph(md(h, header=True), S['cellh']) for h in head]] + [[Paragraph(md(c), S['cell']) for c in r] for r in rows]
    t = Table(data, colWidths=ws, repeatRows=1)
    st = [('BACKGROUND', (0,0), (-1,0), NAVY), ('VALIGN', (0,0), (-1,-1), 'TOP'), ('LINEBELOW', (0,0), (-1,-1), 0.4, LINE), ('LEFTPADDING', (0,0), (-1,-1), 8), ('RIGHTPADDING', (0,0), (-1,-1), 8), ('TOPPADDING', (0,0), (-1,-1), 6), ('BOTTOMPADDING', (0,0), (-1,-1), 7)]
    for i in range(1, len(data)):
        if i % 2 == 1: st.append(('BACKGROUND', (0,i), (-1,i), colors.Color(1, 1, 1, alpha=0.55)))   # light rows stay see-through, so the watermark never disappears under a table
        else: st.append(('BACKGROUND', (0,i), (-1,i), colors.Color(0.89, 0.93, 0.98, alpha=0.75)))
    t.setStyle(TableStyle(st)); return t

def bullet_row(marker, text, width, mw, style=S['li'], mcolor=None):
    m = Paragraph(f'<font name="CL-B" color="{mcolor or NAVY_HEX}">{marker}</font>', style)
    return Table([[m, Paragraph(md(text), style)]], colWidths=[mw, width - mw], style=[('VALIGN', (0,0), (-1,-1), 'TOP'), ('LEFTPADDING', (0,0), (-1,-1), 4), ('RIGHTPADDING', (0,0), (-1,-1), 0), ('TOPPADDING', (0,0), (-1,-1), 0), ('BOTTOMPADDING', (0,0), (-1,-1), 3.5)])

def blocks_to_flow(blocks, width, ckey):
    out = []; n = 0
    for b in blocks:
        k = b[0]
        if k == 'h2': n += 1; out += [Heading(b[1], 1, f'{ckey}-h{n}'), Paragraph(md(b[1]), S['h2'])]
        elif k == 'p': out.append(Paragraph(md(b[1]), S['body']))
        elif k == 'ul': out += [bullet_row('●', it, width, 0.6*cm, mcolor='#3A9A2E') for it in b[1]] + [Spacer(1, 4)]
        elif k == 'ol': out += [bullet_row(f'{i}.', it, width, 0.75*cm) for i, it in enumerate(b[1], 1)] + [Spacer(1, 4)]
        elif k in ('note', 'tip', 'warn'): out += [callout(k, b[1], width), Spacer(1, 9)]
        elif k == 'table': out += [data_table(b[1], b[2], b[3], width), Spacer(1, 10)]
    # A gap after the very last block can spill onto a page of its own when a chapter ends exactly at the bottom of a page.
    while out and isinstance(out[-1], Spacer): out.pop()
    return out

def render_pdf(guide, path, assets):
    r = guide['role']; width = A4[0] - 4*cm
    doc = Guide(path, guide, assets); story = [NextPageTemplate('main'), Spacer(1, 1), PageBreak()]
    story += [Heading('About This Guide', 0, 'about'), Paragraph('About This Guide', S['chtitle']),
      Paragraph(md(f'EduTrack helps run a school from one place. This guide is written for **{r["for_text"]}** and shows only what your role can do, step by step, using the same names you see on the screen. It does not cover technical operation (servers, databases, code).'), S['body']), Spacer(1, 4),
      Paragraph('How to read the boxes', S['h2']), callout('note', 'Useful information to remember.', width), Spacer(1, 6), callout('tip', 'A faster or better way of doing something.', width), Spacer(1, 6), callout('warn', 'Something that can cause data loss or mistakes. Read it carefully.', width), Spacer(1, 9),
      Paragraph(md('**Bold text** is a button, tab, field or menu name exactly as it appears on screen. An arrow shows a menu path: **Help → User Guide** means open the Help group in the menu, then choose User Guide. Every chapter ends with the common problems and what to do about them.'), S['body']), Spacer(1, 14)]
    story += [Heading(guide['glance']['title'], 0, 'glance'), Paragraph(guide['glance']['title'], S['chtitle'])] + blocks_to_flow(guide['glance']['blocks'], width, 'glance') + [PageBreak()]
    toc = TableOfContents(); toc.levelStyles = [S['toc0'], S['toc1']]; toc.dotsMinLevel = 0
    story += [Paragraph('Contents', S['chtitle']), Spacer(1, 6), toc, PageBreak()]
    for i, ch in enumerate(guide['chapters'], 1):
        key = f'c{i}'
        story += [Heading(f'{i}  {ch["title"]}', 0, key),
                  Table([[Paragraph(str(i), S['chnum']), [Paragraph('CHAPTER ' + str(i), ParagraphStyle('k', fontName='CL-B', fontSize=9, textColor=MUTED, leading=12)), Paragraph(md(ch['title']), S['chtitle'])]]], colWidths=[2.3*cm, width - 2.3*cm], style=[('VALIGN', (0,0), (-1,-1), 'MIDDLE'), ('LEFTPADDING', (0,0), (-1,-1), 0)]),
                  Spacer(1, 4), Table([[Paragraph(f'<font name="CL-B" size="8.5" color="#6B7280">PATH</font>&nbsp;&nbsp;{md(ch["path"])}', S['path'])]], colWidths=[width], style=[('BACKGROUND', (0,0), (-1,-1), colors.Color(0.94, 0.96, 0.98, alpha=0.8)), ('LEFTPADDING', (0,0), (-1,-1), 9), ('TOPPADDING', (0,0), (-1,-1), 5), ('BOTTOMPADDING', (0,0), (-1,-1), 6)]),
                  Spacer(1, 9), Paragraph(md(ch['intro']), S['intro'])]
        story += blocks_to_flow(ch['blocks'], width, key) + [PageBreak()]
    for sec, k in ((guide['quick'], 'quick'), (guide['glossary'], 'gloss')):
        story += [Heading(sec['title'], 0, k), Paragraph(sec['title'], S['chtitle']), Spacer(1, 4)] + blocks_to_flow(sec['blocks'], width, k)
        if k == 'quick': story.append(PageBreak())
    doc.multiBuild(story)
