from dsl import *

def fees_manage():
    return CH('fees', 'Fees and Payments', 'Finance › Fee Management',
      'Fees work in three stages: define what each class owes, record what families pay, and follow up on what is still outstanding. Amounts are in Tanzanian shillings (TZS).',
      H2('Fee structures'),
      P('A fee structure says what is charged, how much, how often, to whom and for which year. Manage them under **Fee Management → Fee Structures**.'),
      OL(['Choose to add a fee.', 'Enter the **Fee Name**, for example Tuition or Uniform.', 'Enter the **Amount (TZS)**.', 'Choose the **Frequency**: One-time, Monthly, Quarterly or Annually. This is for information and does not change the balance calculation.', 'Choose the **Class**, the **Academic Year** and the **Campus**.', 'Choose **Applies To** and save.']),
      TABLE(['Applies To', 'Who is charged'], [['Every student in this class', 'All students in the class.'], ['Only students using Transport', 'Students marked as needing transport.'], ['Only students in a Hostel', 'Students marked as needing the hostel.'], ['Only students to be selected', 'Students you pick by hand with **Assign Students**.']], [6, 10]),
      P('Row actions: **Assign Students**, **Edit Structure** and **Delete Structure**. The **Fee Scenario** filter shows the fees that apply in a given situation (all items, standard fees only, standard plus Transport, standard plus Hostel). A fee name can have different prices, for example a Transport fee that differs by route; after choosing a scenario an extra selector appears so you can pick the price you want the total to follow.'),
      H2('Recording a payment'),
      OL(['Open **Fee Management → Record Payment**.', 'Under **1. Find the Student**, choose the Class, Section and Student. An **Account Summary** shows what they owe.', 'Under **2. Payment Details**, choose the **Fee Item**, or leave it as a general payment.',
          'Enter the **Amount (TZS)**, the **Payment Method** (Cash, Bank Transfer, Online / Mobile Money, Card or Cheque) and the **Payment Date**.', 'Add a **Transaction ID** and **Remarks** if you have them.', 'Click **Record Payment**.']),
      P('A printable receipt opens straight away. You can also record a payment from a student\'s fee summary using its **Record Payment** button.'),
      H2('Receipts and checking they are genuine'),
      P('A receipt carries the school letterhead, a receipt number, the amount in words, the payment method, a **QR code and verification code**, and signature and stamp boxes. Print it from the receipt page, or open it later from the student\'s payment history. Anyone can open **Receipt Verification**, enter the receipt number and code (or scan the QR code), and see **Valid Receipt** or **Not a Valid Receipt**, so a photocopy that was altered is detected.'),
      H2('Following up on balances'),
      OL(['Open **Fee Management → Fee Status**.', 'Choose a **Class** and optionally a **Section**, then load the status.', 'The table shows every student\'s expected amount, amount paid, balance and status: **Paid**, **Partial** or **Unpaid**.', 'Open a student to see the full breakdown by fee item and their payment history.']),
      P('To remind parents: tick the students, click **Send Fee Reminder**, edit the message (it starts with ready-made text using `{{student_name}}` and `{{balance}}`, so each parent gets their own child\'s name and balance) and send. Reminders go by SMS to the parent, one message per child, using the parent\'s phone number from their account or from the admission form. If some students have no parent phone number on file, they are left out and EduTrack names them, so you know who to follow up. Use the **Search** box above the table to find a student by name or admission number; the selection follows what you see.'),
      WARN('The placeholders `{{student_name}}` and `{{balance}}` only work in reminders sent from Fee Status. In any other message they are sent exactly as typed.'),
      H2('Common problems'),
      TABLE(['Problem', 'What to do'], [
        ['A student has no fees listed', 'Check a fee structure exists for their class and the academic year, and that Applies To includes them.'],
        ['A Transport or Hostel fee is not charged', 'Mark the student as needing transport or hostel on their record, or assign them by hand.'],
        ['The total looks too low', 'Check the Fee Scenario and price selector, then the Academic year at the top.'],
        ['A reminder says no gateway is active', "The school's SMS provider is not connected. Ask the system owner."]], [5.5, 10.5]))

def fees_parent():
    return CH('fees', 'Fees and Payments', 'Finance › Fee Management',
      'See what is owed for each of your children, what has been paid, and open or print your receipts.',
      H2('Seeing what is owed'),
      OL(['Open **Fee Management** in the menu.', 'Each of your linked children is shown with the **current balance**.', 'Open a child to see the full breakdown by fee item and the payment history.']),
      H2('Receipts'),
      P('Every payment has a receipt with a receipt number, the amount in words and the payment method. Open it from the payment history to view or print it. Each receipt carries a **QR code and verification code**: anyone can scan the code, or open **Receipt Verification** and type the receipt number and code, to confirm the receipt is genuine and has not been altered.'),
      NOTE('You see only your own children\'s fees. Payments are recorded by the school\'s accountant or office when you pay; EduTrack does not take payment from this page. If a payment you made is missing, take your receipt or transaction reference to the school office.'),
      TABLE(['Problem', 'What to do'], [['A child does not appear', 'The child must be linked to your account on the student record. Ask the school office.'], ['The balance looks wrong', 'Open the child\'s breakdown to see each fee item, and compare with your receipts. Then speak to the accountant.']], [5.5, 10.5]))

def expenses(full):
    if full:
        return CH('expenses', 'Expenses', 'Finance › Expenses',
          'Expenses are the school\'s spending ledger. It works like a cashbook: an authorised person records an expense directly, with no approval step.',
          H2('Recording an expense'),
          OL(['Open **Finance → Expenses**, on the **Ledger** tab, and choose to record an expense.', 'Choose the **Category**.', 'Enter the **Amount (TZS)**, the **Date** and **Paid To**.', 'Choose the **Payment Method**: Cash, Bank Transfer, Mobile Money, Cheque or Other.', 'Add a **Reference Number** and **Description** if you have them.', 'Save.']),
          P('To attach a photo of the receipt, open the row\'s actions and choose **Upload Receipt**. A **View** link then appears in the Receipt column.'),
          H2('Finding and correcting entries'),
          P('The ledger lists Date, Category, Paid To, Amount, Method, Status and Receipt. Narrow it with Search, Category, Payment Method and From / To dates. The total at the top always matches the filter you applied. Use **Edit Expense** to correct a detail. Use **Void Expense** when an entry should not count: it stays in the ledger marked Void, like a struck-through line in a paper cashbook, and stops counting toward totals.'),
          H2('Categories'),
          P('Open the **Categories** tab to manage the headings, such as Utilities, Maintenance, Supplies, Transport, Salaries & Wages and Food & Catering. A category already in use cannot be deleted: deactivate it instead.'),
          TABLE(['Problem', 'What to do'], [['An expense was entered by mistake', 'Use Void Expense.'], ['A category cannot be deleted', 'It is in use. Deactivate it.'], ['Salaries appear without being entered', 'That is intended: when payroll is marked Paid it posts the total under Salaries & Wages.']], [5.5, 10.5]))
    return CH('expenses', 'Expenses (view)', 'Finance › Expenses',
      'The expenses ledger is the school\'s spending record. With your role you can look at it, but not change it.',
      H2('Reading the ledger'),
      P('The ledger lists Date, Category, Paid To, Amount, Method, Status and Receipt. Narrow it with **Search**, **Category**, **Payment Method** and **From / To** dates. The total at the top always matches the filter you applied. Entries marked **Void** are kept for the record but do not count toward totals. Click **View** in the Receipt column to see an attached receipt photo.'),
      NOTE('Recording, editing or voiding an expense, and managing categories, are not part of your role by default. If your work includes recording expenses, ask an administrator to give you the **Create Expenses** (and, if needed, **Update/Delete Expenses**) permission in Settings → Permissions.'),
      P('When payroll is marked **Paid**, EduTrack posts one expense for the total net pay under **Salaries & Wages** automatically, so salaries are never entered twice.'))

def payroll_manage():
    return CH('payroll', 'Payroll', 'Finance › Payroll',
      'Payroll is the monthly salary run. Each month is one payroll period with one payslip per staff member. Once a period is paid it posts itself into the expenses ledger.',
      H2('The three stages'),
      TABLE(['Stage', 'What you can do'], [['Draft', 'Generate payslips, edit basic salary, add allowances and deductions.'], ['Processed', 'The period is locked. Nothing can be edited. It is ready to pay.'], ['Paid', 'The period is final. One expense is posted automatically under Salaries & Wages for the total net pay.']], [3.5, 12.5]),
      H2('Running a month'),
      OL(['Open **Finance → Payroll** and click **New Payroll Period**.', 'Choose the **Month**, **Year** and **Campus**, then click **Create**.', 'Open the period with **View Payslips** and click **Generate Payslips**. This creates a payslip for every active staff member who does not have one yet, filled in from their salary. It is safe to run again after adding staff.',
          'For any payslip, choose **Edit Payslip**. Change the **Basic Salary (TZS)** if needed and add named allowances (for example Housing or Transport) and deductions (for example NSSF or PAYE). Gross and net pay update as you type.', 'Use **Remove from Run** to leave a person out of this month.', 'When everything is right, click **Process** to lock the period.', 'After you have paid the staff, click **Mark Paid**.']),
      WARN('**Process** locks the period and **Mark Paid** finalises it and posts to expenses. Check every payslip before you click either one.'),
      P('The period list shows Period, Staff, Total Net Pay and Status. **Delete Period** removes a period that should not exist.'),
      TABLE(['Problem', 'What to do'], [['A staff member has no payslip', 'Their record must be active and have a salary. Click Generate Payslips again.'], ['A payslip cannot be edited', 'The period is already Processed or Paid.'], ['A payroll month was paid too soon', 'A Processed or Paid period is locked. Check every payslip before you click Process.']], [5.5, 10.5]))

def library_manage():
    return CH('library', 'Library', 'Facilities › Library',
      'The library module keeps the catalogue, issues books, takes them back and works out late fines.',
      H2('The catalogue'),
      OL(['Open **Facilities → Library**. Everyone can browse the catalogue.', 'To add a book, enter the **Title**, **Author**, **ISBN**, **Publisher**, **Publication Year**, **Category**, **Shelf / Location**, **Total Copies** and **Replacement Cost (TZS)**.', 'Use **Edit Book** or **Delete Book** from the row actions. A book can be Active, Inactive, Damaged or Lost.']),
      P('The list shows Book, Category, Available, Location and Status. Narrow it with **Search** and **Status**, then **Apply Filters**.'),
      H2('Issuing a book'),
      OL(['On the book\'s row, choose **Issue Book**. It is unavailable when no copies are left.', 'Choose **Student** or **Staff**, then the person. For a student, choose the Class, Section and Student.', 'Confirm the due date. By default a loan lasts 14 days.']),
      H2('Loans, returns and fines'),
      P('Click **Loans** to see every loan, filtered by Issued, Overdue, Returned or Lost. Each shows Book, Borrower, Due, Fine and Status.'),
      UL(['**Mark Returned** records the return, works out any late fine and frees the copy.', '**Report Lost** asks for the **Replacement Cost (TZS)** and **Remarks**, and removes that copy from stock for good.', '**Waive Fine** cancels a fine. You must give a **Reason for Waiving**.']),
      P('Overdue status and fines are worked out live, so opening the list always reflects today\'s date. The school\'s rules are saved under **Save Rules**: Loan Period (days), Overdue Fine per Day (TZS), Stop Charging After (days) and Default Replacement Cost (TZS). The starting values are TZS 500 per day, stopping after 60 days. Fines are collected through Fees, not the library.'),
      TABLE(['Problem', 'What to do'], [['Issue Book is greyed out', 'All copies are out. Wait for a return, or add copies.'], ['A fine looks wrong', 'Check the loan rules under Save Rules, or use Waive Fine with a reason.']], [5.5, 10.5]))

def library_view(who):
    return CH('library', 'Library', 'Facilities › Library',
      'Browse the school library and see your own loans.' if who != 'parent' else 'Browse the school library and see the loans of your children.',
      H2('Browsing the catalogue'),
      P('Open **Library** to see every book with its Category, how many copies are Available, and where it is shelved. Narrow the list with **Search** and **Status**, then **Apply Filters**.'),
      H2('My Books'),
      P('Click **My Books** to see your current and past loans, with the due date and any fine owed. A book is normally lent for 14 days. A late fine builds up each day after the due date, so return books on time.' if who != 'parent' else 'Click **My Books** to see current and past loans and any fine owed, with the due dates.'),
      NOTE('Issuing, returning and fines are handled by the librarian. To borrow a book, take it to the library desk.'))

def hostel_manage():
    return CH('hostel', 'Hostel', 'Facilities › Hostel',
      'The hostel module keeps hostels, rooms and who sleeps where.',
      OL(['Open **Facilities → Hostel**. The list shows Hostel, Type (Boys, Girls or Mixed), Warden, Rooms, Occupancy and Status.', 'To add a hostel, enter the **Hostel Name**, **Total Rooms (est.)**, **Warden**, **Address** and **Campus**.',
          'On a hostel\'s row, choose **Manage Rooms**, then **New Room**. Enter the **Room Number**, **Capacity**, **Floor** and **Status**: Available, Occupied or Maintenance.', 'On a room, choose **Manage Occupants**. Pick the **Class**, **Section** and **Student**, enter a **Fee (TZS)** if one applies, and click **Assign**.', 'To free a bed, click **Vacate** next to the student.']),
      P('The room page shows Rooms, Total Beds, Occupied and Free Beds. A student can be in only one room at a time, so assigning them somewhere new vacates the old room. A room cannot be filled past its capacity.'),
      NOTE('Hostel fees are charged through Fee Management, with Applies To set to hostel.'),
      TABLE(['Problem', 'What to do'], [['A student cannot be assigned to a room', 'The room is full, or the student is not in the class and section you chose.']], [5.5, 10.5]))

def hostel_view(who='parent'):
    return CH('hostel', 'Hostel', 'Facilities › Hostel',
      'Look at the school\'s hostels and their rooms.',
      P('Open **Hostel** to see each hostel with its type (Boys, Girls or Mixed), warden, rooms and occupancy, and open a hostel to see its rooms and how many beds are free.'),
      NOTE('Who sleeps in which room is managed by the hostel warden. If you have a question about a place, ask the warden. ' + ('Hostel fees appear in Fee Management for those who use the hostel.' if who == 'parent' else 'Questions about hostel fees go to the school\'s accountant.') + ''))

def transport_manage():
    return CH('transport', 'Transport', 'Facilities › Transport',
      'Transport has two lists, **Routes** and **Vehicles**, with a button to switch between them.',
      H2('Routes'),
      OL(['Open **Facilities → Transport** and add a route.', 'Enter the **Route Name** and **Route Number**.', 'Choose a **Vehicle** from the list, or leave it unlinked and enter the **Driver Name**, **Driver Phone**, **Vehicle Number** and **Seat Capacity** by hand.', 'Add the stops one at a time, in order. They show as a numbered list on the route.', 'Choose the **Campus** and save.']),
      P('On a route\'s row, choose **Manage Students** to see who rides it. Assign a student by choosing their class, section and name, and set their pickup and drop point. A student rides one route at a time, so assigning a new route replaces the old one. A full route refuses more students.'),
      H2('Vehicles'),
      P('On the **Vehicles** page, record each vehicle\'s Registration Number, Seat Capacity, Make, Model, Year, the driver\'s Name, Phone and Driver License Number, and the **Insurance Expiry** and **Inspection Expiry** dates. A vehicle can be Active, In Maintenance or Inactive. Maintenance records and a photo can be added to each vehicle.'),
      NOTE('Transport fees are charged through Fee Management, with Applies To set to transport.'),
      TABLE(['Problem', 'What to do'], [['A student cannot be assigned to a route', 'It is full, or the student is not in the class and section you chose.']], [5.5, 10.5]))

def transport_view(who='parent'):
    return CH('transport', 'Transport', 'Facilities › Transport',
      'Look at the school\'s bus routes and vehicles.',
      P('Open **Transport** and use the button to switch between **Routes** and **Vehicles**. A route shows its name and number, its stops in order, and the driver and vehicle details. Vehicles show registration, capacity and driver.'),
      NOTE('Which route a student rides is set by the transport manager. Ask them about pickup and drop points. ' + ('Transport fees appear in Fee Management for students who use the bus.' if who == 'parent' else 'Questions about transport fees go to the school\'s accountant.') + ''))

def inventory():
    return CH('inventory', 'Inventory', 'Facilities › Inventory',
      'Inventory tracks two kinds of stock, and they behave differently.',
      TABLE(['', 'Fixed asset', 'Consumable'], [['Examples', 'Desks, projectors, microscopes', 'Chalk, exercise books, cleaning supplies'], ['What matters', 'How many, and in what condition', 'How many are left, and when to restock'], ['Condition', 'Tracked: New, Good, Fair or Poor', 'Not tracked. One pool of stock.'], ['Reorder level', 'Not used', 'Flagged Low at or below it, and Out of stock at 0'], ['Movements', 'Received, Assigned, Damaged, Lost, Adjusted', 'Received, Issued / Used, Damaged / Expired, Lost, Adjusted']], [3, 6.5, 6.5]),
      OL(['Open **Facilities → Inventory**. The tabs **All Items**, **Fixed Assets** and **Consumables** show how many of each you have.', 'Click **New Item**. It asks which type it is first, then shows only the fields that apply.', 'Use **Receive Items** to record a delivery of several items at once.', 'Use **Record Movement** on a row for anything that changes stock. Issuing more than is on hand is refused.', 'Use **View History** to see every movement for an item.']),
      TIP('Chose the wrong type? Edit the item and change **Item Type**. The **Low stock only** filter counts consumables only.'))

def messages_send():
    return CH('messages', 'Messages: SMS and Email', 'Communication › Messages',
      'Messages lets the school reach parents, staff and others by SMS or email, and shows exactly who received what. The tabs run across the top: **Contacts**, **Groups**, **Compose**, **History**, **Website Inquiries**, **Templates** and **Info**. Work through them left to right the first time.',
      H2('Contacts and groups'),
      P('A contact is anyone you can message. **Sync from System** brings in every parent and staff member already in EduTrack (people already synced are skipped, so it is safe to run again after new admissions). **New Contact** adds one by hand. A **static group** has members you choose; a **smart group** works out its members from a rule (for example every parent of one class) and includes new admissions automatically. Groups can have subgroups.'),
      H2('Templates'),
      P('A template is a message you save so you do not retype it. Choose a **Category**, a **Channel** (SMS, Email or In-App) and write the message. Put a placeholder in double curly braces, such as `{{name}}`, and EduTrack fills it in for each recipient.'),
      WARN('A placeholder that is not available in that kind of message is not removed: it goes out exactly as typed. Always check before sending.'),
      H2('Composing and sending'),
      OL(['Open **Compose**. Under **Send To**, choose a single contact, a group or subgroup, everyone of a type, or **Custom Numbers**.', 'Choose the **Channel**, SMS or Email. Optionally pick a **Template**.', 'Click **Preview recipients**: it shows how many people will receive the message and what it will cost.', 'Write the **Message**, then click **Send Message** (or **Save as Draft**).']),
      P('With **Custom Numbers** you can **type numbers** or **pick from contacts** (for example 15 people out of 370), with search, filters and **Select all shown**. Contacts with no phone (for SMS) or no email (for Email) are greyed out. One SMS holds about 160 characters; longer messages use more than one credit.'),
      H2('History and delivery results'),
      TABLE(['Status', 'Meaning'], [['Pending', 'Handed to the provider and waiting for its answer.'], ['Accepted', 'The provider took it, but delivery to the phone is not confirmed.'], ['Delivered', 'Confirmed delivered to the handset.'], ['Failed', 'Rejected or undeliverable. The reason is shown.']], [3.5, 12.5]),
      P('**Refresh Delivery** asks the provider for the latest results; **Retry Failed** tries failed recipients again. **Website Inquiries** shows contact messages sent from the school website: **View Details**, then **Mark Replied**. **Info** shows your SMS credits; where they live depends on how SMS is connected, and credits can be bought on that page where the provider allows it.'),
      TABLE(['Problem', 'What to do'], [['Messages show as sent but nobody received them', 'If the status is Accepted, click Refresh Delivery. If no SMS gateway is active, nothing is delivered.'], ['Failed: "No phone number on file"', 'Add a number to the contact and use Retry Failed.'], ['A send is refused for low balance', 'Add credits, then Retry Failed from the message in History.']], [5.5, 10.5]))

def documents():
    return CH('documents', 'Documents: ID Cards and Certificates', 'Documents › ID Cards / Certificates',
      'Two print-and-hand-out tools: student ID cards and certificates.',
      H2('Student ID cards'),
      OL(['Open **Documents → ID Cards**. Choose the **Class**, then the **Section** (or All sections), then the **Student**.', 'The card appears with **Side A (Front)** and **Side B (Back)**. If the student has no photo, click **Upload Photo** (JPG, PNG or WEBP).', 'Click **Print Card (Front & Back)**.']),
      P('Each card prints at standard bank-card size, 85.6 mm by 54 mm. The front shows the school logo and name, the photo, name, Reg No., Class and date of birth. The back shows the parent or guardian\'s name and phone, the student\'s address, the school contact details, a QR code and a line for the Principal\'s signature. The school logo, address and phone come from **Settings → School**, so fill them in first.'),
      TIP('In the print window set Margins to None and scale to 100%, and turn on Background graphics so the colours print. Print one card on plain paper first and hold it against a real card to check the size.'),
      H2('Certificates'),
      OL(['Open **Documents → Certificates**. Choose one of four designs: Classic Gold, Modern Geometric, Formal Navy & Gold or Elegant Black.', 'Enter the **Certificate Title**, **Recipient Name** and **Body Text**, and choose the **Date**.', 'Enter the two signatories (name and title), then click **Print Certificate**.']),
      NOTE('Certificates are generated fresh each time from what you type and are not stored. Keep a copy of the PDF if you need one later.'))

def reports(full=True):
    rows = [['Financial Summary', 'Income, expenses and payroll, month by month, with the net result.'], ['Fee Collection', 'Per class: Expected, Collected and Outstanding, with the rate.'], ['Attendance Summary', 'Per class: records, present, absent and excused over a date range.'], ['Enrollment', 'Student counts per level and class, split into Male and Female.'], ['Detailed Payments', 'Every fee payment: date, student, admission number, fee, amount, method and reference.'], ['Detailed Expenses', 'Every expense: date, category, paid to, amount, method and reference.']]
    blocks = []
    if full:
        blocks += [H2('Analytics'), P('**Reports → Analytics** is a live page for administrators and principals. Everything is worked out from the database each time you open it, so it is never out of date.'),
          TABLE(['Section', 'What it shows'], [['Overview', 'Active Students, Active Staff, Classes and Pending Leave Requests.'], ['Academic', 'Attendance Rate (30 days) with a 14-day trend, and the average score of the latest completed exam.'], ['Financial', 'Fees Collected (YTD) with the collection rate, this month\'s expenses, the Latest Payroll, and expenses by category.'], ['Operations', 'Transport Occupancy, Library items issued, Hostel Occupancy and Low Stock Items.']], [3.5, 12.5])]
    blocks += [H2('Reports'), P('**Reports → Reports** produces six printable reports for meetings, audits and the board.'), TABLE(['Report', 'What it answers'], rows, [4.2, 11.8]),
      OL(['Open **Reports** and choose the report.', 'Set the filter it offers: Year, Academic Year, or From and To dates.', 'Click **Refresh**. The table appears on screen so you can check it.', 'Click **Download PDF** or **Download Excel**.']),
      P('The files are built in your browser and are not stored on the server: download them when you need them.'),
      TIP('Use Excel when you want to sort, filter or add your own calculations. Use PDF when you want to print or send a fixed copy.'),
      TABLE(['Problem', 'What to do'], [['The report is empty', 'Check the filter dates and the Academic year at the top. A report shows only what falls inside them.'], ['Figures differ from the Dashboard', 'The Dashboard shows the year to date. A report shows exactly the period you chose.']], [5.5, 10.5])]
    return CH('reports', 'Reports and Analytics' if full else 'Reports', 'Reports › Analytics / Reports', 'Analytics shows how the school is doing right now. Reports give you printable tables.' if full else 'Reports give you printable tables for meetings, audits and the board. They draw on records already in EduTrack, so there is nothing extra to enter.', *blocks)

def permissions():
    return CH('permissions', 'Roles and Permissions', 'Settings › Permissions',
      'What a person can do in EduTrack is decided by permissions, not by job title. Administrators can always do everything. Every other role can do exactly what has been ticked for it.',
      H2('The roles'),
      TABLE(['Role', 'What it starts with'], [['Super admin', 'Full access. The top account of the system owner.'], ['Admin', 'Everything in the school. This cannot be switched off, so nobody can lock the school out of its own system.'], ['Principal', 'Running the school: students, attendance, academics, exams, messages, reports, promotion and settings.'], ['Teacher', 'Attendance, marks, their timetable periods, viewing classes, the library and messages, requesting leave.'], ['Accountant', 'Fees and payroll, with view access to expenses, reports and messages.'], ['Librarian', 'Managing the library.'], ['HR manager', 'Staff records including pay, ID and bank details, plus leave and payroll.'], ['Transport manager', 'Managing transport routes and vehicles.'], ['Hostel warden', 'Managing hostel rooms and allocations.'], ['Student', 'Their own timetable, results, library loans, transport and hostel information, leave and notifications.'], ['Parent', "Their children's results, fees, library, transport and hostel information, and notifications."]], [3.5, 12.5]),
      NOTE('Parents and students always see only their own records, whatever the permissions say.'),
      H2('Doors and actions'),
      P('Think of the school as a building with rooms: Students, Fees, Library, Payroll and so on. A permission is a key, and there are two kinds. A **door key** (**Open Students**) puts the module in the menu and opens its pages. An **action key** (**View, Create, Update, Delete**) decides what a person can do once inside. If a person is not given an action, its button is not shown at all.'),
      H2('Changing what a role can do'),
      OL(['Open **Settings → Permissions**.', 'On the **Role Permissions** tab, choose a **Role**.', 'Tick a permission to allow it, or untick it to take it away. What you see ticked is what that role can really do now.', 'To undo your changes, click **Reset to standard**.']),
      P('To take a whole module away from a role, untick its **Open …** permission. To stop just one action, untick that action.'),
      H2('Giving one person extra permissions'),
      OL(['Open **Settings → Permissions** and choose the **Individual Overrides** tab.', 'Choose the **Staff Member**.', 'Tick the extra permissions they need.']),
      NOTE('Overrides only add. To take something away from one person, change their role instead. The change applies on the server straight away; the person\'s menu updates the next time they refresh or sign in.'),
      TABLE(['Problem', 'What to do'], [['A teacher cannot see a page they need', 'Check the role has the Open … permission for that module.'], ['A button is missing', 'The matching action permission is not ticked, for example Update or Delete.'], ['One person needs more than the rest of their role', 'Use Individual Overrides instead of changing the whole role.']], [5.5, 10.5]))

def administration(kind):
    full = kind in ('admin', 'super_admin')
    tabs = [['School', 'Logo and printed contact details'], ['General', 'Date format, receipt size, money decimals'], ['Notifications', 'Which automatic alerts go out, and password reset codes']]
    if full: tabs += [['Permissions', 'What each role and person can do'], ['Academic Year', 'The school years and their terms'], ['Backup & Export', 'Download your data as Excel'], ['Audit Log', 'Who changed what, and when'], ['Login Policy', 'Idle logout and account lock rules']]
    tabs += [['Theme & Colors', 'The look of the application'], ['Security', 'Your own password']]
    blocks = [H2('The Settings tabs'), P('Open **Settings** from the profile menu or the Settings group. You see only the tabs your role allows.' + ('' if full else ' As principal you see the tabs below; the others are for administrators.')), TABLE(['Tab', 'What it is for'], tabs, [4, 12]),
      H2('School: logo and contact details'), P('The **School** tab sets the identity printed on receipts, report cards and ID cards for the campus you selected. Upload your **School Logo**, fill in **Address**, **Phone**, **Email** and **Website**, and save. If you run several campuses, switch the campus at the top and repeat for each.'),
      H2('General'), P('Choose the **Date Format** used across the system, the **Default Receipt Size**, and the **Money Decimals** (none, TZS 12,000, or two, TZS 12,000.00). These belong to the whole school: when someone with permission changes one, everyone sees it on every computer. Below them, **Use EduTrack as an app** lets you install EduTrack like any other program.'),
      H2('Notifications'), P('Choose which events notify people automatically, such as an admission, a payment or entered marks. For each notification you choose **who is told** and **how**. For example, **Payment Recorded** can go to the parent, to the accountants and admins, or to both. Under each person or group you tick the channels to use: **In-App**, **SMS** or **Email**. A notification needs at least one person ticked, or must be switched off. Staff can only be reached by SMS or email if their profile has a phone number or email address. **Password reset codes** decides where the 6-digit code goes when someone forgets their password: email only (the default), SMS only, or either.')]
    if full:
        blocks += [H2('Academic year and terms'), P('Open **Academic Year**. Set the **System Start Year**, then add the **Terms / Semesters** for the year with their **Start Date** and **End Date** (**Add Term** for each one). Terms power the This term card on the Dashboard and the Term choices in exams. Set them up before the year begins.'),
        H2('Login policy'), UL(['**Idle Auto-Logout**: minutes of inactivity before someone is signed out, from 5 to 240.', '**Max Failed Attempts**: wrong passwords allowed before the account locks, from 3 to 10.', '**Lockout Duration**: how long a locked account stays locked, from 5 to 1440 minutes.']),
        H2('Audit log'), P('The Audit Log lists every create, update and delete, who did it and when, in plain words. Filter by activity type, module and date, and click **View Details** on an entry: for an update you see each field before and after. Failed sign-ins are listed too, in red. Passwords and other secrets are never shown.'),
        H2('Backup & Export'), P('Choose **Download a Backup** and pick what to export: Students, Staff, Fee Structures, Payments, or all four, as an Excel workbook. This is an export for your own records and for working in Excel. It is **not** a complete backup of the system: the platform owner\'s automatic daily backup copies the whole database and checks that it can be restored. **Automatic Backup Reminder** only reminds you to download the Excel export.'),
        TIP('Download an export before the end of every term and before any big change. Student promotion, bulk imports and system updates also make an automatic safety backup of the whole database first.')]
    blocks += [H2('Theme and security'), P('On **Theme & Colors** choose a ready-made theme or set custom colours. The **Security** tab shows your email, role and last sign-in, and lets you change your password; a strength bar tells you whether a new password is Weak, Fair or Strong.'),
      TABLE(['Problem', 'What to do'], [['I cannot see a Settings tab', 'Your role does not include that permission.'], ['Receipts or ID cards show the wrong address or logo', 'Check the School tab for the campus you have selected.'], ['Someone is locked out', 'Wait for the lockout to end, or ask them to use Forgot password?']], [5.5, 10.5])]
    return CH('administration', 'Administration' if full else 'Settings', 'Settings', 'This chapter covers the school\'s identity and calendar, how sign-in is protected and the look of the application.' if full else 'The settings you can change for the school and for yourself.', *blocks)

def campus_subscription(full=True):
    blocks = []
    if full:
        blocks += [H2('Campuses'), P('Open **Campus** to manage campuses. The page shows Total, Active and Inactive Campuses and Total Students, and lists each with Campus, Location, Contact, Principal and Status. To add one, enter the **Campus Name**, **Campus Code**, address, phone, email and website, optionally upload a **School Logo**, choose a **Principal**, and set the **Status**. Use **Edit Campus**, **Deactivate** or **Activate** for existing ones.')]
    blocks += [H2('Subscription'),
      P('Open **Subscription** to see your **Current Plan**, when it **Renews / Expires**, the number of Active Students and the Billing Cycle (Monthly, Per Term or Yearly).'),
      OL(['Under **Choose a Plan**, pick the plan and billing cycle, then click **Renew**, **Upgrade** or **Choose Plan**.', 'Check the price breakdown, enter the **Mobile Money Number** and click **Pay**. An invoice is created and a payment prompt is sent to that number.', 'Approve the prompt on the phone. When the payment is confirmed the plan starts. If it has not updated, click **Check Payment Status**.']),
      H2('Invoices and receipts'),
      P('Every attempt to pay creates an invoice. **Preview** opens it on screen, where you can **Download PDF** or **Print** it. An unpaid invoice carries a **Scan to pay** QR code: anyone at the school can scan it and pay with a mobile money number, without signing in. Once paid it shows PAID and has a **Receipt** with a verification QR code, which anyone can use to confirm it is genuine.'),
      UL(['**Pay** sends the payment prompt for an unpaid invoice. Invoices older than 7 days cannot be paid; create a new one.', '**Cancel** withdraws an unpaid invoice. EduTrack asks you to confirm first. Invoices unpaid for 30 days are cancelled automatically.', '**Clean up old invoices** removes cancelled invoices and unpaid ones older than 30 days, after showing how many. Paid invoices and receipts are never removed.']),
      H2('Reminders and expiry'),
      P('EduTrack emails the school\'s administrators 7 days and 3 days before the subscription ends, on the day it ends, and when it locks. After the end date there is a short grace period (2 days by default) during which everything works and a red banner counts down. When it ends, or if the subscription is cancelled, EduTrack locks: everyone is taken to the Subscription page, which is the only item left in the menu. All data is kept, and as soon as a payment is confirmed the menu opens again.'),
      TABLE(['Problem', 'What to do'], [['Everything shows only Subscription', 'The subscription has expired or was cancelled. Pay there and the rest opens again.'], ['The invoice has no school address', 'Fill in the contact details under Settings → School.']], [5.5, 10.5])]
    return CH('subscription', 'Campuses and Subscription' if full else 'Subscription', 'Settings group › Campus / Subscription', 'Manage the school\'s campuses and its EduTrack plan.' if full else 'See the school\'s EduTrack plan, pay for it and keep its invoices and receipts.', *blocks)

def backup_owner():
    return CH('backup', 'Database Backup and Restore', 'Settings › Database Backup',
      'EduTrack makes a complete copy of the whole database every day and proves that it can be restored. This page is for the platform owner: it appears only for an email listed in the server\'s `DEVELOPER_EMAILS` setting, because a full backup holds every school\'s data.',
      H2('How it protects you'),
      UL(['**Complete:** every table in the database, found by asking the database itself, so a table added later is included automatically.', '**Tested:** right after each backup, EduTrack restores it into a scratch area, compares every table with the live data and throws the scratch copy away. Only a backup that passes counts as good.', '**Daily:** at the hour you choose (default 02:00). If the server was asleep at that hour, the backup is made as soon as it wakes.', '**Before risky actions:** a fresh tested backup is made before a student promotion (or revert), before a bulk import and before a database update. If it cannot be made, the action does not run.', '**Off the server:** optionally copied to a folder named “EduTrack Backups” in your Google Drive.']),
      H2('The page'),
      P('**Settings → Database Backup** shows the latest good backup, a **Back up now** button, the schedule (time of day, how long to keep backups, and the safety-backup switch) and the **Backup history** with the restore-test result and Google Drive status of every backup. Each backup can be downloaded, tested again or deleted. The newest three good backups are always kept.'),
      H2('Connecting Google Drive (once)'),
      OL(['In **console.cloud.google.com** create a project and enable the **Google Drive API**.', 'On the **OAuth consent screen** choose External, fill in the app name and your email, and set the publishing status to **In production**. In “Testing” mode Google cancels the link after 7 days and uploads would silently stop.', 'Under **Credentials** create an **OAuth client ID** of type Web application and add the **redirect address** shown on the page as an Authorised redirect URI.', 'Paste the **Client ID** and **Client secret** into the page and click **Save credentials**, then **Connect Google Drive**, sign in and allow access.']),
      NOTE('EduTrack asks only for access to files it creates itself, never the rest of your Drive. The secret and the connection are stored encrypted. If Google ever revokes the link, backups still succeed on the server, you are emailed and the page asks you to reconnect.'),
      H2('Restoring after a disaster'),
      P('Restoring replaces the live database, so it is done on purpose from the server, never from the web page. In the **backend** folder:'),
      TABLE(['Command', 'What it does'], [['`npm run db:backup`', 'Make a backup now and test it. Use this from a hosting cron job if you like.'], ['`npm run db:backup:due`', 'Make today\'s backup only if it is due. Safe to run every hour.'], ['`npm run db:backup:list`', 'List the backup files on the server.'], ['`npm run db:backup:verify -- latest`', 'Run the restore test on a backup again.'], ['`npm run db:restore -- latest --wipe`', 'REPLACE the database with the latest backup. You must type the database name to confirm.']], [6.5, 9.5]),
      P('A restore runs as one all-or-nothing step and checks every table against the backup afterwards. If anything is wrong, the database is left exactly as it was. To restore a file from Google Drive, download it and put it in the **backend/backups** folder first. Restart the app afterwards.'),
      WARN('Student photos and uploaded documents are files on the server, not in the database, so this backup does not include them. Back up the **backend/uploads** folder separately.'))

def platform_owner_note():
    return CH('owner', 'What is Different for a Super Admin', 'Settings',
      'A super admin has everything an administrator has. These are the differences that matter.',
      UL(['**Your role is fixed.** Nobody can change a super admin\'s role from the Staff screen, and you cannot change your own.', 'You can give any staff role, including **Admin** and **Principal**.', 'You are the last person leave requests fall back to when a school has no principal and no admin.', 'A super admin account that belongs to a school is locked like everyone else when that school\'s subscription expires. Only the platform developer, whose email is listed on the server, is never locked.', 'Plan prices, payment-gateway checks and SMS or email gateway credentials are handled by the platform developer on the server, not on the school screens.']),
      NOTE('Everything else in this guide applies to you in full. The chapter **Database Backup and Restore** is visible only if your email is also listed as a platform developer on the server.'))
