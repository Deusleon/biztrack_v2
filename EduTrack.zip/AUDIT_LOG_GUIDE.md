# Audit Log (Activity History) — Guide

**Where:** Settings → Audit Log (admins and super-admins only).

## What you see

Each entry says what actually happened, in words — not the route that was called:

| Entry | Meaning |
|---|---|
| `Created class "Form 1"` | a record was created |
| `Updated class "Form 1A"` · *Changed: Name, Capacity* | a record was edited; the fields that changed are listed under it |
| `Deactivated class "Form 1A"` / `Reactivated …` | an edit whose only change was its status |
| `Deleted class "Form 1A"` | a record was removed |
| `Updated 3 class records (status → inactive)` | a change applied to several records at once |
| `Signed in (user@school.tz)` / `Signed out` / `Changed own password` | account activity |
| `Send — messages` | an action that isn't a record change |

If one request changed several records (e.g. a payment that also updates a student's balance) the title names the main
one and adds `(+2 related changes)`; the detail view lists all of them.

**View Details** (or click the title) opens a window with who / when / module / where from, and:

- **Updates** — a *Field · Before · After* table (before in red, after in green). Ids are shown as names
  ("Main Campus", not a UUID).
- **Creates** — everything the record was created with.
- **Deletes** — what the record looked like when it was deleted.
- **Bulk changes** — how many records and what was set. (Individual before-values aren't available for those.)
- **Technical details** (collapsed) — the request path, device and ids, for troubleshooting.

Filters: search, type (Created / Updated / Deleted / Sign-ins / Other actions), module, date range.

## Passwords and secrets are never stored

Any field whose name suggests a credential (`password`, `secret`, `token`, `api_key`, `pin`, `otp`, …) is recorded as
`[hidden]` — changed, but with neither value shown. Older entries were stored with the raw request body; those are
scrubbed when they are read, so they never reach the screen, though the original text is still in the database table
until it is cleaned up.

## Older entries

Entries written before this existed only have the route. They are described from it ("Updated students "Amina Juma"")
and marked *Older entry*; their detail view shows what was submitted but not the previous values, because that was
never recorded.

## How it works (for developers)

- `middleware/auditLog.js` opens a per-request store (`utils/auditContext.js`, `AsyncLocalStorage`) and registers global
  Sequelize hooks (`afterCreate / afterUpdate / afterDestroy / afterBulk*`). Every change made *while a request is being
  handled* is noted in that store; when the response is sent successfully (POST/PUT/PATCH/DELETE) the notes become one
  `audit_logs` row. Work outside a request (seeds, scripts) is not recorded. Failed requests are not recorded.
- Limits per request: 40 detailed changes, and 5 per model/operation — beyond that only a count is kept (`…and 25 more
  message recipient records created`), so importing 200 students doesn't write 200 entries.
- `utils/auditDescribe.js` holds the wording and scrubbing (pure functions, unit-tested).
- API: `GET /settings/audit-logs` (light list) and `GET /settings/audit-logs/:id` (full details + resolved names).
- No migration — it uses the existing `audit_logs.details` JSONB column.

Tests: `tests/unit/auditDescribe.test.js` and `tests/integration/audit-log.test.js` (real app, real database).
