# Payroll — Guide

Monthly payroll runs. Kept to 2 models: a Period (one month) and Items
(one payslip per staff member in it).

## Lifecycle

Draft -> Processed -> Paid.

- Draft: generate payslips (pre-filled from each staff member's salary),
  edit basic salary, add allowance/deduction line items freely.
- Processed: locked from editing, ready to pay.
- Paid: finalized. A single Expense entry is created automatically under
  "Salaries & Wages" for the period's total net pay -- payroll and the
  expense ledger stay in sync without double-entry bookkeeping.

## How it works

### Payroll (`/payroll`)
Accountant/Admin/HR see the list of payroll periods (create a new one,
open any to manage). Everyone else sees My Payslips instead -- their own
pay history, expandable to see the full breakdown per month.

### Period detail (`/payroll/:id`)
Generate Payslips creates one for every active staff member who doesn't
already have one in this period (safe to run again after adding staff).
Click Edit on any payslip (draft periods only) to add allowances (e.g.
Housing, Transport) or deductions (e.g. NSSF, PAYE) as simple named line
items -- gross/net recompute live as you type. Process locks it; Mark
Paid finalizes it and posts to Expenses.

## How to test

The seed script creates a fully paid January 2026 period (every active
staff member, with the Principal's payslip showing sample allowances/
deductions) and a draft February 2026 period ready to work with.

1. Log in as admin -> Payroll -> confirm January 2026 shows "Paid" and
   February 2026 shows "Draft".
2. Open January 2026 -> confirm payslips are visible but not editable
   (period is paid) -> confirm the Principal's payslip shows Housing/
   Transport allowances and NSSF/PAYE deductions.
3. Expenses -> confirm a "Staff Payroll" entry for January exists under
   Salaries & Wages, matching January's total net pay.
4. Open February 2026 -> Generate Payslips -> confirm one payslip appears
   per active staff member, pre-filled with their basic salary.
5. Edit one payslip -> add a "Transport Allowance" of 100,000 -> Save ->
   confirm gross and net pay update immediately in the table.
6. Process -> confirm editing is now blocked. Mark Paid -> confirm a new
   Expense entry appears for February's total.
7. Log in as a teacher -> Payroll -> confirm they see My Payslips (not
   the period list) with their own January payslip.
