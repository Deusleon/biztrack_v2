# Hostel — Guide

Boarding houses, rooms, and student assignments. Model was already in
place before this round — this added the controller, routes, and UI.

## How it works

### Hostels (`/hostel`)
List of hostels with type (boys/girls/mixed), warden, room count, and
occupancy. Admin/Principal/Hostel Warden can create, edit, delete.

### Manage Rooms (`/hostel/:id/rooms`)
Rooms within one hostel -- capacity, floor, status (available/occupied/
maintenance). "Manage Students" per room opens a panel to assign a
student (class -> section -> student, matching the Transport/Library
pattern) or vacate someone already there. A student can only be in one
room at a time -- assigning them elsewhere automatically vacates their
previous room.

## How to test

The seed script creates 2 hostels (Amani Boys, Furaha Girls) with 6
rooms each, and assigns 6 Form I A students split by gender.

1. Log in as admin -> Hostel -> confirm 2 hostels with occupancy shown.
2. Manage Rooms on Amani Boys -> confirm Room A1 shows some occupied
   seats.
3. Manage Students on Room A1 -> assign another Form I A student ->
   confirm occupancy updates.
4. Try assigning past a room's capacity -> confirm it's blocked.
5. Vacate a student -> confirm the room's occupied count decreases and
   they no longer appear in the room's list.
