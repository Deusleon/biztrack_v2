// FILE PATH: frontend/src/services/api.js
import api from '../utils/api';

export const authService = {
  login: async (credentials) => {
    const response = await api.post('/auth/login', credentials);
    if (response.success && response.data.token) {
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data));
    }
    return response;
  },

  register: async (userData) => {
    const response = await api.post('/auth/register', userData);
    if (response.success && response.data.token) {
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data));
    }
    return response;
  },

  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },

  getCurrentUser: () => {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  },

  getMe: async () => {
    return await api.get('/auth/me');
  },

  updateProfile: async (data) => {
    return await api.put('/auth/profile', data);
  },

  uploadAvatar: async (file) => {
    const formData = new FormData();
    formData.append('avatar', file);
    return await api.post('/auth/profile/avatar', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
  },

  // Public — for someone who cannot sign in. See pages/ForgotPassword.jsx.
  forgotPasswordOptions: async () => api.get('/auth/forgot-password/options'), // { mode: 'email' | 'sms' | 'either' }
  forgotPassword: async (identifier) => api.post('/auth/forgot-password', { identifier }),
  resetPassword: async (data) => api.post('/auth/reset-password', data),

  changePassword: async (data) => {
    const response = await api.put('/auth/change-password', data);
    // Changing the password voids every earlier session, including this one; the
    // server hands back a fresh token so this browser stays signed in.
    if (response.success && response.data?.token) localStorage.setItem('token', response.data.token);
    return response;
  },
};

export const studentService = {
  getAll: async (params) => {
    return await api.get('/students', { params });
  },

  // Takes the selected academic year, so the profile shows the class the
  // student was actually in that year rather than the one they are in now.
  getById: async (id, params) => {
    return await api.get(`/students/${id}`, { params });
  },

  getStats: async (id, params) => {
    return await api.get(`/students/${id}/stats`, { params });
  },

  create: async (data) => {
    return await api.post('/students', data);
  },

  update: async (id, data) => {
    return await api.put(`/students/${id}`, data);
  },

  delete: async (id) => {
    return await api.delete(`/students/${id}`);
  },

  bulkUpdateStatus: async (data) => {
    return await api.patch('/students/bulk/status', data);
  },

  bulkCreate: async (data) => {
    return await api.post('/students/bulk', data);
  },

  // Checks an Excel file's rows (errors, duplicates, plan limit) without saving anything.
  bulkPreview: async (data) => api.post('/students/bulk/preview', data),

  reactivate: async (id) => {
    return await api.patch(`/students/${id}/reactivate`);
  },

  permanentDelete: async (id) => {
    return await api.delete(`/students/${id}/permanent`);
  },
};

export const attendanceService = {
  getAll: async (params) => {
    return await api.get('/attendance', { params });
  },

  getSessions: async (params) => {
    return await api.get('/attendance/sessions', { params });
  },

  getById: async (id) => {
    return await api.get(`/attendance/${id}`);
  },

  mark: async (data) => {
    return await api.post('/attendance/mark', data);
  },

  bulkMark: async (data) => {
    return await api.post('/attendance/bulk-mark', data);
  },

  update: async (id, data) => {
    return await api.put(`/attendance/${id}`, data);
  },

  getReport: async (params) => {
    return await api.get('/attendance/report', { params });
  },
};

export const campusService = {
  getAll: async (params) => {
    return await api.get('/campus', { params });
  },

  getById: async (id) => {
    return await api.get(`/campus/${id}`);
  },

  create: async (data) => {
    return await api.post('/campus', data);
  },

  update: async (id, data) => {
    return await api.put(`/campus/${id}`, data);
  },

  delete: async (id) => {
    return await api.delete(`/campus/${id}`);
  },

  permanentDelete: async (id) => {
    return await api.delete(`/campus/${id}/permanent`);
  },

  reactivate: async (id) => {
    return await api.patch(`/campus/${id}/reactivate`);
  },

  // School logo — printed as the letterhead on receipts and report cards
  uploadLogo: async (id, file) => {
    const formData = new FormData();
    formData.append('logo', file);
    return await api.post(`/campus/${id}/logo`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
  },

  deleteLogo: async (id) => {
    return await api.delete(`/campus/${id}/logo`);
  },

  bulkUpdateStatus: async (data) => {
    return await api.patch('/campus/bulk/status', data);
  },

  getStats: async (id) => {
    return await api.get(`/campus/${id}/stats`);
  },

  // Totals across every campus, not just the page on screen.
  getSummary: async () => {
    return await api.get('/campus/stats/summary');
  },
};

export const staffService = {
  bulkPreview: async (data) => api.post('/staff/bulk/preview', data),
  bulkCreate: async (data) => api.post('/staff/bulk', data),
  getAll: async (params) => {
    return await api.get('/staff', { params });
  },

  getById: async (id) => {
    return await api.get(`/staff/${id}`);
  },

  getStats: async (id) => {
    return await api.get(`/staff/${id}/stats`);
  },

  // Profile picture, shown on the staff details page and reused as their account avatar
  uploadPhoto: async (id, file) => {
    const formData = new FormData();
    formData.append('photo', file);
    return await api.post(`/staff/${id}/photo`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
  },

  // Employment documents — ID copy, appointment letter, certificates
  uploadDocument: async (id, file, meta = {}) => {
    const formData = new FormData();
    formData.append('document', file);
    if (meta.name) formData.append('name', meta.name);
    if (meta.type) formData.append('type', meta.type);
    return await api.post(`/staff/${id}/documents`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
  },

  deleteDocument: async (id, documentId) => {
    return await api.delete(`/staff/${id}/documents/${documentId}`);
  },

  create: async (data) => {
    return await api.post('/staff', data);
  },

  update: async (id, data) => {
    return await api.put(`/staff/${id}`, data);
  },

  delete: async (id) => {
    return await api.delete(`/staff/${id}`);
  },

  permanentDelete: async (id) => {
    return await api.delete(`/staff/${id}/permanent`);
  },

  reactivate: async (id) => {
    return await api.patch(`/staff/${id}/reactivate`);
  },

  bulkUpdateStatus: async (data) => {
    return await api.patch('/staff/bulk/status', data);
  },
};

export const classService = {
  getAll: async (params) => api.get('/classes', { params }),
  getById: async (id) => api.get(`/classes/${id}`),
  getStats: async (id) => api.get(`/classes/${id}/stats`),
  create: async (data) => api.post('/classes', data),
  update: async (id, data) => api.put(`/classes/${id}`, data),
  delete: async (id) => api.delete(`/classes/${id}`),
  permanentDelete: async (id) => api.delete(`/classes/${id}/permanent`),
  reactivate: async (id) => api.patch(`/classes/${id}/reactivate`),
  bulkUpdateStatus: async (data) => api.patch('/classes/bulk/status', data),
  addSection: async (classId, data) => api.post(`/classes/${classId}/sections`, data),
  updateSection: async (classId, sectionId, data) => api.put(`/classes/${classId}/sections/${sectionId}`, data),
  deleteSection: async (classId, sectionId) => api.delete(`/classes/${classId}/sections/${sectionId}`),
  cloneYear: async (data) => api.post('/classes/clone-year', data),
};

export const subjectService = {
  getAll: async (params) => api.get('/subjects', { params }),
  getById: async (id) => api.get(`/subjects/${id}`),
  getStats: async (id) => api.get(`/subjects/${id}/stats`),
  create: async (data) => api.post('/subjects', data),
  update: async (id, data) => api.put(`/subjects/${id}`, data),
  delete: async (id) => api.delete(`/subjects/${id}`),
  permanentDelete: async (id) => api.delete(`/subjects/${id}/permanent`),
  reactivate: async (id) => api.patch(`/subjects/${id}/reactivate`),
  bulkUpdateStatus: async (data) => api.patch('/subjects/bulk/status', data),
};

export const examService = {
  // Exams (CRUD)
  getAll: async (params) => api.get('/exams', { params }),
  getById: async (id) => api.get(`/exams/${id}`),
  create: async (data) => api.post('/exams', data),
  update: async (id, data) => api.put(`/exams/${id}`, data),
  delete: async (id) => api.delete(`/exams/${id}`),

  // Marks entry
  getMarksSheet: async (examId, params) => api.get(`/exams/${examId}/marks-sheet`, { params }),
  saveMarks: async (examId, data) => api.post(`/exams/${examId}/marks`, data),

  // Results
  getClassResults: async (examId, params) => api.get(`/exams/${examId}/class-results`, { params }),
  getReportCard: async (examId, studentId) => api.get(`/exams/${examId}/report-card/${studentId}`),
  getMyExams: async () => api.get('/exams/my-results'),
  getTermSummary: async (params) => api.get('/exams/term-summary', { params }),
};

export const messagingService = {
  // Contacts
  getContacts: async (params) => api.get('/messaging/contacts', { params }),
  createContact: async (data) => api.post('/messaging/contacts', data),
  updateContact: async (id, data) => api.put(`/messaging/contacts/${id}`, data),
  deleteContact: async (id) => api.delete(`/messaging/contacts/${id}`),
  syncContacts: async () => api.post('/messaging/contacts/sync'),

  // Groups
  getGroups: async () => api.get('/messaging/groups'),
  createGroup: async (data) => api.post('/messaging/groups', data),
  updateGroup: async (id, data) => api.put(`/messaging/groups/${id}`, data),
  deleteGroup: async (id) => api.delete(`/messaging/groups/${id}`),
  setGroupMembers: async (id, contact_ids) => api.put(`/messaging/groups/${id}/members`, { contact_ids }),
  getGroupMembers: async (id) => api.get(`/messaging/groups/${id}/members`),

  // Templates
  getTemplates: async (params) => api.get('/messaging/templates', { params }),
  createTemplate: async (data) => api.post('/messaging/templates', data),
  updateTemplate: async (id, data) => api.put(`/messaging/templates/${id}`, data),
  deleteTemplate: async (id) => api.delete(`/messaging/templates/${id}`),

  // Messages
  previewRecipients: async (data) => api.post('/messaging/preview-recipients', data),
  getMessages: async (params) => api.get('/messaging/messages', { params }),
  getMessageById: async (id) => api.get(`/messaging/messages/${id}`),
  getMessageRecipients: async (id, params) => api.get(`/messaging/messages/${id}/recipients`, { params }),
  saveDraft: async (data) => api.post('/messaging/messages/draft', data),
  deleteMessage: async (id) => api.delete(`/messaging/messages/${id}`),
  sendMessage: async (data) => api.post('/messaging/messages/send', data),
  retryMessage: async (id) => api.post(`/messaging/messages/${id}/retry`),
  refreshDelivery: async (id) => api.post(`/messaging/messages/${id}/refresh-delivery`),

  // SMS balance & gateway
  getBalance: async () => api.get('/messaging/sms/balance'),
  purchaseBalance: async (data) => api.post('/messaging/sms/purchase', data),
  updateCostPerSms: async (cost_per_sms) => api.put('/messaging/sms/cost', { cost_per_sms }),
  getTransactions: async (params) => api.get('/messaging/sms/transactions', { params }),
  getGatewaySettings: async () => api.get('/messaging/sms/gateway'),
  updateGatewaySettings: async (data) => api.put('/messaging/sms/gateway', data),
  testGatewayConnection: async () => api.post('/messaging/sms/gateway/test'),
  getProviderSenderIds: async () => api.get('/messaging/sms/gateway/sender-ids'),
  topUpProvider: async (data) => api.post('/messaging/sms/top-up', data),
  getWalletOptions: async (params) => api.get('/messaging/sms/wallet/options', { params }), // SwalaSMS: markets, packages, payment methods
  quoteWalletTopUp: async (data) => api.post('/messaging/sms/wallet/quote', data),
  getSenderIdRequirements: async () => api.get('/messaging/sms/gateway/sender-requirements'),
  requestSenderId: async (data) => api.post('/messaging/sms/gateway/sender-ids', data),
  checkTopUpStatus: async (orderId) => api.get(`/messaging/sms/top-up/${orderId}`),
  getBatchDeliveryStats: async (batchId) => api.get(`/messaging/sms/batch/${batchId}`),

  // Email gateway
  getEmailGatewaySettings: async () => api.get('/messaging/email/gateway'),
  updateEmailGatewaySettings: async (data) => api.put('/messaging/email/gateway', data),
  // Checks the SMTP settings (optionally the unsaved form) — add send_to to also send one real test message
  testEmailGateway: async (data = {}) => api.post('/messaging/email/gateway/test', data),
};

export const notificationService = {
  getMyNotifications: async (params) => api.get('/notifications', { params }),
  getUnreadCount: async () => api.get('/notifications/unread-count'),
  markAsRead: async (id) => api.put(`/notifications/${id}/read`),
  markAllAsRead: async () => api.put('/notifications/read-all'),
  getEventSettings: async () => api.get('/notifications/settings/events'),
  updateEventSetting: async (data) => api.put('/notifications/settings/events', data),
};

// Public receipt verification — no auth required, so these work even when
// nobody is logged in (e.g. checking a physical receipt at the counter).
// The page a "Scan to pay" QR code opens — public, no sign-in.
export const payLinkService = {
  get: async (number, code) => api.get(`/public/subscription-pay/${number}/${code}`),
  status: async (number, code) => api.get(`/public/subscription-pay/${number}/${code}/status`),
  pay: async (number, code, data) => api.post(`/public/subscription-pay/${number}/${code}`, data),
};

export const verifyService = {
  byId: async (paymentId, code) => api.get(`/verify/receipt/${paymentId}/${code}`),
  byCode: async (receiptNo, code) => api.get('/verify/receipt', { params: { receipt_no: receiptNo, code } }),
  subscriptionReceipt: async (receiptNo, code) => api.get('/verify/subscription-receipt', { params: { receipt_no: receiptNo, code } }),
};

export const feeService = {
  // Fee Structures (CRUD)
  getStructures: async (params) => api.get('/fees/structures', { params }),
  createStructure: async (data) => api.post('/fees/structures', data),
  updateStructure: async (id, data) => api.put(`/fees/structures/${id}`, data),
  deleteStructure: async (id) => api.delete(`/fees/structures/${id}`),

  // "Selected Students" — who a fee with applies_to='selected_students' bills
  getStructureStudents: async (id) => api.get(`/fees/structures/${id}/students`),
  setStructureStudents: async (id, studentIds) => api.put(`/fees/structures/${id}/students`, { student_ids: studentIds }),

  // Payments
  getPayments: async (params) => api.get('/fees/payments', { params }),
  createPayment: async (data) => api.post('/fees/payments', data),
  getPaymentById: async (id) => api.get(`/fees/payments/${id}`),
  deletePayment: async (id) => api.delete(`/fees/payments/${id}`),

  // Status / summaries
  getMyChildrenFees: async () => api.get('/fees/my-children'),
  getClassFeeStatus: async (params) => api.get('/fees/class-status', { params }),
  getStudentFeeSummary: async (studentId, params) => api.get(`/fees/student/${studentId}/summary`, { params }),
};

export const permissionsService = {
  getAvailable: async () => api.get('/permissions/available'),
  getRolePermissions: async () => api.get('/permissions/roles'),
  updateRolePermissions: async (role, permissions) => api.put(`/permissions/roles/${role}`, { permissions }),
  resetRolePermissions: async (role) => api.put(`/permissions/roles/${role}`, { reset: true }),
  getStaffPermissions: async () => api.get('/permissions/staff'),
  updateUserPermissions: async (userId, permissions) => api.put(`/permissions/users/${userId}`, { permissions }),
};

export const settingsService = {
  getOverview: async () => api.get('/settings'),
  updateDisplay: async (data) => api.put('/settings/display', data),
  getWebsiteContent: async () => api.get('/settings/website-content'),
  updateWebsiteContent: async (data) => api.put('/settings/website-content', data),
  updateAcademicYear: async (payload) => api.put('/settings/academic-year', payload),
  updateSessionPolicy: async (payload) => api.put('/settings/session-policy', payload),
  updateBackupSchedule: async (payload) => api.put('/settings/backup-schedule', payload),
  exportData: async (type) => api.get('/settings/export', { params: { type } }),
  getAuditLogs: async (params) => api.get('/settings/audit-logs', { params }),
  getAuditLog: async (id) => api.get(`/settings/audit-logs/${id}`),
  getAuditLogResourceTypes: async () => api.get('/settings/audit-logs/resource-types'),
};

export const admissionInquiryService = {
  list: async (params) => api.get('/admission-inquiries', { params }),
  getCounts: async () => api.get('/admission-inquiries/counts'),
  updateStatus: async (id, payload) => api.patch(`/admission-inquiries/${id}`, payload),
};

export const contactInquiryService = {
  list: async (params) => api.get('/contact-inquiries', { params }),
  getCounts: async () => api.get('/contact-inquiries/counts'),
  updateStatus: async (id, payload) => api.patch(`/contact-inquiries/${id}`, payload),
};

export const documentsService = {
  uploadStudentPhoto: async (studentId, file) => {
    const formData = new FormData();
    formData.append('photo', file);
    return api.post(`/documents/students/${studentId}/photo`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
  getStudentDocuments: async (studentId) => api.get(`/documents/students/${studentId}/documents`),
  uploadStudentDocument: async (studentId, file, { category, title } = {}) => {
    const formData = new FormData();
    formData.append('file', file);
    if (category) formData.append('category', category);
    if (title) formData.append('title', title);
    return api.post(`/documents/students/${studentId}/documents`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
  deleteStudentDocument: async (studentId, docId) => api.delete(`/documents/students/${studentId}/documents/${docId}`),
};

export const analyticsService = {
  getDashboard: async (params) => api.get('/analytics/dashboard', { params }),
  getHighlights: async () => api.get('/analytics/highlights'),
};

export const reportsService = {
  getYearRange: async () => api.get('/reports/year-range'),
  getFinancialSummary: async (year) => api.get('/reports/financial-summary', { params: { year } }),
  getFeeCollection: async (academic_year) => api.get('/reports/fee-collection', { params: { academic_year } }),
  getAttendanceSummary: async (params) => api.get('/reports/attendance-summary', { params }),
  getEnrollment: async (params) => api.get('/reports/enrollment', { params }),
  getDetailedPayments: async (params) => api.get('/reports/detailed-payments', { params }),
  getDetailedExpenses: async (params) => api.get('/reports/detailed-expenses', { params }),
};

export const inventoryService = {
  // Items
  getItems: async (params) => api.get('/inventory/items', { params }),
  getItemById: async (id) => api.get(`/inventory/items/${id}`),
  createItem: async (data) => api.post('/inventory/items', data),
  updateItem: async (id, data) => api.put(`/inventory/items/${id}`, data),
  deleteItem: async (id) => api.delete(`/inventory/items/${id}`),

  // Transactions
  getTransactions: async (params) => api.get('/inventory/transactions', { params }),
  createTransaction: async (data) => api.post('/inventory/transactions', data),
  bulkReceive: async (data) => api.post('/inventory/receive', data),
};

export const payrollService = {
  // Periods
  getPeriods: async (params) => api.get('/payroll/periods', { params }),
  getPeriodById: async (id) => api.get(`/payroll/periods/${id}`),
  createPeriod: async (data) => api.post('/payroll/periods', data),
  deletePeriod: async (id) => api.delete(`/payroll/periods/${id}`),
  generateItems: async (id) => api.post(`/payroll/periods/${id}/generate`),
  processPeriod: async (id) => api.put(`/payroll/periods/${id}/process`),
  markPaid: async (id) => api.put(`/payroll/periods/${id}/pay`),

  // Items (payslips)
  updateItem: async (id, data) => api.put(`/payroll/items/${id}`, data),
  deleteItem: async (id) => api.delete(`/payroll/items/${id}`),
  getItemById: async (id) => api.get(`/payroll/items/${id}`),

  // Self-service
  getMyPayslips: async () => api.get('/payroll/my-payslips'),
};

export const hostelService = {
  // Hostels
  getHostels: async (params) => api.get('/hostel/hostels', { params }),
  getHostelById: async (id) => api.get(`/hostel/hostels/${id}`),
  createHostel: async (data) => api.post('/hostel/hostels', data),
  updateHostel: async (id, data) => api.put(`/hostel/hostels/${id}`, data),
  deleteHostel: async (id) => api.delete(`/hostel/hostels/${id}`),

  // Rooms
  getRooms: async (params) => api.get('/hostel/rooms', { params }),
  createRoom: async (data) => api.post('/hostel/rooms', data),
  updateRoom: async (id, data) => api.put(`/hostel/rooms/${id}`, data),
  deleteRoom: async (id) => api.delete(`/hostel/rooms/${id}`),
  getRoomStudents: async (id) => api.get(`/hostel/rooms/${id}/students`),

  // Student allocations
  getStudentAllocation: async (studentId) => api.get(`/hostel/student/${studentId}`),
  assignStudent: async (data) => api.post('/hostel/allocations', data),
  vacateStudent: async (id) => api.put(`/hostel/allocations/${id}/vacate`),
};

export const expenseService = {
  // Categories
  getCategories: async (params) => api.get('/expenses/categories', { params }),
  createCategory: async (data) => api.post('/expenses/categories', data),
  updateCategory: async (id, data) => api.put(`/expenses/categories/${id}`, data),
  deleteCategory: async (id) => api.delete(`/expenses/categories/${id}`),

  // Expenses
  getAll: async (params) => api.get('/expenses', { params }),
  getById: async (id) => api.get(`/expenses/${id}`),
  create: async (data) => api.post('/expenses', data),
  update: async (id, data) => api.put(`/expenses/${id}`, data),
  void: async (id) => api.delete(`/expenses/${id}`),
  uploadReceipt: async (id, file) => {
    const formData = new FormData();
    formData.append('receipt', file);
    return api.post(`/expenses/${id}/receipt`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
  getSummary: async (params) => api.get('/expenses/summary', { params }),
};

export const leaveService = {
  // Types
  getTypes: async (params) => api.get('/leave/types', { params }),
  createType: async (data) => api.post('/leave/types', data),
  updateType: async (id, data) => api.put(`/leave/types/${id}`, data),
  deleteType: async (id) => api.delete(`/leave/types/${id}`),

  // Balances
  getMyBalances: async (year) => api.get('/leave/balances/me', { params: { year } }),
  getUserBalances: async (userId, year) => api.get(`/leave/balances/${userId}`, { params: { year } }),
  adjustBalance: async (id, allocated_days) => api.put(`/leave/balances/${id}`, { allocated_days }),

  // Requests
  createRequest: async (data) => api.post('/leave/requests', data),
  getMyRequests: async (params) => api.get('/leave/requests/me', { params }),
  getPendingApprovals: async () => api.get('/leave/requests/pending-approvals'),
  getAllRequests: async (params) => api.get('/leave/requests', { params }),
  decideRequest: async (id, decision, comment) => api.put(`/leave/requests/${id}/decide`, { decision, comment }),
  cancelRequest: async (id) => api.put(`/leave/requests/${id}/cancel`),
};

export const promotionService = {
  preview: async (params) => api.get('/promotions/preview', { params }),
  run: async (data) => api.post('/promotions/run', data),
  promoteIndividual: async (data) => api.post('/promotions/individual', data),
  revert: async (batchId) => api.post(`/promotions/${batchId}/revert`),
  getHistory: async () => api.get('/promotions'),
  getSections: async (classId) => api.get('/promotions/sections', { params: { class_id: classId } }),
};

export const searchService = {
  search: async (q) => api.get('/search', { params: { q } }),
};

export const subscriptionService = {
  getPlans: async () => api.get('/subscription/plans'),
  getMine: async () => api.get('/subscription/me'),
  getQuote: async (data) => api.post('/subscription/quote', data),
  checkout: async (data) => api.post('/subscription/checkout', data),
  checkStatus: async (reference) => api.get(`/subscription/invoices/${reference}/status`),
  getInvoice: async (reference) => api.get(`/subscription/invoices/${reference}`),
  payInvoice: async (reference, data) => api.post(`/subscription/invoices/${reference}/pay`, data),
  cancelInvoice: async (reference) => api.post(`/subscription/invoices/${reference}/cancel`),
  previewInvoiceCleanup: async () => api.get('/subscription/invoice-cleanup'),
  runInvoiceCleanup: async () => api.post('/subscription/invoice-cleanup'),
  getInvoices: async (params) => api.get('/subscription/invoices', { params }),
  cancel: async () => api.post('/subscription/cancel'),
  // Platform developer
  testGateway: async () => api.post('/subscription/gateway/test'),
  updatePlan: async (id, data) => api.put(`/subscription/plans/${id}`, data),
  getAllTenants: async () => api.get('/subscription/tenants'),
};

export const libraryService = {
  getSettings: async () => api.get('/library/settings'),
  updateSettings: async (data) => api.put('/library/settings', data),
  // Books
  getBooks: async (params) => api.get('/library/books', { params }),
  getBookById: async (id) => api.get(`/library/books/${id}`),
  createBook: async (data) => api.post('/library/books', data),
  updateBook: async (id, data) => api.put(`/library/books/${id}`, data),
  deleteBook: async (id) => api.delete(`/library/books/${id}`),
  getAvailableCopies: async (id) => api.get(`/library/books/${id}/available-copies`),

  // Issue / return
  getIssues: async (params) => api.get('/library/issues', { params }),
  getMyBooks: async () => api.get('/library/my-books'),
  issueBook: async (data) => api.post('/library/issue', data),
  returnBook: async (id, data) => api.put(`/library/issue/${id}/return`, data),
  markLost: async (id, data) => api.put(`/library/issue/${id}/lost`, data),
  settleFine: async (id, data) => api.put(`/library/issue/${id}/fine`, data),
};

export const vehicleService = {
  getAll: async (params) => api.get('/transport/vehicles', { params }),
  getById: async (id) => api.get(`/transport/vehicles/${id}`),
  create: async (data) => api.post('/transport/vehicles', data),
  update: async (id, data) => api.put(`/transport/vehicles/${id}`, data),
  delete: async (id) => api.delete(`/transport/vehicles/${id}`),
  uploadPhoto: async (id, file) => {
    const formData = new FormData();
    formData.append('photo', file);
    return api.post(`/transport/vehicles/${id}/photo`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
  },

  // Maintenance records
  getMaintenanceRecords: async (id, params) => api.get(`/transport/vehicles/${id}/maintenance`, { params }),
  createMaintenanceRecord: async (id, data) => api.post(`/transport/vehicles/${id}/maintenance`, data),
  updateMaintenanceRecord: async (id, recordId, data) => api.put(`/transport/vehicles/${id}/maintenance/${recordId}`, data),
  deleteMaintenanceRecord: async (id, recordId) => api.delete(`/transport/vehicles/${id}/maintenance/${recordId}`),
};

export const transportService = {
  // Routes
  getRoutes: async (params) => api.get('/transport/routes', { params }),
  getRouteById: async (id) => api.get(`/transport/routes/${id}`),
  createRoute: async (data) => api.post('/transport/routes', data),
  updateRoute: async (id, data) => api.put(`/transport/routes/${id}`, data),
  deleteRoute: async (id) => api.delete(`/transport/routes/${id}`),
  getRouteStudents: async (id, params) => api.get(`/transport/routes/${id}/students`, { params }),

  // Student allocations
  getStudentAllocation: async (studentId) => api.get(`/transport/student/${studentId}`),
  assignStudent: async (data) => api.post('/transport/allocations', data),
  updateAllocation: async (id, data) => api.put(`/transport/allocations/${id}`, data),
  removeAllocation: async (id) => api.delete(`/transport/allocations/${id}`),
};

export const timetableService = {
  // Settings (the school week) — one per campus PER education level
  getSettings: async (campus_id, education_level) => api.get('/timetable/settings', { params: { campus_id, education_level } }),
  updateSettings: async (data) => api.put('/timetable/settings', data),

  // Class subjects
  getClassSubjects: async (params) => api.get('/timetable/class-subjects', { params }),
  saveClassSubjects: async (data) => api.put('/timetable/class-subjects', data),

  // Grid — view
  getClassTimetable: async (params) => api.get('/timetable/class', { params }),
  getTeacherTimetable: async (params) => api.get('/timetable/teacher', { params }),
  getMasterTimetable: async (params) => api.get('/timetable/master', { params }),

  // Grid — edit
  upsertEntry: async (data) => api.put('/timetable/entry', data),
  autoFill: async (data) => api.post('/timetable/auto-fill', data),
  clearClassTimetable: async (params) => api.delete('/timetable/class', { params }),
};

// Full-database backup (platform developer only — see backend/src/controllers/backupController.js)
export const backupService = {
  overview: async () => api.get('/backups'),
  updateSettings: async (payload) => api.put('/backups/settings', payload),
  runNow: async () => api.post('/backups/run'),
  verify: async (id) => api.post(`/backups/${id}/verify`),
  download: async (id) => api.get(`/backups/${id}/download`, { responseType: 'blob' }),
  copyToDrive: async (id) => api.post(`/backups/${id}/drive`),
  remove: async (id) => api.delete(`/backups/${id}`),
  saveDriveCredentials: async (payload) => api.put('/backups/drive/credentials', payload),
  driveAuthUrl: async () => api.get('/backups/drive/auth-url'),
  driveTest: async () => api.post('/backups/drive/test'),
  driveDisconnect: async () => api.post('/backups/drive/disconnect'),
};
