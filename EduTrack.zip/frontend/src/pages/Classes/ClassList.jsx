import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { classService, campusService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { Select, Input, DataTable, ConfirmModal, Button, RowActions, ACTION_ICONS, ActionLink } from "../../components/ui";

export default function ClassList() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { currentAcademicYear } = useAcademicYear();

  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [campuses, setCampuses] = useState([]);
  const [selectedClasses, setSelectedClasses] = useState([]);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false, action: null, ids: [] });
  const [filters, setFilters] = usePersistedState("filters", {
    search: "", status: "", campus_id: "", academic_year: "",
    sortBy: "name", sortOrder: "ASC",
  });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 10 });

  // The academic year picked in the header is what the page should show.
  // Without this the list ignored it entirely and returned classes from
  // every year at once, which made the selector look broken.
  useEffect(() => {
    setFilters((f) => (f.academic_year === currentAcademicYear ? f : { ...f, academic_year: currentAcademicYear }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  }, [currentAcademicYear]);

  useEffect(() => {
    fetchCampuses();
  }, []);

  // Held back until the year filter matches the selected year. Both effects
  // run on first mount, and this one used to win the race — so the very
  // first load fetched with an empty year filter and listed every class
  // from every year before the corrected fetch replaced it.
  useEffect(() => {
    if (filters.academic_year !== currentAcademicYear) return;
    fetchClasses();
  }, [filters, pagination.currentPage, currentAcademicYear]);

  const fetchClasses = async () => {
    try {
      setLoading(true);
      const response = await classService.getAll({
        ...filters, page: pagination.currentPage, limit: pagination.itemsPerPage,
      });
      if (response.success) {
        setClasses(response.data);
        setPagination((p) => ({ ...p, ...response.pagination }));
      }
    } catch (err) {
      showError(err.message || "Failed to fetch classes");
    } finally {
      setLoading(false);
    }
  };

  const fetchCampuses = async () => {
    try {
      const response = await campusService.getAll({ limit: 100 });
      if (response.success) setCampuses(response.data);
    } catch {}
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((f) => ({ ...f, [name]: value }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const handleSelectAll = (e) => {
    setSelectedClasses(e.target.checked ? classes.map((c) => c.id) : []);
  };

  const handleSelectOne = (id) => {
    setSelectedClasses((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const handleDelete = (id) => {
    setConfirmModal({ isOpen: true, action: "delete", ids: [id], title: "Deactivate Class", message: "Deactivate this class? Students remain enrolled.", variant: "danger" });
  };

  const handleBulkAction = (status) => {
    if (selectedClasses.length === 0) return;
    setConfirmModal({ isOpen: true, action: "bulk", ids: selectedClasses, status, title: `${status === "active" ? "Activate" : "Deactivate"} Classes`, message: `${status === "active" ? "Activate" : "Deactivate"} ${selectedClasses.length} selected class(es)?`, variant: status === "active" ? "success" : "danger" });
  };

  const handleConfirm = async () => {
    try {
      if (confirmModal.action === "delete") {
        await classService.delete(confirmModal.ids[0]);
        showSuccess("Class deactivated successfully");
      } else if (confirmModal.action === "bulk") {
        await classService.bulkUpdateStatus({ ids: confirmModal.ids, status: confirmModal.status });
        showSuccess(`${confirmModal.ids.length} class(es) updated`);
        setSelectedClasses([]);
      }
      fetchClasses();
    } catch (err) {
      showError(err.message || "Action failed");
    }
    setConfirmModal({ isOpen: false, action: null, ids: [] });
  };

  const handleReactivate = async (id) => {
    try {
      await classService.reactivate(id);
      showSuccess("Class reactivated");
      fetchClasses();
    } catch (err) {
      showError(err.message || "Failed to reactivate");
    }
  };

  const totalClasses = pagination.totalItems;
  const activeCount = classes.filter((c) => c.status === "active").length;
  const inactiveCount = classes.filter((c) => c.status === "inactive").length;
  const totalSections = classes.reduce((sum, c) => sum + (c.sections?.length || 0), 0);

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Classes Management</h1>
            <p className="text-sm text-gray-500 mt-0.5">Manage classes and sections</p>
          </div>
          {can("academics.create") && (
            <ActionLink to="/classes/add" variant="primary">Add Class</ActionLink>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Total Classes</p>
                <p className="text-2xl text-left font-bold text-primary mt-1">{totalClasses}</p>
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Active</p>
                <p className="text-2xl text-left font-bold text-green-600 mt-1">{activeCount}</p>
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg className="w-8 h-8 text-green-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Inactive</p>
                <p className="text-2xl text-left font-bold text-red-600 mt-1">{inactiveCount}</p>
              </div>
              <div className="bg-red-100 p-3 rounded">
                <svg className="w-8 h-8 text-red-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Total Streams</p>
                <p className="text-2xl text-left font-bold text-indigo-600 mt-1">{totalSections}</p>
              </div>
              <div className="bg-indigo-100 p-3 rounded">
                <svg className="w-8 h-8 text-indigo-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-5 rounded shadow">
          <form onSubmit={(e) => { e.preventDefault(); fetchClasses(); }} className="grid grid-cols-2 md:grid-cols-6 gap-4">
            <div className="md:col-span-2">
              <Input
                label="Search"
                name="search"
                value={filters.search}
                onChange={handleFilterChange}
                placeholder="Search by name or grade..."
                leftIcon={
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                }
              />
            </div>
            <div>
              <Select
                label="Status"
                name="status"
                value={filters.status}
                onChange={handleFilterChange}
                options={[
                  { value: "", label: "All Statuses" },
                  { value: "active", label: "Active" },
                  { value: "inactive", label: "Inactive" },
                ]}
              />
            </div>
            <div>
              <Select
                label="Campus"
                name="campus_id"
                value={filters.campus_id}
                onChange={handleFilterChange}
                options={[
                  { value: "", label: "All Campuses" },
                  ...campuses.map((c) => ({ value: c.id, label: c.name })),
                ]}
              />
            </div>
            <div>
              <Input
                label="Academic Year"
                name="academic_year"
                value={filters.academic_year}
                onChange={handleFilterChange}
                placeholder="e.g. 2024-2025"
              />
            </div>
            <div className="flex items-end">
              <button type="submit" className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90">
                Apply Filters
              </button>
            </div>
          </form>
        </div>

        {/* Bulk Actions */}
        {selectedClasses.length > 0 && (can("academics.update") || can("academics.delete")) && (
          <div className="bg-white shadow rounded p-4 px-5 flex flex-wrap items-center justify-between gap-2">
            <div className="flex space-x-2">
              <Button variant="lightSuccess" onClick={() => handleBulkAction("active")}>Activate</Button>
              <Button variant="lightDanger" onClick={() => handleBulkAction("inactive")}>Deactivate</Button>
            </div>
            <span className="text-sm font-medium text-gray-700">
              {selectedClasses.length} class(es) selected
            </span>
          </div>
        )}

        <DataTable
          columns={[
            {
              key: "name",
              label: "Class",
              render: (cls) => (
                <div>
                  <div className="text-sm text-gray-900">{cls.name}</div>
                </div>
              ),
            },
            {
              key: "campus",
              label: "Campus",
              render: (cls) => cls.campus?.name || <span className="text-gray-400">—</span>,
            },
            { key: "academic_year", label: "Academic Year" },
            {
              key: "sections",
              label: "Streams",
              render: (cls) => (
                <span className="text-sm">
                  {cls.sections?.length || 0} stream{cls.sections?.length > 1 ? "s" : ""}
                </span>
              ),
            },
            {
              key: "capacity",
              label: "Capacity",
              render: (cls) => cls.capacity || <span className="text-gray-400">—</span>,
            },
            {
              key: "status",
              label: "Status",
              render: (cls) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold capitalize rounded-full ${cls.status === "active" ? "bg-green-100 border border-green-300 text-green-500" : "bg-red-100 border border-red-300 text-red-600"}`}>
                  {cls.status}
                </span>
              ),
            },
          ]}
          data={classes}
          loading={loading}
          emptyMessage="No classes found"
          selectable={(can("academics.update") || can("academics.delete"))}
          selectedIds={selectedClasses}
          onSelectAll={handleSelectAll}
          onSelectRow={handleSelectOne}
          renderActions={(cls) => {
            return (
              <RowActions
                actions={[
                  { label: "View Details", variant: "primary", icon: ACTION_ICONS.view, hidden: !can("academics.update"), onClick: () => navigate(`/classes/${cls.id}`) },
                  { label: "Edit Class", icon: ACTION_ICONS.edit, hidden: !can("academics.update"), onClick: () => navigate(`/classes/${cls.id}/edit`) },
                  { label: "Reactivate", variant: "success", icon: ACTION_ICONS.check, hidden: !can("academics.update") || cls.status !== "inactive", onClick: () => handleReactivate(cls.id) },
                  { label: "Deactivate", variant: "danger", icon: ACTION_ICONS.remove, hidden: !can("academics.delete") || cls.status === "inactive", onClick: () => handleDelete(cls.id) },
                ]}
              />
            );
          }}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ isOpen: false, action: null, ids: [] })}
        onConfirm={handleConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
      />
    </MainLayout>
  );
}
