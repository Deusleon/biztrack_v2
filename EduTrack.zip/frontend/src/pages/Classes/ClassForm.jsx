import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { classService, campusService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Input, Textarea, Button } from "../../components/ui";
import { academicYearOptions as formatYearOptions, EDUCATION_LEVELS } from "../../utils/academicYear";

export default function ClassForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);
  const { showSuccess, showError } = useToast();

  const [formData, setFormData] = useState({
    campus_id: "", name: "", grade: "", education_level: "o_level", academic_year: "",
    capacity: "", description: "", status: "active",
  });
  const [campuses, setCampuses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  // Academic year options reformat automatically based on education level:
  // Primary & O-Level use a single year ("2025"), A-Level uses a two-year
  // span ("2025-2026") — see src/utils/academicYear.js.
  const academicYearOptions = formatYearOptions(formData.education_level);

  const GRADE_OPTIONS_BY_LEVEL = {
    primary: ["Pre-K", "KG 1", "KG 2", ...Array.from({ length: 6 }, (_, i) => `Standard ${i + 1}`)],
    o_level: ["Form 1", "Form 2", "Form 3", "Form 4"],
    a_level: ["Form 5", "Form 6"],
  };
  const gradeOptions = GRADE_OPTIONS_BY_LEVEL[formData.education_level] || GRADE_OPTIONS_BY_LEVEL.o_level;

  useEffect(() => {
    fetchCampuses();
    if (isEdit) fetchClass();
  }, [id]);

  const fetchCampuses = async () => {
    try {
      const response = await campusService.getAll({ limit: 100 });
      if (response.success) setCampuses(response.data);
    } catch { }
  };

  const fetchClass = async () => {
    try {
      setLoading(true);
      const response = await classService.getById(id);
      if (response.success) {
        const cls = response.data;
        setFormData({
          campus_id: cls.campus_id || "",
          name: cls.name || "",
          grade: cls.grade || "",
          education_level: cls.education_level || "o_level",
          academic_year: cls.academic_year || "",
          capacity: cls.capacity || "",
          description: cls.description || "",
          status: cls.status || "active",
        });
      }
    } catch (err) {
      showError("Failed to load class");
      navigate("/classes");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "education_level") {
      // Grade and Academic Year options both depend on the level — reset
      // them so the admin doesn't end up with a stale "Form 2" under
      // A-Level, or a range-formatted year under Primary.
      setFormData((f) => ({ ...f, education_level: value, grade: "", academic_year: "" }));
      return;
    }
    setFormData((f) => ({ ...f, [name]: value }));
    if (errors[name]) setErrors((e) => ({ ...e, [name]: "" }));
  };

  const validate = () => {
    const errs = {};
    if (!formData.campus_id) errs.campus_id = "Campus is required";
    if (!formData.name.trim()) errs.name = "Class name is required";
    if (!formData.grade) errs.grade = "Grade is required";
    if (!formData.academic_year) errs.academic_year = "Academic year is required";
    if (formData.capacity && (isNaN(formData.capacity) || Number(formData.capacity) < 1)) {
      errs.capacity = "Capacity must be a positive number";
    }
    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }

    try {
      setSubmitting(true);
      const payload = {
        ...formData,
        capacity: formData.capacity ? Number(formData.capacity) : null,
      };
      let response;
      if (isEdit) {
        response = await classService.update(id, payload);
      } else {
        response = await classService.create(payload);
      }
      if (response.success) {
        showSuccess(`Class ${isEdit ? "updated" : "created"} successfully`);
        navigate(isEdit ? `/classes/${id}` : "/classes");
      }
    } catch (err) {
      const apiErrors = err.errors || [];
      if (apiErrors.length > 0) {
        const fieldErrs = {};
        apiErrors.forEach((e) => { fieldErrs[e.field] = e.message; });
        setErrors(fieldErrs);
      } else {
        showError(err.message || "Failed to save class");
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-sm text-gray-600 mt-2">Loading class data...</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4 text-left">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">
              {isEdit ? "Edit Class" : "Add New Class"}
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {isEdit ? "Update class details" : "Create a new class"}
            </p>
          </div>
          <Button
            variant="lightPrimary"
            onClick={() => navigate("/classes")}
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to List
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded shadow text-left">
          <div className="px-5 py-4 space-y-10">
            {/* Class Information */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Class Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Select
                  label="Campus"
                  name="campus_id"
                  value={formData.campus_id}
                  onChange={handleChange}
                  required
                  error={errors.campus_id}
                  options={[
                    { value: "", label: "Select Campus" },
                    ...campuses.map((c) => ({ value: c.id, label: c.name })),
                  ]}
                />
                <Input
                  label="Class Name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  error={errors.name}
                  placeholder="e.g. Class 5A, Form 3"
                />
                <Select
                  label="Education Level"
                  name="education_level"
                  value={formData.education_level}
                  onChange={handleChange}
                  required
                  helperText="Determines the Academic Year format below (single year for Primary/O-Level, e.g. 2025 — a two-year span for A-Level, e.g. 2025-2026)"
                  options={EDUCATION_LEVELS}
                />
                <Select
                  label="Grade"
                  name="grade"
                  value={formData.grade}
                  onChange={handleChange}
                  required
                  error={errors.grade}
                  options={[
                    { value: "", label: "Select Grade" },
                    ...gradeOptions.map((g) => ({ value: g, label: g })),
                  ]}
                />
                <Select
                  label="Academic Year"
                  name="academic_year"
                  value={formData.academic_year}
                  onChange={handleChange}
                  required
                  error={errors.academic_year}
                  options={[
                    { value: "", label: "Select Academic Year" },
                    ...academicYearOptions.map((y) => ({ value: y, label: y })),
                  ]}
                />
                <Input
                  label="Capacity"
                  type="number"
                  name="capacity"
                  min="1"
                  value={formData.capacity}
                  onChange={handleChange}
                  error={errors.capacity}
                  placeholder="Maximum number of students"
                />
                {isEdit && (
                  <Select
                    label="Status"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    options={[
                      { value: "active", label: "Active" },
                      { value: "inactive", label: "Inactive" },
                    ]}
                  />
                )}
                <div className="md:col-span-2">
                  <Textarea
                    label="Description"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    rows={3}
                    placeholder="Optional class description"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Form Footer */}
          <div className="bg-gray-50 px-5 py-4 flex items-center justify-end gap-3 rounded-b">
            <Button type="button" variant="secondary" onClick={() => navigate("/classes")}>Cancel</Button>
            <Button type="submit" loading={submitting}>{isEdit ? "Update Class" : "Create Class"}</Button>
          </div>
        </form>
      </div>
    </MainLayout>
  );
}
