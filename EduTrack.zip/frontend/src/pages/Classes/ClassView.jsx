import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { classService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { ConfirmModal, Input, Button } from "../../components/ui";

export default function ClassView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();

  const [cls, setCls] = useState(null);
  const [stats, setStats] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [loading, setLoading] = useState(true);
  const [confirmModal, setConfirmModal] = useState({
    isOpen: false,
    action: null,
  });

  // Section modal
  const [sectionModal, setSectionModal] = useState({
    isOpen: false,
    section: null,
  });
  const [sectionForm, setSectionForm] = useState({
    name: "",
    class_teacher_id: "",
    capacity: "",
  });
  const [sectionErrors, setSectionErrors] = useState({});
  const [sectionSubmitting, setSectionSubmitting] = useState(false);

  useEffect(() => {
    fetchClass();
    fetchStats();
  }, [id]);

  const fetchClass = async () => {
    try {
      setLoading(true);
      const response = await classService.getById(id);
      if (response.success) setCls(response.data);
      else navigate("/classes");
    } catch {
      navigate("/classes");
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await classService.getStats(id);
      if (response.success) setStats(response.data);
    } catch {}
  };

  const handleDelete = () => {
    setConfirmModal({
      isOpen: true,
      action: "deactivate",
      title: "Deactivate Class",
      message: "Deactivate this class? This action can be reversed.",
      variant: "danger",
    });
  };

  const handleConfirm = async () => {
    try {
      if (confirmModal.action === "deactivate") {
        await classService.delete(id);
        showSuccess("Class deactivated");
        navigate("/classes");
      } else if (confirmModal.action === "reactivate") {
        await classService.reactivate(id);
        showSuccess("Class reactivated");
        fetchClass();
      }
    } catch (err) {
      showError(err.message || "Action failed");
    }
    setConfirmModal({ isOpen: false, action: null });
  };

  const openAddSection = () => {
    setSectionForm({ name: "", class_teacher_id: "", capacity: "" });
    setSectionErrors({});
    setSectionModal({ isOpen: true, section: null });
  };

  const openEditSection = (section) => {
    setSectionForm({
      name: section.name || "",
      class_teacher_id: section.class_teacher_id || "",
      capacity: section.capacity != null ? String(section.capacity) : "",
    });
    setSectionErrors({});
    setSectionModal({ isOpen: true, section });
  };

  const handleSectionSubmit = async (e) => {
    e.preventDefault();
    if (!sectionForm.name.trim()) {
      setSectionErrors({ name: "Stream name is required" });
      return;
    }
    try {
      setSectionSubmitting(true);
      if (sectionModal.section) {
        await classService.updateSection(
          id,
          sectionModal.section.id,
          sectionForm,
        );
        showSuccess("Section updated");
      } else {
        await classService.addSection(id, sectionForm);
        showSuccess("Section added");
      }
      setSectionModal({ isOpen: false, section: null });
      fetchClass();
    } catch (err) {
      showError(err.message || "Failed to save section");
    } finally {
      setSectionSubmitting(false);
    }
  };

  const handleDeleteSection = async (sectionId) => {
    try {
      await classService.deleteSection(id, sectionId);
      showSuccess("Stream removed");
      fetchClass();
    } catch (err) {
      showError(err.message || "Failed to remove section");
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-sm text-gray-500 mt-2">Loading class...</p>
        </div>
      </MainLayout>
    );
  }

  if (!cls) return null;


  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Class Details</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {cls.name} - {cls.academic_year}
            </p>
          </div>
          <Button
            variant="lightPrimary"
            onClick={() => navigate("/classes")}
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }
          >
            Back to List
          </Button>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">
                    Total Streams
                  </p>
                  <p className="text-2xl text-left font-bold text-indigo-600 mt-1">
                    {stats.total_sections ?? "—"}
                  </p>
                </div>
                <div className="bg-indigo-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-indigo-600 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 6h16M4 10h16M4 14h16M4 18h16"
                    />
                  </svg>
                </div>
              </div>
            </div>
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">
                    Active Streams
                  </p>
                  <p className="text-2xl text-left font-bold text-green-600 mt-1">
                    {stats.active_sections ?? "—"}
                  </p>
                </div>
                <div className="bg-green-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-green-600 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
              </div>
            </div>
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">
                    Total Students
                  </p>
                  <p className="text-2xl text-left font-bold text-primary mt-1">
                    {stats.total_students ?? "—"}
                  </p>
                </div>
                <div className="bg-primary-15 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-primary opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                    />
                  </svg>
                </div>
              </div>
            </div>
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">
                    Occupancy Rate
                  </p>
                  <p className="text-2xl text-left font-bold text-amber-600 mt-1">
                    {stats.occupancy_rate != null
                      ? `${Math.round(stats.occupancy_rate)}%`
                      : "—"}
                  </p>
                </div>
                <div className="bg-amber-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-amber-600 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        {(can("academics.update") || can("academics.delete")) && (
          <div className="flex items-center gap-3">
            {can("academics.update") && <Button variant="lightPrimary" onClick={() => navigate(`/classes/${id}/edit`)}>
              Edit Class
            </Button>}
            {cls.status === "inactive" ? (can("academics.update") ? (
              <Button
                variant="lightSuccess"
                onClick={() =>
                  setConfirmModal({
                    isOpen: true,
                    action: "reactivate",
                    title: "Reactivate Class",
                    message: "Reactivate this class?",
                    variant: "success",
                  })
                }
              >
                Reactivate
              </Button>
            ) : null) : (can("academics.delete") ? (
              <Button variant="lightDanger" onClick={handleDelete}>
                Deactivate
              </Button>
            ) : null)}
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded shadow">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {["overview", "streams", "statistics"].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-5 py-3 text-sm font-medium capitalize border-b-2 transition-colors ${activeTab === tab ? "border-primary text-primary" : "border-transparent text-gray-500 hover:text-gray-700"}`}
                >
                  {tab}
                </button>
              ))}
            </nav>
          </div>

          <div className="px-5 py-4 text-left">
            {/* Overview Tab */}
            {activeTab === "overview" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Class Information
                    </h3>
                    <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                      <p className="text-xs text-gray-500">Class Name</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900">{cls.name}</p>
                      <p className="text-xs text-gray-500">Grade</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900">{cls.grade}</p>
                      <p className="text-xs text-gray-500">Education Level</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900 capitalize">
                        {cls.education_level ? cls.education_level.replace("_", "-") : "O-Level"}
                      </p>
                      <p className="text-xs text-gray-500">Academic Year</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900">
                        {cls.academic_year}
                      </p>
                      <p className="text-xs text-gray-500">Capacity</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900">
                        {cls.capacity || "Not set"}
                      </p>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Campus & Status
                    </h3>
                    <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                      <p className="text-xs text-gray-500">Campus</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900">
                        {cls.campus?.name || "—"}
                      </p>
                      <p className="text-xs text-gray-500">Status</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900 capitalize">
                        {cls.status}
                      </p>
                      <p className="text-xs text-gray-500">Created</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900">
                        {formatDate(cls.createdAt)}
                      </p>
                    </div>
                  </div>
                </div>
                {cls.description && (
                  <div>
                    <h3 className="text-sm text-left font-semibold text-gray-700 pb-2 border-b border-gray-100">
                      Description
                    </h3>
                    <p className="text-sm text-gray-600 rounded py-1.5">
                      {cls.description}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Streams Tab */}
            {activeTab === "streams" && (
              <div className="">
                <div className="grid grid-cols-1 gap-5">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-gray-100">
                    <h3 className="text-sm text-left font-semibold text-gray-700">
                      Streams ({cls.sections?.length || 0})
                    </h3>
                    {can("academics.create") && (
                      <Button variant="lightPrimary" size="sm" onClick={openAddSection}>
                        Add Stream
                      </Button>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-5">
                  {cls.sections?.length === 0 ? (
                    <div className="text-center py-10">
                      <p className="text-gray-500 text-sm">No streams yet</p>
                    </div>
                  ) : (
                    <div className="">
                      {cls.sections.map((section) => (
                        <div
                          key={section.id}
                          className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 py-1.5"
                        >
                          <div className="w-[90%] grid sm:grid-cols-4 items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                            <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3">
                              <p className="text-xs text-gray-500">Name</p>
                              <p>:</p>
                              <p className="text-sm text-gray-900">
                                {section.name}
                              </p>
                            </div>
                            <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3">
                              <p className="text-xs text-gray-500">
                                Class Teacher{" "}
                              </p>
                              <p>:</p>
                              {section.class_teacher ? (
                                <p className="text-sm text-gray-900">
                                  {section.class_teacher?.first_name}{" "}
                                  {section.class_teacher?.last_name}
                                </p>
                              ) : (
                                <p className="text-sm text-gray-900">N/A</p>
                              )}
                            </div>
                            <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3">
                              <p className="text-xs text-gray-500">Capacity</p>
                              <p>:</p>
                              <p className="text-sm text-gray-900">
                                {section.capacity ?? "N/A"}
                              </p>
                            </div>
                            <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3">
                              <p className="text-xs text-gray-500">Available</p>
                              <p>:</p>
                              <p className="text-sm text-gray-900">
                                {section.capacity - (section.students?.length ?? 0)}
                              </p>
                            </div>
                          </div>
                          {(can("academics.update") || can("academics.delete")) && (
                            <div className="flex gap-3">
                              {can("academics.update") && <Button
                                variant="lightPrimary"
                                size="xs"
                                onClick={() => openEditSection(section)}
                              >
                                Edit
                              </Button>}
                              {can("academics.delete") && <Button
                                size="xs"
                                variant="lightDanger"
                                onClick={() => handleDeleteSection(section.id)}
                              >
                                Remove
                              </Button>}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Statistics Tab */}
            {activeTab === "statistics" && (
              <div>
                {stats ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {[
                      { label: "Total Streams", value: stats.total_sections },
                      { label: "Active Streams", value: stats.active_sections },
                      { label: "Total Students", value: stats.total_students },
                      {
                        label: "Active Students",
                        value: stats.active_students,
                      },
                      { label: "Capacity", value: stats.capacity || "—" },
                      {
                        label: "Occupancy Rate",
                        value:
                          stats.occupancy_rate != null
                            ? `${Math.round(stats.occupancy_rate)}%`
                            : "—",
                      },
                    ].map((s) => (
                      <div key={s.label} className="bg-gray-50 rounded p-4">
                        <p className="text-xs text-gray-500 mb-1">{s.label}</p>
                        <p className="text-xl font-bold text-gray-900">
                          {s.value}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">
                    No statistics available
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Confirm Modal */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ isOpen: false, action: null })}
        onConfirm={handleConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
      />

      {/* Section Modal */}
      {sectionModal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">
                {sectionModal.section ? "Edit Stream" : "Add Stream"}
              </h3>
              <button
                onClick={() =>
                  setSectionModal({ isOpen: false, section: null })
                }
                className="text-gray-400 hover:text-gray-600"
              >
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
            <form
              onSubmit={handleSectionSubmit}
              className="px-5 py-4 space-y-6"
            >
              <div>
                <Input
                  label="Stream Name"
                  value={sectionForm.name}
                  onChange={(e) =>
                    setSectionForm((f) => ({ ...f, name: e.target.value }))
                  }
                  required
                  placeholder="e.g. A, B, East, West"
                />
                {sectionErrors.name && (
                  <p className="text-red-500 text-xs mt-1">
                    {sectionErrors.name}
                  </p>
                )}
              </div>
              <div>
                <Input
                  label="Capacity (max students)"
                  type="number"
                  min="1"
                  value={sectionForm.capacity}
                  onChange={(e) =>
                    setSectionForm((f) => ({ ...f, capacity: e.target.value }))
                  }
                  placeholder="e.g. 40"
                />
              </div>
              <div className="flex gap-3">
                <Button type="submit" loading={sectionSubmitting}>
                  {sectionModal.section ? "Update Stream" : "Add Stream"}
                </Button>
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() =>
                    setSectionModal({ isOpen: false, section: null })
                  }
                >
                  Cancel
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </MainLayout>
  );
}
