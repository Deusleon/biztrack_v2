export { PrivacyPolicy, TermsOfService } from "./LegalPage";
