import { Link } from "react-router-dom";
import MainLayout from "../../components/MainLayout";
import DocContent, { Inline } from "../../components/docs/DocContent";
import { useAuth } from "../../contexts/AuthContext";
import { LEGAL_LAST_UPDATED } from "../../constants/company";
import { privacyPolicy, termsOfService } from "../../content/legal";
import BrandMark from "../../components/BrandMark";

/** The page itself — shared by Privacy and Terms. */
function LegalDocument({ doc }) {
  return (
    <article className="bg-white rounded shadow p-5 md:p-8 max-w-4xl mx-auto text-left">
      <h1 className="text-2xl font-bold text-gray-900">{doc.title}</h1>
      <p className="text-xs text-gray-500 mt-1">Last updated: {LEGAL_LAST_UPDATED}</p>
      <p className="text-sm text-gray-700 leading-relaxed mt-4"><Inline text={doc.intro} /></p>

      <div className="mt-5 bg-gray-50 border border-gray-200 rounded px-4 py-3">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Contents</p>
        <ul className="text-sm space-y-0.5">
          {doc.sections.map((s) => <li key={s.id}><a href={`#${s.id}`} className="text-primary hover:underline">{s.heading}</a></li>)}
        </ul>
      </div>

      <div className="mt-8"><DocContent sections={doc.sections} /></div>

      <p className="mt-10 pt-4 border-t border-gray-100 text-sm text-gray-500">
        See also: <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link> ·{" "}
        <Link to="/terms" className="text-primary hover:underline">Terms of Service</Link>
      </p>
    </article>
  );
}

/** Signed-in people read these inside the app; everyone else (a parent opening
 * the link from the sign-in page, say) gets a plain page with no app menu. */
function LegalShell({ children }) {
  const { isAuthenticated } = useAuth();
  if (isAuthenticated) return <MainLayout>{children}</MainLayout>;
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="gradient-primary-dark px-4 py-4">
        <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <Link to="/login" className="text-white font-bold text-lg tracking-tight flex items-center gap-2"><BrandMark className="w-9 h-auto" />EduTrack</Link>
          <Link to="/login" className="text-sm text-white opacity-90 hover:opacity-100 underline">Sign in</Link>
        </div>
      </header>
      <main className="flex-1 px-4 py-6">{children}</main>
      <footer className="py-4 text-center text-xs text-gray-500">
        <Link to="/privacy" className="hover:text-primary">Privacy</Link> · <Link to="/terms" className="hover:text-primary">Terms</Link>
      </footer>
    </div>
  );
}

export function PrivacyPolicy() {
  return <LegalShell><LegalDocument doc={privacyPolicy()} /></LegalShell>;
}

export function TermsOfService() {
  return <LegalShell><LegalDocument doc={termsOfService()} /></LegalShell>;
}
