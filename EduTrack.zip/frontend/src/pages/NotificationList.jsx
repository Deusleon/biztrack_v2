import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../contexts/ToastContext";
import { usePreferences } from "../contexts/PreferencesContext";
import { notificationService } from "../services/api";
import MainLayout from "../components/MainLayout";
import { Button } from "../components/ui";
import Icon from "../components/ui/Icon";

const TYPE_STYLES = {
  info: "bg-primary-15 text-primary",
  success: "bg-green-100 text-green-600",
  warning: "bg-yellow-100 text-yellow-600",
  error: "bg-red-100 text-red-600",
  announcement: "bg-purple-100 text-purple-600",
};

export default function NotificationList() {
  const navigate = useNavigate();
  const { showError } = useToast();
  const { formatDateTime } = usePreferences();

  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [pagination, setPagination] = useState({ currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 20 });

  useEffect(() => { load(); }, [unreadOnly, pagination.currentPage]);

  const load = async () => {
    try {
      setLoading(true);
      const res = await notificationService.getMyNotifications({
        page: pagination.currentPage, limit: pagination.itemsPerPage, unread_only: unreadOnly ? "true" : "",
      });
      if (res.success) {
        setNotifications(res.data);
        setPagination((p) => ({ ...p, ...res.pagination }));
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const handleClick = async (n) => {
    if (!n.is_read) {
      try { await notificationService.markAsRead(n.id); setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, is_read: true } : x))); } catch { /* ignore */ }
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await notificationService.markAllAsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
    } catch (err) { showError(err.response?.data?.message || err.message); }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Notifications</h1>
            <p className="text-sm text-gray-500 mt-0.5">Everything the system has alerted you about</p>
          </div>
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
              <input type="checkbox" checked={unreadOnly} onChange={(e) => { setUnreadOnly(e.target.checked); setPagination((p) => ({ ...p, currentPage: 1 })); }} className="accent-primary" />
              Unread only
            </label>
            <Button variant="secondary" onClick={handleMarkAllRead}>Mark all as read</Button>
          </div>
        </div>

        <div className="bg-white rounded shadow divide-y divide-gray-100">
          {loading ? (
            <div className="p-10 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
          ) : notifications.length === 0 ? (
            <div className="p-10 text-center text-gray-400 text-sm">No notifications{unreadOnly ? " — you're all caught up." : " yet."}</div>
          ) : (
            notifications.map((n) => (
              <button
                key={n.id}
                onClick={() => handleClick(n)}
                className={`w-full text-left flex items-start gap-3 px-5 py-4 hover:bg-gray-50 transition-colors ${!n.is_read ? "bg-primary-5" : ""}`}
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${TYPE_STYLES[n.type] || TYPE_STYLES.info}`}>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`text-sm ${!n.is_read ? "font-semibold text-gray-900" : "text-gray-700"}`}>{n.title}</p>
                  <p className="text-sm text-gray-500 mt-0.5">{n.message}</p>
                  <p className="text-xs text-gray-400 mt-1">{formatDateTime(n.createdAt)}</p>
                </div>
                {!n.is_read && <span className="w-2.5 h-2.5 bg-primary rounded-full flex-shrink-0 mt-1.5" />}
              </button>
            ))
          )}
        </div>

        {pagination.totalPages > 1 && (
          <div className="flex items-center justify-center gap-2">
            <Button variant="secondary" size="sm" disabled={pagination.currentPage <= 1} onClick={() => setPagination((p) => ({ ...p, currentPage: p.currentPage - 1 }))}>Previous</Button>
            <span className="text-sm text-gray-500">Page {pagination.currentPage} of {pagination.totalPages}</span>
            <Button variant="secondary" size="sm" disabled={pagination.currentPage >= pagination.totalPages} onClick={() => setPagination((p) => ({ ...p, currentPage: p.currentPage + 1 }))}>Next</Button>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
