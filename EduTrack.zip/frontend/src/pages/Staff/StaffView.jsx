// frontend/src/pages/Staff/StaffView.jsx
import { useState, useEffect, useRef, Fragment } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { staffService, timetableService, leaveService } from "../../services/api";
import { useCampus } from "../../contexts/CampusContext";
import { exportStaffProfilePDF } from "../../utils/staffExport";
import MainLayout from "../../components/MainLayout";
import { ConfirmModal, Button, DataTable, Select, Input, RowActions, ACTION_ICONS } from "../../components/ui";
import { formatNumber } from "../../utils/money";
import Icon from "../../components/ui/Icon";

const DOCUMENT_TYPES = [
  { value: "id_copy", label: "National ID Copy" },
  { value: "appointment_letter", label: "Appointment Letter" },
  { value: "contract", label: "Employment Contract" },
  { value: "certificate", label: "Academic Certificate" },
  { value: "cv", label: "CV / Resume" },
  { value: "other", label: "Other" },
];

const DOCUMENT_TYPE_LABELS = Object.fromEntries(DOCUMENT_TYPES.map((d) => [d.value, d.label]));

const LEAVE_STATUS_STYLES = {
  pending: "bg-amber-100 border border-amber-300 text-amber-600",
  approved: "bg-green-100 border border-green-300 text-green-500",
  rejected: "bg-red-100 border border-red-300 text-red-500",
  cancelled: "bg-gray-100 border border-gray-300 text-gray-500",
};

export default function StaffView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { currentCampus } = useCampus();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();
  const { currentAcademicYear } = useAcademicYear();
  // Leave balances are keyed on a plain calendar year.
  const leaveYear = parseInt(String(currentAcademicYear || '').match(/\d{4}/)?.[0], 10) || new Date().getFullYear();
  useEffect(() => { setLeaveData(null); }, [leaveYear]);
  const [staff, setStaff] = useState(null);
  const [stats, setStats] = useState(null);
  const [staffTimetable, setStaffTimetable] = useState(null);
  const [timetableLoading, setTimetableLoading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [leaveData, setLeaveData] = useState(null);
  const [leaveLoading, setLeaveLoading] = useState(false);
  const [uploadingDoc, setUploadingDoc] = useState(false);
  const [docMeta, setDocMeta] = useState({ name: "", type: "id_copy" });
  const docInputRef = useRef(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const photoInputRef = useRef(null);
  const [confirmModal, setConfirmModal] = useState({
    isOpen: false,
    action: null,
  });

  useEffect(() => {
    fetchStaffData();
  }, [id]);

  const fetchStaffData = async () => {
    try {
      setLoading(true);
      const [staffResponse, statsResponse] = await Promise.all([
        staffService.getById(id),
        staffService.getStats(id),
      ]);
      if (staffResponse.success) setStaff(staffResponse.data);
      if (statsResponse.success) setStats(statsResponse.data);
    } catch (err) {
      showError(err.message || "Failed to fetch staff data");
    } finally {
      setLoading(false);
    }
  };

  const handlePhotoChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      showError('Please choose a JPG, PNG, or WEBP image');
      if (photoInputRef.current) photoInputRef.current.value = '';
      return;
    }
    try {
      setUploadingPhoto(true);
      const response = await staffService.uploadPhoto(id, file);
      if (response.success) {
        setStaff((prev) => ({ ...prev, user: { ...prev.user, avatar: response.data.avatar } }));
        showSuccess('Photo imesasishwa (updated)');
      }
    } catch (err) {
      showError(err.message || 'Failed to upload photo');
    } finally {
      setUploadingPhoto(false);
      if (photoInputRef.current) photoInputRef.current.value = '';
    }
  };

  const handlePrintProfile = async () => {
    try {
      await exportStaffProfilePDF({ school: currentCampus, staff });
    } catch (err) {
      showError('Failed to generate the PDF. Please try again.');
    }
  };

  const handleDelete = () => {
    setConfirmModal({
      isOpen: true,
      action: "delete",
      title: "Deactivate Staff Member",
      message:
        "Are you sure you want to deactivate this staff member? This action can be reversed later.",
      variant: "danger",
    });
  };

  const confirmDelete = async () => {
    try {
      const response = await staffService.delete(id);
      if (response.success) {
        showSuccess("Staff member deactivated successfully");
        navigate("/staff");
      }
    } catch (err) {
      showError(err.message || "Failed to deactivate staff member");
    }
  };

  const handleConfirm = async () => {
    const { action, documentId } = confirmModal;
    setConfirmModal({ isOpen: false, action: null });
    if (action === "delete") return confirmDelete();
    if (action === "delete_document") return deleteDocument(documentId);
  };

  const handleReactivate = async () => {
    try {
      const response = await staffService.reactivate(id);
      if (response.success) {
        showSuccess("Staff member reactivated successfully");
        fetchStaffData();
      }
    } catch (err) {
      showError(err.message || "Failed to reactivate staff member");
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-sm text-gray-600 mt-2">Loading staff data...</p>
        </div>
      </MainLayout>
    );
  }

  if (!staff) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <p className="text-gray-600">Staff member not found</p>
          <Button variant="primary" onClick={() => navigate("/staff")}>Back to List</Button>
        </div>
      </MainLayout>
    );
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "active":
        return "bg-green-100 border border-green-300 text-green-500";
      case "on_leave":
        return "bg-amber-100 border border-amber-300 text-amber-600";
      case "terminated":
        return "bg-gray-100 border border-gray-300 text-gray-500";
      default:
        return "bg-red-100 border border-red-300 text-red-500";
    }
  };

  const tabs = [
    { key: "overview", label: "Overview" },
    { key: "employment", label: "Employment" },
    { key: "statistics", label: "Statistics" },
    { key: "timetable", label: "Timetable" },
    { key: "leave", label: "Leave" },
    { key: "documents", label: "Documents" },
  ];

  const handleDocumentSelect = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      setUploadingDoc(true);
      const res = await staffService.uploadDocument(staff.id, file, docMeta);
      if (res.success) {
        showSuccess("Document uploaded");
        setDocMeta({ name: "", type: "id_copy" });
        fetchStaffData();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || "Failed to upload document");
    } finally {
      setUploadingDoc(false);
    }
  };

  const handleDocumentDelete = (doc) => {
    setConfirmModal({
      isOpen: true,
      action: "delete_document",
      documentId: doc.id,
      title: "Remove Document",
      message: `Remove "${doc.name}" from this staff member's file? This cannot be undone.`,
      variant: "danger",
    });
  };

  const deleteDocument = async (documentId) => {
    try {
      const res = await staffService.deleteDocument(staff.id, documentId);
      if (res.success) {
        showSuccess("Document removed");
        fetchStaffData();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || "Failed to remove document");
    }
  };

  const loadStaffLeave = async () => {
    if (!staff?.user?.id || leaveData) return;
    try {
      setLeaveLoading(true);
      const [balancesRes, requestsRes] = await Promise.all([
        leaveService.getUserBalances(staff.user.id, leaveYear),
        leaveService.getAllRequests({ user_id: staff.user.id, year: leaveYear, limit: 20 }),
      ]);
      setLeaveData({
        balances: balancesRes?.success ? balancesRes.data : [],
        requests: requestsRes?.success ? (requestsRes.data?.requests || requestsRes.data || []) : [],
      });
    } catch {
      setLeaveData({ balances: [], requests: [] });
    } finally {
      setLeaveLoading(false);
    }
  };

  const loadStaffTimetable = async () => {
    if (!staff?.user?.id || staffTimetable) return;
    try {
      setTimetableLoading(true);
      const res = await timetableService.getTeacherTimetable({ teacher_id: staff.user.id, academic_year: currentAcademicYear });
      if (res.success) setStaffTimetable(res.data);
    } catch { }
    finally { setTimetableLoading(false); }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-lg font-bold text-gray-900">
              View Staff Details
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {staff.user?.first_name} {staff.user?.last_name} &mdash;{" "}
              {staff.designation || staff.user?.role?.replace("_", " ")}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={handlePrintProfile}
              variant="lightPrimary"
              leftIcon={
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
                </svg>
              }>Print Profile
            </Button>
            <Button
              onClick={() => navigate("/staff")}
              variant="lightPrimary"
              className="animate-pulse"
              leftIcon={
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 19l-7-7m0 0l7-7m-7 7h18"
                  />
                </svg>
              }>Back to List
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-gray-600">Years of Service</p>
                  <p className="text-2xl text-left font-bold text-gray-900 mt-1">
                    {stats.years_of_service ?? "—"}
                  </p>
                </div>
                <div className="bg-primary-15 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-primary opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                    />
                  </svg>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-gray-600">Experience</p>
                  <p className="text-2xl text-left font-bold text-gray-900 mt-1">
                    {staff.experience_years != null
                      ? `${staff.experience_years} yrs`
                      : "—"}
                  </p>
                </div>
                <div className="bg-indigo-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-indigo-500 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                    />
                  </svg>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-gray-600">Contract Type</p>
                  <p className="text-lg text-left font-bold text-gray-900 mt-1 capitalize">
                    {staff.contract_type?.replace("_", " ") || "—"}
                  </p>
                </div>
                <div className="bg-green-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-green-600 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    />
                  </svg>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">Status</p>
                  <span
                    className={`mt-1 px-3 py-0.5 capitalize rounded-full text-sm font-semibold inline-block ${getStatusColor(staff.status)}`}
                  >
                    {staff.status?.replace("_", " ")}
                  </span>
                </div>
                <div className="bg-yellow-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-yellow-600 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        {(can("staff.update") || can("staff.delete")) && (
          <div className="flex items-center gap-3">
            {can("staff.update") && <Button variant="lightPrimary" onClick={() => navigate(`/staff/${staff.id}/edit`)}>
              Edit Staff
            </Button>}
            {staff.status !== "active" ? (can("staff.update") ? (
              <Button variant="lightSuccess" onClick={handleReactivate}>
                Reactivate
              </Button>
            ) : null) : (can("staff.delete") ? (
              <Button variant="lightDanger" onClick={handleDelete}>
                Deactivate
              </Button>
            ) : null)}
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded shadow">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {tabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`px-5 py-3 border-b-2 font-medium text-sm transition-colors ${activeTab === tab.key
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                    }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="px-5 py-4 text-left">
            {/* Overview Tab */}
            {activeTab === "overview" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Profile picture — first column, left-aligned (not
                      centered) so it lines up with the labels in the two
                      columns beside it. Click to change if you can manage
                      staff. */}
                  <div className="flex flex-col items-start text-left gap-3">
                    <div className={`relative group ${staff.user?.avatar ? "" : "w-3/4"}`}>
                      {staff.user?.avatar ? (
                        <img src={staff.user.avatar} alt="" className="w-86 h-96 rounded object-cover border border-gray-200" />
                      ) : (
                        <div className="w-86 h-96 rounded bg-primary-15 text-primary flex items-center justify-center text-3xl font-bold border border-gray-200">
                          {(staff.user?.first_name?.[0] || '') + (staff.user?.last_name?.[0] || '')}
                        </div>
                      )}
                      {can("staff.update") && (
                        <button
                          onClick={() => photoInputRef.current?.click()}
                          disabled={uploadingPhoto}
                          title="Change photo"
                          className="absolute bottom-1 right-1 bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center text-sm shadow hover:opacity-90 disabled:opacity-50"
                        >
                          {uploadingPhoto ? "…" : "✎"}
                        </button>
                      )}
                      <input ref={photoInputRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handlePhotoChange} />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Personal Information
                    </h3>
                    <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                      {[
                        { label: "Full Name", value: [staff.user?.first_name, staff.user?.middle_name, staff.user?.last_name].filter(Boolean).join(" ") },
                        { label: "Email", value: staff.user?.email },
                        { label: "Phone", value: staff.user?.phone },
                        { label: "Role", value: staff.user?.role?.replace("_", " "), capitalize: true },
                        { label: "Date of Birth", value: staff.date_of_birth ? formatDate(staff.date_of_birth) : null },
                        { label: "Gender", value: staff.gender, capitalize: true },
                        { label: "Marital Status", value: staff.marital_status, capitalize: true },
                        { label: "National ID", value: staff.national_id },
                      ].map((row) => (
                        <Fragment key={row.label}>
                          <p className="text-xs text-gray-500">{row.label}</p>
                          <p>:</p>
                          <p className={`text-sm ${row.value ? "text-gray-900" : "text-gray-300"} ${row.capitalize ? "capitalize" : ""}`}>
                            {row.value || "Not recorded"}
                          </p>
                        </Fragment>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Campus &amp; Department
                    </h3>
                    <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                      {[
                        { label: "Campus", value: staff.campus?.name },
                        { label: "Employee No.", value: staff.employee_number },
                        { label: "Department", value: staff.department },
                        { label: "Designation", value: staff.designation },
                        { label: "Reports To", value: staff.reportsTo ? `${staff.reportsTo.first_name} ${staff.reportsTo.last_name}` : null },
                      ].map((row) => (
                        <Fragment key={row.label}>
                          <p className="text-xs text-gray-500">{row.label}</p>
                          <p>:</p>
                          <p className={`text-sm font-medium ${row.value ? "text-gray-900" : "text-gray-300"}`}>
                            {row.value || "Not recorded"}
                          </p>
                        </Fragment>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4 border-t border-gray-100">
                  <div>
                  </div>
                  <div>
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3">Address</h3>
                    {staff.address || staff.city || staff.country ? (
                      <div className="space-y-1 text-left">
                        {staff.address && <p className="text-sm text-gray-700">{staff.address}</p>}
                        <p className="text-sm text-gray-700">
                          {[staff.city, staff.country].filter(Boolean).join(", ")}
                        </p>
                      </div>
                    ) : (
                      <p className="text-sm text-left text-gray-300">No address recorded</p>
                    )}
                  </div>

                  <div>
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3">Emergency Contact</h3>
                    {staff.emergency_contact || staff.emergency_contact_name ? (
                      <div className="text-left">
                        <p className="text-sm font-medium text-gray-900">
                          {staff.emergency_contact_name || "Name not recorded"}
                          {staff.emergency_contact_relation && (
                            <span className="text-gray-400 font-normal"> — {staff.emergency_contact_relation}</span>
                          )}
                        </p>
                        <p className="text-sm text-gray-700 mt-0.5">
                          {staff.emergency_contact || "No phone number"}
                        </p>
                      </div>
                    ) : (
                      <p className="text-sm text-left text-gray-300">No emergency contact recorded</p>
                    )}
                  </div>
                </div>

                {staff.notes && (
                  <div className="pt-4 border-t border-gray-100 text-left">
                    <h3 className="text-sm font-semibold text-gray-700 mb-2">Notes</h3>
                    <p className="text-sm text-gray-700 whitespace-pre-wrap">{staff.notes}</p>
                  </div>
                )}
              </div>
            )}

            {/* Employment Tab */}
            {activeTab === "employment" && (
              <div className="flex flex-col gap-6 md:flex-row">
                <div className="w-full md:w-1/2 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <h3 className="text-sm font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Employment Information
                    </h3>
                    <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                      <p className="text-xs text-gray-500">Employee Number</p>
                      <p className="">:</p>
                      <p className="text-sm font-medium text-gray-900">
                        {staff.employee_number}
                      </p>

                      <p className="text-xs text-gray-500">Contract Type</p>
                      <p className="">:</p>
                      <p className="text-sm font-medium text-gray-900 capitalize">
                        {staff.contract_type?.replace("_", " ")}
                      </p>

                      {staff.salary != null && (
                        <>
                          <p className="text-xs text-gray-500">Salary</p>
                          <p className="">:</p>
                          <p className="text-sm font-medium text-gray-900">
                            {formatNumber(staff.salary)}
                          </p>
                        </>
                      )}

                      {staff.joining_date && (
                        <>
                          <p className="text-xs text-gray-500">Joining Date</p>
                          <p className="">:</p>
                          <p className="text-sm font-medium text-gray-900">
                            {formatDate(staff.joining_date)}
                          </p>
                        </>
                      )}

                      {staff.experience_years != null && (
                        <>
                          <p className="text-xs text-gray-500">Experience</p>
                          <p className="">:</p>
                          <p className="text-sm font-medium text-gray-900">
                            {staff.experience_years} years
                          </p>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {staff.qualifications &&
                  Array.isArray(staff.qualifications) &&
                  staff.qualifications.length > 0 && (
                    <div className="pt-4 border-t border-gray-100">
                      <h3 className="text-sm font-semibold text-gray-900 mb-3">
                        Qualifications
                      </h3>
                      <ul className="list-disc list-inside space-y-1">
                        {staff.qualifications.map((q, i) => (
                          <li key={i} className="text-sm text-gray-700">
                            {typeof q === "string" ? q : JSON.stringify(q)}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                <div className="w-full md:w-1/2 md:ms-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <h3 className="text-sm font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Payroll &amp; Statutory
                    </h3>
                    <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                      {[
                        { label: "TIN Number", value: staff.tin_number },
                        { label: "NSSF Number", value: staff.nssf_number },
                        { label: "Bank", value: staff.bank_name },
                        { label: "Account Number", value: staff.bank_account_number },
                        { label: "Contract Ends", value: staff.contract_end_date ? formatDate(staff.contract_end_date) : null },
                      ].map((row) => (
                        <Fragment key={row.label}>
                          <p className="text-xs text-gray-500">{row.label}</p>
                          <p>:</p>
                          <p className={`text-sm ${row.value ? "text-gray-900" : "text-gray-300"}`}>
                            {row.value || "Not recorded"}
                          </p>
                        </Fragment>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Timetable Tab */}
            {activeTab === "timetable" && (() => {
              if (!staffTimetable && !timetableLoading) loadStaffTimetable();
              const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
              const DAY_LABELS = { monday: 'Mon', tuesday: 'Tue', wednesday: 'Wed', thursday: 'Thu', friday: 'Fri' };
              const entries = staffTimetable || [];
              const periods = [...new Set(entries.map((e) => e.period_number))].sort((a, b) => a - b);
              const totalClasses = new Set(entries.map((e) => e.class_id)).size;
              const totalSubjects = new Set(entries.map((e) => e.subject_id)).size;
              return (
                <div className="space-y-4">
                  {timetableLoading ? (
                    <div className="py-8 text-center"><div className="inline-block animate-spin rounded-full h-7 w-7 border-b-2 border-primary" /></div>
                  ) : entries.length === 0 ? (
                    <div className="bg-blue-50 border border-blue-200 rounded p-4 text-sm text-blue-700">No timetable periods assigned to this staff member yet.</div>
                  ) : (
                    <>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        {[
                          { label: 'Periods / Week', value: entries.length },
                          { label: 'Classes', value: totalClasses },
                          { label: 'Subjects', value: totalSubjects },
                        ].map((s) => (
                          <div key={s.label} className="bg-primary-10 rounded p-3 text-center">
                            <p className="text-xl font-bold text-primary">{s.value}</p>
                            <p className="text-xs text-gray-600 mt-0.5">{s.label}</p>
                          </div>
                        ))}
                      </div>

                      <div className="overflow-x-auto bg-white rounded shadow">
                        <table className="w-full text-xs border-collapse">
                          <thead>
                            <tr className="bg-gray-50">
                              <th className="border border-gray-200 px-3 py-2 text-left text-gray-600 w-24">Day</th>
                              {periods.map((p) => (
                                <th key={p} className="border border-gray-200 px-3 py-2 text-center text-gray-600 min-w-28">Period {p}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {DAYS.map((day) => {
                              const dayEntries = entries.filter((e) => e.day === day);
                              if (!dayEntries.length) return null;
                              return (
                                <tr key={day} className="hover:bg-gray-50">
                                  <td className="border border-gray-200 px-3 py-2 font-medium text-gray-700 capitalize">{DAY_LABELS[day]}</td>
                                  {periods.map((p) => {
                                    const e = dayEntries.find((x) => x.period_number === p);
                                    return (
                                      <td key={p} className="border border-gray-200 px-2 py-1">
                                        {e ? (
                                          <div className="bg-indigo-50 rounded px-1.5 py-1">
                                            <p className="font-semibold text-indigo-800">{e.subject?.name}</p>
                                            <p className="text-indigo-600 opacity-75">{e.class?.name}{e.section ? ` (${e.section.name})` : ''}</p>
                                          </div>
                                        ) : <span className="text-gray-200">—</span>}
                                      </td>
                                    );
                                  })}
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </>
                  )}
                </div>
              );
            })()}

            {/* Statistics Tab */}
            {activeTab === "statistics" && (
              <div className="space-y-6">
                {stats ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="">
                      <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                        Service Summary
                      </h3>
                      <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                        <p className="text-xs text-gray-600">
                          Years of Service
                        </p>
                        <p className="">:</p>
                        <p className="text-sm font-medium text-gray-900">
                          {stats.years_of_service ?? "—"}
                        </p>
                        <p className="text-xs text-gray-600">Experience</p>
                        <p className="">:</p>
                        <p className="text-sm font-medium text-gray-900">
                          {staff.experience_years != null
                            ? `${staff.experience_years} years`
                            : "—"}
                        </p>
                        <p className="text-xs text-gray-600">Contract Type</p>
                        <p className="">:</p>
                        <p className="text-sm font-medium text-gray-900 capitalize">
                          {staff.contract_type?.replace("_", " ") || "—"}
                        </p>
                      </div>
                    </div>
                    <div className="">
                      <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                        Profile Completion
                      </h3>
                      <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                        {[
                          { label: "Email", done: !!staff.user?.email },
                          { label: "Phone", done: !!staff.user?.phone },
                          { label: "Department", done: !!staff.department },
                          { label: "Designation", done: !!staff.designation },
                          { label: "Address", done: !!staff.address },
                          {
                            label: "Emergency Contact",
                            done: !!staff.emergency_contact,
                          },
                        ].map((item) => (
                          <Fragment key={item.label}>
                            <p className="text-xs text-gray-600">
                              {item.label}
                            </p>
                            <p className="">:</p>
                            <p className="text-sm font-medium text-gray-900">
                              {item.done ? (
                                <svg
                                  className="w-4 h-4 text-green-500"
                                  fill="none"
                                  stroke="currentColor"
                                  viewBox="0 0 24 24"
                                >
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M5 13l4 4L19 7"
                                  />
                                </svg>
                              ) : (
                                <svg
                                  className="w-4 h-4 text-red-500"
                                  fill="none"
                                  stroke="currentColor"
                                  viewBox="0 0 24 24"
                                >
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M6 18L18 6M6 6l12 12"
                                  />
                                </svg>
                              )}
                            </p>
                          </Fragment>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-blue-50 border border-blue-200 rounded p-4">
                    <p className="text-sm text-blue-700">
                      No statistics available for this staff member.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Leave Tab */}
            {activeTab === "leave" && (() => {
              if (!leaveData && !leaveLoading) loadStaffLeave();

              if (leaveLoading) {
                return (
                  <div className="py-10 text-center">
                    <div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" />
                  </div>
                );
              }

              const balances = leaveData?.balances || [];
              const requests = leaveData?.requests || [];

              return (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3">Leave Balances</h3>
                    {balances.length === 0 ? (
                      <div className="bg-blue-50 border border-blue-200 rounded p-4">
                        <p className="text-sm text-blue-700">No leave balances allocated for this staff member.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        {balances.map((b) => {
                          const allocated = Number(b.allocated_days) || 0;
                          const used = Number(b.used_days) || 0;
                          const pct = allocated > 0 ? Math.min(100, Math.round((used / allocated) * 100)) : 0;
                          const exhausted = allocated > 0 && used >= allocated;
                          return (
                            <div key={b.id || b.leave_type?.id} className="bg-white border border-gray-200 rounded p-4">
                              <p className="text-xs text-left text-gray-500">{b.leave_type?.name}</p>
                              <p className="text-2xl text-left font-bold text-primary mt-1">{b.remaining_days}</p>
                              <p className="text-xs text-left text-gray-400">of {allocated} days left</p>
                              <div className="mt-2 h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                                <div className={`h-full rounded-full ${exhausted ? "bg-red-400" : "bg-primary"}`} style={{ width: `${pct}%` }} />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  <div>
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3">Recent Requests</h3>
                    <DataTable
                      columns={[
                        { key: "type", label: "Type", render: (r) => <span className="text-sm text-gray-900">{r.leaveType?.name || "—"}</span> },
                        {
                          key: "dates", label: "Dates",
                          render: (r) => <span className="text-sm text-gray-600">{formatDate(r.start_date)} – {formatDate(r.end_date)}</span>,
                        },
                        { key: "days_count", label: "Days", align: "center", render: (r) => <span className="text-sm text-gray-600">{r.days_count}</span> },
                        {
                          key: "status", label: "Status", align: "center",
                          render: (r) => (
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${LEAVE_STATUS_STYLES[r.status] || ""}`}>
                              {r.status}
                            </span>
                          ),
                        },
                      ]}
                      data={requests}
                      rowId="id"
                      emptyMessage="No leave requests on record"
                    />
                  </div>
                </div>
              );
            })()}

            {/* Documents Tab */}
            {activeTab === "documents" && (() => {
              const documents = Array.isArray(staff.documents) ? staff.documents : [];

              return (
                <div className="space-y-5">
                  {can("staff.update") && (
                    <div className="bg-gray-50 border border-gray-200 rounded p-4">
                      <h3 className="text-sm text-left font-semibold text-gray-700 mb-3">Upload a Document</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                        <Select
                          label="Document Type"
                          value={docMeta.type}
                          onChange={(e) => setDocMeta((m) => ({ ...m, type: e.target.value }))}
                          options={DOCUMENT_TYPES}
                        />
                        <Input
                          label="Label"
                          value={docMeta.name}
                          onChange={(e) => setDocMeta((m) => ({ ...m, name: e.target.value }))}
                          placeholder="Optional — defaults to the file name"
                        />
                        <div>
                          <input
                            ref={docInputRef}
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                            className="hidden"
                            onChange={handleDocumentSelect}
                          />
                          <Button
                            type="button"
                            loading={uploadingDoc}
                            onClick={() => docInputRef.current?.click()}
                          >
                            Choose File &amp; Upload
                          </Button>
                        </div>
                      </div>
                      <p className="text-xs text-left text-gray-400 mt-3">
                        PDF, JPG, PNG or Word. Pick the type first — it is what the list is grouped by.
                      </p>
                    </div>
                  )}

                  <DataTable
                    columns={[
                      {
                        key: "name", label: "Document",
                        render: (d) => (
                          <div>
                            <div className="text-sm font-medium text-gray-900">{d.name}</div>
                            <div className="text-xs text-gray-400">
                              {DOCUMENT_TYPE_LABELS[d.type] || "Other"}
                            </div>
                          </div>
                        ),
                      },
                      {
                        key: "uploaded_at", label: "Uploaded",
                        render: (d) => <span className="text-sm text-gray-600">{d.uploaded_at ? formatDate(d.uploaded_at) : "—"}</span>,
                      },
                      {
                        key: "size", label: "Size", align: "right",
                        render: (d) => (
                          <span className="text-sm text-gray-600">
                            {d.size ? `${Math.max(1, Math.round(d.size / 1024))} KB` : "—"}
                          </span>
                        ),
                      },
                    ]}
                    data={documents}
                    rowId="id"
                    emptyMessage="No documents on file for this staff member"
                    renderActions={(d) => (
                      <RowActions
                        actions={[
                          { label: "Open Document", variant: "primary", icon: ACTION_ICONS.view, onClick: () => window.open(d.url, "_blank", "noopener") },
                          { label: "Remove Document", variant: "danger", icon: ACTION_ICONS.delete, hidden: !can("staff.update"), onClick: () => handleDocumentDelete(d) },
                        ]}
                      />
                    )}
                  />
                </div>
              );
            })()}
          </div>
        </div>
      </div>

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ isOpen: false, action: null })}
        onConfirm={handleConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
      />
    </MainLayout>
  );
}