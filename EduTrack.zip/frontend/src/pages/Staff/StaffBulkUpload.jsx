// FILE PATH: frontend/src/pages/Staff/StaffBulkUpload.jsx
import { staffService, campusService } from "../../services/api";
import ExcelImportPage from "../../components/ExcelImportPage";
import { downloadStaffUploadTemplate, parseStaffUploadFile } from "../../utils/staffBulkTemplate";

export default function StaffBulkUpload() {
  const config = {
    noun: "staff member", nounPlural: "staff", importVerb: "Add", importedWord: "added", chunkSize: 25,
    idKey: "employee_number", idLabel: "Employee No.", detailKey: "role", detailLabel: "Role",
    title: "Bulk Staff Upload",
    subtitle: "Download the Excel template, fill in your staff, then upload it. EduTrack checks every row — and every duplicate — before anything is saved.",
    backPath: "/staff", backLabel: "Back to Staff", goToList: "Go to Staff List",
    reportName: "EduTrack_Staff_Upload",
    templateHelp: 'Each person signs in with their email and the standard staff password, and chooses their own password the first time. The template\'s "Reference" sheet lists your exact Campus names and the Roles you can use. Teaching subjects and documents are added afterwards under Staff → Edit.',
    downloadTemplate: async () => {
      const res = await campusService.getAll({ limit: 100 });
      await downloadStaffUploadTemplate({ campuses: res.success ? res.data : [] });
    },
    parseFile: parseStaffUploadFile,
    preview: (rows) => staffService.bulkPreview({ staff: rows }),
    importChunk: (rows) => staffService.bulkCreate({ staff: rows }),
    resultExtra: { header: "Login email", render: (r) => r.email || "—" },
  };
  return <ExcelImportPage config={config} />;
}
