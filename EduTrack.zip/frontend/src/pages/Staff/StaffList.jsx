import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { staffService, campusService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { Select, Input, ConfirmModal, DataTable, Button, RowActions, ACTION_ICONS, ActionLink } from "../../components/ui";
import Icon from "../../components/ui/Icon";

export default function StaffList() {
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const navigate = useNavigate();
  const [staffList, setStaffList] = useState([]);
  const [campuses, setCampuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedStaff, setSelectedStaff] = useState([]);
  const [confirmModal, setConfirmModal] = useState({
    isOpen: false,
    action: null,
    data: null,
  });
  const [filters, setFilters] = usePersistedState("filters", {
    page: 1,
    limit: 10,
    search: "",
    status: "",
    campus_id: "",
    department: "",
    contract_type: "",
    sortBy: "name",
    sortOrder: "ASC",
  });
  const [pagination, setPagination] = usePersistedState("pagination", {
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
  });

  useEffect(() => {
    fetchStaff();
  }, [
    filters.page,
    filters.limit,
    filters.status,
    filters.campus_id,
    filters.department,
    filters.contract_type,
    filters.sortBy,
    filters.sortOrder,
    filters.search,
  ]);

  useEffect(() => {
    fetchCampuses();
  }, []);

  const fetchCampuses = async () => {
    try {
      const response = await campusService.getAll({ limit: 100 });
      if (response.success) setCampuses(response.data);
    } catch (err) {
      console.error("Failed to fetch campuses:", err);
    }
  };

  const fetchStaff = async () => {
    try {
      setLoading(true);
      const response = await staffService.getAll(filters);
      if (response.success) {
        setStaffList(response.data);
        setPagination(response.pagination);
      }
    } catch (err) {
      showError(err.message || "Failed to fetch staff");
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setFilters((prev) => ({ ...prev, page: 1 }));
    fetchStaff();
  };

  const handleReactivate = async (id) => {
    try {
      const res = await staffService.reactivate(id);
      if (res.success) {
        showSuccess("Staff member reactivated");
        fetchStaff();
      }
    } catch (err) {
      showError(err.message || "Failed to reactivate");
    }
  };

  const handleDelete = (id) => {
    setConfirmModal({
      isOpen: true,
      action: "delete",
      data: id,
      title: "Deactivate Staff Member",
      message:
        "Are you sure you want to deactivate this staff member? This action can be reversed later.",
      variant: "danger",
    });
  };

  const confirmDelete = async () => {
    try {
      const response = await staffService.delete(confirmModal.data);
      if (response.success) {
        showSuccess("Staff member deactivated successfully");
        fetchStaff();
      }
    } catch (err) {
      showError(err.message || "Failed to deactivate staff member");
    }
  };

  const handleBulkStatusUpdate = (status) => {
    if (selectedStaff.length === 0) {
      setConfirmModal({
        isOpen: true,
        action: "info",
        title: "No Selection",
        message: "Please select at least one staff member to update.",
        variant: "info",
        confirmText: "OK",
        hideCancel: true,
      });
      return;
    }
    setConfirmModal({
      isOpen: true,
      action: "bulkUpdate",
      data: status,
      title: "Bulk Status Update",
      message: `Are you sure you want to ${status === "active" ? "activate" : "deactivate"} ${selectedStaff.length} staff member(s)?`,
      variant: "info",
    });
  };

  const confirmBulkUpdate = async () => {
    try {
      const response = await staffService.bulkUpdateStatus({
        ids: selectedStaff,
        status: confirmModal.data,
      });
      if (response.success) {
        showSuccess(
          `${selectedStaff.length} staff member(s) updated successfully`,
        );
        setSelectedStaff([]);
        fetchStaff();
      }
    } catch (err) {
      showError(err.message || "Failed to update staff members");
    }
  };

  const handleConfirm = () => {
    if (confirmModal.action === "delete") confirmDelete();
    else if (confirmModal.action === "bulkUpdate") confirmBulkUpdate();
  };

  const handleSelectAll = (e) => {
    if (e.target.checked) {
      setSelectedStaff(staffList.map((s) => s.id));
    } else {
      setSelectedStaff([]);
    }
  };

  const handleSelectStaff = (id) => {
    setSelectedStaff((prev) =>
      prev.includes(id) ? prev.filter((sid) => sid !== id) : [...prev, id],
    );
  };

  // Bordered pills, matching the student pages and every DataTable in the
  // system — the flat chips here were the only ones without a border.
  const getStatusColor = (status) => {
    switch (status) {
      case "active":
        return "bg-green-100 border border-green-300 text-green-500";
      case "on_leave":
        return "bg-amber-100 border border-amber-300 text-amber-600";
      case "terminated":
        return "bg-gray-100 border border-gray-300 text-gray-500";
      default:
        return "bg-red-100 border border-red-300 text-red-500";
    }
  };

  const getContractColor = (type) => {
    switch (type) {
      case "permanent":
        return "bg-blue-100 border border-blue-300 text-blue-500";
      case "contract":
        return "bg-purple-100 border border-purple-300 text-purple-500";
      case "part_time":
        return "bg-amber-100 border border-amber-300 text-amber-600";
      default:
        return "bg-gray-100 border border-gray-300 text-gray-500";
    }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">
              Staff Management
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              Manage teachers and support staff
            </p>
          </div>
          {can("staff.create") && (
            <div className="flex items-center gap-2">
              <ActionLink to="/staff/bulk-upload" variant="secondary">Bulk Upload</ActionLink>
              <ActionLink to="/staff/add" variant="primary">Add Staff</ActionLink>
            </div>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Total Staff</p>
                <p className="text-2xl text-left font-bold text-primary mt-1">
                  {pagination.totalItems}
                </p>
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg
                  className="w-8 h-8 text-primary opacity-45"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                  />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Active</p>
                <p className="text-2xl text-left font-bold text-green-600 mt-1">
                  {staffList.filter((s) => s.status === "active").length}
                </p>
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg
                  className="w-8 h-8 text-green-600 opacity-45"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">On Leave</p>
                <p className="text-2xl text-left font-bold text-yellow-600 mt-1">
                  {staffList.filter((s) => s.status === "on_leave").length}
                </p>
              </div>
              <div className="bg-yellow-100 p-3 rounded">
                <svg
                  className="w-8 h-8 text-yellow-600 opacity-45"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Inactive</p>
                <p className="text-2xl text-left font-bold text-red-600 mt-1">
                  {
                    staffList.filter(
                      (s) =>
                        s.status === "inactive" || s.status === "terminated",
                    ).length
                  }
                </p>
              </div>
              <div className="bg-red-100 p-3 rounded">
                <svg
                  className="w-8 h-8 text-red-600 opacity-45"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-5 rounded shadow">
          <form
            onSubmit={handleSearch}
            className="grid grid-cols-2 md:grid-cols-6 gap-4"
          >
            <div className="md:col-span-2">
              <Input
                type="text"
                label="Search"
                value={filters.search}
                onChange={(e) =>
                  setFilters({ ...filters, search: e.target.value })
                }
                placeholder="Search by name, employee number..."
                leftIcon={
                  <svg
                    className="w-5 h-5 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                  </svg>
                }
              />
            </div>
            <div>
              <Select
                label="Status"
                value={filters.status}
                onChange={(e) =>
                  setFilters({ ...filters, status: e.target.value, page: 1 })
                }
                options={[
                  { value: "", label: "All Statuses" },
                  { value: "active", label: "Active" },
                  { value: "inactive", label: "Inactive" },
                  { value: "on_leave", label: "On Leave" },
                  { value: "terminated", label: "Terminated" },
                ]}
              />
            </div>
            <div>
              <Select
                label="Campus"
                value={filters.campus_id}
                onChange={(e) =>
                  setFilters({ ...filters, campus_id: e.target.value, page: 1 })
                }
                options={[
                  { value: "", label: "All Campuses" },
                  ...campuses.map((c) => ({ value: c.id, label: c.name })),
                ]}
              />
            </div>
            <div>
              <Select
                label="Contract Type"
                value={filters.contract_type}
                onChange={(e) =>
                  setFilters({
                    ...filters,
                    contract_type: e.target.value,
                    page: 1,
                  })
                }
                options={[
                  { value: "", label: "All Types" },
                  { value: "permanent", label: "Permanent" },
                  { value: "contract", label: "Contract" },
                  { value: "part_time", label: "Part-Time" },
                ]}
              />
            </div>
            <div className="flex items-end">
              <Button
                type="submit"
                className="w-full"
              >
                Apply Filters
              </Button>
            </div>
          </form>
        </div>

        {/* Bulk Actions */}
        {selectedStaff.length > 0 &&
          (can("staff.update") || can("staff.delete")) && (
            <div className="bg-primary-10 border border-primary-25 rounded p-4 px-5 flex flex-wrap items-center justify-between gap-2">
              <span className="text-sm font-medium text-gray-700">
                {selectedStaff.length} staff member(s) selected
              </span>
              <div className="flex space-x-2">
                {can("staff.update") && <Button variant="success" onClick={() => handleBulkStatusUpdate("active")}>Activate</Button>}
                {can("staff.delete") && <Button variant="danger" onClick={() => handleBulkStatusUpdate("inactive")}>Deactivate</Button>}
              </div>
            </div>
          )}

        <DataTable
          columns={[
            {
              key: "name",
              label: "Staff Member",
              render: (staff) => (
                <div>
                  <div className="text-sm font-medium">
                    {staff.user?.first_name} {staff.user?.last_name}
                  </div>
                  {/* <div className="text-xs text-gray-400">
                    #{staff.employee_number}
                  </div> */}
                </div>
              ),
            },
            {
              key: "role",
              label: "Role / Department",
              render: (staff) => (
                <div>
                  <div className="capitalize text-sm text-gray-700">
                    {staff.user?.role?.replace("_", " ")}
                  </div>
                  {staff.department && (
                    <div className="text-xs text-gray-400">
                      {staff.department}
                    </div>
                  )}
                </div>
              ),
            },
            {
              key: "campus",
              label: "Campus",
              render: (staff) =>
                staff.campus?.name || (
                  <span className="text-gray-400">N/A</span>
                ),
            },
            {
              key: "contract_type",
              label: "Contract",
              render: (staff) =>
                staff.contract_type ? (
                  <span
                    className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${getContractColor(staff.contract_type)}`}
                  >
                    {staff.contract_type.replace("_", " ")}
                  </span>
                ) : null,
            },
            {
              key: "status",
              label: "Status",
              render: (staff) => (
                <span
                  className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${getStatusColor(staff.status)}`}
                >
                  {staff.status?.replace("_", " ")}
                </span>
              ),
            },
          ]}
          data={staffList}
          loading={loading}
          emptyMessage="No staff found"
          // selectable={["super_admin", "admin"].includes(user?.role)}
          selectedIds={selectedStaff}
          onSelectAll={handleSelectAll}
          onSelectRow={handleSelectStaff}
          renderActions={(staff) => {
            return (
              <RowActions
                actions={[
                  { label: "View Details", variant: "primary", icon: ACTION_ICONS.view, hidden: !can("staff.update"), onClick: () => navigate(`/staff/${staff.id}`) },
                  { label: "Edit Staff", icon: ACTION_ICONS.edit, hidden: !can("staff.update"), onClick: () => navigate(`/staff/${staff.id}/edit`) },
                  { label: "Deactivate", variant: "danger", icon: ACTION_ICONS.remove, hidden: !can("staff.delete") || staff.status !== "active", onClick: () => handleDelete(staff.id) },
                  { label: "Reactivate", variant: "success", icon: ACTION_ICONS.check, hidden: !can("staff.update") || staff.status === "active", onClick: () => handleReactivate(staff.id) },
                ]}
              />
            );
          }}
          pagination={pagination}
          onPageChange={(page) => setFilters((prev) => ({ ...prev, page }))}
        />
      </div>

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() =>
          setConfirmModal({ isOpen: false, action: null, data: null })
        }
        onConfirm={handleConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
        confirmText={confirmModal.confirmText}
        hideCancel={confirmModal.hideCancel}
      />
    </MainLayout>
  );
}
