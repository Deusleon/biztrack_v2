import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { useAuth } from "../../contexts/AuthContext";
import { staffService, campusService, subjectService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Input, NumberInput, PhoneInput, Textarea, DatePicker, Button } from "../../components/ui";
import { COUNTRIES } from "../../constants/countries";

// Must match the roles the server accepts for staff (backend utils/staffRoles.js).
// "Support Staff" used to be listed here but is not a role the system has, so
// choosing it failed on save.
const STAFF_ROLE_OPTIONS = [
  { value: "teacher", label: "Teacher" },
  { value: "principal", label: "Principal" },
  { value: "admin", label: "Admin" },
  { value: "accountant", label: "Accountant" },
  { value: "librarian", label: "Librarian" },
  { value: "hr", label: "HR Manager" },
  { value: "transport_manager", label: "Transport Manager" },
  { value: "hostel_warden", label: "Hostel Warden" },
];
const ROLE_MANAGERS = ["super_admin", "admin", "principal", "hr"];
const ADMINISTRATORS = ["super_admin", "admin"];

export default function StaffForm() {
  const { id } = useParams();
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();
  const isEdit = Boolean(id);

  const [loading, setLoading] = useState(false);
  const [fetchingData, setFetchingData] = useState(isEdit);
  const [staffUserId, setStaffUserId] = useState(null); // the account being edited
  const [campuses, setCampuses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [formData, setFormData] = useState({
    email: "",
    first_name: "",
    middle_name: "",
    last_name: "",
    phone: "",
    // Deliberately empty: a role decides what this person can do in the
    // system, so it has to be chosen — not left as whatever came first.
    role: "",
    campus_id: "",
    employee_number: "",
    department: "",
    designation: "",
    joining_date: "",
    contract_type: "permanent",
    contract_end_date: "",
    salary: "",
    experience_years: "",
    date_of_birth: "",
    gender: "",
    marital_status: "",
    blood_group: "",
    national_id: "",
    address: "",
    city: "",
    // Pre-filled, as on student admission — nearly every staff member is
    // local, so making it a required blank field is friction for nothing.
    country: "Tanzania",
    emergency_contact: "",
    emergency_contact_name: "",
    emergency_contact_relation: "",
    tin_number: "",
    nssf_number: "",
    bank_name: "",
    bank_account_number: "",
    notes: "",
    status: "active",
    teaching_subjects: [],
  });

  useEffect(() => {
    fetchCampuses();
    fetchSubjects();
    if (isEdit) fetchStaffData();
  }, [id]);

  const fetchCampuses = async () => {
    try {
      const response = await campusService.getAll({ limit: 100 });
      if (response.success) setCampuses(response.data);
    } catch (err) {
      showError(err.message || "Failed to fetch campuses");
    }
  };

  const fetchSubjects = async () => {
    try {
      const response = await subjectService.getAll({ limit: 200, status: 'active' });
      if (response.success) setSubjects(response.data || []);
    } catch {
      // non-critical — subjects for teacher assignment
    }
  };

  const fetchStaffData = async () => {
    try {
      setFetchingData(true);
      const response = await staffService.getById(id);
      if (response.success) {
        const s = response.data;
        setStaffUserId(s.user?.id || s.user_id || null);
        setFormData({
          email: s.user?.email || "",
          first_name: s.user?.first_name || "",
          middle_name: s.user?.middle_name || "",
          last_name: s.user?.last_name || "",
          phone: s.user?.phone || "",
          role: s.user?.role || "",
          campus_id: s.campus_id || "",
          employee_number: s.employee_number || "",
          department: s.department || "",
          designation: s.designation || "",
          joining_date: s.joining_date ? s.joining_date.substring(0, 10) : "",
          contract_type: s.contract_type || "permanent",
          contract_end_date: s.contract_end_date ? s.contract_end_date.substring(0, 10) : "",
          salary: s.salary || "",
          experience_years: s.experience_years || "",
          date_of_birth: s.date_of_birth ? s.date_of_birth.substring(0, 10) : "",
          gender: s.gender || "",
          marital_status: s.marital_status || "",
          blood_group: s.blood_group || "",
          national_id: s.national_id || "",
          address: s.address || "",
          city: s.city || "",
          country: s.country || "Tanzania",
          emergency_contact: s.emergency_contact || "",
          emergency_contact_name: s.emergency_contact_name || "",
          emergency_contact_relation: s.emergency_contact_relation || "",
          tin_number: s.tin_number || "",
          nssf_number: s.nssf_number || "",
          bank_name: s.bank_name || "",
          bank_account_number: s.bank_account_number || "",
          notes: s.notes || "",
          status: s.status || "active",
          teaching_subjects: s.teaching_subjects || [],
        });
      }
    } catch (err) {
      showError(err.message || "Failed to fetch staff data");
    } finally {
      setFetchingData(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.first_name.trim()) return showError("First name is required");
    if (!formData.last_name.trim()) return showError("Last name is required");
    if (!formData.email.trim()) return showError("Email is required — it is their login");
    if (!formData.phone.trim()) return showError("Phone number is required");
    if (!formData.role) return showError("Role is required — choose what this person does");
    if (!formData.campus_id) return showError("Campus is required");
    if (!formData.employee_number.trim())
      return showError("Employee number is required");

    try {
      setLoading(true);
      const submitData = { ...formData };
      if (!submitData.salary) delete submitData.salary;
      if (!submitData.experience_years) delete submitData.experience_years;

      const response = isEdit
        ? await staffService.update(id, submitData)
        : await staffService.create(submitData);

      if (response.success) {
        showSuccess(
          `Staff member ${isEdit ? "updated" : "added"} successfully`,
        );
        navigate("/staff");
      }
    } catch (err) {
      showError(
        err.message || `Failed to ${isEdit ? "update" : "add"} staff member`,
      );
    } finally {
      setLoading(false);
    }
  };

  if (fetchingData) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-sm text-gray-600 mt-2">Loading staff data...</p>
        </div>
      </MainLayout>
    );
  }

  // Who may change this role (the server enforces the same rules):
  // administrators any staff role; principal / HR everyday roles; nobody their own.
  const canManageRoles = ROLE_MANAGERS.includes(currentUser?.role);
  const isAdministrator = ADMINISTRATORS.includes(currentUser?.role);
  const editingSelf = isEdit && staffUserId && currentUser?.id === staffUserId;
  const holdsFixedRole = isEdit && formData.role === "super_admin";
  const roleLocked = isEdit && (editingSelf || holdsFixedRole || !canManageRoles);
  const roleHelp = !isEdit
    ? undefined
    : editingSelf ? "You can't change your own role"
    : holdsFixedRole ? "A super admin's role can't be changed here"
    : !canManageRoles ? "Only an administrator, principal or HR manager can change roles"
    : undefined;
  // Admin and Principal can only be handed out by an administrator; the role
  // someone already holds is always shown so the field never reads blank.
  const roleOptions = [
    ...STAFF_ROLE_OPTIONS.filter((r) => isAdministrator || !["admin", "principal"].includes(r.value) || r.value === formData.role),
    ...(formData.role && !STAFF_ROLE_OPTIONS.some((r) => r.value === formData.role)
      ? [{ value: formData.role, label: formData.role.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()) }]
      : []),
  ];

  return (
    <MainLayout>
      <div className="space-y-4 text-left">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">
              {isEdit ? "Edit Staff Member" : "Add Staff Member"}
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {isEdit
                ? "Update staff member information"
                : "Register a new staff member"}
            </p>
          </div>
          <Button
            onClick={() => navigate("/staff")}
            variant="lightPrimary"
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to List
          </Button>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-white rounded shadow text-left"
        >
          <div className="px-5 py-4 space-y-10">
            {/* Personal Information */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Personal Information
              </h2>
              {/* Three per row on desktop, matching student admission — two
                  columns left this form twice as long as it needed to be. */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input
                  label="First Name"
                  name="first_name"
                  value={formData.first_name}
                  onChange={handleChange}
                  required
                  placeholder="Enter first name"
                />
                <Input
                  label="Middle Name"
                  name="middle_name"
                  value={formData.middle_name}
                  onChange={handleChange}
                  placeholder="Optional"
                />
                <Input
                  label="Last Name"
                  name="last_name"
                  value={formData.last_name}
                  onChange={handleChange}
                  required
                  placeholder="Enter last name"
                />
                {/* Email and phone stay editable when editing — previously
                    they were hidden after creation, so a mistyped login or
                    a changed number could never be corrected. */}
                <Input
                  label="Email"
                  type="email"
                  name="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="name@school.co.tz"
                  helperText={isEdit ? "This is their login" : "This becomes their login"}
                />
                <PhoneInput
                  label="Phone"
                  name="phone"
                  required
                  placeholder="255 6XX XXX XXX"
                  value={formData.phone}
                  onChange={handleChange}
                />
                <Select
                  label="Role"
                  name="role"
                  required
                  value={formData.role}
                  onChange={handleChange}
                  placeholder="Select role…"
                  disabled={roleLocked}
                  helperText={roleHelp}
                  options={roleOptions}
                />
                <DatePicker
                  label="Date of Birth"
                  name="date_of_birth"
                  value={formData.date_of_birth}
                  onChange={handleChange}
                />
                <Select
                  label="Gender"
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                  placeholder="Select…"
                  options={[
                    { value: "male", label: "Male" },
                    { value: "female", label: "Female" },
                    { value: "other", label: "Other" },
                  ]}
                />
                <Select
                  label="Marital Status"
                  name="marital_status"
                  value={formData.marital_status}
                  onChange={handleChange}
                  placeholder="Select…"
                  options={[
                    { value: "single", label: "Single" },
                    { value: "married", label: "Married" },
                    { value: "divorced", label: "Divorced" },
                    { value: "widowed", label: "Widowed" },
                  ]}
                />
                <Input
                  label="National ID (NIDA)"
                  name="national_id"
                  value={formData.national_id}
                  onChange={handleChange}
                  placeholder="Optional"
                />
              </div>
{/* 
              {!isEdit && (
                <p className="text-sm text-gray-600 bg-blue-50 border border-blue-200 rounded px-3 py-2.5 mt-4 leading-relaxed">
                  No password is set here. The staff member signs in with the email above and the
                  school's default staff password, and is asked to change it on first login — so
                  nobody else ever knows their password.
                </p>
              )} */}
            </div>

            {/* Employment Details */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Employment Details
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Select
                  label="Campus"
                  name="campus_id"
                  value={formData.campus_id}
                  onChange={handleChange}
                  required
                  options={[
                    { value: "", label: "Select campus..." },
                    ...campuses.map((c) => ({
                      value: c.id,
                      label: c.name + " (" + c.code + ")",
                    })),
                  ]}
                />
                <Input
                  label="Employee Number"
                  name="employee_number"
                  value={formData.employee_number}
                  onChange={handleChange}
                  required
                  placeholder="e.g., EMP-2026-001"
                />
                <Input
                  label="Department"
                  name="department"
                  value={formData.department}
                  onChange={handleChange}
                  placeholder="e.g., Mathematics, Science"
                />
                <Input
                  label="Designation"
                  name="designation"
                  value={formData.designation}
                  onChange={handleChange}
                  placeholder="e.g., Senior Teacher, HOD"
                />
                <DatePicker
                  label="Joining Date"
                  name="joining_date"
                  value={formData.joining_date}
                  onChange={handleChange}
                />
                <Select
                  label="Contract Type"
                  name="contract_type"
                  value={formData.contract_type}
                  onChange={handleChange}
                  options={[
                    { value: "permanent", label: "Permanent" },
                    { value: "contract", label: "Contract" },
                    { value: "part_time", label: "Part-Time" },
                  ]}
                />
                <NumberInput
                  label="Salary"
                  name="salary"
                  value={formData.salary}
                  onChange={handleChange}
                  placeholder="Monthly salary amount"
                />
                <Input
                  label="Years of Experience"
                  type="number"
                  name="experience_years"
                  value={formData.experience_years}
                  onChange={handleChange}
                  placeholder="Total years of experience"
                />
                {/* Only meaningful for fixed-term staff — a permanent
                    contract has no end date to record. */}
                {formData.contract_type !== "permanent" && (
                  <DatePicker
                    label="Contract End Date"
                    name="contract_end_date"
                    value={formData.contract_end_date}
                    onChange={handleChange}
                  />
                )}
                {isEdit && (
                  <Select
                    label="Status"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    options={[
                      { value: "active", label: "Active" },
                      { value: "inactive", label: "Inactive" },
                      { value: "on_leave", label: "On Leave" },
                      { value: "terminated", label: "Terminated" },
                    ]}
                  />
                )}
              </div>
            </div>

            {/* Payroll & Statutory */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Payroll &amp; Statutory
              </h2>
              {/* <p className="text-sm text-gray-500 mb-4">
                Payroll already works out net pay, but the identifiers a school must file against —
                and the account the money goes to — had nowhere to be recorded.
              </p> */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input label="TIN Number" name="tin_number" value={formData.tin_number} onChange={handleChange} placeholder="Optional" />
                <Input label="NSSF Number" name="nssf_number" value={formData.nssf_number} onChange={handleChange} placeholder="Optional" />
                <Input label="Bank Name" name="bank_name" value={formData.bank_name} onChange={handleChange} placeholder="Optional" />
                {/* <div className="lg:col-span-2"> */}
                  <Input label="Bank Account Number" name="bank_account_number" value={formData.bank_account_number} onChange={handleChange} placeholder="Optional" />
                {/* </div> */}
              </div>
            </div>

            {/* Teaching Subjects — only for teachers */}
            {formData.role === 'teacher' && (
              <div className="text-left">
                <h2 className="text-md font-semibold text-gray-900 mb-1">Teaching Subjects</h2>
                <p className="text-sm text-gray-500 mb-3">Select all subjects this teacher is qualified to teach. This is used when generating timetables.</p>
                {subjects.length === 0 ? (
                  <p className="text-sm text-gray-400 italic">No subjects found. Add subjects first in the Subjects section.</p>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                    {subjects.map((s) => {
                      const checked = (formData.teaching_subjects || []).includes(s.id);
                      return (
                        <label
                          key={s.id}
                          className={`flex items-center gap-2 px-3 py-2 rounded border cursor-pointer transition-colors ${
                            checked ? 'bg-primary/10 border-primary text-primary font-medium' : 'bg-white border-gray-200 text-gray-700 hover:border-gray-400'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={(e) => {
                              const ids = formData.teaching_subjects || [];
                              setFormData((prev) => ({
                                ...prev,
                                teaching_subjects: e.target.checked
                                  ? [...ids, s.id]
                                  : ids.filter((id) => id !== s.id),
                              }));
                            }}
                            className="accent-primary"
                          />
                          <span className="text-sm leading-tight">{s.name}</span>
                          {s.code && <span className="text-xs opacity-60">({s.code})</span>}
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* Address Information */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Address Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="lg:col-span-3">
                  <Textarea
                    label="Address"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    rows={2}
                    placeholder="Street address"
                  />
                </div>
                <Input
                  label="City"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  placeholder="City"
                />
                <Select
                  label="Country"
                  name="country"
                  value={formData.country}
                  onChange={handleChange}
                  searchable
                  options={COUNTRIES.map((c) => ({ value: c, label: c }))}
                />
              </div>
            </div>

            {/* Emergency Contact */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Emergency Contact
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input
                  label="Contact Name"
                  name="emergency_contact_name"
                  value={formData.emergency_contact_name}
                  onChange={handleChange}
                  placeholder="Full name"
                />
                <Input
                  label="Relationship"
                  name="emergency_contact_relation"
                  value={formData.emergency_contact_relation}
                  onChange={handleChange}
                  placeholder="e.g. Spouse, Brother"
                />
                <PhoneInput
                  label="Contact Phone"
                  name="emergency_contact"
                  value={formData.emergency_contact}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* Additional Notes */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Additional Notes
              </h2>
              <Textarea
                label="Notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                rows={3}
                placeholder="Anything else that belongs on this staff member's file"
              />
            </div>
          </div>

          {/* Form Footer */}
          <div className="bg-gray-50 px-5 py-4 flex items-center justify-end gap-3 rounded-b">
            <Button type="button" variant="secondary" onClick={() => navigate("/staff")}>Cancel</Button>
            <Button type="submit" loading={loading}>{isEdit ? "Update Staff" : "Add Staff"}</Button>
          </div>
        </form>
      </div>
    </MainLayout>
  );
}
