import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { usePreferences } from "../contexts/PreferencesContext";
import MainLayout from "../components/MainLayout";
import { notificationService, settingsService, studentService } from "../services/api";
import { ACCESS_FOR_PATH, MODULE_INFO } from "../utils/moduleAccess";

const greeting = () => {
  const h = new Date().getHours();
  return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
};

// Shortcuts to the things people do most — shown only if they may do them.
const SHORTCUTS = [
  { perm: "students.create", label: "Add a student", to: "/students/admission" },
  { perm: "attendance.create", label: "Take attendance", to: "/attendance/take" },
  { perm: "fees.create", label: "Record a fee payment", to: "/fees/record" },
  { perm: "send_messages", label: "Send a message", to: "/messages/compose" },
  { perm: "leave.request", label: "Request leave", to: "/leave" },
  { perm: "payroll.access", label: "See my payslips", to: "/payroll" },
];

/**
 * The personal dashboard — for everyone who isn't given the full Dashboard. It is
 * built only from things every signed-in person may always read (their own
 * notifications, the school calendar, their own children), plus links to the
 * modules their permissions open. Nothing on it can fail with "no permission".
 */
export default function BasicDashboard() {
  const { user, can } = useAuth();
  const { formatDate } = usePreferences();
  const [notifications, setNotifications] = useState(null);
  const [terms, setTerms] = useState([]);
  const [children, setChildren] = useState(null);

  useEffect(() => {
    if (can("notifications.access")) {
      notificationService.getMyNotifications({ limit: 5 }).then((r) => setNotifications(r.success ? r.data : [])).catch(() => setNotifications([]));
    }
    settingsService.getOverview().then((r) => { if (r.success) setTerms(r.data.terms || []); }).catch(() => {});
    if (user?.role === "parent") {
      studentService.getAll({ parent_id: user.id, limit: 20 }).then((r) => setChildren(r.success ? r.data : [])).catch(() => setChildren([]));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const modules = Object.entries(ACCESS_FOR_PATH)
    .filter(([path, key]) => MODULE_INFO[path] && can(key))
    // Notifications has its own panel below; Settings stays out of the way.
    .filter(([path]) => path !== "/notifications");
  const shortcuts = SHORTCUTS.filter((s) => can(s.perm));

  const today = new Date().toISOString().slice(0, 10);
  const term = terms.filter((t) => t.start_date && t.end_date).find((t) => t.start_date <= today && t.end_date >= today);

  return (
    <MainLayout>
      <div className="space-y-5 text-left">
        <div className="bg-white p-6 rounded shadow">
          <h1 className="text-xl font-bold text-gray-900">{greeting()}{user?.first_name ? `, ${user.first_name}` : ""}</h1>
          <p className="text-sm text-gray-500 mt-1">
            {formatDate(today)}{term ? ` · ${term.name}` : ""}{user?.role ? ` · ${user.role.replace(/_/g, " ")}` : ""}
          </p>
        </div>

        {user?.role === "parent" && (
          <div className="bg-white p-5 rounded shadow">
            <h2 className="text-sm font-semibold text-gray-800 mb-3">My children</h2>
            {children === null ? <p className="text-sm text-gray-400">Loading…</p>
              : children.length === 0 ? <p className="text-sm text-gray-500">No children are linked to your account yet. Please ask the school office.</p>
              : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {children.map((c) => (
                    <Link key={c.id} to={`/students/${c.id}`} className="border border-gray-200 rounded p-3 hover:border-primary">
                      <p className="text-sm font-medium text-gray-900">{c.user?.first_name} {c.user?.last_name}</p>
                      <p className="text-xs text-gray-500">{c.class?.name || "No class yet"} · {c.admission_number}</p>
                    </Link>
                  ))}
                </div>
              )}
          </div>
        )}

        {shortcuts.length > 0 && (
          <div className="bg-white p-5 rounded shadow">
            <h2 className="text-sm font-semibold text-gray-800 mb-3">Shortcuts</h2>
            <div className="flex flex-wrap gap-2">
              {shortcuts.map((s) => <Link key={s.to} to={s.to} className="bg-primary text-white text-sm px-4 py-2 rounded hover:opacity-90">{s.label}</Link>)}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 bg-white p-5 rounded shadow">
            <h2 className="text-sm font-semibold text-gray-800 mb-3">Your modules</h2>
            {modules.length === 0 ? (
              <p className="text-sm text-gray-500">You haven't been given access to any modules yet. Please ask your school's administrator.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {modules.map(([path]) => (
                  <Link key={path} to={path} className="border border-gray-200 rounded p-3 hover:border-primary">
                    <p className="text-sm font-medium text-gray-900">{MODULE_INFO[path][0]}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{MODULE_INFO[path][1]}</p>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {can("notifications.access") && (
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <h2 className="text-sm font-semibold text-gray-800">Latest notifications</h2>
              {can("notifications.access") && <Link to="/notifications" className="text-xs text-primary hover:underline">See all</Link>}
            </div>
            {notifications === null ? <p className="text-sm text-gray-400">Loading…</p>
              : notifications.length === 0 ? <p className="text-sm text-gray-500">Nothing new.</p>
              : (
                <ul className="divide-y divide-gray-100">
                  {notifications.map((n) => (
                    <li key={n.id} className="py-2">
                      <p className="text-sm text-gray-800">{n.title}</p>
                      <p className="text-xs text-gray-500 line-clamp-2">{n.message}</p>
                    </li>
                  ))}
                </ul>
              )}
          </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
