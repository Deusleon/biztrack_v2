export { default as HostelList } from './HostelList';
export { default as HostelRooms } from './HostelRooms';
