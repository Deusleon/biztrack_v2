import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { hostelService, studentService } from "../../services/api";
import { useYearAwareClasses } from "../../hooks/useYearAwareClasses";
import MainLayout from "../../components/MainLayout";
import { Select, Input, NumberInput, Button, ConfirmModal, DataTable, RowActions, ACTION_ICONS } from "../../components/ui";

const ROOM_STATUS_STYLES = {
  available: "bg-green-100 border border-green-300 text-green-500",
  occupied: "bg-blue-100 border border-blue-300 text-blue-500",
  maintenance: "bg-amber-100 border border-amber-300 text-amber-600",
};

const TONE_TEXT = { primary: "text-primary", indigo: "text-indigo-600", green: "text-green-600", amber: "text-amber-600", red: "text-red-600" };
const TONE_BG = { primary: "bg-primary-15", indigo: "bg-indigo-100", green: "bg-green-100", amber: "bg-amber-100", red: "bg-red-100" };

export default function HostelRooms() {
  const { id: hostelId } = useParams();
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();

  const [hostel, setHostel] = useState(null);
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);

  const [roomModal, setRoomModal] = useState({ isOpen: false });
  const [roomForm, setRoomForm] = useState({ room_number: "", capacity: 1, floor: "", status: "available" });
  const [savingRoom, setSavingRoom] = useState(false);
  const [confirmDeleteRoom, setConfirmDeleteRoom] = useState({ isOpen: false });

  const [studentsModal, setStudentsModal] = useState(null);
  const [roomStudents, setRoomStudents] = useState([]);
  const [loadingStudents, setLoadingStudents] = useState(false);
  const [assignForm, setAssignForm] = useState({ student_id: "", fee: "" });
  const [selectedClass, setSelectedClass] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [classStudents, setClassStudents] = useState([]);
  const [assigning, setAssigning] = useState(false);
  const [confirmVacate, setConfirmVacate] = useState({ isOpen: false });

  const load = async () => {
    try {
      setLoading(true);
      const [hostelRes, roomsRes] = await Promise.all([hostelService.getHostelById(hostelId), hostelService.getRooms({ hostel_id: hostelId })]);
      if (hostelRes.success) setHostel(hostelRes.data);
      if (roomsRes.success) setRooms(roomsRes.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [hostelId]);
  const classes = useYearAwareClasses({ selectedClassId: selectedClass, onRemap: setSelectedClass });

  useEffect(() => {
    if (!selectedClass) { setClassStudents([]); return; }
    // Only students whose admission record opts them into hostel accommodation.
    // Showing everyone invites allocating a service the family declined,
    // which the fee engine would then start billing them for.
    studentService.getAll({ class_id: selectedClass, section_id: selectedSection || undefined, status: "active", hostel_required: true, limit: 200 }).then((res) => {
      if (res.success) setClassStudents(res.data);
    });
  }, [selectedClass, selectedSection]);
  const sections = classes.find((c) => c.id === selectedClass)?.sections || [];

  const openCreateRoom = () => { setRoomForm({ room_number: "", capacity: 1, floor: "", status: "available" }); setRoomModal({ isOpen: true, mode: "create" }); };
  const openEditRoom = (r) => { setRoomForm({ room_number: r.room_number, capacity: r.capacity, floor: r.floor || "", status: r.status }); setRoomModal({ isOpen: true, mode: "edit", id: r.id }); };

  const handleSaveRoom = async () => {
    if (!roomForm.room_number) { showError("Room number is required"); return; }
    try {
      setSavingRoom(true);
      const payload = { ...roomForm, capacity: Number(roomForm.capacity), hostel_id: hostelId };
      if (roomModal.mode === "edit") await hostelService.updateRoom(roomModal.id, payload);
      else await hostelService.createRoom(payload);
      showSuccess(roomModal.mode === "edit" ? "Room updated" : "Room created");
      setRoomModal({ isOpen: false });
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSavingRoom(false); }
  };

  const handleDeleteRoom = (r) => setConfirmDeleteRoom({ isOpen: true, id: r.id, room_number: r.room_number });
  const confirmDeleteRoomAction = async () => {
    try {
      await hostelService.deleteRoom(confirmDeleteRoom.id);
      showSuccess("Room deleted");
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmDeleteRoom({ isOpen: false });
  };

  const openStudents = async (room) => {
    setStudentsModal(room);
    setSelectedClass(""); setSelectedSection("");
    setAssignForm({ student_id: "", fee: "" });
    setLoadingStudents(true);
    try {
      const res = await hostelService.getRoomStudents(room.id);
      if (res.success) setRoomStudents(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoadingStudents(false); }
  };

  const handleAssign = async () => {
    if (!assignForm.student_id) { showError("Pick a student"); return; }
    try {
      setAssigning(true);
      const res = await hostelService.assignStudent({ student_id: assignForm.student_id, room_id: studentsModal.id, fee: assignForm.fee || undefined });
      if (res.success) {
        showSuccess(res.message);
        setAssignForm({ student_id: "", fee: "" });
        const refreshed = await hostelService.getRoomStudents(studentsModal.id);
        if (refreshed.success) setRoomStudents(refreshed.data);
        load();
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setAssigning(false); }
  };

  const handleVacate = (allocationId) => setConfirmVacate({ isOpen: true, id: allocationId });
  const confirmVacateStudent = async () => {
    try {
      await hostelService.vacateStudent(confirmVacate.id);
      showSuccess("Student vacated");
      const refreshed = await hostelService.getRoomStudents(studentsModal.id);
      if (refreshed.success) setRoomStudents(refreshed.data);
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmVacate({ isOpen: false });
  };

  const alreadyInRoomIds = new Set(roomStudents.map((a) => a.student_id));

  // Hostel-wide occupancy, derived rather than fetched — the room list
  // already carries everything needed.
  const totals = rooms.reduce((acc, r) => {
    const capacity = Number(r.capacity) || 0;
    const occupied = Number(r.occupied) || 0;
    return {
      rooms: acc.rooms + 1,
      capacity: acc.capacity + capacity,
      occupied: acc.occupied + occupied,
      free: acc.free + Math.max(0, capacity - occupied),
    };
  }, { rooms: 0, capacity: 0, occupied: 0, free: 0 });

  if (loading) return <MainLayout><div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div></MainLayout>;
  if (!hostel) return <MainLayout><div className="bg-white p-10 rounded shadow text-center text-gray-400">Hostel not found.</div></MainLayout>;

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">{hostel.name}</h1>
            <p className="text-sm text-gray-500 mt-0.5 capitalize">{hostel.type} hostel{hostel.warden ? ` • Warden: ${hostel.warden.first_name} ${hostel.warden.last_name}` : ""}</p>
          </div>
          <div className="flex items-center gap-2">
            {can("hostel.create") && <Button onClick={openCreateRoom}>New Room</Button>}
            <Button
              onClick={() => navigate("/hostel")}
              variant="lightPrimary"
              className="animate-pulse"
              leftIcon={
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 19l-7-7m0 0l7-7m-7 7h18"
                  />
                </svg>
              }>Back to Hostels
            </Button>
          </div>
        </div>

        {/* Occupancy at a glance — the one number a warden actually needs
            when walking the block. */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Rooms", value: totals.rooms, tone: "primary", d: "M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" },
            { label: "Total Beds", value: totals.capacity, tone: "indigo", d: "M3 10h18M3 10a2 2 0 012-2h14a2 2 0 012 2M3 10v8a2 2 0 002 2h14a2 2 0 002-2v-8M7 14h.01" },
            { label: "Occupied", value: totals.occupied, tone: "green", d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" },
            { label: "Free Beds", value: totals.free, tone: totals.free === 0 ? "red" : "amber", d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" },
          ].map((card) => (
            <div key={card.label} className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">{card.label}</p>
                  <p className={`text-2xl text-left font-bold mt-1 ${TONE_TEXT[card.tone]}`}>{card.value}</p>
                </div>
                <div className={`p-3 rounded ${TONE_BG[card.tone]}`}>
                  <svg className={`w-8 h-8 opacity-45 ${TONE_TEXT[card.tone]}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={card.d} />
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Shared DataTable rather than a card grid, so rooms follow the same
            standard as every other list in the system — and a long block of
            30+ rooms stays scannable instead of becoming a wall of cards. */}
        <DataTable
          columns={[
            {
              key: "room_number", label: "Room",
              render: (r) => (
                <div>
                  <div className="text-sm font-medium text-gray-900">Room {r.room_number}</div>
                  <div className="text-xs text-gray-400">{r.floor ? `Floor ${r.floor}` : "Floor not set"}</div>
                </div>
              ),
            },
            {
              key: "occupancy", label: "Occupancy",
              // A bar rather than a bare "2 / 4" — how full a room is matters
              // more at a glance than the raw numbers.
              render: (r) => {
                const capacity = Number(r.capacity) || 0;
                const occupied = Number(r.occupied) || 0;
                const pct = capacity > 0 ? Math.min(100, Math.round((occupied / capacity) * 100)) : 0;
                const full = capacity > 0 && occupied >= capacity;
                return (
                  <div className="min-w-[140px]">
                    <div className="flex items-baseline justify-between gap-3">
                      <span className="text-sm text-gray-900">{occupied} <span className="text-gray-400">of {capacity}</span></span>
                      <span className={`text-xs font-medium ${full ? "text-red-600" : "text-green-600"}`}>
                        {full ? "Full" : `${capacity - occupied} free`}
                      </span>
                    </div>
                    <div className="mt-1 h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${full ? "bg-red-400" : "bg-primary"}`} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              },
            },
            { key: "capacity", label: "Beds", align: "center", render: (r) => <span className="text-sm text-gray-600">{r.capacity}</span> },
            {
              key: "status", label: "Status", align: "center",
              render: (r) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${ROOM_STATUS_STYLES[r.status]}`}>
                  {r.status}
                </span>
              ),
            },
          ]}
          data={rooms}
          rowId="id"
          emptyMessage="No rooms in this hostel yet"
          renderActions={(r) => (
            <RowActions
              actions={[
                { label: "Manage Occupants", variant: "primary", icon: ACTION_ICONS.view, hidden: !can("hostel.update"), onClick: () => openStudents(r) },
                { label: "Edit Room", icon: ACTION_ICONS.edit, hidden: !can("hostel.update"), onClick: () => openEditRoom(r) },
                { label: "Delete Room", variant: "danger", icon: ACTION_ICONS.delete, hidden: !can("hostel.delete"), onClick: () => handleDeleteRoom(r) },
              ]}
            />
          )}
        />
      </div>

      {roomModal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-sm">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{roomModal.mode === "edit" ? "Edit Room" : "New Room"}</h3>
              <button onClick={() => setRoomModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSaveRoom(); }} className="px-5 py-4 space-y-4">
              <Input label="Room Number" required value={roomForm.room_number} onChange={(e) => setRoomForm((f) => ({ ...f, room_number: e.target.value }))} placeholder="Enter room number" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Capacity" type="number" min={1} required value={roomForm.capacity} onChange={(e) => setRoomForm((f) => ({ ...f, capacity: e.target.value }))} />
                <Input label="Floor" value={roomForm.floor} onChange={(e) => setRoomForm((f) => ({ ...f, floor: e.target.value }))} placeholder="Optional" />
              </div>
              <Select label="Status" value={roomForm.status} onChange={(e) => setRoomForm((f) => ({ ...f, status: e.target.value }))}
                options={[{ value: "available", label: "Available" }, { value: "occupied", label: "Occupied" }, { value: "maintenance", label: "Maintenance" }]} />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={savingRoom}>{roomModal.mode === "edit" ? "Update" : "Create"}</Button>
                <Button type="button" variant="secondary" onClick={() => setRoomModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {studentsModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-lg">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Room {studentsModal.room_number} — Students</h3>
              <button onClick={() => setStudentsModal(null)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <div className="px-5 py-4 max-h-[60vh] overflow-y-auto space-y-4">
              {loadingStudents ? (
                <div className="py-6 text-center"><div className="inline-block animate-spin rounded-full h-5 w-5 border-b-2 border-primary" /></div>
              ) : (
                <div className="divide-y divide-gray-100 border border-gray-200 rounded">
                  {roomStudents.length === 0 ? (
                    <p className="text-sm text-gray-400 py-4 text-center">No students in this room yet.</p>
                  ) : (
                    roomStudents.map((a) => (
                      <div key={a.id} className="flex text-left items-center justify-between px-3 py-2">
                        <div>
                          <p className="text-sm text-gray-900">{a.student?.user?.first_name} {a.student?.user?.last_name}</p>
                          <p className="text-xs text-gray-400">{a.student?.class?.name} {a.student?.section?.name} • {a.student?.admission_number}</p>
                        </div>
                        {can("hostel.update") && <button onClick={() => handleVacate(a.id)} className="text-red-500 hover:underline text-xs">Vacate</button>}
                      </div>
                    ))
                  )}
                </div>
              )}

              {can("hostel.update") && (
                <div className="border-t border-gray-100 pt-4 space-y-3">
                  <p className="text-sm text-left font-semibold text-gray-700">Assign a Student</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <Select label="Class" value={selectedClass} onChange={(e) => { setSelectedClass(e.target.value); setSelectedSection(""); }}
                      options={[{ value: "", label: "Select…" }, ...classes.map((c) => ({ value: c.id, label: c.name }))]} />
                    <Select label="Section" value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} disabled={!selectedClass}
                      options={[{ value: "", label: "All sections" }, ...sections.map((s) => ({ value: s.id, label: s.name }))]} />
                  </div>
                  <Select label="Student" searchable disabled={!selectedClass} value={assignForm.student_id} onChange={(e) => setAssignForm((f) => ({ ...f, student_id: e.target.value }))}
                    options={[{ value: "", label: "Select…" }, ...classStudents.map((s) => ({ value: s.id, label: `${s.user?.first_name} ${s.user?.last_name} (${s.admission_number})${alreadyInRoomIds.has(s.id) ? " — already here" : ""}` }))]} />
                  <NumberInput label="Fee (TZS)" value={assignForm.fee} onChange={(e) => setAssignForm((f) => ({ ...f, fee: e.target.value }))} placeholder="Optional — for reference only" />
                  <div className="flex justify-end gap-3 pt-1">
                    <Button onClick={handleAssign} loading={assigning}>Assign</Button>
                    <Button variant="secondary" onClick={() => setStudentsModal(null)}>Close</Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmDeleteRoom.isOpen} title="Delete Room" message={`Delete room "${confirmDeleteRoom.room_number}"?`} variant="danger" onConfirm={confirmDeleteRoomAction} onClose={() => setConfirmDeleteRoom({ isOpen: false })} />
      <ConfirmModal isOpen={confirmVacate.isOpen} title="Vacate Student" message="Remove this student from the room?" variant="danger" onConfirm={confirmVacateStudent} onClose={() => setConfirmVacate({ isOpen: false })} />
    </MainLayout>
  );
}
