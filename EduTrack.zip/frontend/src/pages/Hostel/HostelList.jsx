import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { useCampus } from "../../contexts/CampusContext";
import { hostelService, campusService, staffService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Input, DataTable, ConfirmModal, Button, RowActions, ACTION_ICONS } from "../../components/ui";

export default function HostelList() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { currentCampusId } = useCampus();
  const { showSuccess, showError } = useToast();

  const [hostels, setHostels] = useState([]);
  const [campuses, setCampuses] = useState([]);
  const [wardens, setWardens] = useState([]);
  const [loading, setLoading] = useState(true);

  const [filters, setFilters] = useState({ search: "", type: "", status: "" });
  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({ name: "", type: "boys", warden_id: "", total_rooms: "", address: "", campus_id: "", status: "active" });
  const [saving, setSaving] = useState(false);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false });

  useEffect(() => { fetchHostels(); }, [filters]);
  useEffect(() => {
    campusService.getAll({ limit: 100 }).then((res) => { if (res.success) { setCampuses(res.data); if (res.data.length === 1) setForm((f) => ({ ...f, campus_id: res.data[0].id })); } });
    staffService.getAll({ limit: 200, status: "active" }).then((res) => { if (res.success) setWardens(res.data); });
  }, []);

  const fetchHostels = async () => {
    try {
      setLoading(true);
      const res = await hostelService.getHostels(filters);
      if (res.success) setHostels(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const handleFilterChange = (e) => setFilters((f) => ({ ...f, [e.target.name]: e.target.value }));

  const openCreate = () => {
    setForm({ name: "", type: "boys", warden_id: "", total_rooms: "", address: "", campus_id: currentCampusId || campuses[0]?.id || "", status: "active" });
    setModal({ isOpen: true, mode: "create" });
  };
  const openEdit = (h) => {
    setForm({ name: h.name, type: h.type, warden_id: h.warden_id || "", total_rooms: h.total_rooms || "", address: h.address || "", campus_id: h.campus_id, status: h.status });
    setModal({ isOpen: true, mode: "edit", id: h.id });
  };

  const handleSave = async () => {
    if (!form.name || !form.campus_id) { showError("Name and campus are required"); return; }
    try {
      setSaving(true);
      const payload = { ...form, total_rooms: form.total_rooms ? Number(form.total_rooms) : null };
      if (modal.mode === "edit") await hostelService.updateHostel(modal.id, payload);
      else await hostelService.createHostel(payload);
      showSuccess(modal.mode === "edit" ? "Hostel updated" : "Hostel created");
      setModal({ isOpen: false });
      fetchHostels();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (h) => { setConfirmModal({ isOpen: true, id: h.id, title: "Delete Hostel", message: `Delete "${h.name}"?` }); };
  const confirmDelete = async () => {
    try {
      await hostelService.deleteHostel(confirmModal.id);
      showSuccess("Hostel deleted");
      fetchHostels();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmModal({ isOpen: false });
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Hostels</h1>
            <p className="text-sm text-gray-500 mt-0.5">Boarding houses, rooms, and student assignments</p>
          </div>
          {can("hostel.create") && (
            <Button variant="primary" onClick={openCreate}>New Hostel</Button>
          )}
        </div>

        <div className="bg-white p-5 rounded shadow">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input label="Search" name="search" value={filters.search} onChange={handleFilterChange} placeholder="Search by name…" />
            <Select label="Type" name="type" value={filters.type} onChange={handleFilterChange} options={[{ value: "", label: "All Types" }, { value: "boys", label: "Boys" }, { value: "girls", label: "Girls" }, { value: "mixed", label: "Mixed" }]} />
            <Select label="Status" name="status" value={filters.status} onChange={handleFilterChange} options={[{ value: "", label: "All Statuses" }, { value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }]} />
          </div>
        </div>

        <DataTable
          columns={[
            { key: "name", label: "Hostel", render: (h) => <span className="text-sm font-medium text-gray-900">{h.name}</span> },
            { key: "type", label: "Type", render: (h) => <span className="text-sm text-gray-600 capitalize">{h.type}</span> },
            { key: "warden", label: "Warden", render: (h) => <span className="text-sm text-gray-600">{h.warden ? `${h.warden.first_name} ${h.warden.last_name}` : "—"}</span> },
            { key: "rooms", label: "Rooms", render: (h) => <span className="text-sm text-gray-700">{h.room_count}</span> },
            {
              key: "occupancy", label: "Occupancy",
              render: (h) => <span className={`text-sm font-medium ${h.total_capacity && h.total_occupied >= h.total_capacity ? "text-red-600" : "text-gray-700"}`}>{h.total_occupied} / {h.total_capacity || "—"}</span>,
            },
            {
              key: "status", label: "Status", align: "center",
              // Same pill treatment as every other module: rounded-full with
              // a matching border, not a square chip.
              render: (h) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${h.status === "active" ? "bg-green-100 border border-green-300 text-green-500" : "bg-red-100 border border-red-300 text-red-500"}`}>
                  {h.status}
                </span>
              ),
            },
          ]}
          data={hostels}
          loading={loading}
          emptyMessage="No hostels found"
          renderActions={(h) => (
            <RowActions
              actions={[
                { label: "Manage Rooms", variant: "primary", icon: ACTION_ICONS.view, hidden: !can("hostel.update"), onClick: () => navigate(`/hostel/${h.id}/rooms`) },
                { label: "Edit Hostel", icon: ACTION_ICONS.edit, hidden: !can("hostel.update"), onClick: () => openEdit(h) },
                { label: "Delete Hostel", variant: "danger", icon: ACTION_ICONS.delete, hidden: !can("hostel.delete"), onClick: () => handleDelete(h) },
              ]}
            />
          )}
        />
      </div>

      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Hostel" : "New Hostel"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <Input label="Hostel Name" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Enter hostel name" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Select label="Type" required value={form.type} onChange={(e) => setForm((f) => ({ ...f, type: e.target.value }))} options={[{ value: "boys", label: "Boys" }, { value: "girls", label: "Girls" }, { value: "mixed", label: "Mixed" }]} />
                <Input label="Total Rooms (est.)" type="number" min={0} value={form.total_rooms} onChange={(e) => setForm((f) => ({ ...f, total_rooms: e.target.value }))} placeholder="Enter total rooms" />
              </div>
              <Select label="Warden" value={form.warden_id} onChange={(e) => setForm((f) => ({ ...f, warden_id: e.target.value }))}
                options={[{ value: "", label: "Not assigned" }, ...wardens.map((s) => ({ value: s.user?.id, label: `${s.user?.first_name} ${s.user?.last_name}` }))]} />
              <Input label="Address" value={form.address} onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))} placeholder="Enter address" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {campuses.length > 0 && (
                  <Select label="Campus" required value={form.campus_id} onChange={(e) => setForm((f) => ({ ...f, campus_id: e.target.value }))}
                    options={[{ value: "", label: "Select…" }, ...campuses.map((c) => ({ value: c.id, label: c.name }))]} />
                )}
                <Select label="Status" value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))} options={[{ value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }]} />
              </div>
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Create"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmModal.isOpen} title={confirmModal.title} message={confirmModal.message} variant="danger" onConfirm={confirmDelete} onClose={() => setConfirmModal({ isOpen: false })} />
    </MainLayout>
  );
}
