// frontend/src/pages/Analytics/Analytics.jsx
import { useState, useEffect } from "react";
import { useToast } from "../../contexts/ToastContext";
import { analyticsService } from "../../services/api";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import MainLayout from "../../components/MainLayout";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from "recharts";
import { formatMoney } from "../../utils/money";


const PIE_COLORS = ["#6366f1", "#22c55e", "#f59e0b", "#ef4444", "#06b6d4", "#a855f7", "#ec4899"];
const MONTH_NAMES = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function StatCard({ label, value, sub, accent = "text-primary" }) {
  return (
    <div className="bg-white p-5 rounded shadow text-left">
      <p className="text-sm text-gray-600">{label}</p>
      <p className={`text-2xl font-bold mt-1 ${accent}`}>{value}</p>
      {sub && <p className="text-xs text-gray-400 mt-0.5">{sub}</p>}
    </div>
  );
}

function SectionCard({ title, children }) {
  return (
    <div className="bg-white rounded shadow p-5">
      <h2 className="text-base font-semibold text-gray-900 mb-4 text-left">{title}</h2>
      {children}
    </div>
  );
}

export default function Analytics() {
  const { showError } = useToast();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { currentAcademicYear } = useAcademicYear();

  useEffect(() => {
    analyticsService.getDashboard({ academic_year: currentAcademicYear })
      .then((res) => { if (res.success) setData(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
    // Re-fetch on year change; the whole dashboard is scoped to it.
  }, [currentAcademicYear]);

  if (loading) return <MainLayout><div className="bg-white p-16 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div></MainLayout>;
  if (!data) return <MainLayout><div className="bg-white p-16 rounded shadow text-center text-gray-400">Could not load analytics.</div></MainLayout>;

  const { overview, academic, financial, operations, period } = data;

  const attendanceChart = (academic.attendance_trend || []).map((d) => ({ ...d, label: d.date.slice(5) }));
  const expensePie = financial.expense_by_category || [];

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="text-left">
          <h1 className="text-xl font-bold text-gray-900">Analytics</h1>
          <p className="text-sm text-gray-500 mt-0.5">A live snapshot across every module</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard label="Active Students" value={overview.total_students} />
          <StatCard label="Active Staff" value={overview.total_staff} />
          <StatCard label="Classes" value={overview.total_classes} />
          <StatCard label="Pending Leave Requests" value={overview.pending_leave_requests} accent={overview.pending_leave_requests > 0 ? "text-amber-600" : "text-primary"} />
        </div>

        <SectionCard title="Academic">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 space-y-4">
              <StatCard label="Attendance Rate (30 days)" value={academic.attendance_rate_30d !== null ? `${academic.attendance_rate_30d}%` : "—"} />
              <StatCard
                label={academic.latest_exam ? `Latest Exam: ${academic.latest_exam.name}` : "Latest Exam"}
                value={academic.latest_exam?.average_percent !== null && academic.latest_exam?.average_percent !== undefined ? `${academic.latest_exam.average_percent}%` : "—"}
                sub={academic.latest_exam ? `Term ${academic.latest_exam.term}` : "No completed exam yet"}
              />
            </div>
            <div className="lg:col-span-2">
              <p className="text-xs text-gray-500 mb-2">Attendance — last 14 days</p>
              {attendanceChart.length === 0 ? (
                <p className="text-sm text-gray-400 py-10 text-center">No attendance data yet.</p>
              ) : (
                <ResponsiveContainer width="100%" height={220}>
                  <LineChart data={attendanceChart}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="present" stroke="#22c55e" name="Present" strokeWidth={2} />
                    <Line type="monotone" dataKey="absent" stroke="#ef4444" name="Absent" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Financial">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 space-y-4">
              <StatCard label="Fees Collected (YTD)" value={formatMoney(financial.fees_collected_ytd)} sub={financial.fee_collection_rate !== null ? `${financial.fee_collection_rate}% of expected` : undefined} />
              {/* Named after the month it actually covers. On a closed year
                  this is December, not the calendar month we're in now. */}
              <StatCard label={`Expenses — ${period?.month_label || "This Month"}`} value={formatMoney(financial.expenses_this_month)} accent="text-red-600" />
              <StatCard label="Latest Payroll" value={financial.latest_payroll ? `${MONTH_NAMES[financial.latest_payroll.month]} ${financial.latest_payroll.year}` : "—"} sub="Last period paid" />
            </div>
            <div className="lg:col-span-2">
              <p className="text-xs text-gray-500 mb-2">Expenses by category (this year)</p>
              {expensePie.length === 0 ? (
                <p className="text-sm text-gray-400 py-10 text-center">No expenses recorded yet.</p>
              ) : (
                <ResponsiveContainer width="100%" height={240}>
                  <PieChart>
                    <Pie data={expensePie} dataKey="total" nameKey="category" cx="50%" cy="50%" outerRadius={80} label={(entry) => entry.category}>
                      {expensePie.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                    </Pie>
                    <Tooltip formatter={(v) => formatMoney(v)} />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Operations">
          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            <StatCard label="Transport Occupancy" value={operations.transport.occupancy_rate !== null ? `${operations.transport.occupancy_rate}%` : "—"} sub={`${operations.transport.occupied} of ${operations.transport.capacity || "—"} seats`} />
            <StatCard label="Library — Issued" value={operations.library.currently_issued} sub={`${operations.library.overdue} overdue`} accent={operations.library.overdue > 0 ? "text-red-600" : "text-primary"} />
            <StatCard label="Hostel Occupancy" value={operations.hostel.occupancy_rate !== null ? `${operations.hostel.occupancy_rate}%` : "—"} sub={`${operations.hostel.occupied} of ${operations.hostel.capacity || "—"} beds`} />
            <StatCard label="Low Stock Items" value={operations.inventory.low_stock} sub={`of ${operations.inventory.total_items} tracked`} accent={operations.inventory.low_stock > 0 ? "text-amber-600" : "text-primary"} />
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={[
              { name: "Transport", occupied: operations.transport.occupied, capacity: operations.transport.capacity },
              { name: "Hostel", occupied: operations.hostel.occupied, capacity: operations.hostel.capacity },
            ]}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="capacity" fill="#e5e7eb" name="Capacity" />
              <Bar dataKey="occupied" fill="#6366f1" name="Occupied" />
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>
      </div>
    </MainLayout>
  );
}