import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../contexts/ToastContext';
import { attendanceService, classService, studentService } from '../../services/api';
import { useYearAwareClasses } from '../../hooks/useYearAwareClasses';
import { useAcademicYear } from '../../contexts/AcademicYearContext';
import MainLayout from '../../components/MainLayout';
import { Select, Input, Button, DatePicker, DataTable } from '../../components/ui';

// ─── Constants ────────────────────────────────────────────────────────────────

const todayDate = new Date().toISOString().split('T')[0];

const QUICK_MARKS = [
  {
    key: 'present', label: 'P', title: 'Present',
    active: 'bg-green-100 text-green-500 border border-green-300',
    inactive: 'bg-gray-100 text-gray-500 hover:bg-green-50 hover:text-green-600 hover:ring-1 hover:ring-green-200'
  },
  {
    key: 'absent', label: 'A', title: 'Absent',
    active: 'bg-red-100 text-red-500 border border-red-300',
    inactive: 'bg-gray-100 text-gray-500 hover:bg-red-50 hover:text-red-600 hover:ring-1 hover:ring-red-200'
  },
  {
    key: 'excused', label: 'E', title: 'Excused',
    active: 'bg-primary-20 text-primary border border-primary-30',
    inactive: 'bg-gray-100 text-gray-500 hover:bg-primary-30 hover:text-primary hover:ring-1 hover:ring-primary'
  },
  {
    key: 'late', label: 'L', title: 'Late',
    active: 'bg-yellow-100 text-yellow-500 border border-yellow-300',
    inactive: 'bg-gray-100 text-gray-500 hover:bg-yellow-50 hover:text-yellow-600 hover:ring-1 hover:ring-yellow-200'
  },
  {
    key: 'half_day', label: 'H', title: 'Half Day',
    active: 'bg-purple-100 text-purple-500 border border-purple-300',
    inactive: 'bg-gray-100 text-gray-500 hover:bg-purple-50 hover:text-purple-600 hover:ring-1 hover:ring-purple-200'
  },
];

const STATUS_COLORS = {
  present: 'bg-green-100 border border-green-300 text-green-500 font-semibold',
  absent: 'bg-red-100 border border-red-300 text-red-500 font-semibold',
  late: 'bg-yellow-100 border border-yellow-300 text-yellow-500 font-semibold',
  excused: 'bg-primary-15 border border-primary-30 text-primary font-semibold',
  half_day: 'bg-purple-100 border border-purple-300 text-purple-500 font-semibold',
};

const SUMMARY_ITEMS = [
  { key: 'present', color: 'bg-green-100 border border-green-300', label: 'Present' },
  { key: 'absent', color: 'bg-red-100 border border-green-300', label: 'Absent' },
  { key: 'excused', color: 'bg-primary-15 border border-green-300', label: 'Excused' },
  { key: 'late', color: 'bg-yellow-100 border border-green-300', label: 'Late' },
  { key: 'half_day', color: 'bg-purple-100 border border-green-300', label: 'Half Day' },
];

// ─── Component ────────────────────────────────────────────────────────────────

export default function AttendanceTake() {
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();

  const [form, setForm] = useState({ date: todayDate, class_id: '', section_id: '' });

  // A teacher who has switched the header to a past year would otherwise
  // pick a class from that year, mark a full register, and only then be
  // told the date is rejected.
  const { currentAcademicYear } = useAcademicYear();
  const selectedBaseYear = parseInt(String(currentAcademicYear || '').match(/\d{4}/)?.[0], 10);
  const isClosedYear = Boolean(selectedBaseYear) && selectedBaseYear !== new Date().getFullYear();
  const [sections, setSections] = useState([]);
  const [students, setStudents] = useState([]);
  const [studentsLoading, setStudentsLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Options refresh for the currently selected year automatically; a
  // stale selection from a previous year is re-mapped onto that same
  // class's row for the new year (see hooks/useYearAwareClasses.js).
  const classes = useYearAwareClasses({
    selectedClassId: form.class_id,
    onRemap: (newClassId) => setForm((f) => ({ ...f, class_id: newClassId, section_id: '' })),
  });

  const loadStudents = async (classId, sectionId) => {
    if (!classId) return;
    try {
      setStudentsLoading(true);
      const params = { class_id: classId, limit: 300, status: 'active' };
      if (sectionId) params.section_id = sectionId;
      const r = await studentService.getAll(params);
      if (r.success) {
        setStudents(
          r.data.map((s) => ({
            student_id: s.id,
            name: `${s.user?.first_name || ''} ${s.user?.last_name || ''}`.trim(),
            admission_number: s.admission_number,
            status: 'present',
            remarks: '',
          }))
        );
      }
    } catch {
    } finally {
      setStudentsLoading(false);
    }
  };

  // ── Handlers ──────────────────────────────────────────────────────────────
  const handleClassChange = async (classId) => {
    setForm((f) => ({ ...f, class_id: classId, section_id: '' }));
    setSections([]);
    setStudents([]);
    if (!classId) return;
    try {
      const r = await classService.getById(classId);
      const classSections = r.success ? r.data.sections || [] : [];
      setSections(classSections);
      // Classes with sections must be taken per-section (not for the whole
      // class), so only auto-load the roster when there's nothing to split by.
      if (classSections.length === 0) await loadStudents(classId, '');
    } catch { }
  };

  const handleSectionChange = async (sectionId) => {
    setForm((f) => ({ ...f, section_id: sectionId }));
    await loadStudents(form.class_id, sectionId);
  };

  const setStudentStatus = (idx, status) =>
    setStudents((prev) => prev.map((s, i) => (i === idx ? { ...s, status } : s)));
  const setStudentRemarks = (idx, remarks) =>
    setStudents((prev) => prev.map((s, i) => (i === idx ? { ...s, remarks } : s)));
  const markAll = (status) =>
    setStudents((prev) => prev.map((s) => ({ ...s, status })));

  const handleSubmit = async () => {
    if (!form.class_id) return showError('Please select a class');
    if (!form.date) return showError('Please select a date');
    // Mirrors the server-side guard, so the problem is caught before a
    // teacher has finished marking a whole class.
    if (form.date.slice(0, 4) !== String(new Date().getFullYear())) {
      return showError(`Attendance can only be taken for ${new Date().getFullYear()}. Closed years can't be back-filled.`);
    }
    if (form.date > todayDate) return showError("Attendance can't be taken for a future date.");
    if (sections.length > 0 && !form.section_id) return showError('This class has sections — please select a section');
    if (students.length === 0) return showError('No students found in this class');
    try {
      setSubmitting(true);
      const payload = {
        class_id: form.class_id,
        date: form.date,
        attendance_records: students.map((s) => ({
          student_id: s.student_id,
          status: s.status,
          remarks: s.remarks || null,
        })),
      };
      if (form.section_id) payload.section_id = form.section_id;

      const response = await attendanceService.bulkMark(payload);
      if (response.success) {
        showSuccess(`Attendance saved for ${students.length} student(s)`);
        navigate('/attendance');
      }
    } catch (err) {
      showError(err.message || 'Failed to save attendance');
    } finally {
      setSubmitting(false);
    }
  };

  // ── Derived ───────────────────────────────────────────────────────────────
  const statusCounts = students.reduce((acc, s) => {
    acc[s.status] = (acc[s.status] || 0) + 1;
    return acc;
  }, {});

  const tableRows = students.map((student, index) => ({
    ...student,
    row_number: index + 1,
  }));

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <MainLayout>
      <div className="space-y-4">

        {isClosedYear && (
          <div className="bg-white border border-primary-20 rounded px-4 py-3 text-sm text-left text-gray-400">
            You are viewing <strong>{currentAcademicYear}</strong>, but attendance can only be recorded for
            the current year ({new Date().getFullYear()}). Switch the year in the header to take a register.
          </div>
        )}

        {/* ── Page Header ── */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Take Attendance</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              Select a class and mark attendance for each student
            </p>
          </div>
          <Button
            variant="lightPrimary"
            onClick={() => navigate('/attendance')}
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to List
          </Button>
        </div>

        {/* ── Session Setup ── */}
        <div className="bg-white rounded shadow">
          <div className="px-5 py-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <DatePicker
                label="Attendance Date"
                name="date"
                value={form.date}
                min={`${new Date().getFullYear()}-01-01`}
                max={todayDate}
                onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))}
                required
              />
              <Select
                label="Class"
                value={form.class_id}
                onChange={(e) => handleClassChange(e.target.value)}
                options={classes.map((c) => ({ value: c.id, label: c.name }))}
                placeholder="Select a class..."
                searchable
                required
              />
              {sections.length > 0 && (
                <Select
                  label="Section / Stream"
                  value={form.section_id}
                  onChange={(e) => handleSectionChange(e.target.value)}
                  options={sections.map((s) => ({ value: s.id, label: s.name }))}
                  placeholder="Select a section..."
                  required
                />
              )}
            </div>
          </div>
        </div>

        {/* ── Loading State ── */}
        {studentsLoading && (
          <div className="bg-white rounded shadow px-5 py-14 text-center">
            <div className="inline-block animate-spin rounded-full h-10 w-10 border-b-2 border-primary mb-3"></div>
            <p className="text-sm text-gray-500 font-medium">Loading students...</p>
          </div>
        )}

        {/* ── Empty: no class selected ── */}
        {!studentsLoading && !form.class_id && (
          <div className="bg-white rounded shadow px-5 py-20 text-center">
            <div className="w-16 h-16 bg-primary-10 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-secondary opacity-60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                  d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              Select a class above to load the student roster
            </p>
          </div>
        )}

        {/* ── Empty: class selected but no students ── */}
        {!studentsLoading && form.class_id && sections.length > 0 && !form.section_id && (
          <div className="bg-white rounded shadow px-5 py-20 text-center">
            <div className="w-16 h-16 bg-primary-10 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-secondary opacity-60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                  d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              This class has sections — select a section above to load its roster
            </p>
          </div>
        )}

        {/* ── Empty: class/section selected but no students ── */}
        {!studentsLoading && form.class_id && (sections.length === 0 || form.section_id) && students.length === 0 && (
          <div className="bg-white rounded shadow px-5 py-12 text-center">
            <p className="text-sm text-gray-500">No active students found in this class/section.</p>
          </div>
        )}

        {/* ── Student Roster ── */}
        {!studentsLoading && students.length > 0 && (
          <div className="bg-white rounded shadow">

            {/* Quick mark all bar */}
            <div className="px-5 py-3 bg-primary-10 border-b border-primary-15">
              <div className="flex flex-wrap items-center gap-3">
                <span className="text-xs font-semibold text-gray-700 mr-1">Mark all as:</span>
                {[
                  { status: 'present', init: 'P', label: 'Present', color: 'green', cls: 'bg-green-100 text-green-700 hover:bg-green-200 border border-green-300' },
                  { status: 'absent', init: 'A', label: 'Absent', color: 'red', cls: 'bg-red-100 text-red-700 hover:bg-red-200 border border-red-300' },
                  { status: 'excused', init: 'E', label: 'Excused', cls: 'bg-primary-15 text-primary hover:bg-primary-25 border border-primary-30' },
                  { status: 'late', init: 'L', label: 'Late', color: 'yellow', cls: 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200 border border-yellow-300' },
                  { status: 'half_day', init: 'H', label: 'Half Day', color: 'purple', cls: 'bg-purple-100 text-purple-700 hover:bg-purple-200 border border-purple-300' },
                ].map((item) => (
                  <div key={item.status} className="flex items-center gap-1.5">
                    <span className={`text-xs font-semibold ${item.color ? `text-${item.color}-700` : 'text-primary'}`}>{item.init}</span>
                    <button
                      key={item.status}
                      type="button"
                      onClick={() => markAll(item.status)}
                      className={`text-xs px-3 py-1.5 rounded font-medium transition-colors ${item.cls}`}
                    >
                      {item.label}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Student table */}
            <DataTable
              columns={[
                {
                  key: 'row_number',
                  label: '#',
                  width: 'w-10',
                  render: (row) => <span className="text-sm text-gray-400 font-medium">{row.row_number}</span>,
                },
                {
                  key: 'student',
                  label: 'Student',
                  width: 'w-1/5',
                  render: (row) => (
                    <div>
                      <p className="text-sm text-gray-900">{row.name}</p>
                      <p className="text-xs text-gray-500">{row.admission_number}</p>
                    </div>
                  ),
                },
                {
                  key: 'status',
                  label: 'Status',
                  width: 'w-1/4',
                  render: (row) => (
                    <div className="flex items-center gap-2 flex-wrap">
                      {QUICK_MARKS.map((opt) => (
                        <button
                          key={opt.key}
                          type="button"
                          title={opt.title}
                          onClick={() => setStudentStatus(row.row_number - 1, opt.key)}
                          className={`w-8 h-8 text-xs font-bold rounded transition-all duration-100 ${row.status === opt.key ? opt.active : opt.inactive}`}
                        >
                          {opt.label}
                        </button>
                      ))}
                      <span className={`ml-1 text-xs px-2.5 py-1 rounded-full font-medium capitalize ${STATUS_COLORS[row.status] || 'bg-gray-100 text-gray-600'}`}>
                        {row.status.replace('_', ' ')}
                      </span>
                    </div>
                  ),
                },
                {
                  key: 'remarks',
                  label: 'Remarks',
                  width: 'w-auto',
                  render: (row) => (
                    <Input
                      value={row.remarks}
                      onChange={(e) => setStudentRemarks(row.row_number - 1, e.target.value)}
                      placeholder="Optional note..."
                    />
                  ),
                },
              ]}
              data={tableRows}
              emptyMessage="No students found in this class/section."
            />

            {/* Footer — summary + submit */}
            <div className="px-5 py-2 border-t border-gray-200 bg-gray-50">
              <div className="flex flex-wrap items-center justify-between gap-4">
                {/* Status summary */}
                <div className="flex flex-wrap items-center gap-4">
                  {SUMMARY_ITEMS.filter((item) => statusCounts[item.key] > 0).map((item) => (
                    <span key={item.key} className="flex items-center gap-1.5 text-xs text-gray-600">
                      <span className={`w-4 h-4 rounded-full ${item.color}`}></span>
                      <span>{item.label}:</span>
                      <span className="font-bold text-gray-900">{statusCounts[item.key]}</span>
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-3">
                  <Button variant="secondary" onClick={() => navigate('/attendance')}>
                    Cancel
                  </Button>
                  <Button onClick={handleSubmit} loading={submitting}>
                    Save Attendance ({students.length})
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </MainLayout>
  );
}
