﻿import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { usePreferences } from '../../contexts/PreferencesContext';
import { attendanceService, classService } from '../../services/api';
import { useYearAwareClasses } from '../../hooks/useYearAwareClasses';
import { useAcademicYear } from '../../contexts/AcademicYearContext';
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from '../../components/MainLayout';
import { Select, Button, DataTable, DatePicker, Input, ActionLink } from '../../components/ui';

const todayDate = new Date().toISOString().split('T')[0];

// ====== Component =============================================================

export default function AttendanceList() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showError } = useToast();
  const { formatDate } = usePreferences();
  const { currentAcademicYear } = useAcademicYear();

  const yearBounds = (() => {
    const base = parseInt(String(currentAcademicYear || '').match(/\d{4}/)?.[0], 10);
    if (!base) return null;
    return { start: `${base}-01-01`, end: `${base}-12-31`, base };
  })();

  const [sessions, setSessions] = useState([]);
  const [filterSections, setFilterSections] = useState([]);
  const [todayStats, setTodayStats] = useState({ present: 0, absent: 0, excused: 0, total: 0 });
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ date_from: '', date_to: '', class_id: '', section_id: '' });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 10 });

  // Options refresh for the currently selected year automatically; a
  // stale selection from a previous year is re-mapped onto that same
  // class's row for the new year (see hooks/useYearAwareClasses.js).
  const classes = useYearAwareClasses({
    selectedClassId: filters.class_id,
    onRemap: (newClassId) => setFilters((f) => ({ ...f, class_id: newClassId })),
  });

  // ====== Lifecycle ===========================================================
  useEffect(() => {
    fetchTodayStats();
  }, []);

  useEffect(() => {
    fetchSessions();
  }, [filters, pagination.currentPage, currentAcademicYear]);

  // A date filter left over from another year would fall outside the new
  // bounds and quietly return nothing.
  useEffect(() => {
    setFilters((f) => (f.date_from || f.date_to ? { ...f, date_from: '', date_to: '' } : f));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  }, [currentAcademicYear]);

  // ====== fetchers ============================================================
  const fetchSessions = async () => {
    try {
      setLoading(true);
      // The year is the outer bound; any date filter the user sets narrows
      // within it, and can never reach outside it.
      const response = await attendanceService.getSessions({
        ...filters,
        date_from: filters.date_from && filters.date_from > yearBounds?.start ? filters.date_from : yearBounds?.start,
        date_to: filters.date_to && filters.date_to < yearBounds?.end ? filters.date_to : yearBounds?.end,
        page: pagination.currentPage,
        limit: pagination.itemsPerPage,
      });
      if (response.success) {
        setSessions(response.data);
        setPagination((p) => ({
          ...p,
          totalItems: response.count || 0,
          totalPages: response.totalPages || 1,
          currentPage: response.currentPage || p.currentPage,
        }));
      }
    } catch (err) {
      showError(err.message || 'Failed to fetch attendance sessions');
    } finally {
      setLoading(false);
    }
  };

  const fetchTodayStats = async () => {
    try {
      const response = await attendanceService.getSessions({
        date_from: todayDate, date_to: todayDate, limit: 200,
      });
      if (response.success) {
        const totals = response.data.reduce(
          (acc, s) => {
            acc.present += s.present;
            acc.absent += s.absent;
            acc.excused += s.excused;
            acc.total += s.total;
            return acc;
          },
          { present: 0, absent: 0, excused: 0, total: 0 }
        );
        setTodayStats(totals);
      }
    } catch { }
  };

  // ====== Filter handlers ============================================================
  const handleFilterChange = async (name, value) => {
    if (name === 'class_id') {
      setFilters((f) => ({ ...f, class_id: value, section_id: '' }));
      setFilterSections([]);
      if (value) {
        try {
          const r = await classService.getById(value);
          if (r.success) setFilterSections(r.data.sections || []);
        } catch { }
      }
    } else {
      setFilters((f) => ({ ...f, [name]: value }));
    }
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const resetFilters = () => {
    setFilters({ date_from: '', date_to: '', class_id: '', section_id: '' });
    setFilterSections([]);
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  // ====== Derived ============================================================
  const canMark = can("attendance.create");
  const attendanceRate = todayStats.total > 0
    ? Math.round((todayStats.present / todayStats.total) * 100)
    : 0;

  // ====== Render ============================================================
  return (
    <MainLayout>
      <div className="space-y-4">

        {/* ====== Page Header ====== */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Attendance Management</h1>
            <p className="text-sm text-gray-500 mt-0.5">Track and manage student attendance by class session</p>
          </div>
          {canMark && (
            <ActionLink to="/attendance/take" variant="primary">Take Attendance</ActionLink>
          )}
        </div>

        {/* ====== Stats Cards ====== */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Present Today</p>
                <p className="text-2xl text-left font-bold text-green-600 mt-1">{todayStats.present}</p>
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg className="w-8 h-8 text-green-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Absent Today</p>
                <p className="text-2xl text-left font-bold text-red-600 mt-1">{todayStats.absent}</p>
              </div>
              <div className="bg-red-100 p-3 rounded">
                <svg className="w-8 h-8 text-red-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Excused Today</p>
                <p className="text-2xl text-left font-bold text-yellow-600 mt-1">{todayStats.excused}</p>
              </div>
              <div className="bg-yellow-100 p-3 rounded">
                <svg className="w-8 h-8 text-yellow-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Today's Rate</p>
                <p className="text-2xl text-left font-bold text-primary mt-1">{attendanceRate}%</p>
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* ====== Filters ====== */}
        <div className="bg-white p-5 rounded shadow">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 items-end">
            <Select
              label="Class"
              value={filters.class_id}
              onChange={(e) => handleFilterChange('class_id', e.target.value)}
              options={classes.map((c) => ({ value: c.id, label: c.name }))}
              placeholder="All Classes"
              searchable
            />
            {filterSections.length > 0 &&
              <Select
                label="Section"
                value={filters.section_id}
                onChange={(e) => handleFilterChange('section_id', e.target.value)}
                options={filterSections.map((s) => ({ value: s.id, label: s.name }))}
                placeholder="All Sections"
              />
            }
            <DatePicker
              label="Date From"
              name="date_from"
              value={filters.date_from}
              min={yearBounds?.start}
              max={yearBounds?.end}
              onChange={(e) => handleFilterChange('date_from', e.target.value)}
              placeholder="From date"
            />
            <DatePicker
              label="Date To"
              name="date_to"
              value={filters.date_to}
              min={yearBounds?.start}
              max={yearBounds?.end}
              onChange={(e) => handleFilterChange('date_to', e.target.value)}
              placeholder="To date"
            />
            {filterSections.length > 0 &&
              <div className="flex gap-2">
                <Button onClick={fetchSessions} className="flex-1">Apply</Button>
                <Button variant="secondary" onClick={resetFilters}>Reset</Button>
              </div>
            }
            {!filterSections.length > 0 &&
              <>
                <Button onClick={fetchSessions} className="flex-1">Apply</Button>
                <Button variant="secondary" onClick={resetFilters}>Reset</Button>
              </>
            }
          </div>
        </div>

        {/* ====== Sessions DataTable ====== */}
        <DataTable
          columns={[
            {
              key: 'date',
              label: 'Date',
              render: (row) => (
                <div>
                  <p className="text-sm text-gray-900">
                    {formatDate(row.date)}
                  </p>
                </div>
              ),
            },
            {
              key: 'class',
              label: 'Class / Section',
              render: (row) => (
                <div className="flex gap-1">
                  <p className="items-center text-sm text-gray-900">{row.class_name || ''}</p>
                  {row.section_name && (
                    <>
                      <p className="text-sm text-gray-700">-</p>
                      <p className="text-sm text-gray-700">{row.section_name}</p>
                    </>
                  )}
                </div>
              ),
            },
            {
              key: 'total',
              label: 'Total',
              render: (row) => (
                <span className="text-sm text-gray-700">{row.total}</span>
              ),
            },
            {
              key: 'present',
              label: 'Present',
              render: (row) => (
                <span className="px-2.5 py-1 inline-flex text-xs font-semibold rounded-full bg-green-100 border border-green-300 text-green-700">
                  {row.present}
                </span>
              ),
            },
            {
              key: 'absent',
              label: 'Absent',
              render: (row) => (
                <span className="px-2.5 py-1 inline-flex text-xs font-semibold rounded-full bg-red-100 border border-red-300 text-red-700">
                  {row.absent}
                </span>
              ),
            },
            {
              key: 'excused',
              label: 'Excused',
              render: (row) => (
                <span className="px-2.5 py-1 inline-flex text-xs font-semibold rounded-full bg-yellow-100 border border-yellow-300 text-yellow-700">
                  {row.excused}
                </span>
              ),
            },
            {
              key: 'rate',
              label: 'Rate',
              render: (row) => {
                const rate = row.total > 0 ? Math.round((row.present / row.total) * 100) : 0;
                const color = rate >= 90 ? 'text-green-600' : rate >= 75 ? 'text-yellow-600' : 'text-red-600';
                return <span className={`text-sm font-medium ${color}`}>{rate}%</span>;
              },
            },
          ]}
          data={sessions.map((s) => ({
            ...s,
            id: `${s.date}_${s.class_id}_${s.section_id || ''}`,
          }))}
          loading={loading}
          emptyMessage="No attendance found"
          renderActions={(row) => (
            <Button
              onClick={() => {
                const params = new URLSearchParams({ date: row.date, class_id: row.class_id });
                if (row.section_id) params.append('section_id', row.section_id);
                navigate(`/attendance/session?${params.toString()}`);
              }}
              variant="lightPrimary"
              size="xs"
            >
              View
            </Button>
          )}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />

      </div>
    </MainLayout>
  );
}