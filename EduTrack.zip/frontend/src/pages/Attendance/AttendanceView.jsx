﻿import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { usePreferences } from '../../contexts/PreferencesContext';
import { attendanceService } from '../../services/api';
import { useCampus } from '../../contexts/CampusContext';
import {
  pivotClassRegister, daysInMonthList,
  exportClassRegisterPDF, exportClassRegisterExcel,
  exportYearlySummaryPDF, exportYearlySummaryExcel,
} from '../../utils/attendanceExport';
import MainLayout from '../../components/MainLayout';
import { Select, Input, Button, DataTable } from '../../components/ui';

// ====== Constants ============================================================================

const STATUS_OPTIONS = [
  { value: 'present', label: 'Present' },
  { value: 'absent', label: 'Absent' },
  { value: 'excused', label: 'Excused' },
  { value: 'late', label: 'Late' },
  { value: 'half_day', label: 'Half Day' },
];

const STATUS_COLORS = {
  present: 'bg-green-100 border border-green-300 text-green-700',
  absent: 'bg-red-100 border border-red-300 text-red-700',
  excused: 'bg-primary-15 border border-primary-30 text-primary',
  late: 'bg-yellow-100 border border-yellow-300 text-yellow-700',
  half_day: 'bg-purple-100 border border-purple-300 text-purple-700',
};

const SUMMARY_ITEMS = [
  { key: 'present', color: 'bg-green-100 border border-green-300', label: 'Present' },
  { key: 'absent', color: 'bg-red-100 border border-red-300', label: 'Absent' },
  { key: 'excused', color: 'bg-primary-15 border border-primary-30', label: 'Excused' },
  { key: 'late', color: 'bg-yellow-100 border border-yellow-300', label: 'Late' },
  { key: 'half_day', color: 'bg-purple-100 border border-purple-300', label: 'Half Day' },
];

// ====== Component ============================================================================

export default function AttendanceView() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();
  const { currentCampus } = useCampus();

  const date = searchParams.get('date') || '';
  const class_id = searchParams.get('class_id') || '';
  const section_id = searchParams.get('section_id') || '';

  const [records, setRecords] = useState([]);
  const [downloading, setDownloading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({ status: '', remarks: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (date && class_id) fetchRecords();
  }, [date, class_id, section_id]);

  const fetchRecords = async () => {
    try {
      setLoading(true);
      const params = { date_from: date, date_to: date, class_id, limit: 300 };
      if (section_id) params.section_id = section_id;
      const response = await attendanceService.getAll(params);
      if (response.success) setRecords(response.data);
    } catch (err) {
      showError(err.message || 'Failed to fetch session records');
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (record) => {
    setEditingId(record.id);
    setEditForm({ status: record.status, remarks: record.remarks || '' });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({ status: '', remarks: '' });
  };

  const saveEdit = async (recordId) => {
    if (!editForm.status) return showError('Status is required');
    if (!editForm.remarks.trim()) return showError('Remarks are required when updating attendance');
    try {
      setSaving(true);
      const response = await attendanceService.update(recordId, {
        status: editForm.status,
        remarks: editForm.remarks.trim(),
      });
      if (response.success) {
        showSuccess('Record updated');
        setEditingId(null);
        fetchRecords();
      }
    } catch (err) {
      showError(err.message || 'Failed to update record');
    } finally {
      setSaving(false);
    }
  };

  // ====== Downloads ============================================================================
  const handleDownloadMonthRegister = async (format) => {
    if (!class_id || !date) return;
    try {
      setDownloading(true);
      const month = date.slice(0, 7);
      const monthDates = daysInMonthList(month);
      const res = await attendanceService.getAll({
        class_id, section_id: section_id || undefined,
        date_from: monthDates[0], date_to: monthDates[monthDates.length - 1], limit: 20000,
      });
      if (!res.success || (res.data || []).length === 0) {
        showError('No attendance records found for that class and month');
        return;
      }
      const pivoted = pivotClassRegister(res.data, { fullDates: monthDates });
      const mLabel = new Date(Number(month.slice(0, 4)), Number(month.slice(5, 7)) - 1, 1)
        .toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
      const filename = `Attendance_Register_${className}${sectionName ? `_${sectionName}` : ''}_${month}`.replace(/\s+/g, '_');
      const args = { school: currentCampus, className, sectionName, monthLabel: mLabel, pivoted, filename };
      if (format === 'pdf') await exportClassRegisterPDF(args);
      else await exportClassRegisterExcel(args);
      showSuccess('Register downloaded');
    } catch (err) {
      showError(err.message || 'Failed to download register');
    } finally {
      setDownloading(false);
    }
  };

  const handleDownloadYear = async (format) => {
    if (!class_id || !date) return;
    try {
      setDownloading(true);
      const year = date.slice(0, 4);
      const res = await attendanceService.getAll({
        class_id, section_id: section_id || undefined,
        date_from: `${year}-01-01`, date_to: `${year}-12-31`, limit: 50000,
      });
      if (!res.success || (res.data || []).length === 0) {
        showError('No attendance records found for that class this year');
        return;
      }
      const filename = `Attendance_Yearly_${className}${sectionName ? `_${sectionName}` : ''}_${year}`.replace(/\s+/g, '_');
      const args = { school: currentCampus, className, sectionName, year, records: res.data, filename };
      if (format === 'pdf') await exportYearlySummaryPDF(args);
      else await exportYearlySummaryExcel(args);
      showSuccess('Yearly attendance downloaded');
    } catch (err) {
      showError(err.message || 'Failed to download yearly attendance');
    } finally {
      setDownloading(false);
    }
  };

  // ====== Derived ============================================================================
  const stats = records.reduce(
    (acc, r) => {
      acc.total += 1;
      acc[r.status] = (acc[r.status] || 0) + 1;
      return acc;
    },
    { total: 0, present: 0, absent: 0, late: 0, excused: 0, half_day: 0 }
  );

  const rate = stats.total > 0 ? Math.round((stats.present / stats.total) * 100) : 0;
  const rateColor = rate >= 90 ? 'green' : rate >= 75 ? 'yellow' : 'red';
  const className = records[0]?.class?.name || '';
  const sectionName = records[0]?.section?.name || '';
  const canEdit = can("attendance.update");
  const formatMarkerName = (marker) => (marker ? `${marker.first_name} ${marker.last_name}`.trim() : '---');
  const isAttendanceModified = (row) => {
    const created = row.created_at || row.createdAt;
    const updated = row.updated_at || row.updatedAt;

    if (created && updated) {
      return new Date(updated).getTime() > new Date(created).getTime();
    }

    const initialMarkerId = row.initial_marked_by || row.initialMarkedBy;
    const latestMarkerId = row.latest_marked_by || row.latestMarkedBy;
    return Boolean(initialMarkerId && latestMarkerId && initialMarkerId !== latestMarkerId);
  };
  const tableRows = records.map((record, index) => ({
    ...record,
    row_number: index + 1,
  }));
  const hasModifiedRecords = tableRows.some((row) => isAttendanceModified(row));

  const tableColumns = [
    {
      key: 'row_number',
      label: '#',
      width: 'w-10',
      render: (row) => <span className="text-sm text-gray-400 font-medium">{row.row_number}</span>,
    },
    {
      key: 'student',
      label: 'Student',
      width: 'w-1/5',
      render: (row) => {
        const name = row.student?.user
          ? `${row.student.user.first_name} ${row.student.user.last_name}`
          : '---';
        return (
          <div>
            <p className="text-sm text-gray-900">{name}</p>
            <p className="text-xs text-gray-500">{row.student?.admission_number}</p>
          </div>
        );
      },
    },
    {
      key: 'status',
      label: 'Status',
      width: 'w-1/5',
      render: (row) => {
        const isEditing = editingId === row.id;
        if (isEditing) {
          return (
            <Select
              value={editForm.status}
              onChange={(e) => setEditForm((f) => ({ ...f, status: e.target.value }))}
              options={STATUS_OPTIONS}
              placeholder="Select status..."
            />
          );
        }
        return (
          <span className={`px-3 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${STATUS_COLORS[row.status] || 'bg-gray-100 text-gray-600'}`}>
            {row.status?.replace('_', ' ')}
          </span>
        );
      },
    },
    {
      key: 'remarks',
      label: 'Remarks',
      width: 'w-1/4',
      render: (row) => {
        const isEditing = editingId === row.id;
        if (isEditing) {
          return (
            <Input
              value={editForm.remarks}
              onChange={(e) => setEditForm((f) => ({ ...f, remarks: e.target.value }))}
              placeholder="Required remarks..."
            />
          );
        }
        return (
          <span className="text-sm text-gray-500">
            {row.remarks || <span className="text-gray-300">---</span>}
          </span>
        );
      },
    },
    {
      key: 'markedBy',
      label: 'Marked By',
      width: 'w-1/5',
      render: (row) => {
        const marker = isAttendanceModified(row) ? (row.initialMarker || row.markedBy) : row.markedBy;
        return <span className="text-sm text-gray-500">{formatMarkerName(marker)}</span>;
      },
    },
  ];

  if (hasModifiedRecords) {
    tableColumns.push({
      key: 'latestMarker',
      label: 'Edited By',
      width: 'w-1/5',
      render: (row) => (
        <span className="text-sm text-gray-500">
          {isAttendanceModified(row) ? formatMarkerName(row.latestMarker || row.markedBy) : '---'}
        </span>
      ),
    });
  }

  const WEEKDAYS_FULL = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const formattedDate = date
    ? `${WEEKDAYS_FULL[new Date(date).getDay()]}, ${formatDate(date)}`
    : '---';

  // ====== Guard ============================================================================
  if (!date || !class_id) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <p className="text-gray-600 mb-4">Invalid session parameters.</p>
          <Button onClick={() => navigate('/attendance')}>Back to Attendance</Button>
        </div>
      </MainLayout>
    );
  }

  // ====== Render ============================================================================
  return (
    <MainLayout>
      <div className="space-y-4">

        {/* ====== Page Header ====== */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">
              View Attendance
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">{formattedDate} : {loading ? 'Attendance Session' : `${className}${sectionName ? ` - ${sectionName}` : ''}`}</p>
          </div>
          <Button
            variant="lightPrimary"
            onClick={() => navigate('/attendance')}
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to List
          </Button>
        </div>

        {/* ====== Downloads — this class's attendance, from right here in
            the session you're already looking at ====== */}
        {!loading && records.length > 0 && (
          <div className="bg-white p-5 rounded shadow">
            <p className="text-sm text-left font-semibold text-gray-700 mb-3">
              Download Attendance — {className}{sectionName ? ` — ${sectionName}` : ''}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border border-gray-200 rounded p-4">
                <p className="text-xs text-gray-500 mb-2">
                  {new Date(date).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })} Register (every day of the month)
                </p>
                <div className="flex gap-2">
                  <Button variant="lightPrimary" disabled={downloading} onClick={() => handleDownloadMonthRegister('pdf')}>PDF</Button>
                  <Button variant="lightPrimary" disabled={downloading} onClick={() => handleDownloadMonthRegister('excel')}>Excel</Button>
                </div>
              </div>
              <div className="border border-gray-200 rounded p-4">
                <p className="text-xs text-gray-500 mb-2">Full Year {date.slice(0, 4)} (summary + each month's register)</p>
                <div className="flex gap-2">
                  <Button variant="lightPrimary" disabled={downloading} onClick={() => handleDownloadYear('pdf')}>PDF</Button>
                  <Button variant="lightPrimary" disabled={downloading} onClick={() => handleDownloadYear('excel')}>Excel</Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ====== Stats Cards ====== */}
        {!loading && records.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex flex-wrap items-center justify-between gap-2 bg-white p-5 rounded shadow">
              <div className="">
                <p className="text-sm text-left text-gray-500 font-medium tracking-wide">Registered</p>
                <p className="text-2xl text-left font-bold text-gray-900 mt-1">{stats.total}</p>
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg
                  className="w-8 h-8 text-primary opacity-45"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                  />
                </svg>
              </div>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2 bg-white p-5 rounded shadow">
              <div className="">
                <p className="text-sm text-left text-gray-500 font-medium tracking-wide">Present</p>
                <p className="text-2xl text-left font-bold text-green-600 mt-1">{stats.present}</p>
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg
                  className="w-8 h-8 text-green-600 opacity-45"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2 bg-white p-5 rounded shadow">
              <div className="">
                <p className="text-sm text-left text-gray-500 font-medium tracking-wide">Absent / Other</p>
                <p className="text-2xl text-left font-bold text-yellow-600 mt-1">
                  {stats.absent + stats.late + stats.excused + stats.half_day}
                </p>
              </div>
              <div className="bg-yellow-100 p-3 rounded">
                <svg
                  className="w-8 h-8 text-yellow-600 opacity-45"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4m0 4h.01M5 13l4 4L19 7"
                  />
                </svg>
              </div>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2 bg-white p-5 rounded shadow">
              <div className="">
                <p className="text-sm text-left text-gray-500 font-medium tracking-wide">Rate</p>
                <p className={`text-2xl text-left font-bold mt-1 text-${rateColor}-600`}>{rate}%</p>
              </div>
              <div className={`bg-${rateColor}-100 p-3 rounded`}>
                <svg
                  className={`w-8 h-8 text-${rateColor}-600 opacity-45`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4m0 4h.01M5 13l4 4L19 7"
                  />
                </svg>
              </div>
            </div>
          </div>
        )}

        {/* ====== Records Table ====== */}
        <div className="space-y-3">
          <DataTable
            columns={tableColumns}
            data={tableRows}
            loading={loading}
            emptyMessage="No attendance records found for this session."
            renderActions={canEdit ? (row) => {
              const isEditing = editingId === row.id;
              return isEditing ? (
                <div className="flex items-center gap-2 justify-center">
                  <Button size="xs" variant="lightPrimary" onClick={() => saveEdit(row.id)} loading={saving}>Save</Button>
                  <Button size="xs" variant="ghost" onClick={cancelEdit}>Cancel</Button>
                </div>
              ) : (
                <Button size="xs" variant="lightPrimary" onClick={() => startEdit(row)}>Edit</Button>
              );
            } : undefined}
          />

          {/* Summary footer */}
          {!loading && records.length > 0 && (
            <div className="px-5 py-3 border-t border-gray-100 bg-white shadow-sm flex flex-wrap items-center gap-4">
              {SUMMARY_ITEMS.filter((item) => stats[item.key] > 0).map((item) => (
                <span key={item.key} className="flex items-center gap-1.5 text-xs text-gray-600">
                  <span className={`w-4 h-4 rounded-full ${item.color}`}></span>
                  <span>{item.label}:</span>
                  <span className="font-bold text-gray-900">{stats[item.key]}</span>
                </span>
              ))}
              <span className="ml-auto text-xs text-gray-500">
                Rate: <span className={`font-bold ${rateColor}`}>{rate}%</span>
              </span>
            </div>
          )}
        </div>

      </div>
    </MainLayout>
  );
}