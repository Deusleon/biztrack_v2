import { useState } from 'react';
import { Select } from '../components/ui';
import MainLayout from '../components/MainLayout';

export default function SelectDemo() {
  const [basicValue, setBasicValue] = useState('');
  const [searchableValue, setSearchableValue] = useState('');
  const [multipleValue, setMultipleValue] = useState([]);
  const [countryValue, setCountryValue] = useState('');

  const basicOptions = [
    { value: 'option1', label: 'Option 1' },
    { value: 'option2', label: 'Option 2' },
    { value: 'option3', label: 'Option 3' },
    { value: 'option4', label: 'Option 4' },
  ];

  const countryOptions = [
    { value: 'us', label: 'United States' },
    { value: 'uk', label: 'United Kingdom' },
    { value: 'ca', label: 'Canada' },
    { value: 'au', label: 'Australia' },
    { value: 'de', label: 'Germany' },
    { value: 'fr', label: 'France' },
    { value: 'jp', label: 'Japan' },
    { value: 'cn', label: 'China' },
    { value: 'in', label: 'India' },
    { value: 'br', label: 'Brazil' },
  ];

  const fruitOptions = [
    { value: 'apple', label: 'Apple' },
    { value: 'banana', label: 'Banana' },
    { value: 'orange', label: 'Orange' },
    { value: 'grape', label: 'Grape' },
    { value: 'mango', label: 'Mango' },
    { value: 'strawberry', label: 'Strawberry' },
  ];

  return (
    <MainLayout>
      <div className="space-y-8 max-w-4xl">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Custom Select Component</h1>
          <p className="text-sm text-gray-500 mt-1">
            Examples of the custom select component with various features
          </p>
        </div>

        {/* Basic Select */}
        <div className="bg-white p-5 rounded-lg shadow space-y-4">
          <h2 className="text-lg font-semibold text-gray-900">Basic Select</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              label="Basic Select"
              placeholder="Choose an option"
              value={basicValue}
              onChange={(e) => setBasicValue(e.target.value)}
              options={basicOptions}
            />

            <Select
              label="Required Select"
              placeholder="Choose an option"
              value={basicValue}
              onChange={(e) => setBasicValue(e.target.value)}
              options={basicOptions}
              required
              helperText="This field is required"
            />
          </div>

          <div className="p-3 bg-gray-50 rounded border border-gray-200">
            <p className="text-sm text-gray-600">
              Selected value: <span className="font-mono font-semibold">{basicValue || 'none'}</span>
            </p>
          </div>
        </div>

        {/* Searchable Select */}
        <div className="bg-white p-5 rounded-lg shadow space-y-4">
          <h2 className="text-lg font-semibold text-gray-900">Searchable Select</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              label="Search Countries"
              placeholder="Select a country"
              value={countryValue}
              onChange={(e) => setCountryValue(e.target.value)}
              options={countryOptions}
              searchable
              helperText="Type to search for countries"
            />

            <Select
              label="Search Fruits"
              placeholder="Select a fruit"
              value={searchableValue}
              onChange={(e) => setSearchableValue(e.target.value)}
              options={fruitOptions}
              searchable
            />
          </div>

          <div className="p-3 bg-gray-50 rounded border border-gray-200">
            <p className="text-sm text-gray-600">
              Selected country: <span className="font-mono font-semibold">{countryValue || 'none'}</span>
            </p>
            <p className="text-sm text-gray-600 mt-1">
              Selected fruit: <span className="font-mono font-semibold">{searchableValue || 'none'}</span>
            </p>
          </div>
        </div>

        {/* Multiple Select */}
        <div className="bg-white p-5 rounded-lg shadow space-y-4">
          <h2 className="text-lg font-semibold text-gray-900">Multiple Select</h2>
          <div className="grid grid-cols-1 gap-4">
            <Select
              label="Select Multiple Fruits"
              placeholder="Choose fruits"
              value={multipleValue}
              onChange={(e) => setMultipleValue(e.target.value)}
              options={fruitOptions}
              multiple
              searchable
              helperText="You can select multiple fruits"
            />
          </div>

          <div className="p-3 bg-gray-50 rounded border border-gray-200">
            <p className="text-sm text-gray-600 mb-2">
              Selected fruits ({multipleValue.length}):
            </p>
            {multipleValue.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {multipleValue.map((value) => {
                  const fruit = fruitOptions.find((f) => f.value === value);
                  return (
                    <span
                      key={value}
                      className="px-3 py-1 bg-primary bg-opacity-10 text-primary rounded-full text-sm font-medium"
                    >
                      {fruit?.label}
                    </span>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-gray-400">No fruits selected</p>
            )}
          </div>
        </div>

        {/* States Demo */}
        <div className="bg-white p-5 rounded-lg shadow space-y-4">
          <h2 className="text-lg font-semibold text-gray-900">Different States</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              label="Disabled Select"
              placeholder="This is disabled"
              value=""
              options={basicOptions}
              disabled
            />

            <Select
              label="Error State"
              placeholder="Select an option"
              value=""
              options={basicOptions}
              error="This field has an error"
              required
            />
          </div>
        </div>

        {/* Code Example */}
        <div className="bg-gray-900 p-5 rounded-lg shadow">
          <h2 className="text-lg font-semibold text-white mb-4">Usage Example</h2>
          <pre className="text-sm text-gray-300 overflow-x-auto">
            <code>{`import { Select } from '../components/ui';

// Basic Select
<Select
  label="Status"
  placeholder="Select status"
  value={status}
  onChange={(e) => setStatus(e.target.value)}
  options={[
    { value: 'active', label: 'Active' },
    { value: 'inactive', label: 'Inactive' }
  ]}
/>

// Searchable Select
<Select
  label="Country"
  searchable
  value={country}
  onChange={(e) => setCountry(e.target.value)}
  options={countryOptions}
/>

// Multiple Select
<Select
  label="Tags"
  multiple
  searchable
  value={tags}
  onChange={(e) => setTags(e.target.value)}
  options={tagOptions}
/>`}</code>
          </pre>
        </div>
      </div>
    </MainLayout>
  );
}
