import { useMemo, useState } from "react";

const TYPE_FILTERS = [
  { value: "", label: "All types" },
  { value: "parent", label: "Parents" },
  { value: "staff", label: "Staff" },
  { value: "student", label: "Students" },
  { value: "supplier", label: "Suppliers" },
  { value: "other", label: "Other" },
];

const TYPE_COLORS = {
  parent: "bg-blue-100 border border-blue-300 text-blue-500",
  staff: "bg-green-100 border border-green-300 text-green-500",
  student: "bg-purple-100 border border-purple-300 text-purple-500",
  supplier: "bg-orange-100 border border-orange-300 text-orange-500",
  other: "bg-gray-100 border border-gray-300 text-gray-600",
};

/**
 * ContactPicker — tick contacts from the saved list instead of typing
 * numbers one by one (e.g. 15 out of 370).
 *
 * Controlled: `selectedIds` is an array of contact ids and `onChange`
 * receives the new array. Selection is kept by id, so it survives
 * searching and filtering — a contact ticked, then filtered out of view,
 * stays selected.
 *
 * A contact the chosen channel cannot reach (no phone for SMS, no email
 * for email) is shown but cannot be ticked, so nothing is selected only to
 * fail at send time with "No phone number on file".
 */
export default function ContactPicker({ contacts, selectedIds, onChange, channel = "sms", loading = false }) {
  const [search, setSearch] = useState("");
  const [type, setType] = useState("");
  const [selectedOnly, setSelectedOnly] = useState(false);

  const selected = useMemo(() => new Set(selectedIds), [selectedIds]);
  const reachable = (c) => (channel === "email" ? !!c.email : !!c.phone);

  const pickable = useMemo(() => contacts.filter((c) => c.status !== "inactive"), [contacts]);

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    return pickable.filter((c) => {
      if (type && c.type !== type) return false;
      if (selectedOnly && !selected.has(c.id)) return false;
      if (!q) return true;
      return [c.name, c.phone, c.email].some((v) => v && String(v).toLowerCase().includes(q));
    });
  }, [pickable, search, type, selectedOnly, selected]);

  const visibleSelectable = visible.filter(reachable);
  const allVisibleSelected = visibleSelectable.length > 0 && visibleSelectable.every((c) => selected.has(c.id));

  // Selected contacts the current channel cannot reach (e.g. switched SMS → email).
  const unreachableSelected = pickable.filter((c) => selected.has(c.id) && !reachable(c)).length;

  const toggle = (id) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id); else next.add(id);
    onChange([...next]);
  };

  const toggleAllVisible = () => {
    const next = new Set(selected);
    if (allVisibleSelected) visibleSelectable.forEach((c) => next.delete(c.id));
    else visibleSelectable.forEach((c) => next.add(c.id));
    onChange([...next]);
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        <input
          type="text" value={search} onChange={(e) => setSearch(e.target.value)}
          placeholder="Search name, phone or email…"
          className="flex-1 min-w-[180px] border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-primary"
        />
        <select
          value={type} onChange={(e) => setType(e.target.value)}
          className="border border-gray-300 rounded px-3 py-2 text-sm bg-white focus:outline-none focus:border-primary"
        >
          {TYPE_FILTERS.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
        </select>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-1.5 cursor-pointer text-gray-700">
            <input type="checkbox" checked={allVisibleSelected} onChange={toggleAllVisible} disabled={visibleSelectable.length === 0} />
            Select all shown ({visibleSelectable.length})
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer text-gray-700">
            <input type="checkbox" checked={selectedOnly} onChange={(e) => setSelectedOnly(e.target.checked)} />
            Selected only
          </label>
        </div>
        <div className="flex items-center gap-3">
          <span className="font-semibold text-primary">{selectedIds.length} selected</span>
          {selectedIds.length > 0 && (
            <button type="button" onClick={() => onChange([])} className="text-gray-500 hover:text-red-600 underline">Clear all</button>
          )}
        </div>
      </div>

      <div className="border border-gray-200 rounded max-h-72 overflow-y-auto divide-y divide-gray-100">
        {loading && <p className="p-4 text-sm text-gray-400 text-center">Loading contacts…</p>}
        {!loading && visible.length === 0 && (
          <p className="p-4 text-sm text-gray-400 text-center">
            {pickable.length === 0 ? "No contacts yet — add some under Messages → Contacts." : "No contacts match your search."}
          </p>
        )}
        {visible.map((c) => {
          const ok = reachable(c);
          return (
            <label
              key={c.id}
              className={`flex items-center gap-3 px-3 py-2 text-sm ${ok ? "cursor-pointer hover:bg-gray-50" : "opacity-50 cursor-not-allowed"} ${selected.has(c.id) ? "bg-primary-5" : ""}`}
            >
              <input type="checkbox" checked={selected.has(c.id)} onChange={() => toggle(c.id)} disabled={!ok} />
              <span className="flex-1 min-w-0">
                <span className="block text-gray-900 truncate">{c.name}</span>
                <span className="block text-xs text-gray-500 truncate">
                  {ok ? (channel === "email" ? c.email : c.phone) : (channel === "email" ? "No email address" : "No phone number")}
                </span>
              </span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full capitalize flex-shrink-0 ${TYPE_COLORS[c.type] || TYPE_COLORS.other}`}>{c.type || "other"}</span>
            </label>
          );
        })}
      </div>

      {unreachableSelected > 0 && (
        <p className="text-xs text-amber-600">
          {unreachableSelected} selected contact{unreachableSelected === 1 ? " has" : "s have"} no {channel === "email" ? "email address" : "phone number"} and will not receive this message.
        </p>
      )}
    </div>
  );
}
