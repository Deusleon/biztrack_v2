import { useState, useEffect } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { messagingService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import MessagesNav from "./MessagesNav";
import ContactPicker from "./ContactPicker";
import { Select, Input, Button } from "../../components/ui";

const RECIPIENT_TYPES = [
  { value: "individual", label: "Single Contact" },
  { value: "group", label: "Group" },
  { value: "subgroup", label: "Subgroup" },
  { value: "role_broadcast", label: "Everyone of a Type" },
  { value: "custom_numbers", label: "Custom Numbers" },
];

const ROLE_OPTIONS = [
  { value: "parent", label: "All Parents" },
  { value: "staff", label: "All Staff" },
  { value: "student", label: "All Students" },
  { value: "supplier", label: "All Suppliers" },
];

const CHANNELS = [
  { value: "sms", label: "SMS" },
  { value: "email", label: "Email" },
];

export default function Compose() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { showSuccess, showError } = useToast();

  const [contacts, setContacts] = useState([]);
  const [groups, setGroups] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [balance, setBalance] = useState(null);
  const [contactsLoading, setContactsLoading] = useState(true);
  // console.log("balance", balance);

  const [form, setForm] = useState({
    channel: "sms",
    subject: "",
    body: "",
    template_id: "",
    recipient_type: searchParams.get("contact") ? "individual" : "individual",
    target_id: searchParams.get("contact") || "",
    role: "parent",
    custom_numbers_text: "",
    // Custom Numbers can be filled two ways: typed by hand ("type") or by
    // ticking saved contacts ("pick"). Ticked ids are kept in contact_ids.
    number_mode: "type",
    contact_ids: [],
  });
  const [draftId, setDraftId] = useState(searchParams.get("draft") || "");

  const [preview, setPreview] = useState(null);
  const [loadingPreview, setLoadingPreview] = useState(false);
  const [sending, setSending] = useState(false);
  const [savingDraft, setSavingDraft] = useState(false);

  useEffect(() => {
    const draftParam = searchParams.get("draft");
    if (draftParam) {
      messagingService.getMessageById(draftParam).then((res) => {
        if (!res.success) return;
        const draft = res.data;
        let recipientMeta = {};
        try { recipientMeta = JSON.parse(draft.recipient_summary || "{}"); } catch { /* pre-existing sent message, ignore */ }
        const pickedFromContacts = draft.recipient_type === "selected_contacts";
        setForm({
          channel: draft.channel, subject: draft.subject || "", body: draft.body, template_id: draft.template_id || "",
          // "selected_contacts" is how a pick-from-list send is stored; on screen it lives under Custom Numbers.
          recipient_type: pickedFromContacts ? "custom_numbers" : (draft.recipient_type || "individual"),
          target_id: recipientMeta.target_id || "",
          role: recipientMeta.role || "parent",
          custom_numbers_text: (recipientMeta.custom_numbers || []).join(", "),
          number_mode: pickedFromContacts ? "pick" : "type",
          contact_ids: recipientMeta.contact_ids || [],
        });
      }).catch((err) => showError(err.response?.data?.message || err.message));
    }
  }, []);

  useEffect(() => {
    loadAllContacts();
    messagingService.getGroups().then((res) => { if (res.success) setGroups(res.data); });
    messagingService.getTemplates({ status: "active" }).then((res) => {
      if (res.success) {
        setTemplates(res.data);
        const templateId = searchParams.get("template");
        if (templateId) {
          const t = res.data.find((tt) => tt.id === templateId);
          if (t) setForm((f) => ({ ...f, template_id: t.id, body: t.body, subject: t.subject || "", channel: t.channel }));
        }
      }
    });
    messagingService.getBalance().then((res) => { if (res.success) setBalance(res.data); });
  }, []);

  // The picker has to show every contact (a school can have thousands), so
  // keep fetching pages until the last one rather than stopping at 500.
  const loadAllContacts = async () => {
    try {
      setContactsLoading(true);
      const all = [];
      let page = 1, totalPages = 1;
      do {
        const res = await messagingService.getContacts({ limit: 500, page });
        if (!res.success) break;
        all.push(...res.data);
        totalPages = res.pagination?.totalPages || 1;
        page += 1;
      } while (page <= totalPages);
      setContacts(all);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setContactsLoading(false); }
  };

  useEffect(() => { setPreview(null); }, [form.recipient_type, form.target_id, form.role, form.custom_numbers_text, form.number_mode, form.contact_ids]);

  const handleTemplateChange = (templateId) => {
    const t = templates.find((tt) => tt.id === templateId);
    setForm((f) => ({ ...f, template_id: templateId, body: t ? t.body : f.body, subject: t?.subject || f.subject, channel: t?.channel || f.channel }));
  };

  const pickingContacts = form.recipient_type === "custom_numbers" && form.number_mode === "pick";

  const buildPreviewPayload = () => ({
    recipient_type: pickingContacts ? "selected_contacts" : form.recipient_type,
    target_id: form.recipient_type === "group" || form.recipient_type === "subgroup" || form.recipient_type === "individual" ? form.target_id : undefined,
    role: form.recipient_type === "role_broadcast" ? form.role : undefined,
    custom_numbers: form.recipient_type === "custom_numbers" && !pickingContacts ? form.custom_numbers_text.split(/[\n,]+/).map((n) => n.trim()).filter(Boolean) : undefined,
    contact_ids: pickingContacts ? form.contact_ids : undefined,
  });

  const handlePreview = async () => {
    try {
      setLoadingPreview(true);
      const res = await messagingService.previewRecipients(buildPreviewPayload());
      if (res.success) setPreview(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoadingPreview(false); }
  };

  const handleSend = async () => {
    if (!form.body.trim()) { showError("Message body is required"); return; }
    if (form.channel === "email" && !form.subject.trim()) { showError("Subject is required for email"); return; }
    if (pickingContacts && form.contact_ids.length === 0) { showError("Tick at least one contact to send to"); return; }
    try {
      setSending(true);
      const res = await messagingService.sendMessage({
        draft_id: draftId || undefined,
        channel: form.channel, subject: form.subject || undefined, body: form.body, template_id: form.template_id || undefined,
        ...buildPreviewPayload(),
      });
      if (res.success) {
        showSuccess(res.message);
        navigate(`/messages/history/${res.data.id}`);
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSending(false); }
  };

  const handleSaveDraft = async () => {
    if (!form.body.trim()) { showError("Message body is required"); return; }
    try {
      setSavingDraft(true);
      const res = await messagingService.saveDraft({
        draft_id: draftId || undefined,
        channel: form.channel, subject: form.subject || undefined, body: form.body, template_id: form.template_id || undefined,
        ...buildPreviewPayload(),
      });
      if (res.success) {
        showSuccess("Saved as draft");
        setDraftId(res.data.id);
        navigate(`/messages/compose?draft=${res.data.id}`, { replace: true });
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSavingDraft(false); }
  };

  const groupOptions = groups.filter((g) => form.recipient_type === "group" ? !g.parent_group_id : !!g.parent_group_id);
  const estimatedCost = form.channel === "sms" && preview ? preview.count * Number(balance?.cost_per_sms ?? 1) : 0;

  // Credits this send can draw on. Meseji, NextSMS and SwalaSMS hold the real balance
  // at the provider; with any other provider it is the local counter. (This
  // used to read Meseji's response shape unconditionally, which crashed the
  // page for every other provider.)
  const availableCredits = !balance ? null
    : balance.provider === "meseji" && balance.provider_balance?.summary ? Number(balance.provider_balance.summary.balance)
    : (balance.provider === "nextsms" || balance.provider === "swalasms") && balance.provider_active ? (balance.provider_credits ?? null)
    : Number(balance.balance);

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">{draftId ? "Edit Draft" : "Compose Message"}</h1>
            <p className="text-sm text-gray-500 mt-0.5">Send an SMS or email to one person, a group, or everyone of a type — including a custom number not saved as a contact</p>
          </div>
        </div>

        <MessagesNav />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 space-y-4">
            {/* Recipients */}
            <div className="bg-white text-left p-5 rounded shadow space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Select label="Send To" value={form.recipient_type} onChange={(e) => setForm((f) => ({ ...f, recipient_type: e.target.value, target_id: "" }))} options={RECIPIENT_TYPES} />

                {(form.recipient_type === "individual") && (
                  <Select label="Contact" searchable value={form.target_id} onChange={(e) => setForm((f) => ({ ...f, target_id: e.target.value }))}
                    options={[{ value: "", label: "Select…" }, ...contacts.map((c) => ({ value: c.id, label: `${c.name} (${c.phone || c.email || "no contact info"})` }))]} />
                )}
                {(form.recipient_type === "group" || form.recipient_type === "subgroup") && (
                  <Select label={form.recipient_type === "group" ? "Group" : "Subgroup"} value={form.target_id} onChange={(e) => setForm((f) => ({ ...f, target_id: e.target.value }))}
                    options={[{ value: "", label: "Select…" }, ...groupOptions.map((g) => ({ value: g.id, label: `${g.name} (${g.member_count})` }))]} />
                )}
                {form.recipient_type === "role_broadcast" && (
                  <Select label="Type" value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))} options={ROLE_OPTIONS} />
                )}
              </div>
              {form.recipient_type === "custom_numbers" && (
                <div className="space-y-3">
                  <div className="inline-flex rounded border border-gray-300 overflow-hidden text-sm">
                    {[{ value: "type", label: "Type numbers" }, { value: "pick", label: "Pick from contacts" }].map((m) => (
                      <button
                        key={m.value} type="button"
                        onClick={() => setForm((f) => ({ ...f, number_mode: m.value }))}
                        className={`px-4 py-1.5 ${form.number_mode === m.value ? "bg-primary text-white" : "bg-white text-gray-700 hover:bg-gray-50"}`}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>

                  {form.number_mode === "type" ? (
                    <div>
                      <label className="text-xs font-medium text-gray-700 block mb-1">Phone numbers</label>
                      <textarea
                        className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-primary"
                        rows={3} placeholder="One per line, or comma-separated: 255700000000, 255711111111"
                        value={form.custom_numbers_text} onChange={(e) => setForm((f) => ({ ...f, custom_numbers_text: e.target.value }))}
                      />
                    </div>
                  ) : (
                    <ContactPicker
                      contacts={contacts} loading={contactsLoading} channel={form.channel}
                      selectedIds={form.contact_ids} onChange={(ids) => setForm((f) => ({ ...f, contact_ids: ids }))}
                    />
                  )}
                </div>
              )}
              <button onClick={handlePreview} disabled={loadingPreview} className="text-sm text-primary hover:underline disabled:opacity-50">
                {loadingPreview ? "Checking…" : "Preview recipients →"}
              </button>
              {preview && (
                <div className="bg-primary-5 border border-primary-15 rounded px-4 py-3 text-sm">
                  <p className="font-semibold text-primary">This will reach {preview.count} {preview.count === 1 ? "person" : "people"}</p>
                  {preview.count > 0 && (
                    <p className="text-xs text-gray-500 mt-1">
                      {preview.contacts.slice(0, 6).map((c) => c.name).join(", ")}
                      {preview.count > 6 ? ` and ${preview.count - 6} more…` : ""}
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* Message */}
            <div className="bg-white text-left p-5 rounded shadow space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Select label="Channel" value={form.channel} onChange={(e) => setForm((f) => ({ ...f, channel: e.target.value }))} options={CHANNELS} />
                <Select label="Use a Template (optional)" value={form.template_id} onChange={(e) => handleTemplateChange(e.target.value)}
                  options={[{ value: "", label: "None — write from scratch" }, ...templates.map((t) => ({ value: t.id, label: t.name }))]} />
              </div>
              {form.channel === "email" && (
                <Input label="Subject" required value={form.subject} onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))} />
              )}
              <div>
                <label className="text-xs font-medium text-gray-700 block mb-1">Message</label>
                <textarea
                  className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-primary"
                  rows={6} value={form.body} onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))}
                  placeholder="Type your message… use {{name}} to insert each recipient's name."
                />
                <p className="text-xs text-gray-400 mt-1">{form.body.length} character(s){form.channel === "sms" ? ` — ~${Math.ceil(form.body.length / 160)} SMS segment(s) per recipient` : ""}</p>
              </div>
              <div className="flex gap-3">
                <Button onClick={handleSend} loading={sending} className="flex-1">Send Message</Button>
                <Button onClick={handleSaveDraft} loading={savingDraft} variant="secondary" className="flex-1">Save as Draft</Button>
              </div>
            </div>
          </div>

          {/* Sidebar summary */}
          <div className="space-y-4">
            {form.channel === "sms" && (
              <div className="bg-white text-left p-5 rounded shadow">
                <h3 className="text-sm font-semibold text-gray-800 mb-3">SMS Balance</h3>
                {preview && (
                  <>
                    <p className="text-2xl font-bold text-gray-900">{availableCredits !== null ? Number(availableCredits).toFixed(0).toLocaleString() : "—"} <span className="text-sm font-normal text-gray-400">credits</span></p>
                    <div className="mt-3 pt-3 border-t border-gray-100 text-sm space-y-1">
                      <div className="flex justify-between"><span className="text-gray-500">Recipients</span><span className="font-medium">{preview.count}</span></div>
                      <div className="flex justify-between"><span className="text-gray-500">Cost</span><span className="font-medium">{estimatedCost.toLocaleString()} credits</span></div>
                      {availableCredits !== null && availableCredits < estimatedCost && (
                        <p className="text-xs text-red-600 mt-2">Not enough balance for this send. <button onClick={() => navigate("/messages/balance")} className="underline">Top up →</button></p>
                      )}
                    </div>
                  </>
                )}
              </div>
            )}
            <div className="bg-white text-left p-5 rounded shadow">
              <h3 className="text-sm font-semibold text-gray-800 mb-2">Tips</h3>
              <ul className="text-xs text-gray-500 space-y-1.5 list-disc pl-4">
                <li>Use <code className="bg-gray-100 px-1 rounded">{"{{name}}"}</code> to personalize each message with the recipient's name.</li>
                <li>Templates save time for messages you send often — manage them under Messages → Templates.</li>
                <li>For custom numbers, type them one per line or comma-separated — or switch to "Pick from contacts" and tick the people you want from your saved list.</li>
              </ul>
            </div>
            <div className="bg-white text-left p-5 rounded shadow">
              <h3 className="text-sm font-semibold text-gray-800 mb-2">Learn More</h3>
              <ul className="text-xs text-gray-500 space-y-1.5 list-disc pl-4">
                <li><Link to="/help/messaging" className="text-primary hover:underline">Messaging documentation</Link></li>
                <li><Link to="/help/messaging-templates" className="text-primary hover:underline">Templates guide</Link></li>
                <li><Link to="/help/sms-balance" className="text-primary hover:underline">SMS balance and top-up</Link></li>
              </ul>
            </div>
            <div className="bg-white text-left p-5 rounded shadow">
              <h3 className="text-sm font-semibold text-gray-800 mb-2">Support</h3>
              <ul className="text-xs text-gray-500 space-y-1.5 list-disc pl-4">
                <li><Link to="/help/contact?from=/messages/compose" className="text-primary hover:underline">Contact support</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
