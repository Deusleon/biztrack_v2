import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { messagingService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { DataTable, Select, Button } from "../../components/ui";

// "sent" and "delivered" are NOT the same thing and were previously shown
// in the same green — a message the gateway accepted looked identical to
// one that actually reached the handset.
const STATUS_STYLES = {
  pending: "bg-gray-100 border border-gray-300 text-gray-500",
  sent: "bg-blue-100 border border-blue-300 text-blue-500",
  delivered: "bg-green-100 border border-green-300 text-green-500",
  failed: "bg-red-100 border border-red-300 text-red-500",
};

const STATUS_LABELS = {
  pending: "Queued",
  sent: "Accepted",      // gateway took it; handset delivery unconfirmed
  delivered: "Delivered",
  failed: "Failed",
};

export default function MessageDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showSuccess, showError, showWarning } = useToast();
  const { formatDateTime } = usePreferences();

  const [message, setMessage] = useState(null);
  const [loading, setLoading] = useState(true);
  const [retrying, setRetrying] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const [recipients, setRecipients] = useState([]);
  const [recipientsLoading, setRecipientsLoading] = useState(true);
  const [statusFilter, setStatusFilter] = usePersistedState("statusFilter", "");
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 15 });

  const loadMessage = () => {
    messagingService.getMessageById(id)
      .then((res) => {
        if (res.success) {
          setMessage(res.data);
          // The recipient list is fetched at the same moment as the message,
          // i.e. BEFORE the server has finished checking delivery with the
          // provider — so it would keep showing the old statuses. Fetch it
          // again now that they are up to date.
          if (res.data.delivery_provider) loadRecipients({ silent: true });
        }
      })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { loadMessage(); }, [id]);

  // While recipients are still waiting on a delivery result, keep checking —
  // results usually arrive within seconds of sending. Stops by itself once
  // everything has an answer, or after about 3 minutes (Refresh Delivery
  // can always be pressed after that).
  const waitingOnDelivery = Boolean(message?.delivery_polling);
  useEffect(() => {
    if (!waitingOnDelivery) return undefined;
    let checks = 0;
    const timer = setInterval(() => {
      checks += 1;
      if (checks > 12) { clearInterval(timer); return; }
      loadMessage();
    }, 15000);
    return () => clearInterval(timer);
  }, [waitingOnDelivery, id]);

  useEffect(() => { loadRecipients(); }, [id, statusFilter, pagination.currentPage]);

  const loadRecipients = async ({ silent = false } = {}) => {
    try {
      if (!silent) setRecipientsLoading(true);
      const res = await messagingService.getMessageRecipients(id, { status: statusFilter, page: pagination.currentPage, limit: pagination.itemsPerPage });
      if (res.success) { setRecipients(res.data); setPagination((p) => ({ ...p, ...res.pagination })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setRecipientsLoading(false); }
  };

  /** Asks the provider for the current delivery outcome. The detail view
   * refreshes automatically when its last check is stale, but a send that
   * has only just gone out is worth re-checking on demand. */
  const handleRefreshDelivery = async () => {
    try {
      setRefreshing(true);
      const res = await messagingService.refreshDelivery(id);
      if (res.success) {
        const check = res.delivery_check;
        if (check?.skipped) {
          showWarning(`Delivery was not checked: ${check.skipped}`, 12000);
        } else if (check?.errors?.length) {
          // The provider could not be asked, or refused — say why instead of
          // leaving every recipient on "Queued" with no explanation.
          showWarning(`Could not confirm delivery: ${check.errors[0]}`, 12000);
        } else if (check) {
          const parts = [];
          if (check.delivered) parts.push(`${check.delivered} delivered`);
          if (check.failed) parts.push(`${check.failed} failed`);
          if (check.still_pending) parts.push(`${check.still_pending} still on the way`);
          if (check.no_report) parts.push(`${check.no_report} not reported yet`);
          if (check.no_message_id) parts.push(`${check.no_message_id} without a message id`);
          showSuccess(parts.length ? `Delivery checked — ${parts.join(", ")}` : "Delivery status refreshed");
        } else {
          showSuccess("Delivery status refreshed");
        }
        loadMessage();
        loadRecipients();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    } finally {
      setRefreshing(false);
    }
  };

  const handleRetry = async () => {
    try {
      setRetrying(true);
      const res = await messagingService.retryMessage(id);
      if (res.success) { showSuccess(res.message); loadMessage(); loadRecipients(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setRetrying(false); }
  };

  if (loading) {
    return <MainLayout><div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div></MainLayout>;
  }
  if (!message) {
    return <MainLayout><div className="bg-white p-10 rounded shadow text-center text-gray-400">Message not found.</div></MainLayout>;
  }

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Message Detail</h1>
            <p className="text-sm text-gray-500 mt-0.5">{formatDateTime(message.sent_at || message.createdAt)}</p>
          </div>
          <div className="flex items-center gap-3">
            {message.channel === "sms" && (
              <Button onClick={handleRefreshDelivery} loading={refreshing} variant="secondary">
                Refresh Delivery
              </Button>
            )}
            {message.failed_count > 0 && (
              <Button onClick={handleRetry} loading={retrying} >Retry Failed ({message.failed_count})</Button>
            )}
            <Button
              onClick={() => navigate("/messages/history")}
              variant="lightPrimary"
              className="animate-pulse"
              leftIcon={
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 19l-7-7m0 0l7-7m-7 7h18"
                  />
                </svg>
              }>Back to History
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded shadow text-left"><p className="text-sm text-gray-600">Total</p><p className="text-2xl font-bold text-gray-900 mt-1">{message.total_recipients}</p></div>
          <div className="bg-white p-5 rounded shadow text-left">
            <p className="text-sm text-gray-600">Delivered</p>
            {message.delivered_count === null || message.delivered_count === undefined ? (
              <p className="text-sm text-gray-400 mt-2">Not confirmed yet</p>
            ) : (
              <p className="text-2xl font-bold text-green-600 mt-1">{message.delivered_count}</p>
            )}
          </div>
          <div className="bg-white p-5 rounded shadow text-left"><p className="text-sm text-gray-600">Failed</p><p className="text-2xl font-bold text-red-600 mt-1">{message.failed_count}</p></div>
          <div className="bg-white p-5 rounded shadow text-left"><p className="text-sm text-gray-600">Cost</p><p className="text-2xl font-bold text-gray-900 mt-1">{Number(message.cost).toLocaleString()}</p></div>
        </div>

        <div className="bg-white rounded shadow p-5 text-left">
          <h3 className="text-sm font-semibold text-gray-900 mb-3">Message Details</h3>
          {message.subject && <p className="text-sm font-semibold text-gray-900 mb-1">{message.subject}</p>}
          <p className="text-sm text-gray-700 whitespace-pre-wrap">{message.body}</p>
          <p className="text-xs text-gray-400 mt-3">
            {message.channel.toUpperCase()} • {message.is_automated ? "Sent automatically by the system" : message.sender ? `Sent by ${message.sender.first_name} ${message.sender.last_name}` : ""}
            {message.template && ` • Template: ${message.template.name}`}
          </p>
        </div>

        <div className="bg-white p-4 rounded shadow flex flex-wrap items-center justify-between gap-2 gap-4">
          <p className="text-sm font-semibold text-gray-700">Recipients ({pagination.totalItems})</p>
          <div className="w-48">
            <Select
              value={statusFilter}
              onChange={(e) => { setStatusFilter(e.target.value); setPagination((p) => ({ ...p, currentPage: 1 })); }}
              options={[{ value: "", label: "All Statuses" }, { value: "sent", label: "Accepted" }, { value: "delivered", label: "Delivered" }, { value: "failed", label: "Failed" }, { value: "pending", label: "Pending" }]}
            />
          </div>
        </div>

        <DataTable
          columns={[
            { key: "name", label: "Name", render: (r) => <span className="text-sm text-gray-900">{r.name_snapshot}</span> },
            { key: "contact", label: "Contact", render: (r) => <span className="text-sm text-gray-600">{r.phone_snapshot || r.email_snapshot || "—"}</span> },
            {
              key: "status", label: "Status", align: "center",
              render: (r) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${STATUS_STYLES[r.status]}`}>
                  {STATUS_LABELS[r.status] || r.status}
                </span>
              ),
            },
            { key: "note", label: "Note", render: (r) => <span className="text-xs text-red-500">{r.error_message || "—"}</span> },
          ]}
          data={recipients}
          loading={recipientsLoading}
          emptyMessage="No recipients match this filter"
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>
    </MainLayout>
  );
}
