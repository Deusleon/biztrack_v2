// FILE PATH: frontend/src/pages/Messages/InquiryList.jsx
import { useState, useEffect } from "react";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { contactInquiryService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import MessagesNav from "./MessagesNav";
import { Select, Input, DataTable, RowActions, ACTION_ICONS } from "../../components/ui";

const STATUS_STYLES = {
  new: "bg-blue-100 border border-blue-300 text-blue-600",
  read: "bg-amber-100 border border-amber-300 text-amber-600",
  replied: "bg-green-100 border border-green-300 text-green-600",
};

const STATUS_LABELS = { new: "New", read: "Read", replied: "Replied" };

function DetailModal({ inquiry, onClose }) {
  if (!inquiry) return null;
  const row = (label, value) => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 py-2 border-b border-gray-100 last:border-0">
      <p className="text-xs text-gray-500 col-span-1">{label}</p>
      <p className="text-sm text-gray-900 col-span-2 break-words whitespace-pre-wrap">{value || "—"}</p>
    </div>
  );
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded shadow-lg w-full max-w-lg max-h-[90vh] overflow-y-auto text-left" onClick={(e) => e.stopPropagation()}>
        <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-4 border-b border-gray-100">
          <h3 className="text-base font-semibold text-gray-900">Message Details</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">&times;</button>
        </div>
        <div className="px-5 py-2">
          {row("From", inquiry.name)}
          {row("Email", inquiry.email)}
          {row("Phone", inquiry.phone)}
          {row("Subject", inquiry.subject)}
          {row("Message", inquiry.message)}
          {row("Status", <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${STATUS_STYLES[inquiry.status]}`}>{STATUS_LABELS[inquiry.status]}</span>)}
          {row("Staff Notes", inquiry.staff_notes)}
        </div>
      </div>
    </div>
  );
}

export default function InquiryList() {
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();

  const [inquiries, setInquiries] = useState([]);
  const [counts, setCounts] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = usePersistedState("filters", { status: "", search: "" });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 15 });
  const [viewing, setViewing] = useState(null);

  useEffect(() => { load(); }, [filters, pagination.currentPage]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { loadCounts(); }, []);

  const load = async () => {
    try {
      setLoading(true);
      const res = await contactInquiryService.list({ ...filters, page: pagination.currentPage, limit: pagination.itemsPerPage });
      if (res.success) { setInquiries(res.data); setPagination((p) => ({ ...p, ...res.pagination })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const loadCounts = async () => {
    try {
      const res = await contactInquiryService.getCounts();
      if (res.success) setCounts(res.data);
    } catch { /* counts strip just won't render */ }
  };

  const changeStatus = async (inquiry, status) => {
    try {
      const res = await contactInquiryService.updateStatus(inquiry.id, { status });
      if (res.success) {
        showSuccess(`Marked as ${STATUS_LABELS[status]}`);
        load();
        loadCounts();
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
  };

  const openDetails = (inquiry) => {
    setViewing(inquiry);
    if (inquiry.status === "new") changeStatus(inquiry, "read");
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Website Inquiries</h1>
            <p className="text-sm text-gray-500 mt-0.5">Messages submitted through the school website's contact form</p>
          </div>
        </div>

        <MessagesNav />

        {counts && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {Object.entries(STATUS_LABELS).map(([key, label]) => (
              <button
                key={key}
                onClick={() => { setFilters((f) => ({ ...f, status: f.status === key ? "" : key })); setPagination((p) => ({ ...p, currentPage: 1 })); }}
                className={`text-left border rounded p-3 transition-colors ${filters.status === key ? "border-primary bg-primary/5 ring-1 ring-primary" : "border-gray-200 bg-white hover:border-gray-300"}`}
              >
                <p className="text-xs text-gray-500">{label}</p>
                <p className="text-xl font-bold text-gray-900 mt-0.5">{counts[key] ?? 0}</p>
              </button>
            ))}
          </div>
        )}

        <div className="bg-white p-5 rounded shadow">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              className="md:col-span-2"
              value={filters.search}
              onChange={(e) => { setFilters((f) => ({ ...f, search: e.target.value })); setPagination((p) => ({ ...p, currentPage: 1 })); }}
              placeholder="Search by name, email, phone, or subject…"
            />
            <Select
              value={filters.status}
              onChange={(e) => { setFilters((f) => ({ ...f, status: e.target.value })); setPagination((p) => ({ ...p, currentPage: 1 })); }}
              options={[{ value: "", label: "All Statuses" }, ...Object.entries(STATUS_LABELS).map(([value, label]) => ({ value, label }))]}
            />
          </div>
        </div>

        <DataTable
          columns={[
            {
              key: "from", label: "From",
              render: (i) => (
                <div className="max-w-xs">
                  <p className="text-sm font-medium">{i.name}</p>
                  <p className="text-xs text-gray-500 truncate">{i.email}{i.phone ? ` · ${i.phone}` : ""}</p>
                </div>
              ),
            },
            {
              key: "subject", label: "Subject",
              render: (i) => (
                <div className="max-w-xs">
                  <p className="text-sm truncate">{i.subject}</p>
                  <p className="text-xs text-gray-500 truncate">{i.message}</p>
                </div>
              ),
            },
            { key: "status", label: "Status", render: (i) => <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${STATUS_STYLES[i.status]}`}>{STATUS_LABELS[i.status]}</span> },
            { key: "date", label: "Received", render: (i) => <span className="text-sm">{formatDate(i.createdAt)}</span> },
          ]}
          data={inquiries}
          loading={loading}
          emptyMessage="No messages received yet"
          renderActions={(i) => (
            <RowActions
              actions={[
                { label: "View Details", variant: "primary", icon: ACTION_ICONS.view, onClick: () => openDetails(i) },
                { label: "Mark Replied", variant: "primary", icon: ACTION_ICONS.check, hidden: i.status === "replied", onClick: () => changeStatus(i, "replied") },
              ]}
            />
          )}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      <DetailModal inquiry={viewing} onClose={() => setViewing(null)} />
    </MainLayout>
  );
}