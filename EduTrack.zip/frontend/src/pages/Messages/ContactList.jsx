import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { messagingService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import MessagesNav from "./MessagesNav";
import { Select, Input, PhoneInput, DataTable, ConfirmModal, Button, RowActions, ACTION_ICONS } from "../../components/ui";
import Icon from "../../components/ui/Icon";

const TYPES = [
  { value: "parent", label: "Parent" },
  { value: "staff", label: "Staff" },
  { value: "student", label: "Student" },
  { value: "supplier", label: "Supplier" },
  { value: "other", label: "Other" },
];

const TYPE_COLORS = {
  parent: "bg-blue-100 border border-blue-300 text-blue-500", staff: "bg-green-100 border border-green-300 text-green-500",
  student: "bg-purple-100 border border-purple-300 text-purple-500", supplier: "bg-orange-100 border border-orange-300 text-orange-500",
  other: "bg-gray-100 border border-gray-300 text-gray-600",
};

export default function ContactList() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();

  const [contacts, setContacts] = useState([]);
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);

  const [filters, setFilters] = usePersistedState("filters", { search: "", type: "", group_id: "" });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 15 });

  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({ name: "", phone: "", email: "", type: "other", notes: "", group_ids: [] });
  const [saving, setSaving] = useState(false);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false });

  useEffect(() => { fetchContacts(); }, [filters, pagination.currentPage]);
  useEffect(() => { fetchGroups(); }, []);

  const fetchContacts = async () => {
    try {
      setLoading(true);
      const res = await messagingService.getContacts({ ...filters, page: pagination.currentPage, limit: pagination.itemsPerPage });
      if (res.success) { setContacts(res.data); setPagination((p) => ({ ...p, ...res.pagination })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const fetchGroups = async () => {
    try {
      const res = await messagingService.getGroups();
      if (res.success) setGroups(res.data);
    } catch { /* non-fatal */ }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((f) => ({ ...f, [name]: value }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const handleSync = async () => {
    try {
      setSyncing(true);
      const res = await messagingService.syncContacts();
      if (res.success) { showSuccess(res.message); fetchContacts(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSyncing(false); }
  };

  const openCreate = () => {
    setForm({ name: "", phone: "", email: "", type: "other", notes: "", group_ids: [] });
    setModal({ isOpen: true, mode: "create" });
  };

  const openEdit = (c) => {
    setForm({ name: c.name, phone: c.phone || "", email: c.email || "", type: c.type, notes: c.notes || "", group_ids: (c.groups || []).map((g) => g.id) });
    setModal({ isOpen: true, mode: "edit", id: c.id });
  };

  const handleSave = async () => {
    if (!form.name || (!form.phone && !form.email)) { showError("Name and at least one of phone/email are required"); return; }
    try {
      setSaving(true);
      if (modal.mode === "edit") await messagingService.updateContact(modal.id, form);
      else await messagingService.createContact(form);
      showSuccess(modal.mode === "edit" ? "Contact updated" : "Contact created");
      setModal({ isOpen: false });
      fetchContacts();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (c) => {
    setConfirmModal({ isOpen: true, id: c.id, title: "Delete Contact", message: `Delete "${c.name}"? This can't be undone.` });
  };

  const confirmDelete = async () => {
    try {
      await messagingService.deleteContact(confirmModal.id);
      showSuccess("Contact deleted");
      fetchContacts();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmModal({ isOpen: false });
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Contacts</h1>
            <p className="text-sm text-gray-500 mt-0.5">Everyone reachable by message — parents, staff, suppliers, and more</p>
          </div>
          <div className="flex gap-2">
            {can("messages.manage_contacts") && (
              <>
                <Button variant="secondary" mobileLabel="Sync from System" onClick={handleSync} disabled={syncing}>{syncing ? "Syncing…" : "↻ Sync from System"}</Button>
                <Button variant="primary" onClick={openCreate}>New Contact</Button>
              </>
            )}
          </div>
        </div>

        <MessagesNav />

        <div className="bg-white p-5 rounded shadow">
          <form onSubmit={(e) => { e.preventDefault(); fetchContacts(); }} className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="md:col-span-2">
              <Input label="Search" name="search" value={filters.search} onChange={handleFilterChange} placeholder="Search by name, phone, email..."
                leftIcon={<svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} />
            </div>
            <Select label="Type" name="type" value={filters.type} onChange={handleFilterChange} options={[{ value: "", label: "All Types" }, ...TYPES]} />
            <Select label="Group" name="group_id" value={filters.group_id} onChange={handleFilterChange} options={[{ value: "", label: "All Contacts" }, ...groups.map((g) => ({ value: g.id, label: g.name }))]} />
            <div className="flex items-end">
              <button type="submit" className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90">Apply Filters</button>
            </div>
          </form>
        </div>

        <DataTable
          columns={[
            { key: "name", label: "Name", render: (c) => <span className="text-sm font-medium text-gray-900">{c.name}</span> },
            { key: "phone", label: "Phone", render: (c) => <span className="text-gray-700 text-sm">{c.phone || "—"}</span> },
            { key: "email", label: "Email", render: (c) => <span className="text-gray-700 text-sm">{c.email || "—"}</span> },
            { key: "type", label: "Type", render: (c) => <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${TYPE_COLORS[c.type]}`}>{c.type}</span> },
            { key: "groups", label: "Groups", render: (c) => <span className="text-xs text-gray-500">{(c.groups || []).map((g) => g.name).join(", ") || "—"}</span> },
          ]}
          data={contacts}
          loading={loading}
          emptyMessage="No contacts found — try 'Sync from System' or add one manually"
          renderActions={(can("send_messages") || can("messages.manage_contacts")) ? (c) => (
            <RowActions
              actions={[
                { label: 'Send Message', variant: 'primary', icon: ACTION_ICONS.upload, hidden: !can("send_messages"), onClick: () => navigate(`/messages/compose?contact=${c.id}`) },
                { label: 'Edit Contact', icon: ACTION_ICONS.edit, hidden: !can("messages.manage_contacts"), onClick: () => openEdit(c) },
                { label: 'Delete Contact', variant: 'danger', icon: ACTION_ICONS.delete, hidden: !can("messages.manage_contacts"), onClick: () => handleDelete(c) },
              ]}
            />
          ) : undefined}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Contact" : "New Contact"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <Input label="Full Name" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Enter full name" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <PhoneInput label="Phone" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} />
                <Input label="Email" type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="Enter email address" />
              </div>
              <Select label="Type" value={form.type} onChange={(e) => setForm((f) => ({ ...f, type: e.target.value }))} options={TYPES} />
              <Select
                label="Groups" multiple value={form.group_ids}
                onChange={(e) => setForm((f) => ({ ...f, group_ids: e.target.value }))}
                placeholder="No groups"
                options={groups.filter((g) => !g.is_dynamic).map((g) => ({ value: g.id, label: g.name }))}
                // helperText="Only static groups are listed — dynamic groups compute their members automatically"
              />
              <Input label="Notes" value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} placeholder="Optional" />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Create"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmModal.isOpen} title={confirmModal.title} message={confirmModal.message} variant="danger" onConfirm={confirmDelete} onClose={() => setConfirmModal({ isOpen: false })} />
    </MainLayout>
  );
}
