import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { messagingService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import MessagesNav from "./MessagesNav";
import SwalaTopUpModal from "../../components/SwalaTopUpModal";
import { Input, NumberInput, Button, PhoneInput, Select } from "../../components/ui";

const TX_STYLES = {
  purchase: "text-green-600", deduction: "text-red-600", refund: "text-green-600", adjustment: "text-gray-600",
};

export default function SmsBalance() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { formatDateTime } = usePreferences();
  const isAdmin = can("messages.billing");

  const [balance, setBalance] = useState(null);
  const [topUpForm, setTopUpForm] = useState({ amount: "", phone: "", method: "ussd" });
  const [senderId, setSenderId] = useState();
  const [topUpResult, setTopUpResult] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  const [topUpModal, setTopUpModal] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState("");
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      setLoading(true);
      const [balRes, txRes] = await Promise.all([messagingService.getBalance(), messagingService.getTransactions({ limit: 20 })]);
      if (balRes.success) setBalance(balRes.data);
      if (txRes.success) setTransactions(txRes.data);

      // Provider sender IDs can only be listed for Meseji. Asking any other
      // provider is refused, and that refusal used to take the whole page
      // down with it (including with the simulated provider).
      if (balRes.success && balRes.data.provider === "meseji") {
        if (balRes.data.sender_id) {
          // The sender configured in Settings is the one every message actually
          // goes out under, so show that.
          setSenderId(balRes.data.sender_id);
        } else {
          try {
            const senderRes = await messagingService.getProviderSenderIds();
            // Same entry as before, but no longer a crash when the account
            // has only one sender ID.
            const entry = senderRes.success ? (senderRes.data[1] ?? senderRes.data[0]) : null;
            if (entry) setSenderId(entry.sender_id);
          } catch { /* shown as "Sender ID not available" */ }
        }
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleTopUp = async () => {
    if (!topUpAmount || Number(topUpAmount) <= 0) { showError("Enter a valid amount"); return; }
    try {
      setSaving(true);
      const res = await messagingService.purchaseBalance({ amount: topUpAmount, description: "Manual top-up" });
      if (res.success) { showSuccess(res.message); setTopUpModal(false); setTopUpAmount(""); load(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  // A live gateway means the provider holds the real credits.
  const liveProvider = Boolean(balance?.provider_active && balance?.provider === "meseji");
  // NextSMS: the credits are held at NextSMS and bought on their site, so
  // there is nothing to top up from here.
  const liveNextSms = Boolean(balance?.provider_active && balance?.provider === "nextsms");
  // SwalaSMS: credits held at SwalaSMS, and bought from here (mobile money prompt or card link).
  const liveSwala = Boolean(balance?.provider_active && balance?.provider === "swalasms");

  const handleBuyCredits = async () => {
    if (!(Number(topUpForm.amount) > 0)) return showError("Enter an amount greater than 0");
    if (!topUpForm.phone) return showError("Enter the mobile money phone number to charge");
    try {
      setSaving(true);
      setTopUpResult(null);
      const res = await messagingService.topUpProvider({
        amount: Number(topUpForm.amount),
        phone: topUpForm.phone,
        method: topUpForm.method,
      });
      if (res.success) {
        showSuccess(res.message);
        setTopUpResult(res.data);
        // Credits only land once the payer approves on their handset, so
        // the balance is re-read rather than assumed.
        load();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">SMS Balance</h1>
            <p className="text-sm text-gray-500 mt-0.5">Credits available for sending SMS messages</p>
          </div>
          <div className="flex gap-2">
            {isAdmin && !liveNextSms && (
              <Button variant="primary" mobileLabel="Top Up Balance" onClick={() => setTopUpModal(true)}>{liveProvider || liveSwala ? "Buy Credits" : "Top Up Balance"}</Button>
            )}
          </div>
        </div>

        <MessagesNav />

        {/* With a live gateway the provider's balance is the real one — the
            local figure is a usage log, and showing it as "your balance"
            was how a funded account came to look empty. */}
        {liveSwala ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white text-left p-5 rounded shadow">
              <p className="text-sm text-gray-500 uppercase tracking-wide">Sender Id</p>
              {balance.sender_id ? (
                <p className="text-xl font-extrabold text-primary mt-2">{balance.sender_id}</p>
              ) : (
                <p className="text-lg text-amber-600 mt-1">Not set — add one in Settings</p>
              )}
              {balance.sender_id === "SWALATECH" && <p className="text-xs text-amber-600 mt-1">SwalaSMS's test sender: it delivers only to your registered test numbers.</p>}
            </div>
            <div className="bg-white text-left p-5 rounded shadow">
              <p className="text-sm text-gray-500 uppercase tracking-wide">Current SMS Balance</p>
              {balance.provider_credits !== null && balance.provider_credits !== undefined ? (
                <p className="text-xl font-extrabold text-primary mt-2">{Number(balance.provider_credits).toLocaleString()}</p>
              ) : (
                <p className="text-lg text-amber-600 mt-1">Couldn't read balance</p>
              )}
              {balance.provider_error && <p className="text-xs text-red-600 mt-1">{balance.provider_error}</p>}
              {(balance.provider_wallets || []).length > 1 && (
                <ul className="text-xs text-gray-500 mt-1 space-y-0.5">
                  {balance.provider_wallets.map((w) => <li key={w.wallet_uid || w.country}>{w.country} {w.calling_code}: {Number(w.balance).toLocaleString()}</li>)}
                </ul>
              )}
              <p className="text-xs text-gray-400 mt-1">Held at SwalaSMS</p>
            </div>
            <div className="bg-white text-left p-5 rounded shadow">
              <p className="text-sm text-gray-500 uppercase tracking-wide">Key Mode</p>
              {balance.provider_mode === "sandbox" ? (
                <>
                  <p className="text-xl font-extrabold text-amber-600 mt-2">Sandbox</p>
                  <p className="text-xs text-amber-700 mt-1">Messages are not really sent and no credits are spent. Use a live key (swl_live_…) for real sends.</p>
                </>
              ) : (
                <>
                  <p className="text-xl font-extrabold text-green-600 mt-2">Live</p>
                  <p className="text-xs text-gray-400 mt-1">Messages are really sent and credits are spent.</p>
                </>
              )}
            </div>
          </div>
        ) : liveNextSms ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white text-left p-5 rounded shadow">
              <p className="text-sm text-gray-500 uppercase tracking-wide">Sender Id</p>
              {balance.sender_id ? (
                <p className="text-xl font-extrabold text-primary mt-2">{balance.sender_id}</p>
              ) : (
                <p className="text-lg text-amber-600 mt-1">Not set — NextSMS default sender is used</p>
              )}
            </div>
            <div className="bg-white text-left p-5 rounded shadow">
              <p className="text-sm text-gray-500 uppercase tracking-wide">Current SMS Balance</p>
              {balance.provider_credits !== null && balance.provider_credits !== undefined ? (
                <p className="text-xl font-extrabold text-primary mt-2">{Number(balance.provider_credits).toLocaleString()}</p>
              ) : (
                <p className="text-lg text-amber-600 mt-1">Couldn't read balance</p>
              )}
              {balance.provider_error && <p className="text-xs text-red-600 mt-1">{balance.provider_error}</p>}
              <p className="text-xs text-gray-400 mt-1">Held at NextSMS</p>
            </div>
            <div className="bg-white text-left p-5 rounded shadow">
              <p className="text-sm text-gray-500 uppercase tracking-wide">Need more credits?</p>
              <p className="text-sm text-gray-600 mt-2">Buy SMS credits in your NextSMS account at <a href="https://nextsms.co.tz" target="_blank" rel="noopener noreferrer" className="text-primary underline">nextsms.co.tz</a>. The balance here updates as soon as they are added.</p>
            </div>
          </div>
        ) : liveProvider ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white text-left p-5 rounded shadow text-center">
              <p className="text-sm text-left text-gray-500 uppercase tracking-wide">
                Sender Id
              </p>
              {senderId !== null && senderId !== undefined ? (
                <p className="text-xl text-left font-extrabold text-primary mt-2">{senderId}</p>
              ) : (
                <p className="text-lg text-left text-amber-600 mt-1">Sender ID not available</p>
              )
              }
            </div>
            <div className="bg-white text-left p-5 rounded shadow text-center">
              <p className="text-sm text-left text-gray-500 uppercase tracking-wide">
                Current SMS Balance
              </p>
              {balance.provider_balance !== null && balance.provider_balance !== undefined ? (
                <p className="text-xl text-left font-extrabold text-primary mt-2">{Number(balance.provider_balance.summary.balance).toFixed(0).toLocaleString()}</p>
              ) : (
                <p className="text-lg text-left text-amber-600 mt-1">Couldn't read balance</p>
              )}
              <p className="text-xs text-left text-gray-400 mt-1">
                Rate • {balance ? Number(balance.provider_balance.summary.rate) : ""} TZS per SMS
              </p>
              {/* {liveProvider && (
            <p className="text-xs text-left text-gray-400 mt-2">Local usage log: {Number(balance.balance).toLocaleString()}</p>
          )} */}
            </div>
            <div className="bg-white text-left p-5 rounded shadow text-center">
              <p className="text-sm text-left text-gray-500 uppercase tracking-wide">
                Total Messages Sent
              </p>
              {balance.provider_balance !== null && balance.provider_balance !== undefined ? (
                <p className="text-xl text-left font-extrabold text-primary mt-2">{Number(balance.provider_balance.summary.total_sent).toLocaleString()}</p>
              ) : (
                <p className="text-lg text-left text-amber-600 mt-1">Unknown</p>
              )}
            </div>
            <div className="bg-white text-left p-5 rounded shadow text-center">
              <p className="text-sm text-left text-gray-500 uppercase tracking-wide">
                Successfully Delivered
              </p>
              {balance.provider_balance !== null && balance.provider_balance !== undefined ? (
                <p className="text-xl text-left font-extrabold text-primary mt-2">{Number(balance.provider_balance.summary.total_delivered).toLocaleString()}</p>
              ) : (
                <p className="text-lg text-left text-amber-600 mt-1">Unknown</p>
              )}
            </div>
            <div className="bg-white text-left p-5 rounded shadow text-center">
              <p className="text-sm text-left text-gray-500 uppercase tracking-wide">
                Failed Deliveries
              </p>
              {balance.provider_balance !== null && balance.provider_balance !== undefined ? (
                <p className="text-xl text-left font-extrabold text-primary mt-2">{Number(balance.provider_balance.summary.total_failed).toLocaleString()}</p>
              ) : (
                <p className="text-lg text-left text-amber-600 mt-1">Unknown</p>
              )}
            </div>
            <div className="bg-white text-left p-5 rounded shadow text-center">
              <p className="text-sm text-left text-gray-500 uppercase tracking-wide">
                Success Rate
              </p>
              {balance.provider_balance !== null && balance.provider_balance !== undefined ? (
                <p className="text-xl text-left font-extrabold text-primary mt-2">{balance.provider_balance.summary.success_rate}</p>
              ) : (
                <p className="text-lg text-left text-amber-600 mt-1">Unknown</p>
              )}
            </div>
          </div>
        ) : (
          loading ? (
            <div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary" /></div>
          ) : balance ? (
            // No live gateway: the balance is the local counter an admin tops up by hand.
            <div className="bg-white text-left p-5 rounded shadow max-w-sm">
              <p className="text-sm text-gray-500 uppercase tracking-wide">Local SMS Balance</p>
              <p className="text-xl font-extrabold text-primary mt-2">{Number(balance.balance).toLocaleString()}</p>
              <p className="text-xs text-gray-400 mt-1">Recorded locally — activate a gateway in Settings → Messages to use real credits.</p>
            </div>
          ) : (""))
        }
      </div>

      {topUpModal && liveSwala && <SwalaTopUpModal onClose={() => setTopUpModal(false)} onPaid={load} />}

      {topUpModal && !liveSwala && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-sm">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Top Up SMS Balance</h3>
              <button onClick={() => setTopUpModal(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            {liveProvider ? (
              <form onSubmit={(e) => { e.preventDefault(); handleBuyCredits(); }} className="px-5 py-4 space-y-4">
                <NumberInput
                  label="Amount (TZS)"
                  required
                  allowDecimals={false}
                  value={topUpForm.amount}
                  onChange={(e) => setTopUpForm((f) => ({ ...f, amount: e.target.value }))}
                  placeholder="Enter the amount to charge"
                // helperText="Meseji converts this to SMS credits at their current rate."
                />
                <PhoneInput
                  label="Mobile Money Number"
                  required
                  value={topUpForm.phone}
                  onChange={(e) => setTopUpForm((f) => ({ ...f, phone: e.target.value }))}
                />
                <Select
                  label="Payment Method"
                  value={topUpForm.method}
                  onChange={(e) => setTopUpForm((f) => ({ ...f, method: e.target.value }))}
                  options={[
                    { value: "ussd", label: "USSD push (approve on the handset)" },
                    { value: "zenopay", label: "ZenoPay (Lipa Namba / QR link)" },
                  ]}
                />

                {topUpResult && (
                  <div className="bg-green-50 border border-green-200 rounded px-3 py-2.5 text-sm text-left text-green-800 space-y-1">
                    {topUpResult.method === "zenopay" ? (
                      <>
                        <p>Order created. Pay using this link or TAN number:</p>
                        {topUpResult.paymentUrl && (
                          <a href={topUpResult.paymentUrl} target="_blank" rel="noopener noreferrer" className="underline break-all">
                            {topUpResult.paymentUrl}
                          </a>
                        )}
                        {topUpResult.tanNumber && <p>TAN: <strong>{topUpResult.tanNumber}</strong></p>}
                      </>
                    ) : (
                      <p>USSD prompt sent. Approve it on the handset — credits arrive once the payment completes.</p>
                    )}
                  </div>
                )}

                <div className="flex justify-end gap-3">
                  <Button type="submit" loading={saving}>Buy Credits</Button>
                  <Button type="button" variant="secondary" onClick={() => { setTopUpModal(false); setTopUpResult(null); }}>Close</Button>
                </div>
              </form>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); handleTopUp(); }} className="px-5 py-4 space-y-4">
                <NumberInput label="Credits to add" required allowDecimals={false} value={topUpAmount} onChange={(e) => setTopUpAmount(e.target.value)} placeholder="e.g. 1000" />
                <p className="text-xs text-left text-gray-500">
                  Recorded locally only — no payment is taken. Activate a gateway in Settings → Messages to buy
                  real credits.
                </p>
                <div className="flex gap-3">
                  <Button type="submit" loading={saving}>Add Credits</Button>
                  <Button type="button" variant="secondary" onClick={() => setTopUpModal(false)}>Cancel</Button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </MainLayout>
  );
}
