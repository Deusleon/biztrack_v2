import { useAuth } from "../../contexts/AuthContext";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { messagingService } from "../../services/api";
import { useYearAwareClasses } from "../../hooks/useYearAwareClasses";
import MainLayout from "../../components/MainLayout";
import MessagesNav from "./MessagesNav";
import { Select, Input, Button, ConfirmModal, RowActions, ACTION_ICONS } from "../../components/ui";

export default function GroupList() {
  const { can } = useAuth();
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();

  const [groups, setGroups] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);

  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({ name: "", description: "", parent_group_id: "", is_dynamic: false, dynamic_role: "parent", dynamic_class_id: "" });
  const [saving, setSaving] = useState(false);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false });

  const [membersModal, setMembersModal] = useState({ isOpen: false });
  const [memberSearch, setMemberSearch] = useState("");
  const [selectedMemberIds, setSelectedMemberIds] = useState([]);
  const [savingMembers, setSavingMembers] = useState(false);

  const classes = useYearAwareClasses({
    selectedClassId: form.dynamic_class_id,
    onRemap: (newClassId) => setForm((f) => ({ ...f, dynamic_class_id: newClassId })),
  });

  useEffect(() => { load(); }, []);

  const load = async () => {
    try {
      setLoading(true);
      const res = await messagingService.getGroups();
      if (res.success) setGroups(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const openCreate = (parentGroupId = "") => {
    setForm({ name: "", description: "", parent_group_id: parentGroupId, is_dynamic: false, dynamic_role: "parent", dynamic_class_id: "" });
    setModal({ isOpen: true, mode: "create" });
  };

  const openEdit = (g) => {
    setForm({
      name: g.name, description: g.description || "", parent_group_id: g.parent_group_id || "",
      is_dynamic: g.is_dynamic, dynamic_role: g.dynamic_filter?.role || "parent", dynamic_class_id: g.dynamic_filter?.class_id || "",
    });
    setModal({ isOpen: true, mode: "edit", id: g.id });
  };

  const handleSave = async () => {
    if (!form.name) { showError("Group name is required"); return; }
    const payload = {
      name: form.name, description: form.description, parent_group_id: form.parent_group_id || null,
      is_dynamic: form.is_dynamic,
      dynamic_filter: form.is_dynamic ? { role: form.dynamic_role, ...(form.dynamic_class_id && { class_id: form.dynamic_class_id }) } : null,
    };
    try {
      setSaving(true);
      if (modal.mode === "edit") await messagingService.updateGroup(modal.id, payload);
      else await messagingService.createGroup(payload);
      showSuccess(modal.mode === "edit" ? "Group updated" : "Group created");
      setModal({ isOpen: false });
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (g) => setConfirmModal({ isOpen: true, id: g.id, title: "Delete Group", message: `Delete "${g.name}"?` });
  const confirmDelete = async () => {
    try {
      await messagingService.deleteGroup(confirmModal.id);
      showSuccess("Group deleted");
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmModal({ isOpen: false });
  };

  const openManageMembers = async (g) => {
    try {
      const [membersRes, contactsRes] = await Promise.all([
        messagingService.getGroupMembers(g.id),
        messagingService.getContacts({ limit: 500 }),
      ]);
      setContacts(contactsRes.success ? contactsRes.data : []);
      setSelectedMemberIds(membersRes.success ? membersRes.data.map((c) => c.id) : []);
      setMemberSearch("");
      setMembersModal({ isOpen: true, group: g });
    } catch (err) { showError(err.response?.data?.message || err.message); }
  };

  const toggleMember = (contactId) => {
    setSelectedMemberIds((prev) => (prev.includes(contactId) ? prev.filter((id) => id !== contactId) : [...prev, contactId]));
  };

  const saveMembers = async () => {
    try {
      setSavingMembers(true);
      await messagingService.setGroupMembers(membersModal.group.id, selectedMemberIds);
      showSuccess("Members updated");
      setMembersModal({ isOpen: false });
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSavingMembers(false); }
  };

  const topLevelGroups = groups.filter((g) => !g.parent_group_id);
  const subgroupsOf = (id) => groups.filter((g) => g.parent_group_id === id);
  const filteredContacts = contacts.filter((c) => {
    const q = memberSearch.trim().toLowerCase();
    if (!q) return true;
    return c.name?.toLowerCase().includes(q) || c.phone?.toLowerCase().includes(q) || c.email?.toLowerCase().includes(q);
  });

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Contact Groups</h1>
            <p className="text-sm text-gray-500 mt-0.5">Organize contacts into groups and subgroups for quick, targeted messaging</p>
          </div>
          <div className="flex gap-2">
            {can("messages.manage_contacts") && <Button variant="primary" onClick={() => openCreate()}>New Group</Button>}
          </div>
        </div>

        <MessagesNav />

        {loading ? (
          <div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
        ) : topLevelGroups.length === 0 ? (
          <div className="bg-white p-10 rounded shadow text-center text-gray-400 text-sm">No groups yet. Create one to get started.</div>
        ) : (
          <div className="space-y-3">
            {topLevelGroups.map((g) => (
              <div key={g.id} className="bg-white rounded shadow overflow-hidden">
                <GroupRow group={g} onEdit={openEdit} onDelete={handleDelete} onManageMembers={openManageMembers} onAddSubgroup={() => openCreate(g.id)} />
                {subgroupsOf(g.id).length > 0 && (
                  <div className="border-t border-gray-100 pl-8 divide-y divide-gray-50">
                    {subgroupsOf(g.id).map((sub) => (
                      <GroupRow key={sub.id} group={sub} isSub onEdit={openEdit} onDelete={handleDelete} onManageMembers={openManageMembers} />
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Create / Edit modal */}
      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Group" : "New Group"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <Input label="Group Name" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Enter group name" />
              <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} placeholder="Optional" />
              {!form.parent_group_id && (
                <Select
                  label="Parent Group" value={form.parent_group_id}
                  onChange={(e) => setForm((f) => ({ ...f, parent_group_id: e.target.value }))}
                  options={[{ value: "", label: "None — this is a top-level group" }, ...groups.filter((g) => !g.parent_group_id && g.id !== modal.id).map((g) => ({ value: g.id, label: g.name }))]}
                  helperText="Set this to make the group a subgroup of another"
                />
              )}
              <label className="flex items-center gap-2 cursor-pointer text-sm text-gray-700">
                <input type="checkbox" checked={form.is_dynamic} onChange={(e) => setForm((f) => ({ ...f, is_dynamic: e.target.checked }))} className="accent-primary" />
                Smart group (members computed automatically)
              </label>
              {form.is_dynamic ? (
                <div className="bg-indigo-50 border border-indigo-200 rounded p-3 space-y-3">
                  <Select label="Contact type" value={form.dynamic_role} onChange={(e) => setForm((f) => ({ ...f, dynamic_role: e.target.value }))}
                    options={[{ value: "parent", label: "Parents" }, { value: "staff", label: "Staff" }, { value: "student", label: "Students" }, { value: "supplier", label: "Suppliers" }]} />
                  {form.dynamic_role === "parent" && (
                    <Select label="Only parents of this class (optional)" value={form.dynamic_class_id} onChange={(e) => setForm((f) => ({ ...f, dynamic_class_id: e.target.value }))}
                      options={[{ value: "", label: "All parents" }, ...classes.map((c) => ({ value: c.id, label: c.name }))]} />
                  )}
                  <p className="text-xs text-left text-indigo-700">Membership updates automatically.</p>
                </div>
              ) : (
                ""
              )}
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Create"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Manage members modal (static groups only) */}
      {membersModal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-lg">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Members — {membersModal.group.name}</h3>
              <button onClick={() => setMembersModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            {contacts.length > 0 && (
              <div className="px-5 pt-4">
                <Input
                  placeholder="Search by name, phone, or email…"
                  value={memberSearch}
                  onChange={(e) => setMemberSearch(e.target.value)}
                  leftIcon={
                    <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  }
                />
              </div>
            )}
            <div className="px-5 py-4 max-h-[60vh] overflow-y-auto divide-y divide-gray-100">
              {contacts.length === 0 ? (
                <p className="text-sm text-gray-400 py-4">No contacts yet — add some first.</p>
              ) : filteredContacts.length === 0 ? (
                <p className="text-sm text-gray-400 py-4">No contacts match "{memberSearch}".</p>
              ) : (
                filteredContacts.map((c) => (
                  <label key={c.id} className="flex items-center gap-3 py-2 cursor-pointer">
                    <input type="checkbox" checked={selectedMemberIds.includes(c.id)} onChange={() => toggleMember(c.id)} className="accent-primary" />
                    <div>
                      <p className="text-sm text-gray-900">{c.name}</p>
                      <p className="text-xs text-gray-400">{c.phone || c.email}</p>
                    </div>
                  </label>
                ))
              )}
            </div>
            <div className="px-5 py-4 border-t justify-end border-gray-100 flex gap-3">
              <Button onClick={saveMembers} loading={savingMembers}>Save ({selectedMemberIds.length} selected)</Button>
              <Button variant="secondary" onClick={() => setMembersModal({ isOpen: false })}>Cancel</Button>
            </div>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmModal.isOpen} title={confirmModal.title} message={confirmModal.message} variant="danger" onConfirm={confirmDelete} onClose={() => setConfirmModal({ isOpen: false })} />
    </MainLayout>
  );
}

function GroupRow({ group, isSub, onEdit, onDelete, onManageMembers, onAddSubgroup }) {
  const { can } = useAuth();
  return (
    <div className="px-5 py-4 flex flex-wrap items-center justify-between gap-2">
      <div>
        <div className="flex items-center gap-2">
          {isSub && <span className="text-gray-300">↳</span>}
          <p className="text-sm font-semibold text-gray-900">{group.name}</p>
          {group.is_dynamic && <span className="text-xs bg-indigo-100 border border-indigo-300 text-indigo-700 px-2 py-0.5 rounded-full">Smart</span>}
        </div>
        {group.description && <p className="text-xs text-gray-500 mt-0.5">{group.description}</p>}
        <p className="text-xs text-gray-400 mt-0.5">{group.member_count} member{group.member_count === 1 ? "" : "s"}</p>
      </div>
      <RowActions
        actions={[
          { label: "Manage Members", variant: "primary", icon: ACTION_ICONS.members, hidden: !can("messages.manage_contacts") || group.is_dynamic, onClick: () => onManageMembers(group) },
          { label: "Add Subgroup", icon: ACTION_ICONS.add, hidden: !can("messages.manage_contacts") || !onAddSubgroup, onClick: onAddSubgroup },
          { label: "Edit Group", icon: ACTION_ICONS.edit, hidden: !can("messages.manage_contacts"), onClick: () => onEdit(group) },
          { label: "Delete Group", variant: "danger", icon: ACTION_ICONS.delete, hidden: !can("messages.manage_contacts"), onClick: () => onDelete(group) },
        ]}
      />
    </div>
  );
}
