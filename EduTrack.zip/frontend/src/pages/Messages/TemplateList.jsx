import { useAuth } from "../../contexts/AuthContext";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { messagingService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import MessagesNav from "./MessagesNav";
import { Select, Input, ConfirmModal, Button, DataTable, RowActions, ACTION_ICONS } from "../../components/ui";
import Icon from "../../components/ui/Icon";

const CATEGORIES = [
  { value: "fee_reminder", label: "Fee Reminder" },
  { value: "exam_result", label: "Exam Result" },
  { value: "attendance", label: "Attendance" },
  { value: "general", label: "General" },
  { value: "event", label: "Event" },
  { value: "custom", label: "Custom" },
];
const CHANNELS = [{ value: "sms", label: "SMS" }, { value: "email", label: "Email" }, { value: "in_app", label: "In-App" }];

export default function TemplateList() {
  const { can } = useAuth();
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();

  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);

  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({ name: "", category: "general", channel: "sms", subject: "", body: "" });
  const [saving, setSaving] = useState(false);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false });

  useEffect(() => { load(); }, []);

  const load = async () => {
    try {
      setLoading(true);
      const res = await messagingService.getTemplates();
      if (res.success) setTemplates(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const openCreate = () => { setForm({ name: "", category: "general", channel: "sms", subject: "", body: "" }); setModal({ isOpen: true, mode: "create" }); };
  const openEdit = (t) => { setForm({ name: t.name, category: t.category, channel: t.channel, subject: t.subject || "", body: t.body }); setModal({ isOpen: true, mode: "edit", id: t.id }); };

  const handleSave = async () => {
    if (!form.name || !form.body) { showError("Name and body are required"); return; }
    try {
      setSaving(true);
      if (modal.mode === "edit") await messagingService.updateTemplate(modal.id, form);
      else await messagingService.createTemplate(form);
      showSuccess(modal.mode === "edit" ? "Template updated" : "Template created");
      setModal({ isOpen: false });
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (t) => setConfirmModal({ isOpen: true, id: t.id, title: "Delete Template", message: `Delete "${t.name}"?` });
  const confirmDelete = async () => {
    try { await messagingService.deleteTemplate(confirmModal.id); showSuccess("Template deleted"); load(); }
    catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmModal({ isOpen: false });
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Message Templates</h1>
            <p className="text-sm text-gray-500 mt-0.5">Reusable messages — use <code className="bg-gray-100 px-1 rounded">{"{{name}}"}</code> to personalize</p>
          </div>
          <div className="flex gap-2">
            {can("messages.manage_templates") && <Button variant="primary" onClick={openCreate}>New Template</Button>}
          </div>
        </div>

        <MessagesNav />

        {loading ? (
          <div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
        ) : (
          <div className="bg-white rounded shadow overflow-hidden">
            <DataTable
              columns={[
                {
                  key: "name", label: "Template",
                  render: (t) => (
                    <div>
                      <button onClick={() => navigate(`/messages/compose?template=${t.id}`)} className="text-sm font-medium text-gray-900 hover:text-primary hover:underline text-left">
                        {t.name}
                      </button>
                      <p className="text-sm text-gray-400 mt-0.5 line-clamp-1 max-w-md">{t.body}</p>
                    </div>
                  ),
                },
                { key: "category", label: "Category", render: (t) => <span className="text-xs bg-gray-100 border border-gray-300 text-gray-600 px-2 py-0.5 rounded-full capitalize">{t.category.replace("_", " ")}</span> },
                { key: "channel", label: "Channel", render: (t) => <span className="text-xs bg-primary-15 border border-primary-30 text-primary px-2 py-0.5 rounded-full uppercase">{t.channel}</span> },
              ]}
              data={templates}
              loading={loading}
              emptyMessage="No templates yet."
              renderActions={(t) => (
                <RowActions
                  actions={[
                    { label: "Use Template", variant: "primary", icon: ACTION_ICONS.copy, hidden: !can("messages.manage_templates"), onClick: () => navigate(`/messages/compose?template=${t.id}`) },
                    { label: "Edit Template", icon: ACTION_ICONS.edit, hidden: !can("messages.manage_templates"), onClick: () => openEdit(t) },
                    { label: "Delete Template", variant: "danger", icon: ACTION_ICONS.delete, hidden: !can("messages.manage_templates"), onClick: () => handleDelete(t) },
                  ]}
                />
              )}
            />
          </div>
        )}
      </div>

      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Template" : "New Template"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <Input label="Template Name" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Enter template name" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Select label="Category" value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))} options={CATEGORIES} />
                <Select label="Channel" value={form.channel} onChange={(e) => setForm((f) => ({ ...f, channel: e.target.value }))} options={CHANNELS} />
              </div>
              {form.channel === "email" && <Input label="Subject" value={form.subject} onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))} />}
              <div className="text-left">
                <label className="text-sm font-medium text-gray-700 block mb-1">Body</label>
                <textarea className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-primary" rows={5}
                  value={form.body} onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))} placeholder="Use {{name}} to personalize" />
              </div>
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Create"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmModal.isOpen} title={confirmModal.title} message={confirmModal.message} variant="danger" onConfirm={confirmDelete} onClose={() => setConfirmModal({ isOpen: false })} />
    </MainLayout>
  );
}
