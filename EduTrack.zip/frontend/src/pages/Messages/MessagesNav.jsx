// FILE PATH: frontend/src/pages/Messages/MessagesNav.jsx
import { useNavigate, useLocation, Navigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";

// Each tab needs its own permission, so a person sees only the tabs they can use.
const TABS = [
  { path: "/messages/contacts", label: "Contacts", needs: "messages.view" },
  { path: "/messages/groups", label: "Groups", needs: "messages.view" },
  { path: "/messages/compose", label: "Compose", needs: "send_messages" },
  { path: "/messages/history", label: "History", needs: "messages.view" },
  { path: "/messages/inquiries", label: "Website Inquiries", needs: "inquiries.view" },
  { path: "/messages/templates", label: "Templates", needs: "messages.view" },
  { path: "/messages/balance", label: "Info", needs: "messages.view" },
];

/** /messages itself: open the first tab this person is allowed to use. */
export function MessagesIndex() {
  const { user, can } = useAuth();
  const known = Array.isArray(user?.effective_permissions);
  const first = TABS.find((t) => !known || can(t.needs));
  return first ? <Navigate to={first.path} replace /> : <Navigate to="/dashboard" replace />;
}

/** Renders a consistent tab bar across every page under /messages so
 * it's always one click to jump to Contacts, Groups, Compose (send a new
 * SMS — including to a custom number not saved as a contact), History,
 * Templates, or the SMS balance, no matter which of those pages you're
 * currently on. */
export default function MessagesNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, can } = useAuth();
  const known = Array.isArray(user?.effective_permissions);

  return (
    <div className="bg-white rounded shadow overflow-x-auto">
      <div className="flex min-w-max">
        {TABS.filter((tab) => !known || can(tab.needs)).map((tab) => {
          const isActive = location.pathname === tab.path || (tab.path === "/messages/contacts" && location.pathname === "/messages");
          return (
            <button
              key={tab.path}
              onClick={() => navigate(tab.path)}
              className={`px-5 py-3 text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
                isActive ? "border-primary text-primary" : "border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-200"
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}