import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { messagingService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import MessagesNav from "./MessagesNav";
import { Select, DataTable, ConfirmModal, RowActions, ACTION_ICONS, Button } from "../../components/ui";
import Icon from "../../components/ui/Icon";

const STATUS_STYLES = {
  draft: "bg-gray-100 border border-gray-300 text-gray-600",
  queued: "bg-blue-100 border border-blue-300 text-blue-500",
  sending: "bg-yellow-100 border border-yellow-300 text-yellow-500",
  sent: "bg-green-100 border border-green-300 text-green-500",
  partially_sent: "bg-orange-100 border border-orange-300 text-orange-500",
  failed: "bg-red-100 border border-red-300 text-red-500",
};

const RECIPIENT_LABELS = {
  individual: "Single Contact", group: "Group", subgroup: "Subgroup",
  role_broadcast: "Broadcast", custom_numbers: "Custom Numbers", selected_contacts: "Selected Contacts",
};

export default function MessageHistory() {
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();
  const { formatDateTime } = usePreferences();

  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = usePersistedState("filters", { status: "", channel: "" });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 15 });
  const [confirmModal, setConfirmModal] = useState({ isOpen: false });

  useEffect(() => { load(); }, [filters, pagination.currentPage]);

  const load = async () => {
    try {
      setLoading(true);
      const res = await messagingService.getMessages({ ...filters, page: pagination.currentPage, limit: pagination.itemsPerPage });
      if (res.success) { setMessages(res.data); setPagination((p) => ({ ...p, ...res.pagination })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const handleDeleteDraft = (m) => {
    setConfirmModal({ isOpen: true, id: m.id, title: "Delete Draft", message: "Delete this draft message? This can't be undone." });
  };
  const confirmDeleteDraft = async () => {
    try {
      await messagingService.deleteMessage(confirmModal.id);
      showSuccess("Draft deleted");
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmModal({ isOpen: false });
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Message History</h1>
            <p className="text-sm text-gray-500 mt-0.5">Everything sent, with delivery status</p>
          </div>
          <div className="flex gap-2">
            <Button variant="primary" onClick={() => navigate("/messages/compose")}>New Message</Button>
          </div>
        </div>

        <MessagesNav />

        <div className="bg-white p-5 rounded shadow">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Select label="Status" value={filters.status} onChange={(e) => { setFilters((f) => ({ ...f, status: e.target.value })); setPagination((p) => ({ ...p, currentPage: 1 })); }}
              options={[{ value: "", label: "All Statuses" }, ...Object.keys(STATUS_STYLES).map((s) => ({ value: s, label: s.replace("_", " ").replace(/\b\w/g, (c) => c.toUpperCase()) }))]} />
            <Select label="Channel" value={filters.channel} onChange={(e) => { setFilters((f) => ({ ...f, channel: e.target.value })); setPagination((p) => ({ ...p, currentPage: 1 })); }}
              options={[{ value: "", label: "All Channels" }, { value: "sms", label: "SMS" }, { value: "email", label: "Email" }, { value: "in_app", label: "In-App" }]} />
          </div>
        </div>

        <DataTable
          columns={[
            {
              key: "body", label: "Message",
              render: (m) => (
                <div className="max-w-xs">
                  <p className="text-sm truncate">{m.subject || m.body}</p>
                  <p className="text-xs text-gray-500">{RECIPIENT_LABELS[m.recipient_type]} — {m.recipient_summary}</p>
                </div>
              ),
            },
            { key: "channel", label: "Channel", render: (m) => <span className="text-sm uppercase">{m.channel}</span> },
            { key: "sender", label: "Sent By", render: (m) => <span className="text-sm">{m.is_automated ? "System" : m.sender ? `${m.sender.first_name} ${m.sender.last_name}` : "—"}</span> },
            { key: "status", label: "Status", render: (m) => <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${STATUS_STYLES[m.status]}`}>{m.status.replace("_", " ")}</span> },
            {
              key: "delivered", label: "Delivered",
              render: (m) => (
                <span className="text-sm  text-green-500">
                  {m.delivered_count}
                </span>
              ),
            },
            {
              key: "failed", label: "Failed",
              render: (m) => (
                <span className="text-sm text-red-500">
                  {m.provider_failed_count}
                </span>
              ),
            },
            { key: "date", label: "Date", render: (m) => <span className="text-sm">{formatDateTime(m.sent_at || m.createdAt)}</span> },
          ]}
          data={messages}
          loading={loading}
          emptyMessage="No messages sent yet"
          renderActions={(m) => (
            <RowActions
              actions={[
                { label: 'Edit Draft', variant: 'primary', icon: ACTION_ICONS.edit, hidden: m.status !== 'draft', onClick: () => navigate(`/messages/compose?draft=${m.id}`) },
                { label: 'View Message', variant: 'primary', icon: ACTION_ICONS.view, hidden: m.status === 'draft', onClick: () => navigate(`/messages/history/${m.id}`) },
                { label: 'Delete Draft', variant: 'danger', icon: ACTION_ICONS.delete, hidden: m.status !== 'draft', onClick: () => handleDeleteDraft(m) },
              ]}
            />
          )}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      <ConfirmModal isOpen={confirmModal.isOpen} title={confirmModal.title} message={confirmModal.message} variant="danger" onConfirm={confirmDeleteDraft} onClose={() => setConfirmModal({ isOpen: false })} />
    </MainLayout>
  );
}
