export { default as ExamList } from './ExamList';
export { default as MarksEntry } from './MarksEntry';
export { default as ResultsHome } from './ResultsHome';
export { default as ReportCard } from './ReportCard';
export { default as TermSummary } from './TermSummary';
