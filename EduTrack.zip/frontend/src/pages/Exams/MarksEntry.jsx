import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { examService, classService, subjectService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Input, Button, DataTable } from "../../components/ui";

const gradeColor = (grade) => ({
  A: "text-green-600", B: "text-blue-600", C: "text-yellow-600", D: "text-orange-600", F: "text-red-600",
}[grade] || "text-gray-300");

const computeGradePreview = (marks, max) => {
  if (marks === "" || marks === null || marks === undefined || !max) return null;
  const pct = (Number(marks) / Number(max)) * 100;
  if (pct >= 75) return "A";
  if (pct >= 65) return "B";
  if (pct >= 45) return "C";
  if (pct >= 30) return "D";
  return "F";
};

export default function MarksEntry() {
  const { id: examId } = useParams();
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();

  const [exam, setExam]         = useState(null);
  const [classes, setClasses]   = useState([]);
  const [sections, setSections] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [selectedClass, setSelectedClass]     = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [maxMarks, setMaxMarks] = useState(100);

  const [rows, setRows]         = useState([]);
  const [loadingSheet, setLoadingSheet] = useState(false);
  const [saving, setSaving]     = useState(false);

  useEffect(() => {
    examService.getById(examId).then((res) => { if (res.success) setExam(res.data); });
    subjectService.getAll({ limit: 200, status: "active" }).then((res) => { if (res.success) setSubjects(res.data); });
  }, [examId]);

  useEffect(() => {
    // Classes for THIS exam's own academic year, not whatever the global
    // year selector currently shows — an exam is fixed to one year the
    // moment it's created, so entering marks for an older exam must
    // still offer that exam's own classes. Narrowed further to exactly
    // the classes the exam actually covers (`exam.class_ids`), so a
    // class that shares the same year but wasn't part of this exam
    // never shows up as a pickable option.
    if (!exam) return;
    classService.getAll({ limit: 200, status: "active", academic_year: exam.academic_year }).then((res) => {
      if (!res.success) return;
      const allowed = new Set(exam.class_ids || []);
      setClasses(allowed.size ? res.data.filter((c) => allowed.has(c.id)) : res.data);
    });
  }, [exam]);

  // If the exam is limited to specific classes, only offer those here.
  const availableClasses = exam?.class_ids?.length ? classes.filter((c) => exam.class_ids.includes(c.id)) : classes;

  useEffect(() => {
    const cls = classes.find((c) => c.id === selectedClass);
    setSections(cls?.sections || []);
    setSelectedSection("");
    setRows([]);
  }, [selectedClass]);

  const loadSheet = async () => {
    if (!selectedClass || !selectedSubject) { showError("Pick a class and a subject first"); return; }
    try {
      setLoadingSheet(true);
      const res = await examService.getMarksSheet(examId, {
        class_id: selectedClass,
        section_id: selectedSection || undefined,
        subject_id: selectedSubject,
      });
      if (res.success) {
        setRows(res.data.map((r) => ({ ...r, marks_obtained: r.marks_obtained ?? "" })));
        const existingMax = res.data.find((r) => r.max_marks)?.max_marks;
        if (existingMax) setMaxMarks(existingMax);
      }
    } catch (err) { showError(err.message); }
    finally { setLoadingSheet(false); }
  };

  const updateMark = (studentId, value) => {
    setRows((prev) => prev.map((r) => (r.student_id === studentId ? { ...r, marks_obtained: value } : r)));
  };

  const handleSave = async () => {
    if (rows.length === 0) return;
    const maxMarksNum = Number(maxMarks);
    if (!(maxMarksNum > 0)) { showError("Max marks must be greater than 0"); return; }
    for (const r of rows) {
      if (r.marks_obtained !== "" && (Number(r.marks_obtained) < 0 || Number(r.marks_obtained) > maxMarksNum)) {
        showError(`${r.name}'s marks are out of range (0–${maxMarksNum})`);
        return;
      }
    }
    try {
      setSaving(true);
      await examService.saveMarks(examId, {
        class_id: selectedClass,
        section_id: selectedSection || undefined,
        subject_id: selectedSubject,
        max_marks: maxMarksNum,
        records: rows.map((r) => ({ student_id: r.student_id, marks_obtained: r.marks_obtained === "" ? null : Number(r.marks_obtained) })),
      });
      showSuccess("Marks saved");
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const filledCount = rows.filter((r) => r.marks_obtained !== "").length;

  // Rank students within this subject by marks — standard "competition"
  // ranking, so tied scores share a rank and the next rank skips ahead
  // (1, 2, 2, 4…). Only rows with marks entered get ranked.
  const ranksById = (() => {
    const filled = rows.filter((r) => r.marks_obtained !== "" && r.marks_obtained !== null && r.marks_obtained !== undefined);
    const sorted = [...filled].sort((a, b) => Number(b.marks_obtained) - Number(a.marks_obtained));
    const map = {};
    let rank = 0, prevMarks = null, seen = 0;
    sorted.forEach((r) => {
      seen++;
      const m = Number(r.marks_obtained);
      if (m !== prevMarks) { rank = seen; prevMarks = m; }
      map[r.student_id] = rank;
    });
    return map;
  })();

  const ordinal = (n) => {
    const s = ["th", "st", "nd", "rd"];
    const v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
  };

  const handleDownloadTemplate = async () => {
    if (rows.length === 0) return;
    const XLSX = await import("xlsx");
    const wsData = [
      ["Admission No.", "Student Name", `Marks (out of ${maxMarks})`],
      ...rows.map((r) => [r.admission_number, r.name, r.marks_obtained !== "" ? r.marks_obtained : ""]),
    ];
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Marks");
    XLSX.writeFile(wb, `marks_template_${(exam?.name || "exam").replace(/\s+/g, "_")}.xlsx`);
  };

  const handleImportFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-selecting the same file later
    if (!file) return;
    try {
      const XLSX = await import("xlsx");
      const buffer = await file.arrayBuffer();
      const wb = XLSX.read(buffer, { type: "array" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const data = XLSX.utils.sheet_to_json(sheet, { defval: "" });

      if (data.length === 0) { showError("The file appears to be empty"); return; }

      // Match rows by Admission Number (case-insensitive, trimmed) — the
      // safest key since names can repeat or be typed differently.
      const byAdmission = {};
      rows.forEach((r) => { byAdmission[String(r.admission_number).trim().toLowerCase()] = r.student_id; });

      let updated = 0, skipped = 0;
      const marksById = {};
      data.forEach((record) => {
        const admNoKey = Object.keys(record).find((k) => /adm/i.test(k)) || "Admission No.";
        const marksKey = Object.keys(record).find((k) => /marks/i.test(k)) || "Marks";
        const admNo = String(record[admNoKey] ?? "").trim().toLowerCase();
        const studentId = byAdmission[admNo];
        if (!studentId) { skipped++; return; }
        const marksVal = record[marksKey];
        if (marksVal === "" || marksVal === undefined || marksVal === null) return;
        marksById[studentId] = marksVal;
        updated++;
      });

      setRows((prev) => prev.map((r) => (marksById[r.student_id] !== undefined ? { ...r, marks_obtained: marksById[r.student_id] } : r)));
      showSuccess(`Imported marks for ${updated} student(s)` + (skipped > 0 ? ` — ${skipped} row(s) didn't match any admission number` : ""));
    } catch (err) {
      showError("Couldn't read that file. Make sure it's the downloaded template (or has 'Admission No.' and 'Marks' columns).");
    }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Enter Marks</h1>
            <p className="text-sm text-gray-500 mt-0.5">{exam?.name} — {exam?.academic_year} {exam?.term && `• ${exam.term}`}</p>
          </div>
          <Button 
            onClick={() => navigate("/exams")}
            variant="lightPrimary"
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to Exams
          </Button>
        </div>

        {/* Selection panel */}
        <div className="bg-white p-5 rounded shadow">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 items-end">
            <Select
              label="Class"
              required
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              options={[{ value: "", label: "Select…" }, ...availableClasses.map((c) => ({ value: c.id, label: c.name }))]}
            />
            <Select
              label="Section"
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              disabled={!selectedClass}
              options={[{ value: "", label: "All sections" }, ...sections.map((s) => ({ value: s.id, label: s.name }))]}
            />
            <Select
              label="Subject"
              required
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              options={[{ value: "", label: "Select…" }, ...subjects.map((s) => ({ value: s.id, label: s.name }))]}
            />
            <Input label="Out of" type="number" min={1} value={maxMarks} onChange={(e) => setMaxMarks(e.target.value)} />
            <button
              onClick={loadSheet}
              disabled={!selectedClass || !selectedSubject || loadingSheet}
              className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90 disabled:opacity-50"
            >
              {loadingSheet ? "Loading…" : "Load Students"}
            </button>
          </div>
        </div>

        {rows.length > 0 && (
          <div className="space-y-3">
            <div className="bg-white px-5 py-3 rounded shadow flex items-center justify-between flex-wrap gap-2">
              <p className="text-sm text-gray-600">
                <span className="font-semibold text-gray-900">{rows.length}</span> student(s) —{" "}
                <span className="font-semibold text-gray-900">{filledCount}</span> marked
              </p>
              <div className="flex items-center gap-2">
                <Button variant="secondary" size="sm" onClick={handleDownloadTemplate}>Download Template</Button>
                <label className="border border-gray-300 text-sm text-gray-700 px-3 py-1.5 rounded hover:bg-gray-50 flex items-center gap-1.5 cursor-pointer">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
                  Import from Excel
                  <input type="file" accept=".xlsx,.xls,.csv" onChange={handleImportFile} className="hidden" />
                </label>
                <Button variant="lightPrimary" onClick={handleSave} loading={saving} size="sm">Save Marks</Button>
              </div>
            </div>

            <DataTable
              columns={[
                { key: "no", label: "No.", width: "w-16", render: (r, index) => <span className="text-sm">{index + 1}.</span> },
                { key: "admission_number", label: "Adm No.", render: (r) => <span className="text-sm">{r.admission_number}</span> },
                { key: "name", label: "Student", render: (r) => <span className="text-sm">{r.name}</span> },
                {
                  key: "marks", label: `Marks / ${maxMarks}`,
                  render: (r) => (
                    <input
                      type="number" min={0} max={maxMarks}
                      className="w-20 border border-gray-300 rounded px-2 py-1.5 text-sm text-center focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                      value={r.marks_obtained}
                      onChange={(e) => updateMark(r.student_id, e.target.value)}
                      placeholder="—"
                    />
                  ),
                },
                {
                  key: "grade", label: "Grade",
                  render: (r) => {
                    const preview = computeGradePreview(r.marks_obtained, maxMarks);
                    return <span className={`font-bold text-sm ${gradeColor(preview)}`}>{preview || "—"}</span>;
                  },
                },
                {
                  key: "position", label: "Position",
                  render: (r) => {
                    const rank = ranksById[r.student_id];
                    if (!rank) return <span className="text-gray-400">—</span>;
                    return (
                      <span className={`text-sm font-semibold ${rank === 1 ? "text-amber-600" : rank === 2 ? "text-gray-500" : rank === 3 ? "text-orange-700" : "text-gray-700"}`}>
                        {ordinal(rank)}
                      </span>
                    );
                  },
                },
              ]}
              data={rows}
              rowId="student_id"
            />
          </div>
        )}
      </div>
    </MainLayout>
  );
}
