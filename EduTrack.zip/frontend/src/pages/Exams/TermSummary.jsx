import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { useCampus } from "../../contexts/CampusContext";
import { examService, classService } from "../../services/api";
import { exportResultsPDF, exportResultsExcel } from "../../utils/examExport";
import MainLayout from "../../components/MainLayout";
import { Select, Button } from "../../components/ui";

const gradeColor = (grade) => ({
  A: "text-green-600", B: "text-blue-600", C: "text-yellow-600", D: "text-orange-600", F: "text-red-600",
}[grade] || "text-gray-300");

const TERMS = ["Term 1", "Term 2", "Term 3"];

export default function TermSummary() {
  const navigate = useNavigate();
  const { currentAcademicYear } = useAcademicYear();
  const { currentCampus } = useCampus();
  const { showError } = useToast();

  const [classes, setClasses] = useState([]);
  const [sections, setSections] = useState([]);
  const [selectedTerm, setSelectedTerm] = useState("Term 1");
  const [selectedClass, setSelectedClass] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState("");

  useEffect(() => {
    classService.getAll({ limit: 200, status: "active", academic_year: currentAcademicYear }).then((res) => { if (res.success) setClasses(res.data); });
  }, [currentAcademicYear]);

  useEffect(() => {
    const cls = classes.find((c) => c.id === selectedClass);
    setSections(cls?.sections || []);
    setSelectedSection("");
  }, [selectedClass]);

  const loadSummary = async () => {
    if (!selectedClass) { showError("Pick a class first"); return; }
    try {
      setLoading(true);
      const res = await examService.getTermSummary({
        academic_year: currentAcademicYear, term: selectedTerm,
        class_id: selectedClass, section_id: selectedSection || undefined,
      });
      if (res.success) setResults(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const currentClassLabel = () => {
    const cls = classes.find((c) => c.id === selectedClass);
    const sec = sections.find((s) => s.id === selectedSection);
    return `${cls?.name || ""}${sec ? ` ${sec.name}` : ""}`.trim();
  };

  const handleExportPDF = async () => {
    if (!results) return;
    try {
      setExporting("pdf");
      await exportResultsPDF({
        school: currentCampus,
        title: `${selectedTerm} Summary — ${currentClassLabel()}`,
        subtitle: `${currentAcademicYear} • Combines: ${results.exams.map((e) => e.name).join(", ")}`,
        subjects: results.subjects, students: results.students,
        filename: `${selectedTerm.replace(/\s+/g, "_")}_Summary_${currentClassLabel().replace(/\s+/g, "_")}`,
      });
    } catch { showError("Failed to export PDF"); }
    finally { setExporting(""); }
  };

  const handleExportExcel = async () => {
    if (!results) return;
    try {
      setExporting("excel");
      await exportResultsExcel({
        title: `${selectedTerm} Summary — ${currentClassLabel()}`,
        subjects: results.subjects, students: results.students,
        filename: `${selectedTerm.replace(/\s+/g, "_")}_Summary_${currentClassLabel().replace(/\s+/g, "_")}`,
      });
    } catch { showError("Failed to export Excel"); }
    finally { setExporting(""); }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Term Summary</h1>
            <p className="text-sm text-gray-500 mt-0.5">Combines every exam in a term into one consolidated report per subject</p>
          </div>
          <Button
            onClick={() => navigate("/results")}
            variant="lightPrimary"
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to Results
          </Button>
        </div>

        <div className="bg-white p-5 rounded shadow">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 items-end">
            <span className="text-xs text-gray-500 bg-gray-100 border border-gray-200 rounded px-3 py-3">
              Year: <strong className="text-gray-700">{currentAcademicYear}</strong>
            </span>
            <Select label="Term" value={selectedTerm} onChange={(e) => setSelectedTerm(e.target.value)}
              options={TERMS.map((t) => ({ value: t, label: t }))} />
            <Select label="Class" required value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)}
              options={[{ value: "", label: "Select…" }, ...classes.map((c) => ({ value: c.id, label: c.name }))]} />
            <Select label="Section" value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} disabled={!selectedClass}
              options={[{ value: "", label: "All sections" }, ...sections.map((s) => ({ value: s.id, label: s.name }))]} />
            <Button variant="primary" mobileLabel="View Summary" onClick={loadSummary} disabled={!selectedClass || loading}>{loading ? "Loading…" : "View Summary"}</Button>
          </div>
        </div>

        {results && (
          results.exams.length === 0 ? (
            <div className="bg-white p-10 rounded shadow text-center">
              <svg className="w-12 h-12 text-gray-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <p className="text-gray-500 text-sm">No exams found for {selectedTerm}, {currentAcademicYear}.</p>
            </div>
          ) : results.students.length === 0 ? (
            <div className="bg-white p-10 rounded shadow text-center">
              <p className="text-gray-500 text-sm">No students in this class/section.</p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="bg-white shadow rounded px-4 py-3 text-sm text-gray-700 flex items-center justify-between flex-wrap gap-2">
                <span>Combining <strong>{results.exams.length}</strong> exam(s): {results.exams.map((e) => e.name).join(", ")}</span>
                <div className="flex gap-2">
                  <Button variant="secondary" size="sm" mobileLabel="Export PDF" onClick={handleExportPDF} disabled={!!exporting}>{exporting === "pdf" ? "Exporting…" : "Export PDF"}</Button>
                  <Button variant="secondary" size="sm" mobileLabel="Export Excel" onClick={handleExportExcel} disabled={!!exporting}>{exporting === "excel" ? "Exporting…" : "Export Excel"}</Button>
                </div>
              </div>

              <div className="bg-white rounded shadow overflow-x-auto lg:overflow-visible">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Adm No.</th>
                      <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student</th>
                      {results.subjects.map((s) => (
                        <th key={s.id} className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">{s.code || s.name}</th>
                      ))}
                      <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                      <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Avg %</th>
                      <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Grade</th>
                      <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Rank</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {results.students.map((r) => (
                      <tr key={r.student_id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-5 py-2 text-sm text-left text-gray-500">{r.admission_number}</td>
                        <td className="px-5 py-2 text-sm text-left font-medium text-gray-900">{r.name}</td>
                        {r.subjects.map((sg) => (
                          <td key={sg.subject_id} className="px-4 py-2 text-center text-sm text-gray-700">
                            {sg.marks_obtained !== null ? sg.marks_obtained : <span className="text-gray-300">—</span>}
                          </td>
                        ))}
                        <td className="px-5 py-2 text-center text-sm font-semibold text-gray-900">
                          {r.total_obtained !== null ? r.total_obtained : <span className="text-gray-300">—</span>}
                        </td>
                        <td className="px-5 py-2 text-center text-sm text-gray-700">{r.average !== null ? `${r.average}%` : <span className="text-gray-300">—</span>}</td>
                        <td className={`px-5 py-2 text-center text-sm font-bold ${gradeColor(r.overall_grade)}`}>{r.overall_grade || "—"}</td>
                        <td className="px-5 py-2 text-center text-sm text-gray-700">{r.position || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )
        )}
      </div>
    </MainLayout>
  );
}