import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { usePersistedState } from "../../hooks/usePersistedState";
import { examService, campusService, classService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Input, DataTable, ConfirmModal, Button, DatePicker, RowActions, ACTION_ICONS } from "../../components/ui";

const STATUS_STYLES = {
  draft:     "bg-gray-100 border border-gray-300 text-gray-600",
  scheduled: "bg-blue-100 border border-blue-300 text-blue-500",
  ongoing:   "bg-yellow-100 border border-yellow-300 text-yellow-600",
  completed: "bg-green-100 border border-green-300 text-green-500",
  cancelled: "bg-red-100 border border-red-300 text-red-500",
};

const EXAM_TYPES = ["Midterm", "Final", "Mock", "Quiz", "Continuous Assessment"];
const TERMS = ["Term 1", "Term 2"];

export default function ExamList() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { currentAcademicYear } = useAcademicYear();
  const { formatDate } = usePreferences();
  const { showSuccess, showError } = useToast();

  const isStaff = can("exams.marks");

  const [exams, setExams] = useState([]);
  const [campuses, setCampuses] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);

  const [filters, setFilters] = usePersistedState("filters", {
    search: "", status: "", academic_year: "",
    sortBy: "start_date", sortOrder: "DESC",
  });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 10 });

  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({
    name: "", exam_type: "Midterm", academic_year: currentAcademicYear, term: "Term 1",
    start_date: "", end_date: "", status: "draft", campus_id: "", class_ids: [],
  });
  const [saving, setSaving] = useState(false);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false });

  // Keep the year filter tied to the header selection.
  useEffect(() => {
    setFilters((f) => (f.academic_year === currentAcademicYear ? f : { ...f, academic_year: currentAcademicYear }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  }, [currentAcademicYear]);

  // Held until the filter matches the selected year. Both effects fire on
  // mount, and without this guard the first fetch went out with an empty
  // year and listed exams from every year before being replaced.
  useEffect(() => {
    if (filters.academic_year !== currentAcademicYear) return;
    fetchExams();
  }, [filters, pagination.currentPage, currentAcademicYear]);

  useEffect(() => { fetchCampuses(); fetchClasses(); }, [currentAcademicYear]);

  const fetchExams = async () => {
    try {
      setLoading(true);
      const res = await examService.getAll({
        ...filters, page: pagination.currentPage, limit: pagination.itemsPerPage,
      });
      if (res.success) {
        setExams(res.data);
        setPagination((p) => ({ ...p, ...res.pagination }));
      }
    } catch (err) { showError(err.message || "Failed to fetch exams"); }
    finally { setLoading(false); }
  };

  const fetchCampuses = async () => {
    try {
      const res = await campusService.getAll({ limit: 100 });
      if (res.success) {
        setCampuses(res.data);
        if (res.data.length === 1) setForm((f) => ({ ...f, campus_id: res.data[0].id }));
      }
    } catch { /* non-fatal */ }
  };

  const fetchClasses = async () => {
    try {
      // Classes offered when CREATING an exam are for the current
      // academic year only — a new exam is always for the year that's
      // currently selected, and this avoids the same class name
      // ("Form I") appearing once per year it has ever existed.
      const res = await classService.getAll({ limit: 200, status: "active", academic_year: currentAcademicYear });
      if (res.success) setClasses(res.data);
    } catch { /* non-fatal */ }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((f) => ({ ...f, [name]: value }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const openCreate = () => {
    setForm({
      name: "", exam_type: "Midterm", academic_year: currentAcademicYear, term: "Term 1",
      start_date: "", end_date: "", status: "draft", campus_id: campuses[0]?.id || "", class_ids: [],
    });
    setModal({ isOpen: true, mode: "create" });
  };

  const openEdit = (exam) => {
    setForm({
      name: exam.name, exam_type: exam.exam_type || "Midterm", academic_year: exam.academic_year,
      term: exam.term || "Term 1", start_date: exam.start_date || "", end_date: exam.end_date || "",
      status: exam.status, campus_id: exam.campus_id, class_ids: exam.class_ids || [],
    });
    setModal({ isOpen: true, mode: "edit", id: exam.id });
  };

  const handleSave = async () => {
    if (!form.name || !form.academic_year || !form.campus_id) {
      showError("Name, academic year and campus are required");
      return;
    }
    try {
      setSaving(true);
      if (modal.mode === "edit") await examService.update(modal.id, form);
      else await examService.create(form);
      showSuccess(modal.mode === "edit" ? "Exam updated" : "Exam created");
      setModal({ isOpen: false });
      fetchExams();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (exam) => {
    setConfirmModal({ isOpen: true, id: exam.id, title: "Delete Exam", message: `Delete "${exam.name}"? This can't be undone.`, variant: "danger" });
  };

  const confirmDelete = async () => {
    try {
      await examService.delete(confirmModal.id);
      showSuccess("Exam deleted");
      fetchExams();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmModal({ isOpen: false });
  };

  // ── Stat cards ──────────────────────────────────────────────────────────
  const totalExams = pagination.totalItems;
  const ongoingCount = exams.filter((e) => e.status === "ongoing").length;
  const completedCount = exams.filter((e) => e.status === "completed").length;
  const draftCount = exams.filter((e) => e.status === "draft").length;

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Exams</h1>
            <p className="text-sm text-gray-500 mt-0.5">Create exams, enter marks, and view results</p>
          </div>
          {can("exams.create") && (
            <Button onClick={openCreate} className="bg-primary text-sm text-white px-5 py-2.5 rounded hover:opacity-90 flex items-center space-x-2">
              <span>New Exam</span>
            </Button>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Total Exams</p>
                <p className="text-2xl text-left font-bold text-primary mt-1">{totalExams}</p>
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Ongoing</p>
                <p className="text-2xl text-left font-bold text-yellow-600 mt-1">{ongoingCount}</p>
              </div>
              <div className="bg-yellow-100 p-3 rounded">
                <svg className="w-8 h-8 text-yellow-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Completed</p>
                <p className="text-2xl text-left font-bold text-green-600 mt-1">{completedCount}</p>
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg className="w-8 h-8 text-green-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Draft</p>
                <p className="text-2xl text-left font-bold text-gray-600 mt-1">{draftCount}</p>
              </div>
              <div className="bg-gray-100 p-3 rounded">
                <svg className="w-8 h-8 text-gray-500 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-5 rounded shadow">
          <form onSubmit={(e) => { e.preventDefault(); fetchExams(); }} className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="md:col-span-2">
              <Input
                label="Search"
                name="search"
                value={filters.search}
                onChange={handleFilterChange}
                placeholder="Search by exam name..."
                leftIcon={
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                }
              />
            </div>
            <div>
              <Select
                label="Status"
                name="status"
                value={filters.status}
                onChange={handleFilterChange}
                options={[
                  { value: "", label: "All Statuses" },
                  ...Object.keys(STATUS_STYLES).map((s) => ({ value: s, label: s.charAt(0).toUpperCase() + s.slice(1) })),
                ]}
              />
            </div>
            <div>
              <Input
                label="Academic Year"
                name="academic_year"
                value={filters.academic_year}
                onChange={handleFilterChange}
                placeholder="e.g. 2025-2026"
              />
            </div>
            <div className="flex items-end">
              <button type="submit" className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90">
                Apply Filters
              </button>
            </div>
          </form>
        </div>

        <DataTable
          columns={[
            {
              key: "name",
              label: "Exam",
              render: (exam) => (
                <div>
                  <div className="text-sm">{exam.name}</div>
                  <div className="text-xs text-gray-500">{exam.campus?.name}</div>
                </div>
              ),
            },
            {
              key: "exam_type",
              label: "Type",
              render: (exam) => <span className="text-sm">{exam.exam_type || "—"}</span>,
            },
            {
              key: "academic_year",
              label: "Year / Term",
              render: (exam) => (
                <span className="text-sm">{exam.academic_year} {exam.term && `• ${exam.term}`}</span>
              ),
            },
            {
              key: "dates",
              label: "Dates",
              render: (exam) => (
                <span className="text-sm">
                  {exam.start_date ? formatDate(exam.start_date) : "—"}
                  {exam.end_date ? ` – ${formatDate(exam.end_date)}` : ""}
                </span>
              ),
            },
            {
              key: "classes",
              label: "Classes",
              render: (exam) => (
                <span className="text-sm">
                  {!exam.class_ids || exam.class_ids.length === 0
                    ? "All classes"
                    : `${exam.class_ids.length} class${exam.class_ids.length > 1 ? "es" : ""}`}
                </span>
              ),
            },
            {
              key: "status",
              label: "Status",
              render: (exam) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${STATUS_STYLES[exam.status] || "bg-gray-100 border border-gray-300 text-gray-600"}`}>
                  {exam.status}
                </span>
              ),
            },
          ]}
          data={exams}
          loading={loading}
          emptyMessage="No exams found"
          renderActions={(exam) => (
            <RowActions
              actions={[
                { label: "Enter Marks", variant: "primary", icon: ACTION_ICONS.edit, hidden: !isStaff, onClick: () => navigate(`/exams/${exam.id}/marks-entry`) },
                { label: "View Results", icon: ACTION_ICONS.view, onClick: () => navigate(`/results?exam=${exam.id}`) },
                { label: "Edit Exam", icon: ACTION_ICONS.edit, hidden: !can("exams.update"), onClick: () => openEdit(exam) },
                { label: "Delete Exam", variant: "danger", icon: ACTION_ICONS.delete, hidden: !can("exams.delete"), onClick: () => handleDelete(exam) },
              ]}
            />
          )}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      {/* Create / Edit Modal */}
      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-lg">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Exam" : "New Exam"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <Input label="Exam Name" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Enter exam name" />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Select label="Type" value={form.exam_type} onChange={(e) => setForm((f) => ({ ...f, exam_type: e.target.value }))}
                  options={EXAM_TYPES.map((t) => ({ value: t, label: t }))} />
                <Select label="Term" value={form.term} onChange={(e) => setForm((f) => ({ ...f, term: e.target.value }))}
                  options={TERMS.map((t) => ({ value: t, label: t }))} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Academic Year" required value={form.academic_year} disabled />
                <Select label="Status" value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}
                  options={Object.keys(STATUS_STYLES).map((s) => ({ value: s, label: s.charAt(0).toUpperCase() + s.slice(1) }))} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <DatePicker label="Start Date" value={form.start_date || ""} onChange={(e) => setForm((f) => ({ ...f, start_date: e.target.value }))} />
                <DatePicker label="End Date" value={form.end_date || ""} onChange={(e) => setForm((f) => ({ ...f, end_date: e.target.value }))} align="right" />
              </div>

              {campuses.length > 1 && (
                <Select label="Campus" required value={form.campus_id} onChange={(e) => setForm((f) => ({ ...f, campus_id: e.target.value }))}
                  options={[{ value: "", label: "Select campus…" }, ...campuses.map((c) => ({ value: c.id, label: c.name }))]} />
              )}

              <Select
                label="Applicable Classes"
                multiple
                value={form.class_ids}
                onChange={(e) => setForm((f) => ({ ...f, class_ids: e.target.value }))}
                placeholder="All classes"
                helperText="Leave empty to apply this exam to every class."
                options={classes.map((c) => ({ value: c.id, label: c.name }))}
              />

              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update Exam" : "Create Exam"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        variant="danger"
        onConfirm={confirmDelete}
        onClose={() => setConfirmModal({ isOpen: false })}
      />
    </MainLayout>
  );
}
