import { useState, useEffect, useRef } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { examService, classService, studentService } from "../../services/api";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { useCampus } from "../../contexts/CampusContext";
import { exportResultsPDF, exportResultsExcel } from "../../utils/examExport";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { Select, Button } from "../../components/ui";

const gradeColor = (grade) => ({
  A: "text-green-600", B: "text-blue-600", C: "text-yellow-600", D: "text-orange-600", F: "text-red-600",
}[grade] || "text-gray-300");

export default function ResultsHome() {
  const { user, can } = useAuth();
  const navigate = useNavigate();
  const { showError } = useToast();
  const [searchParams] = useSearchParams();

  const isStaff = can("exams.marks");
  const isParent = user?.role === "parent";
  const isStudent = user?.role === "student";

  const [exams, setExams] = useState([]);
  const [selectedExam, setSelectedExam] = usePersistedState("selectedExam", searchParams.get("exam") || "");

  // Staff view
  const [classes, setClasses] = useState([]);
  const [sections, setSections] = useState([]);
  const [selectedClass, setSelectedClass] = usePersistedState("selectedClass", "");
  const [selectedSection, setSelectedSection] = usePersistedState("selectedSection", "");
  const [results, setResults] = usePersistedState("results", null);
  const [loadingResults, setLoadingResults] = useState(false);

  // Parent view
  const [children, setChildren] = useState([]);
  const [selectedChild, setSelectedChild] = useState("");

  // Student view
  const [myExams, setMyExams] = useState(null);
  const [myStudentId, setMyStudentId] = useState(null);

  const { currentAcademicYear } = useAcademicYear();
  const { currentCampus } = useCampus();

  // Exams and classes are both year-scoped. Without this the page offered
  // every exam ever held, so selecting 2027 could still open 2026 results.
  useEffect(() => {
    setSelectedExam("");
    setSelectedClass("");

    examService.getAll({ limit: 100, sortBy: "start_date", sortOrder: "DESC", academic_year: currentAcademicYear }).then((res) => {
      if (res.success) setExams(res.data);
    });
    if (isStaff) {
      classService.getAll({ limit: 200, status: "active", academic_year: currentAcademicYear }).then((res) => { if (res.success) setClasses(res.data); });
    }
    if (isParent) {
      studentService.getAll({ parent_id: user.id, limit: 50 }).then((res) => {
        if (res.success) {
          setChildren(res.data);
          if (res.data.length === 1) setSelectedChild(res.data[0].id);
        }
      });
    }
    if (isStudent) {
      examService.getMyExams().then((res) => {
        if (res.success) { setMyExams(res.data.exams); setMyStudentId(res.data.student_id); }
      }).catch((err) => showError(err.response?.data?.message || err.message));
    }
  }, [currentAcademicYear]);

  // Sections for the selected class — re-derives once `classes` finishes
  // loading. Only resets the chosen section when the class actually
  // changes (not when `classes` merely finishes loading), so a persisted
  // section selection survives navigating back to this page.
  const prevClassRef = useRef(selectedClass);
  useEffect(() => {
    const cls = classes.find((c) => c.id === selectedClass);
    setSections(cls?.sections || []);
    if (prevClassRef.current !== selectedClass) setSelectedSection("");
    prevClassRef.current = selectedClass;
  }, [selectedClass, classes]);

  // If the selected exam is limited to specific classes, only offer those.
  const selectedExamObj = exams.find((ex) => ex.id === selectedExam);
  const availableClasses = selectedExamObj?.class_ids?.length
    ? classes.filter((c) => selectedExamObj.class_ids.includes(c.id))
    : classes;

  const loadResults = async () => {
    if (!selectedExam || !selectedClass) { showError("Pick an exam and a class first"); return; }
    try {
      setLoadingResults(true);
      const res = await examService.getClassResults(selectedExam, { class_id: selectedClass, section_id: selectedSection || undefined });
      if (res.success) setResults(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoadingResults(false); }
  };

  const [exporting, setExporting] = useState("");
  const currentClassLabel = () => {
    const cls = classes.find((c) => c.id === selectedClass);
    const sec = sections.find((s) => s.id === selectedSection);
    return `${cls?.name || ""}${sec ? ` ${sec.name}` : ""}`.trim();
  };

  const handleExportPDF = async () => {
    if (!results) return;
    try {
      setExporting("pdf");
      await exportResultsPDF({
        school: currentCampus,
        title: `${results.exam?.name || "Exam Results"} — ${currentClassLabel()}`,
        subtitle: `${results.exam?.academic_year || ""} ${results.exam?.term ? `• ${results.exam.term}` : ""}`,
        subjects: results.subjects, students: results.students,
        filename: `${(results.exam?.name || "results").replace(/\s+/g, "_")}_${currentClassLabel().replace(/\s+/g, "_")}`,
      });
    } catch { showError("Failed to export PDF"); }
    finally { setExporting(""); }
  };

  const handleExportExcel = async () => {
    if (!results) return;
    try {
      setExporting("excel");
      await exportResultsExcel({
        title: `${results.exam?.name || "Exam Results"} — ${currentClassLabel()}`,
        subjects: results.subjects, students: results.students,
        filename: `${(results.exam?.name || "results").replace(/\s+/g, "_")}_${currentClassLabel().replace(/\s+/g, "_")}`,
      });
    } catch { showError("Failed to export Excel"); }
    finally { setExporting(""); }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Results</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {isStaff ? "View class results and individual report cards" : "View your exam results"}
            </p>
          </div>
          {isStaff && (
            <Button variant="primary" onClick={() => navigate("/results/term-summary")}>Term Summary</Button>
          )}
        </div>

        {/* ── Staff: class results matrix ── */}
        {isStaff && (
          <>
            <div className="bg-white p-5 rounded shadow">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 items-end">
                <Select label="Exam" required value={selectedExam} onChange={(e) => { setSelectedExam(e.target.value); setSelectedClass(""); }}
                  options={[{ value: "", label: "Select…" }, ...exams.map((ex) => ({ value: ex.id, label: ex.name }))]} />
                <Select label="Class" required value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)}
                  options={[{ value: "", label: "Select…" }, ...availableClasses.map((c) => ({ value: c.id, label: c.name }))]} />
                <Select label="Section" value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} disabled={!selectedClass}
                  options={[{ value: "", label: "All sections" }, ...sections.map((s) => ({ value: s.id, label: s.name }))]} />
                <button
                  onClick={loadResults}
                  disabled={loadingResults}
                  className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90 disabled:opacity-50"
                >
                  {loadingResults ? "Loading…" : "View Results"}
                </button>
              </div>
            </div>

            {results && (
              results.students.length === 0 ? (
                <div className="bg-white p-10 rounded shadow text-center">
                  <svg className="w-12 h-12 text-gray-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 17v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6m0 0h14m-14 0a2 2 0 002 2h10a2 2 0 002-2m0 0V9a2 2 0 00-2-2h-2a2 2 0 00-2 2v8" />
                  </svg>
                  <p className="text-gray-500 text-sm">No students in this class/section.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="bg-white px-5 py-3 rounded shadow flex items-center justify-between flex-wrap gap-2">
                    <p className="text-sm text-gray-500">{results.students.length} student(s) — {results.subjects.length} subject(s)</p>
                    <div className="flex gap-2">
                      <Button variant="secondary" size="sm" mobileLabel="Export PDF" onClick={handleExportPDF} disabled={!!exporting}>{exporting === "pdf" ? "Exporting…" : "Export PDF"}</Button>
                      <Button variant="secondary" size="sm" mobileLabel="Export Excel" onClick={handleExportExcel} disabled={!!exporting}>{exporting === "excel" ? "Exporting…" : "Export Excel"}</Button>
                    </div>
                  </div>
                  <div className="bg-white rounded shadow overflow-x-auto lg:overflow-visible">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Adm No.</th>
                          <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student</th>
                          {results.subjects.map((s) => (
                            <th key={s.id} className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">{s.code || s.name}</th>
                          ))}
                          <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                          <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Avg %</th>
                          <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Grade</th>
                          <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Rank</th>
                          <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {results.students.map((r) => (
                          <tr key={r.student_id} className="hover:bg-gray-50 transition-colors">
                            <td className="px-5 py-2 text-sm text-left text-gray-500">{r.admission_number}</td>
                            <td className="px-5 py-2 text-sm text-left font-medium text-gray-900">{r.name}</td>
                            {r.subjects.map((sg) => (
                              <td key={sg.subject_id} className="px-4 py-2 text-center text-sm text-gray-700">
                                {sg.marks_obtained !== null ? sg.marks_obtained : <span className="text-gray-300">—</span>}
                              </td>
                            ))}
                            <td className="px-5 py-2 text-center text-sm font-semibold text-gray-900">
                              {r.total_obtained !== null ? r.total_obtained : <span className="text-gray-300">—</span>}
                            </td>
                            <td className="px-5 py-2 text-center text-sm text-gray-700">{r.average !== null ? `${r.average}%` : <span className="text-gray-300">—</span>}</td>
                            <td className={`px-5 py-2 text-center text-sm font-bold ${gradeColor(r.overall_grade)}`}>{r.overall_grade || "—"}</td>
                            <td className="px-5 py-2 text-center text-sm text-gray-700">{r.position || "—"}</td>
                            <td className="px-5 py-2 text-center whitespace-nowrap text-sm font-medium">
                              <button onClick={() => navigate(`/results/${selectedExam}/report-card/${r.student_id}`)} className="text-primary hover:underline">
                                Report Card
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )
            )}
          </>
        )}

        {/* ── Parent: pick child + exam ── */}
        {isParent && (
          <div className="bg-white p-5 rounded shadow">
            {children.length === 0 ? (
              <p className="text-sm text-gray-500">No children linked to your account yet.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <Select label="Child" value={selectedChild} onChange={(e) => setSelectedChild(e.target.value)}
                  options={[{ value: "", label: "Select…" }, ...children.map((c) => ({ value: c.id, label: `${c.user?.first_name || ""} ${c.user?.last_name || ""}`.trim() }))]} />
                <Select label="Exam" value={selectedExam} onChange={(e) => setSelectedExam(e.target.value)}
                  options={[{ value: "", label: "Select…" }, ...exams.map((ex) => ({ value: ex.id, label: ex.name }))]} />
                <button
                  disabled={!selectedChild || !selectedExam}
                  onClick={() => navigate(`/results/${selectedExam}/report-card/${selectedChild}`)}
                  className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90 disabled:opacity-50"
                >
                  View Report Card
                </button>
              </div>
            )}
          </div>
        )}

        {/* ── Student: pick an exam they have grades for ── */}
        {isStudent && (
          <div className="bg-white rounded shadow divide-y divide-gray-100">
            {myExams === null ? (
              <div className="p-10 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
            ) : myExams.length === 0 ? (
              <p className="p-5 text-sm text-gray-500">No results published yet.</p>
            ) : (
              myExams.map((ex) => (
                <button
                  key={ex.id}
                  onClick={() => navigate(`/results/${ex.id}/report-card/${myStudentId}`)}
                  className="w-full flex flex-wrap items-center justify-between gap-2 px-5 py-4 text-left hover:bg-gray-50 transition-colors"
                >
                  <div>
                    <p className="text-sm font-medium text-gray-900">{ex.name}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{ex.academic_year} {ex.term && `• ${ex.term}`}</p>
                  </div>
                  <span className="text-primary text-sm font-medium">View →</span>
                </button>
              ))
            )}
          </div>
        )}
      </div>
    </MainLayout>
  );
}