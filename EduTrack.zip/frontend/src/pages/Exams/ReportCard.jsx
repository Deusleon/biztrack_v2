import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { examService } from "../../services/api";
import { exportReportCardPDF } from "../../utils/examExport";
import { useCampus } from "../../contexts/CampusContext";
import MainLayout from "../../components/MainLayout";
import { Button } from "../../components/ui";

const GRADE_STYLES = {
  A: { text: "text-green-700", bg: "bg-green-50", border: "border-green-200", remark: "Excellent" },
  B: { text: "text-blue-700", bg: "bg-blue-50", border: "border-blue-200", remark: "Good" },
  C: { text: "text-yellow-700", bg: "bg-yellow-50", border: "border-yellow-200", remark: "Satisfactory" },
  D: { text: "text-orange-700", bg: "bg-orange-50", border: "border-orange-200", remark: "Needs Improvement" },
  F: { text: "text-red-700", bg: "bg-red-50", border: "border-red-200", remark: "Fail" },
};
const gradeInfo = (g) => GRADE_STYLES[g] || { text: "text-gray-400", bg: "bg-gray-50", border: "border-gray-200", remark: "—" };

// Test / Exam / Average are percentages; show a dash when there is nothing to show.
const fmtPct = (v) => (v === null || v === undefined ? "—" : `${v}%`);

const ordinal = (n) => {
  if (!n) return "—";
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
};

export default function ReportCard() {
  const { id: examId, studentId } = useParams();
  const navigate = useNavigate();
  const { showError } = useToast();
  const { currentCampus } = useCampus();

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    examService.getReportCard(examId, studentId)
      .then((res) => { if (res.success) setData(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, [examId, studentId]);

  if (loading) {
    return (
      <MainLayout>
        <div className="bg-white p-16 rounded shadow text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!data) {
    return (
      <MainLayout>
        <div className="bg-white p-16 rounded shadow text-center text-gray-400">
          <p>Report card not available.</p>
          <button onClick={() => navigate(-1)} className="text-primary hover:underline text-sm mt-2">← Back</button>
        </div>
      </MainLayout>
    );
  }

  const { exam, student, subjects, basis, total_obtained, average, overall_grade, position, class_size } = data;
  const overall = gradeInfo(overall_grade);
  const today = new Date().toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" });

  const handleDownloadPDF = async () => {
    try {
      setDownloading(true);
      await exportReportCardPDF({
        school: currentCampus, exam, student, subjects, basis,
        total_obtained, average, overall_grade, position, class_size,
        filename: `Report_Card_${student?.name?.replace(/\s+/g, "_") || "student"}_${exam?.name?.replace(/\s+/g, "_") || "exam"}`,
      });
    } catch {
      showError("Failed to generate PDF");
    } finally {
      setDownloading(false);
    }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Screen-only toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-2 print:hidden">
          <div className="flex gap-2">
            <Button variant="secondary" mobileLabel="Download PDF" onClick={handleDownloadPDF} disabled={downloading}>{downloading ? "Generating…" : "Download PDF"}</Button>
            <Button variant="primary" onClick={() => window.print()}>Print Report Card</Button>
          </div>
          <Button
            onClick={() => navigate(-1)}
            variant="lightPrimary"
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to Results
          </Button>
        </div>

        {/* ── Two-column layout: a fuller summary panel on the left, the
             report document on the right — sized so neither side crowds
             the other or leaves a big empty gap between them. ── */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 items-start">
          {/* Left: summary panel — hidden when printing, since only the
              report document itself should print. */}
          <div className="lg:col-span-2 print:hidden bg-white rounded shadow p-5 lg:sticky lg:top-4 space-y-5">
            <div>
              <h3 className="text-sm text-left font-semibold text-gray-900">About this report</h3>
              <p className="text-sm text-left text-gray-500 mt-2 leading-relaxed">
                This is {student?.name || "the student"}'s official academic report for{" "}
                <span className="font-medium text-gray-700">{exam?.name}</span>, covering each
                subject's test average, final exam score and overall average, the overall grade, and class position for the term.
              </p>
            </div>

            <div className="border-t text-left border-gray-100 pt-4 grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-3">
              <div>
                <p className="text-xs text-gray-400">Student</p>
                <p className="text-sm font-medium text-gray-800">{student?.name || "—"}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Admission No.</p>
                <p className="text-sm font-medium text-gray-800">{student?.admission_number || "—"}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Class</p>
                <p className="text-sm font-medium text-gray-800">
                  {student?.class || "—"}{student?.section ? ` — ${student.section}` : ""}
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Academic Year</p>
                <p className="text-sm font-medium text-gray-800">{exam?.academic_year || "—"}</p>
              </div>
              {exam?.term && (
                <div>
                  <p className="text-xs text-gray-400">Term</p>
                  <p className="text-sm font-medium text-gray-800">{exam.term}</p>
                </div>
              )}
              {exam?.exam_type && (
                <div>
                  <p className="text-xs text-gray-400">Exam Type</p>
                  <p className="text-sm font-medium text-gray-800 capitalize">{exam.exam_type}</p>
                </div>
              )}
            </div>

            {subjects.length > 0 && (
              <div className="border-t border-gray-100 pt-4 space-y-2.5">
                <div className="flex items-center gap-4">
                  <span className="w-1/2 text-sm text-left text-gray-500">Subjects</span>
                  <span className="w-1/2 text-sm text-left font-semibold text-gray-900">{subjects.length}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="w-1/2 text-sm text-left text-gray-500">Average</span>
                  <span className="w-1/2 text-sm text-left font-semibold text-gray-900">{average !== null ? `${average}%` : "—"}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="w-1/2 text-sm text-left text-gray-500">Overall Grade</span>
                  <span className={`w-1/2 text-sm text-left font-bold ${overall.text}`}>{overall_grade || "—"}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="w-1/2 text-sm text-left text-gray-500">Class Position</span>
                  <span className="w-1/2 text-sm text-left font-semibold text-gray-900">
                    {position ? `${ordinal(position)}${class_size ? ` of ${class_size}` : ""}` : "—"}
                  </span>
                </div>
              </div>
            )}

            <div className="border-t border-gray-100 pt-4">
              <p className="text-xs text-left text-gray-400 leading-relaxed">
                Use <span className="font-medium text-gray-500">Print Report Card</span> for a physical copy, or{" "}
                <span className="font-medium text-gray-500">Download PDF</span> to save/share it digitally.
                Generated on {today}.
              </p>
            </div>
          </div>

          {/* Right: the report document itself */}
          <div className="lg:col-span-3 bg-white shadow print:shadow-none rounded-sm border-2 border-gray-300 print:border-gray-500 mx-auto w-full max-w-5xl print:max-w-none print:!mt-0">
          {/* Letterhead */}
          <div className="px-8 pt-8 pb-5 text-center border-b-4 border-double border-gray-800">
            {/* School logo, uploaded per campus in Settings → School.
                Omitted entirely when unset so the letterhead falls back to
                the text-only version rather than a broken image. */}
            {currentCampus?.logo_url && (
              <img
                src={currentCampus.logo_url}
                alt={`${currentCampus?.name || "School"} logo`}
                className="h-20 w-auto max-w-[160px] object-contain mx-auto mb-3"
              />
            )}
            <h1 className="text-2xl font-extrabold uppercase tracking-wide text-gray-900">
              {currentCampus?.name || "School Name"}
            </h1>
            <p className="text-xs text-gray-500 mt-1">
              {[currentCampus?.address, currentCampus?.city, currentCampus?.country].filter(Boolean).join(", ") || "School Address"}
            </p>
            <p className="text-xs text-gray-500">
              {[currentCampus?.phone, currentCampus?.email].filter(Boolean).join("   •   ")}
            </p>
            <div className="mt-4 inline-block bg-gray-900 text-white text-sm font-bold uppercase tracking-widest px-5 py-1.5 rounded-sm">
              Student Academic Report
            </div>
          </div>

          {/* Exam banner */}
          <div className="px-8 py-3 bg-gray-50 border-b border-gray-300 flex flex-wrap items-center justify-between gap-2">
            <p className="text-sm font-semibold text-gray-800">{exam?.name}</p>
            <p className="text-xs text-gray-600">
              {exam?.academic_year} {exam?.term && `• ${exam.term}`} {exam?.exam_type && `• ${exam.exam_type}`}
            </p>
          </div>

          {/* Student info */}
          <div className="px-8 py-5 border-b border-gray-300">
            <table className="w-full text-sm">
              <tbody>
                <tr>
                  <td className="py-1.5 text-left text-gray-500 w-24 align-top">Student Name:</td>
                  <td className="py-1.5 pr-8 font-semibold text-gray-900 border-b border-gray-300">{student?.name}</td>
                  <td className="py-1.5 text-left text-gray-500 w-16 align-top">Gender:</td>
                  <td className="py-1.5 font-semibold text-gray-900 border-b border-gray-300 capitalize">{student?.gender || "—"}</td>
                </tr>
                <tr>
                  <td className="py-1.5 text-left text-gray-500 w-24 align-top">Admission No:</td>
                  <td className="py-1.5 font-semibold text-gray-900 border-b border-gray-300">{student?.admission_number}</td>
                  <td className="py-1.5 text-left text-gray-500 align-top">Class:</td>
                  <td className="py-1.5 pr-8 font-semibold text-gray-900 border-b border-gray-300">
                    {student?.class}{student?.section ? ` — ${student.section}` : ""}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Subjects table */}
          <div className="px-8 pt-6">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-gray-900 text-white">
                  <th className="px-3 py-2 text-left font-semibold text-xs uppercase tracking-wide w-10">#</th>
                  <th className="px-3 py-2 text-left font-semibold text-xs uppercase tracking-wide">Subject</th>
                  <th className="px-3 py-2 text-center font-semibold text-xs uppercase tracking-wide">Test</th>
                  <th className="px-3 py-2 text-center font-semibold text-xs uppercase tracking-wide">Exam</th>
                  <th className="px-3 py-2 text-center font-semibold text-xs uppercase tracking-wide">Average</th>
                  <th className="px-3 py-2 text-center font-semibold text-xs uppercase tracking-wide">Grade</th>
                  <th className="px-3 py-2 text-center font-semibold text-xs uppercase tracking-wide">Remark</th>
                </tr>
              </thead>
              <tbody>
                {subjects.length === 0 ? (
                  <tr><td colSpan={7} className="px-3 py-8 text-center text-gray-400 border border-gray-300">No marks recorded yet.</td></tr>
                ) : subjects.map((s, i) => {
                  const g = gradeInfo(s.grade);
                  return (
                    <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                      <td className="px-3 py-2 border border-gray-300 text-gray-500">{i + 1}</td>
                      <td className="px-3 py-2 text-left border border-gray-300 font-medium text-gray-900">{s.subject}</td>
                      <td className="px-3 py-2 border border-gray-300 text-center">{fmtPct(s.test_average)}</td>
                      <td className="px-3 py-2 border border-gray-300 text-center">
                        {fmtPct(s.exam_percentage)}
                        {s.exam_max && s.exam_max !== 100 && (
                          <span className="block text-[10px] text-gray-400 leading-tight">{s.exam_score}/{s.exam_max}</span>
                        )}
                      </td>
                      <td className="px-3 py-2 border border-gray-300 text-center font-semibold text-gray-900">{fmtPct(s.average)}</td>
                      <td className={`px-3 py-2 border border-gray-300 text-center font-bold ${g.text}`}>{s.grade || "—"}</td>
                      <td className={`px-3 py-2 border border-gray-300 text-center text-xs font-medium ${g.text}`}>{s.grade ? g.remark : "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {subjects.length > 0 && (
              <p className="text-[11px] text-left text-gray-500 mt-2 leading-relaxed">
                <span className="font-semibold text-gray-600">Test</span> = average of{" "}
                {basis?.tests?.length ? `${basis.tests.length} test${basis.tests.length === 1 ? "" : "s"} (${basis.tests.map((t) => t.name).join(", ")})` : "the term's tests (none recorded)"}.{" "}
                <span className="font-semibold text-gray-600">Exam</span> = {basis?.final ? basis.final.name : "final exam (not recorded yet)"}.{" "}
                <span className="font-semibold text-gray-600">Average</span> = average of Test and Exam. All figures are percentages.
              </p>
            )}
          </div>

          {/* Summary */}
          {subjects.length > 0 && (
            <div className="px-8 pt-6">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="border border-gray-300 rounded-sm p-3 text-center">
                  <p className="text-xl font-extrabold text-gray-900">{total_obtained !== null ? total_obtained : "—"}</p>
                  <p className="text-xs text-gray-500 uppercase tracking-wide mt-0.5">Total Score</p>
                </div>
                <div className="border border-gray-300 rounded-sm p-3 text-center">
                  <p className="text-xl font-extrabold text-gray-900">{average !== null ? `${average}%` : "—"}</p>
                  <p className="text-xs text-gray-500 uppercase tracking-wide mt-0.5">Average</p>
                </div>
                <div className={`border rounded-sm p-3 text-center ${overall.border} ${overall.bg}`}>
                  <p className={`text-xl font-extrabold ${overall.text}`}>{overall_grade || "—"}</p>
                  <p className="text-xs text-gray-500 uppercase tracking-wide mt-0.5">Overall Grade</p>
                </div>
                <div className="border border-gray-300 rounded-sm p-3 text-center">
                  <p className="text-xl font-extrabold text-gray-900">{position ? ordinal(position) : "—"}</p>
                  <p className="text-xs text-gray-500 uppercase tracking-wide mt-0.5">
                    Class Position {class_size ? `(of ${class_size})` : ""}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Grading key */}
          <div className="px-8 pt-6">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Grading Key</p>
            <div className="flex flex-wrap gap-2">
              {Object.entries(GRADE_STYLES).map(([letter, g]) => (
                <span key={letter} className={`text-xs px-2.5 py-1 rounded-sm border ${g.border} ${g.bg} ${g.text} font-medium`}>
                  {letter} — {g.remark}
                </span>
              ))}
            </div>
          </div>

          {/* Remarks */}
          <div className="px-8 pt-6 grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Class Teacher's Remarks</p>
              <div className="h-14 border-b border-dotted border-gray-400" />
            </div>
            <div>
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Head Teacher's Remarks</p>
              <div className="h-14 border-b border-dotted border-gray-400" />
            </div>
          </div>

          {/* Signatures */}
          <div className="px-8 pt-10 pb-8 grid grid-cols-1 sm:grid-cols-3 gap-8">
            {["Class Teacher", "Head Teacher / Principal", "Parent / Guardian"].map((role) => (
              <div key={role} className="text-center">
                <div className="border-b border-gray-500 h-10" />
                <p className="text-xs text-gray-500 mt-1.5">{role}</p>
                <p className="text-xs text-gray-400">Date: ______________</p>
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="px-8 py-3 border-t border-gray-300 text-center">
            <p className="text-xs text-gray-400">Generated by EduTrack on {today}</p>
          </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
