import { useState } from "react";
import { useCampus } from "../../contexts/CampusContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import MainLayout from "../../components/MainLayout";
import { Input, DatePicker, Button } from "../../components/ui";

const TEMPLATES = [
  { id: "classic", name: "Classic Gold", description: "Warm ivory background, ornate gold double-border, medal seal" },
  { id: "modern", name: "Modern Geometric", description: "Bold diagonal color blocks in your school colors, gold seal" },
  { id: "formal", name: "Formal Navy & Gold", description: "Navy & gold banner, medal seal, serif type" },
  { id: "elegant", name: "Elegant Black", description: "Black corner frame, letterpress feel, understated" },
];

export default function Certificates() {
  const { currentCampus } = useCampus();
  const { formatDate } = usePreferences();
  const [template, setTemplate] = useState("classic");
  const [form, setForm] = useState({
    title: "Certificate of Achievement",
    recipient_name: "",
    body: "in recognition of outstanding achievement and dedication",
    date: new Date().toISOString().slice(0, 10),
    signatory1_name: "",
    signatory1_title: "Principal",
    signatory2_name: "",
    signatory2_title: "Class Teacher",
  });

  const update = (field, value) => setForm((f) => ({ ...f, [field]: value }));

  return (
    <MainLayout>
      <div className="space-y-4">
        <style>{`@media print { @page { size: A4 landscape; margin: 0; } }`}</style>

        <div className="print:hidden text-left">
          <h1 className="text-xl font-bold text-gray-900">Certificate Generator</h1>
          <p className="text-sm text-gray-500 mt-0.5">Fill in the details, pick a design, and print</p>
        </div>

        <div className="bg-white p-5 rounded shadow print:hidden space-y-4">
          <div>
            <label className="text-sm text-left font-medium text-gray-700 block mb-2">Design</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {TEMPLATES.map((t) => (
                <button key={t.id} onClick={() => setTemplate(t.id)}
                  className={`text-left p-3 rounded border-2 transition-colors ${template === t.id ? "border-primary bg-primary-10" : "border-gray-200 hover:border-gray-300"}`}>
                  <p className="text-sm font-medium text-gray-900">{t.name}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{t.description}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label="Certificate Title" value={form.title} onChange={(e) => update("title", e.target.value)} placeholder="e.g. Certificate of Achievement" />
            <Input label="Recipient Name" value={form.recipient_name} onChange={(e) => update("recipient_name", e.target.value)} placeholder="Full name" />
          </div>
          <Input label="Body Text" value={form.body} onChange={(e) => update("body", e.target.value)} placeholder="e.g. for outstanding performance in Mathematics" />
          <DatePicker label="Date" value={form.date} onChange={(e) => update("date", e.target.value)} />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input label="Signatory 1 Name" value={form.signatory1_name} onChange={(e) => update("signatory1_name", e.target.value)} />
            <Input label="Signatory 1 Title" value={form.signatory1_title} onChange={(e) => update("signatory1_title", e.target.value)} />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input label="Signatory 2 Name" value={form.signatory2_name} onChange={(e) => update("signatory2_name", e.target.value)} />
            <Input label="Signatory 2 Title" value={form.signatory2_title} onChange={(e) => update("signatory2_title", e.target.value)} />
          </div>

          <Button variant="primary" onClick={() => window.print()} disabled={!form.recipient_name}>Print Certificate</Button>
        </div>

        <div className="flex justify-center">
          <CertificatePreview template={template} form={form} school={currentCampus} formatDate={formatDate} />
        </div>
      </div>
    </MainLayout>
  );
}

function CertificatePreview({ template, form, school, formatDate }) {
  const schoolName = school?.name || "School Name";
  const recipient = form.recipient_name || "Recipient Name";
  // A stable-looking reference number derived from the form content —
  // not stored anywhere, just makes the printed certificate look like
  // it has real provenance instead of an obviously-generated document.
  const certNumber = `CERT-${(form.date || "").replace(/-/g, "")}-${String((recipient.length * 37 + form.title.length * 11) % 9000 + 1000)}`;

  const Signature = ({ name, title, color = "#374151" }) => (
    <div className="text-center flex-1">
      <div className="pt-1 mx-6" style={{ borderTop: `1px solid ${color}` }}>
        <p className="text-xs font-semibold" style={{ color }}>{name || "\u00A0"}</p>
        <p className="text-[10px] text-gray-500">{title}</p>
      </div>
    </div>
  );

  // A gold-medal-style seal — ribbon + star, drawn in SVG so it scales
  // and prints crisply instead of being a raster image.
  const Seal = ({ size = 90, ring = "#c9a339", fill = "#d4af37", ribbon = "#1e3a5f" }) => (
    <svg width={size} height={size * 1.35} viewBox="0 0 100 135" className="drop-shadow-md">
      <path d="M30 70 L15 130 L50 110 L85 130 L70 70 Z" fill={ribbon} />
      <circle cx="50" cy="45" r="42" fill={fill} stroke={ring} strokeWidth="3" />
      <circle cx="50" cy="45" r="32" fill="none" stroke="#fff" strokeWidth="1.5" opacity="0.6" />
      <path d="M50 26 L54.5 38 L67 38 L57 46 L61 58 L50 50 L39 58 L43 46 L33 38 L45.5 38 Z" fill="#fff" opacity="0.95" />
    </svg>
  );

  if (template === "modern") {
    return (
      <div className="w-[842px] h-[595px] bg-white shadow-lg print:shadow-none relative overflow-hidden flex flex-col">
        {/* Bold geometric triangle accents, top-left and bottom-right */}
        <div className="absolute -top-24 -left-24 w-80 h-80 opacity-95" style={{ background: "linear-gradient(135deg, var(--color-primary), var(--color-primary-dark))", clipPath: "polygon(0 0, 100% 0, 0 100%)" }} />
        <div className="absolute top-0 left-0 w-56 h-56 opacity-40" style={{ background: "linear-gradient(135deg, var(--color-primary-dark), transparent)", clipPath: "polygon(0 0, 70% 0, 0 70%)" }} />
        <div className="absolute -bottom-24 -right-24 w-80 h-80 opacity-95" style={{ background: "linear-gradient(315deg, var(--color-primary), var(--color-primary-dark))", clipPath: "polygon(100% 100%, 0 100%, 100% 0)" }} />
        <div className="absolute top-8 right-8">
          <Seal size={64} />
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-20 text-center relative z-10">
          <p className="text-xs tracking-[0.35em] text-gray-400 uppercase">{schoolName}</p>
          <h1 className="text-4xl font-bold text-gray-900 mt-5" style={{ fontFamily: "'Playfair Display', serif" }}>{form.title}</h1>
          <div className="w-24 h-1 my-5" style={{ backgroundColor: "var(--color-primary)" }} />
          <p className="text-sm text-gray-500">This certificate is proudly presented to</p>
          <p className="text-5xl mt-3 mb-4" style={{ fontFamily: "'Great Vibes', cursive", color: "var(--color-primary-dark)" }}>{recipient}</p>
          <p className="text-sm text-gray-600 max-w-lg">{form.body}</p>
          <p className="text-xs text-gray-400 mt-6">{formatDate(form.date)}</p>
        </div>
        <div className="flex justify-around px-28 pb-10 relative z-10">
          <Signature name={form.signatory1_name} title={form.signatory1_title} />
          <Signature name={form.signatory2_name} title={form.signatory2_title} />
        </div>
        <p className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[8px] text-gray-300 tracking-wider">{certNumber}</p>
      </div>
    );
  }

  if (template === "formal") {
    return (
      <div className="w-[842px] h-[595px] bg-white shadow-lg print:shadow-none relative overflow-hidden flex flex-col">
        <div className="h-6" style={{ background: "linear-gradient(to right, #0f2444, #1e3a5f, #b8860b)" }} />
        <div className="absolute inset-3 border border-[#c9a339] pointer-events-none" />
        <div className="absolute inset-[18px] border border-[#c9a339] opacity-40 pointer-events-none" />
        <div className="flex-1 flex flex-col items-center justify-center px-20 text-center">
          <Seal size={80} ribbon="#0f2444" />
          <p className="text-sm font-semibold text-[#1e3a5f] uppercase tracking-[0.25em] mt-3">{schoolName}</p>
          <h1 className="text-3xl font-bold text-[#1e3a5f] mt-4" style={{ fontFamily: "'Playfair Display', serif" }}>{form.title}</h1>
          <p className="text-sm text-gray-500 mt-5">This is to certify that</p>
          <p className="text-5xl my-3 pb-2 px-10" style={{ fontFamily: "'Great Vibes', cursive", color: "#1e3a5f", borderBottom: "2px solid #b8860b" }}>{recipient}</p>
          <p className="text-sm text-gray-600 max-w-lg mt-2">{form.body}</p>
          <p className="text-xs text-gray-400 mt-4">Awarded on {formatDate(form.date)}</p>
        </div>
        <div className="flex justify-around px-28 pb-8">
          <Signature name={form.signatory1_name} title={form.signatory1_title} color="#1e3a5f" />
          <Signature name={form.signatory2_name} title={form.signatory2_title} color="#1e3a5f" />
        </div>
        <p className="text-center text-[8px] text-gray-300 tracking-wider pb-1">{certNumber}</p>
        <div className="h-4" style={{ background: "linear-gradient(to right, #b8860b, #1e3a5f, #0f2444)" }} />
      </div>
    );
  }

  if (template === "elegant") {
    return (
      <div className="w-[842px] h-[595px] bg-white shadow-lg print:shadow-none relative overflow-hidden flex flex-col border border-black">
        <div className="m-5 border border-black flex-1 flex flex-col items-center justify-center px-20 text-center relative">
          <div className="absolute top-4 left-4 w-10 h-10 border-t border-l border-black" />
          <div className="absolute top-4 right-4 w-10 h-10 border-t border-r border-black" />
          <div className="absolute bottom-4 left-4 w-10 h-10 border-b border-l border-black" />
          <div className="absolute bottom-4 right-4 w-10 h-10 border-b border-r border-black" />

          <p className="text-xs tracking-[0.45em] text-gray-500 uppercase">{schoolName}</p>
          <h1 className="text-4xl font-light tracking-wide text-black mt-8" style={{ fontFamily: "'Playfair Display', serif" }}>{form.title}</h1>
          <p className="text-sm text-gray-500 mt-8 italic">presented to</p>
          <p className="text-5xl text-black my-4" style={{ fontFamily: "'Great Vibes', cursive" }}>{recipient}</p>
          <p className="text-sm text-gray-600 max-w-lg italic">{form.body}</p>
          <p className="text-xs text-gray-400 mt-8">{formatDate(form.date)}</p>
          <div className="flex justify-around w-full px-16 mt-10">
            <Signature name={form.signatory1_name} title={form.signatory1_title} />
            <Signature name={form.signatory2_name} title={form.signatory2_title} />
          </div>
          <p className="absolute bottom-2 text-[8px] text-gray-300 tracking-wider">{certNumber}</p>
        </div>
      </div>
    );
  }

  // classic — red/gold ornate, matching a traditional graduation certificate look
  return (
    <div className="w-[842px] h-[595px] shadow-lg print:shadow-none relative overflow-hidden flex flex-col" style={{ background: "linear-gradient(160deg, #fdf6ea 0%, #fff 60%)" }}>
      <div className="absolute inset-4 border-4 border-double" style={{ borderColor: "#b8860b" }} />
      <div className="absolute inset-8 border" style={{ borderColor: "#d4af3766" }} />
      <div className="absolute top-0 left-0 w-full h-3" style={{ background: "linear-gradient(to right, #7a1f2b, #b8860b)" }} />
      <div className="absolute bottom-0 left-0 w-full h-16 opacity-90" style={{ background: "linear-gradient(to right, #7a1f2b, #9c2a3a)", clipPath: "polygon(0 40%, 100% 0%, 100% 100%, 0% 100%)" }} />

      <div className="flex-1 flex flex-col items-center justify-center px-20 text-center relative z-10">
        <Seal size={84} fill="#d4af37" ring="#8b6914" ribbon="#7a1f2b" />
        <p className="text-xs tracking-[0.3em] uppercase font-semibold mt-3" style={{ color: "#8b6914" }}>{schoolName}</p>
        <h1 className="text-4xl font-bold mt-4" style={{ color: "#7a1f2b", fontFamily: "'Playfair Display', serif" }}>{form.title}</h1>
        <p className="text-sm text-gray-500 mt-5">This certificate is presented to</p>
        <p className="text-5xl text-gray-900 my-3" style={{ fontFamily: "'Great Vibes', cursive" }}>{recipient}</p>
        <p className="text-sm text-gray-600 max-w-lg">{form.body}</p>
        <p className="text-xs text-gray-400 mt-5">Given this {formatDate(form.date)}</p>
      </div>
      <div className="flex justify-around px-28 pb-14 relative z-10">
        <Signature name={form.signatory1_name} title={form.signatory1_title} color="#7a1f2b" />
        <Signature name={form.signatory2_name} title={form.signatory2_title} color="#7a1f2b" />
      </div>
      <p className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[8px] text-gray-400 tracking-wider z-10">{certNumber}</p>
    </div>
  );
}
