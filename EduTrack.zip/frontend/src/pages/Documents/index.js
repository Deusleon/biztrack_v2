export { default as IDCard } from './IDCard';
export { default as Certificates } from './Certificates';
