import { useState, useEffect, useRef } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { useCampus } from "../../contexts/CampusContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { studentService, classService, documentsService } from "../../services/api";
import { useYearAwareClasses } from "../../hooks/useYearAwareClasses";
import MainLayout from "../../components/MainLayout";
import { Select, Button } from "../../components/ui";
import { QRCodeSVG } from "qrcode.react";

// ─────────────────────────────────────────────────────────────────────────
// Card geometry
//
// Both sides are designed on a fixed 440 × 277.5 px canvas (the CR80 / ISO
// ID-1 ratio, 85.6 × 54 mm). On screen they render at that size. For
// printing, the canvas is scaled down to exactly 85.6 × 54 mm with a CSS
// transform (85.6 mm = 323.53 px at 96 dpi → 323.53 / 440 = 0.7353), so the
// printed card is the same design as on screen at true card size instead of
// a 380 px-wide card overflowing a 323 px-wide page.
//
// Side A and Side B print as two consecutive card-sized pages: front, then back.
// ─────────────────────────────────────────────────────────────────────────
const CARD_W = 520;
const CARD_H = 330;
const PRINT_SCALE = 0.5;

const CARD_CSS = `
  .idc-frame { width: ${CARD_W}px; height: ${CARD_H}px; position: relative; flex-shrink: 0; }
  .idc-card { width: ${CARD_W}px; height: ${CARD_H}px; position: relative; overflow: hidden; display: flex; flex-direction: column; text-align: left; background: #fff; border-radius: 14px; border: 1px solid #e5e7eb; box-shadow: 0 10px 25px -5px rgba(0,0,0,.15); }
  @media print {
    @page { size: 85.6mm 54mm; margin: 0; }
    .idc-wrap { display: block !important; margin: 0 !important; }
    .idc-page { display: block !important; break-after: page; page-break-after: always; }
    .idc-page:last-child { break-after: auto; page-break-after: auto; }
    .idc-frame { width: 85.6mm; height: 54mm; overflow: hidden; }
    .idc-card { transform: scale(${PRINT_SCALE}); transform-origin: top left; border-radius: 0; border: none; box-shadow: none; }
  }
`;

const headerBg = { background: "linear-gradient(to right, var(--color-primary), var(--color-primary-dark))" };
const serif = { fontFamily: "'Playfair Display', serif" };
const clamp = (lines) => ({ display: "-webkit-box", WebkitLineClamp: lines, WebkitBoxOrient: "vertical", overflow: "hidden" });

function SchoolMark({ campus, size = 44 }) {
  return (
    <div className="rounded-full bg-white flex items-center justify-center flex-shrink-0 overflow-hidden border-2 border-white/60" style={{ width: size, height: size }}>
      {campus?.logo_url ? (
        <img src={campus.logo_url} alt="" className="w-full h-full object-contain p-0.5" />
      ) : (
        <span className="font-bold text-primary" style={{ fontSize: size * 0.4 }}>{(campus?.name || "S").charAt(0)}</span>
      )}
    </div>
  );
}

// One aligned "LABEL  value" line. Every row on both sides uses the same
// label column width, so values line up in a clean vertical edge.
const LABEL_W = 60;
function Row({ label, value, strong = false, lines = 1, labelW = LABEL_W }) {
  return (
    <div className="grid items-baseline text-left" style={{ gridTemplateColumns: `${labelW}px minmax(0, 1fr)`, columnGap: 8 }}>
      <span className="text-[14px] text-gray-600 tracking-wider leading-tight">{label}</span>
      <span
        className={`${strong ? "text-[14px] font-bold" : "text-[14px] font-semibold"} text-gray-900 leading-snug`}
        style={lines > 1 ? clamp(lines) : { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}
      >
        : {value || "—"}
      </span>
    </div>
  );
}

// Side A — front
function CardFront({ student, campus, formatDate, validity }) {
  const fullName = `${student.user?.first_name || ""} ${student.user?.last_name || ""}`.trim();
  const classLabel = [student.class?.name, student.section?.name].filter(Boolean).join(" ");
  return (
    <div className="idc-card">
      {/* Decorative corner accents */}
      <div className="absolute -top-12 -right-12 w-32 h-32 bg-primary-10 rounded-full" />
      <div className="absolute top-10 -right-5 w-20 h-20 bg-primary-20 rounded-full" />

      {/* Header — school identity sits in the top 64px; the photo dips into the lower 20px only */}
      <div className="text-white px-5 relative z-10" style={{ ...headerBg, height: 84 }}>
        <div className="flex items-center gap-3" style={{ height: 80 }}>
          <SchoolMark campus={campus} />
          <div className="text-left min-w-0">
            <p className="text-[16px] font-bold uppercase tracking-wide leading-tight truncate">{campus?.name || "School Name"}</p>
            <p className="text-[14px] font-bold uppercase tracking-widest leading-none">Student Identity Card</p>
          </div>
        </div>
      </div>

      {/* Photo (left) + details (right). Both columns start on the same line. */}
      <div className="px-5 flex items-start gap-4 relative z-10" style={{ marginTop: 20 }}>
        <div className="bg-gray-100 rounded overflow-hidden flex-shrink-0 border-2 border-white shadow-md" style={{ width: 148, height: 170 }}>
          {student.user?.avatar ? (
            <img src={student.user.avatar} alt="" className="w-full h-full object-cover object-top" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-300">
              <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
            </div>
          )}
        </div>

        <div className="w-full flex-1">
          <div className="space-y-[7px] text-left">
            <Row label="Name" value={fullName} />
            <Row label="Reg No." value={student.admission_number} />
            <Row label="Gender" value={student.gender ? student.gender.charAt(0).toUpperCase() + student.gender.slice(1) : ""} />
            <Row label="Valid" value={validity} />
          </div>
          <div className="flex -mt-2 items-end justify-end">
            <div className="bg-white p-1.5 rounded border border-gray-200">
              <QRCodeSVG value={`EduTrack|${student.admission_number}|${fullName}|${student.class?.name}`} size={78} level="M" />
            </div>
          </div>
        </div>
      </div>

      {/* Footer band */}
      <div className="text-white px-5 flex flex-wrap items-center justify-between gap-2 relative z-10 text-[10.5px] mt-auto" style={{ ...headerBg, height: 28 }}>
        {/* <span className="font-medium">Valid {validity}</span> */}
        {/* {campus?.phone && <span className="opacity-90">{campus.phone}</span>} */}
      </div>
    </div>
  );
}

// Side B — back
function CardBack({ student, campus, validity }) {
  const fullName = `${student.user?.first_name || ""} ${student.user?.last_name || ""}`.trim();
  const parentName = student.parent ? `${student.parent.first_name || ""} ${student.parent.last_name || ""}`.trim() : "";
  const W = 74;
  return (
    <div className="idc-card">
      {/* Header */}
      <div className="text-white px-5 relative z-10 flex items-center justify-center" style={{ ...headerBg, height: 34 }}>
        <p className="text-[13px] font-bold uppercase tracking-wide truncate text-center">{campus?.name || "School Name"}</p>
      </div>

      {/* Notice */}
      <p className="px-5 py-3 text-[14px] text-gray-500 leading-snug text-center mt-12">
        This card is the property of {campus?.name || "the school"} and is not transferable. <br />
        If found, please return it to the school. <br />
        {campus?.phone ? ` Phone: ${campus.phone}` : ""} <br />
        {campus?.email ? ` Email: ${campus.email}` : ""}
      </p>

      {/* Signature */}
      <div className="px-5 mt-16 pb-12 flex items-center justify-center gap-3">
        <div className="text-center" style={{ width: 200 }}>
          <div className="border-t border-gray-400 pt-0.5">
            <p className="text-[14px] text-gray-500">Principal's Signature</p>
          </div>
        </div>
      </div>

      {/* Bottom band */}
      <div style={{ ...headerBg, height: 8 }} />
    </div>
  );
}

export default function IDCard() {
  const { user, can } = useAuth();
  const { currentCampus } = useCampus();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();
  const fileInputRef = useRef(null);

  const [selectedClass, setSelectedClass] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [classStudents, setClassStudents] = useState([]);
  const [selectedStudentId, setSelectedStudentId] = useState("");
  const [student, setStudent] = useState(null);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);

  // Options refresh for the currently selected year automatically; a
  // stale selection from a previous year is re-mapped onto that same
  // class's row for the new year (see hooks/useYearAwareClasses.js).
  const classes = useYearAwareClasses({ selectedClassId: selectedClass, onRemap: setSelectedClass });

  useEffect(() => {
    if (!selectedClass) { setClassStudents([]); return; }
    studentService.getAll({ class_id: selectedClass, section_id: selectedSection || undefined, status: "active", limit: 300 }).then((res) => {
      if (res.success) setClassStudents(res.data);
    });
  }, [selectedClass, selectedSection]);

  const sections = classes.find((c) => c.id === selectedClass)?.sections || [];

  useEffect(() => {
    if (!selectedStudentId) { setStudent(null); return; }
    setLoading(true);
    studentService.getById(selectedStudentId)
      .then((res) => { if (res.success) setStudent(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, [selectedStudentId]);

  const handlePhotoSelect = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || !student) return;
    try {
      setUploading(true);
      const res = await documentsService.uploadStudentPhoto(student.id, file);
      if (res.success) { showSuccess("Photo uploaded"); setStudent((s) => ({ ...s, user: { ...s.user, avatar: res.data.avatar } })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setUploading(false); }
  };

  const academicYearLabel = () => {
    const y = new Date().getFullYear();
    return `${y}/${y + 1}`;
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <style>{CARD_CSS}</style>

        <div className="print:hidden">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Student ID Card</h1>
            <p className="text-sm text-gray-500 mt-0.5">Generate a printable ID card (front and back) for any student</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded shadow print:hidden">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Select label="Class" value={selectedClass} onChange={(e) => { setSelectedClass(e.target.value); setSelectedSection(""); setSelectedStudentId(""); }}
              options={[{ value: "", label: "Select…" }, ...classes.map((c) => ({ value: c.id, label: c.name }))]} />
            <Select label="Section" value={selectedSection} onChange={(e) => { setSelectedSection(e.target.value); setSelectedStudentId(""); }} disabled={!selectedClass}
              options={[{ value: "", label: "All sections" }, ...sections.map((s) => ({ value: s.id, label: s.name }))]} />
            <Select label="Student" searchable disabled={!selectedClass} value={selectedStudentId} onChange={(e) => setSelectedStudentId(e.target.value)}
              options={[{ value: "", label: "Select…" }, ...classStudents.map((s) => ({ value: s.id, label: `${s.user?.first_name} ${s.user?.last_name} (${s.admission_number})` }))]} />
          </div>
        </div>

        {loading && <div className="bg-white p-10 rounded shadow text-center print:hidden"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>}

        {student && !loading && (
          <>
            <div className="flex items-center gap-3 print:hidden">
              {can("students.documents") && (
                <>
                  <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handlePhotoSelect} />
                  <Button variant="secondary" mobileLabel="Upload Photo" onClick={() => fileInputRef.current?.click()} disabled={uploading}>{uploading ? "Uploading…" : student.user?.avatar ? "Change Photo" : "Upload Photo"}</Button>
                </>
              )}
              <Button variant="primary" onClick={() => window.print()}>Print Card (Front &amp; Back)</Button>
            </div>

            <div className="idc-wrap flex flex-wrap justify-center items-start gap-x-10 gap-y-8 print:!mt-0">
              {[
                { key: "front", label: "Side A — Front", node: <CardFront student={student} campus={currentCampus} formatDate={formatDate} validity={academicYearLabel()} /> },
                { key: "back", label: "Side B — Back", node: <CardBack student={student} campus={currentCampus} validity={academicYearLabel()} /> },
              ].map((side) => (
                <div key={side.key} className="idc-page flex flex-col items-center gap-2">
                  <span className="print:hidden text-xs font-semibold text-gray-500 uppercase tracking-wider">{side.label}</span>
                  {/* Lanyard clip — screen-only visual context, not part of the printed card face */}
                  <div className="print:hidden flex flex-col items-center -mb-1">
                    <div className="w-10 h-14 rounded-sm opacity-90" style={{ background: "linear-gradient(to bottom, var(--color-primary), var(--color-primary-dark))", clipPath: "polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%)" }} />
                    <div className="w-16 h-6 bg-gray-300 rounded-sm -mt-1 shadow-sm" />
                  </div>
                  <div className="idc-frame">{side.node}</div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </MainLayout>
  );
}
