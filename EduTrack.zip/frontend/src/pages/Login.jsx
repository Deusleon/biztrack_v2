import { useState } from 'react';
import { useNavigate, Navigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Input, Button } from '../components/ui';
import BrandMark from "../components/BrandMark";

// A one-off message left by whatever sent the person here (a password just
// changed, a session ended because the password changed elsewhere).
const takeLoginNotice = () => {
  try {
    const notice = sessionStorage.getItem('loginNotice');
    if (notice) sessionStorage.removeItem('loginNotice');
    return notice || '';
  } catch { return ''; }
};

export default function Login() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [error, setError] = useState('');
  const [notice] = useState(takeLoginNotice);
  const [loading, setLoading] = useState(false);

  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // Already signed in (e.g. came back to /login manually) — no reason to
  // show the form again, just go straight to the dashboard.
  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await login(formData);
      navigate('/dashboard');
    } catch (err) {
      setError(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="max-w-md w-full bg-white rounded shadow-lg overflow-hidden">
        {/* Brand header — same mark and gradient as the app's own Sidebar,
            so this is unmistakably the same product before you've even
            logged in, and reflects whichever theme color the school has
            chosen (gradient-primary-dark tracks --color-primary). */}
        <div className="gradient-primary-dark px-8 py-8 text-center">
          <BrandMark className="w-24 h-auto mx-auto mb-3" />
          <h1 className="text-2xl font-bold tracking-tight text-white">EduTrack</h1>
          <p className="text-sm text-white opacity-80 mt-0.5">School Management System</p>
        </div>

        <div className="p-8">
          <h2 className="text-lg font-semibold text-gray-900 text-left mb-5">Sign In</h2>

          {notice && !error && (
            <div className="bg-green-50 border border-green-200 text-green-700 text-sm px-4 py-3 rounded mb-4 text-left" role="status">
              {notice}
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded mb-4 text-left">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Email"
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="e.g., email@example.com"
              required
              autoComplete="username"
            />

            <Input
              label="Password"
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="••••••••"
              required
              autoComplete="current-password"
            />

            <div className="text-right -mt-1">
              <Link to="/forgot-password" className="text-sm text-primary hover:underline">Forgot password?</Link>
            </div>

            <Button type="submit" loading={loading} className="w-full mt-2">
              Sign In
            </Button>
          </form>
          <p className="text-xs text-gray-500 text-center mt-6">
            By signing in you agree to our{" "}
            <Link to="/terms" className="text-primary hover:underline">Terms of Service</Link> and{" "}
            <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link>.
          </p>
        </div>
      </div>
    </div>
  );
}
