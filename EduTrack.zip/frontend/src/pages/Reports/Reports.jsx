import { useState, useEffect } from "react";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { reportsService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Button, DatePicker, DataTable } from "../../components/ui";
import {
  exportFinancialSummaryPDF, exportFinancialSummaryExcel,
  exportFeeCollectionPDF, exportFeeCollectionExcel,
  exportAttendanceSummaryPDF, exportAttendanceSummaryExcel,
  exportEnrollmentPDF, exportEnrollmentExcel,
  exportDetailedPaymentsPDF, exportDetailedPaymentsExcel,
  exportDetailedExpensesPDF, exportDetailedExpensesExcel,
} from "../../utils/reportsExport";
import { formatMoney } from "../../utils/money";


const REPORTS = [
  { id: "financial", name: "Financial Summary", description: "Income vs Expenses vs Payroll, month by month for the year" },
  { id: "fees", name: "Fee Collection", description: "Expected vs collected vs outstanding, by class" },
  { id: "attendance", name: "Attendance Summary", description: "Attendance rate by class over a date range" },
  { id: "enrollment", name: "Enrollment", description: "Student counts per class, by gender" },
  { id: "payments", name: "Detailed Payments", description: "Every individual fee payment in a date range" },
  { id: "expenses", name: "Detailed Expenses", description: "Every individual expense transaction in a date range" },
];

export default function Reports() {
  const { showError } = useToast();
  const { currentAcademicYear, yearOptions } = useAcademicYear();
  const [activeReport, setActiveReport] = useState(null);
  const [yearRange, setYearRange] = useState({ start_year: new Date().getFullYear(), end_year: new Date().getFullYear() });
  const [year, setYear] = useState(new Date().getFullYear());
  // The Fee Collection report is scoped by ACADEMIC year (like every other
  // fee-related screen), not the calendar year used by Financial Summary —
  // without this it silently mixed every year's fee structures together,
  // ignoring the header's academic-year selector entirely.
  const [feeAcademicYear, setFeeAcademicYear] = useState(currentAcademicYear);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    reportsService.getYearRange().then((res) => {
      if (res.success) { setYearRange(res.data); setYear(res.data.end_year); }
    }).catch(() => {});
  }, []);

  // Keep the Fee Collection year in step with the header's global academic
  // year selector, the same way every other academic-year-scoped page does.
  useEffect(() => { setFeeAcademicYear(currentAcademicYear); }, [currentAcademicYear]);

  // The Financial Summary takes a plain calendar year, and it was left on
  // whatever the API reported as the newest year with data — so choosing
  // 2027 in the header could still show 2026 figures. School years run
  // January to December here, so the selected academic year's base year IS
  // the calendar year to report on.
  useEffect(() => {
    const base = parseInt(String(currentAcademicYear || "").match(/\d{4}/)?.[0], 10);
    if (base) setYear(base);
  }, [currentAcademicYear]);

  // A report already on screen belongs to the year it was run for. Leaving
  // it up after the year changes is the most misleading thing this page
  // can do — the heading says one year and the numbers are another's.
  useEffect(() => { setResult(null); setActiveReport(null); }, [currentAcademicYear]);

  const runReport = async (id) => {
    setActiveReport(id);
    setResult(null);
    setLoading(true);
    try {
      let res;
      if (id === "financial") res = await reportsService.getFinancialSummary(year);
      else if (id === "fees") res = await reportsService.getFeeCollection(feeAcademicYear);
      // Attendance/Payments/Expenses stay date-range reports (an admin
      // can still narrow to any specific dates), but now default that
      // range to the SELECTED academic year's real calendar window
      // whenever no explicit date was typed — so switching the header's
      // year selector changes what these show too, the same as Fee
      // Collection already does, instead of always defaulting to "the
      // last 30 days" / "this calendar year" regardless of it.
      else if (id === "attendance") res = await reportsService.getAttendanceSummary({ start_date: startDate || undefined, end_date: endDate || undefined, academic_year: currentAcademicYear });
      else if (id === "enrollment") res = await reportsService.getEnrollment({ academic_year: currentAcademicYear });
      else if (id === "payments") res = await reportsService.getDetailedPayments({ start_date: startDate || undefined, end_date: endDate || undefined, academic_year: currentAcademicYear });
      else if (id === "expenses") res = await reportsService.getDetailedExpenses({ start_date: startDate || undefined, end_date: endDate || undefined, academic_year: currentAcademicYear });
      if (res.success) setResult(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const handleExport = async (format) => {
    if (!result) return;
    try {
      setExporting(true);
      if (activeReport === "financial") {
        const args = { year: result.year, rows: result.rows, totals: result.totals, filename: `financial-summary-${result.year}` };
        format === "pdf" ? await exportFinancialSummaryPDF(args) : await exportFinancialSummaryExcel(args);
      } else if (activeReport === "fees") {
        const args = { rows: result.rows, totals: result.totals, filename: `fee-collection-report${feeAcademicYear ? `-${feeAcademicYear}` : ""}` };
        format === "pdf" ? await exportFeeCollectionPDF(args) : await exportFeeCollectionExcel(args);
      } else if (activeReport === "attendance") {
        const args = { start_date: result.start_date, end_date: result.end_date, rows: result.rows, filename: `attendance-summary-${result.start_date}-to-${result.end_date}` };
        format === "pdf" ? await exportAttendanceSummaryPDF(args) : await exportAttendanceSummaryExcel(args);
      } else if (activeReport === "enrollment") {
        const args = { rows: result.rows, totals: result.totals, filename: "enrollment-report" };
        format === "pdf" ? await exportEnrollmentPDF(args) : await exportEnrollmentExcel(args);
      } else if (activeReport === "payments") {
        const args = { start_date: result.start_date, end_date: result.end_date, rows: result.rows, total: result.total, filename: `detailed-payments-${result.start_date}-to-${result.end_date}` };
        format === "pdf" ? await exportDetailedPaymentsPDF(args) : await exportDetailedPaymentsExcel(args);
      } else if (activeReport === "expenses") {
        const args = { start_date: result.start_date, end_date: result.end_date, rows: result.rows, total: result.total, filename: `detailed-expenses-${result.start_date}-to-${result.end_date}` };
        format === "pdf" ? await exportDetailedExpensesPDF(args) : await exportDetailedExpensesExcel(args);
      }
    } catch (err) { showError("Could not generate the file — " + err.message); }
    finally { setExporting(false); }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="text-left">
          <h1 className="text-xl font-bold text-gray-900">Reports</h1>
          <p className="text-sm text-gray-500 mt-0.5">Generate and download reports as PDF or Excel</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {REPORTS.map((r) => (
            <button key={r.id} onClick={() => runReport(r.id)}
              className={`text-left bg-white rounded shadow p-5 hover:shadow-md transition-shadow border-2 ${activeReport === r.id ? "border-primary" : "border-transparent"}`}>
              <p className="text-sm font-semibold text-gray-900">{r.name}</p>
              <p className="text-xs text-gray-500 mt-1">{r.description}</p>
            </button>
          ))}
        </div>

        {activeReport && (
          <div className="rounded shadow space-y-4">
            <div className="flex items-end justify-between flex-wrap gap-4">
              <div className="flex items-end gap-3">
                {activeReport === "financial" && (
                  <Select label="Year" value={year} onChange={(e) => setYear(Number(e.target.value))}
                    options={Array.from({ length: yearRange.end_year - yearRange.start_year + 1 }, (_, i) => yearRange.start_year + i).map((y) => ({ value: y, label: String(y) }))} />
                )}
                {activeReport === "fees" && (
                  <Select label="Academic Year" value={feeAcademicYear} onChange={(e) => setFeeAcademicYear(e.target.value)}
                    options={(yearOptions || []).map((y) => ({ value: y, label: y }))} />
                )}
                {(activeReport === "attendance" || activeReport === "payments" || activeReport === "expenses") && (
                  <>
                    <DatePicker label="From" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                    <DatePicker label="To" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                  </>
                )}
                <Button onClick={() => runReport(activeReport)} variant="secondary" loading={loading}>Refresh</Button>
              </div>
              {result && (
                <div className="flex gap-2">
                  <Button onClick={() => handleExport("pdf")} loading={exporting} variant="secondary">Download PDF</Button>
                  <Button onClick={() => handleExport("excel")} loading={exporting} variant="secondary">Download Excel</Button>
                </div>
              )}
            </div>

            {loading ? (
              <div className="py-10 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
            ) : result && (
              <ReportPreview reportId={activeReport} data={result} />
            )}
          </div>
        )}
      </div>
    </MainLayout>
  );
}

function ReportPreview({ reportId, data }) {
  if (reportId === "financial") {
    return (
      <DataTable
        columns={[
          { key: "month_name", label: "Month" },
          { key: "income", label: "Income", align: "right", render: (r) => formatMoney(r.income) },
          { key: "expenses", label: "Expenses", align: "right", render: (r) => formatMoney(r.expenses) },
          { key: "payroll", label: "Payroll", align: "right", render: (r) => formatMoney(r.payroll) },
          { key: "net", label: "Net", align: "right", render: (r) => <span className={r.net < 0 ? "text-red-600" : "text-green-600"}>{formatMoney(r.net)}</span> },
        ]}
        data={data.rows}
        rowId="month"
        emptyMessage="No financial activity recorded for this year."
        footer={
          <tr className="font-semibold">
            <td className="px-5 py-2 text-sm">Total</td>
            <td className="px-5 py-2 text-sm text-right">{formatMoney(data.totals.income)}</td>
            <td className="px-5 py-2 text-sm text-right">{formatMoney(data.totals.expenses)}</td>
            <td className="px-5 py-2 text-sm text-right">{formatMoney(data.totals.payroll)}</td>
            <td className="px-5 py-2 text-sm text-right">{formatMoney(data.totals.net)}</td>
          </tr>
        }
      />
    );
  }
  if (reportId === "fees") {
    return (
      <DataTable
        columns={[
          { key: "class_name", label: "Class" },
          { key: "students", label: "Students", align: "right" },
          { key: "expected", label: "Expected", align: "right", render: (r) => formatMoney(r.expected) },
          { key: "collected", label: "Collected", align: "right", render: (r) => formatMoney(r.collected) },
          { key: "outstanding", label: "Outstanding", align: "right", render: (r) => <span className="text-red-600">{formatMoney(r.outstanding)}</span> },
          { key: "collection_rate", label: "Rate", align: "right", render: (r) => (r.collection_rate !== null ? `${r.collection_rate}%` : "—") },
        ]}
        data={data.rows}
        rowId="class_name"
        emptyMessage="No fee structures found for this year."
      />
    );
  }
  if (reportId === "attendance") {
    return (
      <DataTable
        columns={[
          { key: "class_name", label: "Class" },
          { key: "total_records", label: "Records", align: "right" },
          { key: "present", label: "Present", align: "right", render: (r) => <span className="text-green-600">{r.present}</span> },
          { key: "absent", label: "Absent", align: "right", render: (r) => <span className="text-red-500">{r.absent}</span> },
          { key: "excused", label: "Excused", align: "right" },
          { key: "attendance_rate", label: "Rate", align: "right", render: (r) => <span className="font-medium">{r.attendance_rate}%</span> },
        ]}
        data={data.rows}
        rowId="class_name"
        emptyMessage="No attendance records in this range."
      />
    );
  }
  if (reportId === "enrollment") {
    return (
      <DataTable
        columns={[
          { key: "class_name", label: "Class" },
          { key: "education_level", label: "Level", render: (r) => <span className="capitalize text-gray-500">{r.education_level?.replace("_", "-")}</span> },
          { key: "total", label: "Total", align: "right" },
          { key: "male", label: "Male", align: "right" },
          { key: "female", label: "Female", align: "right" },
        ]}
        data={data.rows}
        rowId="class_name"
        emptyMessage="No classes found for this year."
        footer={
          <tr className="font-semibold">
            <td className="px-5 py-2 text-sm" colSpan={2}>Total</td>
            <td className="px-5 py-2 text-sm text-right">{data.totals.total}</td>
            <td className="px-5 py-2 text-sm text-right">{data.totals.male}</td>
            <td className="px-5 py-2 text-sm text-right">{data.totals.female}</td>
          </tr>
        }
      />
    );
  }
  if (reportId === "payments") {
    return (
      <DataTable
        columns={[
          { key: "payment_date", label: "Date" },
          { key: "student_name", label: "Student" },
          { key: "admission_number", label: "Adm No." },
          { key: "fee_structure", label: "Fee" },
          { key: "amount", label: "Amount", align: "right", render: (r) => formatMoney(r.amount) },
          { key: "payment_method", label: "Method", render: (r) => <span className="capitalize">{r.payment_method.replace("_", " ")}</span> },
          { key: "transaction_id", label: "Reference" },
        ]}
        data={data.rows}
        rowId={(r, i) => `${r.payment_date}-${r.admission_number}-${i}`}
        emptyMessage="No payments in this range."
        footer={data.rows.length > 0 && (
          <tr className="font-semibold">
            <td className="px-5 py-2 text-sm" colSpan={4}>Total</td>
            <td className="px-5 py-2 text-sm text-right">{formatMoney(data.total)}</td>
            <td className="px-5 py-2 text-sm" colSpan={2}></td>
          </tr>
        )}
      />
    );
  }
  if (reportId === "expenses") {
    return (
      <DataTable
        columns={[
          { key: "expense_date", label: "Date" },
          { key: "category", label: "Category" },
          { key: "payee", label: "Paid To" },
          { key: "amount", label: "Amount", align: "right", render: (r) => formatMoney(r.amount) },
          { key: "payment_method", label: "Method", render: (r) => <span className="capitalize">{r.payment_method.replace("_", " ")}</span> },
          { key: "reference_number", label: "Reference" },
        ]}
        data={data.rows}
        rowId={(r, i) => `${r.expense_date}-${r.reference_number}-${i}`}
        emptyMessage="No expenses in this range."
        footer={data.rows.length > 0 && (
          <tr className="font-semibold">
            <td className="px-5 py-2 text-sm" colSpan={3}>Total</td>
            <td className="px-5 py-2 text-sm text-right">{formatMoney(data.total)}</td>
            <td className="px-5 py-2 text-sm" colSpan={2}></td>
          </tr>
        )}
      />
    );
  }
  return null;
}
