import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useSubscription } from "../contexts/SubscriptionContext";
import BrandMark from "../components/BrandMark";
import { ActionLink, Button } from "../components/ui";

/**
 * Shown, instead of the page asked for, to someone who cannot open the
 * Subscription page themselves (a teacher, an accountant …) while the school is locked.
 */
export default function SubscriptionLocked() {
  const { logout, user } = useAuth();
  const { status } = useSubscription();
  const cancelled = status === "cancelled";
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4 py-8">
      <div className="max-w-md w-full bg-white rounded shadow-lg overflow-hidden text-left">
        <div className="gradient-primary-dark px-8 py-6 text-center">
          <BrandMark className="w-16 h-auto mx-auto mb-2" />
          <h1 className="text-xl font-bold tracking-tight text-white">EduTrack is paused</h1>
        </div>
        <div className="p-8 space-y-4 text-sm text-gray-700 leading-relaxed">
          <p>
            {cancelled
              ? "This school's EduTrack subscription has been cancelled."
              : "This school's EduTrack subscription has expired and the grace period has passed."}{" "}
            Nothing in EduTrack can be used until it is renewed.
          </p>
          <p>
            {user?.first_name ? `${user.first_name}, please` : "Please"} ask your school administrator to renew the
            subscription. Everything you entered is safe and will be here again as soon as the payment is confirmed.
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            <ActionLink to="/help/contact" variant="secondary">Contact support</ActionLink>
            <Button variant="primary" onClick={logout}>Sign out</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
