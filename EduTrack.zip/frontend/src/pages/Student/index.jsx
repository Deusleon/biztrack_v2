export { default as StudentList } from './StudentList';
export { default as AdmissionForm } from './AdmissionForm';
export { default as StudentView } from './StudentView';
export { default as Promotion } from './Promotion';
export { default as InquiryList } from './InquiryList';
export { default as BulkUpload } from './BulkUpload';
