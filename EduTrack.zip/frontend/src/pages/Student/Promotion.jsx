import { useState, useEffect } from "react";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { promotionService, classService, studentService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Button, DataTable, ConfirmModal } from "../../components/ui";

const ACTION_OPTIONS = [
  { value: "promoted", label: "Promote" },
  { value: "retained", label: "Repeat year" },
  { value: "graduated", label: "Graduate" },
  { value: "transferred", label: "Left school" },
];

const ACTION_STYLES = {
  promoted: "bg-green-100 border border-green-300 text-green-500",
  retained: "bg-amber-100 border border-amber-300 text-amber-600",
  graduated: "bg-blue-100 border border-blue-300 text-blue-500",
  transferred: "bg-gray-100 border border-gray-300 text-gray-500",
};

// Mirrors backend/src/utils/gradeLevels.js's gradeNumber — just enough to
// sort/filter candidate target classes in this dropdown. The backend is
// still the authority that actually enforces "must be higher".
const ROMAN = { I: 1, II: 2, III: 3, IV: 4, V: 5, VI: 6, VII: 7 };
const gradeNumber = (grade) => {
  const raw = String(grade || "").trim().toUpperCase();
  const digits = raw.match(/\d+/);
  if (digits) return parseInt(digits[0], 10);
  const roman = raw.match(/\b(VII|VI|IV|V|III|II|I)\b/);
  return roman ? ROMAN[roman[1]] : null;
};

export default function Promotion() {
  const { showSuccess, showError } = useToast();
  const { formatDateTime } = usePreferences();
  const { currentAcademicYear, yearOptions } = useAcademicYear();

  const [fromYear, setFromYear] = useState(currentAcademicYear);
  const [toYear, setToYear] = useState("");
  const [preview, setPreview] = useState(null);
  const [decisions, setDecisions] = useState({});
  const [loading, setLoading] = useState(false);
  const [running, setRunning] = useState(false);
  const [confirm, setConfirm] = useState({ isOpen: false });
  const [history, setHistory] = useState([]);
  const [revertBatch, setRevertBatch] = useState(null);
  // Page position per class. A school promoting 800 students would
  // otherwise render one page tens of thousands of pixels long.
  const [groupPage, setGroupPage] = useState({});

  const PAGE_SIZE = 10;
  const [creatingClasses, setCreatingClasses] = useState(false);

  // ── Individual mid-year promotion — a separate, smaller flow from the
  // bulk year-end run above: move ONE student straight into a higher
  // class right now, within the same academic year. ──
  const [indivSearch, setIndivSearch] = useState("");
  const [indivResults, setIndivResults] = useState([]);
  const [indivSearching, setIndivSearching] = useState(false);
  const [indivStudent, setIndivStudent] = useState(null);
  const [indivClasses, setIndivClasses] = useState([]);
  const [indivToClassId, setIndivToClassId] = useState("");
  const [indivSections, setIndivSections] = useState([]);
  const [indivToSectionId, setIndivToSectionId] = useState("");
  const [indivNotes, setIndivNotes] = useState("");
  const [indivSubmitting, setIndivSubmitting] = useState(false);

  useEffect(() => {
    if (!indivStudent) { setIndivClasses([]); return; }
    classService.getAll({ limit: 300, status: "active", academic_year: indivStudent.class?.academic_year })
      .then((res) => {
        if (!res.success) return;
        const currentGradeNum = gradeNumber(indivStudent.class?.grade);
        setIndivClasses(
          res.data.filter((c) =>
            c.id !== indivStudent.class_id
            && c.campus_id === indivStudent.campus_id
            && c.education_level === indivStudent.class?.education_level
            && (currentGradeNum === null || (gradeNumber(c.grade) ?? -Infinity) > currentGradeNum)
          )
        );
      })
      .catch(() => setIndivClasses([]));
  }, [indivStudent]);

  useEffect(() => {
    if (!indivToClassId) { setIndivSections([]); setIndivToSectionId(""); return; }
    classService.getById(indivToClassId)
      .then((res) => { if (res.success) setIndivSections(res.data.sections || []); })
      .catch(() => setIndivSections([]));
  }, [indivToClassId]);

  const handleIndivSearch = async (query) => {
    setIndivSearch(query);
    if (!query || query.trim().length < 2) { setIndivResults([]); return; }
    try {
      setIndivSearching(true);
      const res = await studentService.getAll({ search: query, status: "active", limit: 8 });
      if (res.success) setIndivResults(res.data);
    } catch { setIndivResults([]); }
    finally { setIndivSearching(false); }
  };

  const pickIndivStudent = (student) => {
    setIndivStudent(student);
    setIndivResults([]);
    setIndivSearch(`${student.user?.first_name || ""} ${student.user?.last_name || ""}`.trim());
    setIndivToClassId("");
    setIndivToSectionId("");
    setIndivNotes("");
  };

  const resetIndivForm = () => {
    setIndivStudent(null);
    setIndivSearch("");
    setIndivResults([]);
    setIndivToClassId("");
    setIndivToSectionId("");
    setIndivNotes("");
  };

  const handleIndivPromote = async () => {
    if (!indivStudent || !indivToClassId) return;
    try {
      setIndivSubmitting(true);
      const res = await promotionService.promoteIndividual({
        student_id: indivStudent.id, to_class_id: indivToClassId,
        to_section_id: indivToSectionId || undefined, notes: indivNotes || undefined,
      });
      if (res.success) {
        showSuccess(res.message || "Student promoted");
        resetIndivForm();
        loadHistory();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || "Failed to promote this student");
    } finally {
      setIndivSubmitting(false);
    }
  };

  // Default the target year to the one after the year being closed.
  useEffect(() => {
    if (!toYear && yearOptions?.length) {
      const idx = yearOptions.indexOf(fromYear);
      if (idx >= 0 && yearOptions[idx + 1]) setToYear(yearOptions[idx + 1]);
    }
  }, [fromYear, yearOptions]);

  const loadHistory = () => {
    promotionService.getHistory()
      .then((res) => { if (res.success) setHistory(res.data || []); })
      .catch(() => {});
  };

  useEffect(() => { loadHistory(); }, []);

  const handlePreview = async () => {
    if (!fromYear || !toYear) return showError("Choose both academic years");
    if (fromYear === toYear) return showError("The two years must be different");

    try {
      setLoading(true);
      setPreview(null);
      const res = await promotionService.preview({ from_academic_year: fromYear, to_academic_year: toYear });
      if (res.success) {
        setPreview(res.data);
        // Seed every student with the suggested decision, so the common
        // case is one click and the exceptions are the only edits.
        const seeded = {};
        (res.data.groups || []).forEach((g) => {
          g.students.forEach((s) => {
            seeded[s.id] = {
              action: s.suggested_action,
              to_class_id: g.to_class?.id || null,
              to_section_id: null,
            };
          });
        });
        setDecisions(seeded);
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateMissingClasses = async () => {
    if (!fromYear || !toYear) return;
    try {
      setCreatingClasses(true);
      const res = await classService.cloneYear({ from_academic_year: fromYear, to_academic_year: toYear });
      if (res.success) {
        showSuccess(res.message);
        // Re-run the preview so the newly created classes show up as
        // valid targets right away, without the admin re-clicking.
        await handlePreview();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    } finally {
      setCreatingClasses(false);
    }
  };

  const setAction = (studentId, action, group) => {
    setDecisions((d) => ({
      ...d,
      [studentId]: {
        action,
        // Repeating means the SAME grade in the NEW year — a different
        // class row, because the source class belongs to the year being
        // closed. This previously carried over whatever was already set,
        // which was the promotion target seeded on load: marking a student
        // to repeat quietly promoted them anyway.
        to_class_id: action === "promoted" ? group.to_class?.id || null
          : action === "retained" ? group.retain_class?.id || null
            : null,
        to_section_id: null,
      },
    }));
  };

  /** Applies one decision to every student in a class at once. With
   * pagination in place, setting a whole form otherwise means paging
   * through it ten students at a time. */
  const setGroupAction = (group, action) => {
    setDecisions((d) => {
      const next = { ...d };
      group.students.forEach((s) => {
        next[s.id] = {
          action,
          to_class_id: action === "promoted" ? group.to_class?.id || null
            : action === "retained" ? group.retain_class?.id || null
              : null,
          to_section_id: null,
        };
      });
      return next;
    });
  };

  const counts = Object.values(decisions).reduce((acc, d) => {
    acc[d.action] = (acc[d.action] || 0) + 1;
    return acc;
  }, {});

  const handleRun = async () => {
    setConfirm({ isOpen: false });
    const payload = Object.entries(decisions).map(([student_id, d]) => ({ student_id, ...d }));

    // Retained students need a target class in the new year, and there's
    // no sensible default — better to say so than to fail server-side.
    const missing = payload.filter((d) => (d.action === "promoted" || d.action === "retained") && !d.to_class_id);
    if (missing.length > 0) {
      const repeaters = missing.filter((d) => d.action === "retained").length;
      return showError(repeaters > 0
        ? `${repeaters} student(s) are set to repeat, but ${toYear} has no class for their current grade. Create it first.`
        : `${missing.length} student(s) have no destination class. Set one, or mark them as leaving.`);
    }

    try {
      setRunning(true);
      const res = await promotionService.run({
        from_academic_year: fromYear, to_academic_year: toYear, decisions: payload,
      });
      if (res.success) {
        showSuccess(res.message);
        setPreview(null);
        setDecisions({});
        loadHistory();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    } finally {
      setRunning(false);
    }
  };

  const handleRevert = async () => {
    const batchId = revertBatch?.batch_id;
    setRevertBatch(null);
    if (!batchId) return;
    try {
      const res = await promotionService.revert(batchId);
      if (res.success) {
        showSuccess(res.message);
        loadHistory();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Student Promotion</h1>
            <p className="text-sm text-gray-500 mt-0.5">Move students into the next academic year</p>
          </div>
        </div>

        {/* Individual mid-year promotion — jump ONE student ahead, right
            now, within the current academic year (separate from the
            year-end bulk run below). */}
        <div className="bg-white p-5 rounded shadow">
          <h2 className="text-sm font-semibold text-gray-700 text-left mb-1">Individual Mid-Year Promotion</h2>
          <p className="text-sm text-left text-gray-400 mb-4">
            Move one student straight into a higher class right now — for a student who's clearly outgrown their
            current class before the year-end promotion run.
          </p>
          {!indivStudent ? (
            <div className="relative max-w-md">
              <input
                type="text"
                value={indivSearch}
                onChange={(e) => handleIndivSearch(e.target.value)}
                placeholder="Search student by name or admission number..."
                className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
              />
              {indivSearching && <p className="text-xs text-gray-400 mt-1">Searching...</p>}
              {indivResults.length > 0 && (
                <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded shadow max-h-64 overflow-y-auto">
                  {indivResults.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => pickIndivStudent(s)}
                      className="w-full text-left px-3 py-2 text-sm hover:bg-gray-50 flex flex-wrap items-center justify-between gap-2"
                    >
                      <span>{s.user?.first_name} {s.user?.last_name}</span>
                      <span className="text-xs text-gray-400">{s.admission_number} — {s.class?.name || "No class"}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 bg-gray-50 border border-gray-200 rounded px-3 py-2">
                <div className="text-left text-sm">
                  <span className="font-medium text-gray-900">{indivStudent.user?.first_name} {indivStudent.user?.last_name}</span>
                  <span className="text-gray-400"> — {indivStudent.admission_number} — Currently: {indivStudent.class?.name || "No class"}</span>
                </div>
                <button onClick={resetIndivForm} className="text-xs text-gray-500 hover:text-gray-700 underline">Change student</button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <Select
                  label="Promote To"
                  value={indivToClassId}
                  onChange={(e) => setIndivToClassId(e.target.value)}
                  options={[
                    { value: "", label: indivClasses.length ? "Select a class" : "No eligible higher class found" },
                    ...indivClasses.map((c) => ({ value: c.id, label: c.name })),
                  ]}
                />
                <Select
                  label="Section (optional)"
                  value={indivToSectionId}
                  onChange={(e) => setIndivToSectionId(e.target.value)}
                  disabled={!indivToClassId || indivSections.length === 0}
                  options={[
                    { value: "", label: indivSections.length === 0 ? "No sections" : "Select section" },
                    ...indivSections.map((s) => ({ value: s.id, label: s.name })),
                  ]}
                />
                <div className="flex items-end">
                  <Button onClick={handleIndivPromote} loading={indivSubmitting} disabled={!indivToClassId}>
                    Promote Now
                  </Button>
                </div>
              </div>
              <textarea
                value={indivNotes}
                onChange={(e) => setIndivNotes(e.target.value)}
                placeholder="Notes (optional) — e.g. reason for the early promotion"
                rows={2}
                className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
              />
            </div>
          )}
        </div>

        {/* Year selection */}
        <div className="bg-white p-5 rounded shadow">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <Select
              label="Year Being Closed"
              value={fromYear}
              onChange={(e) => { setFromYear(e.target.value); setPreview(null); }}
              options={(yearOptions || []).map((y) => ({ value: y, label: y }))}
            />
            <Select
              label="Year Being Opened"
              value={toYear}
              onChange={(e) => { setToYear(e.target.value); setPreview(null); }}
              options={(yearOptions || []).map((y) => ({ value: y, label: y }))}
            />
            <Button onClick={handlePreview} loading={loading}>Preview Promotion</Button>
          </div>
          <p className="text-sm text-left text-gray-400 mt-3">
            Nothing changes until you review the preview and confirm. If a class for the new year doesn't exist
            yet, you'll get an option to create it automatically from this year's classes after previewing.
          </p>
        </div>

        {preview && (
          <>
            {preview.warnings?.length > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded px-4 py-3 text-sm text-left text-amber-800">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-medium mb-1">Some classes can't be promoted yet:</p>
                    <ul className="list-disc list-inside space-y-0.5">
                      {preview.warnings.map((w, i) => <li key={i}>{w}</li>)}
                    </ul>
                  </div>
                  <Button
                    onClick={handleCreateMissingClasses}
                    loading={creatingClasses}
                    className="shrink-0 !bg-amber-600 hover:!bg-amber-700"
                  >
                    Create missing classes
                  </Button>
                </div>
                <p className="text-xs text-amber-700 mt-2">
                  This clones every class from {fromYear} into {toYear} (same name, grade and streams) — nothing
                  is duplicated for classes that already exist in {toYear}.
                </p>
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Students", value: preview.summary.total, tone: "text-primary" },
                { label: "To Promote", value: counts.promoted || 0, tone: "text-green-600" },
                { label: "To Graduate", value: counts.graduated || 0, tone: "text-blue-600" },
                { label: "Repeating", value: counts.retained || 0, tone: "text-amber-600" },
              ].map((c) => (
                <div key={c.label} className="bg-white p-5 rounded shadow">
                  <p className="text-sm text-left text-gray-600">{c.label}</p>
                  <p className={`text-2xl text-left font-bold mt-1 ${c.tone}`}>{c.value}</p>
                </div>
              ))}
            </div>

            {preview.groups.map((group, groupIndex) => {
              const page = groupPage[group.from_class.id] || 1;
              const totalPages = Math.max(1, Math.ceil(group.students.length / PAGE_SIZE));
              const pageStudents = group.students.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

              return (
              <div key={group.from_class.id} className="bg-white rounded shadow overflow-hidden">
                <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="text-left">
                      <p className="text-sm font-semibold text-gray-800">
                        {/* Numbered in processing order so it's obvious the
                            highest form is handled first. */}
                        <span className="text-gray-400 font-normal">{groupIndex + 1}. </span>
                        {group.from_class.name}
                        <span className="text-gray-400 font-normal"> → {group.to_class?.name || (group.is_final_year ? "Graduating" : "No target class")}</span>
                      </p>
                      <p className="text-xs text-gray-400">{group.students.length} student(s)</p>
                    </div>
                    {group.issue && <p className="text-xs text-red-600 max-w-md text-right">{group.issue}</p>}
                  </div>

                  {/* Set the whole class in one go — paging through a form of
                      120 to set each student individually is not a workflow. */}
                  {group.students.length > 0 && (
                    <div className="flex items-center gap-2 flex-wrap mt-2">
                      <span className="text-xs text-gray-500">Set all:</span>
                      {ACTION_OPTIONS.filter((o) =>
                        (o.value !== "graduated" || group.is_final_year)
                        && (o.value !== "promoted" || Boolean(group.to_class))
                        && (o.value !== "retained" || Boolean(group.retain_class))).map((o) => (
                        <button
                          key={o.value}
                          onClick={() => setGroupAction(group, o.value)}
                          className="text-xs px-2.5 py-1 rounded border border-gray-300 text-gray-600 hover:bg-white hover:border-primary hover:text-primary"
                        >
                          {o.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <DataTable
                  columns={[
                    {
                      key: "name", label: "Student",
                      render: (s) => (
                        <div>
                          <div className="text-sm text-gray-900">{s.name}</div>
                          <div className="text-xs text-gray-400">{[s.admission_number, s.section].filter(Boolean).join(" · ")}</div>
                        </div>
                      ),
                    },
                    {
                      key: "action", label: "Decision",
                      render: (s) => (
                        <div className="w-40">
                          <Select
                            value={decisions[s.id]?.action || s.suggested_action}
                            onChange={(e) => setAction(s.id, e.target.value, group)}
                            options={ACTION_OPTIONS.filter((o) =>
                              // Only a final-year class can graduate; only a
                              // class with somewhere to go can promote; and a
                              // student can only repeat if next year actually
                              // has a class for their current grade.
                              (o.value !== "graduated" || group.is_final_year)
                              && (o.value !== "promoted" || Boolean(group.to_class))
                              && (o.value !== "retained" || Boolean(group.retain_class)))}
                          />
                        </div>
                      ),
                    },
                    {
                      key: "destination", label: "Destination", align: "center",
                      render: (s) => {
                        const d = decisions[s.id] || {};
                        if (d.action === "promoted") return <span className="text-sm text-gray-700">{group.to_class?.name || "—"}</span>;
                        if (d.action === "retained") return <span className="text-sm text-amber-600">{group.retain_class?.name || "Same grade"} ({toYear})</span>;
                        return <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${ACTION_STYLES[d.action] || ""}`}>{d.action}</span>;
                      },
                    },
                  ]}
                  data={pageStudents}
                  rowId="id"
                  emptyMessage="No active students in this class"
                />

                {totalPages > 1 && (
                  <div className="px-5 py-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-2">
                    <p className="text-xs text-gray-500">
                      Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, group.students.length)} of {group.students.length}
                    </p>
                    <div className="flex items-center gap-2">
                      <Button variant="secondary" size="sm" disabled={page === 1} onClick={() => setGroupPage((g) => ({ ...g, [group.from_class.id]: page - 1 }))}>Previous</Button>
                      <span className="text-xs text-gray-500">Page {page} of {totalPages}</span>
                      <Button variant="secondary" size="sm" disabled={page === totalPages} onClick={() => setGroupPage((g) => ({ ...g, [group.from_class.id]: page + 1 }))}>Next</Button>
                    </div>
                  </div>
                )}
              </div>
              );
            })}

            {preview.summary.total > 0 && (
              <div className="bg-white p-5 rounded shadow flex items-center justify-between flex-wrap gap-3">
                <p className="text-sm text-left text-gray-600">
                  This moves <strong>{preview.summary.total}</strong> student(s) from {fromYear} into {toYear}.
                  It can be undone from the history below.
                </p>
                <Button loading={running} onClick={() => setConfirm({ isOpen: true })}>
                  Run Promotion
                </Button>
              </div>
            )}
          </>
        )}

        {/* History */}
        <DataTable
          columns={[
            { key: "years", label: "Promotion", render: (b) => <span className="text-sm font-medium text-gray-900">{b.from_academic_year} → {b.to_academic_year}</span> },
            {
              key: "counts", label: "Outcome",
              render: (b) => (
                <span className="text-xs text-gray-600">
                  {b.counts.promoted || 0} promoted · {b.counts.retained || 0} repeating · {b.counts.graduated || 0} graduated
                </span>
              ),
            },
            { key: "total", label: "Students", align: "center", render: (b) => <span className="text-sm text-gray-600">{b.total}</span> },
            { key: "by", label: "By", render: (b) => <span className="text-sm text-gray-600">{b.performed_by || "—"}</span> },
            { key: "date", label: "Date", render: (b) => <span className="text-xs text-gray-500">{formatDateTime(b.created_at)}</span> },
            {
              key: "status", label: "Status", align: "center",
              render: (b) => (b.reverted_at
                ? <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 border border-gray-300 text-gray-500">Reverted</span>
                : <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 border border-green-300 text-green-500">Applied</span>),
            },
          ]}
          data={history}
          rowId="batch_id"
          emptyMessage="No promotions have been run yet"
          renderActions={(b) => (b.reverted_at ? null : (
            <button onClick={() => setRevertBatch(b)} className="text-red-500 hover:underline text-xs font-medium">
              Revert
            </button>
          ))}
        />
      </div>

      <ConfirmModal
        isOpen={confirm.isOpen}
        title="Run Promotion"
        message={`This will move ${preview?.summary.total || 0} student(s) into ${toYear}. You can undo it afterwards from the history.`}
        onConfirm={handleRun}
        onClose={() => setConfirm({ isOpen: false })}
      />

      <ConfirmModal
        isOpen={Boolean(revertBatch)}
        title="Revert Promotion"
        // Names the run and its size: "revert" on its own doesn't say which
        // of several runs is about to be undone.
        message={revertBatch
          ? `Undo the ${revertBatch.from_academic_year} → ${revertBatch.to_academic_year} promotion? All ${revertBatch.total} student(s) go back to the class and status they had before it. This cannot be redone — you would have to run the promotion again.`
          : ""}
        confirmText="Yes, revert"
        variant="danger"
        onConfirm={handleRevert}
        onClose={() => setRevertBatch(null)}
      />
    </MainLayout>
  );
}
