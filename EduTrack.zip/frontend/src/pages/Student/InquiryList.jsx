// FILE PATH: frontend/src/pages/Student/InquiryList.jsx
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { admissionInquiryService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { Select, Input, DataTable, RowActions, ACTION_ICONS, ConfirmModal } from "../../components/ui";

const STATUS_STYLES = {
  new: "bg-blue-100 border border-blue-300 text-blue-500",
  contacted: "bg-amber-100 border border-amber-300 text-amber-600",
  enrolled: "bg-green-100 border border-green-300 text-green-500",
  declined: "bg-red-100 border border-red-300 text-red-500",
};

const STATUS_LABELS = { new: "New", contacted: "Contacted", enrolled: "Enrolled", declined: "Declined" };

const fullName = (i) => [i.first_name, i.middle_name, i.last_name].filter(Boolean).join(" ");

function DetailModal({ inquiry, onClose }) {
  if (!inquiry) return null;
  const row = (label, value) => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 py-2 border-b border-gray-100 last:border-0">
      <p className="text-xs text-gray-500 col-span-1">{label}</p>
      <p className="text-sm text-gray-900 col-span-2 break-words">{value || "—"}</p>
    </div>
  );
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded shadow-lg w-full max-w-lg max-h-[90vh] overflow-y-auto text-left" onClick={(e) => e.stopPropagation()}>
        <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-4 border-b border-gray-100">
          <h3 className="text-base font-semibold text-gray-900">Application Details</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">&times;</button>
        </div>
        <div className="px-5 py-2">
          <p className="text-xs text-gray-400 uppercase tracking-wide mt-3 mb-1">Student</p>
          {row("Full Name", fullName(inquiry))}
          {row("Date of Birth", inquiry.date_of_birth)}
          {row("Gender", inquiry.gender ? inquiry.gender.charAt(0).toUpperCase() + inquiry.gender.slice(1) : null)}
          {row("Desired Class", inquiry.desired_class)}

          <p className="text-xs text-gray-400 uppercase tracking-wide mt-4 mb-1">Parent / Guardian</p>
          {row("Name", inquiry.parent_name)}
          {row("Phone", inquiry.phone)}
          {row("Email", inquiry.email)}
          {row("Address", inquiry.address)}

          <p className="text-xs text-gray-400 uppercase tracking-wide mt-4 mb-1">Application</p>
          {row("Reference", inquiry.reference)}
          {row("Status", <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${STATUS_STYLES[inquiry.status]}`}>{STATUS_LABELS[inquiry.status]}</span>)}
          {row("Message", inquiry.message)}
          {row("Staff Notes", inquiry.staff_notes)}
        </div>
      </div>
    </div>
  );
}

export default function InquiryList() {
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();

  const [inquiries, setInquiries] = useState([]);
  const [counts, setCounts] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = usePersistedState("filters", { status: "", search: "" });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 15 });
  const [viewing, setViewing] = useState(null);
  const [declining, setDeclining] = useState(null);

  useEffect(() => { load(); }, [filters, pagination.currentPage]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { loadCounts(); }, []);

  const load = async () => {
    try {
      setLoading(true);
      const res = await admissionInquiryService.list({ ...filters, page: pagination.currentPage, limit: pagination.itemsPerPage });
      if (res.success) { setInquiries(res.data); setPagination((p) => ({ ...p, ...res.pagination })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const loadCounts = async () => {
    try {
      const res = await admissionInquiryService.getCounts();
      if (res.success) setCounts(res.data);
    } catch { /* counts strip just won't render */ }
  };

  const changeStatus = async (inquiry, status) => {
    try {
      const res = await admissionInquiryService.updateStatus(inquiry.id, { status });
      if (res.success) {
        showSuccess(`Marked as ${STATUS_LABELS[status]}`);
        load();
        loadCounts();
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
  };

  const confirmDecline = async () => {
    if (!declining) return;
    await changeStatus(declining, "declined");
    setDeclining(null);
  };

  // Hands the inquiry straight to the real Admission Form, pre-filled —
  // AdmissionForm.jsx reads location.state.prefillInquiry on mount. The
  // inquiry itself gets marked "enrolled" automatically once that form is
  // submitted successfully (see AdmissionForm.jsx), not here — staff may
  // still back out without completing admission.
  const startAdmission = (inquiry) => {
    navigate("/students/admission", {
      state: {
        inquiryId: inquiry.id,
        prefillInquiry: {
          first_name: inquiry.first_name,
          middle_name: inquiry.middle_name || "",
          last_name: inquiry.last_name,
          date_of_birth: inquiry.date_of_birth || "",
          gender: inquiry.gender || "",
          address: inquiry.address || "",
          parent_name: inquiry.parent_name,
          parent_phone: inquiry.phone,
          parent_email: inquiry.email || "",
        },
      },
    });
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="text-left">
          <h1 className="text-xl font-bold text-gray-900">Online Applications</h1>
          <p className="text-sm text-gray-500 mt-0.5">Admission inquiries submitted through the school website</p>
        </div>

        {counts && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {Object.entries(STATUS_LABELS).map(([key, label]) => (
              <button
                key={key}
                onClick={() => { setFilters((f) => ({ ...f, status: f.status === key ? "" : key })); setPagination((p) => ({ ...p, currentPage: 1 })); }}
                className={`text-left border rounded p-3 transition-colors ${filters.status === key ? "border-primary bg-primary/5 ring-1 ring-primary" : "border-gray-200 bg-white hover:border-gray-300"}`}
              >
                <p className="text-xs text-gray-500">{label}</p>
                <p className="text-xl font-bold text-gray-900 mt-0.5">{counts[key] ?? 0}</p>
              </button>
            ))}
          </div>
        )}

        <div className="bg-white p-5 rounded shadow">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              className="md:col-span-2"
              value={filters.search}
              onChange={(e) => { setFilters((f) => ({ ...f, search: e.target.value })); setPagination((p) => ({ ...p, currentPage: 1 })); }}
              placeholder="Search by student, parent, email, phone, or reference…"
            />
            <Select
              value={filters.status}
              onChange={(e) => { setFilters((f) => ({ ...f, status: e.target.value })); setPagination((p) => ({ ...p, currentPage: 1 })); }}
              options={[{ value: "", label: "All Statuses" }, ...Object.entries(STATUS_LABELS).map(([value, label]) => ({ value, label }))]}
            />
          </div>
        </div>

        <DataTable
          columns={[
            {
              key: "no", label: "No.",
              render: (i, idx) => <span className="text-sm">{(pagination.currentPage - 1) * pagination.itemsPerPage + idx + 1}.</span>,
            },
            {
              key: "student", label: "Student",
              render: (i) => (
                <div className="max-w-xs">
                  <p className="text-sm font-medium">{fullName(i)}</p>
                  {/* <p className="text-xs text-gray-500">{i.desired_class || "—"} · Ref: {i.reference}</p> */}
                </div>
              ),
            },
            {
              key: "parent", label: "Parent / Guardian",
              render: (i) => (
                <div className="max-w-xs">
                  <p className="text-sm">{i.parent_name}</p>
                  {/* <p className="text-xs text-gray-500 truncate">{i.phone}{i.email ? ` · ${i.email}` : ""}</p> */}
                </div>
              ),
            },
            { key: "status", label: "Status", render: (i) => <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${STATUS_STYLES[i.status]}`}>{STATUS_LABELS[i.status]}</span> },
            { key: "date", label: "Submitted", render: (i) => <span className="text-sm">{formatDate(i.createdAt)}</span> },
          ]}
          data={inquiries}
          loading={loading}
          emptyMessage="No admission inquiries yet"
          renderActions={(i) => (
            <RowActions
              actions={[
                { label: "View Details", variant: "primary", icon: ACTION_ICONS.view, onClick: () => setViewing(i) },
                { label: "Mark Contacted", variant: "primary", icon: ACTION_ICONS.check, hidden: i.status !== "new", onClick: () => changeStatus(i, "contacted") },
                { label: "Start Admission", variant: "primary", icon: ACTION_ICONS.add, hidden: i.status === "enrolled" || i.status === "declined", onClick: () => startAdmission(i) },
                { label: "Decline", variant: "danger", icon: ACTION_ICONS.remove, hidden: i.status === "enrolled" || i.status === "declined", onClick: () => setDeclining(i) },
              ]}
            />
          )}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      <DetailModal inquiry={viewing} onClose={() => setViewing(null)} />

      <ConfirmModal
        isOpen={!!declining}
        onClose={() => setDeclining(null)}
        onConfirm={confirmDecline}
        title="Decline Application"
        message={declining ? `Decline ${fullName(declining)}'s application? The student will not be admitted through this application.` : ''}
        confirmText="Decline"
        variant="danger"
      />
    </MainLayout>
  );
}