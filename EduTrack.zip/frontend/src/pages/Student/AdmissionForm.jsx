﻿// FILE PATH: frontend/src/pages/Student/AdmissionForm.jsx
import { useState, useEffect } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { studentService, campusService, classService, documentsService, admissionInquiryService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Input, Textarea, Button, DatePicker, ConfirmModal, PhoneInput } from "../../components/ui";
import { COUNTRIES } from "../../constants/countries";

// Kept in sync with the `category` ENUM on the backend StudentDocument model.
export const DOCUMENT_CATEGORIES = [
  { value: "medical_form", label: "Medical Form" },
  { value: "birth_certificate", label: "Birth Certificate" },
  { value: "report_card", label: "Report Card" },
  { value: "immunization_record", label: "Immunization Record" },
  { value: "national_id", label: "National ID" },
  { value: "passport_photo", label: "Passport Photo" },
  { value: "transfer_letter", label: "Transfer Letter" },
  { value: "other", label: "Other" },
];

export default function AdmissionForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { showSuccess, showError, showWarning, showInfo } = useToast();
  const { currentAcademicYear } = useAcademicYear();
  const isEdit = Boolean(id);

  // Tells the admin what really happened with the parent's admission notice —
  // a failed or simulated SMS used to look exactly like a delivered one.
  // `parent` is null when no parent phone/email was entered.
  const announceParentNotice = (parent) => {
    if (!parent) return;
    if (!parent.enabled) { showInfo("The parent admission notice is switched off in Settings → Notifications."); return; }
    if (parent.sms === "failed" || parent.email === "failed") {
      showWarning(`Student admitted, but the parent notice could not be sent: ${(parent.errors || []).join("; ") || "unknown error"}`);
    } else if (parent.sms === "sent" || parent.email === "sent") {
      showSuccess(`Parent notified${parent.sms === "sent" ? " by SMS" : ""}${parent.sms === "sent" && parent.email === "sent" ? " and" : ""}${parent.email === "sent" ? " by email" : ""}.`);
    } else if (parent.sms === "simulated") {
      showWarning("Student admitted, but no SMS gateway is active, so the parent was NOT sent a message. Set one up in Settings → Messages.");
    }
  };

  // Arriving from Students → Online Applications → Start Admission carries
  // the inquiry's details here so staff don't have to re-type them, plus
  // the inquiry's id so it can be marked "enrolled" once this succeeds.
  const prefillInquiry = location.state?.prefillInquiry;
  const inquiryId = location.state?.inquiryId;

  const [loading, setLoading] = useState(false);
  const [fetchingData, setFetchingData] = useState(isEdit);
  const [campuses, setCampuses] = useState([]);
  const [classes, setClasses] = useState([]);
  const [sections, setSections] = useState([]);
  const [formData, setFormData] = useState(() => ({
    first_name: "",
    middle_name: "",
    last_name: "",
    date_of_birth: "",
    gender: "",
    address: "",
    city: "",
    state: "",
    country: "Tanzania",
    postal_code: "",
    campus_id: "",
    admission_date: "",
    admission_number: "",
    class_id: "",
    section_id: "",
    parent_name: "",
    parent_phone: "",
    parent_email: "",
    parent_address: "",
    emergency_contact: "",
    other_notes: "",
    transport_required: "no",
    hostel_required: "no",
    status: "active",
    ...(prefillInquiry || {}),
  }));
  const [documents, setDocuments] = useState([]);
  const [docUploading, setDocUploading] = useState(false);
  const [generatedCredentials, setGeneratedCredentials] = useState(null);
  const [docDeleteTarget, setDocDeleteTarget] = useState(null);

  useEffect(() => {
    fetchCampuses();
    fetchClasses();
    if (isEdit) {
      fetchStudentData();
      fetchDocuments();
    }
  }, [id, currentAcademicYear]);

  const fetchDocuments = async () => {
    try {
      const response = await documentsService.getStudentDocuments(id);
      if (response.success) {
        setDocuments(response.data.map((d) => ({
          localId: d.id,
          id: d.id,
          category: d.category,
          title: d.title || "",
          file_name: d.file_name,
          file_url: d.file_url,
          isNew: false,
        })));
      }
    } catch (err) {
      showError(err.message || "Failed to fetch documents");
    }
  };

  const fetchCampuses = async () => {
    try {
      const response = await campusService.getAll({ limit: 100 });
      if (response.success) setCampuses(response.data);
    } catch (err) {
      showError(err.message || "Failed to fetch campuses");
    }
  };

  const fetchClasses = async () => {
    try {
      // Only THIS year's classes are offered — the same name ("Form I")
      // otherwise appears once per year it has ever existed. When
      // editing an existing student whose current class belongs to a
      // different year, fetchStudentData (below) adds that one class
      // back in so the field still displays correctly.
      const response = await classService.getAll({ limit: 200, status: 'active', academic_year: currentAcademicYear });
      if (response.success) setClasses(response.data);
    } catch (err) {
      showError(err.message || "Failed to fetch classes");
    }
  };

  const fetchSections = async (classId) => {
    if (!classId) { setSections([]); return; }
    try {
      const response = await classService.getById(classId);
      if (response.success) setSections(response.data.sections || []);
    } catch {
      setSections([]);
    }
  };

  const fetchStudentData = async () => {
    try {
      setFetchingData(true);
      const response = await studentService.getById(id);
      if (response.success) {
        const s = response.data;
        setFormData({
          first_name: s.user?.first_name || "",
          middle_name: s.user?.middle_name || "",
          last_name: s.user?.last_name || "",
          date_of_birth: s.date_of_birth ? s.date_of_birth.substring(0, 10) : "",
          gender: s.gender || "",
          address: s.address || "",
          city: s.city || "",
          state: s.state || "",
          country: s.country || "Tanzania",
          postal_code: s.postal_code || "",
          campus_id: s.campus_id || "",
          admission_date: s.admission_date ? s.admission_date.substring(0, 10) : "",
          admission_number: s.admission_number || "",
          class_id: s.class_id || "",
          section_id: s.section_id || "",
          parent_name: s.parent_name || "",
          parent_phone: s.parent_phone || "",
          parent_email: s.parent_email || "",
          parent_address: s.parent_address || "",
          emergency_contact: s.emergency_contact || "",
          other_notes: s.other_notes || "",
          transport_required: s.transport_required ? "yes" : "no",
          hostel_required: s.hostel_required ? "yes" : "no",
          status: s.status || "active",
        });
        // The year-filtered class list (fetchClasses) won't include this
        // student's class if it belongs to a different academic year
        // than the one currently selected — add it back in so the field
        // still shows their real, current class instead of going blank.
        if (s.class) {
          setClasses((prev) => (prev.some((c) => c.id === s.class.id) ? prev : [...prev, s.class]));
        }
      }
    } catch (err) {
      showError(err.message || "Failed to fetch student data");
    } finally {
      setFetchingData(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'class_id') {
      setFormData((prev) => ({ ...prev, class_id: value, section_id: '' }));
      fetchSections(value);
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const addDocumentRow = () => {
    setDocuments((prev) => [...prev, { localId: `tmp_${Date.now()}_${prev.length}`, id: null, category: "other", title: "", file: null, file_name: "", isNew: true }]);
  };

  const updateDocumentField = (localId, field, value) => {
    setDocuments((prev) => prev.map((d) => (d.localId === localId ? { ...d, [field]: value } : d)));
  };

  const handleDocumentFile = async (localId, file) => {
    if (!file) return;
    if (!isEdit) {
      // Student doesn't exist yet — just stage the file, it gets uploaded after creation.
      updateDocumentField(localId, "file", file);
      updateDocumentField(localId, "file_name", file.name);
      return;
    }
    // Edit mode: student already exists, upload right away.
    const row = documents.find((d) => d.localId === localId);
    try {
      setDocUploading(true);
      const response = await documentsService.uploadStudentDocument(id, file, { category: row?.category, title: row?.title });
      if (response.success) {
        setDocuments((prev) => prev.map((d) => (d.localId === localId ? {
          localId: response.data.id, id: response.data.id, category: response.data.category,
          title: response.data.title || "", file_name: response.data.file_name, file_url: response.data.file_url, isNew: false,
        } : d)));
        showSuccess("Document uploaded");
      }
    } catch (err) {
      showError(err.message || "Failed to upload document");
    } finally {
      setDocUploading(false);
    }
  };

  const removeDocumentRow = (localId) => {
    const row = documents.find((d) => d.localId === localId);
    if (!row) return;
    if (row.isNew) {
      setDocuments((prev) => prev.filter((d) => d.localId !== localId));
      return;
    }
    setDocDeleteTarget(row);
  };

  const confirmRemoveDocument = async () => {
    const row = docDeleteTarget;
    if (!row) return;
    try {
      const response = await documentsService.deleteStudentDocument(id, row.id);
      if (response.success) {
        setDocuments((prev) => prev.filter((d) => d.localId !== row.localId));
        showSuccess("Document deleted");
      }
    } catch (err) {
      showError(err.message || "Failed to delete document");
    }
  };

  const uploadStagedDocuments = async (studentId) => {
    const staged = documents.filter((d) => d.isNew && d.file);
    for (const doc of staged) {
      try {
        await documentsService.uploadStudentDocument(studentId, doc.file, { category: doc.category, title: doc.title });
      } catch (err) {
        showError(`Failed to upload "${doc.file_name}": ${err.message || "unknown error"}`);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.first_name.trim()) return showError("First name is required");
    if (!formData.last_name.trim()) return showError("Last name is required");
    if (!formData.gender) return showError("Gender is required");
    if (!formData.date_of_birth) return showError("Date of birth is required");
    if (!formData.campus_id) return showError("Campus is required");
    if (!formData.admission_date) return showError("Admission date is required");
    if (!formData.admission_number.trim()) return showError("Admission number is required");

    try {
      setLoading(true);
      const submitData = { ...formData };
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      if (!submitData.class_id || !uuidRegex.test(submitData.class_id)) delete submitData.class_id;
      if (!submitData.section_id || !uuidRegex.test(submitData.section_id)) delete submitData.section_id;

      const response = isEdit
        ? await studentService.update(id, submitData)
        : await studentService.create(submitData);

      if (response.success) {
        if (!isEdit && inquiryId) {
          // Best-effort — the student is already admitted regardless of
          // whether this succeeds, so it never blocks the main flow.
          admissionInquiryService.updateStatus(inquiryId, { status: 'enrolled' }).catch(() => {});
        }
        if (!isEdit) {
          announceParentNotice(response.notifications?.parent);
          await uploadStagedDocuments(response.data.id);
          if (response.credentials) {
            // Show the auto-generated login once — it can't be retrieved
            // again after this (the password is hashed at rest).
            setGeneratedCredentials({
              email: response.credentials.email,
              password: response.credentials.password,
              studentName: `${formData.first_name} ${formData.last_name}`.trim(),
            });
            setLoading(false);
            return;
          }
        }
        showSuccess(`Student ${isEdit ? "updated" : "admitted"} successfully`);
        navigate("/students");
      }
    } catch (err) {
      showError(err.message || `Failed to ${isEdit ? "update" : "submit"} admission`);
    } finally {
      setLoading(false);
    }
  };

  if (fetchingData) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-sm text-gray-500 mt-2">Loading student data...</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4 text-left">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">
              {isEdit ? "Edit Student" : "Student Admission Form"}
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {isEdit ? "Update student information" : "Fill in details to register a new student"}
            </p>
          </div>
          <Button
            variant="lightPrimary"
            onClick={() => navigate("/students")}
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }
          >
            Back to List
          </Button>
        </div>

        {prefillInquiry && !isEdit && (
          <div className="flex items-start gap-2 bg-primary-5 border border-primary-20 text-sm text-gray-700 rounded px-4 py-3">
            <svg className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p>Pre-filled from an Online Application. Review the details below before submitting.</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="bg-white rounded shadow text-left">
          <div className="px-5 py-4 space-y-7">
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">Personal Information</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input label="First Name" name="first_name" value={formData.first_name} onChange={handleChange} required placeholder="Enter first name" />
                <Input label="Middle Name" name="middle_name" value={formData.middle_name} onChange={handleChange} placeholder="Enter middle name (optional)" />
                <Input label="Last Name" name="last_name" value={formData.last_name} onChange={handleChange} required placeholder="Enter last name" />
                <DatePicker label="Date of Birth" name="date_of_birth" value={formData.date_of_birth} onChange={handleChange} required/>
                <Select
                  label="Gender"
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                  required
                  options={[
                    { value: "", label: "Select gender" },
                    { value: "male", label: "Male" },
                    { value: "female", label: "Female" },
                    { value: "other", label: "Other" },
                  ]}
                />
                <Input label="Emergency Contact" name="emergency_contact" value={formData.emergency_contact} onChange={handleChange} placeholder="Enter emergence contact" />
              </div>
            </div>

            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">Address Information</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input label="Address" name="address" value={formData.address} onChange={handleChange} placeholder="Enter address" />
                <Input label="City" name="city" value={formData.city} onChange={handleChange} placeholder="Enter city" />
                <Select
                  label="Country"
                  name="country"
                  value={formData.country}
                  onChange={handleChange}
                  searchable
                  options={COUNTRIES.map((c) => ({ value: c, label: c }))}
                />
              </div>
            </div>

            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">Academic Information</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Select
                  label="Campus"
                  name="campus_id"
                  value={formData.campus_id}
                  onChange={handleChange}
                  required
                  options={[
                    { value: "", label: "Select campus" },
                    ...campuses.map((c) => ({ value: c.id, label: c.name + " (" + c.code + ")" })),
                  ]}
                />
                <Input label="Admission Number" name="admission_number" value={formData.admission_number} onChange={handleChange} required placeholder="Enter admission number" />
                <DatePicker label="Admission Date" name="admission_date" value={formData.admission_date} onChange={handleChange} required />
                <Select
                  label="Class / Grade"
                  name="class_id"
                  value={formData.class_id}
                  onChange={handleChange}
                  searchable
                  options={[
                    { value: '', label: 'Select class' },
                    ...classes.map((c) => ({ value: c.id, label: c.name })),
                  ]}
                />
                <Select
                  label="Section"
                  name="section_id"
                  value={formData.section_id}
                  onChange={handleChange}
                  disabled={!formData.class_id || sections.length === 0}
                  options={[
                    { value: '', label: sections.length === 0 ? 'Select class first' : 'Select section' },
                    ...sections.map((s) => ({ value: s.id, label: s.name })),
                  ]}
                />
                {isEdit && (
                  <Select
                    label="Status"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    options={[
                      { value: "active", label: "Active" },
                      { value: "inactive", label: "Inactive" },
                      { value: "graduated", label: "Graduated" },
                      { value: "suspended", label: "Suspended" },
                      { value: "expelled", label: "Expelled" },
                    ]}
                  />
                )}
              </div>
            </div>

            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">Parent / Guardian Information</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input label="Parent / Guardian Name" name="parent_name" value={formData.parent_name} onChange={handleChange} placeholder="Enter full name" />
                <PhoneInput label="Parent / Guardian Phone" name="parent_phone" value={formData.parent_phone} onChange={handleChange} />
                <Input label="Parent / Guardian Email" type="email" name="parent_email" value={formData.parent_email} onChange={handleChange} placeholder="Enter email address" />
                <Input label="Parent / Guardian Address" name="parent_address" value={formData.parent_address} onChange={handleChange} placeholder="Enter home address" />
              </div>
            </div>

            <div className="text-left">
              <div className="items-cente mb-2">
                <h2 className="text-md font-semibold text-gray-900">Documents</h2>
                <Button type="button" variant="lightPrimary" onClick={addDocumentRow}>
                  + Add Document
                </Button>
              </div>
              {documents.length === 0 ? (
                <p className="text-sm text-gray-400">No documents attached yet. Click "Add Document" to attach documents such as a birth certificate, medical form, or transfer letter.</p>
              ) : (
                <div className="space-y-3">
                  {documents.map((doc) => (
                    <div key={doc.localId} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 items-end bg-white border border-gray-200 rounded p-3">
                      <Select
                        label="Category"
                        value={doc.category}
                        onChange={(e) => updateDocumentField(doc.localId, "category", e.target.value)}
                        searchable
                        options={DOCUMENT_CATEGORIES}
                      />
                      <Input
                        label="Document Title (optional)"
                        value={doc.title}
                        onChange={(e) => updateDocumentField(doc.localId, "title", e.target.value)}
                        placeholder="e.g., Medical clearance letter"
                      />
                      <div className="text-left">
                        <label className="block text-xs font-medium text-gray-600 mb-1">File</label>
                        {doc.file_name && !doc.file ? (
                          <a href={doc.file_url} target="_blank" rel="noopener noreferrer" className="text-sm text-primary underline break-all">
                            {doc.file_name}
                          </a>
                        ) : (
                          <input
                            type="file"
                            accept=".jpg,.jpeg,.png,.webp,.pdf,.doc,.docx"
                            onChange={(ev) => handleDocumentFile(doc.localId, ev.target.files?.[0])}
                            disabled={docUploading}
                            className="block w-full text-sm text-gray-600 file:mr-3 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-sm file:bg-primary-10 file:text-primary hover:file:opacity-80"
                          />
                        )}
                        {doc.file_name && doc.file && <p className="text-xs text-gray-500 mt-1 truncate">{doc.file_name} (pending upload)</p>}
                      </div>
                      <div className="text-end">
                        <Button type="button" variant="lightDanger" onClick={() => removeDocumentRow(doc.localId)}>
                          Remove
                        </Button>
                      </div>
                    </div>
                  ))}
                  {!isEdit && (
                    <p className="text-xs text-gray-400 mt-2">Files are uploaded once the admission is submitted.</p>
                  )}
                </div>
              )}
            </div>

            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">Additional Options</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Select
                  label="Transport Required"
                  name="transport_required"
                  value={formData.transport_required}
                  onChange={handleChange}
                  options={[{ value: "no", label: "No" }, { value: "yes", label: "Yes" }]}
                />
                <Select
                  label="Hostel Required"
                  name="hostel_required"
                  value={formData.hostel_required}
                  onChange={handleChange}
                  options={[{ value: "no", label: "No" }, { value: "yes", label: "Yes" }]}
                />
              </div>
            </div>
            
            <div className="text-left">
              <div className="grid grid-cols-1 gap-4">
                <Textarea
                  label="Notes"
                  name="other_notes"
                  value={typeof formData.other_notes === "string" ? formData.other_notes : ""}
                  onChange={handleChange}
                  rows={3}
                  placeholder="Add any additional notes or relevant information"
                />
              </div>
            </div>
          </div>

          <div className="bg-gray-50 px-5 py-4 flex items-center justify-end gap-3 rounded-b">
            <Button type="button" variant="secondary" onClick={() => navigate("/students")}>
              Cancel
            </Button>
            <Button type="submit" loading={loading}>
              {isEdit ? "Update Student" : "Submit Admission"}
            </Button>
          </div>
        </form>
      </div>

      {/* Generated credentials modal — shown once right after a new admission succeeds */}
      {generatedCredentials && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-5 text-left">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-primary-10 text-primary flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <h3 className="text-md font-semibold text-gray-900">Student Admitted Successfully</h3>
                <p className="text-xs text-gray-500">{generatedCredentials.studentName}</p>
              </div>
            </div>

            <p className="text-sm text-gray-600 mb-3">
              A login has been generated automatically. Please save or share it with the student/parent —
              it will not be shown again. They can change the password after logging in.
            </p>

            <div className="bg-gray-50 border border-gray-200 rounded p-3 space-y-2 text-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-gray-500">Email</span>
                <span className="font-mono text-gray-900 break-all text-right">{generatedCredentials.email}</span>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-gray-500">Password</span>
                <span className="font-mono text-gray-900">{generatedCredentials.password}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 mt-5">
              <Button
                type="button"
                variant="lightPrimary"
                onClick={() => {
                  const text = `Email: ${generatedCredentials.email}\nPassword: ${generatedCredentials.password}`;
                  if (navigator.clipboard?.writeText) {
                    navigator.clipboard.writeText(text);
                    showSuccess("Credentials copied to clipboard");
                  }
                }}
              >
                Copy
              </Button>
              <Button
                type="button"
                onClick={() => {
                  setGeneratedCredentials(null);
                  showSuccess("Student admitted successfully");
                  navigate("/students");
                }}
              >
                Done
              </Button>
            </div>
          </div>
        </div>
      )}

      <ConfirmModal
        isOpen={!!docDeleteTarget}
        onClose={() => setDocDeleteTarget(null)}
        onConfirm={confirmRemoveDocument}
        title="Delete Document"
        message={docDeleteTarget ? `Are you sure you want to delete "${docDeleteTarget.file_name}"? This cannot be undone.` : ""}
        confirmText="Delete"
        variant="danger"
      />
    </MainLayout>
  );
}