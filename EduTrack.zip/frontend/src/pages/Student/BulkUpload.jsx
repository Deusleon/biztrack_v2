// FILE PATH: frontend/src/pages/Student/BulkUpload.jsx
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { studentService, campusService, classService } from "../../services/api";
import ExcelImportPage from "../../components/ExcelImportPage";
import { downloadBulkUploadTemplate, parseBulkUploadFile } from "../../utils/studentBulkTemplate";

const NOTICE_LABELS = { sent: "Sent", simulated: "Not sent (no gateway)", failed: "Failed", skipped: "No contact / off" };
const NOTICE_ORDER = ["sent", "simulated", "failed", "skipped"];

export default function BulkUpload() {
  const { currentAcademicYear } = useAcademicYear();

  const config = {
    noun: "student", nounPlural: "students", importVerb: "Admit", importedWord: "admitted",
    idKey: "admission_number", idLabel: "Admission No.", detailKey: "class_name", detailLabel: "Class",
    title: "Bulk Student Admission",
    subtitle: "Download the Excel template, fill in your students, then upload it. EduTrack checks every row before anything is saved.",
    backPath: "/students", backLabel: "Back to Students", goToList: "Go to Students List",
    reportName: "EduTrack_Student_Upload",
    templateHelp: 'The template includes a "Reference" sheet listing your school\'s exact Campus and Class names — use those names exactly (case doesn\'t matter) so each row can be matched automatically.',
    downloadTemplate: async () => {
      const [campusRes, classRes] = await Promise.all([
        campusService.getAll({ limit: 100 }),
        classService.getAll({ limit: 300, status: "active", academic_year: currentAcademicYear }),
      ]);
      await downloadBulkUploadTemplate({ campuses: campusRes.success ? campusRes.data : [], classes: classRes.success ? classRes.data : [] });
    },
    parseFile: parseBulkUploadFile,
    preview: (rows) => studentService.bulkPreview({ students: rows, academic_year: currentAcademicYear }),
    importChunk: (rows) => studentService.bulkCreate({ students: rows, academic_year: currentAcademicYear }),
    resultExtra: { header: "Parent Notice", render: (r) => NOTICE_LABELS[r.parent_notification] || "—" },
    resultSummaryExtra: (summary) => summary.created > 0 && (
      <p className="text-sm text-gray-600">
        Parent notices — {NOTICE_ORDER.filter((k) => summary.parent_notifications?.[k]).map((k) => `${summary.parent_notifications[k]} ${NOTICE_LABELS[k].toLowerCase()}`).join(", ") || "none"}
        {summary.parent_notifications?.simulated > 0 && (
          <span className="block text-amber-700 mt-1">No SMS gateway is active, so those parents were not actually messaged. Set one up in Settings → Messages.</span>
        )}
      </p>
    ),
  };

  return <ExcelImportPage config={config} />;
}
