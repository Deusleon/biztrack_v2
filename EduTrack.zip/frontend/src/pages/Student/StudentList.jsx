﻿import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { useAcademicYear } from '../../contexts/AcademicYearContext';
import { studentService, campusService, classService } from '../../services/api';
import { usePersistedState } from '../../hooks/usePersistedState';
import MainLayout from '../../components/MainLayout';
import { Select, Input, DataTable, ConfirmModal, Button, RowActions, ACTION_ICONS } from '../../components/ui';
import Icon from "../../components/ui/Icon";

const LEVEL_LABEL = { primary: 'Standard', o_level: 'Form', a_level: 'Form' };
const GENDER_INITIAL = { male: 'M', female: 'F', other: 'O' };

/** Age in whole years, computed from date_of_birth as of today. Returns
 * null when there's no date of birth on record, so the column can show
 * a clear placeholder instead of a wrong/misleading number. */
const calculateAge = (dateOfBirth) => {
  if (!dateOfBirth) return null;
  const dob = new Date(dateOfBirth);
  if (Number.isNaN(dob.getTime())) return null;
  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const monthDiff = today.getMonth() - dob.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) age -= 1;
  return age;
};

/** For the CURRENT year we have a real class row, so its real name is
 * shown ("Form II A"). For any other year there's no real class row to
 * name (see utils/studentHistory.js on the backend) — just the grade
 * they held that year — so it's rendered as "Form 2" from grade +
 * education_level instead. */
const classLabel = (student) => {
  if (student.class?.name) return `${student.class.name}${student.section ? ` ${student.section.name}` : ''}`;
  if (student.class?.grade) return `${LEVEL_LABEL[student.class.education_level] || ''} ${student.class.grade}`.trim();
  return null;
};

export default function StudentList() {
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { currentAcademicYear } = useAcademicYear();
  const navigate = useNavigate();
  const [students, setStudents] = useState([]);
  // Whole-school head-counts from the server — NOT derived from the page on screen.
  const [headcounts, setHeadcounts] = useState(null);
  const [campuses, setCampuses] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedStudents, setSelectedStudents] = useState([]);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false, action: null, data: null });
  const [filters, setFilters] = usePersistedState('filters', {
    search: '',
    status: '',
    campus_id: '',
    class_id: '',
    gender: '',
    sortBy: 'name',
    sortOrder: 'ASC',
  });
  const [pagination, setPagination] = usePersistedState('pagination', {
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
    itemsPerPage: 10,
  });

  useEffect(() => {
    fetchStudents();
  }, [filters, pagination.currentPage, currentAcademicYear]);

  useEffect(() => {
    fetchCampuses();
  }, []);

  useEffect(() => {
    fetchClasses();
  }, [currentAcademicYear]);

  const fetchClasses = async () => {
    try {
      const response = await classService.getAll({ limit: 300, status: 'active', academic_year: currentAcademicYear });
      if (response.success) setClasses(response.data);
    } catch {}
  };

  const fetchCampuses = async () => {
    try {
      const response = await campusService.getAll({ limit: 100 });
      if (response.success) setCampuses(response.data);
    } catch {}
  };

  const fetchStudents = async () => {
    try {
      setLoading(true);
      const response = await studentService.getAll({
        ...filters,
        academic_year: currentAcademicYear,
        page: pagination.currentPage,
        limit: pagination.itemsPerPage,
      });
      if (response.success) {
        setStudents(response.data);
        if (response.stats) setHeadcounts(response.stats);
        setPagination((p) => ({ ...p, ...response.pagination }));
      }
    } catch (err) {
      showError(err.message || 'Failed to fetch students');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((f) => ({ ...f, [name]: value }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const handleReactivate = async (id) => {
    try {
      await studentService.reactivate(id);
      showSuccess('Student reactivated');
      fetchStudents();
    } catch (err) {
      showError(err.message || 'Failed to reactivate');
    }
  };

  const handleDelete = (id) => {
    setConfirmModal({
      isOpen: true,
      action: 'delete',
      data: id,
      title: 'Deactivate Student',
      message: 'Are you sure you want to deactivate this student? This action can be reversed later.',
      variant: 'danger',
    });
  };

  const confirmDelete = async () => {
    try {
      const response = await studentService.delete(confirmModal.data);
      if (response.success) {
        showSuccess('Student deactivated successfully');
        fetchStudents();
      }
    } catch (err) {
      showError(err.message || 'Failed to deactivate student');
    }
  };

  const handleBulkStatusUpdate = (status) => {
    if (selectedStudents.length === 0) return;
    setConfirmModal({
      isOpen: true,
      action: 'bulkUpdate',
      data: status,
      title: 'Bulk Status Update',
      message: `${status === 'active' ? 'Activate' : 'Deactivate'} ${selectedStudents.length} student(s)?`,
      variant: status === 'active' ? 'success' : 'danger',
    });
  };

  const confirmBulkUpdate = async () => {
    try {
      const response = await studentService.bulkUpdateStatus({
        ids: selectedStudents,
        status: confirmModal.data,
      });
      if (response.success) {
        showSuccess(`${selectedStudents.length} student(s) updated successfully`);
        setSelectedStudents([]);
        fetchStudents();
      }
    } catch (err) {
      showError(err.message || 'Failed to update students');
    }
  };

  const handleConfirm = () => {
    if (confirmModal.action === 'delete') confirmDelete();
    else if (confirmModal.action === 'bulkUpdate') confirmBulkUpdate();
  };

  const handleSelectAll = (e) => setSelectedStudents(e.target.checked ? students.map((s) => s.id) : []);
  const handleSelectOne = (id) => setSelectedStudents((prev) => prev.includes(id) ? prev.filter((sid) => sid !== id) : [...prev, id]);

  const totalStudents = headcounts?.total ?? pagination.totalItems;
  const activeCount = headcounts?.active ?? students.filter((s) => s.status === 'active').length;
  const inactiveCount = headcounts?.inactive ?? students.filter((s) => s.status === 'inactive').length;

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Students Management</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              Manage student records and information — showing each student's class for {currentAcademicYear || "the current year"}.
            </p>
          </div>
          {can("students.create") && (
            <div className="flex items-center gap-2">
              <Button variant="secondary" onClick={() => navigate('/students/bulk-upload')}>Bulk Upload</Button>
              <Button variant="primary" onClick={() => navigate('/students/admission')}>New Admission</Button>
            </div>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Total Students</p>
                <p className="text-2xl text-left font-bold text-primary mt-1">{totalStudents}</p>
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Active</p>
                <p className="text-2xl text-left font-bold text-green-600 mt-1">{activeCount}</p>
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg className="w-8 h-8 text-green-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Inactive</p>
                <p className="text-2xl text-left font-bold text-red-600 mt-1">{inactiveCount}</p>
              </div>
              <div className="bg-red-100 p-3 rounded">
                <svg className="w-8 h-8 text-red-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Campuses</p>
                <p className="text-2xl text-left font-bold text-indigo-600 mt-1">{campuses.length}</p>
              </div>
              <div className="bg-indigo-100 p-3 rounded">
                <svg className="w-8 h-8 text-indigo-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-5 rounded shadow">
          <form onSubmit={(e) => { e.preventDefault(); fetchStudents(); }} className="grid grid-cols-1 md:grid-cols-7 gap-4">
            <div className="md:col-span-2">
              <Input
                label="Search"
                name="search"
                value={filters.search}
                onChange={handleFilterChange}
                placeholder="Search by name, admission number..."
                leftIcon={
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                }
              />
            </div>
            <div>
              <Select
                label="Campus"
                name="campus_id"
                value={filters.campus_id}
                onChange={handleFilterChange}
                options={[
                  { value: '', label: 'All Campuses' },
                  ...campuses.map((c) => ({ value: c.id, label: c.name })),
                ]}
              />
            </div>
            <div>
              <Select
                label="Class"
                name="class_id"
                value={filters.class_id}
                onChange={handleFilterChange}
                options={[
                  { value: '', label: 'All Classes' },
                  ...classes.map((c) => ({ value: c.id, label: c.name })),
                ]}
              />
            </div>
            <div>
              <Select
                label="Status"
                name="status"
                value={filters.status}
                onChange={handleFilterChange}
                options={[
                  { value: '', label: 'All Statuses' },
                  { value: 'active', label: 'Active' },
                  { value: 'inactive', label: 'Inactive' },
                ]}
              />
            </div>
            <div>
              <Select
                label="Gender"
                name="gender"
                value={filters.gender}
                onChange={handleFilterChange}
                options={[
                  { value: '', label: 'All Genders' },
                  { value: 'male', label: 'Male' },
                  { value: 'female', label: 'Female' },
                  { value: 'other', label: 'Other' },
                ]}
              />
            </div>
            <div className="flex items-end">
              <button type="submit" className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90">
                Apply Filters
              </button>
            </div>
          </form>
        </div>

        {/* Bulk Actions */}
        {selectedStudents.length > 0 && (can("students.update") || can("students.delete")) && (
          <div className="bg-white shadow rounded p-4 px-5 flex flex-wrap items-center justify-between gap-2">
            <div className="flex space-x-2">
              {can("students.update") && <Button variant="lightSuccess" onClick={() => handleBulkStatusUpdate('active')}>Activate</Button>}
              {can("students.delete") && <Button variant="lightDanger" onClick={() => handleBulkStatusUpdate('inactive')}>Deactivate</Button>}
            </div>
            <span className="text-sm font-medium text-gray-700">
              {selectedStudents.length} student(s) selected
            </span>
          </div>
        )}

        {/* Data Table */}
        <DataTable
          columns={[
            {
              key: 'name',
              label: 'Student',
              render: (student) => (
                <div>
                  <div className="text-sm font-medium text-gray-900">
                    {[student.user?.first_name, student.user?.middle_name, student.user?.last_name].filter(Boolean).join(' ')}
                  </div>
                </div>
              ),
            },
            {
              key: 'admission_number',
              label: 'Admission No.',
              render: (student) => (
                <span className="text-sm text-gray-700">{student.admission_number}</span>
              ),
            },
            {
              key: 'campus',
              label: 'Campus',
              render: (student) => student.campus?.name || <span className="text-gray-400">N/A</span>,
            },
            {
              key: 'class',
              label: 'Class',
              render: (student) => {
                const label = classLabel(student);
                if (!label) return <span className="text-gray-400">No class set</span>;
                const isProjected = student.historical_view?.source === 'projected';
                return (
                  <span>
                    {label}
                    {isProjected && (
                      <span
                        className="ml-1.5 text-[10px] uppercase tracking-wide text-amber-600 bg-amber-50 border border-amber-200 rounded px-1 py-0.5"
                        title="No promotion record covers this year yet — this grade is estimated from their current class."
                      >
                        estimated
                      </span>
                    )}
                  </span>
                );
              },
            },
            {
              key: 'gender',
              label: 'Gender',
              render: (student) => (
                <span className="text-sm text-gray-600" title={student.gender || ''}>
                  {student.gender ? (GENDER_INITIAL[student.gender] || student.gender.charAt(0).toUpperCase()) : '—'}
                </span>
              ),
            },
            {
              key: 'age',
              label: 'Age',
              render: (student) => {
                const age = calculateAge(student.date_of_birth);
                return <span className="text-sm text-gray-600">{age !== null ? age : '—'}</span>;
              },
            },
            {
              key: 'status',
              label: 'Status',
              render: (student) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${student.status === 'active' ? 'bg-green-100 border border-green-300 text-green-500' : 'bg-red-100 border border-red-300 text-red-500'}`}>
                  {student.status}
                </span>
              ),
            },
          ]}
          data={students}
          loading={loading}
          emptyMessage="No students found"
          selectable={(can("students.update") || can("students.delete"))}
          selectedIds={selectedStudents}
          onSelectAll={handleSelectAll}
          onSelectRow={handleSelectOne}
          renderActions={(student) => (
            <RowActions
              actions={[
                { label: 'View Details', variant: 'primary', icon: ACTION_ICONS.view, hidden: !can("students.update"), onClick: () => navigate(`/students/${student.id}`) },
                { label: 'Edit Student', icon: ACTION_ICONS.edit, hidden: !can("students.update"), onClick: () => navigate(`/students/${student.id}/edit`) },
                { label: 'Deactivate', variant: 'danger', icon: ACTION_ICONS.remove, hidden: !can("students.delete") || student.status !== 'active', onClick: () => handleDelete(student.id) },
                { label: 'Reactivate', variant: 'success', icon: ACTION_ICONS.check, hidden: !can("students.update") || student.status === 'active', onClick: () => handleReactivate(student.id) },
              ]}
            />
          )}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ isOpen: false, action: null, data: null })}
        onConfirm={handleConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
      />
    </MainLayout>
  );
}
