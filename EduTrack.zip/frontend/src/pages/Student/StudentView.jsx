import { useState, useEffect, useCallback, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { studentService, attendanceService, documentsService } from "../../services/api";
import { useCampus } from "../../contexts/CampusContext";
import { exportStudentAttendancePDF, exportStudentAttendanceExcel } from "../../utils/attendanceExport";
import MainLayout from "../../components/MainLayout";
import { ConfirmModal, Button, Select, Input } from "../../components/ui";
import { DOCUMENT_CATEGORIES } from "./AdmissionForm";
import { formatMoney } from "../../utils/money";

const ATTENDANCE_STATUS_COLORS = {
  present: { bg: "bg-green-300", cellBg: "bg-green-100 border border-green-300", light: "bg-green-100 border border-green-300", text: "text-green-600", label: "Present", short: "Present" },
  absent: { bg: "bg-red-300", cellBg: "bg-red-100 border border-red-300", light: "bg-red-100 border border-red-300", text: "text-red-600", label: "Absent", short: "Absent" },
  late: { bg: "bg-yellow-300", cellBg: "bg-yellow-100 border border-yellow-300", light: "bg-yellow-100 border border-yellow-300", text: "text-yellow-600", label: "Late", short: "Late" },
  excused: { bg: "bg-blue-300", cellBg: "bg-blue-100 border border-blue-300", light: "bg-blue-100 border border-blue-300", text: "text-blue-600", label: "Excused", short: "Excused" },
  half_day: { bg: "bg-purple-300", cellBg: "bg-purple-100 border border-purple-300", light: "bg-purple-100 border border-purple-300", text: "text-purple-600", label: "Half Day", short: "Half Day" },
};

const fullName = (user) => [user?.first_name, user?.middle_name, user?.last_name].filter(Boolean).join(" ");

// Matches the shape from GET /students/:id/stats — used as the initial
// (and between-year-switch) state so every `stats.xxx.yyy` access below
// stays safe instead of crashing while a fresh fetch is in flight. All
// zeros just reads as "no data yet for this year" rather than an error.
const EMPTY_STATS = {
  academic_year: null,
  attendance: { total: 0, present: 0, absent: 0, late: 0, excused: 0, half_day: 0, percentage: 0 },
  exams: { total: 0, passed: 0, failed: 0, average: 0 },
  fees: { total: 0, paid: 0, pending: 0, paid_percentage: 0 },
};

export default function StudentView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { currentCampus } = useCampus();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();
  const { currentAcademicYear } = useAcademicYear();
  const [student, setStudent] = useState(null);
  const [stats, setStats] = useState(EMPTY_STATS);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [confirmModal, setConfirmModal] = useState({
    isOpen: false,
    action: null,
  });
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const photoInputRef = useRef(null);

  const now = new Date();
  const [calendarYear, setCalendarYear] = useState(now.getFullYear());
  const [calendarMonth, setCalendarMonth] = useState(now.getMonth()); // 0-indexed

  // The attendance calendar opened on the CURRENT month regardless of the
  // year being viewed, so selecting 2024 showed an empty grid for a month
  // that year never had. Jump to a month inside the selected year instead.
  useEffect(() => {
    // Academic years are written "2025" or "2025-2026" — the first number
    // is the one the calendar needs.
    const startYear = parseInt(String(currentAcademicYear || "").match(/\d{4}/)?.[0], 10);
    if (!startYear || startYear === calendarYear) return;

    setCalendarYear(startYear);
    // Stay on today's month when the selected year IS this year; otherwise
    // open in January, the first month with data to show.
    setCalendarMonth(startYear === now.getFullYear() ? now.getMonth() : 0);
  }, [currentAcademicYear]);
  const [monthAttendance, setMonthAttendance] = useState([]);
  const [yearDownloading, setYearDownloading] = useState(false);
  const [attendanceLoading, setAttendanceLoading] = useState(false);
  const [documents, setDocuments] = useState([]);
  const [documentsLoading, setDocumentsLoading] = useState(false);

  // Re-fetch when the year changes too: the student's class is only
  // correct for the year being viewed, and after a promotion the stored
  // class_id points at the CURRENT year, not the selected one.
  useEffect(() => {
    fetchStudentData();
  }, [id, currentAcademicYear]);

  // Statistics are scoped to ONE academic year (see backend
  // studentController.getStats) — separated from the student's own
  // profile fetch so switching the global year selector refreshes just
  // the stats, without re-fetching name/photo/documents unnecessarily.
  useEffect(() => {
    fetchStats();
  }, [id, currentAcademicYear]);

  const fetchStats = async () => {
    try {
      const statsResponse = await studentService.getStats(id, { academic_year: currentAcademicYear });
      if (statsResponse.success) setStats(statsResponse.data);
    } catch (err) {
      showError(err.message || "Failed to fetch student statistics");
    }
  };

  const fetchDocuments = useCallback(async () => {
    try {
      setDocumentsLoading(true);
      const response = await documentsService.getStudentDocuments(id);
      if (response.success) setDocuments(response.data);
    } catch (err) {
      showError(err.message || "Failed to fetch documents");
    } finally {
      setDocumentsLoading(false);
    }
  }, [id]);

  useEffect(() => {
    if (activeTab === "documents") fetchDocuments();
  }, [activeTab, fetchDocuments]);

  const fetchMonthAttendance = useCallback(async (year, month) => {
    try {
      setAttendanceLoading(true);
      const firstDay = `${year}-${String(month + 1).padStart(2, "0")}-01`;
      const lastDayDate = new Date(year, month + 1, 0);
      const lastDay = `${year}-${String(month + 1).padStart(2, "0")}-${String(lastDayDate.getDate()).padStart(2, "0")}`;
      const response = await attendanceService.getAll({
        student_id: id,
        date_from: firstDay,
        date_to: lastDay,
        limit: 100,
      });
      if (response.success) setMonthAttendance(response.data);
    } catch (err) {
      showError(err.message || "Failed to fetch attendance records");
    } finally {
      setAttendanceLoading(false);
    }
  }, [id]);

  useEffect(() => {
    if (activeTab === "attendance") {
      fetchMonthAttendance(calendarYear, calendarMonth);
    }
  }, [activeTab, calendarYear, calendarMonth, fetchMonthAttendance]);

  const fetchStudentData = async () => {
    try {
      setLoading(true);
      const studentResponse = await studentService.getById(id, { academic_year: currentAcademicYear });

      if (studentResponse.success) {
        setStudent(studentResponse.data);
      }
    } catch (err) {
      showError(err.message || "Failed to fetch student data");
    } finally {
      setLoading(false);
    }
  };

  // The class to SHOW is the one for the selected year. `student.class` is
  // always the current one, so after a promotion it would silently
  // misreport every earlier year.
  const yearClass = student?.historical_class ?? student?.class ?? null;
  const yearSection = student?.historical_section ?? student?.section ?? null;

  const handleDownloadMonthAttendance = async (format) => {
    if (monthAttendance.length === 0) { showError('No attendance records for this month'); return; }
    try {
      const rangeLabel = new Date(calendarYear, calendarMonth, 1).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
      const studentInfo = { name: `${student.user?.first_name || ''} ${student.user?.last_name || ''}`.trim(), admission_number: student.admission_number };
      const filename = `Attendance_${studentInfo.name}_${calendarYear}-${String(calendarMonth + 1).padStart(2, '0')}`.replace(/\s+/g, '_');
      const args = { school: currentCampus, student: studentInfo, rangeLabel, records: monthAttendance, filename };
      if (format === 'pdf') await exportStudentAttendancePDF(args);
      else await exportStudentAttendanceExcel(args);
    } catch (err) {
      showError('Failed to download attendance');
    }
  };

  const handleDownloadYearAttendance = async (format) => {
    try {
      setYearDownloading(true);
      const res = await attendanceService.getAll({
        student_id: id, date_from: `${calendarYear}-01-01`, date_to: `${calendarYear}-12-31`, limit: 2000,
      });
      if (!res.success || (res.data || []).length === 0) { showError('No attendance records found for this year'); return; }
      const studentInfo = { name: `${student.user?.first_name || ''} ${student.user?.last_name || ''}`.trim(), admission_number: student.admission_number };
      const filename = `Attendance_${studentInfo.name}_${calendarYear}`.replace(/\s+/g, '_');
      const args = { school: currentCampus, student: studentInfo, rangeLabel: `Year ${calendarYear}`, records: res.data, filename };
      if (format === 'pdf') await exportStudentAttendancePDF(args);
      else await exportStudentAttendanceExcel(args);
    } catch (err) {
      showError('Failed to download attendance');
    } finally {
      setYearDownloading(false);
    }
  };

  const handleDelete = () => {
    setConfirmModal({
      isOpen: true,
      action: "delete",
      title: "Deactivate Student",
      message:
        "Are you sure you want to deactivate this student? This action can be reversed later.",
      variant: "danger",
    });
  };

  const confirmDelete = async () => {
    try {
      const response = await studentService.delete(id);
      if (response.success) {
        showSuccess("Student deactivated successfully");
        navigate("/students");
      }
    } catch (err) {
      showError(err.message || "Failed to delete student");
    }
  };

  const handleReactivate = async () => {
    try {
      const response = await studentService.reactivate(id);
      if (response.success) {
        showSuccess("Student reactivated successfully");
        fetchStudentData();
      }
    } catch (err) {
      showError(err.message || "Failed to reactivate student");
    }
  };

  // Same as the staff page: the picture is the student's account avatar, so
  // it is also what shows on their ID card and anywhere else a profile
  // picture appears. Only Admin / Principal can change it (the server checks).
  const handlePhotoChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      showError("Please choose a JPG, PNG, or WEBP image");
      if (photoInputRef.current) photoInputRef.current.value = "";
      return;
    }
    try {
      setUploadingPhoto(true);
      const response = await documentsService.uploadStudentPhoto(id, file);
      if (response.success) {
        setStudent((prev) => ({ ...prev, user: { ...prev.user, avatar: response.data.avatar } }));
        showSuccess("Photo imesasishwa (updated)");
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || "Failed to upload photo");
    } finally {
      setUploadingPhoto(false);
      if (photoInputRef.current) photoInputRef.current.value = "";
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-sm text-gray-500 mt-2">Loading student data...</p>
        </div>
      </MainLayout>
    );
  }

  if (!student) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <p className="text-gray-600">Student not found</p>
          <Button
            onClick={() => navigate("/students")}
            className="animate-pulse"
          >
            Back to List
          </Button>
        </div>
      </MainLayout>
    );
  }

  const getStatusColor = (status) => {
    return status === "active"
      ? "bg-green-100 border border-green-300 text-green-500"
      : "bg-red-100 border border-red-300 text-red-500";
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* {student.is_historical_view && (
          <div className={`rounded px-4 py-3 text-sm text-left border ${
            student.enrolled_in_year === false
              ? "bg-gray-50 border-gray-200 text-gray-600"
              : "bg-blue-50 border-blue-200 text-blue-800"
          }`}>
            {student.enrolled_in_year === false ? (
              <>This student has no record for <strong>{student.viewing_academic_year}</strong> — they had not
              joined the school yet, or had already left. Switch the year in the header to see a year they were enrolled.</>
            ) : (
              <>Showing <strong>{student.viewing_academic_year}</strong>. This is a past academic year, so the
              class, attendance and results below are that year&rsquo;s — not the student&rsquo;s current ones.</>
            )}
          </div>
        )} */}

        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">
              Student Information
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              Student Name: {fullName(student.user)}
            </p>
          </div>
          <Button
            variant="lightPrimary"
            onClick={() => navigate("/students")}
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }
          >
            Back to List
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {/* Attendance Rate */}
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Attendance Rate</p>
                <p className={`text-2xl text-left font-bold mt-1 ${stats.attendance.percentage >= 90
                  ? "text-green-600"
                  : stats.attendance.percentage >= 75
                    ? "text-yellow-600"
                    : "text-red-600"
                  }`}>
                  {stats.attendance.total > 0 ? `${stats.attendance.percentage}%` : "0"}
                </p>
                {stats.attendance.total > 0 && (
                  <p className="text-xs text-left text-gray-400 mt-0.5 capitalize">
                    {stats.attendance.present} / {stats.attendance.total} days
                  </p>
                )}
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg className="w-8 h-8 text-green-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
            </div>
          </div>

          {/* Class for the year being viewed — not necessarily the class
              they are in now. */}
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">
                  Class {student.is_historical_view && <span className="text-gray-400">({student.viewing_academic_year})</span>}
                </p>
                <p className="text-xl text-left font-bold text-gray-900 mt-1">
                  {yearClass?.name || (student.enrolled_in_year === false ? "Not enrolled" : "—")}
                </p>
                {yearSection && (
                  <p className="text-xs text-left text-gray-400 mt-0.5">Section: {yearSection.name}</p>
                )}
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
            </div>
          </div>

          {/* Days Present */}
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Days Present</p>
                <p className="text-xl text-left font-bold text-gray-900 mt-1">
                  {stats.attendance.present}
                </p>
                {stats.attendance.absent > 0 && (
                  <p className="text-xs text-left text-red-400 mt-0.5 capitalize">{stats.attendance.absent} absent</p>
                )}
              </div>
              <div className="bg-indigo-100 p-3 rounded">
                <svg className="w-8 h-8 text-indigo-500 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
            </div>
          </div>

          {/* Student Status */}
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-left">
                <p className="text-sm text-left text-gray-600">Student Status</p>
                <p className={`mt-3 px-3 py-0.5 rounded-full text-sm text-left font-semibold inline-block capitalize ${getStatusColor(student.status)}`}>
                  {student.status?.replace("_", " ")}
                </p>
              </div>
              <div className="bg-yellow-100 p-3 rounded">
                <svg className="w-8 h-8 text-yellow-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        {(can("students.update") || can("students.delete")) && (
          <div className="flex items-center gap-3">
            {can("students.update") && <Button variant="lightPrimary" onClick={() => navigate(`/students/${student.id}/edit`)}>
              Edit Student
            </Button>}
            {student.status === "inactive" ? (can("students.update") ? (
              <Button variant="lightSuccess" onClick={handleReactivate}>
                Reactivate
              </Button>
            ) : null) : (can("students.delete") ? (
              <Button variant="lightDanger" onClick={handleDelete}>
                Deactivate
              </Button>
            ) : null)}
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded shadow">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {["overview", "details", "statistics", "attendance", "documents"].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-5 py-3 text-sm font-medium capitalize border-b-2 transition-colors ${activeTab === tab ? "border-primary text-primary" : "border-transparent text-gray-500 hover:text-gray-700"}`}
                >
                  {tab}
                </button>
              ))}
            </nav>
          </div>

          <div className="px-5 py-4 text-left">
            {/* Overview Tab */}
            {activeTab === "overview" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Profile picture — first column, left-aligned so it lines up
                      with the labels in the columns beside it (same as the staff
                      page). Admin / Principal can change it. */}
                  <div className="flex flex-col items-start text-left gap-3">
                    <div className={`relative group ${student.user?.avatar ? "" : "w-3/4"}`}>
                      {student.user?.avatar ? (
                        <img src={student.user.avatar} alt="" className="h-96 w-86 rounded object-cover border border-gray-200" />
                      ) : (
                        <div className="w-86 h-96 rounded bg-primary-15 text-primary flex items-center justify-center text-3xl font-bold border border-gray-200">
                          {(student.user?.first_name?.[0] || "") + (student.user?.last_name?.[0] || "")}
                        </div>
                      )}
                      {can("students.documents") && (
                        <button
                          onClick={() => photoInputRef.current?.click()}
                          disabled={uploadingPhoto}
                          title="Change photo"
                          className="absolute bottom-1 right-1 bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center text-sm shadow hover:opacity-90 disabled:opacity-50"
                        >
                          {uploadingPhoto ? "…" : "✎"}
                        </button>
                      )}
                      <input ref={photoInputRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handlePhotoChange} />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Personal Information
                    </h3>

                    <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                      <p className="text-xs text-gray-600">Full Name</p>
                      <p>:</p>
                      <p className="text-sm font-medium text-gray-900">
                        {fullName(student.user)}
                      </p>
                      <p className="text-xs text-gray-600">Email</p>
                      <p>:</p>
                      <p className="text-sm font-medium text-gray-900">
                        {student.user?.email}
                      </p>
                      {student.user?.phone && (
                        <>
                          <p className="text-xs text-gray-600">Phone</p>
                          <p>:</p>
                          <p className="text-sm font-medium text-gray-900">
                            {student.user.phone}
                          </p>
                        </>
                      )}

                      {student.date_of_birth && (
                        <>
                          <p className="text-xs text-gray-600">Date of Birth</p>
                          <p>:</p>
                          <p className="text-sm font-medium text-gray-900">
                            {formatDate(student.date_of_birth)}
                          </p>
                        </>
                      )}

                      {student.gender && (
                        <>
                          <p className="text-xs text-gray-600">Gender</p>
                          <p>:</p>
                          <p className="text-sm font-medium text-gray-900 capitalize">
                            {student.gender}
                          </p>
                        </>
                      )}

                      {(student.address ||
                        student.city ||
                        student.country) && (
                          <>
                            <p className="text-xs text-gray-600">Address</p>
                            <p>:</p>
                            <p className="text-sm font-medium text-gray-900 capitalize">
                              <span>{student.address} - </span>
                              {[
                                student.city,
                                student.country,
                              ]
                                .filter(Boolean)
                                .join(", ")}
                            </p>
                          </>
                        )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Academic Information
                    </h3>

                    <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                      <p className="text-xs text-gray-600">Admission Number</p>
                      <p>:</p>
                      <p className="text-sm font-medium text-gray-900">
                        {student.admission_number}
                      </p>
                      {student.admission_date && (
                        <>
                          <p className="text-xs text-gray-600">
                            Admission Date
                          </p>
                          <p>:</p>
                          <p className="text-sm font-medium text-gray-900">
                            {formatDate(student.admission_date)}
                          </p>
                        </>
                      )}
                      <p className="text-xs text-gray-600">Campus</p>
                      <p>:</p>
                      <p className="text-sm font-medium text-gray-900">
                        {student.campus?.name || "N/A"}
                      </p>

                      {/* The class for the YEAR BEING VIEWED. This read
                          student.class directly, which is always the current
                          one — so on the Overview tab the class never changed
                          no matter which year was selected. */}
                      <p className="text-xs text-gray-600">Class</p>
                      <p>:</p>
                      <p className="text-sm font-medium text-gray-900">
                        {yearClass
                          ? `${yearClass.name}${yearSection ? ` - ${yearSection.name}` : ""}`
                          : student.enrolled_in_year === false
                            ? `Not enrolled in ${student.viewing_academic_year}`
                            : "N/A"}
                      </p>

                      <p className="text-xs text-gray-600">Status</p>
                      <p>:</p>
                      <p
                        className={`py-0.5 rounded-full text-sm text-center font-medium max-w-20 capitalize ${getStatusColor(student.status)}`}
                      >
                        {student.status}
                      </p>

                      {student.roll_number && (
                        <>
                          <p className="text-xs text-gray-600">Roll Number</p>
                          <p>:</p>
                          <p className="text-sm font-medium text-gray-900">
                            {student.roll_number}
                          </p>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {student.other_notes && (
                  <div className="pt-4 space-y-2 border-t border-gray-200">
                    <h3 className="text-sm font-semibold text-gray-700">
                      Other Notes
                    </h3>
                    <p className="text-sm text-gray-700">
                      {student.other_notes}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Details Tab */}
            {activeTab === "details" && (
              <div className="space-y-6 text-left">
                {/* Parent / Guardian */}
                {(student.parent_name ||
                  student.parent_phone ||
                  student.parent_email) && (
                    <div className="pt-4 space-y-2">
                      <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                        Parent / Guardian
                      </h3>
                      <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                        {student.parent_name && (
                          <>
                            <p className="text-xs text-gray-500">Full Name</p>
                            <p>:</p>
                            <p className="text-sm font-medium text-gray-900">
                              {student.parent_name}
                            </p>
                          </>
                        )}
                        {student.parent_phone && (
                          <>
                            <p className="text-xs text-gray-500">Phone Number</p>
                            <p>:</p>
                            <p className="text-sm font-medium text-gray-900">
                              {student.parent_phone}
                            </p>
                          </>
                        )}
                        {student.parent_email && (
                          <>
                            <p className="text-xs text-gray-500">Email</p>
                            <p>:</p>
                            <p className="text-sm font-medium text-gray-900">
                              {student.parent_email}
                            </p>
                          </>
                        )}
                        {student.parent_address && (
                          <>
                            <p className="text-xs text-gray-500">Address</p>
                            <p>:</p>
                            <p className="text-sm font-medium text-gray-900">
                              {student.parent_address}
                            </p>
                          </>
                        )}
                      </div>
                    </div>
                  )}

                {(student.transport_required || student.hostel_required) && (
                  <div className="pt-4 space-y-2 border-t border-gray-200">
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Additional Options
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {student.transport_required && (
                        <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-blue-100 text-blue-700 border border-blue-200">
                          Transport Required
                        </span>
                      )}
                      {student.hostel_required && (
                        <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-purple-100 text-purple-700 border border-purple-200">
                          Hostel Required
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {student.emergency_contact && (
                  <div className="pt-4 space-y-2 border-t border-gray-200">
                    <h3 className="text-sm font-semibold text-gray-700">
                      Emergency Contact
                    </h3>
                    <p className="text-sm text-gray-700">
                      {student.emergency_contact}
                    </p>
                  </div>
                )}

                {student.other_notes && (
                  <div className="pt-4 space-y-2 border-t border-gray-200">
                    <h3 className="text-sm font-semibold text-gray-700">
                      Notes &amp; Other Information
                    </h3>
                    <p className="text-sm text-gray-700 whitespace-pre-wrap">
                      {student.other_notes}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Statistics Tab */}
            {activeTab === "statistics" && stats && (
              <div className="space-y-6">
                <p className="text-sm text-left text-gray-500 -mt-2">
                  Showing attendance, exam, and fee records for {stats.academic_year || currentAcademicYear}
                  {yearClass?.education_level && (
                    <> — {yearClass.education_level === 'primary' ? 'Standard' : 'Form'} figures reflect their
                      class during that year specifically, not their current one.</>
                  )}
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Attendance Stats */}
                  <div className="bg-primary-10 p-4 rounded">
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-primary-20">
                      Attendance
                    </h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-xs text-gray-600">
                          Total Days:
                        </span>
                        <span className="text-sm font-medium text-gray-900">
                          {stats.attendance.total}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-xs text-gray-600">Present:</span>
                        <span className="text-sm font-medium text-green-600">
                          {stats.attendance.present}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-xs text-gray-600">Absent:</span>
                        <span className="text-sm font-medium text-red-600">
                          {stats.attendance.absent}
                        </span>
                      </div>
                      <div className="flex justify-between pt-2 border-t border-primary-20">
                        <span className="text-xs font-semibold text-gray-700">
                          Percentage:
                        </span>
                        <span className="text-sm font-semibold text-primary">
                          {stats.attendance.percentage}%
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Exam Stats */}
                  <div className="bg-green-50 p-4 rounded">
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-green-200">
                      Exams
                    </h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-xs text-gray-600">
                          Total Exams:
                        </span>
                        <span className="text-sm font-medium text-gray-900">
                          {stats.exams.total}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-xs text-gray-600">Passed:</span>
                        <span className="text-sm font-medium text-green-600">
                          {stats.exams.passed}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-xs text-gray-600">Failed:</span>
                        <span className="text-sm font-medium text-red-600">
                          {stats.exams.failed}
                        </span>
                      </div>
                      <div className="flex justify-between pt-2 border-t border-green-200">
                        <span className="text-xs font-semibold text-gray-700">
                          Average:
                        </span>
                        <span className="text-sm font-semibold text-green-600">
                          {stats.exams.average}%
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Fee Stats */}
                  <div className="bg-yellow-50 p-4 rounded">
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-yellow-200">
                      Fees
                    </h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-xs text-gray-600">
                          Total Fees:
                        </span>
                        <span className="text-sm font-medium text-gray-900">
                          {formatMoney(stats.fees.total)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-xs text-gray-600">Paid:</span>
                        <span className="text-sm font-medium text-green-600">
                          {formatMoney(stats.fees.paid)}
                        </span>
                      </div>
                      {/* <div className="flex justify-between">
                        <span className="text-xs text-gray-600">{stats.fees.pending > 0 ? 'Pending:' : stats.fees.pending < 0 ? 'Overpaid:' : ''}</span>
                        <span className={`text-sm font-medium ${stats.fees.pending > 0 ? 'text-red-600' : stats.fees.pending < 0 ? 'text-blue-600' : 'text-gray-600'}`}>
                          {formatMoney(stats.fees.pending)}
                        </span>
                      </div> */}
                      <div className="flex justify-between">
                        <span className="text-xs text-gray-600">
                          {stats.fees.pending < 0 ? 'Overpaid:' : 'Pending:'}
                        </span>
                        <span
                          className={`text-sm font-medium ${stats.fees.pending > 0
                            ? 'text-red-600'
                            : stats.fees.pending < 0
                              ? 'text-blue-600'
                              : 'text-gray-600'
                            }`}
                        >
                          {formatMoney(Math.abs(Number(stats.fees.pending)))}
                        </span>
                      </div>
                      <div className="flex justify-between pt-2 border-t border-yellow-200">
                        <span className="text-xs text-gray-600">Paid %:</span>
                        <span className="text-sm font-semibold text-yellow-600">
                          {stats.fees.paid_percentage}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white border rounded p-4">
                  <p className="text-sm text-gray-500">
                    Detailed statistics will be populated as attendance, exam,
                    and fee records are added.
                  </p>
                </div>
              </div>
            )}

            {/* Attendance Tab */}
            {activeTab === "attendance" && (
              <AttendanceCalendarTab
                year={calendarYear}
                month={calendarMonth}
                records={monthAttendance}
                loading={attendanceLoading}
                onDownloadMonth={handleDownloadMonthAttendance}
                onDownloadYear={handleDownloadYearAttendance}
                yearDownloading={yearDownloading}
                onPrevMonth={() => {
                  if (calendarMonth === 0) {
                    setCalendarYear((y) => y - 1);
                    setCalendarMonth(11);
                  } else {
                    setCalendarMonth((m) => m - 1);
                  }
                }}
                onNextMonth={() => {
                  if (calendarMonth === 11) {
                    setCalendarYear((y) => y + 1);
                    setCalendarMonth(0);
                  } else {
                    setCalendarMonth((m) => m + 1);
                  }
                }}
              />
            )}

            {/* Documents Tab */}
            {activeTab === "documents" && (
              <DocumentsTab
                studentId={student.id}
                documents={documents}
                loading={documentsLoading}
                canManage={can("students.documents")}
                onUploaded={(doc) => setDocuments((prev) => [doc, ...prev])}
                onDeleted={(docId) => setDocuments((prev) => prev.filter((d) => d.id !== docId))}
                showError={showError}
                showSuccess={showSuccess}
              />
            )}
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ isOpen: false, action: null })}
        onConfirm={confirmDelete}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
      />
    </MainLayout>
  );
}

// ====== Attendance Calendar Tab Component ====================================================

const DAY_HEADERS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

function AttendanceCalendarTab({ year, month, records, loading, onPrevMonth, onNextMonth, onDownloadMonth, onDownloadYear, yearDownloading }) {
  // Build a map of date string → status
  const statusMap = {};
  records.forEach((r) => {
    const dateKey = r.date?.slice(0, 10);
    if (dateKey) statusMap[dateKey] = r.status;
  });

  // Compute calendar grid
  const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0=Sun
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const today = new Date();
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;

  // Summary counts for this month
  const summary = { present: 0, absent: 0, late: 0, excused: 0, half_day: 0 };
  records.forEach((r) => {
    if (r.status in summary) summary[r.status]++;
  });
  const totalMarked = records.length;
  const attendanceRate = totalMarked > 0
    ? Math.round((summary.present / totalMarked) * 100)
    : null;

  // Cells: leading blanks + day numbers
  const cells = [
    ...Array(firstDayOfMonth).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];

  const getDateKey = (day) =>
    `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;

  const getCellStyle = (day) => {
    if (!day) return "";
    const status = statusMap[getDateKey(day)];
    if (status) return ATTENDANCE_STATUS_COLORS[status]?.cellBg || "bg-gray-100";
    const cellDate = new Date(year, month, day);
    if (cellDate > today) return "bg-gray-50";
    return "bg-gray-100";
  };

  const getStatus = (day) => (day ? statusMap[getDateKey(day)] : null);

  const isTodayCell = (day) => {
    return isCurrentMonth && today.getDate() === day;
  };

  return (
    <div className="space-y-5">
      {/* Month Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button
          onClick={onPrevMonth}
          className="p-2 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h3 className="text-base font-semibold text-gray-800">
          {MONTH_NAMES[month]} {year}
        </h3>
        <button
          onClick={onNextMonth}
          className="p-2 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>

      {/* Summary Badges */}
      {!loading && totalMarked > 0 && (
        <div className="flex flex-wrap items-center gap-3">
          {Object.entries(summary)
            .filter(([, count]) => count > 0)
            .map(([status, count]) => {
              const cfg = ATTENDANCE_STATUS_COLORS[status];
              return (
                <span key={status} className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${cfg.light} ${cfg.text}`}>
                  <span className={`w-2 h-2 rounded-full ${cfg.bg}`}></span>
                  {cfg.label}: <span className="font-bold">{count}</span>
                </span>
              );
            })}
          {attendanceRate !== null && (
            <span className="text-sm text-gray-500 font-medium">
              Rate:{" "}
              <span className={`font-bold ${attendanceRate >= 90 ? "text-green-600" : attendanceRate >= 75 ? "text-yellow-600" : "text-red-600"}`}>
                {attendanceRate}%
              </span>
            </span>
          )}
          {/* Downloads */}
          <div className="ml-auto flex flex-wrap items-center gap-2 text-xs">
            <span className="text-gray-700">Download Attendance:</span>
            <Button onClick={() => onDownloadMonth?.('pdf')} variant="outline" size="sm">
              This Month
            </Button>
            {/* <button onClick={() => onDownloadMonth?.('excel')} className="border border-gray-300 rounded px-2.5 py-1 hover:bg-gray-50">This Month (Excel)</button> */}
            <span className="text-gray-300">|</span>
            <Button disabled={yearDownloading} onClick={() => onDownloadYear?.('pdf')} variant="outline" size="sm">
              {yearDownloading ? 'Preparing...' : `Full Year ${year}`}
            </Button>
            {/* <button disabled={yearDownloading} onClick={() => onDownloadYear?.('excel')} className="border border-gray-300 rounded px-2.5 py-1 hover:bg-gray-50 disabled:opacity-50">
          {yearDownloading ? 'Preparing...' : `Full Year ${year} (Excel)`}
        </button> */}
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      ) : (
        <>
          {/* Calendar Grid */}
          <div className="select-none">
            {/* Day headers */}
            <div className="grid grid-cols-7 gap-1 mb-1">
              {DAY_HEADERS.map((d) => (
                <div key={d} className="text-center text-xs font-semibold text-gray-400 py-1">
                  {d}
                </div>
              ))}
            </div>
            {/* Day cells */}
            <div className="grid grid-cols-7 gap-1">
              {cells.map((day, idx) => {
                const status = day ? getStatus(day) : null;
                const cfg = status ? ATTENDANCE_STATUS_COLORS[status] : null;
                return (
                  <div
                    key={idx}
                    className={`
                      h-10 flex flex-col items-center justify-center rounded transition-all
                      ${day ? getCellStyle(day) : ""}
                      ${day && isTodayCell(day) ? "ring-2 ring-offset-1 ring-primary" : ""}
                    `}
                  >
                    {day && (
                      <>
                        <span className={`text-xs leading-none font-medium ${cfg ? cfg.text : "text-gray-400"}`}>
                          {day}
                        </span>
                        {cfg && (
                          <span className={`text-xs leading-none font-semibold capitalize mt-0.5 ${cfg.text}`}>
                            {cfg.short}
                          </span>
                        )}
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-3 pt-2 border-t border-gray-100">
            {Object.entries(ATTENDANCE_STATUS_COLORS).map(([status, cfg]) => (
              <span key={status} className="flex items-center gap-1.5 text-xs text-gray-600">
                <span className={`w-3 h-3 rounded-full ${cfg.bg}`}></span>
                {cfg.label}
              </span>
            ))}
            <span className="flex items-center gap-1.5 text-xs text-gray-600">
              <span className="w-3 h-3 rounded-full bg-gray-300"></span>
              No Record
            </span>
          </div>

          {totalMarked === 0 && (
            <div className="bg-gray-50 border border-gray-200 rounded p-4 text-center">
              <p className="text-sm text-gray-500">No attendance records found for {MONTH_NAMES[month]} {year}.</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ====== Documents Tab Component ================================================================

const CATEGORY_LABEL = Object.fromEntries(DOCUMENT_CATEGORIES.map((c) => [c.value, c.label]));

function DocumentsTab({ studentId, documents, loading, canManage, onUploaded, onDeleted, showError, showSuccess }) {
  const [category, setCategory] = useState("other");
  const [title, setTitle] = useState("");
  const [uploading, setUploading] = useState(false);
  const [deletingId, setDeletingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const fileInputRef = useRef(null);

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      setUploading(true);
      const response = await documentsService.uploadStudentDocument(studentId, file, { category, title });
      if (response.success) {
        onUploaded(response.data);
        setTitle("");
        showSuccess("Document uploaded");
      }
    } catch (err) {
      showError(err.message || "Failed to upload document");
    } finally {
      setUploading(false);
    }
  };

  const confirmDeleteDocument = async () => {
    const doc = deleteTarget;
    if (!doc) return;
    try {
      setDeletingId(doc.id);
      const response = await documentsService.deleteStudentDocument(studentId, doc.id);
      if (response.success) {
        onDeleted(doc.id);
        showSuccess("Document deleted");
      }
    } catch (err) {
      showError(err.message || "Failed to delete document");
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-4 text-left">
      {canManage && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end bg-gray-50 border border-gray-200 rounded p-3">
          <Select label="Category" value={category} onChange={(e) => setCategory(e.target.value)} options={DOCUMENT_CATEGORIES} />
          <Input
            type="text"
            label="Document Title (optional)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., Medical clearance letter"
          />
          <div>
            <input ref={fileInputRef} type="file" accept=".jpg,.jpeg,.png,.webp,.pdf,.doc,.docx" className="hidden" onChange={handleFileSelect} />
            <Button type="button" variant="lightPrimary" onClick={() => fileInputRef.current?.click()} loading={uploading}>
              + Upload Document
            </Button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="py-8 text-center">
          <div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" />
        </div>
      ) : documents.length === 0 ? (
        <p className="text-sm text-gray-400 py-4">No documents attached yet.</p>
      ) : (
        <div className="divide-y divide-gray-100 border border-gray-200 rounded">
          {documents.map((doc) => (
            <div key={doc.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3">
              <div className="min-w-0">
                <p className="text-sm font-medium text-gray-800 truncate">{doc.title || doc.file_name}</p>
                <p className="text-xs text-gray-500">
                  {CATEGORY_LABEL[doc.category] || "Other"} · {doc.file_name}
                  {doc.uploader ? ` · Uploaded by ${doc.uploader.first_name} ${doc.uploader.last_name}` : ""}
                </p>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0 ml-4">
                <a href={doc.file_url} target="_blank" rel="noopener noreferrer" className="text-sm text-primary hover:underline">
                  View
                </a>
                {canManage && (
                  <Button
                    type="button"
                    onClick={() => setDeleteTarget(doc)}
                    disabled={deletingId === doc.id}
                    variant="lightDanger"
                    size="xs"
                  >
                    Delete
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <ConfirmModal
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDeleteDocument}
        title="Delete Document"
        message={deleteTarget ? `Are you sure you want to delete "${deleteTarget.file_name}"? This cannot be undone.` : ""}
        confirmText="Delete"
        variant="danger"
      />
    </div>
  );
}
