import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { useAuth } from "../../contexts/AuthContext";
import { useCampus } from "../../contexts/CampusContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { usePersistedState } from "../../hooks/usePersistedState";
import { useYearAwareClasses } from "../../hooks/useYearAwareClasses";
import { timetableService, staffService, subjectService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Button, NumberInput, DataTable } from "../../components/ui";
import { computeDayGrid } from "./gridUtils";

const EDUCATION_LEVELS = [
  { value: "o_level", label: "O-Level" },
  { value: "a_level", label: "A-Level" },
  { value: "primary", label: "Primary" },
];

const DAYS = [
  { value: "monday", label: "Monday" },
  { value: "tuesday", label: "Tuesday" },
  { value: "wednesday", label: "Wednesday" },
  { value: "thursday", label: "Thursday" },
  { value: "friday", label: "Friday" },
];

const ACTIVITY_PRESETS = ["Cleanliness", "Subject Clubs", "Religion", "Mosque", "Debate", "Sport & Games"];

const DEFAULT_SETTINGS = {
  start_time: "07:30", period_duration: 40, periods_per_day: 8, friday_periods: 4,
  break_after_period: null, break_duration: 20, lunch_after_period: null, lunch_duration: 40,
  daily_activities: {},
};

export default function TimetableSetup() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { currentCampusId } = useCampus();
  const { currentAcademicYear } = useAcademicYear();

  const canManage = can("timetable.update");

  useEffect(() => {
    if (user && !canManage) navigate("/timetable");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const [tab, setTab] = usePersistedState("setupTab", "week");
  const [level, setLevel] = usePersistedState("setupLevel", "o_level");

  // ── School Week tab state ────────────────────────────────────────────
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [loadingSettings, setLoadingSettings] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);
  const [newActivity, setNewActivity] = useState({}); // { [day]: text being typed }

  const loadSettings = useCallback(() => {
    if (!currentCampusId) return;
    setLoadingSettings(true);
    timetableService.getSettings(currentCampusId, level)
      .then((res) => { if (res.success) setSettings(res.data); })
      .catch(() => showError("Failed to load the school week settings"))
      .finally(() => setLoadingSettings(false));
  }, [currentCampusId, level]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { loadSettings(); }, [loadSettings]);

  const updateField = (field, value) => setSettings((s) => ({ ...s, [field]: value }));

  const saveSettings = async () => {
    setSavingSettings(true);
    try {
      const res = await timetableService.updateSettings({
        campus_id: currentCampusId,
        education_level: level,
        start_time: settings.start_time,
        period_duration: Number(settings.period_duration),
        periods_per_day: Number(settings.periods_per_day),
        friday_periods: Number(settings.friday_periods),
        break_after_period: settings.break_after_period ? Number(settings.break_after_period) : null,
        break_duration: Number(settings.break_duration) || 0,
        lunch_after_period: settings.lunch_after_period ? Number(settings.lunch_after_period) : null,
        lunch_duration: Number(settings.lunch_duration) || 0,
        daily_activities: settings.daily_activities || {},
      });
      if (res.success) {
        showSuccess(res.message || "School week saved");
        loadSettings();
      } else {
        showError(res.message || "Could not save the school week");
      }
    } catch (err) {
      showError(err?.response?.data?.message || "Could not save the school week");
    } finally {
      setSavingSettings(false);
    }
  };

  const addActivity = (day, text) => {
    const clean = (text || "").trim();
    if (!clean) return;
    const existing = settings.daily_activities?.[day] || [];
    if (!existing.includes(clean)) {
      updateField("daily_activities", { ...settings.daily_activities, [day]: [...existing, clean] });
    }
    setNewActivity((n) => ({ ...n, [day]: "" }));
  };
  const removeActivity = (day, text) => {
    const existing = settings.daily_activities?.[day] || [];
    updateField("daily_activities", { ...settings.daily_activities, [day]: existing.filter((a) => a !== text) });
  };

  const regularGrid = computeDayGrid(settings, "monday");
  const fridayGrid = computeDayGrid(settings, "friday");

  // ── Class Subjects tab state ─────────────────────────────────────────
  const [selectedClass, setSelectedClass] = usePersistedState("setupSelectedClass", "");
  const classes = useYearAwareClasses({
    selectedClassId: selectedClass,
    onRemap: setSelectedClass,
    extraParams: currentCampusId ? { campus_id: currentCampusId, education_level: level } : { education_level: level },
  });

  const [allSubjects, setAllSubjects] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [rows, setRows] = useState({}); // subject_id -> { checked, periods_per_week, teacher_id }
  const [loadingSubjects, setLoadingSubjects] = useState(false);
  const [savingSubjects, setSavingSubjects] = useState(false);

  useEffect(() => {
    if (!currentCampusId) return;
    subjectService.getAll({ limit: 200, status: "active", campus_id: currentCampusId }).then((res) => { if (res.success) setAllSubjects(res.data); });
    staffService.getAll({ limit: 200, status: "active", role: "teacher" }).then((res) => { if (res.success) setTeachers(res.data); });
  }, [currentCampusId]);

  const classAcademicYear = classes.find((c) => c.id === selectedClass)?.academic_year || currentAcademicYear;

  useEffect(() => {
    if (!selectedClass || !classAcademicYear) { setRows({}); return; }
    setLoadingSubjects(true);
    timetableService.getClassSubjects({ class_id: selectedClass, academic_year: classAcademicYear })
      .then((res) => {
        if (!res.success) return;
        const next = {};
        res.data.forEach((cs) => {
          next[cs.subject_id] = { checked: true, periods_per_week: cs.periods_per_week, teacher_id: cs.teacher_id || "" };
        });
        setRows(next);
      })
      .catch(() => showError("Failed to load subjects for this class"))
      .finally(() => setLoadingSubjects(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedClass, classAcademicYear]);

  const toggleSubject = (subjectId) => {
    setRows((r) => {
      const current = r[subjectId];
      if (current?.checked) return { ...r, [subjectId]: { ...current, checked: false } };
      return { ...r, [subjectId]: { checked: true, periods_per_week: current?.periods_per_week || 2, teacher_id: current?.teacher_id || "" } };
    });
  };
  const setRowField = (subjectId, field, value) => {
    setRows((r) => ({ ...r, [subjectId]: { ...r[subjectId], [field]: value } }));
  };

  const saveClassSubjects = async () => {
    if (!selectedClass) { showError("Pick a class first"); return; }
    setSavingSubjects(true);
    try {
      const subjects = Object.entries(rows)
        .filter(([, v]) => v.checked)
        .map(([subject_id, v]) => ({ subject_id, periods_per_week: Number(v.periods_per_week) || 1, teacher_id: v.teacher_id || null }));
      const res = await timetableService.saveClassSubjects({ class_id: selectedClass, academic_year: classAcademicYear, subjects });
      if (res.success) showSuccess(res.message || "Subjects saved");
      else showError(res.message || "Could not save subjects");
    } catch (err) {
      showError(err?.response?.data?.message || "Could not save subjects");
    } finally {
      setSavingSubjects(false);
    }
  };

  const totalPeriodsPicked = Object.values(rows).filter((r) => r.checked).reduce((sum, r) => sum + (Number(r.periods_per_week) || 0), 0);
  const weeklyCapacity = Number(settings.periods_per_day) * 4 + Number(settings.friday_periods);

  const teacherOptions = [{ value: "", label: "Not assigned yet" }, ...teachers.map((t) => ({ value: t.user?.id || t.id, label: `${t.user?.first_name || t.first_name} ${t.user?.last_name || t.last_name}` }))];

  if (!canManage) return null;

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-xl text-left font-semibold text-gray-900">Timetable — Setup</h1>
            <p className="text-sm text-gray-500">Define the school week, then tell the system what each class studies.</p>
          </div>
          <Button
            variant="lightPrimary"
            onClick={() => navigate("/timetable")}
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to Timetable</Button>
        </div>

        <div className="bg-white rounded shadow p-4 flex flex-wrap items-end gap-4">
          <div className="w-56">
            <Select label="Education Level" options={EDUCATION_LEVELS} value={level} onChange={(e) => setLevel(e.target.value)} />
          </div>
          <p className="text-sm text-gray-500 pb-2.5">Primary, O-Level and A-Level each keep their own school week and subject plans.</p>
        </div>

        <div className="bg-white rounded shadow overflow-x-auto">
          <div className="flex min-w-max">
            {[{ key: "week", label: "School Week" }, { key: "subjects", label: "Class Subjects" }].map((t) => (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`px-5 py-3 text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${tab === t.key ? "border-primary text-primary" : "border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-200"
                  }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white rounded shadow">
          {/* ── School Week ────────────────────────────────────────────── */}
          {tab === "week" && (
            <div className="p-5">
              {loadingSettings ? (
                <div className="py-10 text-center"><div className="inline-block animate-spin rounded-full h-7 w-7 border-b-2 border-primary" /></div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm text-left font-medium text-gray-700 mb-1">Day starts at</label>
                        <input type="time" value={settings.start_time} onChange={(e) => updateField("start_time", e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
                      </div>
                      <NumberInput label="Minutes per period" value={settings.period_duration} onChange={(e) => updateField("period_duration", e.target.value)} min={10} max={180} />
                      <NumberInput label="Periods per day (Mon–Thu)" value={settings.periods_per_day} onChange={(e) => updateField("periods_per_day", e.target.value)} min={1} max={15} />
                      <NumberInput label="Periods on Friday" value={settings.friday_periods} onChange={(e) => updateField("friday_periods", e.target.value)} min={0} max={15} />
                    </div>

                    <div className="border-t border-gray-100 pt-4 grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <NumberInput label="Tea break after period #" helperText="Leave blank for no tea break" value={settings.break_after_period ?? ""} onChange={(e) => updateField("break_after_period", e.target.value || null)} min={0} max={15} />
                      <NumberInput label="Tea break duration (min)" value={settings.break_duration} onChange={(e) => updateField("break_duration", e.target.value)} min={0} max={120} />
                      <NumberInput label="Lunch after period #" helperText="Leave blank for no lunch break" value={settings.lunch_after_period ?? ""} onChange={(e) => updateField("lunch_after_period", e.target.value || null)} min={0} max={15} />
                      <NumberInput label="Lunch duration (min)" value={settings.lunch_duration} onChange={(e) => updateField("lunch_duration", e.target.value)} min={0} max={120} />
                    </div>

                    <div className="border-t border-gray-100 pt-4">
                      <label className="block text-sm text-left font-medium text-gray-700 mb-2">End-of-day activities</label>
                      <div className="space-y-5">
                        {DAYS.map((d) => (
                          <div key={d.value} className="flex items-start gap-2">
                            <span className="text-sm text-left font-medium text-gray-500 w-20 pt-2 flex-shrink-0">{d.label}</span>
                            <div className="flex-1 min-w-0">
                              <div className="flex flex-wrap gap-1.5 mb-1.5">
                                {(settings.daily_activities?.[d.value] || []).map((a) => (
                                  <span key={a} className="inline-flex items-center bg-primary-10 text-primary rounded px-2 py-0.5 text-xs font-medium">
                                    {a}
                                    <button type="button" className="ml-1.5 hover:text-red-600" onClick={() => removeActivity(d.value, a)}>×</button>
                                  </span>
                                ))}
                              </div>
                              <div className="flex flex-col sm:flex-row gap-3">
                                <div className="flex-1 min-w-0">
                                  <Select
                                    placeholder="Pick a common activity…"
                                    searchable
                                    options={ACTIVITY_PRESETS.map((p) => ({ value: p, label: p }))}
                                    value=""
                                    onChange={(e) => addActivity(d.value, e.target.value)}
                                  />
                                </div>
                                <input
                                  value={newActivity[d.value] || ""}
                                  onChange={(e) => setNewActivity((n) => ({ ...n, [d.value]: e.target.value }))}
                                  onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addActivity(d.value, newActivity[d.value]); } }}
                                  placeholder="Or type a custom one…"
                                  className="flex-1 px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                                />
                                <Button size="xs" className="sm:w-1/6" variant="secondary" onClick={() => addActivity(d.value, newActivity[d.value])}>Add</Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="flex justify-end pt-5">
                      <Button variant="primary" loading={savingSettings} onClick={saveSettings}>Save School Week</Button>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-left font-medium text-gray-700 mb-1">Preview — Monday to Thursday</p>
                    <GridPreview slots={regularGrid} />
                    <p className="text-sm text-left font-medium text-gray-700 mt-5 mb-2">Preview — Friday</p>
                    <GridPreview slots={fridayGrid} />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── Class Subjects ─────────────────────────────────────────── */}
          {tab === "subjects" && (
            <div className="p-5 space-y-4">
              <div className="flex flex-wrap items-end gap-3">
                <div className="w-64">
                  <Select
                    label="Class"
                    placeholder="Choose a class"
                    options={classes.map((c) => ({ value: c.id, label: c.name }))}
                    value={selectedClass}
                    onChange={(e) => setSelectedClass(e.target.value)}
                  />
                </div>
                {selectedClass && (
                  <p className="text-sm text-gray-500 pb-2.5">
                    {totalPeriodsPicked} / {weeklyCapacity} periods/week picked
                    {totalPeriodsPicked > weeklyCapacity && <span className="text-red-600 font-medium"> — over this class's weekly capacity</span>}
                  </p>
                )}
              </div>

              {!selectedClass ? (
                <p className="text-sm text-gray-400 py-6 text-center">Pick a class above to configure its subjects.</p>
              ) : allSubjects.length === 0 && !loadingSubjects ? (
                <p className="text-sm text-gray-400 py-6 text-center">No subjects found. Add subjects first in the Subjects section.</p>
              ) : (
                <>
                  <DataTable
                    loading={loadingSubjects}
                    data={allSubjects}
                    rowId="id"
                    emptyMessage="No subjects found."
                    columns={[
                      {
                        key: "checked", label: "", width: "w-10",
                        render: (s) => (
                          <input type="checkbox" checked={!!rows[s.id]?.checked} onChange={() => toggleSubject(s.id)} className="w-4 h-4 accent-primary" />
                        ),
                      },
                      {
                        key: "name", label: "Subject",
                        render: (s) => <span className={rows[s.id]?.checked ? "text-gray-900" : "text-gray-400"}>{s.name} <span className="text-gray-400 text-sm">({s.code})</span></span>,
                      },
                      {
                        key: "periods_per_week", label: "Periods / Week", width: "w-40",
                        render: (s) => (
                          <input
                            type="number" min={1} max={40} disabled={!rows[s.id]?.checked}
                            value={rows[s.id]?.periods_per_week ?? 2}
                            onChange={(e) => setRowField(s.id, "periods_per_week", e.target.value)}
                            className="w-20 px-2 py-1 border border-gray-300 rounded text-sm disabled:bg-gray-100 focus:outline-none focus:ring-1 focus:ring-primary"
                          />
                        ),
                      },
                      {
                        key: "teacher_id", label: "Teacher", width: "w-56",
                        render: (s) => (
                          <select
                            disabled={!rows[s.id]?.checked}
                            value={rows[s.id]?.teacher_id || ""}
                            onChange={(e) => setRowField(s.id, "teacher_id", e.target.value)}
                            className="w-full px-2 py-1.5 border border-gray-300 rounded text-sm disabled:bg-gray-100 focus:outline-none focus:ring-1 focus:ring-primary"
                          >
                            {teacherOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                          </select>
                        ),
                      },
                    ]}
                  />
                  <div className="flex justify-end">
                    <Button variant="primary" loading={savingSubjects} onClick={saveClassSubjects}>Save Subjects</Button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}

function GridPreview({ slots }) {
  if (slots.length === 0) return <p className="text-sm text-gray-400">No periods configured for this day.</p>;
  return (
    <div className="border border-gray-200 rounded divide-y divide-gray-100 text-sm">
      {slots.map((s, i) => (
        <div key={i} className={`flex flex-wrap items-center justify-between gap-2 px-3 py-2 ${s.type !== "period" ? "bg-amber-50 text-amber-700" : "text-gray-700"}`}>
          <span>{s.type === "period" ? `Period ${s.period_number}` : s.label}</span>
          <span className="font-mono">{s.start_time} – {s.end_time}</span>
        </div>
      ))}
    </div>
  );
}
