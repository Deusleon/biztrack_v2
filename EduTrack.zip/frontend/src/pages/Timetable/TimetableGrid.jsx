import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { useAuth } from "../../contexts/AuthContext";
import { useCampus } from "../../contexts/CampusContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { usePersistedState } from "../../hooks/usePersistedState";
import { timetableService, staffService } from "../../services/api";
import { useYearAwareClasses } from "../../hooks/useYearAwareClasses";
import MainLayout from "../../components/MainLayout";
import { Select, Button, ConfirmModal } from "../../components/ui";
import { computeDayGrid } from "./gridUtils";
import { exportClassTimetablePDF } from "../../utils/timetableExport";

const DAYS = [
  { value: "monday", label: "Monday", short: "Mon" },
  { value: "tuesday", label: "Tuesday", short: "Tue" },
  { value: "wednesday", label: "Wednesday", short: "Wed" },
  { value: "thursday", label: "Thursday", short: "Thu" },
  { value: "friday", label: "Friday", short: "Fri" },
];

const EDUCATION_LEVELS = [
  { value: "o_level", label: "O-Level" },
  { value: "a_level", label: "A-Level" },
  { value: "primary", label: "Primary" },
];

const SUBJECT_COLORS = [
  "bg-blue-50 text-blue-700 border-blue-200", "bg-green-50 text-green-700 border-green-200",
  "bg-purple-50 text-purple-700 border-purple-200", "bg-orange-50 text-orange-700 border-orange-200",
  "bg-pink-50 text-pink-700 border-pink-200", "bg-teal-50 text-teal-700 border-teal-200",
  "bg-indigo-50 text-indigo-700 border-indigo-200", "bg-amber-50 text-amber-700 border-amber-200",
];
const colorForSubject = (subjectId) => {
  if (!subjectId) return "bg-white border-gray-200";
  let hash = 0;
  for (let i = 0; i < subjectId.length; i++) hash = (hash * 31 + subjectId.charCodeAt(i)) % SUBJECT_COLORS.length;
  return SUBJECT_COLORS[hash];
};

/** Groups raw TimetableEntry rows by "day-period" for O(1) cell lookups
 * while rendering the grid. */
const indexEntries = (entries) => {
  const map = {};
  for (const e of entries) map[`${e.day}-${e.period_number}`] = e;
  return map;
};

export default function TimetableGrid() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError, showWarning } = useToast();
  const { currentCampusId, currentCampus } = useCampus();
  const { currentAcademicYear } = useAcademicYear();
  const canManage = can("timetable.entry");
  const canManageSetup = can("timetable.update");

  const [mode, setMode] = usePersistedState("mode", "class"); // class | master | teacher
  const [settings, setSettings] = useState(null);
  const [teachers, setTeachers] = useState([]);

  const [selectedClass, setSelectedClass] = usePersistedState("selectedClass", "");
  const [selectedSection, setSelectedSection] = usePersistedState("selectedSection", "");
  const [selectedTeacher, setSelectedTeacher] = usePersistedState("selectedTeacher", "");
  const [masterDay, setMasterDay] = usePersistedState("masterDay", "monday");
  const [masterLevel, setMasterLevel] = usePersistedState("masterLevel", "o_level");

  const [classSubjects, setClassSubjects] = useState([]);
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(false);
  const [autoFilling, setAutoFilling] = useState(false);
  const [regenerating, setRegenerating] = useState(false);
  const [downloadingPdf, setDownloadingPdf] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [confirmRegenerate, setConfirmRegenerate] = useState(false);

  const [editCell, setEditCell] = useState(null); // { day, period_number } | null

  // ── Rearrange mode — fully separate state, so dragging never touches
  // Class View's own data until "Finish" explicitly saves it. ──────────
  const [rearrangeLoading, setRearrangeLoading] = useState(false);
  const [rearrangeLoaded, setRearrangeLoaded] = useState(false);
  const [originalMap, setOriginalMap] = useState({}); // snapshot at load time — the diff base for "Finish"
  const [draftMap, setDraftMap] = useState({}); // "day-period" -> content | undefined, edited by dragging
  const [otherSectionsBusy, setOtherSectionsBusy] = useState(new Set()); // "teacherId-day-period", other sections only
  const [dragFromKey, setDragFromKey] = useState(null);
  const [dragOverKey, setDragOverKey] = useState(null);
  const [finishing, setFinishing] = useState(false);
  const [confirmDiscard, setConfirmDiscard] = useState(false);

  const classes = useYearAwareClasses({
    selectedClassId: selectedClass,
    onRemap: (newClassId) => { setSelectedClass(newClassId); setSelectedSection(""); },
    extraParams: currentCampusId ? { campus_id: currentCampusId } : undefined,
  });

  useEffect(() => {
    if (!currentCampusId) return;
    staffService.getAll({ limit: 200, status: "active", role: "teacher" }).then((res) => { if (res.success) setTeachers(res.data); });
  }, [currentCampusId]);

  const currentClass = classes.find((c) => c.id === selectedClass);
  const sections = currentClass?.sections || [];
  const level = currentClass?.education_level || "o_level";
  const classAcademicYear = currentClass?.academic_year || currentAcademicYear;

  // Keep the section selection valid whenever the class changes.
  useEffect(() => {
    if (sections.length > 0 && !sections.some((s) => s.id === selectedSection)) {
      setSelectedSection(sections[0].id);
    }
    if (sections.length === 0) setSelectedSection("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedClass, sections.length]);

  // Settings for whichever education level the current view needs.
  const settingsLevel = mode === "master" ? masterLevel : level;
  useEffect(() => {
    if (!currentCampusId) return;
    timetableService.getSettings(currentCampusId, settingsLevel).then((res) => { if (res.success) setSettings(res.data); });
  }, [currentCampusId, settingsLevel]);

  // ── Data loading per mode ────────────────────────────────────────────
  const loadClassView = useCallback(() => {
    if (!selectedClass || !selectedSection || !classAcademicYear) { setEntries([]); return; }
    setLoading(true);
    Promise.all([
      timetableService.getClassTimetable({ class_id: selectedClass, section_id: selectedSection, academic_year: classAcademicYear }),
      timetableService.getClassSubjects({ class_id: selectedClass, academic_year: classAcademicYear }),
    ])
      .then(([entriesRes, subjectsRes]) => {
        if (entriesRes.success) setEntries(entriesRes.data);
        if (subjectsRes.success) setClassSubjects(subjectsRes.data);
      })
      .catch(() => showError("Failed to load this class's timetable"))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedClass, selectedSection, classAcademicYear]);

  const loadMasterView = useCallback(() => {
    if (!currentCampusId || !currentAcademicYear) return;
    setLoading(true);
    timetableService.getMasterTimetable({ campus_id: currentCampusId, academic_year: currentAcademicYear, education_level: masterLevel })
      .then((res) => { if (res.success) setEntries(res.data); })
      .catch(() => showError("Failed to load the master timetable"))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentCampusId, currentAcademicYear, masterLevel]);

  const loadTeacherView = useCallback(() => {
    if (!selectedTeacher || !currentAcademicYear) { setEntries([]); return; }
    setLoading(true);
    timetableService.getTeacherTimetable({ teacher_id: selectedTeacher, academic_year: currentAcademicYear })
      .then((res) => { if (res.success) setEntries(res.data); })
      .catch(() => showError("Failed to load this teacher's timetable"))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTeacher, currentAcademicYear]);

  useEffect(() => {
    if (mode === "class") loadClassView();
    else if (mode === "master") loadMasterView();
    else if (mode === "teacher") loadTeacherView();
  }, [mode, loadClassView, loadMasterView, loadTeacherView]);

  // ── Manual edit ───────────────────────────────────────────────────────
  const saveEntry = async ({ subject_id, teacher_id, doublePeriod }) => {
    if (!editCell) return;
    const payloadBase = { class_id: selectedClass, section_id: selectedSection, academic_year: classAcademicYear, day: editCell.day };
    try {
      const first = await timetableService.upsertEntry({ ...payloadBase, period_number: editCell.period_number, subject_id: subject_id || null, teacher_id: teacher_id || null });
      if (!first.success) { showError(first.message || "Could not save this period"); return; }
      if (doublePeriod && subject_id) {
        const second = await timetableService.upsertEntry({ ...payloadBase, period_number: editCell.period_number + 1, subject_id, teacher_id: teacher_id || null });
        if (!second.success) showError(second.message || "Saved this period, but the next one could not be filled");
      }
      showSuccess("Period saved");
      setEditCell(null);
      loadClassView();
    } catch (err) {
      showError(err?.response?.data?.message || "Could not save this period");
    }
  };

  const runAutoFill = async () => {
    if (!selectedClass || !selectedSection) return;
    setAutoFilling(true);
    try {
      const res = await timetableService.autoFill({ class_id: selectedClass, section_id: selectedSection, academic_year: classAcademicYear });
      if (res.success) { showSuccess(res.message); loadClassView(); }
      else showError(res.message || "Auto-Fill failed");
    } catch (err) {
      showError(err?.response?.data?.message || "Auto-Fill failed");
    } finally {
      setAutoFilling(false);
    }
  };

  /** Clears this section's ENTIRE timetable and builds a fresh one from
   * scratch, in one step — for when the current arrangement just isn't
   * working and the user wants the system to try again. Unlike "Auto-Fill
   * Empty Periods" (which only ever touches empty cells), this discards
   * every existing period first, including manual edits — hence the
   * confirmation modal before this ever runs. */
  const runRegenerate = async () => {
    if (!selectedClass || !selectedSection) return;
    setRegenerating(true);
    try {
      const res = await timetableService.autoFill({ class_id: selectedClass, section_id: selectedSection, academic_year: classAcademicYear, regenerate: true });
      if (res.success) { showSuccess(res.message); loadClassView(); }
      else showError(res.message || "Could not regenerate the timetable");
    } catch (err) {
      showError(err?.response?.data?.message || "Could not regenerate the timetable");
    } finally {
      setRegenerating(false);
      setConfirmRegenerate(false);
    }
  };

  const downloadPdf = async () => {
    if (!currentClass || !selectedSection) return;
    setDownloadingPdf(true);
    try {
      const sectionName = sections.find((s) => s.id === selectedSection)?.name || "";
      await exportClassTimetablePDF({
        school: currentCampus, className: currentClass.name, sectionName, academicYear: classAcademicYear,
        grid, entryMap, dailyActivities,
        filename: `${currentClass.name}-${sectionName}-Timetable`.replace(/\s+/g, "-"),
      });
    } catch {
      showError("Could not generate the PDF");
    } finally {
      setDownloadingPdf(false);
    }
  };

  const runClear = async () => {
    try {
      const res = await timetableService.clearClassTimetable({ class_id: selectedClass, section_id: selectedSection, academic_year: classAcademicYear });
      if (res.success) { showSuccess(res.message); loadClassView(); }
      else showError(res.message || "Could not clear the timetable");
    } catch (err) {
      showError(err?.response?.data?.message || "Could not clear the timetable");
    }
  };

  // ── Rearrange: load a fresh draft whenever the class/section/mode
  // changes. Nothing here is written to the server until "Finish". ─────
  const loadRearrangeData = useCallback(() => {
    if (!selectedClass || !selectedSection || !classAcademicYear) return;
    setRearrangeLoading(true);
    setRearrangeLoaded(false);
    Promise.all([
      timetableService.getClassTimetable({ class_id: selectedClass, section_id: selectedSection, academic_year: classAcademicYear }),
      // Same campus/level's OTHER sections — used only to warn about a
      // teacher already being booked elsewhere at a candidate drop time.
      currentCampusId ? timetableService.getMasterTimetable({ campus_id: currentCampusId, academic_year: classAcademicYear, education_level: level }) : Promise.resolve({ success: false }),
    ])
      .then(([ownRes, masterRes]) => {
        if (ownRes.success) {
          const map = indexEntries(ownRes.data);
          setOriginalMap(map);
          setDraftMap(map);
        }
        const busy = new Set();
        if (masterRes.success) {
          masterRes.data.forEach((e) => {
            if (e.teacher_id && e.section_id !== selectedSection) busy.add(`${e.teacher_id}-${e.day}-${e.period_number}`);
          });
        }
        setOtherSectionsBusy(busy);
        setRearrangeLoaded(true);
      })
      .catch(() => showError("Failed to load this class's timetable for rearranging"))
      .finally(() => setRearrangeLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedClass, selectedSection, classAcademicYear, currentCampusId, level]);

  useEffect(() => {
    if (mode === "rearrange") loadRearrangeData();
  }, [mode, loadRearrangeData]);

  const hasUnsavedChanges = JSON.stringify(Object.keys(draftMap).sort().map((k) => [k, draftMap[k]?.subject_id, draftMap[k]?.teacher_id]))
    !== JSON.stringify(Object.keys(originalMap).sort().map((k) => [k, originalMap[k]?.subject_id, originalMap[k]?.teacher_id]));

  /** Swaps whatever is in two cells of the DRAFT (not yet saved). Refuses
   * the swap outright — with a clear reason — if either side's teacher
   * would end up double-booked against an OTHER section's already-saved
   * timetable, exactly the same rule the manual cell editor and Auto-Fill
   * already enforce. */
  const handleDrop = (day, periodNumber) => {
    const toKey = `${day}-${periodNumber}`;
    const fromKey = dragFromKey;
    setDragFromKey(null);
    setDragOverKey(null);
    if (!fromKey || fromKey === toKey) return;

    const [fromDay, fromPeriodStr] = fromKey.split(/-(\d+)$/);
    const fromPeriod = Number(fromPeriodStr);
    const fromContent = draftMap[fromKey];
    const toContent = draftMap[toKey];

    if (fromContent?.teacher_id && otherSectionsBusy.has(`${fromContent.teacher_id}-${day}-${periodNumber}`)) {
      showWarning(`Can't move ${fromContent.subject?.name || "this subject"} here — ${fromContent.teacher?.first_name} ${fromContent.teacher?.last_name} already teaches another section at this time.`);
      return;
    }
    if (toContent?.teacher_id && otherSectionsBusy.has(`${toContent.teacher_id}-${fromDay}-${fromPeriod}`)) {
      showWarning(`Can't move ${toContent.subject?.name || "this subject"} here — ${toContent.teacher?.first_name} ${toContent.teacher?.last_name} already teaches another section at this time.`);
      return;
    }

    setDraftMap((prev) => {
      const next = { ...prev };
      if (toContent) next[fromKey] = toContent; else delete next[fromKey];
      if (fromContent) next[toKey] = fromContent; else delete next[toKey];
      return next;
    });
  };

  /** Sends only the cells that actually changed to the real, already-
   * validated upsertEntry endpoint — one call per changed cell, run
   * sequentially so the server's own conflict check always sees the
   * latest state. Nothing here bypasses that server-side check; dragging
   * only ever prepares what to send. */
  const finishRearrange = async () => {
    const keys = new Set([...Object.keys(originalMap), ...Object.keys(draftMap)]);
    const changed = [...keys].filter((k) => {
      const a = originalMap[k]; const b = draftMap[k];
      return (a?.subject_id || null) !== (b?.subject_id || null) || (a?.teacher_id || null) !== (b?.teacher_id || null);
    });
    if (changed.length === 0) { showSuccess("Nothing to save — no changes made."); return; }

    setFinishing(true);
    let succeeded = 0;
    const failures = [];
    for (const key of changed) {
      const [day, periodStr] = key.split(/-(\d+)$/);
      const content = draftMap[key];
      try {
        const res = await timetableService.upsertEntry({
          class_id: selectedClass, section_id: selectedSection, academic_year: classAcademicYear,
          day, period_number: Number(periodStr), subject_id: content?.subject_id || null, teacher_id: content?.teacher_id || null,
        });
        if (res.success) succeeded++; else failures.push(res.message || `${day} period ${periodStr}`);
      } catch (err) {
        failures.push(err?.response?.data?.message || `${day} period ${periodStr}`);
      }
    }
    setFinishing(false);

    if (failures.length === 0) showSuccess(`Rearranged timetable saved — ${succeeded} period(s) updated.`);
    else showWarning(`Saved ${succeeded} of ${changed.length} changes. Could not save: ${failures.join("; ")}`);

    loadRearrangeData(); // reload from the server so the draft always reflects true saved state
    loadClassView(); // keep Class View's own data in sync too, in case the user switches tabs
  };

  const discardRearrange = () => {
    setDraftMap(originalMap);
    setConfirmDiscard(false);
  };

  const grid = settings ? { regular: computeDayGrid(settings, "monday"), friday: computeDayGrid(settings, "friday") } : { regular: [], friday: [] };
  const entryMap = indexEntries(entries);
  const dailyActivities = settings?.daily_activities || {};

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-xl text-left font-semibold text-gray-900">Timetable</h1>
            <p className="text-sm text-gray-500">View and edit the school's class schedule.</p>
          </div>
          {canManageSetup && <Button variant="primary" onClick={() => navigate("/timetable/setup")}>Setup</Button>}
        </div>

        <div className="bg-white rounded shadow overflow-x-auto">
          <div className="flex min-w-max">
            {[
              { key: "class", label: "Class View" },
              { key: "master", label: "All Classes" },
              { key: "teacher", label: "Teacher View" },
              { key: "rearrange", label: "Rearrange" },
            ].map((m) => (
              <button
                key={m.key}
                onClick={() => setMode(m.key)}
                className={`px-5 py-3 text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
                  mode === m.key ? "border-primary text-primary" : "border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-200"
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* ── Class View ──────────────────────────────────────────────── */}
        {mode === "class" && (
          <>
            <div className="bg-white rounded border border-gray-200 p-4 flex flex-wrap items-end gap-3">
              <div className="w-56">
                <Select label="Class" placeholder="Choose a class" options={classes.map((c) => ({ value: c.id, label: c.name }))} value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)} />
              </div>
              <div className="w-40">
                <Select label="Section" placeholder="Section" options={sections.map((s) => ({ value: s.id, label: s.name }))} value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} disabled={sections.length === 0} />
              </div>
              {canManage && selectedClass && selectedSection && (
                <div className="flex flex-wrap gap-2 ml-auto">
                  <Button variant="secondary" size="sm" loading={downloadingPdf} onClick={downloadPdf} disabled={entries.length === 0}>Download PDF</Button>
                  <Button variant="secondary" size="sm" loading={autoFilling} onClick={runAutoFill}>Auto-Fill Empty Periods</Button>
                  <Button variant="secondary" size="sm" loading={regenerating} onClick={() => setConfirmRegenerate(true)}>Regenerate</Button>
                  <Button variant="lightDanger" size="sm" onClick={() => setConfirmClear(true)}>Clear All</Button>
                </div>
              )}
            </div>

            {!selectedClass || !selectedSection ? (
              <div className="bg-white rounded border border-gray-200 p-10 text-center text-sm text-gray-400">Pick a class and section to view its timetable.</div>
            ) : loading ? (
              <div className="bg-white rounded border border-gray-200 p-10 text-center"><div className="inline-block animate-spin rounded-full h-7 w-7 border-b-2 border-primary" /></div>
            ) : classSubjects.length === 0 ? (
              <div className="bg-amber-50 border border-amber-200 rounded p-4 text-sm text-amber-700">
                This class has no subjects configured yet.{" "}
                {canManageSetup && <button className="underline font-medium" onClick={() => navigate("/timetable/setup")}>Set them up first</button>}
              </div>
            ) : (
              <ClassGrid
                grid={grid} entryMap={entryMap} dailyActivities={dailyActivities} canManage={canManage}
                onCellClick={(day, period_number) => setEditCell({ day, period_number })}
              />
            )}
          </>
        )}

        {/* ── All Classes (Master) ────────────────────────────────────── */}
        {mode === "master" && (
          <>
            <div className="bg-white rounded border border-gray-200 p-4 flex flex-wrap items-end gap-3">
              <div className="w-48">
                <Select label="Education Level" options={EDUCATION_LEVELS} value={masterLevel} onChange={(e) => setMasterLevel(e.target.value)} />
              </div>
              <div className="w-48">
                <Select label="Day" options={DAYS.map((d) => ({ value: d.value, label: d.label }))} value={masterDay} onChange={(e) => setMasterDay(e.target.value)} />
              </div>
            </div>
            {loading ? (
              <div className="bg-white rounded border border-gray-200 p-10 text-center"><div className="inline-block animate-spin rounded-full h-7 w-7 border-b-2 border-primary" /></div>
            ) : (
              <MasterGrid grid={masterDay === "friday" ? grid.friday : grid.regular} day={masterDay} entries={entries} classes={classes.filter((c) => (c.education_level || "o_level") === masterLevel)} dailyActivities={dailyActivities} />
            )}
          </>
        )}

        {/* ── Teacher View ────────────────────────────────────────────── */}
        {mode === "teacher" && (
          <>
            <div className="bg-white rounded border border-gray-200 p-4 flex flex-wrap items-end gap-3">
              <div className="w-64">
                <Select
                  label="Teacher" placeholder="Choose a teacher" searchable
                  options={teachers.map((t) => ({ value: t.user?.id || t.id, label: `${t.user?.first_name || t.first_name} ${t.user?.last_name || t.last_name}` }))}
                  value={selectedTeacher} onChange={(e) => setSelectedTeacher(e.target.value)}
                />
              </div>
            </div>
            {!selectedTeacher ? (
              <div className="bg-white rounded border border-gray-200 p-10 text-center text-sm text-gray-400">Pick a teacher to view their weekly timetable.</div>
            ) : loading ? (
              <div className="bg-white rounded border border-gray-200 p-10 text-center"><div className="inline-block animate-spin rounded-full h-7 w-7 border-b-2 border-primary" /></div>
            ) : (
              <TeacherGrid entries={entries} />
            )}
          </>
        )}

        {/* ── Rearrange — drag periods between slots on a private draft;
             nothing is saved until "Finish". ──────────────────────────── */}
        {mode === "rearrange" && (
          <>
            <div className="bg-white rounded border border-gray-200 p-4 flex flex-wrap items-end gap-3">
              <div className="w-56">
                <Select label="Class" placeholder="Choose a class" options={classes.map((c) => ({ value: c.id, label: c.name }))} value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)} />
              </div>
              <div className="w-40">
                <Select label="Section" placeholder="Section" options={sections.map((s) => ({ value: s.id, label: s.name }))} value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} disabled={sections.length === 0} />
              </div>
              {rearrangeLoaded && (
                <div className="flex gap-2 ml-auto">
                  {hasUnsavedChanges && <span className="self-center text-xs text-amber-600 font-medium mr-1">Unsaved changes</span>}
                  <Button variant="secondary" size="sm" disabled={!hasUnsavedChanges || finishing} onClick={() => setConfirmDiscard(true)}>Discard</Button>
                  <Button variant="primary" size="sm" loading={finishing} disabled={!hasUnsavedChanges} onClick={finishRearrange}>Finish &amp; Save</Button>
                </div>
              )}
            </div>

            {!selectedClass || !selectedSection ? (
              <div className="bg-white rounded border border-gray-200 p-10 text-center text-sm text-gray-400">Pick a class and section to rearrange its timetable.</div>
            ) : rearrangeLoading ? (
              <div className="bg-white rounded border border-gray-200 p-10 text-center"><div className="inline-block animate-spin rounded-full h-7 w-7 border-b-2 border-primary" /></div>
            ) : (
              <>
                <div className="bg-white border border-gray-200 rounded p-3 text-sm text-left text-gray-400">
                  Drag a period onto another period to swap them. Moves that would double-book a teacher who also teaches another section are blocked automatically. Nothing is saved until you click <strong>Finish &amp; Save</strong>.
                </div>
                <RearrangeGrid
                  grid={grid} draftMap={draftMap} dragFromKey={dragFromKey} dragOverKey={dragOverKey}
                  onDragStart={setDragFromKey} onDragOver={setDragOverKey} onDrop={handleDrop}
                />
              </>
            )}
          </>
        )}
      </div>

      {editCell && (
        <CellEditor
          editCell={editCell}
          classSubjects={classSubjects}
          currentEntry={entryMap[`${editCell.day}-${editCell.period_number}`]}
          onClose={() => setEditCell(null)}
          onSave={saveEntry}
        />
      )}

      <ConfirmModal
        isOpen={confirmClear}
        title="Clear Timetable"
        message={`Remove every period for ${currentClass?.name || "this class"} ${sections.find((s) => s.id === selectedSection)?.name || ""}? This cannot be undone.`}
        confirmText="Clear it"
        variant="danger"
        onConfirm={runClear}
        onClose={() => setConfirmClear(false)}
      />

      <ConfirmModal
        isOpen={confirmRegenerate}
        title="Regenerate Timetable"
        message={`Build a brand new arrangement for ${currentClass?.name || "this class"} ${sections.find((s) => s.id === selectedSection)?.name || ""}? This replaces every period — including any manual edits — with a fresh auto-generated layout.`}
        confirmText="Regenerate"
        variant="danger"
        onConfirm={runRegenerate}
        onClose={() => setConfirmRegenerate(false)}
      />

      <ConfirmModal
        isOpen={confirmDiscard}
        title="Discard Changes"
        message="Throw away your dragged changes and go back to the currently saved timetable?"
        confirmText="Discard"
        variant="danger"
        onConfirm={discardRearrange}
        onClose={() => setConfirmDiscard(false)}
      />
    </MainLayout>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Class View grid — one section, days as columns, periods as rows.
// ═══════════════════════════════════════════════════════════════════════
function ClassGrid({ grid, entryMap, dailyActivities, canManage, onCellClick }) {
  const maxRows = Math.max(grid.regular.length, grid.friday.length);
  const hasActivities = Object.keys(dailyActivities).some((d) => (dailyActivities[d] || []).length > 0);
  return (
    <div className="bg-white rounded border border-gray-200 overflow-x-auto">
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className="bg-gray-50">
            <th className="text-left px-3 py-2 text-xs font-medium text-gray-500 uppercase w-28">Time</th>
            {DAYS.map((d) => <th key={d.value} className="text-left px-3 py-2 text-xs font-medium text-gray-500 uppercase">{d.label}</th>)}
          </tr>
        </thead>
        <tbody>
          {Array.from({ length: maxRows }).map((_, rowIdx) => {
            // Each day may have its own break placement (Friday especially,
            // being a shorter day), so the shared Time column reflects the
            // common Monday–Thursday reference, while each day's own cell
            // still shows ITS OWN exact time — the two only diverge on
            // Friday when its shorter day skips a break/lunch the other
            // days have.
            const refSlot = grid.regular[rowIdx] || grid.friday[rowIdx];
            return (
              <tr key={rowIdx} className="border-t border-gray-100">
                <td className="px-3 py-1.5 text-xs text-gray-500 font-mono align-top whitespace-nowrap">
                  {refSlot ? `${refSlot.start_time}–${refSlot.end_time}` : ""}
                </td>
                {DAYS.map((d) => {
                  const slots = d.value === "friday" ? grid.friday : grid.regular;
                  const slot = slots[rowIdx];
                  if (!slot) return <td key={d.value} className="px-1 py-1"></td>;
                  if (slot.type !== "period") {
                    return (
                      <td key={d.value} className="px-1 py-1">
                        <div className="bg-amber-50 border border-amber-100 text-amber-700 text-xs rounded px-2 py-2 text-center">
                          <div className="font-medium">{slot.label}</div>
                          <div className="text-[10px] opacity-75 font-mono">{slot.start_time}–{slot.end_time}</div>
                        </div>
                      </td>
                    );
                  }
                  const entry = entryMap[`${d.value}-${slot.period_number}`];
                  return (
                    <td key={d.value} className="px-1 py-1">
                      <button
                        disabled={!canManage}
                        onClick={() => onCellClick(d.value, slot.period_number)}
                        className={`w-full text-left border rounded px-2 py-2 text-xs transition-colors ${colorForSubject(entry?.subject_id)} ${canManage ? "hover:brightness-95 cursor-pointer" : "cursor-default"}`}
                      >
                        {entry?.subject ? (
                          <>
                            <div className="font-semibold truncate">{entry.subject.name}</div>
                            {entry.teacher && <div className="truncate opacity-75">{entry.teacher.first_name} {entry.teacher.last_name}</div>}
                            <div className="text-[10px] opacity-60 font-mono mt-0.5">{slot.start_time}–{slot.end_time}</div>
                          </>
                        ) : (
                          <>
                            <div className="text-gray-400 font-medium">FREE</div>
                            <div className="text-[10px] text-gray-300 font-mono mt-0.5">{slot.start_time}–{slot.end_time}</div>
                          </>
                        )}
                      </button>
                    </td>
                  );
                })}
              </tr>
            );
          })}
          {hasActivities && (
            <tr className="border-t-2 border-gray-200 bg-gray-50">
              <td className="px-3 py-2 text-xs font-medium text-gray-500 align-top">Activities</td>
              {DAYS.map((d) => {
                const acts = dailyActivities[d.value] || [];
                const dayGrid = d.value === "friday" ? grid.friday : grid.regular;
                const lastSlot = dayGrid[dayGrid.length - 1];
                return (
                  <td key={d.value} className="px-2 py-2 align-top">
                    {acts.length === 0 ? (
                      <span className="text-xs text-gray-300">—</span>
                    ) : (
                      <>
                        {acts.map((a) => (
                          <div key={a} className="text-xs text-gray-600 truncate">{a}</div>
                        ))}
                        {lastSlot && <div className="text-[10px] text-gray-400 font-mono mt-0.5">From {lastSlot.end_time}</div>}
                      </>
                    )}
                  </td>
                );
              })}
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Rearrange grid — a private draft of one section's week, laid out just
// like ClassGrid, but every period cell is drag-and-drop capable. Fully
// separate from ClassGrid on purpose: it only ever reads/writes the
// draft passed in via props, never touching the real `entries` state, so
// nothing here can affect the normal Class View grid.
// ═══════════════════════════════════════════════════════════════════════
function RearrangeGrid({ grid, draftMap, dragFromKey, dragOverKey, onDragStart, onDragOver, onDrop }) {
  const maxRows = Math.max(grid.regular.length, grid.friday.length);
  return (
    <div className="bg-white rounded border border-gray-200 overflow-x-auto">
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className="bg-gray-50">
            <th className="text-left px-3 py-2 text-xs font-medium text-gray-500 uppercase w-28">Time</th>
            {DAYS.map((d) => <th key={d.value} className="text-left px-3 py-2 text-xs font-medium text-gray-500 uppercase">{d.label}</th>)}
          </tr>
        </thead>
        <tbody>
          {Array.from({ length: maxRows }).map((_, rowIdx) => {
            const refSlot = grid.regular[rowIdx] || grid.friday[rowIdx];
            return (
              <tr key={rowIdx} className="border-t border-gray-100">
                <td className="px-3 py-1.5 text-xs text-gray-500 font-mono align-top whitespace-nowrap">
                  {refSlot ? `${refSlot.start_time}–${refSlot.end_time}` : ""}
                </td>
                {DAYS.map((d) => {
                  const slots = d.value === "friday" ? grid.friday : grid.regular;
                  const slot = slots[rowIdx];
                  if (!slot) return <td key={d.value} className="px-1 py-1"></td>;
                  if (slot.type !== "period") {
                    return (
                      <td key={d.value} className="px-1 py-1">
                        <div className="bg-amber-50 border border-amber-100 text-amber-700 text-xs rounded px-2 py-2 text-center">
                          <div className="font-medium">{slot.label}</div>
                          <div className="text-[10px] opacity-75 font-mono">{slot.start_time}–{slot.end_time}</div>
                        </div>
                      </td>
                    );
                  }
                  const key = `${d.value}-${slot.period_number}`;
                  const content = draftMap[key];
                  const isDragging = dragFromKey === key;
                  const isDragOver = dragOverKey === key && dragFromKey !== key;
                  return (
                    <td key={d.value} className="px-1 py-1">
                      <div
                        draggable
                        onDragStart={() => onDragStart(key)}
                        onDragOver={(e) => { e.preventDefault(); if (dragOverKey !== key) onDragOver(key); }}
                        onDragLeave={() => { if (dragOverKey === key) onDragOver(null); }}
                        onDrop={(e) => { e.preventDefault(); onDrop(d.value, slot.period_number); }}
                        onDragEnd={() => { onDragStart(null); onDragOver(null); }}
                        className={`w-full text-left border rounded px-2 py-2 text-xs cursor-move select-none transition-all ${colorForSubject(content?.subject_id)} ${isDragging ? "opacity-40" : ""} ${isDragOver ? "ring-2 ring-primary ring-offset-1" : ""}`}
                      >
                        {content?.subject ? (
                          <>
                            <div className="font-semibold truncate">{content.subject.name}</div>
                            {content.teacher && <div className="truncate opacity-75">{content.teacher.first_name} {content.teacher.last_name}</div>}
                          </>
                        ) : (
                          <div className="text-gray-400 font-medium">FREE</div>
                        )}
                      </div>
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// All Classes (master) grid — one day, every class's section as a column.
// ═══════════════════════════════════════════════════════════════════════
function MasterGrid({ grid, day, entries, classes, dailyActivities }) {
  const dayEntries = entries.filter((e) => e.day === day);
  // One column per (class, section) actually present on this day's entries
  // OR configured in `classes` — build columns from classes' sections so
  // empty sections still show up as blank columns rather than vanishing.
  const columns = [];
  for (const c of classes) {
    for (const s of c.sections || []) columns.push({ classId: c.id, className: c.name, sectionId: s.id, sectionName: s.name });
  }
  if (columns.length === 0) {
    return <div className="bg-white rounded border border-gray-200 p-10 text-center text-sm text-gray-400">No classes found for this education level.</div>;
  }
  const periods = grid.filter((s) => s.type === "period");
  const activitiesToday = dailyActivities?.[day] || [];

  return (
    <div className="bg-white rounded border border-gray-200 overflow-x-auto">
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className="bg-gray-50">
            <th className="text-left px-3 py-2 text-xs font-medium text-gray-500 uppercase w-24">Period</th>
            {columns.map((c) => (
              <th key={c.sectionId} className="text-left px-3 py-2 text-xs font-medium text-gray-500 uppercase whitespace-nowrap">{c.className} {c.sectionName}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {periods.map((p) => (
            <tr key={p.period_number} className="border-t border-gray-100">
              <td className="px-3 py-1.5 text-xs text-gray-500 font-mono whitespace-nowrap">P{p.period_number}<br /><span className="text-gray-400">{p.start_time}–{p.end_time}</span></td>
              {columns.map((c) => {
                const entry = dayEntries.find((e) => e.section_id === c.sectionId && e.period_number === p.period_number);
                return (
                  <td key={c.sectionId} className="px-1 py-1">
                    <div className={`border rounded px-2 py-1.5 text-xs ${colorForSubject(entry?.subject_id)}`}>
                      {entry?.subject ? (
                        <>
                          <div className="font-medium truncate">{entry.subject.name}</div>
                          {entry.teacher && <div className="truncate opacity-75 text-[11px]">{entry.teacher.first_name} {entry.teacher.last_name}</div>}
                        </>
                      ) : <span className="text-gray-400 font-medium">FREE</span>}
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
          {activitiesToday.length > 0 && (
            <tr className="border-t-2 border-gray-200 bg-amber-50">
              <td className="px-3 py-2 text-xs font-medium text-amber-700">Activity</td>
              <td colSpan={columns.length} className="px-3 py-2 text-xs text-amber-700">
                {activitiesToday.join(", ")}
                {grid.length > 0 && <span className="ml-2 font-mono text-[11px] opacity-75">From {grid[grid.length - 1].end_time}</span>}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Teacher View grid — one teacher's full week across every class.
// ═══════════════════════════════════════════════════════════════════════
function TeacherGrid({ entries }) {
  const periods = [...new Set(entries.map((e) => e.period_number))].sort((a, b) => a - b);
  if (entries.length === 0) {
    return <div className="bg-white rounded border border-gray-200 p-10 text-center text-sm text-gray-400">No periods assigned to this teacher yet.</div>;
  }
  return (
    <div className="bg-white rounded border border-gray-200 overflow-x-auto">
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className="bg-gray-50">
            <th className="text-left px-3 py-2 text-xs font-medium text-gray-500 uppercase w-20">Period</th>
            {DAYS.map((d) => <th key={d.value} className="text-left px-3 py-2 text-xs font-medium text-gray-500 uppercase">{d.label}</th>)}
          </tr>
        </thead>
        <tbody>
          {periods.map((p) => (
            <tr key={p} className="border-t border-gray-100">
              <td className="px-3 py-1.5 text-xs text-gray-500 font-mono">P{p}</td>
              {DAYS.map((d) => {
                const entry = entries.find((e) => e.day === d.value && e.period_number === p);
                return (
                  <td key={d.value} className="px-1 py-1">
                    {entry ? (
                      <div className={`border rounded px-2 py-1.5 text-xs ${colorForSubject(entry.subject_id)}`}>
                        <div className="font-medium truncate">{entry.subject?.name}</div>
                        <div className="truncate opacity-75 text-[11px]">{entry.class?.name} {entry.section?.name}</div>
                      </div>
                    ) : <div className="text-gray-400 text-xs font-medium text-center py-1.5">FREE</div>}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Cell editor — pick a subject (only from this class's configured
// subjects), optionally a teacher (defaults to that subject's assigned
// teacher), and optionally a double period.
// ═══════════════════════════════════════════════════════════════════════
function CellEditor({ editCell, classSubjects, currentEntry, onClose, onSave }) {
  const [subjectId, setSubjectId] = useState(currentEntry?.subject_id || "");
  const [teacherId, setTeacherId] = useState(currentEntry?.teacher_id || "");
  const [doublePeriod, setDoublePeriod] = useState(false);
  const [saving, setSaving] = useState(false);

  const subjectOptions = [{ value: "", label: "— Empty period —" }, ...classSubjects.map((cs) => ({ value: cs.subject_id, label: cs.subject?.name || "Subject" }))];
  const selectedClassSubject = classSubjects.find((cs) => cs.subject_id === subjectId);
  const teacherOptions = [
    { value: "", label: selectedClassSubject?.teacher ? `Default: ${selectedClassSubject.teacher.first_name} ${selectedClassSubject.teacher.last_name}` : "No teacher" },
    ...classSubjects
      .filter((cs) => cs.teacher)
      .filter((cs, i, arr) => arr.findIndex((x) => x.teacher_id === cs.teacher_id) === i)
      .map((cs) => ({ value: cs.teacher_id, label: `${cs.teacher.first_name} ${cs.teacher.last_name}` })),
  ];

  const handleSubjectChange = (val) => {
    setSubjectId(val);
    const cs = classSubjects.find((c) => c.subject_id === val);
    setTeacherId(cs?.teacher_id || "");
  };

  const handleSave = async () => {
    setSaving(true);
    await onSave({ subject_id: subjectId || null, teacher_id: teacherId || null, doublePeriod });
    setSaving(false);
  };

  const dayLabel = DAYS.find((d) => d.value === editCell.day)?.label;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded shadow-xl w-full max-w-sm">
        <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-base font-semibold">{dayLabel} — Period {editCell.period_number}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="px-5 py-4 space-y-4">
          <Select label="Subject" options={subjectOptions} value={subjectId} onChange={(e) => handleSubjectChange(e.target.value)} />
          {subjectId && <Select label="Teacher" options={teacherOptions} value={teacherId} onChange={(e) => setTeacherId(e.target.value)} />}
          {subjectId && (
            <label className="flex items-center gap-2 text-sm text-gray-700">
              <input type="checkbox" checked={doublePeriod} onChange={(e) => setDoublePeriod(e.target.checked)} className="w-4 h-4 accent-primary" />
              Double period (also fill Period {editCell.period_number + 1})
            </label>
          )}
          <div className="flex justify-end gap-3 pt-1">
            <Button loading={saving} onClick={handleSave}>Save</Button>
            <Button variant="secondary" onClick={onClose}>Cancel</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
