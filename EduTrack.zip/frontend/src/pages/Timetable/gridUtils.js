// Mirrors backend/src/controllers/timetableController.js's computeDayGrid()
// exactly, so both Timetable pages can render/preview the period grid
// instantly from a TimetableSettings row without a server round-trip.

const parseTime = (hhmm) => {
  const [h, m] = String(hhmm || "07:30").split(":").map(Number);
  return h * 60 + m;
};

const formatTime = (mins) => {
  const wrapped = ((mins % 1440) + 1440) % 1440;
  const h = Math.floor(wrapped / 60);
  const m = wrapped % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
};

export const computeDayGrid = (settings, day) => {
  const periodsCount = day === "friday" ? settings.friday_periods : settings.periods_per_day;
  const slots = [];
  let cursor = parseTime(settings.start_time);
  for (let p = 1; p <= periodsCount; p++) {
    const start = cursor;
    cursor += Number(settings.period_duration) || 0;
    slots.push({ type: "period", period_number: p, start_time: formatTime(start), end_time: formatTime(cursor) });
    if (Number(settings.break_after_period) === p && settings.break_duration) {
      const bStart = cursor;
      cursor += Number(settings.break_duration) || 0;
      slots.push({ type: "break", label: "Break", start_time: formatTime(bStart), end_time: formatTime(cursor) });
    }
    if (Number(settings.lunch_after_period) === p && settings.lunch_duration) {
      const lStart = cursor;
      cursor += Number(settings.lunch_duration) || 0;
      slots.push({ type: "lunch", label: "Lunch", start_time: formatTime(lStart), end_time: formatTime(cursor) });
    }
  }
  return slots;
};
