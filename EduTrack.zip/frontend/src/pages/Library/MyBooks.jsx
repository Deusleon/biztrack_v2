import { useState, useEffect } from "react";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { libraryService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { formatMoneyOrDash as formatMoney } from "../../utils/money";

const STATUS_STYLES = {
  issued: "bg-blue-100 text-blue-700", overdue: "bg-red-100 text-red-700",
  returned: "bg-green-100 text-green-700", lost: "bg-gray-100 text-gray-600",
};


export default function MyBooks() {
  const { showError } = useToast();
  const { formatDate } = usePreferences();
  const [loans, setLoans] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    libraryService.getMyBooks()
      .then((res) => { if (res.success) setLoans(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, []);

  const current = loans.filter((l) => l.status === "issued" || l.status === "overdue");
  const history = loans.filter((l) => l.status === "returned" || l.status === "lost");

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="text-left">
          <h1 className="text-xl font-bold text-gray-900">My Books</h1>
          <p className="text-sm text-gray-500 mt-0.5">Library books currently or previously borrowed</p>
        </div>

        {loading ? (
          <div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
        ) : (
          <>
            <div className="bg-white rounded shadow overflow-hidden">
              <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
                <p className="text-sm font-semibold text-gray-700">Currently Borrowed ({current.length})</p>
              </div>
              {current.length === 0 ? (
                <div className="p-8 text-center text-gray-400 text-sm">Nothing out right now.</div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {current.map((l) => (
                    <div key={l.id} className="px-5 py-3 flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <p className="text-sm font-medium text-gray-900">{l.book?.title}</p>
                        <p className="text-xs text-gray-400">{l.book?.author} • Due {formatDate(l.due_date)}</p>
                      </div>
                      <div className="text-right">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded capitalize ${STATUS_STYLES[l.status]}`}>{l.status}</span>
                        {l.fine_amount > 0 && <p className="text-xs text-red-500 mt-1">Fine: {formatMoney(l.fine_amount)}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {history.length > 0 && (
              <div className="bg-white rounded shadow overflow-hidden">
                <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
                  <p className="text-sm font-semibold text-gray-700">History</p>
                </div>
                <div className="divide-y divide-gray-100">
                  {history.map((l) => (
                    <div key={l.id} className="px-5 py-3 flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <p className="text-sm text-gray-700">{l.book?.title}</p>
                        <p className="text-xs text-gray-400">Issued {formatDate(l.issue_date)}{l.return_date ? ` — Returned ${formatDate(l.return_date)}` : ""}</p>
                      </div>
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded capitalize ${STATUS_STYLES[l.status]}`}>{l.status}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </MainLayout>
  );
}
