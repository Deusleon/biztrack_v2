import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { libraryService, studentService, staffService } from "../../services/api";
import { useYearAwareClasses } from "../../hooks/useYearAwareClasses";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { Select, Input, NumberInput, DataTable, ConfirmModal, Button, DatePicker, RowActions, ACTION_ICONS } from "../../components/ui";

const STATUS_STYLES = {
  active: "bg-green-100 border border-green-300 text-green-500", inactive: "bg-gray-100 border border-gray-300 text-gray-600",
  damaged: "bg-amber-100 border border-amber-300 text-amber-500", lost: "bg-red-100 border border-red-300 text-red-500",
};

export default function BookList() {
  const navigate = useNavigate();
  const { user, canAny, can } = useAuth();
  const { showSuccess, showError } = useToast();

  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  const [filters, setFilters] = usePersistedState("filters", { search: "", category: "", status: "" });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 15 });

  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({ isbn: "", title: "", author: "", publisher: "", publication_year: "", category: "", total_copies: 1, location: "", replacement_cost: "", status: "active" });
  const [saving, setSaving] = useState(false);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false });

  const [issueModal, setIssueModal] = useState(false);
  const [issueBook, setIssueBook] = useState(null);
  const [borrowerType, setBorrowerType] = useState("student");
  const [selectedClass, setSelectedClass] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [classStudents, setClassStudents] = useState([]);
  const [staffList, setStaffList] = useState([]);
  const [issueForm, setIssueForm] = useState({ user_id: "", due_date: "", copy_number: "" });
  const [issuing, setIssuing] = useState(false);

  useEffect(() => { fetchBooks(); }, [filters, pagination.currentPage]);
  const classes = useYearAwareClasses({ selectedClassId: selectedClass, onRemap: setSelectedClass });
  useEffect(() => { staffService.getAll({ limit: 200, status: "active" }).then((res) => { if (res.success) setStaffList(res.data); }); }, []);

  const fetchBooks = async () => {
    try {
      setLoading(true);
      const res = await libraryService.getBooks({ ...filters, page: pagination.currentPage, limit: pagination.itemsPerPage });
      if (res.success) { setBooks(res.data); setPagination((p) => ({ ...p, ...res.pagination })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((f) => ({ ...f, [name]: value }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const openCreate = () => {
    setForm({ isbn: "", title: "", author: "", publisher: "", publication_year: "", category: "", total_copies: 1, location: "", replacement_cost: "", status: "active" });
    setModal({ isOpen: true, mode: "create" });
  };

  const openEdit = (b) => {
    setForm({ isbn: b.isbn || "", title: b.title, author: b.author || "", publisher: b.publisher || "", publication_year: b.publication_year || "", category: b.category || "", total_copies: b.total_copies, location: b.location || "", replacement_cost: b.replacement_cost ?? "", status: b.status });
    setModal({ isOpen: true, mode: "edit", id: b.id });
  };

  const handleSave = async () => {
    if (!form.title) { showError("Title is required"); return; }
    try {
      setSaving(true);
      const payload = { ...form, total_copies: Number(form.total_copies), publication_year: form.publication_year ? Number(form.publication_year) : null, replacement_cost: form.replacement_cost === "" ? null : Number(form.replacement_cost) };
      if (modal.mode === "edit") await libraryService.updateBook(modal.id, payload);
      else await libraryService.createBook(payload);
      showSuccess(modal.mode === "edit" ? "Book updated" : "Book added");
      setModal({ isOpen: false });
      fetchBooks();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (b) => {
    setConfirmModal({ isOpen: true, id: b.id, title: "Delete Book", message: `Delete "${b.title}"? This can't be undone.` });
  };
  const confirmDelete = async () => {
    try {
      await libraryService.deleteBook(confirmModal.id);
      showSuccess("Book deleted");
      fetchBooks();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmModal({ isOpen: false });
  };

  const openIssue = (book) => {
    setIssueBook(book);
    setBorrowerType("student");
    setSelectedClass(""); setSelectedSection(""); setClassStudents([]);
    setIssueForm({ user_id: "", due_date: "", copy_number: "" });
    setIssueModal(true);
  };

  useEffect(() => {
    if (!selectedClass) { setClassStudents([]); return; }
    studentService.getAll({ class_id: selectedClass, section_id: selectedSection || undefined, status: "active", limit: 200 }).then((res) => {
      if (res.success) setClassStudents(res.data);
    });
  }, [selectedClass, selectedSection]);

  const sections = classes.find((c) => c.id === selectedClass)?.sections || [];

  const handleIssue = async () => {
    if (!issueForm.user_id) { showError("Pick who's borrowing this book"); return; }
    try {
      setIssuing(true);
      const res = await libraryService.issueBook({ book_id: issueBook.id, user_id: issueForm.user_id, due_date: issueForm.due_date || undefined, copy_number: issueForm.copy_number || undefined });
      if (res.success) { showSuccess(res.message); setIssueModal(false); fetchBooks(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setIssuing(false); }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Library</h1>
            <p className="text-sm text-gray-500 mt-0.5">Book catalog, availability, and loans</p>
          </div>
          <div className="flex gap-2">
            {canAny("library") ? (
              <Button variant="secondary" onClick={() => navigate("/library/loans")}>Loans</Button>
            ) : (
              <Button variant="secondary" onClick={() => navigate("/library/my-books")}>My Books</Button>
            )}
            {can("library.create") && (
              <Button variant="primary" onClick={openCreate}>New Book</Button>
            )}
          </div>
        </div>

        <div className="bg-white p-5 rounded shadow">
          <form onSubmit={(e) => { e.preventDefault(); fetchBooks(); }} className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <Input label="Search" name="search" value={filters.search} onChange={handleFilterChange} placeholder="Search by title, author, ISBN…"
                leftIcon={<svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} />
            </div>
            <Select label="Status" name="status" value={filters.status} onChange={handleFilterChange}
              options={[{ value: "", label: "All Statuses" }, { value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }, { value: "damaged", label: "Damaged" }, { value: "lost", label: "Lost" }]} />
            <div className="flex items-end">
              <button type="submit" className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90">Apply Filters</button>
            </div>
          </form>
        </div>

        <DataTable
          columns={[
            {
              key: "title", label: "Book",
              render: (b) => (
                <div>
                  <p className="text-sm font-medium text-gray-900">{b.title}</p>
                  <p className="text-xs text-gray-400">{b.author || "Unknown author"}{b.isbn ? ` • ${b.isbn}` : ""}</p>
                </div>
              ),
            },
            { key: "category", label: "Category", render: (b) => <span className="text-sm text-gray-600">{b.category || "—"}</span> },
            {
              key: "copies", label: "Available",
              render: (b) => (
                <span className={`text-sm font-medium ${b.available_copies === 0 ? "text-red-600" : "text-gray-700"}`}>
                  {b.available_copies} / {b.total_copies}
                </span>
              ),
            },
            { key: "location", label: "Location", render: (b) => <span className="text-sm text-gray-600">{b.location || "—"}</span> },
            { key: "status", label: "Status", render: (b) => <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${STATUS_STYLES[b.status]}`}>{b.status}</span> },
          ]}
          data={books}
          loading={loading}
          emptyMessage="No books found"
          renderActions={(can("library.update") || can("library.delete")) ? (b) => (
            <RowActions
              actions={[
                // Nothing to issue when every copy is already out — the old
                // menu showed a permanently greyed-out row instead.
                { label: 'Issue Book', variant: 'primary', icon: ACTION_ICONS.upload, hidden: !can("library.update") || b.available_copies === 0, onClick: () => openIssue(b) },
                { label: 'Edit Book', icon: ACTION_ICONS.edit, hidden: !can("library.update"), onClick: () => openEdit(b) },
                { label: 'Delete Book', variant: 'danger', icon: ACTION_ICONS.delete, hidden: !can("library.delete"), onClick: () => handleDelete(b) },
              ]}
            />
          ) : undefined}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Book" : "New Book"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <Input label="Title" required value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} placeholder="Enter book title" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Author" value={form.author} onChange={(e) => setForm((f) => ({ ...f, author: e.target.value }))} placeholder="Enter book author" />
                <Input label="ISBN" value={form.isbn} onChange={(e) => setForm((f) => ({ ...f, isbn: e.target.value }))} placeholder="Enter ISBN"/>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Publisher" value={form.publisher} onChange={(e) => setForm((f) => ({ ...f, publisher: e.target.value }))} placeholder="Enter publisher" />
                <Input label="Publication Year" type="number" value={form.publication_year} onChange={(e) => setForm((f) => ({ ...f, publication_year: e.target.value }))} placeholder="Enter publication year" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Category" value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))} placeholder="Enter category" />
                <Input label="Shelf / Location" value={form.location} onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))} placeholder="Enter shelf or location" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Total Copies" type="number" min={1} required value={form.total_copies} onChange={(e) => setForm((f) => ({ ...f, total_copies: e.target.value }))} placeholder="Enter total copies" />
                <NumberInput
                  label="Replacement Cost (TZS)"
                  value={form.replacement_cost}
                  onChange={(e) => setForm((f) => ({ ...f, replacement_cost: e.target.value }))}
                  placeholder="Enter replacement cost"
                  helperText="Charged to a borrower who loses a copy. Leave blank and a loss costs them only the overdue fine."
                />
              </div>
              <Select label="Status" value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}
                options={[{ value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }, { value: "damaged", label: "Damaged" }, { value: "lost", label: "Lost" }]} />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Add Book"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {issueModal && issueBook && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Issue "{issueBook.title}"</h3>
              <button onClick={() => setIssueModal(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleIssue(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="flex gap-2">
                <button type="button" onClick={() => { setBorrowerType("student"); setIssueForm((f) => ({ ...f, user_id: "" })); }}
                  className={`flex-1 text-sm py-2 rounded border ${borrowerType === "student" ? "bg-primary text-white border-primary" : "border-gray-300 text-gray-700"}`}>Student</button>
                <button type="button" onClick={() => { setBorrowerType("staff"); setIssueForm((f) => ({ ...f, user_id: "" })); }}
                  className={`flex-1 text-sm py-2 rounded border ${borrowerType === "staff" ? "bg-primary text-white border-primary" : "border-gray-300 text-gray-700"}`}>Staff</button>
              </div>

              {borrowerType === "student" ? (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Select label="Class" required value={selectedClass} onChange={(e) => { setSelectedClass(e.target.value); setSelectedSection(""); }}
                      options={[{ value: "", label: "Select…" }, ...classes.map((c) => ({ value: c.id, label: c.name }))]} />
                    <Select label="Section" value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} disabled={!selectedClass}
                      options={[{ value: "", label: "All sections" }, ...sections.map((s) => ({ value: s.id, label: s.name }))]} />
                  </div>
                  <Select label="Student" required searchable disabled={!selectedClass} value={issueForm.user_id} onChange={(e) => setIssueForm((f) => ({ ...f, user_id: e.target.value }))}
                    options={[{ value: "", label: "Select…" }, ...classStudents.map((s) => ({ value: s.user?.id, label: `${s.user?.first_name} ${s.user?.last_name} (${s.admission_number})` }))]} />
                </>
              ) : (
                <Select label="Staff Member" required searchable value={issueForm.user_id} onChange={(e) => setIssueForm((f) => ({ ...f, user_id: e.target.value }))}
                  options={[{ value: "", label: "Select…" }, ...staffList.map((s) => ({ value: s.user?.id, label: `${s.user?.first_name} ${s.user?.last_name}` }))]} />
              )}

              <DatePicker label="Due Date" value={issueForm.due_date} onChange={(e) => setIssueForm((f) => ({ ...f, due_date: e.target.value }))} helperText="Leave blank for the default 14-day loan period" />
              <Input label="Copy No." type="number" min={1} value={issueForm.copy_number} onChange={(e) => setIssueForm((f) => ({ ...f, copy_number: e.target.value }))}
                placeholder="e.g. 3" helperText="Optional — write the copy number printed/marked on the physical book, so returns match the right one" />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={issuing}>Issue Book</Button>
                <Button type="button" variant="secondary" onClick={() => setIssueModal(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmModal.isOpen} title={confirmModal.title} message={confirmModal.message} variant="danger" onConfirm={confirmDelete} onClose={() => setConfirmModal({ isOpen: false })} />
    </MainLayout>
  );
}
