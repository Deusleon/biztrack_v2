// frontend/src/pages/Library/LoanList.jsx
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { libraryService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { Select, Input, NumberInput, DataTable, ConfirmModal, Button, RowActions, ACTION_ICONS } from "../../components/ui";
import { formatMoneyOrDash as formatMoney } from "../../utils/money";

const STATUS_STYLES = {
  issued: "bg-blue-100 border border-blue-300 text-blue-500", overdue: "bg-red-100 border border-red-300 text-red-500",
  returned: "bg-green-100 border border-green-300 text-green-500", lost: "bg-red-100 border border-red-300 text-red-500",
};


// A fine is collected through Fees, not here — the badge says where the
// debt stands rather than implying the library takes the money.
const FINE_STATUS_LABELS = {
  pending: "On fee account",
  partial: "On fee account",
  paid: "Settled",
  waived: "Waived",
};
const FINE_STATUS_STYLES = {
  pending: "bg-amber-100 border border-amber-300 text-amber-600",
  partial: "bg-amber-100 border border-amber-300 text-amber-600",
  paid: "bg-green-100 border border-green-300 text-green-500",
  waived: "bg-gray-100 border border-gray-300 text-gray-500",
};

export default function LoanList() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();

  const [settings, setSettings] = useState(null);
  const [rulesModal, setRulesModal] = useState(false);
  const [rulesForm, setRulesForm] = useState({});

  const [loans, setLoans] = useState([]);
  const [loading, setLoading] = useState(true);

  const [filters, setFilters] = usePersistedState("filters", { status: "", borrower: "" });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 15 });

  const [confirmReturn, setConfirmReturn] = useState({ isOpen: false });
  // Marking a copy lost charges the borrower, so it gets a form rather than
  // a bare confirm — the librarian may need to override the replacement cost.
  const [lostModal, setLostModal] = useState({ isOpen: false });
  const [lostForm, setLostForm] = useState({ replacement_cost: "", remarks: "" });
  const [fineModal, setFineModal] = useState({ isOpen: false });
  const [fineForm, setFineForm] = useState({ amount: "", reason: "" });
  const [saving, setSaving] = useState(false);

  // A loan belongs to the year it was issued in. School years run January
  // to December, so the selected year is that calendar year.
  const { currentAcademicYear } = useAcademicYear();
  const yearBounds = (() => {
    const base = parseInt(String(currentAcademicYear || "").match(/\d{4}/)?.[0], 10);
    return base ? { start: `${base}-01-01`, end: `${base}-12-31` } : null;
  })();

  useEffect(() => { fetchLoans(); }, [filters, pagination.currentPage, currentAcademicYear]);

  useEffect(() => { setPagination((p) => ({ ...p, currentPage: 1 })); }, [currentAcademicYear]);

  useEffect(() => {
    libraryService.getSettings()
      .then((res) => { if (res.success) setSettings(res.data); })
      .catch(() => {});
  }, []);

  const fetchLoans = async () => {
    try {
      setLoading(true);
      const res = await libraryService.getIssues({
        ...filters,
        start_date: yearBounds?.start,
        end_date: yearBounds?.end,
        page: pagination.currentPage, limit: pagination.itemsPerPage,
      });
      if (res.success) { setLoans(res.data); setPagination((p) => ({ ...p, ...res.pagination })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const handleReturn = (loan) => setConfirmReturn({ isOpen: true, id: loan.id });
  const confirmReturnBook = async () => {
    try {
      const res = await libraryService.returnBook(confirmReturn.id, {});
      showSuccess(res.message);
      fetchLoans();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmReturn({ isOpen: false });
  };

  const openLostModal = (loan) => {
    setLostForm({ replacement_cost: loan.book?.replacement_cost ?? "", remarks: "" });
    setLostModal({ isOpen: true, loan });
  };
  const submitMarkLost = async () => {
    try {
      setSaving(true);
      const res = await libraryService.markLost(lostModal.loan.id, {
        replacement_cost: lostForm.replacement_cost === "" ? undefined : Number(lostForm.replacement_cost),
        remarks: lostForm.remarks || undefined,
      });
      showSuccess(res.message);
      setLostModal({ isOpen: false });
      fetchLoans();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const openRulesModal = () => {
    setRulesForm({
      default_loan_days: settings?.default_loan_days ?? 14,
      fine_per_day: settings?.fine_per_day ?? 500,
      max_fine_days: settings?.max_fine_days ?? 60,
      default_replacement_cost: settings?.default_replacement_cost ?? 0,
    });
    setRulesModal(true);
  };

  const saveRules = async () => {
    try {
      setSaving(true);
      const res = await libraryService.updateSettings(rulesForm);
      if (res.success) {
        showSuccess(res.message);
        setSettings(res.data);
        setRulesModal(false);
        fetchLoans();
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const openFineModal = (loan) => {
    setFineForm({ amount: "", reason: "" });
    setFineModal({ isOpen: true, loan });
  };
  const submitWaiver = async () => {
    try {
      setSaving(true);
      const res = await libraryService.settleFine(fineModal.loan.id, { reason: fineForm.reason || undefined });
      showSuccess(res.message);
      setFineModal({ isOpen: false });
      fetchLoans();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Library Loans</h1>
            <p className="text-sm text-gray-500 mt-0.5">Every book currently or previously on loan</p>
          </div>
          <div className="flex items-center gap-2">
            {can("library.update") && (
              <Button variant="secondary" onClick={openRulesModal}>Lending Rules</Button>
            )}
            <Button variant="secondary" onClick={() => navigate("/library")}>Books</Button>
          </div>
        </div>

        {/* The rate behind every fine on this page. It was a constant in the
            code, so fines appeared that nobody at the school had set. */}
        {/* {settings && (
          <div className="bg-gray-100 border border-gray-300 rounded px-4 py-2.5 text-sm text-left text-gray-700">
            {Number(settings.fine_per_day) > 0 ? (
              <>Overdue fine: <strong>{formatMoney(settings.fine_per_day)} per day</strong>, capped
              at {settings.max_fine_days} days. Loans run {settings.default_loan_days} days.</>
            ) : (
              <>This library does not charge overdue fines. Loans run {settings.default_loan_days} days.</>
            )}
          </div>
        )} */}

        <div className="bg-white p-5 rounded shadow">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Input label="Borrower" value={filters.borrower} onChange={(e) => { setFilters((f) => ({ ...f, borrower: e.target.value })); setPagination((p) => ({ ...p, currentPage: 1 })); }} placeholder="Search by name…" />
            <Select label="Status" value={filters.status} onChange={(e) => { setFilters((f) => ({ ...f, status: e.target.value })); setPagination((p) => ({ ...p, currentPage: 1 })); }}
              options={[{ value: "", label: "All Statuses" }, { value: "issued", label: "Issued" }, { value: "overdue", label: "Overdue" }, { value: "returned", label: "Returned" }, { value: "lost", label: "Lost" }]} />
          </div>
        </div>

        <DataTable
          columns={[
            { key: "book", label: "Book", render: (l) => <span className="text-sm font-medium">{l.book?.title}{l.copy_number ? <span className="text-xs text-gray-500"> (Copy #{l.copy_number})</span> : ""}</span> },
            { key: "borrower", label: "Borrower", render: (l) => <span className="text-sm">{l.user?.first_name} {l.user?.last_name} <span className="text-xs text-gray-500 capitalize">({l.user?.role})</span></span> },
            { key: "issue_date", label: "Issued", render: (l) => <span className="text-sm">{formatDate(l.issue_date)}</span> },
            { key: "due_date", label: "Due", render: (l) => <span className="text-sm">{formatDate(l.due_date)}</span> },
            {
              key: "fine", label: "Fine",
              // A single figure hid what the borrower was actually being
              // charged for — lateness and a lost book are very different
              // conversations to have with a parent.
              render: (l) => {
                const total = Number(l.fine_amount || 0);
                if (total <= 0) return <span className="text-sm text-gray-300">—</span>;
                const replacement = Number(l.replacement_charge || 0);
                const overdue = Number(l.overdue_fine || 0);
                return (
                  <div>
                    <div className="text-sm font-medium text-gray-900">{formatMoney(total)}</div>
                    <div className="text-xs text-gray-400">
                      {overdue > 0 && <>late {formatMoney(overdue)}</>}
                      {overdue > 0 && replacement > 0 && " + "}
                      {replacement > 0 && <>book {formatMoney(replacement)}</>}
                    </div>
                    {l.fine_status && l.fine_status !== "none" && (
                      <span className={`mt-1 px-2 inline-flex text-[10px] leading-4 font-semibold rounded-full ${FINE_STATUS_STYLES[l.fine_status] || ""}`}>
                        {FINE_STATUS_LABELS[l.fine_status] || l.fine_status}
                      </span>
                    )}
                  </div>
                );
              },
            },
            { key: "status", label: "Status", align: "left", render: (l) => <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${STATUS_STYLES[l.status]}`}>{l.status}</span> },
          ]}
          data={loans}
          loading={loading}
          emptyMessage="No loans found"
          renderActions={can("library.update") ? (l) => {
            const isOpenLoan = l.status === "issued" || l.status === "overdue";
            const owes = Number(l.fine_amount || 0) > 0 && l.fine_status !== "waived";
            return (
              <RowActions
                actions={[
                  { label: "Mark Returned", variant: "success", icon: ACTION_ICONS.check, hidden: !isOpenLoan, onClick: () => handleReturn(l) },
                  { label: "Report Lost", variant: "danger", icon: ACTION_ICONS.remove, hidden: !isOpenLoan, onClick: () => openLostModal(l) },
                  // A fine outlives the loan — it still needs collecting
                  // after the book is back on the shelf or written off.
                  { label: "Waive Fine", icon: ACTION_ICONS.remove, hidden: !owes, onClick: () => openFineModal(l) },
                ]}
              />
            );
          } : undefined}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      <ConfirmModal isOpen={confirmReturn.isOpen} title="Mark as Returned" message="Confirm this book has been returned? Any late fine will be calculated automatically." onConfirm={confirmReturnBook} onClose={() => setConfirmReturn({ isOpen: false })} />

      {/* Report Lost — charges the borrower, so it asks rather than assumes */}
      {lostModal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <div className="text-left">
                <h3 className="text-base font-semibold">Report Copy Lost</h3>
                <p className="text-xs text-gray-500 mt-0.5">{lostModal.loan?.book?.title}</p>
              </div>
              <button onClick={() => setLostModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); submitMarkLost(); }} className="px-5 py-4 space-y-4">
              <p className="text-sm text-left text-gray-600 bg-amber-50 border border-amber-200 rounded px-3 py-2.5 leading-relaxed">
                The borrower will be charged the overdue fine accrued so far <strong>plus</strong> the replacement
                cost below. The library's total copies for this title drop by one.
              </p>
              <NumberInput
                label="Replacement Cost (TZS)"
                value={lostForm.replacement_cost}
                onChange={(e) => setLostForm((f) => ({ ...f, replacement_cost: e.target.value }))}
                helperText={lostModal.loan?.book?.replacement_cost
                  ? "Pre-filled from this book's replacement cost — override it for this case if needed."
                  : "This book has no replacement cost on file. Enter one, or leave blank to charge only the overdue fine."}
              />
              <Input label="Remarks" value={lostForm.remarks} onChange={(e) => setLostForm((f) => ({ ...f, remarks: e.target.value }))} placeholder="Optional note" />
              <div className="flex gap-3 pt-1">
                <Button type="submit" variant="danger" loading={saving}>Report Lost</Button>
                <Button type="button" variant="secondary" onClick={() => setLostModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Waive Fine — collection itself happens in Fees, since the fine is
          raised as a charge on the student's fee account. */}
      {fineModal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <div className="text-left">
                <h3 className="text-base font-semibold">Waive Fine</h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  {fineModal.loan?.user?.first_name} {fineModal.loan?.user?.last_name} — {fineModal.loan?.book?.title}
                </p>
              </div>
              <button onClick={() => setFineModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); submitWaiver(); }} className="px-5 py-4 space-y-4">
              <div className="bg-gray-50 border border-gray-200 rounded px-3 py-2.5 space-y-1.5 text-sm">
                <div className="flex justify-between"><span className="text-gray-500">Overdue fine</span><span className="text-gray-800">{formatMoney(fineModal.loan?.overdue_fine)}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Replacement charge</span><span className="text-gray-800">{formatMoney(fineModal.loan?.replacement_charge)}</span></div>
                <div className="flex justify-between border-t border-gray-200 pt-1.5">
                  <span className="font-medium text-gray-700">Total owed</span>
                  <span className="font-bold text-red-600">{formatMoney(fineModal.loan?.fine_amount)}</span>
                </div>
              </div>

              <p className="text-sm text-left text-gray-600 bg-gray-100 border border-gray-300 rounded px-3 py-2.5 leading-relaxed">
                This fine sits on the student's fee balance, so it is <strong>collected by the accountant through
                Fees</strong> like everything else they owe. Waiving it here writes the debt off and removes it
                from that balance.
              </p>

              <Input label="Reason for Waiving" value={fineForm.reason} onChange={(e) => setFineForm((f) => ({ ...f, reason: e.target.value }))} placeholder="e.g. book later found and returned" />

              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" variant="lightDanger" loading={saving}>Waive Fine</Button>
                <Button type="button" variant="secondary" onClick={() => setFineModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}


      {/* Lending Rules */}
      {rulesModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <div className="text-left">
                <h3 className="text-base font-semibold">Lending Rules</h3>
                <p className="text-xs text-gray-500 mt-0.5">Applies to loans issued from now on</p>
              </div>
              <button onClick={() => setRulesModal(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>

            <form onSubmit={(e) => { e.preventDefault(); saveRules(); }} className="px-5 py-4 space-y-4">
              <NumberInput
                label="Loan Period (days)"
                required
                allowDecimals={false}
                value={rulesForm.default_loan_days}
                onChange={(e) => setRulesForm((f) => ({ ...f, default_loan_days: e.target.value }))}
                helperText="How long a book is lent for when no due date is set explicitly."
              />
              <NumberInput
                label="Overdue Fine per Day (TZS)"
                required
                value={rulesForm.fine_per_day}
                onChange={(e) => setRulesForm((f) => ({ ...f, fine_per_day: e.target.value }))}
                helperText="Set to 0 if your library does not charge for late returns."
              />
              <NumberInput
                label="Stop Charging After (days)"
                required
                allowDecimals={false}
                value={rulesForm.max_fine_days}
                onChange={(e) => setRulesForm((f) => ({ ...f, max_fine_days: e.target.value }))}
                helperText="A cap, so a book forgotten over a long holiday can't reach a fine nobody can pay."
              />
              <NumberInput
                label="Default Replacement Cost (TZS)"
                value={rulesForm.default_replacement_cost}
                onChange={(e) => setRulesForm((f) => ({ ...f, default_replacement_cost: e.target.value }))}
                helperText="Charged when a lost book has no replacement cost of its own recorded."
              />

              <p className="text-xs text-left text-gray-500 bg-gray-50 border border-gray-200 rounded px-3 py-2.5 leading-relaxed">
                Fines already raised keep the amounts borrowers were quoted. Raising the rate today does not
                increase a debt someone was already told they owe.
              </p>

              <div className="flex justify-end gap-3">
                <Button type="submit" loading={saving}>Save Rules</Button>
                <Button type="button" variant="secondary" onClick={() => setRulesModal(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

    </MainLayout>
  );
}