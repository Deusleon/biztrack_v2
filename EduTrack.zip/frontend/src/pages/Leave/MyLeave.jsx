// frontend/src/pages/Leave/MyLeave.jsx
import { useState, useEffect } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { leaveService } from "../../services/api";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import MainLayout from "../../components/MainLayout";
import LeaveTabs from "./LeaveTabs";
import { Select, Input, Button, ConfirmModal, DatePicker, DataTable, RowActions, ACTION_ICONS } from "../../components/ui";
import Icon from "../../components/ui/Icon";

const STATUS_STYLES = {
  pending: "bg-amber-100 border border-amber-300 text-amber-600",
  approved: "bg-green-100 border border-green-300 text-green-500",
  rejected: "bg-red-100 border border-red-300 text-red-500",
  cancelled: "bg-gray-100 border border-gray-300 text-gray-500",
};

export default function MyLeave() {
  const { user, can, canAny } = useAuth();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();
  const isStaff = user?.role !== 'student';

  // Leave balances are stored per calendar year, and school years run
  // January to December — so the selected academic year's base year is the
  // leave year.
  const { currentAcademicYear } = useAcademicYear();
  const selectedYear = parseInt(String(currentAcademicYear || '').match(/\d{4}/)?.[0], 10) || new Date().getFullYear();
  const canApprove = (can("leave.request") && user?.role !== "student");
  const canManageSetup = canAny("leave");

  const [requests, setRequests] = useState([]);
  const [balances, setBalances] = useState([]);
  const [types, setTypes] = useState([]);
  const [loading, setLoading] = useState(true);

  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ leave_type_id: "", start_date: "", end_date: "", reason: "" });
  const [saving, setSaving] = useState(false);
  const [confirmCancel, setConfirmCancel] = useState({ isOpen: false });

  const load = async () => {
    try {
      setLoading(true);
      // Requests and balances both belong to the selected year. Leave types
      // are configuration, not year-scoped, so they aren't filtered.
      const calls = [
        leaveService.getMyRequests({ year: selectedYear }),
        leaveService.getTypes({ applies_to: isStaff ? "staff" : "student" }),
      ];
      if (isStaff) calls.push(leaveService.getMyBalances(selectedYear));
      const results = await Promise.all(calls);
      if (results[0].success) setRequests(results[0].data);
      if (results[1].success) setTypes(results[1].data);
      if (isStaff && results[2]?.success) setBalances(results[2].data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [selectedYear]);

  const openRequest = () => {
    setForm({ leave_type_id: types[0]?.id || "", start_date: "", end_date: "", reason: "" });
    setModal(true);
  };

  const daysCount = form.start_date && form.end_date
    ? Math.max(0, Math.floor((new Date(form.end_date) - new Date(form.start_date)) / 86400000) + 1)
    : 0;

  const handleSubmit = async () => {
    if (!form.leave_type_id || !form.start_date || !form.end_date) { showError("Fill in the leave type and dates"); return; }
    try {
      setSaving(true);
      const res = await leaveService.createRequest(form);
      if (res.success) { showSuccess(res.message); setModal(false); load(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleCancel = (id) => setConfirmCancel({ isOpen: true, id });
  const confirmCancelRequest = async () => {
    try {
      await leaveService.cancelRequest(confirmCancel.id);
      showSuccess("Request cancelled");
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmCancel({ isOpen: false });
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">{isStaff ? "My Leave" : "My Leave / Excuse Requests"}</h1>
            <p className="text-sm text-gray-500 mt-0.5">Request leave and track approvals</p>
          </div>
          <Button variant="primary" onClick={openRequest}>Request Leave</Button>
        </div>

        <LeaveTabs active="requests" canApprove={canApprove} canManageSetup={canManageSetup} />

        {isStaff && balances.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {balances.map((b) => {
              const allocated = Number(b.allocated_days) || 0;
              const used = Number(b.used_days) || 0;
              const pct = allocated > 0 ? Math.min(100, Math.round((used / allocated) * 100)) : 0;
              const exhausted = allocated > 0 && used >= allocated;
              return (
                <div key={b.leave_type.id} className="bg-white p-5 rounded shadow">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="text-sm text-left text-gray-600">{b.leave_type.name}</p>
                      <p className={`text-2xl text-left font-bold mt-1 ${exhausted ? "text-red-600" : "text-primary"}`}>{b.remaining_days}</p>
                      <p className="text-xs text-left text-gray-400 mt-0.5">of {allocated} days ({b.year})</p>
                    </div>
                    <div className={`p-3 rounded ${exhausted ? "bg-red-100" : "bg-primary-15"}`}>
                      <svg className={`w-8 h-8 opacity-45 ${exhausted ? "text-red-600" : "text-primary"}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                    </div>
                  </div>
                  {/* How much has been taken, at a glance — "18" alone doesn't
                      show how close someone is to running out. */}
                  <div className="mt-3 h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full ${exhausted ? "bg-red-400" : "bg-primary"}`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <DataTable
          columns={[
            { key: "type", label: "Type", render: (r) => <span className="text-sm font-medium text-gray-900">{r.leaveType?.name}</span> },
            { key: "dates", label: "Dates", render: (r) => <span className="text-sm text-gray-600">{formatDate(r.start_date)} – {formatDate(r.end_date)}</span> },
            { key: "days_count", label: "Days", align: "center", render: (r) => <span className="text-sm text-gray-600">{r.days_count}</span> },
            {
              key: "status", label: "Status", align: "center",
              render: (r) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${STATUS_STYLES[r.status]}`}>
                  {r.status}
                </span>
              ),
            },
            {
              key: "approval", label: "Approval",
              render: (r) => {
                if (r.status === "pending") {
                  const approver = r.current_step === 1 ? r.step1Approver : r.step2Approver;
                  const name = approver ? `${approver.first_name} ${approver.last_name}` : `Step ${r.current_step}`;
                  return <span className="text-xs text-gray-500">Awaiting {name}</span>;
                }
                const comment = r.step1_comment || r.step2_comment;
                if (r.status === "rejected" && comment) {
                  return <span className="text-xs text-red-500 italic">{comment}</span>;
                }
                return <span className="text-xs text-gray-300">—</span>;
              },
            },
          ]}
          data={requests}
          loading={loading}
          rowId="id"
          emptyMessage="No leave requests yet"
          renderActions={(r) => (
            <RowActions
              actions={[
                // Only a request still awaiting a decision can be withdrawn.
                { label: "Cancel Request", variant: "danger", icon: ACTION_ICONS.remove, hidden: r.status !== "pending", onClick: () => handleCancel(r.id) },
              ]}
            />
          )}
        />
      </div>

      {modal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Request Leave</h3>
              <button onClick={() => setModal(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSubmit(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <Select label="Leave Type" required value={form.leave_type_id} onChange={(e) => setForm((f) => ({ ...f, leave_type_id: e.target.value }))}
                options={[{ value: "", label: "Select…" }, ...types.map((t) => ({ value: t.id, label: t.name }))]} />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <DatePicker label="Start Date" required value={form.start_date} onChange={(e) => setForm((f) => ({ ...f, start_date: e.target.value }))} />
                <DatePicker label="End Date" required value={form.end_date} onChange={(e) => setForm((f) => ({ ...f, end_date: e.target.value }))} align="right" />
              </div>
              {daysCount > 0 && <p className="text-xs text-gray-500">{daysCount} day(s) total</p>}
              <Input label="Reason" value={form.reason} onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))} placeholder="Optional" />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>Submit Request</Button>
                <Button type="button" variant="secondary" onClick={() => setModal(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmCancel.isOpen} title="Cancel Request" message="Cancel this leave request?" variant="danger" onConfirm={confirmCancelRequest} onClose={() => setConfirmCancel({ isOpen: false })} />
    </MainLayout>
  );
}