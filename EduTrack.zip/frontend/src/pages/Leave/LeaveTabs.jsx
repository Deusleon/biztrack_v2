import { useNavigate } from "react-router-dom";

/**
 * LeaveTabs — the tab strip shared by My Requests, Approvals and Setup.
 *
 * The three live on separate routes, but to a user they're one module.
 * Previously Approvals and Setup were outline buttons sitting beside
 * "Request Leave" in the header, which read as three equally-weighted
 * actions rather than a primary action plus two sections. This gives Leave
 * the same arrangement as Expenses: header → tab strip → content.
 *
 * Tabs are filtered by permission, so a member of staff with no approval
 * rights simply sees one tab rather than a strip full of dead ends.
 */
export default function LeaveTabs({ active, canApprove = false, canManageSetup = false }) {
  const navigate = useNavigate();

  const tabs = [
    { id: "requests", label: "My Requests", path: "/leave" },
    { id: "approvals", label: "Approvals", path: "/leave/approvals", hidden: !canApprove },
    // Leave Types and Staff Balances were sub-tabs inside a "Setup" page —
    // a tab strip nested in a tab strip, and two clicks to reach either.
    // They're sections of the module in their own right.
    { id: "types", label: "Leave Types", path: "/leave/types", hidden: !canManageSetup },
    { id: "balances", label: "Staff Balances", path: "/leave/balances", hidden: !canManageSetup },
  ].filter((t) => !t.hidden);

  // One tab is not a choice — showing a strip would just be decoration.
  if (tabs.length < 2) return null;

  return (
    <div className="bg-white rounded shadow">
      <div className="flex border-b border-gray-200">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => navigate(tab.path)}
            className={`px-5 py-3 text-sm font-medium border-b-2 transition-colors ${
              active === tab.id
                ? "border-primary text-primary"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </div>
  );
}
