import { useState, useEffect } from "react";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { leaveService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import LeaveTabs from "./LeaveTabs";
import { Button, Input } from "../../components/ui";

export default function Approvals() {
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();

  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [decisionModal, setDecisionModal] = useState(null);
  const [comment, setComment] = useState("");
  const [deciding, setDeciding] = useState(false);

  const load = async () => {
    try {
      setLoading(true);
      const res = await leaveService.getPendingApprovals();
      if (res.success) setRequests(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const openDecision = (request, decision) => { setDecisionModal({ request, decision }); setComment(""); };

  const handleDecide = async () => {
    try {
      setDeciding(true);
      const res = await leaveService.decideRequest(decisionModal.request.id, decisionModal.decision, comment || undefined);
      if (res.success) { showSuccess(res.message); setDecisionModal(null); load(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setDeciding(false); }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Leave Approvals</h1>
            <p className="text-sm text-gray-500 mt-0.5">Requests currently awaiting your decision</p>
          </div>
        </div>

        {/* Same tab strip as My Leave, so the three pages read as
            one module instead of separate screens linked by buttons. */}
        <LeaveTabs active="approvals" canApprove canManageSetup />

        {loading ? (
          <div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
        ) : requests.length === 0 ? (
          <div className="bg-white p-10 rounded shadow text-center text-gray-400 text-sm">Nothing waiting on you right now.</div>
        ) : (
          <div className="space-y-3">
            {requests.map((r) => (
              <div key={r.id} className="bg-white rounded shadow p-5 flex items-start justify-between">
                <div className="text-left">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-gray-900">{r.user?.first_name} {r.user?.last_name}</p>
                    <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full capitalize">{r.requester_role}</span>
                    <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">Step {r.current_step} of 2</span>
                  </div>
                  <p className="text-sm text-gray-700 mt-1">{r.leaveType?.name} — {formatDate(r.start_date)} to {formatDate(r.end_date)} ({r.days_count} day{r.days_count > 1 ? "s" : ""})</p>
                  {r.reason && <p className="text-xs text-gray-500 mt-1">"{r.reason}"</p>}
                  {r.current_step === 2 && r.step1_decision && (
                    <p className="text-xs text-green-600 mt-1">Step 1 approved{r.step1Approver ? ` by ${r.step1Approver.first_name} ${r.step1Approver.last_name}` : ""}{r.step1_comment ? ` — "${r.step1_comment}"` : ""}</p>
                  )}
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <Button onClick={() => openDecision(r, "approved")} size="sm">Approve</Button>
                  <Button onClick={() => openDecision(r, "rejected")} variant="danger" size="sm">Reject</Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {decisionModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-sm">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold capitalize">{decisionModal.decision} Request</h3>
              <button onClick={() => setDecisionModal(null)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleDecide(); }} className="px-5 py-4 space-y-4">
              <p className="text-sm text-left text-gray-600">
                {decisionModal.request.user?.first_name} {decisionModal.request.user?.last_name} — {decisionModal.request.leaveType?.name}
              </p>
              <Input label="Comment" value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Optional" />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={deciding} variant={decisionModal.decision === "rejected" ? "danger" : "primary"}>
                  Confirm {decisionModal.decision === "approved" ? "Approval" : "Rejection"}
                </Button>
                <Button type="button" variant="secondary" onClick={() => setDecisionModal(null)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </MainLayout>
  );
}
