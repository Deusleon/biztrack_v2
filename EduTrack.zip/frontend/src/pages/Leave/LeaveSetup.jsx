// frontend/src/pages/Leave/LeaveSetup.jsx
import { useAuth } from "../../contexts/AuthContext";
import { useState, useEffect } from "react";
import { useToast } from "../../contexts/ToastContext";
import { leaveService, staffService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import LeaveTabs from "./LeaveTabs";
import { Select, Input, Button, ConfirmModal, DataTable, RowActions, ACTION_ICONS } from "../../components/ui";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import Icon from "../../components/ui/Icon";

/**
 * Leave Types and Staff Balances used to be two sub-tabs nested inside a
 * "Setup" page — which meant a tab strip inside a tab strip, and two
 * clicks to reach either one. They're now top-level sections of the Leave
 * module in their own right, each on its own route.
 *
 * Both still live in this file because they share the same data layer and
 * neither is large enough to justify a file of its own.
 */

export function LeaveTypes() {
  const { can } = useAuth();
  const { showSuccess, showError } = useToast();
  // The create action is owned by the page header, next to the title —
  // the same place "Request Leave" sits on My Leave. TypesTab raises this
  // counter to ask for the form, rather than rendering its own button
  // floating above the table.
  const [createSignal, setCreateSignal] = useState(0);

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Leave Types</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              The kinds of leave staff and students can request
            </p>
          </div>
          {can("leave.create") && <Button variant="primary" onClick={() => setCreateSignal((c) => c + 1)}>New Leave Type</Button>}
        </div>

        <LeaveTabs active="types" canApprove canManageSetup />

        <TypesTab showSuccess={showSuccess} showError={showError} createSignal={createSignal} />
      </div>
    </MainLayout>
  );
}

export function StaffBalances() {
  const { showSuccess, showError } = useToast();

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Staff Balances</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              How many days each staff member has left, per leave type
            </p>
          </div>
        </div>

        <LeaveTabs active="balances" canApprove canManageSetup />

        <BalancesTab showSuccess={showSuccess} showError={showError} />
      </div>
    </MainLayout>
  );
}

function TypesTab({ showSuccess, showError, createSignal = 0 }) {
  const { can } = useAuth();
  const [types, setTypes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({ name: "", applies_to: "staff", has_balance: true, default_days_per_year: "", status: "active" });
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState({ isOpen: false });

  const load = async () => {
    try {
      setLoading(true);
      const res = await leaveService.getTypes({});
      if (res.success) setTypes(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const openCreate = () => { setForm({ name: "", applies_to: "staff", has_balance: true, default_days_per_year: "", status: "active" }); setModal({ isOpen: true, mode: "create" }); };

  // Opens the form when the page header's button is pressed. Guarded on
  // the initial 0 so the modal doesn't pop open on first render.
  useEffect(() => {
    if (createSignal > 0) openCreate();
  }, [createSignal]);
  const openEdit = (t) => { setForm({ name: t.name, applies_to: t.applies_to, has_balance: t.has_balance, default_days_per_year: t.default_days_per_year || "", status: t.status }); setModal({ isOpen: true, mode: "edit", id: t.id }); };

  const handleSave = async () => {
    if (!form.name) { showError("Name is required"); return; }
    try {
      setSaving(true);
      const payload = { ...form, default_days_per_year: form.default_days_per_year ? Number(form.default_days_per_year) : null };
      if (modal.mode === "edit") await leaveService.updateType(modal.id, payload);
      else await leaveService.createType(payload);
      showSuccess(modal.mode === "edit" ? "Leave type updated" : "Leave type created");
      setModal({ isOpen: false });
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (t) => setConfirmDelete({ isOpen: true, id: t.id, name: t.name });
  const confirmDeleteType = async () => {
    try {
      await leaveService.deleteType(confirmDelete.id);
      showSuccess("Leave type deleted");
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmDelete({ isOpen: false });
  };

  return (
    <div className="space-y-4">
      <DataTable
        columns={[
          { key: "name", label: "Name", render: (t) => <span className="text-sm text-gray-900">{t.name}</span> },
          { key: "applies_to", label: "Applies To", render: (t) => <span className="text-sm text-gray-600 capitalize">{t.applies_to}</span> },
          { key: "has_balance", label: "Balance?", align: "center", render: (t) => <span className="text-sm text-gray-600">{t.has_balance ? "Yes" : "No"}</span> },
          { key: "default_days_per_year", label: "Days", align: "center", render: (t) => <span className="text-sm text-gray-600">{t.default_days_per_year || "—"}</span> },
          {
            key: "status", label: "Status", align: "center",
            render: (t) => (
              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${t.status === "active" ? "bg-green-100 border border-green-300 text-green-500" : "bg-red-100 border border-red-300 text-red-500"}`}>
                {t.status}
              </span>
            ),
          },
        ]}
        data={types}
        loading={loading}
        rowId="id"
        emptyMessage="No leave types configured yet"
        renderActions={(t) => (
          <RowActions
            actions={[
              { label: "Edit Type", variant: "primary", icon: ACTION_ICONS.edit, hidden: !can("leave.update"), onClick: () => openEdit(t) },
              { label: "Delete Type", variant: "danger", icon: ACTION_ICONS.delete, hidden: !can("leave.delete"), onClick: () => handleDelete(t) },
            ]}
          />
        )}
      />

      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-sm">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Leave Type" : "New Leave Type"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4">
              <Input label="Name" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="e.g. Annual Leave" />
              <Select label="Applies To" value={form.applies_to} onChange={(e) => setForm((f) => ({ ...f, applies_to: e.target.value }))}
                options={[{ value: "staff", label: "Staff" }, { value: "student", label: "Student" }, { value: "both", label: "Both" }]} />
              <label className="flex items-center gap-2 cursor-pointer text-sm text-gray-700">
                <input type="checkbox" checked={form.has_balance} onChange={(e) => setForm((f) => ({ ...f, has_balance: e.target.checked }))} className="accent-primary" />
                Draws from a yearly day balance
              </label>
              {form.has_balance && (
                <Input label="Default Days / Year" type="number" min={0} value={form.default_days_per_year} onChange={(e) => setForm((f) => ({ ...f, default_days_per_year: e.target.value }))} />
              )}
              <Select label="Status" value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}
                options={[{ value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }]} />
              <div className="flex gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Create"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmDelete.isOpen} title="Delete Leave Type" message={`Delete "${confirmDelete.name}"?`} variant="danger" onConfirm={confirmDeleteType} onClose={() => setConfirmDelete({ isOpen: false })} />
    </div>
  );
}

function BalancesTab({ showSuccess, showError }) {
  const { can } = useAuth();
  const [staffList, setStaffList] = useState([]);
  const [selectedStaff, setSelectedStaff] = useState("");

  // Balances are stored per calendar year, so the selected academic year's
  // base year decides which set is shown and adjusted.
  const { currentAcademicYear } = useAcademicYear();
  const selectedYear = parseInt(String(currentAcademicYear || '').match(/\d{4}/)?.[0], 10) || new Date().getFullYear();

  const [balances, setBalances] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editValue, setEditValue] = useState("");

  useEffect(() => { staffService.getAll({ limit: 200, status: "active" }).then((res) => { if (res.success) setStaffList(res.data); }); }, []);

  useEffect(() => {
    if (!selectedStaff) { setBalances([]); return; }
    setLoading(true);
    leaveService.getUserBalances(selectedStaff, selectedYear)
      .then((res) => { if (res.success) setBalances(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, [selectedStaff, selectedYear]);

  const startEdit = (b) => { setEditingId(b.id); setEditValue(b.allocated_days); };
  const saveEdit = async (b) => {
    try {
      await leaveService.adjustBalance(b.id, Number(editValue));
      showSuccess("Balance updated");
      setEditingId(null);
      leaveService.getUserBalances(selectedStaff, selectedYear).then((res) => { if (res.success) setBalances(res.data); });
    } catch (err) { showError(err.response?.data?.message || err.message); }
  };

  return (
    <div className="space-y-4">
      {/* Filter card — the picker was sitting bare on the page background,
          which is why this page looked unfinished next to the others. */}
      <div className="bg-white p-5 rounded shadow">
        <div className="max-w-sm">
          <Select
            label="Staff Member"
            searchable
            value={selectedStaff}
            onChange={(e) => setSelectedStaff(e.target.value)}
            placeholder="Select a staff member…"
            options={staffList.map((s) => ({ value: s.user?.id, label: `${s.user?.first_name} ${s.user?.last_name}` }))}
          />
        </div>
      </div>

      {/* Shared DataTable, which brings its own card, loading state and
          empty message — the hand-rolled table here had none of them. */}
      <DataTable
        columns={[
          { key: "leave_type", label: "Leave Type", render: (b) => <span className="text-sm font-medium text-gray-900">{b.leave_type?.name}</span> },
          {
            key: "allocated_days", label: "Allocated", align: "center",
            render: (b) => (editingId === b.id ? (
              <input
                type="number"
                min={0}
                autoFocus
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") saveEdit(b); if (e.key === "Escape") setEditingId(null); }}
                className="w-20 border border-primary rounded px-2 py-1 text-center text-sm focus:outline-none focus:ring-1 focus:ring-primary"
              />
            ) : (
              <span className="text-sm text-gray-900">{b.allocated_days}</span>
            )),
          },
          { key: "used_days", label: "Used", align: "center", render: (b) => <span className="text-sm text-gray-600">{b.used_days}</span> },
          {
            key: "remaining_days", label: "Remaining", align: "center",
            render: (b) => {
              const exhausted = Number(b.remaining_days) <= 0;
              return <span className={`text-sm font-semibold ${exhausted ? "text-red-600" : "text-gray-900"}`}>{b.remaining_days}</span>;
            },
          },
        ]}
        data={selectedStaff ? balances : []}
        loading={loading}
        rowId="id"
        emptyMessage={selectedStaff
          ? "No balance-tracked leave types configured for this staff member"
          : "Pick a staff member above to view and adjust their leave balance"}
        renderActions={(b) => (editingId === b.id ? (
          <div className="flex items-center justify-center gap-3">
            <button onClick={() => saveEdit(b)} className="text-primary hover:underline text-xs font-medium">Save</button>
            <button onClick={() => setEditingId(null)} className="text-gray-500 hover:underline text-xs">Cancel</button>
          </div>
        ) : (can("leave.update") ? (
          <button onClick={() => startEdit(b)} className="text-primary hover:underline text-xs font-medium">Adjust</button>
        ) : null))}
      />
    </div>
  );
}