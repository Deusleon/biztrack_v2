import { useAuth } from "../contexts/AuthContext";
import Dashboard from "./Dashboard";
import BasicDashboard from "./BasicDashboard";

/**
 * Everyone has a dashboard. The full one (statistics, charts, highlights) is for
 * people holding the "Open the full Dashboard" permission; everyone else gets a
 * simple personal one that only uses what they are always allowed to see — so
 * nobody is ever shown a dashboard full of "no permission" errors.
 */
export default function DashboardHome() {
  const { user, can } = useAuth();
  const permissionsKnown = Array.isArray(user?.effective_permissions);
  return !permissionsKnown || can("dashboard.access") ? <Dashboard /> : <BasicDashboard />;
}
