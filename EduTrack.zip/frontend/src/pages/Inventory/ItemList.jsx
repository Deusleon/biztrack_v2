import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { inventoryService, campusService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { Select, Input, NumberInput, DataTable, ConfirmModal, Button, DatePicker, RowActions, ACTION_ICONS } from "../../components/ui";

const CONDITION_STYLES = {
  new: "bg-blue-100 border border-blue-300 text-blue-500", good: "bg-green-100 border border-green-300 text-green-500",
  fair: "bg-amber-100 border border-amber-300 text-amber-500", poor: "bg-red-100 border border-red-300 text-red-500",
};
const CONDITIONS = [
  { value: "new", label: "New" }, { value: "good", label: "Good" },
  { value: "fair", label: "Fair" }, { value: "poor", label: "Poor" },
];
const ITEM_TYPES = [
  { value: "asset", label: "Fixed Asset" },
  { value: "consumable", label: "Consumable" },
];
const TYPE_STYLES = {
  asset: "bg-indigo-50 border border-indigo-200 text-indigo-600",
  consumable: "bg-teal-50 border border-teal-200 text-teal-600",
};
const TABS = [
  { value: "", label: "All Items" },
  { value: "asset", label: "Fixed Assets" },
  { value: "consumable", label: "Consumables" },
];
const isConsumable = (item) => item?.item_type === "consumable";

// The same five movements mean slightly different things for the two kinds
// of stock, so the wording follows the item: an asset is "assigned" and
// has a condition; a consumable is "used up" and just has a quantity.
const txTypesFor = (item) => (isConsumable(item)
  ? [
      { value: "received", label: "Received (stock in)" }, { value: "issued", label: "Issued / Used" },
      { value: "damaged", label: "Damaged / Expired" }, { value: "lost", label: "Lost" },
      { value: "adjusted", label: "Adjusted (set exact quantity)" },
    ]
  : [
      { value: "received", label: "Received (stock in)" }, { value: "issued", label: "Assigned (given out)" },
      { value: "damaged", label: "Damaged" }, { value: "lost", label: "Lost" },
      { value: "adjusted", label: "Adjusted (correction)" },
    ]);

export default function ItemList() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();

  const [items, setItems] = useState([]);
  const [campuses, setCampuses] = useState([]);
  const [loading, setLoading] = useState(true);

  const [filters, setFilters] = usePersistedState("filters", { search: "", category: "", low_stock: "" });
  // Which kind of stock is on screen. Applied here rather than on the server
  // so the tab counts stay correct while you switch between tabs.
  const [typeTab, setTypeTab] = usePersistedState("typeTab", "");

  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({ name: "", item_type: "consumable", category: "", unit: "pcs", quantity_on_hand: 0, condition: "good", reorder_level: "", location: "", campus_id: "", status: "active" });
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState({ isOpen: false });

  const [txModal, setTxModal] = useState(null);
  const [txForm, setTxForm] = useState({ type: "received", quantity: "", condition: "good", issued_to: "", transaction_date: "", notes: "" });
  const [savingTx, setSavingTx] = useState(false);

  const [receiveModal, setReceiveModal] = useState(false);
  const [receiveDate, setReceiveDate] = useState("");
  const [receiveLines, setReceiveLines] = useState([{ item_id: "", quantity: "", condition: "good", notes: "" }]);
  const [savingReceive, setSavingReceive] = useState(false);

  const fetchItems = async () => {
    try {
      setLoading(true);
      const res = await inventoryService.getItems(filters);
      if (res.success) setItems(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { fetchItems(); }, [filters]);
  useEffect(() => { campusService.getAll({ limit: 100 }).then((res) => { if (res.success) setCampuses(res.data); }); }, []);

  const handleFilterChange = (e) => setFilters((f) => ({ ...f, [e.target.name]: e.target.value }));

  const openCreate = () => {
    setForm({ name: "", item_type: typeTab || "consumable", category: "", unit: "pcs", quantity_on_hand: 0, condition: "good", reorder_level: "", location: "", campus_id: campuses[0]?.id || "", status: "active" });
    setModal({ isOpen: true, mode: "create" });
  };
  const openEdit = (item) => {
    setForm({ name: item.name, item_type: item.item_type || "consumable", category: item.category || "", unit: item.unit, quantity_on_hand: item.quantity_on_hand, condition: "good", reorder_level: item.reorder_level || "", location: item.location || "", campus_id: item.campus_id || "", status: item.status });
    setModal({ isOpen: true, mode: "edit", id: item.id });
  };

  const handleSave = async () => {
    if (!form.name) { showError("Name is required"); return; }
    try {
      setSaving(true);
      const payload = {
        ...form, quantity_on_hand: Number(form.quantity_on_hand),
        // Only consumables run low, so only they carry a reorder level.
        reorder_level: form.item_type === "consumable" && form.reorder_level ? Number(form.reorder_level) : null,
      };
      if (modal.mode === "edit") {
        const { quantity_on_hand, condition, ...editable } = payload;
        await inventoryService.updateItem(modal.id, editable);
      } else {
        await inventoryService.createItem(payload);
      }
      showSuccess(modal.mode === "edit" ? "Item updated" : "Item added");
      setModal({ isOpen: false });
      fetchItems();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (item) => { setConfirmDelete({ isOpen: true, id: item.id, name: item.name }); };
  const confirmDeleteItem = async () => {
    try {
      await inventoryService.deleteItem(confirmDelete.id);
      showSuccess("Item deleted");
      fetchItems();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmDelete({ isOpen: false });
  };

  const openTx = (item) => {
    setTxModal(item);
    setTxForm({ type: "received", quantity: "", condition: "good", issued_to: "", transaction_date: new Date().toISOString().slice(0, 10), notes: "" });
  };
  const handleSaveTx = async () => {
    if (!txForm.quantity) { showError("Enter a quantity"); return; }
    try {
      setSavingTx(true);
      const res = await inventoryService.createTransaction({ ...txForm, item_id: txModal.id, quantity: Number(txForm.quantity) });
      if (res.success) { showSuccess(res.message); setTxModal(null); fetchItems(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSavingTx(false); }
  };

  const openHistory = (item) => {
    navigate(`/inventory/history?item_id=${item.id}`);
  };

  const openReceive = () => {
    setReceiveDate(new Date().toISOString().slice(0, 10));
    setReceiveLines([{ item_id: "", quantity: "", condition: "good", notes: "" }]);
    setReceiveModal(true);
  };
  const addReceiveLine = () => setReceiveLines((prev) => [...prev, { item_id: "", quantity: "", condition: "good", notes: "" }]);
  const updateReceiveLine = (idx, field, value) => setReceiveLines((prev) => prev.map((l, i) => (i === idx ? { ...l, [field]: value } : l)));
  const removeReceiveLine = (idx) => setReceiveLines((prev) => prev.filter((_, i) => i !== idx));

  const handleBulkReceive = async () => {
    const valid = receiveLines.filter((l) => l.item_id && Number(l.quantity) > 0);
    if (valid.length === 0) { showError("Add at least one item with a quantity"); return; }
    try {
      setSavingReceive(true);
      const res = await inventoryService.bulkReceive({ transaction_date: receiveDate, items: valid });
      if (res.success) { showSuccess(res.message); setReceiveModal(false); fetchItems(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSavingReceive(false); }
  };

  // Only consumables run low — a fixed asset has no reorder level.
  const isLowStock = (item) => isConsumable(item) && item.reorder_level !== null && item.quantity_on_hand <= item.reorder_level;

  const tabCount = (value) => (value ? items.filter((i) => i.item_type === value).length : items.length);
  const visibleItems = typeTab ? items.filter((i) => i.item_type === typeTab) : items;

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Inventory</h1>
            <p className="text-sm text-gray-500 mt-0.5">Assets, equipment, and supplies on hand</p>
          </div>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => navigate("/inventory/history")}>History</Button>
            {can("inventory.create") && (
              <>
                <Button variant="secondary" onClick={openReceive}>Receive Items</Button>
                <Button variant="primary" onClick={openCreate}>New Item</Button>
              </>
            )}
          </div>
        </div>

        {/* Same tab strip as Messaging and Leave: a white card holding the tabs. */}
        <div className="bg-white rounded shadow overflow-x-auto">
          <div className="flex min-w-max border-b border-gray-200">
            {TABS.map((t) => (
              <button
                key={t.value || "all"}
                type="button"
                onClick={() => setTypeTab(t.value)}
                className={`px-5 py-3 text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
                  typeTab === t.value
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-200"
                }`}
              >
                {t.label}
                <span className="ml-2 text-xs font-normal px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-500">{tabCount(t.value)}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white p-5 rounded shadow">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Input label="Search" name="search" value={filters.search} onChange={handleFilterChange} placeholder="Name or location" />
            <Input label="Category" name="category" value={filters.category} onChange={handleFilterChange} placeholder="e.g. Furniture" />
            <div className="flex items-end pb-2.5">
              <label className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                <input type="checkbox" checked={filters.low_stock === "true"} onChange={(e) => setFilters((f) => ({ ...f, low_stock: e.target.checked ? "true" : "" }))} className="accent-primary" />
                Low stock only (consumables)
              </label>
            </div>
          </div>
        </div>

        <DataTable
          columns={[
            {
              key: "name", label: "Item",
              render: (i) => (
                <div>
                  <p className="text-sm">{i.name}</p>
                  {/* <p className="text-sm text-gray-400">{i.category || "Uncategorized"}{i.location ? ` • ${i.location}` : ""}</p> */}
                </div>
              ),
            },
            {
              key: "item_type", label: "Type",
              render: (i) => (
                <span className={`px-2 inline-flex text-sm font-medium rounded-full ${TYPE_STYLES[i.item_type] || TYPE_STYLES.consumable}`}>
                  {isConsumable(i) ? "Consumable" : "Fixed Asset"}
                </span>
              ),
            },
            {
              key: "quantity", label: "On Hand",
              render: (i) => (
                <span className={`text-sm ${isLowStock(i) ? "text-red-600" : "text-gray-700"}`}>
                  {i.quantity_on_hand} {i.unit}
                  {isLowStock(i) && <span className="ml-1 text-xs">({i.quantity_on_hand === 0 ? "Out of stock" : "Low"})</span>}
                </span>
              ),
            },
            {
              // Assets: how many are in which condition. Consumables: when
              // to restock — condition isn't tracked for things that get used up.
              key: "condition", label: "Condition / Reorder",
              render: (i) => (isConsumable(i) ? (
                <span className="text-sm text-gray-500">
                  {i.reorder_level !== null && i.reorder_level !== undefined ? `Reorder at ${i.reorder_level} ${i.unit}` : "No reorder level"}
                </span>
              ) : (
                <div className="flex flex-wrap gap-1">
                  {CONDITIONS.filter((c) => (i.condition_breakdown?.[c.value] || 0) > 0).map((c) => (
                    <span key={c.value} className={`px-2 inline-flex text-sm font-medium rounded-full capitalize ${CONDITION_STYLES[c.value]}`}>{i.condition_breakdown[c.value]} {c.label}</span>
                  ))}
                  {i.quantity_on_hand === 0 && <span className="text-sm text-gray-300">—</span>}
                </div>
              )),
            },
            { key: "status", label: "Status", render: (i) => <span className={`px-2 inline-flex text-sm leading-5 font-semibold capitalize rounded-full ${i.status === "active" ? "bg-green-100 border border-green-300 text-green-500" : "bg-gray-100 border border-gray-300 text-gray-600"}`}>{i.status}</span> },
          ]}
          data={visibleItems}
          loading={loading}
          emptyMessage={typeTab === "asset" ? "No fixed assets found" : typeTab === "consumable" ? "No consumables found" : "No inventory items found"}
          renderActions={(i) => (
            <RowActions
              actions={[
                { label: 'View History', variant: 'primary', icon: ACTION_ICONS.view, hidden: !can("inventory.update"), onClick: () => openHistory(i) },
                { label: 'Record Movement', icon: ACTION_ICONS.copy, hidden: !can("inventory.update"), onClick: () => openTx(i) },
                { label: 'Edit Item', icon: ACTION_ICONS.edit, hidden: !can("inventory.update"), onClick: () => openEdit(i) },
                { label: 'Delete Item', variant: 'danger', icon: ACTION_ICONS.delete, hidden: !can("inventory.delete"), onClick: () => handleDelete(i) },
              ]}
            />
          )}
        />
      </div>

      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Item" : "New Item"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <Input label="Item Name" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Enter item name" />
              <Select
                label="Item Type"
                required
                value={form.item_type}
                onChange={(e) => setForm((f) => ({ ...f, item_type: e.target.value }))}
                options={ITEM_TYPES}
                // helperText={form.item_type === "asset"
                //   ? "Fixed asset — desks, projectors, equipment. Tracked by condition; not used up."
                //   : "Consumable — chalk, books, supplies. Runs down; tracked by quantity and reorder level."}
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Category" value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))} placeholder="e.g. Furniture" />
                <Input label="Unit" value={form.unit} onChange={(e) => setForm((f) => ({ ...f, unit: e.target.value }))} placeholder="pcs, kg, boxes…" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Quantity on Hand" type="number" min={0} disabled={modal.mode === "edit"} required value={form.quantity_on_hand} onChange={(e) => setForm((f) => ({ ...f, quantity_on_hand: e.target.value }))}
                  helperText={modal.mode === "edit" ? "Use 'Record Movement' to change stock" : undefined} />
                {form.item_type === "consumable" && (
                  <Input label="Reorder Level" type="number" min={0} value={form.reorder_level} onChange={(e) => setForm((f) => ({ ...f, reorder_level: e.target.value }))} placeholder="Optional" helperText="Flagged as low at or below this" />
                )}
              </div>
              <Input label="Location" value={form.location} onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))} placeholder="e.g. Store Room A" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {modal.mode !== "edit" && form.item_type === "asset" && (
                  <Select label="Initial Condition" value={form.condition} onChange={(e) => setForm((f) => ({ ...f, condition: e.target.value }))} options={CONDITIONS} />
                )}
                <Select label="Status" value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))} options={[{ value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }]} />
              </div>
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Add Item"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {txModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-lg">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Record Movement — {txModal.name}</h3>
              <button onClick={() => setTxModal(null)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSaveTx(); }} className="px-5 py-4 space-y-4">
              <p className="text-xs text-left text-gray-500">{isConsumable(txModal) ? "Consumable" : "Fixed asset"} — currently {txModal.quantity_on_hand} {txModal.unit} on hand.</p>
              <Select label="Type" required value={txForm.type} onChange={(e) => setTxForm((f) => ({ ...f, type: e.target.value }))} options={txTypesFor(txModal)} />
              <div className="gap-4 text-left">
                <div className={isConsumable(txModal) ? "" : "grid grid-cols-2 gap-4"}>
                  <Input label={txForm.type === "adjusted" ? (isConsumable(txModal) ? "Corrected Quantity (total on hand)" : "Corrected Quantity (for this condition)") : "Quantity"} type="number" min={0} required value={txForm.quantity} onChange={(e) => setTxForm((f) => ({ ...f, quantity: e.target.value }))} placeholder="Enter quantity" />
                  {!isConsumable(txModal) && (
                    <Select label="Condition" required value={txForm.condition} onChange={(e) => setTxForm((f) => ({ ...f, condition: e.target.value }))} options={CONDITIONS} />
                  )}
                </div>
                {!isConsumable(txModal) && (
                  <span className="text-xs text-left text-gray-500">
                    {`Current status: ${CONDITIONS.map((c) => `${txModal.condition_breakdown?.[c.value] || 0} ${c.label.toLowerCase()}`).join(", ")}`}
                  </span>
                )}
              </div>
              {txForm.type === "issued" && (
                <Input label={isConsumable(txModal) ? "Issued To / Used By" : "Assigned To"} value={txForm.issued_to} onChange={(e) => setTxForm((f) => ({ ...f, issued_to: e.target.value }))} placeholder="Class, department, or person" />
              )}
              <DatePicker label="Date" value={txForm.transaction_date} onChange={(e) => setTxForm((f) => ({ ...f, transaction_date: e.target.value }))} />
              <Input label="Notes" value={txForm.notes} onChange={(e) => setTxForm((f) => ({ ...f, notes: e.target.value }))} placeholder="Enter notes (optional)" />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={savingTx}>Save</Button>
                <Button type="button" variant="secondary" onClick={() => setTxModal(null)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {receiveModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-2xl">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Receive Items</h3>
              <button onClick={() => setReceiveModal(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleBulkReceive(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <DatePicker label="Delivery Date" value={receiveDate} onChange={(e) => setReceiveDate(e.target.value)} />

              {/* Built from the shared Select/NumberInput/Input components
                  rather than raw <select>/<input>, so this modal picks up the
                  same focus rings, search, sizing and error styling as every
                  other form — and the quantity field formats as you type. */}
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="text-sm font-medium text-gray-700">Items Received</label>
                  <Button type="button" variant="lightPrimary" size="xs" onClick={addReceiveLine}>+ Add Line</Button>
                </div>

                {receiveLines.map((line, idx) => (
                  <div key={idx} className="border border-gray-200 rounded p-3 bg-gray-50">
                    <div className="flex items-start justify-between mb-2">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Line {idx + 1}</span>
                      {receiveLines.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeReceiveLine(idx)}
                          className="text-gray-400 hover:text-red-500"
                          aria-label={`Remove line ${idx + 1}`}
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="md:col-span-2">
                        <Select
                          label="Item"
                          searchable
                          value={line.item_id}
                          onChange={(e) => updateReceiveLine(idx, "item_id", e.target.value)}
                          placeholder="Select item…"
                          options={items.map((i) => ({ value: i.id, label: `${i.name} (${i.unit}) — ${isConsumable(i) ? "Consumable" : "Asset"}` }))}
                        />
                      </div>
                      <NumberInput
                        label="Quantity"
                        allowDecimals={false}
                        value={line.quantity}
                        onChange={(e) => updateReceiveLine(idx, "quantity", e.target.value)}
                        placeholder="0"
                      />
                      {isConsumable(items.find((i) => i.id === line.item_id)) ? (
                        <p className="text-xs text-gray-500 self-end pb-2">Consumable — added to the quantity on hand.</p>
                      ) : (
                        <Select
                          label="Condition"
                          value={line.condition}
                          onChange={(e) => updateReceiveLine(idx, "condition", e.target.value)}
                          options={CONDITIONS}
                        />
                      )}
                      <div className="md:col-span-2">
                        <Input
                          label="Note"
                          value={line.notes}
                          onChange={(e) => updateReceiveLine(idx, "notes", e.target.value)}
                          placeholder="Optional — supplier, delivery note number, etc."
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={savingReceive}>Receive All</Button>
                <Button type="button" variant="secondary" onClick={() => setReceiveModal(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmDelete.isOpen} title="Delete Item" message={`Delete "${confirmDelete.name}"? This removes its history too.`} variant="danger" onConfirm={confirmDeleteItem} onClose={() => setConfirmDelete({ isOpen: false })} />
    </MainLayout>
  );
}
