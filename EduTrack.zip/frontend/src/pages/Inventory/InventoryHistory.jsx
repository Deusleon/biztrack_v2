import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { inventoryService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, DataTable, Button } from "../../components/ui";

const TYPE_STYLES = {
  received: "text-green-600", issued: "text-red-500", damaged: "text-red-500", lost: "text-red-500", adjusted: "text-gray-600",
};
const TX_TYPES = [
  { value: "", label: "All Types" }, { value: "received", label: "Received" }, { value: "issued", label: "Issued" },
  { value: "damaged", label: "Damaged" }, { value: "lost", label: "Lost" }, { value: "adjusted", label: "Adjusted" },
];

export default function InventoryHistory() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { showError } = useToast();
  const { formatDate } = usePreferences();

  const [items, setItems] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 20 });

  const itemFilter = searchParams.get("item_id") || "";
  const typeFilter = searchParams.get("type") || "";

  useEffect(() => { inventoryService.getItems({}).then((res) => { if (res.success) setItems(res.data); }); }, []);

  const fetchHistory = async (page = 1) => {
    try {
      setLoading(true);
      const res = await inventoryService.getTransactions({ item_id: itemFilter || undefined, type: typeFilter || undefined, page, limit: pagination.itemsPerPage });
      if (res.success) { setTransactions(res.data); setPagination((p) => ({ ...p, ...res.pagination })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { fetchHistory(1); }, [itemFilter, typeFilter]);

  const updateFilter = (key, value) => {
    const next = new URLSearchParams(searchParams);
    value ? next.set(key, value) : next.delete(key);
    setSearchParams(next);
  };

  const selectedItem = items.find((i) => i.id === itemFilter);

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Inventory History</h1>
            <p className="text-sm text-gray-500 mt-0.5">{selectedItem ? `Movements for "${selectedItem.name}"` : "Every stock movement across all items"}</p>
          </div>
          <Button
            onClick={() => navigate("/inventory")}
            variant="lightPrimary"
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to Inventory
          </Button>
        </div>

        <div className="bg-white p-5 rounded shadow">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Select label="Item" value={itemFilter} onChange={(e) => updateFilter("item_id", e.target.value)}
              options={[{ value: "", label: "All Items" }, ...items.map((i) => ({ value: i.id, label: i.name }))]} />
            <Select label="Type" value={typeFilter} onChange={(e) => updateFilter("type", e.target.value)} options={TX_TYPES} />
          </div>
        </div>

        <DataTable
          columns={[
            { key: "transaction_date", label: "Date", render: (h) => <span className="text-sm text-gray-600">{formatDate(h.transaction_date)}</span> },
            { key: "item", label: "Item", render: (h) => <span className="text-sm">{h.item?.name}</span> },
            { key: "type", label: "Type", render: (h) => <span className="text-sm text-gray-700 capitalize">{h.type}{h.issued_to ? ` — ${h.issued_to}` : ""}</span> },
            { key: "condition", label: "Condition", render: (h) => <span className="text-sm text-gray-600 capitalize">{h.condition || "—"}</span> },
            {
              key: "quantity", label: "Quantity",
              render: (h) => (
                <span className={`text-sm font-medium ${TYPE_STYLES[h.type]}`}>
                  {h.type === "adjusted" ? `= ${h.quantity}` : h.type === "received" ? `+${h.quantity}` : `-${h.quantity}`} {h.item?.unit}
                </span>
              ),
            },
            { key: "recordedBy", label: "Recorded By", render: (h) => <span className="text-sm text-gray-600">{h.recordedBy ? `${h.recordedBy.first_name} ${h.recordedBy.last_name}` : "—"}</span> },
            { key: "notes", label: "Notes", render: (h) => <span className="text-sm text-gray-500">{h.notes || "—"}</span> },
          ]}
          data={transactions}
          loading={loading}
          emptyMessage="No movements found"
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => fetchHistory(page)}
        />
      </div>
    </MainLayout>
  );
}
