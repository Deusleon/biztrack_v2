// frontend/src/pages/Payroll/PayrollDetail.jsx
import { useAuth } from "../../contexts/AuthContext";
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { payrollService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { NumberInput, Button, ConfirmModal, DataTable, RowActions, ACTION_ICONS } from "../../components/ui";
import { formatMoney } from "../../utils/money";

const STATUS_STYLES = { draft: "bg-gray-100 text-gray-600", processed: "bg-amber-100 text-amber-700", paid: "bg-green-100 text-green-700" };


export default function PayrollDetail() {
  const { can } = useAuth();
  const { id } = useParams();
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();

  const [period, setPeriod] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [paying, setPaying] = useState(false);
  const [confirmProcess, setConfirmProcess] = useState(false);
  const [confirmPay, setConfirmPay] = useState(false);

  const [editItem, setEditItem] = useState(null);
  const [editForm, setEditForm] = useState({ basic_salary: 0, allowances: [], deductions: [] });
  const [savingItem, setSavingItem] = useState(false);
  const [confirmRemoveItem, setConfirmRemoveItem] = useState({ isOpen: false });

  const load = async () => {
    try {
      setLoading(true);
      const res = await payrollService.getPeriodById(id);
      if (res.success) setPeriod(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [id]);

  const handleGenerate = async () => {
    try {
      setGenerating(true);
      const res = await payrollService.generateItems(id);
      if (res.success) { showSuccess(res.message); load(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setGenerating(false); }
  };

  const handleProcess = async () => {
    try {
      setProcessing(true);
      const res = await payrollService.processPeriod(id);
      if (res.success) { showSuccess(res.message); load(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setProcessing(false); setConfirmProcess(false); }
  };

  const handlePay = async () => {
    try {
      setPaying(true);
      const res = await payrollService.markPaid(id);
      if (res.success) { showSuccess(res.message); load(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setPaying(false); setConfirmPay(false); }
  };

  const openEditItem = (item) => {
    setEditItem(item);
    setEditForm({ basic_salary: item.basic_salary, allowances: item.allowances || [], deductions: item.deductions || [] });
  };

  const addLine = (type) => setEditForm((f) => ({ ...f, [type]: [...f[type], { label: "", amount: "" }] }));
  const updateLine = (type, idx, field, value) => setEditForm((f) => ({ ...f, [type]: f[type].map((l, i) => (i === idx ? { ...l, [field]: value } : l)) }));
  const removeLine = (type, idx) => setEditForm((f) => ({ ...f, [type]: f[type].filter((_, i) => i !== idx) }));

  const previewGross = Number(editForm.basic_salary || 0) + editForm.allowances.reduce((s, a) => s + Number(a.amount || 0), 0);
  const previewDeductions = editForm.deductions.reduce((s, d) => s + Number(d.amount || 0), 0);
  const previewNet = previewGross - previewDeductions;

  const handleSaveItem = async () => {
    try {
      setSavingItem(true);
      const payload = {
        basic_salary: Number(editForm.basic_salary),
        allowances: editForm.allowances.filter((a) => a.label).map((a) => ({ label: a.label, amount: Number(a.amount || 0) })),
        deductions: editForm.deductions.filter((d) => d.label).map((d) => ({ label: d.label, amount: Number(d.amount || 0) })),
      };
      const res = await payrollService.updateItem(editItem.id, payload);
      if (res.success) { showSuccess("Payslip updated"); setEditItem(null); load(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSavingItem(false); }
  };

  const handleRemoveItem = (item) => setConfirmRemoveItem({ isOpen: true, id: item.id });
  const confirmRemove = async () => {
    try {
      await payrollService.deleteItem(confirmRemoveItem.id);
      showSuccess("Payslip removed");
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmRemoveItem({ isOpen: false });
  };

  if (loading) return <MainLayout><div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div></MainLayout>;
  if (!period) return <MainLayout><div className="bg-white p-10 rounded shadow text-center text-gray-400">Payroll period not found.</div></MainLayout>;

  const isDraft = period.status === "draft";
  const totalNet = (period.items || []).reduce((s, i) => s + Number(i.net_pay), 0);

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">{period.month_name} {period.year} Payroll</h1>
            {/* <p className="text-sm text-gray-500 mt-0.5">
              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded capitalize ${STATUS_STYLES[period.status]}`}>{period.status}</span>
            </p> */}
          </div>
          <div className="flex items-center gap-2">
            {isDraft && can("payroll.create") && <Button onClick={handleGenerate} loading={generating} variant="secondary">Generate Payslips</Button>}
            {isDraft && can("payroll.update") && period.items?.length > 0 && <Button onClick={() => setConfirmProcess(true)} loading={processing}>Process</Button>}
            {period.status === "processed" && can("payroll.update") && <Button onClick={() => setConfirmPay(true)} loading={paying}>Mark Paid</Button>}
            <Button
              onClick={() => navigate("/payroll")}
              variant="lightPrimary"
              className="animate-pulse"
              leftIcon={
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 19l-7-7m0 0l7-7m-7 7h18"
                  />
                </svg>
              }>Back to Payroll
            </Button>
          </div>
        </div>

        {/* Stats Cards — left-aligned figure, icon on the right, matching
            every other module's cards. These were the only ones still
            without an icon. */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-500">Staff</p>
                <p className="text-2xl text-left font-bold text-primary mt-1">{period.items?.length || 0}</p>
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-500">Total Net Pay</p>
                <p className="text-2xl text-left font-bold text-green-600 mt-1">{formatMoney(totalNet)}</p>
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg className="w-8 h-8 text-green-500 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-500">Period</p>
                <p className="text-2xl text-left font-bold text-indigo-600 mt-1">{period.month_name}</p>
                <p className="text-xs text-left text-gray-400">{period.year}</p>
              </div>
              <div className="bg-indigo-100 p-3 rounded">
                <svg className="w-8 h-8 text-indigo-500 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-500">Status</p>
                <p className={`text-2xl text-left font-bold mt-1 capitalize ${
                  period.status === "paid" ? "text-green-500"
                    : period.status === "processed" ? "text-amber-500" : "text-gray-500"
                }`}>{period.status}</p>
              </div>
              <div className={`p-3 rounded ${
                period.status === "paid" ? "bg-green-100"
                  : period.status === "processed" ? "bg-amber-100" : "bg-gray-100"
              }`}>
                <svg className={`w-8 h-8 opacity-45 ${
                  period.status === "paid" ? "text-green-500"
                    : period.status === "processed" ? "text-amber-500" : "text-gray-500"
                }`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* The explanation that used to sit inside the Status card — it was
            a paragraph of prose in a slot meant for a single figure. */}
        <div className="bg-gray-50 border border-gray-200 rounded px-4 py-2.5 text-sm text-left text-gray-600">
          {period.status === "draft" && "Editable — generate payslips, adjust allowances and deductions, then process."}
          {period.status === "processed" && "Locked — ready to mark as paid."}
          {period.status === "paid" && `Paid ${period.paid_at ? new Date(period.paid_at).toLocaleDateString() : ""} — recorded in Expenses.`}
        </div>

        {/* Shared DataTable, so the payslip list matches every other module's
            alignment, empty state and Actions column. */}
        <DataTable
          columns={[
            {
              key: "staff", label: "Staff",
              render: (item) => (
                <div>
                  <div className="text-sm text-gray-900">{item.user?.first_name} {item.user?.last_name}</div>
                  <div className="text-xs text-gray-400">{item.staff?.designation || item.staff?.department || ""}</div>
                </div>
              ),
            },
            { key: "basic_salary", label: "Basic", align: "right", render: (item) => <span className="text-sm text-gray-700">{formatMoney(item.basic_salary)}</span> },
            {
              key: "allowances", label: "Allowances", align: "right",
              render: (item) => {
                const total = (item.allowances || []).reduce((s, a) => s + Number(a.amount), 0);
                return total > 0
                  ? <span className="text-sm text-green-600">+{formatMoney(total)}</span>
                  : <span className="text-sm text-gray-300">—</span>;
              },
            },
            {
              key: "deductions", label: "Deductions", align: "right",
              render: (item) => {
                const total = (item.deductions || []).reduce((s, d) => s + Number(d.amount), 0);
                return total > 0
                  ? <span className="text-sm text-red-500">-{formatMoney(total)}</span>
                  : <span className="text-sm text-gray-300">—</span>;
              },
            },
            { key: "net_pay", label: "Net Pay", align: "right", render: (item) => <span className="text-sm font-medium text-gray-900">{formatMoney(item.net_pay)}</span> },
          ]}
          data={period.items || []}
          rowId="id"
          emptyMessage={isDraft ? 'No payslips yet — click "Generate Payslips" to create one for every active staff member.' : "No payslips in this period."}
          // Payslips are only editable while the run is still a draft;
          // once processed the figures are a financial record.
          renderActions={isDraft ? (item) => (
            <RowActions
              actions={[
                { label: "Edit Payslip", variant: "primary", icon: ACTION_ICONS.edit, hidden: !can("payroll.update"), onClick: () => openEditItem(item) },
                { label: "Remove from Run", variant: "danger", icon: ACTION_ICONS.remove, hidden: !can("payroll.delete"), onClick: () => handleRemoveItem(item) },
              ]}
            />
          ) : undefined}
        />
      </div>

      {editItem && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-lg">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{editItem.user?.first_name} {editItem.user?.last_name} — Payslip</h3>
              <button onClick={() => setEditItem(null)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <div className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <NumberInput label="Basic Salary (TZS)" value={editForm.basic_salary} onChange={(e) => setEditForm((f) => ({ ...f, basic_salary: e.target.value }))} />

              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                  <label className="text-xs font-medium text-gray-700">Allowances</label>
                  <button type="button" onClick={() => addLine("allowances")} className="text-xs text-primary hover:underline">+ Add</button>
                </div>
                {editForm.allowances.map((a, i) => (
                  <div key={i} className="flex gap-2 mb-2">
                    <input value={a.label} onChange={(e) => updateLine("allowances", i, "label", e.target.value)} placeholder="e.g. Housing" className="flex-1 border border-gray-300 rounded px-3 py-1.5 text-sm" />
                    <div className="w-32 flex-shrink-0"><NumberInput value={a.amount} onChange={(e) => updateLine("allowances", i, "amount", e.target.value)} placeholder="Amount" /></div>
                    <button type="button" onClick={() => removeLine("allowances", i)} className="text-red-500 text-xs px-2">✕</button>
                  </div>
                ))}
              </div>

              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                  <label className="text-xs font-medium text-gray-700">Deductions</label>
                  <button type="button" onClick={() => addLine("deductions")} className="text-xs text-primary hover:underline">+ Add</button>
                </div>
                {editForm.deductions.map((d, i) => (
                  <div key={i} className="flex gap-2 mb-2">
                    <input value={d.label} onChange={(e) => updateLine("deductions", i, "label", e.target.value)} placeholder="e.g. NSSF" className="flex-1 border border-gray-300 rounded px-3 py-1.5 text-sm" />
                    <div className="w-32 flex-shrink-0"><NumberInput value={d.amount} onChange={(e) => updateLine("deductions", i, "amount", e.target.value)} placeholder="Amount" /></div>
                    <button type="button" onClick={() => removeLine("deductions", i)} className="text-red-500 text-xs px-2">✕</button>
                  </div>
                ))}
              </div>

              <div className="bg-gray-50 rounded p-3 text-sm space-y-1">
                <div className="flex justify-between"><span className="text-gray-500">Gross Pay</span><span className="text-gray-900">{formatMoney(previewGross)}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Total Deductions</span><span className="text-red-500">-{formatMoney(previewDeductions)}</span></div>
                <div className="flex justify-between font-semibold border-t border-gray-200 pt-1"><span className="text-gray-900">Net Pay</span><span className="text-primary">{formatMoney(previewNet)}</span></div>
              </div>

              <div className="flex justify-end gap-3 pt-1">
                <Button onClick={handleSaveItem} loading={savingItem}>Save</Button>
                <Button variant="secondary" onClick={() => setEditItem(null)}>Cancel</Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmProcess} title="Process Payroll" message={`Lock ${period.month_name} ${period.year} for editing and mark it ready to pay?`} onConfirm={handleProcess} onClose={() => setConfirmProcess(false)} />
      <ConfirmModal isOpen={confirmPay} title="Mark Payroll Paid" message={`Finalize ${period.month_name} ${period.year} and record ${formatMoney(totalNet)} in Expenses under "Salaries & Wages"?`} onConfirm={handlePay} onClose={() => setConfirmPay(false)} />
      <ConfirmModal isOpen={confirmRemoveItem.isOpen} title="Remove Payslip" message="Remove this staff member from the payroll period?" variant="danger" onConfirm={confirmRemove} onClose={() => setConfirmRemoveItem({ isOpen: false })} />
    </MainLayout>
  );
}