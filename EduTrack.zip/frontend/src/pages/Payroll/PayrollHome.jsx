import { useAuth } from "../../contexts/AuthContext";
import PayrollList from "./PayrollList";
import MyPayslips from "./MyPayslips";

export default function PayrollHome() {
  const { can } = useAuth();
  // Whoever may run payroll sees the payroll screen; everyone else sees their own payslips.
  return can("payroll.view") ? <PayrollList /> : <MyPayslips />;
}
