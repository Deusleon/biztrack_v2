import { useAuth } from "../../contexts/AuthContext";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { useCampus } from "../../contexts/CampusContext";
import { payrollService, campusService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Button, ConfirmModal, DataTable, RowActions, ACTION_ICONS } from "../../components/ui";
import { formatMoney } from "../../utils/money";

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
// Same pill treatment as every other module's status column: rounded-full
// with a matching border, not a plain square chip.
const STATUS_STYLES = {
  draft: "bg-gray-100 border border-gray-300 text-gray-500",
  processed: "bg-amber-100 border border-amber-300 text-amber-500",
  paid: "bg-green-100 border border-green-300 text-green-500",
};


export default function PayrollList() {
  const { can } = useAuth();
  const navigate = useNavigate();
  const { currentCampusId } = useCampus();
  const { showSuccess, showError } = useToast();

  const [periods, setPeriods] = useState([]);
  const [campuses, setCampuses] = useState([]);
  const [loading, setLoading] = useState(true);

  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ month: new Date().getMonth() + 1, year: new Date().getFullYear(), campus_id: "" });
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState({ isOpen: false });

  // Payroll periods are stamped with a plain calendar year, and school
  // years run January to December — so the selected academic year's base
  // year IS the payroll year. Without this the list showed every period
  // ever run, regardless of the year selected in the header.
  const { currentAcademicYear } = useAcademicYear();
  const selectedYear = parseInt(String(currentAcademicYear || "").match(/\d{4}/)?.[0], 10) || new Date().getFullYear();

  const load = async () => {
    try {
      setLoading(true);
      const res = await payrollService.getPeriods({ year: selectedYear });
      if (res.success) setPeriods(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [selectedYear]);
  useEffect(() => { campusService.getAll({ limit: 100 }).then((res) => { if (res.success) { setCampuses(res.data); if (res.data.length === 1) setForm((f) => ({ ...f, campus_id: res.data[0].id })); } }); }, []);

  const openCreate = () => {
    // Defaults to the year being viewed, so a period isn't accidentally
    // created in a different year from the one on screen.
    setForm({ month: new Date().getMonth() + 1, year: selectedYear, campus_id: currentCampusId || campuses[0]?.id || "" });
    setModal(true);
  };

  const handleCreate = async () => {
    try {
      setSaving(true);
      // Sent explicitly rather than from form state: the header year can
      // change while the dialog is open, and a period created for the old
      // year would vanish from the list the moment it saved.
      const res = await payrollService.createPeriod({ ...form, year: selectedYear });
      if (res.success) { showSuccess(res.message); setModal(false); navigate(`/payroll/${res.data.id}`); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (p) => setConfirmDelete({ isOpen: true, id: p.id, label: `${p.month_name} ${p.year}` });
  const confirmDeletePeriod = async () => {
    try {
      await payrollService.deletePeriod(confirmDelete.id);
      showSuccess("Payroll period deleted");
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmDelete({ isOpen: false });
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Payroll</h1>
            <p className="text-sm text-gray-500 mt-0.5">Monthly payroll runs</p>
          </div>
          {can("payroll.create") && <Button onClick={openCreate}>New Payroll Period</Button>}
        </div>

        {/* The shared DataTable rather than a hand-rolled <table>, so this
            page picks up the same loading spinner, empty state, alignment
            rules and Actions column as every other module. */}
        <DataTable
          columns={[
            {
              key: "period", label: "Period",
              render: (p) => (
                <div>
                  <div className="text-sm font-medium text-gray-900">{p.month_name} {p.year}</div>
                  {p.campus?.name && <div className="text-xs text-gray-400">{p.campus.name}</div>}
                </div>
              ),
            },
            { key: "staff_count", label: "Staff", align: "center", render: (p) => <span className="text-sm text-gray-600">{p.staff_count}</span> },
            { key: "total_net_pay", label: "Total Net Pay", align: "right", render: (p) => <span className="text-sm font-medium text-gray-900">{formatMoney(p.total_net_pay)}</span> },
            {
              key: "status", label: "Status", align: "center",
              render: (p) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${STATUS_STYLES[p.status]}`}>
                  {p.status}
                </span>
              ),
            },
          ]}
          data={periods}
          loading={loading}
          rowId="id"
          emptyMessage="No payroll periods yet"
          renderActions={(p) => (
            <RowActions
              actions={[
                { label: "View Payslips", variant: "primary", icon: ACTION_ICONS.view, hidden: !can("payroll.update"), onClick: () => navigate(`/payroll/${p.id}`) },
                // A processed or paid run is a financial record — only a
                // draft can still be thrown away.
                { label: "Delete Period", variant: "danger", icon: ACTION_ICONS.delete, hidden: !can("payroll.delete") || p.status !== "draft", onClick: () => handleDelete(p) },
              ]}
            />
          )}
        />
      </div>

      {modal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <div className="text-left">
                <h3 className="text-base font-semibold">New Payroll Period</h3>
                <p className="text-xs text-gray-500 mt-0.5">Opens a draft you can generate payslips into</p>
              </div>
              <button onClick={() => setModal(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleCreate(); }} className="px-5 py-5 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Select label="Month" required value={form.month} onChange={(e) => setForm((f) => ({ ...f, month: Number(e.target.value) }))}
                  options={MONTHS.map((m, i) => ({ value: i + 1, label: m }))} />
                {/* Locked to the year being viewed. A period created for
                    another year would immediately disappear from the list
                    that created it, which reads as the save having failed. */}
                <Select label="Year" required value={selectedYear} disabled
                  options={[{ value: selectedYear, label: String(selectedYear) }]} />
              </div>
              <Select
                label="Campus"
                value={form.campus_id}
                onChange={(e) => setForm((f) => ({ ...f, campus_id: e.target.value }))}
                disabled={campuses.length <= 1}
                helperText={campuses.length > 1 ? "Leave as All campuses to pay every staff member in one run" : "Your organization has a single campus"}
                options={[{ value: "", label: "All campuses" }, ...campuses.map((c) => ({ value: c.id, label: c.name }))]}
              />
              <p className="text-xs text-left text-gray-500 bg-gray-50 border border-gray-200 rounded px-3 py-2.5 leading-relaxed">
                A period starts as a <strong>draft</strong>. Payslips are generated from each active staff member's salary,
                and stay editable until you process the run.
              </p>
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>Create</Button>
                <Button type="button" variant="secondary" onClick={() => setModal(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmDelete.isOpen} title="Delete Payroll Period" message={`Delete ${confirmDelete.label}? This removes all its payslips.`} variant="danger" onConfirm={confirmDeletePeriod} onClose={() => setConfirmDelete({ isOpen: false })} />
    </MainLayout>
  );
}