import { useState, useEffect } from "react";
import { useToast } from "../../contexts/ToastContext";
import { payrollService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { formatMoney } from "../../utils/money";



export default function MyPayslips() {
  const { showError } = useToast();
  const [payslips, setPayslips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState(null);

  useEffect(() => {
    payrollService.getMyPayslips()
      .then((res) => { if (res.success) setPayslips(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="text-left">
          <h1 className="text-xl font-bold text-gray-900">My Payslips</h1>
          <p className="text-sm text-gray-500 mt-0.5">Your pay history</p>
        </div>

        {loading ? (
          <div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
        ) : payslips.length === 0 ? (
          <div className="bg-white p-10 rounded shadow text-center text-gray-400 text-sm">No payslips yet.</div>
        ) : (
          <div className="space-y-3">
            {payslips.map((p) => (
              <div key={p.id} className="bg-white rounded shadow overflow-hidden">
                <button onClick={() => setExpandedId(expandedId === p.id ? null : p.id)} className="w-full flex flex-wrap items-center justify-between gap-2 px-5 py-4 text-left hover:bg-gray-50">
                  <div>
                    <p className="text-sm font-semibold text-gray-900">{p.month_name} {p.period.year}</p>
                    <p className="text-xs text-gray-400 capitalize">{p.period.status}</p>
                  </div>
                  <p className="text-lg font-bold text-primary">{formatMoney(p.net_pay)}</p>
                </button>
                {expandedId === p.id && (
                  <div className="px-5 pb-4 border-t border-gray-100 pt-3 text-sm space-y-2">
                    <div className="flex justify-between"><span className="text-gray-500">Basic Salary</span><span className="text-gray-900">{formatMoney(p.basic_salary)}</span></div>
                    {(p.allowances || []).map((a, i) => (
                      <div key={i} className="flex justify-between"><span className="text-gray-500">+ {a.label}</span><span className="text-green-600">{formatMoney(a.amount)}</span></div>
                    ))}
                    <div className="flex justify-between font-medium border-t border-gray-100 pt-2"><span className="text-gray-700">Gross Pay</span><span className="text-gray-900">{formatMoney(p.gross_pay)}</span></div>
                    {(p.deductions || []).map((d, i) => (
                      <div key={i} className="flex justify-between"><span className="text-gray-500">- {d.label}</span><span className="text-red-500">{formatMoney(d.amount)}</span></div>
                    ))}
                    <div className="flex justify-between font-semibold border-t border-gray-100 pt-2"><span className="text-gray-900">Net Pay</span><span className="text-primary">{formatMoney(p.net_pay)}</span></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
