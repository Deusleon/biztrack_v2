import { useAuth } from '../contexts/AuthContext';
import { Navigate } from 'react-router-dom';
import MainLayout from '../components/MainLayout';

const PlaceholderPage = ({ title, description, icon }) => {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
          <p className="text-sm text-gray-500 mt-1">{description}</p>
        </div>
        <div className="bg-white rounded shadow-md p-12 text-center">
          <div className="text-primary mb-4">
            {icon}
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">{title} Coming Soon</h3>
          <p className="text-gray-600 mb-4">This feature is under development</p>
          <div className="inline-flex items-center px-4 py-2 bg-primary bg-opacity-10 text-primary rounded">
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            Check back soon for updates
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

// NOTE: Exams and Results used to be placeholders here. They now have a
// real implementation under ./Exams — see App.jsx, which imports
// { ExamList, MarksEntry, ResultsHome, ReportCard } from './Exams' instead.

// NOTE: Fees used to be a placeholder here. It now has a real implementation
// under ./Fees — see App.jsx, which imports
// { FeeStructureList, RecordPayment, FeeStatus, StudentFeeSummary, PaymentReceipt } from './Fees' instead.

export const Library = () => (
  <PlaceholderPage
    title="Library Management"
    description="Manage library books and circulation"
    icon={
      <svg className="w-20 h-20 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
      </svg>
    }
  />
);

export const Transport = () => (
  <PlaceholderPage
    title="Transport Management"
    description="Manage school transport and routes"
    icon={
      <svg className="w-20 h-20 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
      </svg>
    }
  />
);

export const Hostel = () => (
  <PlaceholderPage
    title="Hostel Management"
    description="Manage hostel rooms and allocation"
    icon={
      <svg className="w-20 h-20 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
      </svg>
    }
  />
);

export const Reports = () => (
  <PlaceholderPage
    title="Reports & Analytics"
    description="Generate and view comprehensive reports"
    icon={
      <svg className="w-20 h-20 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
      </svg>
    }
  />
);

// Settings is now a full component, imported separately
export { default as Settings } from './Settings';

// NOTE: Notifications used to be a placeholder here. It now has a real
// implementation at ./NotificationList — see App.jsx.

// NOTE: Messages used to be a placeholder here. It now has a real
// implementation under ./Messages — see App.jsx.