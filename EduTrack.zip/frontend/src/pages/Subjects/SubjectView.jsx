import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { subjectService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { ConfirmModal, Button } from "../../components/ui";

export default function SubjectView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();

  const [subject, setSubject] = useState(null);
  const [stats, setStats] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [loading, setLoading] = useState(true);
  const [confirmModal, setConfirmModal] = useState({
    isOpen: false,
    action: null,
  });

  useEffect(() => {
    fetchSubject();
    fetchStats();
  }, [id]);

  const fetchSubject = async () => {
    try {
      setLoading(true);
      const response = await subjectService.getById(id);
      if (response.success) setSubject(response.data);
      else navigate("/subjects");
    } catch {
      navigate("/subjects");
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await subjectService.getStats(id);
      if (response.success) setStats(response.data);
    } catch { }
  };

  const handleConfirm = async () => {
    try {
      if (confirmModal.action === "deactivate") {
        await subjectService.delete(id);
        showSuccess("Subject deactivated");
        navigate("/subjects");
      } else if (confirmModal.action === "reactivate") {
        await subjectService.reactivate(id);
        showSuccess("Subject reactivated");
        fetchSubject();
      }
    } catch (err) {
      showError(err.message || "Action failed");
    }
    setConfirmModal({ isOpen: false, action: null });
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-sm text-gray-500 mt-2">Loading subject...</p>
        </div>
      </MainLayout>
    );
  }

  if (!subject) return null;


  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">View Subject</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {subject.name} - {subject.code}
            </p>
          </div>
          <Button
            variant="lightPrimary"
            onClick={() => navigate("/subjects")}
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }
          >
            Back to List
          </Button>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">Classes Taking</p>
                  <p className="text-2xl text-left font-bold text-primary mt-1">
                    {stats.classes_taking ?? 0}
                  </p>
                </div>
                <div className="bg-primary-15 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-primary opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"
                    />
                  </svg>
                </div>
              </div>
            </div>
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">
                    Students Taking
                  </p>
                  <p className="text-2xl text-left font-bold text-indigo-600 mt-1">
                    {stats.students_taking ?? 0}
                  </p>
                </div>
                <div className="bg-indigo-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-indigo-600 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                    />
                  </svg>
                </div>
              </div>
            </div>
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">
                    Average Perfomance
                  </p>
                  <p className="text-2xl text-left font-bold text-green-600 mt-1">
                    {stats.average_performance ?? 0}%
                  </p>
                </div>
                <div className="bg-green-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-green-600 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                    />
                  </svg>
                </div>
              </div>
            </div>
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">
                    Average Grade
                  </p>
                  <p className="text-2xl text-left font-bold text-amber-600 mt-1">
                    {stats.average_grade ?? "—"}
                  </p>
                </div>
                <div className="bg-amber-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-amber-600 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        {(can("academics.update") || can("academics.delete")) && (
          <div className="flex items-center gap-3">
            {can("academics.update") && <Button variant="lightPrimary" onClick={() => navigate(`/subjects/${id}/edit`)}>
              Edit Subject
            </Button>}
            {subject.status === "inactive" ? (can("academics.update") ? (
              <Button
                variant="lightSuccess"
                onClick={() =>
                  setConfirmModal({
                    isOpen: true,
                    action: "reactivate",
                    title: "Reactivate Subject",
                    message: "Reactivate this subject?",
                    variant: "success",
                  })
                }
              >
                Reactivate
              </Button>
            ) : null) : (can("academics.delete") ? (
              <Button
                variant="lightDanger"
                onClick={() =>
                  setConfirmModal({
                    isOpen: true,
                    action: "deactivate",
                    title: "Deactivate Subject",
                    message: "Deactivate this subject?",
                    variant: "danger",
                  })
                }
              >
                Deactivate
              </Button>
            ) : null)}
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded shadow">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {["overview", "statistics"].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-5 py-3 text-sm font-medium capitalize border-b-2 transition-colors ${activeTab === tab ? "border-primary text-primary" : "border-transparent text-gray-500 hover:text-gray-700"}`}
                >
                  {tab}
                </button>
              ))}
            </nav>
          </div>

          <div className="px-5 py-4 text-left">
            {/* Overview Tab */}
            {activeTab === "overview" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Subject Information
                    </h3>
                    <div className="grid items-center text-left grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                      <p className="text-xs text-gray-500">Subject Name</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900">{subject.name}</p>
                      <p className="text-xs text-gray-500">Code</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900">
                        {subject.code}
                      </p>
                      <p className="text-xs text-gray-500">Credits</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900">
                        {subject.credits ?? "Not set"}
                      </p>
                      <p className="text-xs text-gray-500">Type</p>
                      <p>:</p>
                      <p>
                        <span
                          className={`text-xs font-semibold px-2 py-0.5 rounded-full ${subject.is_elective ? "bg-indigo-100 border border-indigo-300 text-indigo-500" : "bg-amber-100 border border-amber-300 text-amber-600"}`}
                        >
                          {subject.is_elective ? "Elective" : "Compulsory"}
                        </span>
                      </p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-sm font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Campus & Status
                    </h3>
                    <div className="grid items-center text-left grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-4">
                      <p className="text-xs text-gray-500">Campus</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900">
                        {subject.campus?.name || "All Campuses"}
                      </p>
                      <p className="text-xs text-gray-500">Status</p>
                      <p>:</p>
                      <p>
                        <span
                          className={`text-xs font-semibold px-2 py-0.5 rounded-full capitalize ${subject.status === "active" ? "bg-green-100 border border-green-300 text-green-500" : "bg-red-100 border border-red-300 text-red-500"}`}
                        >
                          {subject.status}
                        </span>
                      </p>
                      <p className="text-xs text-gray-500">Created</p>
                      <p>:</p>
                      <p className="text-sm text-gray-900">
                        {formatDate(subject.createdAt)}
                      </p>
                    </div>
                  </div>
                </div>
                {subject.description && (
                  <div>
                    <h3 className="text-sm font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                      Description
                    </h3>
                    <p className="text-sm text-gray-600 rounded p-1.5">
                      {subject.description}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Statistics Tab */}
            {activeTab === "statistics" && (
              <div>
                {stats ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {[
                      { label: "Classes Taking", value: stats.classes_taking ?? 0 },
                      { label: "Students Taking", value: stats.students_taking ?? 0 },
                      { label: "Credits", value: subject.credits ?? "—" },
                      {
                        label: "Timetable Slots / Week",
                        value: stats.timetable_slots ?? 0,
                      },
                      {
                        label: "Grades Recorded",
                        value: stats.grades_recorded ?? 0,
                      },
                      {
                        label: "Average Grade",
                        value: stats.average_grade ?? "—",
                      },
                      {
                        label: "Average Performance",
                        value: `${stats.average_performance ?? 0}%`,
                      },
                    ].map((s) => (
                      <div key={s.label} className="bg-gray-50 rounded p-4">
                        <p className="text-xs text-gray-500 mb-1">{s.label}</p>
                        <p className="text-xl font-bold text-gray-900">
                          {s.value}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">
                    No statistics available
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ isOpen: false, action: null })}
        onConfirm={handleConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
      />
    </MainLayout>
  );
}
