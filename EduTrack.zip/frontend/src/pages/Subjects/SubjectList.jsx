import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { subjectService, campusService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { Select, Input, DataTable, ConfirmModal, Button, RowActions, ACTION_ICONS, ActionLink } from "../../components/ui";
import Icon from "../../components/ui/Icon";

export default function SubjectList() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();

  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [campuses, setCampuses] = useState([]);
  const [selectedSubjects, setSelectedSubjects] = useState([]);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false, action: null, ids: [] });
  const [filters, setFilters] = usePersistedState("filters", {
    search: "", status: "", campus_id: "", is_elective: "",
    sortBy: "name", sortOrder: "ASC",
  });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 10 });

  useEffect(() => { fetchSubjects(); fetchCampuses(); }, [filters, pagination.currentPage]);

  const fetchSubjects = async () => {
    try {
      setLoading(true);
      const response = await subjectService.getAll({
        ...filters, page: pagination.currentPage, limit: pagination.itemsPerPage,
      });
      if (response.success) {
        setSubjects(response.data);
        setPagination((p) => ({ ...p, ...response.pagination }));
      }
    } catch (err) { showError(err.message || "Failed to fetch subjects"); }
    finally { setLoading(false); }
  };

  const fetchCampuses = async () => {
    try {
      const response = await campusService.getAll({ limit: 100 });
      if (response.success) setCampuses(response.data);
    } catch {}
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((f) => ({ ...f, [name]: value }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const handleSelectAll = (e) => setSelectedSubjects(e.target.checked ? subjects.map((s) => s.id) : []);
  const handleSelectOne = (id) => setSelectedSubjects((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);

  const handleDelete = (id) => setConfirmModal({ isOpen: true, action: "delete", ids: [id], title: "Deactivate Subject", message: "Deactivate this subject?", variant: "danger" });
  const handleBulkAction = (status) => {
    if (selectedSubjects.length === 0) return;
    setConfirmModal({ isOpen: true, action: "bulk", ids: selectedSubjects, status, title: `${status === "active" ? "Activate" : "Deactivate"} Subjects`, message: `${status === "active" ? "Activate" : "Deactivate"} ${selectedSubjects.length} subject(s)?`, variant: status === "active" ? "success" : "danger" });
  };

  const handleConfirm = async () => {
    try {
      if (confirmModal.action === "delete") {
        await subjectService.delete(confirmModal.ids[0]);
        showSuccess("Subject deactivated");
      } else if (confirmModal.action === "bulk") {
        await subjectService.bulkUpdateStatus({ ids: confirmModal.ids, status: confirmModal.status });
        showSuccess(`${confirmModal.ids.length} subject(s) updated`);
        setSelectedSubjects([]);
      }
      fetchSubjects();
    } catch (err) { showError(err.message || "Action failed"); }
    setConfirmModal({ isOpen: false, action: null, ids: [] });
  };

  const handleReactivate = async (id) => {
    try { await subjectService.reactivate(id); showSuccess("Subject reactivated"); fetchSubjects(); }
    catch (err) { showError(err.message || "Failed to reactivate"); }
  };

  const totalSubjects = pagination.totalItems;
  const activeCount = subjects.filter((s) => s.status === "active").length;
  const electiveCount = subjects.filter((s) => s.is_elective).length;
  const compulsoryCount = subjects.filter((s) => !s.is_elective).length;

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Subjects</h1>
            <p className="text-sm text-gray-500 mt-0.5">Manage curriculum subjects</p>
          </div>
          {can("academics.create") && (
            <ActionLink to="/subjects/add" variant="primary">Add Subject</ActionLink>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Total Subjects</p>
                <p className="text-2xl text-left font-bold text-primary mt-1">{totalSubjects}</p>
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Active</p>
                <p className="text-2xl text-left font-bold text-green-600 mt-1">{activeCount}</p>
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg className="w-8 h-8 text-green-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Elective</p>
                <p className="text-2xl text-left font-bold text-indigo-600 mt-1">{electiveCount}</p>
              </div>
              <div className="bg-indigo-100 p-3 rounded">
                <svg className="w-8 h-8 text-indigo-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Compulsory</p>
                <p className="text-2xl text-left font-bold text-amber-600 mt-1">{compulsoryCount}</p>
              </div>
              <div className="bg-amber-100 p-3 rounded">
                <svg className="w-8 h-8 text-amber-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-5 rounded shadow">
          <form onSubmit={(e) => { e.preventDefault(); fetchSubjects(); }} className="grid grid-cols-2 md:grid-cols-6 gap-4">
            <div className="md:col-span-2">
              <Input
                label="Search"
                name="search"
                value={filters.search}
                onChange={handleFilterChange}
                placeholder="Search by name or code..."
                leftIcon={
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                }
              />
            </div>
            <div>
              <Select
                label="Status"
                name="status"
                value={filters.status}
                onChange={handleFilterChange}
                options={[
                  { value: "", label: "All Statuses" },
                  { value: "active", label: "Active" },
                  { value: "inactive", label: "Inactive" },
                ]}
              />
            </div>
            <div>
              <Select
                label="Campus"
                name="campus_id"
                value={filters.campus_id}
                onChange={handleFilterChange}
                options={[
                  { value: "", label: "All Campuses" },
                  ...campuses.map((c) => ({ value: c.id, label: c.name })),
                ]}
              />
            </div>
            <div>
              <Select
                label="Type"
                name="is_elective"
                value={filters.is_elective}
                onChange={handleFilterChange}
                options={[
                  { value: "", label: "All Types" },
                  { value: "false", label: "Compulsory" },
                  { value: "true", label: "Elective" },
                ]}
              />
            </div>
            <div className="flex items-end">
              <button type="submit" className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90">
                Apply Filters
              </button>
            </div>
          </form>
        </div>

        {/* Bulk Actions */}
        {selectedSubjects.length > 0 && (can("academics.update") || can("academics.delete")) && (
          <div className="bg-white shadow rounded p-4 px-5 flex flex-wrap items-center justify-between gap-2">
            <div className="flex space-x-2">
              <Button variant="lightSuccess" onClick={() => handleBulkAction("active")}>Activate</Button>
              <Button variant="lightDanger" onClick={() => handleBulkAction("inactive")}>Deactivate</Button>
            </div>
            <span className="text-sm font-medium text-gray-700">
              {selectedSubjects.length} subject(s) selected
            </span>
          </div>
        )}

        <DataTable
          columns={[
            {
              key: "name",
              label: "Subject",
              render: (subject) => (
                <div>
                  <div className="text-sm">{subject.name}</div>
                  {subject.description && <div className="text-xs text-gray-400 truncate max-w-xs">{subject.description}</div>}
                </div>
              ),
            },
            {
              key: "code",
              label: "Code",
              render: (subject) => (
                <span className="text-sm">{subject.code}</span>
              ),
            },
            {
              key: "campus",
              label: "Campus",
              render: (subject) => subject.campus?.name || <span className="">All Campuses</span>,
            },
            {
              key: "credits",
              label: "Credits",
              render: (subject) => subject.credits ?? <span className="text-gray-400">—</span>,
            },
            {
              key: "is_elective",
              label: "Type",
              render: (subject) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${subject.is_elective ? "bg-indigo-100 border border-indigo-300 text-indigo-500" : "bg-amber-100 border border-amber-300 text-amber-600"}`}>
                  {subject.is_elective ? "Elective" : "Compulsory"}
                </span>
              ),
            },
            {
              key: "status",
              label: "Status",
              render: (subject) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${subject.status === "active" ? "bg-green-100 border border-green-300 text-green-500" : "bg-red-100 border border-red-300 text-red-500"}`}>
                  {subject.status}
                </span>
              ),
            },
          ]}
          data={subjects}
          loading={loading}
          emptyMessage="No subjects found"
          selectable={(can("academics.update") || can("academics.delete"))}
          selectedIds={selectedSubjects}
          onSelectAll={handleSelectAll}
          onSelectRow={handleSelectOne}
          renderActions={(subject) => {
            return (
              <RowActions
                actions={[
                  { label: "View Details", variant: "primary", icon: ACTION_ICONS.view, hidden: !can("academics.update"), onClick: () => navigate(`/subjects/${subject.id}`) },
                  { label: "Edit Subject", icon: ACTION_ICONS.edit, hidden: !can("academics.update"), onClick: () => navigate(`/subjects/${subject.id}/edit`) },
                  { label: "Reactivate", variant: "success", icon: ACTION_ICONS.check, hidden: !can("academics.update") || subject.status !== "inactive", onClick: () => handleReactivate(subject.id) },
                  { label: "Deactivate", variant: "danger", icon: ACTION_ICONS.remove, hidden: !can("academics.delete") || subject.status === "inactive", onClick: () => handleDelete(subject.id) },
                ]}
              />
            );
          }}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ isOpen: false, action: null, ids: [] })}
        onConfirm={handleConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
      />
    </MainLayout>
  );
}
