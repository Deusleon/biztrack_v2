import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { subjectService, campusService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Input, Textarea, Button } from "../../components/ui";

export default function SubjectForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);
  const { showSuccess, showError } = useToast();

  const [formData, setFormData] = useState({
    name: "", code: "", description: "", campus_id: "",
    credits: "", is_elective: false, status: "active",
  });
  const [campuses, setCampuses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    fetchCampuses();
    if (isEdit) fetchSubject();
  }, [id]);

  const fetchCampuses = async () => {
    try {
      const response = await campusService.getAll({ limit: 100 });
      if (response.success) setCampuses(response.data);
    } catch { }
  };

  const fetchSubject = async () => {
    try {
      setLoading(true);
      const response = await subjectService.getById(id);
      if (response.success) {
        const s = response.data;
        setFormData({
          name: s.name || "",
          code: s.code || "",
          description: s.description || "",
          campus_id: s.campus_id || "",
          credits: s.credits ?? "",
          is_elective: s.is_elective || false,
          status: s.status || "active",
        });
      }
    } catch (err) {
      showError("Failed to load subject");
      navigate("/subjects");
    } finally { setLoading(false); }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((f) => ({ ...f, [name]: type === "checkbox" ? checked : value }));
    if (errors[name]) setErrors((e) => ({ ...e, [name]: "" }));
  };

  const validate = () => {
    const errs = {};
    if (!formData.name.trim()) errs.name = "Subject name is required";
    if (!formData.code.trim()) errs.code = "Subject code is required";
    if (formData.credits && (isNaN(formData.credits) || Number(formData.credits) < 0)) errs.credits = "Credits must be a non-negative number";
    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }

    try {
      setSubmitting(true);
      const payload = {
        ...formData,
        credits: formData.credits !== "" ? Number(formData.credits) : null,
        campus_id: formData.campus_id || null,
      };
      let response;
      if (isEdit) response = await subjectService.update(id, payload);
      else response = await subjectService.create(payload);

      if (response.success) {
        showSuccess(`Subject ${isEdit ? "updated" : "created"} successfully`);
        navigate(isEdit ? `/subjects/${id}` : "/subjects");
      }
    } catch (err) {
      const apiErrors = err.errors || [];
      if (apiErrors.length > 0) {
        const fieldErrs = {};
        apiErrors.forEach((e) => { fieldErrs[e.field] = e.message; });
        setErrors(fieldErrs);
      } else {
        showError(err.message || "Failed to save subject");
      }
    } finally { setSubmitting(false); }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-sm text-gray-600 mt-2">Loading subject data...</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4 text-left">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">
              {isEdit ? "Edit Subject" : "Add New Subject"}
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {isEdit ? "Update subject details" : "Create a new curriculum subject"}
            </p>
          </div>
          <Button
            variant="lightPrimary"
            onClick={() => navigate("/subjects")}
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }
          >
            Back to List
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded shadow text-left">
          <div className="px-5 py-4 space-y-10">
            {/* Subject Information */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Subject Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Subject Name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  error={errors.name}
                  placeholder="e.g. Mathematics, English Language"
                />
                <Input
                  label="Subject Code"
                  name="code"
                  value={formData.code}
                  onChange={handleChange}
                  required
                  error={errors.code}
                  placeholder="e.g. MATH101, ENG201"
                />
                <Input
                  label="Credits"
                  type="number"
                  name="credits"
                  min="0"
                  value={formData.credits}
                  onChange={handleChange}
                  error={errors.credits}
                  placeholder="Number of credits (e.g. 3)"
                />
                <Select
                  label="Campus"
                  name="campus_id"
                  value={formData.campus_id}
                  onChange={handleChange}
                  helperText="Leave blank to apply to all campuses"
                  options={[
                    { value: "", label: "All Campuses" },
                    ...campuses.map((c) => ({ value: c.id, label: c.name })),
                  ]}
                />
                {isEdit && (
                  <Select
                    label="Status"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    options={[
                      { value: "active", label: "Active" },
                      { value: "inactive", label: "Inactive" },
                    ]}
                  />
                )}
                <div className="md:col-span-2">
                  <Textarea
                    label="Description"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    rows={3}
                    placeholder="Optional subject description"
                  />
                </div>
                <div className="md:col-span-2 flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="is_elective"
                    name="is_elective"
                    checked={formData.is_elective}
                    onChange={handleChange}
                    className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
                  />
                  <label htmlFor="is_elective" className="text-sm font-medium text-gray-700">
                    Elective Subject
                  </label>
                  <span className="text-xs text-gray-400">(unchecked = compulsory)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Form Footer */}
          <div className="bg-gray-50 px-5 py-4 flex items-center justify-end gap-3 rounded-b">
            <Button type="button" variant="secondary" onClick={() => navigate("/subjects")}>Cancel</Button>
            <Button type="submit" loading={submitting}>{isEdit ? "Update Subject" : "Create Subject"}</Button>
          </div>
        </form>
      </div>
    </MainLayout>
  );
}
