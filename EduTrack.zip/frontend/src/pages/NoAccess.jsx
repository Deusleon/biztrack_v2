import { Link } from "react-router-dom";
import MainLayout from "../components/MainLayout";
import { ActionLink } from "../components/ui";
import Icon from "../components/ui/Icon";

/** Shown when someone opens a module their role has not been given the "Open …" permission for. */
export default function NoAccess() {
  return (
    <MainLayout>
      <div className="bg-white p-10 rounded shadow text-center max-w-xl mx-auto space-y-3">
        <h1 className="text-lg font-semibold text-gray-900">You don't have access to this part of EduTrack</h1>
        <p className="text-sm text-gray-600">
          Your role hasn't been given permission to open it. If you think you should have it, ask your school's administrator —
          they can allow it in Settings → Permissions.
        </p>
        <ActionLink to="/dashboard" variant="primary">Back to the dashboard</ActionLink>
      </div>
    </MainLayout>
  );
}
