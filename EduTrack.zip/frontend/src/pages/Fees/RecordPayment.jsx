import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { feeService, studentService } from "../../services/api";
import { useYearAwareClasses } from "../../hooks/useYearAwareClasses";
import MainLayout from "../../components/MainLayout";
import { Select, Input, Button, DatePicker, NumberInput } from "../../components/ui";
import { sumOfItems, outstandingFor, buildPaymentPayload } from "./paymentItems";
import { formatMoney } from "../../utils/money";

const PAYMENT_METHODS = [
  { value: "cash", label: "Cash" },
  { value: "bank_transfer", label: "Bank Transfer" },
  { value: "online", label: "Online / Mobile Money" },
  { value: "card", label: "Card" },
  { value: "cheque", label: "Cheque" },
];


const todayISO = () => new Date().toISOString().slice(0, 10);

export default function RecordPayment() {
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();

  const [sections, setSections] = useState([]);
  const [students, setStudents] = useState([]);
  const [selectedClass, setSelectedClass] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [selectedStudent, setSelectedStudent] = useState("");

  const [summary, setSummary] = useState(null);
  const [loadingSummary, setLoadingSummary] = useState(false);

  // `fee_structure_ids` is an array so one payment can settle several fee
  // items at once and produce ONE receipt listing them all, rather than a
  // separate payment and receipt per item. Empty means a general payment.
  const [form, setForm] = useState({
    fee_structure_ids: [], amount: "", payment_method: "cash",
    payment_date: todayISO(), transaction_id: "", remarks: "",
  });
  const [saving, setSaving] = useState(false);

  // Options refresh for the currently selected year automatically; a
  // stale selection from a previous year is re-mapped onto that same
  // class's row for the new year (see hooks/useYearAwareClasses.js).
  const classes = useYearAwareClasses({ selectedClassId: selectedClass, onRemap: setSelectedClass });

  useEffect(() => {
    const cls = classes.find((c) => c.id === selectedClass);
    setSections(cls?.sections || []);
    setSelectedSection(""); setSelectedStudent(""); setStudents([]); setSummary(null);
  }, [selectedClass]);

  useEffect(() => {
    if (!selectedClass) return;
    studentService.getAll({ class_id: selectedClass, section_id: selectedSection || undefined, status: "active", limit: 200 }).then((res) => {
      if (res.success) setStudents(res.data);
    });
    setSelectedStudent(""); setSummary(null);
  }, [selectedClass, selectedSection]);

  useEffect(() => {
    // A new student means a different set of fee items — carrying the old
    // selection over would bill this student for another student's items.
    setForm((f) => ({ ...f, fee_structure_ids: [], amount: "" }));
    if (!selectedStudent) { setSummary(null); return; }
    setLoadingSummary(true);
    feeService.getStudentFeeSummary(selectedStudent).then((res) => {
      if (res.success) setSummary(res.data);
    }).catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoadingSummary(false));
  }, [selectedStudent]);

  const handleFeeItemsChange = (ids) => {
    // Same convenience as before, just summed across everything picked:
    // pre-fill the amount with the selected items' charges, or the
    // outstanding balance when nothing specific is chosen. Still fully editable.
    const items = summary?.fee_items || [];
    const total = ids.length > 0 ? sumOfItems(items, ids) : (summary?.balance > 0 ? summary.balance : 0);
    setForm((f) => ({ ...f, fee_structure_ids: ids, amount: total > 0 ? String(total) : "" }));
  };

  const handleSave = async () => {
    if (!selectedStudent) { showError("Select a student first"); return; }
    if (!form.payment_date) { showError("Payment date is required"); return; }

    const { error, payload } = buildPaymentPayload({
      feeItems: summary?.fee_items || [],
      selectedIds: form.fee_structure_ids,
      amount: form.amount,
    });
    if (error) { showError(error); return; }

    try {
      setSaving(true);
      const res = await feeService.createPayment({
        student_id: selectedStudent,
        ...payload,
        payment_method: form.payment_method,
        payment_date: form.payment_date, transaction_id: form.transaction_id || undefined,
        remarks: form.remarks || undefined,
      });
      if (res.success) {
        showSuccess("Payment recorded");
        navigate(`/fees/receipt/${res.data.id}`);
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Record Payment</h1>
            <p className="text-sm text-gray-500 mt-0.5">Log a fee payment against a student's account</p>
          </div>
          <Button
            onClick={() => navigate("/fees")}
            variant="lightPrimary"
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to Fees
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Student picker + payment form */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white p-5 rounded shadow">
              <h3 className="text-sm text-left font-semibold text-gray-800 mb-3">1. Find the Student</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Select label="Class" required value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)}
                  options={[{ value: "", label: "Select…" }, ...classes.map((c) => ({ value: c.id, label: c.name }))]} />
                <Select label="Section" value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} disabled={!selectedClass}
                  options={[{ value: "", label: "All sections" }, ...sections.map((s) => ({ value: s.id, label: s.name }))]} />
                <Select label="Student" required value={selectedStudent} onChange={(e) => setSelectedStudent(e.target.value)} disabled={!selectedClass}
                  searchable
                  options={[{ value: "", label: "Select…" }, ...students.map((s) => ({ value: s.id, label: `${s.user?.first_name || ""} ${s.user?.last_name || ""} (${s.admission_number})` }))]} />
              </div>
            </div>

            {selectedStudent && (
              <div className="bg-white p-5 rounded shadow">
                <h3 className="text-sm text-left font-semibold text-gray-800 mb-3">2. Payment Details</h3>
                <div className="space-y-4">
                  <Select
                    label="Fee Item"
                    multiple
                    searchable
                    value={form.fee_structure_ids}
                    onChange={(e) => handleFeeItemsChange(e.target.value)}
                    placeholder="General payment (no specific item)"
                    helperText="Pick one or more items or Leave empty to record against the overall balance."
                    options={(summary?.fee_items || []).map((i) => {
                      // Show what's LEFT on each item, not the full charge —
                      // a part-paid tuition of 800,000 with 500,000 already
                      // received must read 300,000 here.
                      const due = outstandingFor(i);
                      const suffix = due <= 0
                        ? "fully paid"
                        : `${formatMoney(due)} due${due !== (i.annual_amount ?? i.amount) ? ` of ${formatMoney(i.annual_amount ?? i.amount)}` : ""}`;
                      return { value: i.id, label: `${i.name} — ${suffix}` };
                    })}
                  />
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <NumberInput label="Amount (TZS)" required value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
                    <Select label="Payment Method" required value={form.payment_method} onChange={(e) => setForm((f) => ({ ...f, payment_method: e.target.value }))} options={PAYMENT_METHODS} />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <DatePicker label="Payment Date" required value={form.payment_date} onChange={(e) => setForm((f) => ({ ...f, payment_date: e.target.value }))} />
                    <Input label="Transaction ID" value={form.transaction_id} onChange={(e) => setForm((f) => ({ ...f, transaction_id: e.target.value }))} placeholder="Optional" />
                  </div>
                  <Input label="Remarks" value={form.remarks} onChange={(e) => setForm((f) => ({ ...f, remarks: e.target.value }))} placeholder="Optional note" />
                  <Button onClick={handleSave} loading={saving} className="w-full">Record Payment</Button>
                </div>
              </div>
            )}
          </div>

          {/* Balance summary sidebar */}
          <div className="space-y-4">
            {selectedStudent ? (
              <div className="bg-white p-5 rounded shadow">
                {/* `summary` is null for the moment between picking a
                    student and the fetch resolving — read through it, or
                    this whole page crashes on every selection. */}
                {summary && (
                  <div>
                    <p className="text-sm font-semibold text-gray-900">{summary.student.name}</p>
                    <p className="text-xs text-gray-500">{summary.student.admission_number} — {summary.student.class} {summary.student.section}</p>
                  </div>
                )}
                {loadingSummary ? (
                  <div className="text-center py-6"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
                ) : summary ? (
                  <div className="space-y-3">
                    <h3 className="text-sm text-left font-semibold text-gray-800 mt-3 mb-1">Account Summary</h3>
                    <div className="border-t border-gray-100 space-y-1.5 text-sm">
                      <div className="flex justify-between"><span className="text-gray-500">Expected</span><span className="font-medium text-gray-900">{formatMoney(summary.expected)}</span></div>
                      <div className="flex justify-between"><span className="text-gray-500">Paid</span><span className="font-medium text-green-600">{formatMoney(summary.paid)}</span></div>
                      <div className="flex justify-between border-t border-gray-100 pt-1.5">
                        <span className="text-gray-700 font-medium">Balance</span>
                        <span className={`font-bold ${summary.balance > 0 ? "text-red-600" : "text-green-600"}`}>{formatMoney(summary.balance)}</span>
                      </div>
                    </div>
                    {summary.payments.length > 0 && (
                      <div className="border-t border-gray-100 pt-3">
                        <p className="text-sm text-left font-semibold text-gray-800 tracking-wide mb-2">Recent Payments</p>
                        <div className="space-y-1.5">
                          {summary.payments.slice(0, 5).map((p) => (
                            <div key={p.id} className="flex justify-between text-xs">
                              <span className="text-gray-500">{formatDate(p.payment_date)}</span>
                              <span className="font-medium text-gray-800">{formatMoney(p.amount)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : null}
              </div>
            ) :
              <div className="bg-white p-5 items-center h-32 rounded shadow">
                <h3 className="text-sm font-semibold text-gray-800 mt-3 mb-1">Account Summary</h3>
                <p className="text-sm mt-6 text-gray-700">Select class & student first</p>
              </div>}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
