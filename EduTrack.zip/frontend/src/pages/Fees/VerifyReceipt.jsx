import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { verifyService } from "../../services/api";
import { formatMoney } from "../../utils/money";

export default function VerifyReceipt() {
  const { paymentId, code: codeFromUrl } = useParams();
  const [receiptNo, setReceiptNo] = useState("");
  const [code, setCode] = useState(codeFromUrl || "");
  const [result, setResult] = useState(null); // null = not checked yet
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState("");

  // Scanned a QR code — it encodes the exact payment id + code, so verify
  // immediately instead of making the person retype anything.
  useEffect(() => {
    if (paymentId && codeFromUrl) {
      setChecking(true);
      verifyService.byId(paymentId, codeFromUrl)
        .then((res) => setResult(res.data))
        .catch(() => setError("Could not reach the verification service. Please try again."))
        .finally(() => setChecking(false));
    }
  }, [paymentId, codeFromUrl]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!receiptNo.trim() || !code.trim()) {
      setError("Enter both the Receipt No. and the Verification Code printed on the receipt.");
      return;
    }
    setError("");
    setChecking(true);
    setResult(null);
    try {
      const res = await verifyService.byCode(receiptNo.trim(), code.trim());
      setResult(res.data);
    } catch {
      setError("Could not reach the verification service. Please try again.");
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4 py-10">
      <div className="max-w-md w-full">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Receipt Verification</h1>
          <p className="text-gray-500 text-sm mt-1">Confirm a payment receipt is genuine and unaltered</p>
        </div>

        {!paymentId && (
          <div className="bg-white rounded shadow-lg p-5 mb-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Receipt No.</label>
                <input
                  type="text"
                  value={receiptNo}
                  onChange={(e) => setReceiptNo(e.target.value)}
                  placeholder="RCT-XXXXXXXX"
                  className="w-full border border-gray-300 rounded px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Verification Code</label>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="Printed below the receipt's QR code"
                  className="w-full border border-gray-300 rounded px-3 py-2.5 text-sm uppercase focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                />
              </div>
              {error && <p className="text-sm text-red-600">{error}</p>}
              <button type="submit" disabled={checking} className="w-full bg-primary text-white text-sm font-medium py-2.5 rounded hover:opacity-90 disabled:opacity-50">
                {checking ? "Checking…" : "Verify Receipt"}
              </button>
            </form>
          </div>
        )}

        {checking && paymentId && (
          <div className="bg-white rounded shadow-lg p-8 text-center">
            <div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" />
          </div>
        )}

        {result && (
          <div className={`rounded shadow-lg p-5 border-t-4 ${result.valid ? "bg-green-50 border-green-500" : "bg-red-50 border-red-500"}`}>
            {result.valid ? (
              <>
                <div className="flex items-center gap-2 mb-4">
                  <svg className="w-7 h-7 text-green-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <h2 className="text-lg font-bold text-green-700">Valid Receipt</h2>
                </div>
                <div className="space-y-2 text-sm">
                  <Row label="School" value={result.school} />
                  <Row label="Receipt No." value={result.receipt_no} />
                  <Row label="Student" value={result.student_name} />
                  <Row label="Admission No." value={result.admission_number} />
                  <Row label="Class" value={result.class_name} />
                  <Row label="Amount" value={formatMoney(result.amount)} strong />
                  <Row label="Date" value={result.payment_date ? new Date(result.payment_date).toLocaleDateString() : "—"} />
                  <Row label="Status" value={result.status} />
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <svg className="w-7 h-7 text-red-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                <div>
                  <h2 className="text-lg font-bold text-red-700">Not a Valid Receipt</h2>
                  <p className="text-sm text-red-600 mt-0.5">
                    This Receipt No. / Code combination doesn't match any payment on record. It may be forged, altered, or mistyped.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, strong }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 gap-3">
      <span className="text-gray-500">{label}</span>
      <span className={`text-right ${strong ? "font-bold text-gray-900" : "font-medium text-gray-800"}`}>{value || "—"}</span>
    </div>
  );
}
