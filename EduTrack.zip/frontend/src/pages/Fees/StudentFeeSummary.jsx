import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { feeService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Input, Button, DatePicker, DataTable, NumberInput } from "../../components/ui";
import { sumOfItems, outstandingFor, buildPaymentPayload } from "./paymentItems";

const METHOD_LABELS = {
  cash: "Cash", bank_transfer: "Bank Transfer", online: "Online / Mobile Money", card: "Card", cheque: "Cheque",
};
const PAYMENT_METHODS = Object.entries(METHOD_LABELS).map(([value, label]) => ({ value, label }));
const todayISO = () => new Date().toISOString().slice(0, 10);

export default function StudentFeeSummary() {
  const { studentId } = useParams();
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();
  const { formatDate, formatMoney } = usePreferences();

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  // `fee_structure_ids` is an array so one payment can settle several fee
  // items at once and produce a single receipt listing them all, rather
  // than one receipt per item. Empty means a general payment.
  const [payModal, setPayModal] = useState(false);
  const [payForm, setPayForm] = useState({ fee_structure_ids: [], amount: "", payment_method: "cash", payment_date: todayISO(), transaction_id: "", remarks: "" });
  const [saving, setSaving] = useState(false);

  const load = () => {
    feeService.getStudentFeeSummary(studentId)
      .then((res) => { if (res.success) setData(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [studentId]);

  const openPayModal = () => {
    setPayForm({ fee_structure_ids: [], amount: "", payment_method: "cash", payment_date: todayISO(), transaction_id: "", remarks: "" });
    setPayModal(true);
  };

  const handleFeeItemsChange = (ids) => {
    // Pre-fill the amount with the selected items' charges summed, or the
    // outstanding balance when nothing specific is picked. Still editable.
    const total = ids.length > 0 ? sumOfItems(data?.fee_items || [], ids) : (data?.balance > 0 ? data.balance : 0);
    setPayForm((f) => ({ ...f, fee_structure_ids: ids, amount: total > 0 ? String(total) : "" }));
  };

  const handleRecordPayment = async () => {
    if (!payForm.payment_date) { showError("Payment date is required"); return; }

    const { error, payload } = buildPaymentPayload({
      feeItems: data?.fee_items || [],
      selectedIds: payForm.fee_structure_ids,
      amount: payForm.amount,
    });
    if (error) { showError(error); return; }

    try {
      setSaving(true);
      const res = await feeService.createPayment({
        student_id: studentId,
        ...payload,
        payment_method: payForm.payment_method,
        payment_date: payForm.payment_date, transaction_id: payForm.transaction_id || undefined,
        remarks: payForm.remarks || undefined,
      });
      if (res.success) {
        showSuccess("Payment recorded");
        setPayModal(false);
        setLoading(true);
        load();
        navigate(`/fees/receipt/${res.data.id}`);
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary" /></div>
      </MainLayout>
    );
  }

  if (!data) {
    return (
      <MainLayout>
        <div className="bg-white p-10 rounded shadow text-center text-gray-400">
          <p>Fee summary not available.</p>
          <div className="flex items-center justify-center gap-4 mt-3">
            <button onClick={() => { setLoading(true); load(); }} className="text-primary hover:underline text-sm">Try again</button>
            <button onClick={() => navigate(-1)} className="text-primary hover:underline text-sm">← Back</button>
          </div>
        </div>
      </MainLayout>
    );
  }

  const { student, academic_year, fee_items, expected, paid, balance, extra = 0, payments, previous_years_arrears, total_owed } = data;
  const arrears = previous_years_arrears || { total: 0, years: [] };


  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">{student.name}</h1>
            <p className="text-sm text-gray-500 mt-0.5">{student.admission_number} — {student.class} {student.section} • {academic_year}</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={() => navigate(-1)}
              variant="lightPrimary"
              className="animate-pulse"
              leftIcon={
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 19l-7-7m0 0l7-7m-7 7h18"
                  />
                </svg>
              }>Back to Fee Status
            </Button>
          </div>
        </div>
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Expected</p>
                <p className="text-2xl text-left font-bold text-primary mt-1">{formatMoney(expected)}</p>
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Paid</p>
                <p className="text-2xl text-left font-bold text-green-600 mt-1">{formatMoney(paid)}</p>
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg className="w-8 h-8 text-green-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          {/* Paying above what's owed is credit the school holds, not a
              negative balance — so it gets its own card rather than
              rendering Balance as a minus figure. */}
          {extra > 0 ? (
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">Extra (Overpaid)</p>
                  <p className="text-2xl text-left font-bold text-blue-600 mt-1">{formatMoney(extra)}</p>
                </div>
                <div className="bg-blue-100 p-3 rounded">
                  <svg className="w-8 h-8 text-blue-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 11l5-5m0 0l5 5m-5-5v12" />
                  </svg>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-left text-gray-600">Balance</p>
                  <p className={`text-2xl text-left font-bold mt-1 ${balance > 0 ? "text-red-600" : "text-green-600"}`}>{formatMoney(balance)}</p>
                </div>
                <div className={`p-3 rounded ${balance > 0 ? "bg-red-100" : "bg-green-100"}`}>
                  <svg className={`w-8 h-8 opacity-45 ${balance > 0 ? "text-red-600" : "text-green-600"}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Arrears carried from previous years — kept visually and
            structurally separate from this year's Expected/Paid/Balance
            above (those never include it), so it's never mistaken for
            part of the current year's own charges. */}
        {arrears.total > 0 && (
          <div className="bg-amber-50 border border-amber-300 rounded shadow overflow-hidden">
            <div className="px-5 py-3 border-b border-amber-200 bg-amber-100 flex items-center justify-between flex-wrap gap-2">
              <div className="text-left">
                <p className="text-sm font-semibold text-amber-900">⚠ Deni la Miaka ya Nyuma (Arrears from Previous Years)</p>
                <p className="text-xs text-amber-700 mt-0.5">
                  This is carried-forward debt from earlier academic years — not part of {academic_year}'s own fees shown above.
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs text-amber-700">Jumla ya Deni (Total Arrears)</p>
                <p className="text-xl font-bold text-amber-900">{formatMoney(arrears.total)}</p>
              </div>
            </div>
            <div className="divide-y divide-amber-100">
              {arrears.years.map((y) => (
                <div key={y.academic_year} className="px-5 py-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <p className="text-sm font-medium text-gray-800 text-left">
                      {y.academic_year} — {y.class_name}
                    </p>
                    <p className="text-sm text-amber-800">
                      Alilipa {formatMoney(y.paid)} kati ya {formatMoney(y.expected)} — <strong>Deni: {formatMoney(y.balance)}</strong>
                    </p>
                  </div>
                  {y.items.length > 0 && (
                    <ul className="mt-2 text-xs text-gray-600 text-left list-disc list-inside space-y-0.5">
                      {y.items.map((item) => (
                        <li key={item.name}>
                          {item.name}: alilipa {formatMoney(item.paid)} kati ya {formatMoney(item.annual_amount)} — bado <strong>{formatMoney(item.outstanding)}</strong>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
            {typeof total_owed === 'number' && (
              <div className="px-5 py-3 border-t border-amber-200 bg-amber-100 flex flex-wrap items-center justify-between gap-2">
                <p className="text-sm font-semibold text-gray-800">Jumla Anachodaiwa Sasa (Total Owed Now: {academic_year} + Arrears)</p>
                <p className="text-lg font-bold text-red-700">{formatMoney(total_owed)}</p>
              </div>
            )}
          </div>
        )}

        {/* Record Payment — kept separate from the header, which only navigates back */}
        <div className="bg-white p-4 rounded shadow flex items-center justify-between flex-wrap gap-3">
          <p className="text-sm text-gray-600">Ready to log a payment for {student.name}?</p>
          <Button onClick={openPayModal}>Record Payment</Button>
        </div>

        {/* Fee items breakdown */}
        {fee_items.length > 0 && (
          <div className="bg-white rounded shadow overflow-hidden">
            <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
              <p className="text-sm text-left font-semibold text-gray-700">Fee Items for {student.name}</p>
            </div>
            <DataTable
              columns={[
                { key: "no", label: "No.", width: "w-8", render: (item, index) => <span className="text-sm">{index + 1}.</span> },
                { key: "name", label: "Item", render: (item) => <span className="text-sm text-gray-900">{item.name}</span> },
                {
                  key: "frequency", label: "Frequency",
                  render: (item) => (
                    <span className="text-sm text-gray-600 capitalize">
                      {item.frequency.replace("_", "-")}
                      {item.billing_cycles > 1 && <span className="text-gray-400"> × {item.billing_cycles}</span>}
                    </span>
                  ),
                },
                { key: "charge", label: "Charge", render: (item) => <span className="text-sm text-gray-600">{formatMoney(item.amount)}</span> },
                { key: "annual", label: "For the Year", render: (item) => <span className="text-sm font-medium text-gray-900">{formatMoney(item.annual_amount ?? item.amount)}</span> },
              ]}
              data={fee_items}
              rowId="id"
            />
          </div>
        )}

        {/* Payment history */}
        <div className="bg-white rounded shadow overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
            <p className="text-sm text-left font-semibold text-gray-700">Payment History</p>
          </div>
          <DataTable
            columns={[
              { key: "no", label: "No.", width: "w-8", render: (p, index) => <span className="text-sm">{index + 1}</span> },
              { key: "date", label: "Date", render: (p) => <span className="text-sm text-gray-700">{formatDate(p.payment_date)}</span> },
              {
                key: "item", label: "Fee Item",
                // A payment can now cover several items at once — showing
                // only feeStructure?.name would render those as "General
                // payment", which is wrong and hides what was actually paid.
                render: (p) => {
                  const allocations = Array.isArray(p.allocations) ? p.allocations : [];
                  if (allocations.length > 0) {
                    return (
                      <div>
                        <span className="text-sm text-gray-700">{allocations.length} fee items</span>
                        <div className="text-xs text-gray-400">{allocations.map((a) => a.name).filter(Boolean).join(", ")}</div>
                      </div>
                    );
                  }
                  return <span className="text-sm text-gray-700">{p.feeStructure?.name || <span className="text-gray-400">General payment</span>}</span>;
                },
              },
              { key: "method", label: "Method", render: (p) => <span className="text-sm text-gray-600">{METHOD_LABELS[p.payment_method] || p.payment_method}</span> },
              { key: "amount", label: "Amount", align: "", render: (p) => <span className="text-sm font-medium text-gray-900">{formatMoney(p.amount)}</span> },
              {
                key: "receipt", label: "Receipt", align: "left",
                render: (p) => <button onClick={() => navigate(`/fees/receipt/${p.id}`)} className="text-primary hover:underline text-xs">View</button>,
              },
            ]}
            data={payments}
            rowId="id"
            emptyMessage="No payments recorded yet."
          />
        </div>
      </div>

      {/* Record Payment Modal — same student, no navigating away */}
      {payModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Record Payment — {student.name}</h3>
              <button onClick={() => setPayModal(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleRecordPayment(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="bg-gray-50 rounded px-3 py-2 text-sm flex justify-between">
                <span className="text-gray-500">{extra > 0 ? "Extra on account" : "Current balance"}</span>
                <span className={`font-bold ${extra > 0 ? "text-blue-600" : balance > 0 ? "text-red-600" : "text-green-600"}`}>
                  {formatMoney(extra > 0 ? extra : balance)}
                </span>
              </div>
              <Select
                label="Fee Item"
                multiple
                value={payForm.fee_structure_ids}
                onChange={(e) => handleFeeItemsChange(e.target.value)}
                placeholder="General payment"
                helperText="Pick one or more items or Leave empty to record against the overall balance."
                options={fee_items.map((i) => {
                  // What's still owed on the item, not its full charge.
                  const due = outstandingFor(i);
                  return { value: i.id, label: `${i.name} — ${due <= 0 ? "fully paid" : `${formatMoney(due)} due`}` };
                })}
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <NumberInput label="Amount (TZS)" required value={payForm.amount} onChange={(e) => setPayForm((f) => ({ ...f, amount: e.target.value }))} />
                <Select label="Payment Method" required value={payForm.payment_method} onChange={(e) => setPayForm((f) => ({ ...f, payment_method: e.target.value }))} options={PAYMENT_METHODS} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <DatePicker label="Payment Date" required value={payForm.payment_date} onChange={(e) => setPayForm((f) => ({ ...f, payment_date: e.target.value }))} />
                <Input label="Transaction ID" value={payForm.transaction_id} onChange={(e) => setPayForm((f) => ({ ...f, transaction_id: e.target.value }))} placeholder="Optional" />
              </div>
              <Input label="Remarks" value={payForm.remarks} onChange={(e) => setPayForm((f) => ({ ...f, remarks: e.target.value }))} placeholder="Optional note" />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>Record Payment</Button>
                <Button type="button" variant="secondary" onClick={() => setPayModal(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </MainLayout>
  );
}
