/**
 * Helpers for turning a multi-select of fee items + one total amount into
 * the `items` payload `feeService.createPayment` expects.
 *
 * The form stays exactly as it was — a Fee Item select and an editable
 * Amount field — the select simply now accepts more than one item so a
 * single payment produces ONE receipt listing everything, instead of
 * forcing a separate payment and receipt per item.
 */

/** What a fee item still owes.
 *
 * This is the figure the form works with everywhere — the select label,
 * the pre-filled amount, and the allocation cap. Billing against the full
 * annual charge instead would re-bill a part-paid item: a student who paid
 * 500,000 of an 800,000 tuition should see 300,000 next time, not 800,000.
 *
 * Falls back to the full charge for API responses that predate the
 * per-item `outstanding` field. */
export const outstandingFor = (item) =>
  item?.outstanding !== undefined && item?.outstanding !== null
    ? Number(item.outstanding)
    : Number(item?.annual_amount ?? item?.amount ?? 0);

/** Sum of what the chosen items still owe — what the Amount field pre-fills to. */
export const sumOfItems = (feeItems, selectedIds) =>
  selectedIds.reduce((sum, id) => sum + outstandingFor(feeItems.find((i) => i.id === id)), 0);

/**
 * Splits `total` across the selected fee items.
 *
 * The backend records what each item received, but the form only asks for
 * one total — so the split happens here. Items are filled in the order
 * they were selected, each taking up to what it still owes before the next
 * gets anything, with any remainder landing on the last item.
 *
 * That means:
 *   - total left untouched  → every item is cleared to zero
 *   - total reduced         → the earlier items are settled first, the
 *                             way a cashier applies a short payment
 *   - total increased       → the surplus sits on the final item
 *
 * Items receiving nothing are dropped, since the backend rejects a zero
 * line and a 0.00 row on the receipt would just be noise.
 */
export const allocateAmount = (feeItems, selectedIds, total) => {
  let remaining = Number(total || 0);

  return selectedIds
    .map((id, index) => {
      const charge = outstandingFor(feeItems.find((i) => i.id === id));
      const isLast = index === selectedIds.length - 1;

      // The last item absorbs whatever is left, so the allocations always
      // add up to exactly the total the user typed.
      const share = isLast ? remaining : Math.min(charge, remaining);
      remaining = Math.round((remaining - share) * 100) / 100;

      // A one-off personal charge (a lost library book, say) is not a class
      // fee structure, so it travels under its own key — the Payment table's
      // fee_structure_id column can only hold a real fee structure.
      const item = feeItems.find((i) => i.id === id);
      const key = item?.is_charge ? "charge_id" : "fee_structure_id";

      return { [key]: id, amount: Math.round(share * 100) / 100 };
    })
    .filter((i) => i.amount > 0);
};

/**
 * Builds and validates the payment payload.
 *
 * No items selected is a general payment against the overall balance —
 * exactly what an empty Fee Item select meant before.
 *
 * Returns { error } on failure, or { payload } on success.
 */
export const buildPaymentPayload = ({ feeItems, selectedIds, amount }) => {
  const total = Number(amount);
  if (!amount || total <= 0) return { error: 'Enter a valid amount' };

  if (!selectedIds || selectedIds.length === 0) {
    return { payload: { amount: total } };
  }

  const items = allocateAmount(feeItems, selectedIds, total);
  if (items.length === 0) return { error: 'The amount is too small to cover any of the selected fee items' };

  return { payload: { items } };
};
