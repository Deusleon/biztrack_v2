import { usePreferences } from "../../contexts/PreferencesContext";
import { NumberInput } from "../../components/ui";

/**
 * FeeItemsPicker — lets a bursar settle SEVERAL fee items in one payment,
 * so the parent walks away with ONE receipt listing everything they just
 * paid for, instead of a separate receipt per item.
 *
 * Two modes, mutually exclusive:
 *   - "items"   → tick specific fee items and set an amount for each
 *   - "general" → a single lump sum against the overall balance, for when
 *                 the money isn't earmarked for any particular item
 *
 * Controlled component. Props
 * ───────────────────────────
 * feeItems  {Array}    Fee items from the student's summary. Each:
 *                        { id, name, annual_amount, amount, paid, outstanding, frequency, billing_cycles }
 * mode      {string}   "items" | "general"
 * onModeChange {Function} (mode) → void
 * selected  {Object}   { [feeStructureId]: amountString } — ticked items only
 * onSelectedChange {Function} (next) → void
 * disabled  {boolean}  Greys out the whole picker while saving.
 */
export default function FeeItemsPicker({
  feeItems = [],
  mode = "items",
  onModeChange,
  selected = {},
  onSelectedChange,
  disabled = false,
}) {
  const { formatMoney } = usePreferences();

  const selectedIds = Object.keys(selected);
  const total = selectedIds.reduce((sum, id) => sum + Number(selected[id] || 0), 0);

  // Anything still owed on an item; falls back to the full annual charge
  // for older API responses that predate the per-item `outstanding` field.
  const outstandingFor = (item) =>
    item.outstanding !== undefined && item.outstanding !== null
      ? Number(item.outstanding)
      : Number(item.annual_amount ?? item.amount ?? 0);

  const toggleItem = (item) => {
    const next = { ...selected };
    if (next[item.id] !== undefined) {
      delete next[item.id];
    } else {
      // Pre-fill with what's actually still owed rather than the full
      // annual charge — re-billing an already part-paid item is the most
      // common source of over-collection.
      const due = outstandingFor(item);
      next[item.id] = due > 0 ? String(due) : "";
    }
    onSelectedChange(next);
  };

  const setAmount = (id, value) => onSelectedChange({ ...selected, [id]: value });

  const selectAllUnpaid = () => {
    const next = { ...selected };
    feeItems.forEach((item) => {
      const due = outstandingFor(item);
      if (due > 0 && next[item.id] === undefined) next[item.id] = String(due);
    });
    onSelectedChange(next);
  };

  const clearAll = () => onSelectedChange({});

  const unpaidCount = feeItems.filter((i) => outstandingFor(i) > 0).length;

  return (
    <div className="space-y-3">
      {/* Mode switch */}
      <div className="flex rounded overflow-hidden border border-gray-300 w-fit text-sm">
        {[
          { value: "items", label: "Specific Fee Items" },
          { value: "general", label: "General Payment" },
        ].map((m) => (
          <button
            key={m.value}
            type="button"
            disabled={disabled}
            onClick={() => onModeChange(m.value)}
            className={`px-4 py-2 whitespace-nowrap transition-colors disabled:opacity-50 ${
              mode === m.value ? "bg-primary text-white" : "bg-white text-gray-600 hover:bg-gray-50"
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {mode === "general" ? (
        <p className="text-xs text-gray-500">
          The amount will be recorded against the student's overall balance, without being tied to any
          particular fee item.
        </p>
      ) : feeItems.length === 0 ? (
        <div className="border border-gray-200 rounded p-5 text-center">
          <p className="text-sm text-gray-500">No fee items set up for this student's class yet.</p>
          <p className="text-xs text-gray-400 mt-1">Switch to General Payment to record this payment anyway.</p>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <p className="text-xs text-gray-500">
              Tick every item this payment covers — they'll all appear on one receipt.
            </p>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={selectAllUnpaid}
                disabled={disabled || unpaidCount === 0}
                className="text-xs text-primary hover:underline disabled:opacity-40 disabled:no-underline"
              >
                Select all unpaid ({unpaidCount})
              </button>
              {selectedIds.length > 0 && (
                <button type="button" onClick={clearAll} disabled={disabled} className="text-xs text-gray-500 hover:underline">
                  Clear
                </button>
              )}
            </div>
          </div>

          <div className="border border-gray-200 rounded divide-y divide-gray-100 max-h-72 overflow-y-auto">
            {feeItems.map((item) => {
              const isSelected = selected[item.id] !== undefined;
              const due = outstandingFor(item);
              const fullyPaid = due <= 0;
              return (
                <div key={item.id} className={`p-3 ${isSelected ? "bg-primary-5" : ""}`}>
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      className="accent-primary mt-0.5 flex-shrink-0"
                      checked={isSelected}
                      disabled={disabled}
                      onChange={() => toggleItem(item)}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline justify-between gap-3 flex-wrap">
                        <p className="text-sm font-medium text-gray-900">{item.name}</p>
                        {fullyPaid ? (
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 border border-green-300 text-green-600">
                            Fully paid
                          </span>
                        ) : (
                          <span className="text-xs text-red-600 font-medium">{formatMoney(due)} due</span>
                        )}
                      </div>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {formatMoney(item.annual_amount ?? item.amount)} for the year
                        {Number(item.paid) > 0 && <> · {formatMoney(item.paid)} paid so far</>}
                      </p>

                      {isSelected && (
                        <div className="mt-2 max-w-[220px]">
                          <NumberInput
                            label="Amount to pay"
                            value={selected[item.id]}
                            disabled={disabled}
                            onChange={(e) => setAmount(item.id, e.target.value)}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {selectedIds.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-2 bg-gray-50 border border-gray-200 rounded px-4 py-2.5">
              <span className="text-sm text-gray-600">
                {selectedIds.length} item{selectedIds.length > 1 ? "s" : ""} selected
              </span>
              <span className="text-sm font-bold text-gray-900">{formatMoney(total)}</span>
            </div>
          )}
        </>
      )}
    </div>
  );
}

/** Turns the picker's state into the payload `feeService.createPayment`
 * expects, and validates it. Shared so the page and the modal can't drift
 * apart on what counts as a valid payment.
 *
 * Returns { error } on failure, or { payload } on success. */
export function buildPaymentItems({ mode, selected, amount }) {
  if (mode === "general") {
    if (!amount || Number(amount) <= 0) return { error: "Enter a valid amount" };
    return { payload: { amount: Number(amount) } };
  }

  const entries = Object.entries(selected);
  if (entries.length === 0) return { error: "Select at least one fee item, or switch to General Payment" };

  const invalid = entries.find(([, value]) => !value || Number(value) <= 0);
  if (invalid) return { error: "Every selected fee item needs an amount greater than 0" };

  return {
    payload: {
      items: entries.map(([fee_structure_id, value]) => ({ fee_structure_id, amount: Number(value) })),
    },
  };
}
