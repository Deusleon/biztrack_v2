import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { feeService, campusService } from "../../services/api";
import { resolveAcademicYearForLevel } from "../../utils/academicYear";
import { usePersistedState } from "../../hooks/usePersistedState";
import { useYearAwareClasses } from "../../hooks/useYearAwareClasses";
import MainLayout from "../../components/MainLayout";
import { Select, Input, NumberInput, DataTable, ConfirmModal, Button, RowActions, ACTION_ICONS } from "../../components/ui";
import Icon from "../../components/ui/Icon";

const FREQUENCIES = [
  { value: "one_time", label: "One-time" },
  { value: "monthly", label: "Monthly" },
  { value: "quarterly", label: "Quarterly" },
  { value: "annually", label: "Annually" },
];

const APPLIES_TO_LABELS = {
  transport: "Transport only",
  hostel: "Hostel only",
  selected_students: "Selected students",
};

const FREQUENCY_MULTIPLIER = { one_time: 1, monthly: 12, quarterly: 4, annually: 1 };
const effectiveCycles = (structure) => {
  if (structure.frequency === "one_time" || structure.frequency === "annually") return 1;
  return structure.billing_cycles || FREQUENCY_MULTIPLIER[structure.frequency] || 1;
};

function FeeAmountCell({ structure }) {
  const { formatMoney } = usePreferences();
  const cycles = effectiveCycles(structure);
  if (cycles === 1) {
    return <span className="text-sm">{formatMoney(structure.amount)}</span>;
  }
  return (
    <div>
      <div className="text-sm">
        {formatMoney(structure.amount)} <span className="text-gray-400 font-normal">/{structure.frequency === "monthly" ? "mo" : "qtr"}</span>
      </div>
      <div className="text-xs text-gray-400">{formatMoney(structure.amount * cycles)} for the year ({cycles} {structure.frequency === "monthly" ? "months" : "quarters"})</div>
    </div>
  );
}

export default function FeeStructureList() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { currentAcademicYear } = useAcademicYear();
  const { showSuccess, showError } = useToast();
  const { formatMoney } = usePreferences();


  const [structures, setStructures] = useState([]);
  const [summary, setSummary] = useState({ total_amount: 0, active_count: 0, total_count: 0 });
  const [campuses, setCampuses] = useState([]);
  // Fee names that carry more than one price (Transport per route, ...),
  // as reported by the API for the current filters.
  const [variants, setVariants] = useState([]);
  const [loading, setLoading] = useState(true);

  const [filters, setFilters] = usePersistedState("filters", { search: "", class_id: "", status: "", applies_to: "", fee_variants: [] });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 10 });

  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({
    name: "", amount: "", frequency: "one_time", billing_cycles: "", applies_to: "all", academic_year: currentAcademicYear,
    class_id: "", campus_id: "", status: "active",
  });
  const [saving, setSaving] = useState(false);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false });

  const [assignModal, setAssignModal] = useState({ isOpen: false, structure: null, students: [], loading: false, saving: false, search: "" });

  const classes = useYearAwareClasses({
    selectedClassId: filters.class_id,
    onRemap: (newClassId) => setFilters((f) => ({ ...f, class_id: newClassId })),
  });

  useEffect(() => { fetchStructures(); }, [filters, pagination.currentPage, currentAcademicYear]);
  useEffect(() => { fetchCampuses(); }, []);

  const fetchStructures = async () => {
    try {
      setLoading(true);
      const { fee_variants: pickedVariants = [], ...restFilters } = filters;
      const res = await feeService.getStructures({
        ...restFilters,
        ...(pickedVariants.length > 0 && { fee_variants: JSON.stringify(pickedVariants) }),
        academic_year: currentAcademicYear, page: pagination.currentPage, limit: pagination.itemsPerPage,
      });
      if (res.success) {
        setStructures(res.data);
        setPagination((p) => ({ ...p, ...res.pagination }));
        if (res.summary) setSummary(res.summary);
        const available = res.variants || [];
        setVariants(available);
        // A pick that no longer exists (class / scenario / year changed
        // underneath it) would otherwise sit there invisibly — drop it.
        const stillValid = pickedVariants.filter((k) => available.some((v) => v.key === k));
        if (stillValid.length !== pickedVariants.length) {
          setFilters((f) => ({ ...f, fee_variants: stillValid }));
        }
      }
    } catch (err) { showError(err.message || "Failed to fetch fee structures"); }
    finally { setLoading(false); }
  };

  const fetchCampuses = async () => {
    try {
      const res = await campusService.getAll({ limit: 100 });
      if (res.success) { setCampuses(res.data); if (res.data.length === 1) setForm((f) => ({ ...f, campus_id: res.data[0].id })); }
    } catch { /* non-fatal */ }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    // Variants belong to one service scenario — switching scenario starts
    // them afresh rather than carrying a pick over to a different service.
    setFilters((f) => ({ ...f, [name]: value, ...(name === "applies_to" && { fee_variants: [] }) }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const handleVariantChange = (e) => {
    setFilters((f) => ({ ...f, fee_variants: e.target.value || [] }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const showVariants = !!filters.applies_to && variants.length > 0;
  // One shared name (Transport Fee) → use it as the label; several → generic.
  const variantNames = [...new Set(variants.map((v) => v.name.toLowerCase()))];
  const variantSelectLabel = variantNames.length === 1 ? variants[0].name : "Fee Variant";

  const variantLabel = (v) => {
    const per = v.frequency === "monthly" ? "/mo" : v.frequency === "quarterly" ? "/qtr" : "";
    return `${v.name} — ${formatMoney(v.amount)}${per}`;
  };

  const openCreate = () => {
    setForm({ name: "", amount: "", frequency: "one_time", billing_cycles: "", applies_to: "all", academic_year: "", class_id: "", campus_id: campuses[0]?.id || "", status: "active" });
    setModal({ isOpen: true, mode: "create" });
  };

  const openEdit = (s) => {
    setForm({ name: s.name, amount: s.amount, frequency: s.frequency, billing_cycles: s.billing_cycles || "", applies_to: s.applies_to || "all", academic_year: s.academic_year, class_id: s.class_id, campus_id: s.campus_id, status: s.status });
    setModal({ isOpen: true, mode: "edit", id: s.id });
  };

  const handleSave = async () => {
    if (!form.name || !form.amount || !form.class_id || !form.campus_id) {
      showError("Name, amount, class and campus are required"); return;
    }
    if (Number(form.amount) <= 0) { showError("Amount must be greater than 0"); return; }
    try {
      setSaving(true);
      let saved;
      if (modal.mode === "edit") saved = await feeService.updateStructure(modal.id, form);
      else saved = await feeService.createStructure(form);
      showSuccess(modal.mode === "edit" ? "Fee structure updated" : "Fee structure created");
      setModal({ isOpen: false });
      await fetchStructures();
      // A fresh 'selected_students' fee has no one on it yet — go
      // straight to the checklist rather than making the admin find
      // their way back via the row action.
      if (form.applies_to === "selected_students" && saved?.data?.id) {
        openAssignModal(saved.data);
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (s) => {
    setConfirmModal({ isOpen: true, id: s.id, title: "Delete Fee Structure", message: `Delete "${s.name}"? This can't be undone.`, variant: "danger" });
  };

  const confirmDelete = async () => {
    try {
      await feeService.deleteStructure(confirmModal.id);
      showSuccess("Fee structure deleted");
      fetchStructures();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmModal({ isOpen: false });
  };

  const openAssignModal = async (s) => {
    setAssignModal({ isOpen: true, structure: s, students: [], loading: true, saving: false, search: "" });
    try {
      const res = await feeService.getStructureStudents(s.id);
      if (res.success) {
        setAssignModal((m) => ({ ...m, students: res.data.students, loading: false }));
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || "Failed to load students");
      setAssignModal({ isOpen: false, structure: null, students: [], loading: false, saving: false, search: "" });
    }
  };

  const toggleAssignStudent = (studentId) => {
    setAssignModal((m) => ({
      ...m,
      students: m.students.map((st) => (st.id === studentId ? { ...st, selected: !st.selected } : st)),
    }));
  };

  const setAllAssignSelected = (selected) => {
    setAssignModal((m) => ({ ...m, students: m.students.map((st) => ({ ...st, selected })) }));
  };

  const saveAssignments = async () => {
    try {
      setAssignModal((m) => ({ ...m, saving: true }));
      const studentIds = assignModal.students.filter((s) => s.selected).map((s) => s.id);
      const res = await feeService.setStructureStudents(assignModal.structure.id, studentIds);
      if (res.success) {
        showSuccess(res.message || "Students updated");
        setAssignModal({ isOpen: false, structure: null, students: [], loading: false, saving: false, search: "" });
        fetchStructures();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || "Failed to save students");
      setAssignModal((m) => ({ ...m, saving: false }));
    }
  };

  const totalActive = summary.active_count;
  const totalValue = summary.total_amount;

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Fee Structures</h1>
            <p className="text-sm text-gray-500 mt-0.5">Define what each class owes per academic year</p>
          </div>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => navigate("/fees/status")}>Class Fee Status</Button>
            <Button variant="secondary" onClick={() => navigate("/fees/record")}>Record Payment</Button>
            {can("fees.create") && (
              <Button variant="primary" onClick={openCreate}>New Fee Structure</Button>
            )}          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Fee Items</p>
                <p className="text-2xl text-left font-bold text-primary mt-1">{pagination.totalItems}</p>
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3v-6m-3 6v-9m-2 9h10a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Active</p>
                <p className="text-2xl text-left font-bold text-green-600 mt-1">{totalActive}</p>
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg className="w-8 h-8 text-green-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">
                  Total Value (annualized){(filters.applies_to || filters.fee_variants?.length > 0) && (
                    <span className="block text-[11px] text-gray-400 font-normal mt-0.5">
                      {filters.fee_variants?.length > 0 ? "for the selected fee variant" : "for the selected scenario"}
                    </span>
                  )}
                </p>
                <p className="text-2xl text-left font-bold text-indigo-600 mt-1">{formatMoney(totalValue)}</p>
              </div>
              <div className="bg-indigo-100 p-3 rounded">
                <svg className="w-8 h-8 text-indigo-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-5 rounded shadow">
          <form onSubmit={(e) => { e.preventDefault(); fetchStructures(); }} className={`grid grid-cols-1 gap-4 ${showVariants ? "md:grid-cols-7" : "md:grid-cols-6"}`}>
            <div className="md:col-span-2">
              <Input
                label="Search" name="search" value={filters.search} onChange={handleFilterChange}
                placeholder="Search by fee name..."
                leftIcon={<svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>}
              />
            </div>
            <div>
              <Select label="Class" name="class_id" value={filters.class_id} onChange={handleFilterChange}
                options={[{ value: "", label: "All Classes" }, ...classes.map((c) => ({ value: c.id, label: `${c.name}` }))]} />
            </div>
            <div>
              <Select
                label="Fee Scenario"
                name="applies_to"
                value={filters.applies_to}
                onChange={handleFilterChange}
                options={[
                  { value: "", label: "All fee items" },
                  { value: "general", label: "Standard fees Only" },
                  { value: "transport", label: "Include Transport Only" },
                  { value: "hostel", label: "Include Hostel Only" },
                ]}
              />
            </div>
            {/* Only after a Fee Scenario is chosen AND some fee in it has one
                name at several prices (Transport per route, Hostel per room
                type, ...). The total then follows the pick, not the highest. */}
            {showVariants && (
              <div>
                <Select
                  label={variantSelectLabel}
                  name="fee_variants"
                  multiple
                  searchable
                  value={filters.fee_variants || []}
                  onChange={handleVariantChange}
                  placeholder={variantNames.length === 1 ? `All ${variants[0].name} prices` : "All prices"}
                  options={variants.map((v) => ({ value: v.key, label: variantLabel(v) }))}
                />
              </div>
            )}
            <div>
              <Select label="Status" name="status" value={filters.status} onChange={handleFilterChange}
                options={[{ value: "", label: "All Statuses" }, { value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }]} />
            </div>
            <div className="flex items-end">
              <button type="submit" className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90">Apply Filters</button>
            </div>
          </form>
        </div>

        <DataTable
          columns={[
            {
              key: "name", label: "Fee Item",
              render: (s) => (
                <div>
                  <div className="text-sm">{s.name}</div>
                  <div className="text-xs text-gray-400">{s.class?.name} ({s.class?.grade})</div>
                </div>
              ),
            },
            { key: "amount", label: "Amount", render: (s) => <FeeAmountCell structure={s} /> },
            { key: "frequency", label: "Frequency", render: (s) => <span className="text-gray-700 text-sm capitalize">{s.frequency.replace("_", "-")}</span> },
            { key: "applies_to", label: "Applies To", render: (s) => s.applies_to && s.applies_to !== "all" ? <span className="px-2 inline-flex text-sm leading-5 font-semibold rounded-full border border-amber-300 bg-amber-100 text-amber-500">{APPLIES_TO_LABELS[s.applies_to] || s.applies_to}</span> : <span className="text-sm">Everyone</span> },
            { key: "academic_year", label: "Year", render: (s) => <span className="text-gray-700 text-sm">{s.academic_year}</span> },
            {
              key: "status", label: "Status",
              render: (s) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${s.status === "active" ? "bg-green-100 border border-green-300 text-green-500" : "bg-red-100 border border-red-300 text-red-500"}`}>
                  {s.status}
                </span>
              ),
            },
          ]}
          data={structures}
          loading={loading}
          emptyMessage="No fee structures found"
          renderActions={(s) => (
            <RowActions
              actions={[
                { label: "Assign Students", variant: "primary", icon: ACTION_ICONS.members, onClick: () => openAssignModal(s), hidden: !can("fees.update") || s.applies_to !== "selected_students" },
                { label: "Edit Structure", variant: "primary", icon: ACTION_ICONS.edit, hidden: !can("fees.update"), onClick: () => openEdit(s) },
                { label: "Delete Structure", variant: "danger", icon: ACTION_ICONS.delete, hidden: !can("fees.delete"), onClick: () => handleDelete(s) },
              ]}
            />
          )}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      {/* Create / Edit Modal */}
      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-lg">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Fee Structure" : "New Fee Structure"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <Input label="Fee Name" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Enter fee name" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <NumberInput label="Amount (TZS)" required value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
                <Select
                  label="Frequency"
                  value={form.frequency}
                  onChange={(e) => setForm((f) => ({ ...f, frequency: e.target.value, billing_cycles: "" }))}
                  options={FREQUENCIES}
                />
              </div>
              {(form.frequency === "monthly" || form.frequency === "quarterly") && (
                <Input
                  label={`Number of ${form.frequency === "monthly" ? "months" : "quarters"} actually charged`}
                  type="number" min={1} max={form.frequency === "monthly" ? 12 : 4}
                  value={form.billing_cycles}
                  onChange={(e) => setForm((f) => ({ ...f, billing_cycles: e.target.value }))}
                  placeholder={String(FREQUENCY_MULTIPLIER[form.frequency])}
                  helperText={`Defaults to ${FREQUENCY_MULTIPLIER[form.frequency]} (the full year) if left blank. Lower this for fees that skip holiday periods — e.g. a transport fee only charged for the months school is in session.`}
                />
              )}
              <Select
                label="Applies To"
                value={form.applies_to}
                onChange={(e) => setForm((f) => ({ ...f, applies_to: e.target.value }))}
                options={[
                  { value: "all", label: "Every student in this class" },
                  { value: "transport", label: "Only students using Transport" },
                  { value: "hostel", label: "Only students in a Hostel" },
                  { value: "selected_students", label: "Only students to be selected" },
                ]}
                helperText={
                  form.applies_to === "selected_students"
                    ? "You'll pick exactly which students this applies to after saving."
                    : "'All' fees (Tuition, Uniform, Exam...) apply to everyone. Pick Transport/Hostel for fees that only apply to students who actually use that service."
                }
              />
              {form.amount > 0 && effectiveCycles({ frequency: form.frequency, billing_cycles: form.billing_cycles }) > 1 && (
                <p className="text-xs text-left text-indigo-700 bg-indigo-50 border border-indigo-200 rounded px-3 py-2 -mt-2">
                  {formatMoney(form.amount)} × {effectiveCycles({ frequency: form.frequency, billing_cycles: form.billing_cycles })} ({form.frequency}) = <strong>{formatMoney(form.amount * effectiveCycles({ frequency: form.frequency, billing_cycles: form.billing_cycles }))} for the whole academic year</strong>
                </p>
              )}
              <Select label="Class" required value={form.class_id} onChange={(e) => {
                  const classId = e.target.value;
                  const cls = classes.find((c) => c.id === classId);
                  setForm((f) => ({
                    ...f, class_id: classId,
                    academic_year: cls ? resolveAcademicYearForLevel(currentAcademicYear, cls.education_level) : f.academic_year,
                  }));
                }}
                options={[{ value: "", label: "Select class…" }, ...classes.map((c) => ({ value: c.id, label: `${c.name}` }))]} />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="Academic Year" required value={form.academic_year} disabled
                  // helperText={classes.find((c) => c.id === form.class_id)?.education_level === "a_level" ? "A-Level uses a two-year span" : "Single year (Primary/O-Level)"}
                />
                <Select label="Status" value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}
                  options={[{ value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }]} />
              </div>
              {campuses.length > 1 && (
                <Select label="Campus" required value={form.campus_id} onChange={(e) => setForm((f) => ({ ...f, campus_id: e.target.value }))}
                  options={[{ value: "", label: "Select campus…" }, ...campuses.map((c) => ({ value: c.id, label: c.name }))]} />
              )}
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Create"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Assign Students — the checklist for a 'selected_students' fee */}
      {assignModal.isOpen && (() => {
        const term = assignModal.search.trim().toLowerCase();
        const visible = term
          ? assignModal.students.filter((s) => s.name.toLowerCase().includes(term) || (s.admission_number || "").toLowerCase().includes(term))
          : assignModal.students;
        const selectedCount = assignModal.students.filter((s) => s.selected).length;
        return (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded shadow-xl w-full max-w-lg flex flex-col max-h-[85vh]">
              <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2 flex-shrink-0">
                <div className="text-left">
                  <h3 className="text-base font-semibold">Assign Students</h3>
                  <p className="text-xs text-gray-500 mt-0.5">{assignModal.structure?.name} — {formatMoney(assignModal.structure?.amount)}</p>
                </div>
                <button onClick={() => setAssignModal({ isOpen: false, structure: null, students: [], loading: false, saving: false, search: "" })} className="text-gray-400 hover:text-gray-600">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              </div>

              {assignModal.loading ? (
                <div className="py-16 text-center flex-1">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
                </div>
              ) : (
                <>
                  <div className="px-5 pt-4 pb-2 flex-shrink-0 space-y-2">
                    <Input
                      value={assignModal.search}
                      onChange={(e) => setAssignModal((m) => ({ ...m, search: e.target.value }))}
                      placeholder="Search by name or admission number..."
                    />
                    <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
                      <span className="text-gray-500">{selectedCount} of {assignModal.students.length} selected</span>
                      <div className="flex gap-3">
                        <button type="button" onClick={() => setAllAssignSelected(true)} className="text-primary hover:underline">Select All</button>
                        <button type="button" onClick={() => setAllAssignSelected(false)} className="text-gray-500 hover:underline">Clear All</button>
                      </div>
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto px-5 divide-y divide-gray-100 border-t border-gray-100">
                    {visible.length === 0 ? (
                      <p className="text-sm text-gray-400 py-8 text-center">No students match your search</p>
                    ) : (
                      visible.map((s) => (
                        <label key={s.id} className="flex items-center gap-3 py-2.5 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={s.selected}
                            onChange={() => toggleAssignStudent(s.id)}
                            className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
                          />
                          <div className="text-left">
                            <p className="text-sm text-gray-900">{s.name}</p>
                            <p className="text-xs text-gray-400">{s.admission_number}{s.section ? ` — ${s.section}` : ""}</p>
                          </div>
                        </label>
                      ))
                    )}
                  </div>

                  <div className="px-5 py-4 border-t border-gray-200 flex justify-end gap-3 flex-shrink-0">
                    <Button onClick={saveAssignments} loading={assignModal.saving}>Save ({selectedCount})</Button>
                    <Button
                      type="button" variant="secondary"
                      onClick={() => setAssignModal({ isOpen: false, structure: null, students: [], loading: false, saving: false, search: "" })}
                    >
                      Cancel
                    </Button>
                  </div>
                </>
              )}
            </div>
          </div>
        );
      })()}

      <ConfirmModal isOpen={confirmModal.isOpen} title={confirmModal.title} message={confirmModal.message} variant="danger" onConfirm={confirmDelete} onClose={() => setConfirmModal({ isOpen: false })} />
    </MainLayout>
  );
}