import { useState, useEffect, useLayoutEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { QRCodeSVG } from "qrcode.react";
import { useToast } from "../../contexts/ToastContext";
import { feeService } from "../../services/api";
import { useCampus } from "../../contexts/CampusContext";
import { usePreferences, RECEIPT_SIZES } from "../../contexts/PreferencesContext";
import MainLayout from "../../components/MainLayout";
import { Button } from "../../components/ui";
import { formatNumber } from "../../utils/money";

const formatMoneyStrict = (n) => formatNumber(n); // follows Settings → Money Decimals, like every other amount

const METHOD_LABELS = {
  cash: "Cash", bank_transfer: "Bank Transfer", online: "Online / Mobile Money", card: "Card", cheque: "Cheque",
};

// Simple, dependency-free number-to-words for the receipt's "in words" line.
const ONES = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
  "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
const TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
function numberToWords(n) {
  n = Math.round(n);
  if (n === 0) return "Zero";
  const chunk = (num) => {
    let s = "";
    if (num >= 100) { s += ONES[Math.floor(num / 100)] + " Hundred "; num %= 100; }
    if (num >= 20) { s += TENS[Math.floor(num / 10)] + " "; num %= 10; }
    if (num > 0) s += ONES[num] + " ";
    return s.trim();
  };
  const units = ["", " Thousand", " Million", " Billion"];
  let unitIndex = 0, remaining = n;
  const parts = [];
  while (remaining > 0) {
    const chunkVal = remaining % 1000;
    if (chunkVal > 0) parts.unshift(chunk(chunkVal) + units[unitIndex]);
    remaining = Math.floor(remaining / 1000);
    unitIndex++;
  }
  return parts.join(" ");
}

const PAGE_SPEC = {
  a5: { width: "148mm", pageSize: "A5", cssWidth: "max-w-2xl", paperMm: 148, paperHeightMm: 210, marginMm: 8 },
  thermal80: { width: "80mm", pageSize: "80mm auto", cssWidth: "w-[389px]", paperMm: 80, paperHeightMm: null, marginMm: 2 },
  thermal58: { width: "58mm", pageSize: "58mm auto", cssWidth: "w-[302px]", paperMm: 58, paperHeightMm: null, marginMm: 2 },
};

const FALLBACK_SIZE = "a5";

const PX_PER_MM = 96 / 25.4; // CSS px are fixed at 96 per inch

const printScaleFor = (size, measured) => {
  if (!measured?.width || !measured?.height) return 1;

  const { paperMm, paperHeightMm, marginMm } = PAGE_SPEC[size];

  const printableWidthPx = (paperMm - marginMm * 2) * PX_PER_MM;
  const widthScale = printableWidthPx / measured.width;

  // Roll paper grows to fit, so only fixed-height sheets constrain height.
  const heightScale = paperHeightMm
    ? ((paperHeightMm - marginMm * 2) * PX_PER_MM) / measured.height
    : Infinity;

  const scale = Math.min(1, widthScale, heightScale);
  return Math.round(scale * 10000) / 10000;
};

export default function PaymentReceipt() {
  const { id: paymentId } = useParams();
  const navigate = useNavigate();
  const { showError } = useToast();
  const { currentCampus } = useCampus();
  const { formatDate, defaultReceiptSize, formatMoney } = usePreferences();

  const [payment, setPayment] = useState(null);
  const [loading, setLoading] = useState(true);
  
  const [size, setSize] = useState(PAGE_SPEC[defaultReceiptSize] ? defaultReceiptSize : FALLBACK_SIZE);
  
  const sheetRef = useRef(null);
  const [measured, setMeasured] = useState(null);

  useLayoutEffect(() => {
    const el = sheetRef.current;
    if (!el) return;

    const measure = () => {
      const width = el.offsetWidth;
      const height = el.offsetHeight;
      setMeasured((prev) => (prev && prev.width === width && prev.height === height ? prev : { width, height }));
    };
    measure();

    if (typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, [size, payment]);

  useEffect(() => {
    feeService.getPaymentById(paymentId)
      .then((res) => { if (res.success) setPayment(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, [paymentId]);

  if (loading) {
    return (
      <MainLayout>
        <div className="bg-white p-16 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary" /></div>
      </MainLayout>
    );
  }

  if (!payment) {
    return (
      <MainLayout>
        <div className="bg-white p-16 rounded shadow text-center text-gray-400">
          <p>Receipt not available.</p>
          <button onClick={() => navigate(-1)} className="text-primary hover:underline text-sm mt-2">← Back</button>
        </div>
      </MainLayout>
    );
  }

  const receiptNo = `RCT-${payment.id.slice(0, 8).toUpperCase()}`;
  const studentName = `${payment.student?.user?.first_name || ""} ${payment.student?.user?.last_name || ""}`.trim();
  const isThermal = size === "thermal80" || size === "thermal58";
  const printScale = printScaleFor(size, measured);

  return (
    <MainLayout>
      <div className="space-y-4">
        <style>{`
          @media print {
            @page { size: ${PAGE_SPEC[size].pageSize}; margin: ${PAGE_SPEC[size].marginMm}mm; }
            .receipt-print-area {
              display: block !important;
              width: 100% !important;
              max-width: none !important;
              margin: 0 !important;
              padding: 0 !important;
              gap: 0 !important;
            }
            .receipt-sheet {
              /* Pinned to the exact width it's rendering at on screen, then
                 scaled down as a whole - so the printout is a faithful
                 reduction of the preview rather than a reflow at full font
                 size. zoom is used rather than transform: scale() because
                 zoom shrinks the layout box along with the content; a
                 transform would leave the original full-height box behind
                 and still paginate onto a second sheet. */
              width: ${measured?.width || 672}px !important;
              max-width: none !important;
              min-width: 0 !important;
              /* Centred rather than pinned left: a tall receipt scales down
                 to fit the page height, which leaves it narrower than the
                 sheet, and a centred block reads far better than one hugging
                 the left edge. */
              margin: 0 auto !important;
              border-radius: 0 !important;
              zoom: ${printScale};
            }
          }
        `}</style>

        {/* Screen-only toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 print:hidden">
          <div className="flex items-center gap-3">
            <div className="flex rounded overflow-hidden border border-gray-300 text-sm">
              {RECEIPT_SIZES.map((s) => (
                <button
                  key={s.value}
                  onClick={() => setSize(s.value)}
                  className={`px-3 py-2.5 whitespace-nowrap ${size === s.value ? "bg-primary text-white" : "bg-white text-gray-600 hover:bg-gray-50"}`}
                >
                  {s.label}
                </button>
              ))}
            </div>
            <Button variant="primary" onClick={() => window.print()}>Print</Button>
          </div>
          <Button onClick={() => navigate(-1)}
            variant="lightPrimary"
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to Summary
          </Button>
        </div>

        {/* ── Two-column layout: a fuller summary panel on the left, the
             receipt on the right — same balanced 2/3 split as the Report
             Card page, so neither side crowds the other. ── */}
        <div className="receipt-print-area grid grid-cols-2 lg:grid-cols-5 gap-6 items-start">
          <div className="lg:col-span-2 print:hidden bg-white rounded shadow p-5 lg:sticky lg:top-4 space-y-5">
            <div>
              <h3 className="text-sm font-semibold text-gray-900">About this receipt</h3>
              <p className="text-sm text-left text-gray-500 mt-2 leading-relaxed">
                Official proof of payment for <span className="font-medium text-gray-700">{studentName || "the student"}</span>.
                Keep this for your records — it can be reprinted anytime from the student's fee summary.
              </p>
            </div>

            <div className="border-t text-left border-gray-100 pt-4 grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-3">
              <div>
                <p className="text-xs text-gray-400">Student</p>
                <p className="text-sm font-medium text-gray-800">{studentName || "—"}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Admission No.</p>
                <p className="text-sm font-medium text-gray-800">{payment.student?.admission_number || "—"}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Class</p>
                <p className="text-sm font-medium text-gray-800">
                  {payment.student?.class?.name || "—"}{payment.student?.section?.name ? ` — ${payment.student.section.name}` : ""}
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Method</p>
                <p className="text-sm font-medium text-gray-800">{METHOD_LABELS[payment.payment_method] || payment.payment_method}</p>
              </div>
            </div>

            <div className="border-t border-gray-100 pt-4 space-y-2.5">
              <div className="flex items-center">
                <span className="w-1/2 text-left text-xs text-gray-500">Receipt No.</span>
                <span className="w-1/2 text-left text-sm ps-2 font-semibold text-gray-900">{receiptNo}</span>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="w-1/2 text-left text-xs text-gray-500">Amount Paid</span>
                <span className="w-1/2 text-left text-sm ps-2 font-bold text-primary">{formatMoney(payment.amount)}</span>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="w-1/2 text-left text-xs text-gray-500">Date</span>
                <span className="w-1/2 text-left text-sm ps-2 font-semibold text-gray-900">{formatDate(payment.payment_date)}</span>
              </div>
              {payment.balance !== null && payment.balance !== undefined && (
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="w-1/2 text-left text-xs text-gray-500">Balance Remaining</span>
                  <span className={`w-1/2 text-left text-sm ps-2 font-bold ${payment.balance > 0 ? "text-red-600" : "text-green-600"}`}>{formatMoney(payment.balance)}</span>
                </div>
              )}
            </div>

            <div className="border-t border-gray-100 pt-4">
              <p className="text-xs text-left text-gray-400 leading-relaxed">
                Choose a paper size above, then use <span className="font-medium text-gray-500">Print</span> for a physical copy.
              </p>
            </div>
          </div>

          <div className="lg:col-span-3 bg print:col-span-full">
            {isThermal ? (
              <ThermalReceipt
                sheetRef={sheetRef}
                size={size} payment={payment} campus={currentCampus} receiptNo={receiptNo}
                studentName={studentName} formatDate={formatDate}
              />
            ) : (
              <FormalReceipt
                sheetRef={sheetRef}
                size={size} payment={payment} campus={currentCampus} receiptNo={receiptNo}
                studentName={studentName} formatDate={formatDate}
              />
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}

const MIN_RECEIPT_ROWS = 7;

function ReceiptAmountCell({ item }) {
  if (item.amount !== null && item.amount !== undefined) {
    return <>{formatMoneyStrict(item.amount)}</>;
  }
  if (item.status === "paid") {
    return <span className="text-green-600 font-semibold uppercase text-[10px] tracking-wide">Fully Paid</span>;
  }
  if (item.status === "partial") {
    return <span className="text-amber-600 font-semibold uppercase text-[10px] tracking-wide">Part Paid</span>;
  }
  return <span className="text-gray-300">—</span>;
}

function FormalReceipt({ size, payment, campus, receiptNo, studentName, formatDate, sheetRef }) {
  const { formatMoney } = usePreferences();
  const checklist = payment.fee_checklist && payment.fee_checklist.length > 0
    ? payment.fee_checklist
    : [{ name: payment.feeStructure?.name || "General Fee Payment", amount: Number(payment.amount) }];
  // Pad with blank rows so the receipt always has a fuller, consistent
  // "receipt book" look, even for a student with very few fee items.
  const rows = [...checklist];
  while (rows.length < MIN_RECEIPT_ROWS) rows.push({ name: "", amount: null });

  const isA5 = size === "a5";
  const paidDate = payment.payment_date ? new Date(payment.payment_date) : new Date();
  const dd = String(paidDate.getDate()).padStart(2, "0");
  const mm = String(paidDate.getMonth() + 1).padStart(2, "0");
  const yyyy = String(paidDate.getFullYear());

  const gradient = { background: "linear-gradient(to right, var(--color-primary), var(--color-primary-30))" };
  const verifyUrl = payment.verification_code
    ? `${window.location.origin}/verify-receipt/${payment.id}/${payment.verification_code}`
    : null;

  return (
    <div ref={sheetRef} className={`receipt-sheet bg-white shadow print:shadow-none overflow-hidden print:rounded-none print:!mt-0 ${PAGE_SPEC[size].cssWidth} print:max-w-none ${isA5 ? "text-[13px]" : ""}`}>
      <div className="w-full px-5 py-5  flex flex-wrap items-center justify-between gap-2">
        <div className={`text-left items-center gap-4`}>
          <h1 className={`font-extrabold uppercase text-gray-900 leading-tight break-words ${isA5 ? "text-xl" : "text-2xl"}`}>
            {campus?.name || "School Name"}
          </h1>
          <p className="text-sm font-medium text-gray-800 mt-1">{campus?.address || "School Address"}</p>
          <p className="text-sm font-medium text-gray-800">Email: {campus?.email || "info@schoolname.co.tz"}</p>
          <p className="text-sm font-medium text-gray-800">Website: {campus?.website || "www.schoolwebsite.co.tz"}</p>
          <p className="text-sm font-medium text-gray-800">Contact: {campus?.phone || ""}</p>
        </div>
        <div className="w-24 h-24 flex items-center justify-center flex-shrink-0">
          {campus?.logo_url ? (
            <img src={campus.logo_url} alt={`${campus?.name || "School"} logo`} className="max-w-full max-h-full object-contain" />
          ) : (
            <span className="text-3xl font-extrabold text-primary">{(campus?.name || "S").trim().charAt(0)}</span>
          )}
        </div>
      </div>
      <div className="h-0.5 bg-gray-600" />

      <div className={`${isA5 ? "pt-3" : "pt-6"} px-5`}>
        <h2 className={`text-center font-extrabold uppercase tracking-wide text-gray-900 ${isA5 ? "text-xl" : "text-2xl"}`}>
          Receipt For Payment
        </h2>

        {/* Student's Name / Class box + Date boxes */}
        <div className={`flex items-end gap-4 ${isA5 ? "mt-3 text-xs" : "mt-6 text-sm"}`}>
          <div className="w-3/5">
            <div className="flex-1 w-full border-2 border-gray-600 rounded-sm p-4 space-y-4">
              <p className="flex items-baseline gap-2">
                <span className="text-gray-900 font-extrabold uppercase whitespace-nowrap">Student's Name:</span>
                <span className="flex-1 text-primary text-sm font-medium border-b-2 border-gray-600 truncate">{studentName}</span>
              </p>
              <p className="flex items-baseline gap-2">
                <span className="text-gray-900 font-extrabold uppercase whitespace-nowrap">Student's Class:</span>
                <span className="flex-1 text-primary text-sm font-medium border-b-2 border-gray-600 truncate">
                  {payment.student?.class?.name}{payment.student?.section?.name ? ` — ${payment.student.section.name}` : ""}
                </span>
              </p>
            </div>
          </div>
          <div className="w-2/5">
            <div className="flex justify-end items-center gap-2 flex-shrink-0">
              <span className="text-sm font-extrabold text-gray-900 uppercase">Date:</span>
              <div className="flex rounded-sm overflow-hidden border-2 border-gray-600">
                {[dd, mm, yyyy].map((part, i) => (
                  <div key={i} className={`h-8 flex items-center justify-center ${isA5 ? "text-xs" : "text-sm"} ${i !== 2 ? "border-r-2 border-gray-600" : ""} ${i === 2 ? "w-12" : "w-9"}`}>
                    <span className="font-bold text-primary">{part}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 border-2 border-gray-600">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className={`bg-primary-30`}>
                <th className="w-10 border-r-2 border-gray-600">NO</th>
                <th className={`${isA5 ? "py-1" : "py-2.5"} text-center uppercase text-gray-900 font-extrabold border-r-2 border-gray-600`}>
                  Payment Description
                </th>
                <th className="w-36 text-center uppercase text-gray-900 font-extrabold">
                  Amount(TZS)
                </th>
              </tr>
            </thead>
            <tbody>
              {rows.map((item, idx) => (
                <tr key={idx} className="border-t-2 border-gray-600">
                  <td className="w-10 text-center border-r-2 border-gray-600 font-semibold text-xs">{item.name ? idx + 1 : "\u00A0"}</td>
                  <td className={`${isA5 ? "py-1 text-xs" : "py-2.5 text-sm"} pl-4 border-r-2 text-left border-gray-600 font-semibold uppercase`}>{item.name || "\u00A0"}</td>
                  <td className={`${isA5 ? "py-1 text-xs" : "py-2.5 text-sm"} pr-4 text-right font-bold text-primary`}>
                    <ReceiptAmountCell item={item} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Total amount — below the table, not inside it, like the sample */}
        <div className="flex justify-end items-end gap-3 mt-3">
          <p className={`font-bold uppercase text-gray-900 ${isA5 ? "text-sm" : "text-base"}`}>Total Amount:</p>
          <p className="w-36 text-right font-extrabold text-primary border-b-2 border-gray-600 pe-4 pb-1">{formatMoneyStrict(payment.amount)}</p>
        </div>

        {/* Amount in words — gradient banner with the words written on a rule below */}
        <div className="mt-3">
          <div className="w-2/3">
            <p className={`${isA5 ? "text-xs" : "text-base"} text-left font-extrabold text-gray-900 uppercase`}>Amount Paid (In Words):</p>
          </div>
          <p className="text-sm text-primary font-medium border-b-2 border-gray-600 pb-1">
            {numberToWords(payment.amount)} Shillings Only
          </p>
        </div>

        <div className="flex mt-6 pb-3 justify-between">
          {/* Balance due — smaller banner + rule */}
          {payment.balance !== null && payment.balance !== undefined && (
            <div className="w-1/2 items-end">
              <div className="text-left">
                {/* An overpayment is credit the school holds, so the receipt
                    says so outright rather than printing a negative balance. */}
                <p className={`${isA5 ? "text-xs" : "text-base"} font-extrabold text-gray-900 uppercase`}>
                  {payment.extra > 0 ? "Extra (Overpaid):" : "Balance Due:"}
                </p>
                <p className={`w-48 border-b-2 border-gray-600 pb-1 mt-4 font-bold ${payment.extra > 0 ? "text-blue-600" : payment.balance > 0 ? "text-red-600" : "text-green-600"}`}>
                  {formatMoney(payment.extra > 0 ? payment.extra : payment.balance)}
                </p>
              </div>
            </div>
          )}

          {/* Official Stamp (left) + Bursar's Signature (right, as in the sample) */}
          <div className="w-1/2 items-end">
            <div className="text-right">
              <p className={`${isA5 ? "text-xs" : "text-base"} font-extrabold text-gray-900 mb-9 uppercase`}>Bursar's Signature & Stamp:</p>
              <div className="ms-14 pt-[3px] border-b-2 border-gray-600" />
              <p className="uppercase text-xs font-semibold">{payment.receivedBy ? ` ${payment.receivedBy.first_name} ${payment.receivedBy.last_name}` : ""}</p>
            </div>
          </div>
        </div>
      </div>

      {payment.verification_code && (
        <div className="px-5 pb-5 flex items-center justify-center gap-3 border-t border-gray-100 pt-4">
          <div className="bg-white p-1 border border-gray-200 rounded flex-shrink-0">
            <QRCodeSVG value={verifyUrl} size={70} level="M" />
          </div>
          <div className="min-w-0">
            <p className="text-[10px] text-gray-400 uppercase tracking-wide">Scan to verify authenticity</p>
            <p className="text-xs font-mono font-semibold text-gray-700 mt-0.5">{receiptNo} · {payment.verification_code}</p>
          </div>
        </div>
      )}

      <div className="px-5 py-3 border-t border-gray-100 text-center bg-gray-50">
        <p className="text-xs text-gray-400">System-generated by EduTrack on {formatDate(new Date())}.</p>
      </div>
    </div>
  );
}

function ThermalReceipt({ size, payment, campus, receiptNo, studentName, formatDate, sheetRef }) {
  const { formatMoney } = usePreferences();
  const dash = size === "thermal58" ? "-".repeat(24) : "-".repeat(32);
  return (
    <div ref={sheetRef} className={`receipt-sheet bg-white shadow print:shadow-none mx-auto print:!mt-0 font-mono text-[11px] leading-relaxed px-3 py-4 ${PAGE_SPEC[size].cssWidth} print:w-full`}>
      <div className="text-center">
        <p className="font-bold text-sm uppercase">{campus?.name || "School Name"}</p>
        {campus?.address && <p className="text-[10px]">{campus.address}</p>}
        {campus?.phone && <p className="text-[10px]">{campus.phone}</p>}
      </div>
      <p className="text-center my-2">{dash}</p>
      <p className="text-center font-semibold">PAYMENT RECEIPT</p>
      <p className="text-center my-2">{dash}</p>

      <div className="space-y-0.5">
        <Row label="Receipt No" value={receiptNo} />
        <Row label="Date" value={formatDate(payment.payment_date)} />
        <Row label="Student" value={studentName} />
        <Row label="Adm No" value={payment.student?.admission_number} />
        <Row label="Class" value={`${payment.student?.class?.name || ""}${payment.student?.section?.name ? ` ${payment.student.section.name}` : ""}`} />
        <Row label="Method" value={METHOD_LABELS[payment.payment_method] || payment.payment_method} />
      </div>

      <p className="my-2">{dash}</p>
      <p className="font-semibold">{payment.feeStructure?.name || "General fee payment"}</p>
      {payment.transaction_id && <p className="text-[10px]">Txn: {payment.transaction_id}</p>}
      <p className="my-2">{dash}</p>

      <div className="flex justify-between font-bold text-sm">
        <span>TOTAL</span>
        <span>{formatMoney(payment.amount)}</span>
      </div>
      <p className="my-2">{dash}</p>
      <p className="text-[10px] italic">
        {numberToWords(payment.amount)} Shillings Only
      </p>
      <p className="text-center mt-4 text-[10px]">*** Thank you ***</p>
      {payment.verification_code && (
        <>
          <p className="my-2">{dash}</p>
          <p className="text-[10px] text-center">Verify: {receiptNo} / {payment.verification_code}</p>
        </>
      )}
      <p className="text-center text-[10px] text-gray-500">Generated by EduTrack — {formatDate(new Date())}</p>
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between gap-2">
      <span className="text-gray-600">{label}:</span>
      <span className="font-medium text-right">{value || "—"}</span>
    </div>
  );
}
