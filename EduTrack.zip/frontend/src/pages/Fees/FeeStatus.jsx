import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { feeService, messagingService } from "../../services/api";
import { resolveAcademicYearForLevel } from "../../utils/academicYear";
import { usePersistedState } from "../../hooks/usePersistedState";
import { useYearAwareClasses } from "../../hooks/useYearAwareClasses";
import MainLayout from "../../components/MainLayout";
import { Select, Button, Textarea, Input } from "../../components/ui";

const STATUS_STYLES = {
  paid: "bg-green-100 border border-green-300 text-green-500",
  partial: "bg-yellow-100 border border-yellow-300 text-yellow-600",
  unpaid: "bg-red-100 border border-red-300 text-red-500",
  "n/a": "bg-gray-100 border border-gray-300 text-gray-500",
};

export default function FeeStatus() {
  const { user, can } = useAuth();
  const { formatMoney } = usePreferences();
  const navigate = useNavigate();
  const { currentAcademicYear } = useAcademicYear();
  const { showError, showSuccess, showWarning } = useToast();

  const isStaff = can("fees.view");
  const isParent = user?.role === "parent";

  // Staff view
  const [sections, setSections] = useState([]);
  const [selectedClass, setSelectedClass] = usePersistedState("selectedClass", "");
  const [selectedSection, setSelectedSection] = usePersistedState("selectedSection", "");
  const [results, setResults] = usePersistedState("results", null);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");

  // Options refresh for the currently selected year automatically; a
  // stale selection from a previous year is re-mapped onto that same
  // class's row for the new year (see hooks/useYearAwareClasses.js).
  const classes = useYearAwareClasses({
    selectedClassId: isStaff ? selectedClass : null,
    onRemap: setSelectedClass,
  });

  // Parent view
  const [children, setChildren] = useState(null);

  // Defaulter reminders
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [reminderModal, setReminderModal] = useState(false);
  const [reminderBody, setReminderBody] = useState("Ndugu Mzazi/Mlezi, unakumbushwa kulipa ada za shule za mwanao {{student_name}}. Kiasi kilichobaki ni TZS {{balance}}. Asante kwa ushirikiano wako.");
  const [sendingReminder, setSendingReminder] = useState(false);

  useEffect(() => {
    if (isParent) {
      feeService.getMyChildrenFees().then((res) => { if (res.success) setChildren(res.data); })
        .catch((err) => showError(err.response?.data?.message || err.message));
    }
  }, [currentAcademicYear]);

  // Sections for the selected class — re-derives once `classes` finishes
  // loading; only resets the chosen section when the class actually
  // changes, so a persisted section selection survives navigating back.
  const prevClassRef = useRef(selectedClass);
  useEffect(() => {
    const cls = classes.find((c) => c.id === selectedClass);
    setSections(cls?.sections || []);
    if (prevClassRef.current !== selectedClass) setSelectedSection("");
    prevClassRef.current = selectedClass;
  }, [selectedClass, classes]);

  const loadStatus = async () => {
    if (!selectedClass) { showError("Pick a class first"); return; }
    try {
      setLoading(true);
      const cls = classes.find((c) => c.id === selectedClass);
      const resolvedYear = resolveAcademicYearForLevel(currentAcademicYear, cls?.education_level);
      const res = await feeService.getClassFeeStatus({ class_id: selectedClass, section_id: selectedSection || undefined, academic_year: resolvedYear });
      if (res.success) { setResults(res.data); setSelectedIds(new Set()); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  // Refresh automatically whenever this page is (re)mounted with a class
  // already selected — e.g. coming back from Record Payment via Back/
  // browser nav. Without this, the persisted `results` from before the
  // payment stays on screen and looks like the payment "didn't save".
  useEffect(() => {
    if (isStaff && selectedClass && classes.length > 0) loadStatus();
  }, [classes.length]); // eslint-disable-line react-hooks/exhaustive-deps

  // The search narrows the table, the "Select All Defaulters" button and so who a reminder goes to: what you see is what you pick.
  const term = search.trim().toLowerCase();
  const visibleStudents = (results?.students || []).filter((r) => !term || String(r.name || "").toLowerCase().includes(term) || String(r.admission_number || "").toLowerCase().includes(term));
  const defaulterIds = visibleStudents.filter((r) => r.payment_status === "unpaid" || r.payment_status === "partial").map((r) => r.student_id);

  const toggleSelected = (studentId) => setSelectedIds((prev) => {
    const next = new Set(prev);
    next.has(studentId) ? next.delete(studentId) : next.add(studentId);
    return next;
  });
  const selectAllDefaulters = () => setSelectedIds(new Set(defaulterIds));
  const clearSelection = () => setSelectedIds(new Set());

  const handleSendReminders = async () => {
    if (!reminderBody.trim()) { showError("Write a reminder message"); return; }
    try {
      setSendingReminder(true);
      const studentBalances = {};
      results.students.forEach((r) => { if (selectedIds.has(r.student_id)) studentBalances[r.student_id] = r.balance; });
      const res = await messagingService.sendMessage({ channel: "sms", body: reminderBody, recipient_type: "student_parents", student_ids: [...selectedIds], student_balances: studentBalances });
      if (res.success) {
        // Some students may have no parent number on file: say who was left out rather than implying everyone was reached.
        (res.skipped_students?.length ? showWarning : showSuccess)(res.message || "Reminders sent");
        setReminderModal(false); clearSelection();
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSendingReminder(false); }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Fee Status</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {isStaff ? "See who's paid, partially paid, or still owes" : "Your children's fee balance"}
            </p>
          </div>
          {isStaff && (
            <Button
              onClick={() => navigate("/fees")}
              variant="lightPrimary"
              className="animate-pulse"
              leftIcon={
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 19l-7-7m0 0l7-7m-7 7h18"
                  />
                </svg>
              }>Back to Fee Structures
            </Button>
          )}
        </div>

        {/* ── Staff: class matrix ── */}
        {isStaff && (
          <>
            <div className="bg-white p-5 rounded shadow">
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4 items-end">
                <div className="col-span-2">
                  <Input label="Search" value={search} onChange={(e) => setSearch(e.target.value)} disabled={!results}
                    placeholder={results ? "Search by student name or admission number…" : "Load a class to search its students"} />
                </div>
                <Select label="Class" required value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)}
                  options={[{ value: "", label: "Select…" }, ...classes.map((c) => ({ value: c.id, label: c.name }))]} />
                <Select label="Section" value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} disabled={!selectedClass}
                  options={[{ value: "", label: "All sections" }, ...sections.map((s) => ({ value: s.id, label: s.name }))]} />
                <button onClick={loadStatus} disabled={!selectedClass || loading} className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90 disabled:opacity-50">
                  {loading ? "Loading…" : "View Status"}
                </button>
              </div>
            </div>

            {results && (
              results.students.length === 0 ? (
                <div className="bg-white p-10 rounded shadow text-center">
                  <p className="text-gray-500 text-sm">No students in this class/section.</p>
                </div>
              ) : (
                <>
                  {/* Stats Cards */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white p-5 rounded shadow">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <p className="text-sm text-left text-gray-600">Students</p>
                          <p className="text-2xl text-left font-bold text-primary mt-1">{results.students.length}</p>
                        </div>
                        <div className="bg-primary-15 p-3 rounded">
                          <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div className="bg-white p-5 rounded shadow">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <p className="text-sm text-left text-gray-600">Total Expected</p>
                          <p className="text-2xl text-left font-bold text-indigo-600 mt-1">{formatMoney(results.totals.expected)}</p>
                        </div>
                        <div className="bg-indigo-100 p-3 rounded">
                          <svg className="w-8 h-8 text-indigo-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div className="bg-white p-5 rounded shadow">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <p className="text-sm text-left text-gray-600">Total Collected</p>
                          <p className="text-2xl text-left font-bold text-green-600 mt-1">{formatMoney(results.totals.paid)}</p>
                        </div>
                        <div className="bg-green-100 p-3 rounded">
                          <svg className="w-8 h-8 text-green-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div className="bg-white p-5 rounded shadow">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <p className="text-sm text-left text-gray-600">Outstanding</p>
                          <p className="text-2xl text-left font-bold text-red-600 mt-1">{formatMoney(results.totals.balance)}</p>
                          {/* Overpayments are excluded from Outstanding on
                              purpose — letting them net off would hide a
                              defaulter behind a student who paid too much. */}
                          {results.totals.extra > 0 && (
                            <p className="text-[11px] text-left text-blue-600 mt-0.5">+{formatMoney(results.totals.extra)} extra held</p>
                          )}
                        </div>
                        <div className="bg-red-100 p-3 rounded">
                          <svg className="w-8 h-8 text-red-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded shadow flex items-center justify-between flex-wrap gap-3">
                    <div className="flex items-center gap-3">
                      <Button variant="secondary" onClick={selectAllDefaulters} disabled={defaulterIds.length === 0}>
                        Select All Defaulters ({defaulterIds.length})
                      </Button>
                      {selectedIds.size > 0 && <button onClick={clearSelection} className="text-xs text-gray-500 hover:underline">Clear selection</button>}
                    </div>
                    {can("send_messages") && <Button onClick={() => setReminderModal(true)} disabled={selectedIds.size === 0}>
                      Send Reminder ({selectedIds.size})
                    </Button>}
                  </div>

                  <div className="bg-white rounded shadow overflow-x-auto lg:overflow-visible">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-10"></th>
                          <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Adm No.</th>
                          <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student</th>
                          <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Expected</th>
                          <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Paid</th>
                          <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Balance</th>
                          <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                          <th className="px-5 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {visibleStudents.length === 0 && (
                          <tr><td colSpan={8} className="px-5 py-8 text-center text-sm text-gray-500">No student matches "{search}".</td></tr>
                        )}
                        {visibleStudents.map((r) => {
                          const isDefaulter = r.payment_status === "unpaid" || r.payment_status === "partial";
                          return (
                            <tr key={r.student_id} className="hover:bg-gray-50 transition-colors">
                              <td className="px-4 py-2 text-center">
                                {isDefaulter && (
                                  <input type="checkbox" className="accent-primary" checked={selectedIds.has(r.student_id)} onChange={() => toggleSelected(r.student_id)} />
                                )}
                              </td>
                              <td className="px-5 py-2 text-sm text-left text-gray-700">{r.admission_number}</td>
                              <td className="px-5 py-2 text-sm text-left text-gray-700">{r.name}</td>
                              <td className="px-5 py-2 text-center text-sm font-medium text-gray-700">{formatMoney(r.expected)}</td>
                              <td className="px-5 py-2 text-center text-sm font-medium text-green-600">{formatMoney(r.paid)}</td>
                              <td className="px-5 py-2 text-center text-sm font-medium">
                                {r.extra > 0 ? (
                                  <span className="text-blue-600">+{formatMoney(r.extra)} extra</span>
                                ) : (
                                  <span className={r.balance > 0 ? "text-red-600" : "text-gray-500"}>{formatMoney(r.balance)}</span>
                                )}
                              </td>
                              <td className="px-5 py-2 text-center">
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${STATUS_STYLES[r.payment_status]}`}>{r.payment_status}</span>
                              </td>
                              <td className="px-5 py-2 text-center whitespace-nowrap text-sm font-medium">
                                <button onClick={() => navigate(`/fees/student/${r.student_id}`)} className="text-primary hover:underline">View</button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </>
              )
            )}
          </>
        )}

        {/* ── Parent: children summary ── */}
        {isParent && (
          <div className="bg-white rounded shadow divide-y divide-gray-100">
            {children === null ? (
              <div className="p-10 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
            ) : children.length === 0 ? (
              <p className="p-5 text-sm text-gray-500">No children linked to your account yet.</p>
            ) : (
              children.map((c) => (
                <button
                  key={c.student_id}
                  onClick={() => navigate(`/fees/student/${c.student_id}`)}
                  className="w-full flex flex-wrap items-center justify-between gap-2 px-5 py-4 text-left hover:bg-gray-50 transition-colors"
                >
                  <div>
                    <p className="text-sm font-medium text-gray-900">{c.name}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{c.class} {c.section} — {c.admission_number}</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-bold ${c.balance > 0 ? "text-red-600" : "text-green-600"}`}>{formatMoney(c.balance)}</p>
                    <p className="text-xs text-gray-400">balance</p>
                    {c.arrears_total > 0 && (
                      <p className="text-xs font-medium text-amber-700 mt-0.5">
                        + {formatMoney(c.arrears_total)} deni la mwaka uliopita
                      </p>
                    )}
                  </div>
                </button>
              ))
            )}
          </div>
        )}
      </div>

      {reminderModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Send Fee Reminder</h3>
              <button onClick={() => setReminderModal(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSendReminders(); }} className="px-5 py-4 space-y-4">
              <p className="text-sm text-left text-gray-600">Sending an SMS reminder to the parents of <strong>{selectedIds.size}</strong> student{selectedIds.size > 1 ? "s" : ""} with an outstanding balance.</p>
              <Textarea label="Message" required rows={4} value={reminderBody} onChange={(e) => setReminderBody(e.target.value)}
                helperText="Use {{student_name}} and {{balance}} — each parent gets a personalized message with their own child's name and amount owed." />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={sendingReminder}>Send</Button>
                <Button type="button" variant="secondary" onClick={() => setReminderModal(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </MainLayout>
  );
}
