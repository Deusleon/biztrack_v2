import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { verifyService } from "../../services/api";
import { formatMoney } from "../../utils/money";
import BrandMark from "../../components/BrandMark";

const fmtDate = (d) => (d ? new Date(d).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "—");

/**
 * Public page (no sign-in): confirms that an EduTrack SUBSCRIPTION receipt is genuine.
 * The receipt's QR code opens it with the receipt number and code already filled in.
 */
export default function VerifySubscriptionReceipt() {
  const { number: numberFromUrl, code: codeFromUrl } = useParams();
  const [receiptNo, setReceiptNo] = useState(numberFromUrl ? numberFromUrl.replace(/^INV-/, "RCT-") : "");
  const [code, setCode] = useState(codeFromUrl || "");
  const [result, setResult] = useState(null);
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState("");

  const check = async (no, c) => {
    setChecking(true); setError(""); setResult(null);
    try {
      const res = await verifyService.subscriptionReceipt(no, c);
      setResult(res.data);
    } catch {
      setError("Could not reach the verification service. Please try again.");
    } finally {
      setChecking(false);
    }
  };

  useEffect(() => { if (numberFromUrl && codeFromUrl) check(numberFromUrl, codeFromUrl); }, [numberFromUrl, codeFromUrl]);

  const submit = (e) => {
    e.preventDefault();
    if (!receiptNo.trim() || !code.trim()) return setError("Enter both the Receipt No. and the Verification Code printed on the receipt.");
    check(receiptNo.trim(), code.trim());
  };

  const Row = ({ label, value, strong }) => (
    <div className="flex justify-between gap-4 py-2 border-b border-gray-100 text-sm">
      <span className="text-gray-500">{label}</span>
      <span className={`text-right ${strong ? "font-bold text-gray-900" : "font-medium text-gray-800"}`}>{value}</span>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md bg-white rounded shadow-lg overflow-hidden text-left">
        <div className="gradient-primary-dark px-8 py-6 text-center">
          <BrandMark className="w-16 h-auto mx-auto mb-2" />
          <h1 className="text-xl font-bold tracking-tight text-white">Receipt Verification</h1>
          <p className="text-xs text-white/80 mt-1">Confirm an EduTrack subscription receipt is genuine</p>
        </div>

        <div className="p-8 space-y-5">
          {checking && <div className="text-center py-4"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>}

          {result?.valid === true && (
            <div>
              <div className="rounded px-4 py-3 bg-green-50 border border-green-200 text-green-700 font-bold text-center">Valid Receipt</div>
              <div className="mt-3">
                <Row label="Receipt No." value={result.receipt_number} strong />
                <Row label="School" value={result.school || "—"} />
                <Row label="Plan" value={`${result.plan || "—"} (${result.billing_cycle})`} />
                <Row label="Amount" value={formatMoney(result.amount, result.currency || "TZS")} strong />
                <Row label="Date paid" value={fmtDate(result.paid_at)} />
                <Row label="Service period" value={`${fmtDate(result.period_start)} to ${fmtDate(result.period_end)}`} />
              </div>
              <p className="text-[11px] text-gray-500 mt-3">If the amount or date on your copy differs from the above, the copy has been altered.</p>
            </div>
          )}
          {result?.valid === false && (
            <div className="rounded px-4 py-3 bg-red-50 border border-red-200 text-red-700 text-center">
              <p className="font-bold">Not a Valid Receipt</p>
              <p className="text-xs mt-1">The receipt number and code do not match any payment received by EduTrack.</p>
            </div>
          )}
          {error && <p className="text-sm text-red-600">{error}</p>}

          <form onSubmit={submit} className="space-y-3">
            <div>
              <label className="text-xs font-medium text-gray-700 block mb-1">Receipt No.</label>
              <input className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-primary" placeholder="RCT-2026-00004" value={receiptNo} onChange={(e) => setReceiptNo(e.target.value)} />
            </div>
            <div>
              <label className="text-xs font-medium text-gray-700 block mb-1">Verification Code</label>
              <input className="w-full border border-gray-300 rounded px-3 py-2 text-sm uppercase focus:outline-none focus:border-primary" placeholder="10 characters" value={code} onChange={(e) => setCode(e.target.value)} />
            </div>
            <button type="submit" className="w-full bg-primary text-white text-sm py-2.5 rounded hover:opacity-90">Verify</button>
          </form>
        </div>
      </div>
    </div>
  );
}
