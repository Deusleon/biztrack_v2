import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { authService } from "../services/api";
import { Input, Button } from "../components/ui";
import { isStrongPassword, passwordChecks } from "../utils/passwordRules";
import BrandMark from "../components/BrandMark";

/**
 * Shown INSTEAD of the app while an account still has the shared starting
 * password. Nothing behind it is loaded (the server refuses every other request
 * for such an account anyway), so there is no way to carry on without choosing a
 * password. When it is saved the person is signed out and signs in again with
 * the new one.
 */
export default function ForcePasswordChange() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ current_password: "", new_password: "", confirm_password: "" });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const set = (field) => (e) => { setForm((f) => ({ ...f, [field]: e.target.value })); setError(""); };

  const checks = [
    ...passwordChecks(form.new_password),
    { ok: form.new_password.length > 0 && form.new_password !== form.current_password, label: "Different from your current password" },
    { ok: form.confirm_password.length > 0 && form.new_password === form.confirm_password, label: "Both new passwords match" },
  ];
  const ready = form.current_password && isStrongPassword(form.new_password) && checks.every((c) => c.ok);

  const signOut = () => { logout(); navigate("/login", { replace: true }); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!ready || saving) return;
    try {
      setSaving(true);
      const res = await authService.changePassword({ current_password: form.current_password, new_password: form.new_password });
      if (res.success) {
        // Read once by the sign-in page. Stored (not passed in navigation state)
        // because signing out also redirects, and either redirect may win.
        try { sessionStorage.setItem("loginNotice", "Your password has been changed. Please sign in with your new password."); } catch { /* ignore */ }
        logout();
        navigate("/login", { replace: true });
      }
    } catch (err) {
      setError(err.message || "Could not change the password. Please try again.");
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4 py-8">
      <div className="max-w-md w-full bg-white rounded shadow-lg overflow-hidden">
        <div className="gradient-primary-dark px-8 py-6 text-center">
          <BrandMark className="w-16 h-auto mx-auto mb-2" />
          <h1 className="text-xl font-bold tracking-tight text-white">Choose a new password</h1>
          <p className="text-sm text-white opacity-80 mt-0.5">EduTrack</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-4 text-left">
          <p className="text-sm text-gray-700 leading-relaxed">
            Welcome{user?.first_name ? `, ${user.first_name}` : ""}. You signed in with the standard starting password.
            For your security, choose a password only you know before you continue. You'll then be signed out and can sign in with it.
          </p>

          {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded" role="alert">{error}</div>}

          <Input
            label="Current password" type="password" required autoComplete="current-password"
            value={form.current_password} onChange={set("current_password")}
            helperText="The password you were given"
          />
          <Input
            label="New password" type="password" required autoComplete="new-password"
            value={form.new_password} onChange={set("new_password")}
          />
          <Input
            label="Confirm new password" type="password" required autoComplete="new-password"
            value={form.confirm_password} onChange={set("confirm_password")}
          />

          <ul className="text-xs space-y-1">
            {checks.map((c) => (
              <li key={c.label} className={c.ok ? "text-green-700" : "text-gray-500"}>{c.ok ? "✓" : "○"} {c.label}</li>
            ))}
          </ul>

          <Button type="submit" loading={saving} disabled={!ready} className="w-full">Change password</Button>
          <button type="button" onClick={signOut} className="block mx-auto text-xs text-gray-500 hover:text-gray-700 underline">Sign out</button>
        </form>
      </div>
    </div>
  );
}
