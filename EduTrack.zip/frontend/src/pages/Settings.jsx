// FILE PATH: frontend/src/pages/Settings.jsx
import { useState, useEffect, useRef, Fragment } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme, presetThemes } from '../contexts/ThemeContext';
import { usePreferences, RECEIPT_SIZES, MONEY_DECIMAL_OPTIONS } from '../contexts/PreferencesContext';
import { useToast } from '../contexts/ToastContext';
import InstallAppCard from '../components/InstallAppCard';
import DatabaseBackupPanel from '../components/DatabaseBackupPanel';
import WebsiteContentPanel from '../components/WebsiteContentPanel';
import { DATE_FORMATS } from '../utils/dateFormat';
import { notificationService, messagingService, permissionsService, campusService, authService, settingsService } from '../services/api';
import { useCampus } from '../contexts/CampusContext';
import { Navigate } from 'react-router-dom';
import Select from '../components/ui/Select';
import Input from '../components/ui/Input';
import Textarea from '../components/ui/Textarea';
import Button from '../components/ui/Button';
import { DataTable, RowActions, ACTION_ICONS } from '../components/ui';
import AuditLogDetailModal, { KindBadge } from '../components/AuditLogDetailModal';
import { fieldLabel } from '../utils/auditLogView';
import DatePicker from '../components/ui/DatePicker';
import NumberInput from '../components/ui/NumberInput';
import MainLayout from '../components/MainLayout';

export default function Settings() {
  const { isAuthenticated, user, can } = useAuth();
  const { theme, setPresetTheme, setCustomTheme } = useTheme();
  const { dateFormat, setDateFormat, defaultReceiptSize, setDefaultReceiptSize, moneyDecimals, setMoneyDecimals } = usePreferences();
  const { showSuccess: toastSuccess, showError: toastError } = useToast();
  // These three settings belong to the whole school, so only people with this permission change them.
  const canChangeDisplay = can('settings.display');
  const changeDisplay = async (setter, value) => {
    try {
      await setter(value);
      toastSuccess('Saved for the whole school');
    } catch (err) {
      toastError(err.response?.data?.message || err.message);
    }
  };
  // ?tab=… lets a link (e.g. coming back from Google) open a specific tab.
  const [activeTab, setActiveTab] = useState(() => new URLSearchParams(window.location.search).get('tab') || 'school');
  const [customColors, setCustomColors] = useState({
    primary: theme.primary || '#2563eb',
    primaryDark: theme.primaryDark || '#1e40af',
    primaryLight: theme.primaryLight || '#3b82f6',
    accent: theme.accent || '#06b6d4',
  });

  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  const handlePresetClick = (presetKey) => {
    setPresetTheme(presetKey);
  };

  const handleCustomColorChange = (colorKey, value) => {
    setCustomColors(prev => ({
      ...prev,
      [colorKey]: value,
    }));
  };

  const applyCustomTheme = () => {
    setCustomTheme('Custom Theme', customColors);
  };

  const tabs = [
    { id: 'school', name: 'School', icon: '' },
    { id: 'general', name: 'General', icon: '' },
    ...(can('notifications.manage') ? [{ id: 'notifications', name: 'Notifications', icon: '' }] : []),
    ...(user?.is_developer ? [{ id: 'messages', name: 'Messages', icon: '' }] : []),
    ...(can('permissions.manage') ? [{ id: 'permissions', name: 'Permissions', icon: '' }] : []),
    ...(can('settings.academic_year') ? [{ id: 'academic_year', name: 'Academic Year', icon: '' }] : []),
    ...(can('settings.backup') ? [{ id: 'backup', name: 'Backup & Export', icon: '' }] : []),
    ...(user?.is_developer ? [{ id: 'database_backup', name: 'Database Backup', icon: '' }] : []),
    ...(can('audit.view') ? [{ id: 'audit_log', name: 'Audit Log', icon: '' }] : []),
    ...(can('settings.login_policy') ? [{ id: 'login_policy', name: 'Login Policy', icon: '' }] : []),
    ...(can('settings.website') ? [{ id: 'website', name: 'Website', icon: '' }] : []),
    { id: 'theme', name: 'Theme & Colors', icon: '' },
    { id: 'security', name: 'Security', icon: '' },
  ];

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className='text-left'>
          <h1 className="text-xl font-bold text-gray-900">Settings</h1>
          <p className="text-sm text-gray-500 mt-0.5">Manage your system preferences and configuration</p>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded shadow overflow-x-auto">
          <nav className="flex min-w-max">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${activeTab === tab.id
                  ? 'border-primary text-primary'
                  : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-200'
                  }`}
              >
                <span>{tab.icon}</span>
                {tab.name}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="bg-white rounded shadow-md p-5">
          {activeTab === 'theme' && (
            <div className="space-y-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Choose a Theme</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {Object.entries(presetThemes).map(([key, preset]) => (
                    <button
                      key={key}
                      onClick={() => handlePresetClick(key)}
                      className={`relative p-4 rounded border-2 transition-all ${theme.name === preset.name
                        ? 'border-primary shadow-lg'
                        : 'border-gray-200 hover:border-gray-300'
                        }`}
                    >
                      <div className="space-y-2">
                        <div className="flex space-x-1 mb-3">
                          <div
                            className="w-8 h-8 rounded"
                            style={{ backgroundColor: preset.primary }}
                          ></div>
                          <div
                            className="w-8 h-8 rounded"
                            style={{ backgroundColor: preset.primaryDark }}
                          ></div>
                          <div
                            className="w-8 h-8 rounded"
                            style={{ backgroundColor: preset.accent }}
                          ></div>
                        </div>
                        <p className="text-sm font-medium text-gray-900">{preset.name}</p>
                      </div>
                      {theme.name === preset.name && (
                        <div className="absolute top-2 right-2">
                          <svg className="w-5 h-5 text-primary" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          </svg>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Custom Colors</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Primary Color
                    </label>
                    <div className="flex items-center space-x-3">
                      <input
                        type="color"
                        value={customColors.primary}
                        onChange={(e) => handleCustomColorChange('primary', e.target.value)}
                        className="w-16 h-10 rounded border border-gray-300 cursor-pointer"
                      />
                      <Input
                        className="flex-1"
                        value={customColors.primary}
                        onChange={(e) => handleCustomColorChange('primary', e.target.value)}
                        placeholder="#2563eb"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Primary Dark
                    </label>
                    <div className="flex items-center space-x-3">
                      <input
                        type="color"
                        value={customColors.primaryDark}
                        onChange={(e) => handleCustomColorChange('primaryDark', e.target.value)}
                        className="w-16 h-10 rounded border border-gray-300 cursor-pointer"
                      />
                      <Input
                        className="flex-1"
                        value={customColors.primaryDark}
                        onChange={(e) => handleCustomColorChange('primaryDark', e.target.value)}
                        placeholder="#1e40af"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Primary Light
                    </label>
                    <div className="flex items-center space-x-3">
                      <input
                        type="color"
                        value={customColors.primaryLight}
                        onChange={(e) => handleCustomColorChange('primaryLight', e.target.value)}
                        className="w-16 h-10 rounded border border-gray-300 cursor-pointer"
                      />
                      <Input
                        className="flex-1"
                        value={customColors.primaryLight}
                        onChange={(e) => handleCustomColorChange('primaryLight', e.target.value)}
                        placeholder="#3b82f6"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Accent Color
                    </label>
                    <div className="flex items-center space-x-3">
                      <input
                        type="color"
                        value={customColors.accent}
                        onChange={(e) => handleCustomColorChange('accent', e.target.value)}
                        className="w-16 h-10 rounded border border-gray-300 cursor-pointer"
                      />
                      <Input
                        className="flex-1"
                        value={customColors.accent}
                        onChange={(e) => handleCustomColorChange('accent', e.target.value)}
                        placeholder="#06b6d4"
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex items-center space-x-4">
                  <Button onClick={applyCustomTheme}>
                    Apply Custom Theme
                  </Button>
                  <div className="flex items-center space-x-2">
                    <div className="text-sm text-gray-500">Preview:</div>
                    <div className="flex space-x-1">
                      <div
                        className="w-6 h-6 rounded"
                        style={{ backgroundColor: customColors.primary }}
                      ></div>
                      <div
                        className="w-6 h-6 rounded"
                        style={{ backgroundColor: customColors.primaryDark }}
                      ></div>
                      <div
                        className="w-6 h-6 rounded"
                        style={{ backgroundColor: customColors.primaryLight }}
                      ></div>
                      <div
                        className="w-6 h-6 rounded"
                        style={{ backgroundColor: customColors.accent }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-blue-800">Theme Tip</h3>
                    <p className="mt-1 text-sm text-blue-700">
                      Your theme preference is saved locally and will persist across sessions. Choose colors that match your institution's branding!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'general' && (
            <>
              <div className={`mb-6 rounded px-4 py-3 text-sm text-left ${canChangeDisplay ? 'bg-blue-50 border border-blue-200 text-blue-800' : 'bg-gray-50 border border-gray-200 text-gray-600'}`}>
                {canChangeDisplay
                  ? 'These settings apply to everyone at your school, on every computer.'
                  : 'These settings are shared by the whole school. Only an administrator can change them.'}
              </div>
            <div className="flex flex-col gap-6 md:gap-0 md:space-x-12 md:flex-row">
              <div className='w-full md:w-1/2'>
                <h3 className="text-base text-left font-semibold text-gray-900 mb-1">Date Format</h3>
                <p className="text-sm text-left text-gray-500 mb-4">Applies to every date shown across the app — reports, tables, receipts, and forms.</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {DATE_FORMATS.map((f) => (
                    <button
                      key={f.value}
                      onClick={() => changeDisplay(setDateFormat, f.value)}
                      disabled={!canChangeDisplay}
                      className={`text-left border rounded px-4 py-3 transition-colors ${dateFormat === f.value ? 'border-primary bg-primary/5 ring-1 ring-primary' : 'border-gray-200 hover:border-gray-300'
                        }`}
                    >
                      <p className="text-sm font-semibold text-gray-900">{f.label}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{f.example}</p>
                    </button>
                  ))}
                </div>
              </div>
              <div className='hidden md:block border'></div>
              <div className="w-full md:w-1/2">
                <h3 className="text-base text-left font-semibold text-gray-900 mb-1">Default Receipt Size</h3>
                <p className="text-sm text-left text-gray-500 mb-4">
                  The paper size payment receipts open with by default. You can still switch sizes when printing any individual receipt.
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {RECEIPT_SIZES.map((s) => (
                    <button
                      key={s.value}
                      onClick={() => changeDisplay(setDefaultReceiptSize, s.value)}
                      disabled={!canChangeDisplay}
                      className={`text-center border rounded px-4 py-3 transition-colors ${defaultReceiptSize === s.value ? 'border-primary bg-primary/5 ring-1 ring-primary' : 'border-gray-200 hover:border-gray-300'
                        }`}
                    >
                      <p className="text-sm font-semibold text-gray-900">{s.label}</p>
                    </button>
                  ))}
                </div>

                <h3 className="text-base text-left font-semibold text-gray-900 mb-1 mt-6">Money Decimals</h3>
                <p className="text-sm text-left text-gray-500 mb-4">
                  How many decimal places to show for TZS amounts across fee structures, receipts, and reports.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {MONEY_DECIMAL_OPTIONS.map((o) => (
                    <button
                      key={o.value}
                      onClick={() => changeDisplay(setMoneyDecimals, o.value)}
                      disabled={!canChangeDisplay}
                      className={`text-left border rounded px-4 py-3 transition-colors ${!canChangeDisplay ? 'opacity-60 cursor-not-allowed ' : ''}${moneyDecimals === o.value ? 'border-primary bg-primary/5 ring-1 ring-primary' : 'border-gray-200 hover:border-gray-300'
                        }`}
                    >
                      <p className="text-sm font-semibold text-gray-900">{o.label}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
              <InstallAppCard />
            </>
          )}

          {activeTab === 'school' && <SchoolBrandingPanel />}

          {activeTab === 'notifications' && <NotificationEventsPanel />}

          {activeTab === 'messages' && (
            <div className="flex flex-col gap-6 md:gap-0 md:space-x-12 md:flex-row">
              <div className='w-full md:w-1/2'>
                <SmsGatewayPanel />
              </div>
              <div className='hidden md:block border'></div>
              <div className='w-full md:w-1/2'>
                <EmailGatewayPanel />
              </div>
            </div>
          )}

          {activeTab === 'permissions' && <PermissionsPanel />}

          {activeTab === 'academic_year' && <AcademicYearPanel />}

          {activeTab === 'backup' && <BackupExportPanel />}
          {activeTab === 'database_backup' && user?.is_developer && <DatabaseBackupPanel />}

          {activeTab === 'audit_log' && <AuditLogPanel />}

          {activeTab === 'website' && can('settings.website') && <WebsiteContentPanel />}

          {activeTab === 'login_policy' && <LoginPolicyPanel />}

          {activeTab === 'security' && <SecurityPanel />}
        </div>
      </div>
    </MainLayout>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Notification event settings — which automatic events fire, and where
// ─────────────────────────────────────────────────────────────────────────
function NotificationEventsPanel() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [savingKey, setSavingKey] = useState("");
  const { showSuccess, showError } = useToast();

  useEffect(() => {
    notificationService.getEventSettings()
      .then((res) => { if (res.success) setEvents(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, []);

  const toggleEnabled = async (evt) => {
    try {
      setSavingKey(evt.event_key);
      const res = await notificationService.updateEventSetting({ event_key: evt.event_key, enabled: !evt.enabled });
      if (res.success) setEvents((prev) => prev.map((e) => (e.event_key === evt.event_key ? { ...e, enabled: !evt.enabled } : e)));
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSavingKey(""); }
  };

  // Who is told, and how: { party: [channels] } — saved as one piece so a notification can never end up half-changed.
  const saveAudience = async (evt, audience) => {
    try {
      setSavingKey(evt.event_key);
      const res = await notificationService.updateEventSetting({ event_key: evt.event_key, audience });
      if (res.success) {
        setEvents((prev) => prev.map((e) => (e.event_key !== evt.event_key ? e : {
          ...e,
          parties: e.parties.map((p) => ({ ...p, enabled: Boolean(audience[p.key]), channels: audience[p.key] || p.channels })),
        })));
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSavingKey(""); }
  };
  const audienceOf = (evt) => Object.fromEntries(evt.parties.filter((p) => p.enabled).map((p) => [p.key, p.channels]));

  const toggleParty = (evt, party) => {
    const audience = audienceOf(evt);
    if (party.enabled) delete audience[party.key]; else audience[party.key] = party.channels?.length ? party.channels : ["in_app"];
    saveAudience(evt, audience);
  };
  const togglePartyChannel = (evt, party, channel) => {
    const audience = audienceOf(evt);
    audience[party.key] = party.channels.includes(channel) ? party.channels.filter((c) => c !== channel) : [...party.channels, channel];
    saveAudience(evt, audience);
  };

  if (loading) return <div className="py-12 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>;

  // Password reset codes are a choice of WHERE, never an on/off switch — they get
  // their own card instead of a toggle (a school that turned them off would leave
  // people unable to recover their own account).
  const resetEvent = events.find((e) => e.event_key === "password_reset");
  const resetMode = !resetEvent ? "email" : resetEvent.channels.includes("sms") ? (resetEvent.channels.includes("email") ? "either" : "sms") : "email";
  const chooseResetMode = async (mode) => {
    const channels = mode === "either" ? ["email", "sms"] : [mode];
    try {
      setSavingKey("password_reset");
      const res = await notificationService.updateEventSetting({ event_key: "password_reset", channels });
      if (res.success) {
        setEvents((prev) => prev.map((e) => (e.event_key === "password_reset" ? { ...e, channels } : e)));
        showSuccess("Password reset codes will be sent " + (mode === "either" ? "by email or SMS" : mode === "sms" ? "by SMS" : "by email"));
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSavingKey(""); }
  };
  const RESET_CHOICES = [
    { value: "email", title: "Email only", note: "The form asks for an email address. Free — recommended." },
    { value: "sms", title: "SMS only", note: "The form asks for a phone number. Uses your SMS credits." },
    { value: "either", title: "Email or SMS", note: "The form accepts either, and the code goes to every email / phone the account has." },
  ];

  return (
    <div className="w-full space-y-5">
      {resetEvent && (
        <div className="border border-gray-200 rounded-lg p-4 text-left">
          <p className="text-sm font-medium text-gray-900">Password reset codes</p>
          <p className="text-xs text-gray-500 mt-0.5">When someone forgets their password they get a 6-digit code. Choose where it is sent — and so what the "Forgot password" page asks for.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3">
            {RESET_CHOICES.map((c) => (
              <label key={c.value} className={`border rounded p-3 cursor-pointer ${resetMode === c.value ? "border-primary bg-primary-15" : "border-gray-200 hover:border-gray-300"}`}>
                <span className="flex items-center gap-2 text-sm font-medium text-gray-900">
                  <input type="radio" name="reset_mode" checked={resetMode === c.value} onChange={() => chooseResetMode(c.value)} disabled={savingKey === "password_reset"} className="accent-primary" />
                  {c.title}
                </span>
                <span className="block text-xs text-gray-500 mt-1 ml-6">{c.note}</span>
              </label>
            ))}
          </div>
          {resetMode !== "email" && <p className="text-xs text-amber-700 mt-2">SMS needs an active SMS gateway (set up by your platform administrator in Settings → Messages); without one no code can be sent by SMS.</p>}
        </div>
      )}
      <div>
        <h3 className="text-base text-left font-semibold text-gray-900 mb-1">Automatic Notifications</h3>
        <p className="text-sm text-left text-gray-500">Choose which events notify people automatically, who is told (for example the parent only, the finance office only, or both) and through which channel. Staff can only be reached by SMS or email if their profile has a phone number or email address.</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {events.filter((evt) => evt.event_key !== "password_reset").map((evt) => (
          <div key={evt.event_key} className="border border-gray-200 rounded-lg p-4 flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <p className="text-sm text-left font-medium text-gray-900">{evt.label}</p>
              <p className="text-xs text-left text-gray-500 mt-0.5">{evt.description}</p>
              {evt.enabled && (
                <div className="mt-3 space-y-2 text-left">
                  <p className="text-[11px] font-semibold uppercase tracking-wide text-gray-400">{evt.parties.length > 1 ? "Send to" : "Sent to"}</p>
                  {evt.parties.map((party) => (
                    <div key={party.key} className={`rounded border px-3 py-2 ${party.enabled ? "border-gray-200 bg-white" : "border-dashed border-gray-200 bg-gray-50"}`}>
                      <label className="flex items-start gap-2 cursor-pointer">
                        <input type="checkbox" checked={party.enabled} onChange={() => toggleParty(evt, party)} disabled={savingKey === evt.event_key} className="accent-primary mt-0.5" />
                        <span className="min-w-0">
                          <span className={`block text-sm ${party.enabled ? "text-gray-900" : "text-gray-500"}`}>{party.label}</span>
                          {party.description && <span className="block text-xs text-gray-400">{party.description}</span>}
                        </span>
                      </label>
                      {party.enabled && (
                        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 ml-6">
                          {["in_app", "sms", "email"].map((ch) => (
                            <label key={ch} className="flex items-center gap-1.5 text-xs text-gray-600 cursor-pointer">
                              <input type="checkbox" checked={party.channels.includes(ch)} onChange={() => togglePartyChannel(evt, party, ch)} className="accent-primary" disabled={savingKey === evt.event_key} />
                              {ch === "in_app" ? "In-App" : ch.toUpperCase()}
                            </label>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                  {evt.parties.length > 1 && evt.parties.every((p) => !p.enabled) && <p className="text-xs text-amber-700">Nobody is chosen, so nothing will be sent. Tick at least one, or switch the notification off.</p>}
                </div>
              )}
            </div>
            <button
              onClick={() => toggleEnabled(evt)}
              disabled={savingKey === evt.event_key}
              aria-label={`${evt.enabled ? "Switch off" : "Switch on"} ${evt.label}`}
              className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${evt.enabled ? "bg-primary" : "bg-gray-300"}`}
            >
              <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${evt.enabled ? "translate-x-5" : ""}`} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Staff Permissions Manager
// ─────────────────────────────────────────────────────────────────────────
function PermissionsPanel() {
  return (
    <div className="w-full space-y-4">
      <div>
        <h3 className="text-base text-left font-semibold text-gray-900 mb-1">Permissions</h3>
        <p className="text-sm text-left text-gray-500">Every action in EduTrack follows a permission. Role Permissions decide what each role can do — tick to allow, untick to take away (any role, the Principal too). Individual Overrides give one specific person extra permissions on top of their role. Admins can always do everything.</p>
      </div>
      <div className="flex flex-col gap-6 md:gap-0 md:space-x-12 md:flex-row">
        <div className="w-full md:w-1/2">
          <RolePermissionsTab />
        </div>
        <div className="hidden md:block border"></div>
        <div className="w-full md:w-1/2">
          <IndividualPermissionsTab />
        </div>
      </div>
    </div>
  );
}

function PermissionGrid({ available, granted, onToggle, onCheckAll, saving }) {
  const modules = [...new Set(available.map((p) => p.module))];
  const [selectedModule, setSelectedModule] = useState(modules[0] || "");
  const [search, setSearch] = useState("");

  // Keep the selection valid if the available list changes (e.g. switching role/staff).
  useEffect(() => {
    if (modules.length > 0 && !modules.includes(selectedModule)) setSelectedModule(modules[0]);
  }, [available]); // eslint-disable-line react-hooks/exhaustive-deps

  const moduleLabel = (mod) => mod.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

  const searchMatches = search.trim()
    ? available.filter((p) => p.label.toLowerCase().includes(search.trim().toLowerCase()))
    : [];

  const activeModule = search.trim() ? null : selectedModule;
  const modPerms = activeModule
    ? available.filter((p) => p.module === activeModule)
    : searchMatches;
  const grantedCountFor = (mod) => available.filter((p) => p.module === mod && granted.includes(p.key)).length;
  const totalFor = (mod) => available.filter((p) => p.module === mod).length;
  const allChecked = activeModule ? grantedCountFor(activeModule) === totalFor(activeModule) && totalFor(activeModule) > 0 : false;

  return (
    <div className="border border-gray-200 rounded overflow-hidden flex flex-col sm:flex-row" style={{ minHeight: "22rem" }}>
      {/* Module list (left pane) */}
      <div className="sm:w-56 flex-shrink-0 border-b sm:border-b-0 sm:border-r border-gray-200 bg-gray-50 flex flex-col">
        <div className="p-2 border-b border-gray-200">
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search permissions..."
          />
        </div>
        <div className="overflow-y-auto flex-1" style={{ maxHeight: "20rem" }}>
          {modules.map((mod) => {
            const grantedCount = grantedCountFor(mod);
            const total = totalFor(mod);
            const isSelected = !search.trim() && selectedModule === mod;
            return (
              <button
                key={mod}
                type="button"
                onClick={() => { setSearch(""); setSelectedModule(mod); }}
                className={`w-full text-left px-3 py-2.5 flex flex-wrap items-center justify-between gap-2 border-l-2 transition-colors ${isSelected ? "border-primary bg-white" : "border-transparent hover:bg-gray-100"
                  }`}
              >
                <span className={`text-sm capitalize truncate ${isSelected ? "text-gray-900 font-medium" : "text-gray-600"}`}>
                  {moduleLabel(mod)}
                </span>
                <span className={`text-xs flex-shrink-0 px-1.5 py-0.5 rounded-full ${grantedCount === total ? "bg-primary-10 text-primary" : grantedCount > 0 ? "bg-gray-200 text-gray-600" : "bg-gray-100 text-gray-400"
                  }`}>
                  {grantedCount}/{total}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Permissions list (right pane) */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b border-gray-200 bg-gray-50">
          <span className="text-sm font-medium text-gray-800">
            {search.trim() ? `Search results for "${search.trim()}"` : moduleLabel(activeModule || "")}
          </span>
          {activeModule && (
            <label className="flex items-center gap-2 cursor-pointer">
              <span className="text-xs text-gray-500">Check All</span>
              <button type="button" disabled={saving} onClick={() => onCheckAll(modPerms.map((p) => p.key), !allChecked)}
                className={`relative w-9 h-5 rounded-full transition-colors flex-shrink-0 ${allChecked ? "bg-primary" : "bg-gray-300"}`}>
                <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${allChecked ? "translate-x-4" : ""}`} />
              </button>
            </label>
          )}
        </div>
        <div className="divide-y divide-gray-100 overflow-y-auto flex-1" style={{ maxHeight: "20rem" }}>
          {modPerms.length === 0 ? (
            <p className="text-sm text-gray-400 px-4 py-6 text-center">
              {search.trim() ? "No permissions match your search." : "No permissions in this module."}
            </p>
          ) : (
            modPerms.map((perm) => (
              <label key={perm.key} className="flex flex-wrap items-center justify-between gap-2 gap-3 px-4 py-2.5 cursor-pointer hover:bg-gray-50">
                <div className="min-w-0">
                  <span className="text-sm text-gray-700">{perm.label}</span>
                  {search.trim() && (
                    <span className="block text-xs text-gray-400 capitalize">{moduleLabel(perm.module)}</span>
                  )}
                </div>
                <button type="button" disabled={saving} onClick={() => onToggle(perm.key)}
                  className={`relative w-9 h-5 rounded-full transition-colors flex-shrink-0 ${granted.includes(perm.key) ? "bg-primary" : "bg-gray-300"}`}>
                  <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${granted.includes(perm.key) ? "translate-x-4" : ""}`} />
                </button>
              </label>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function RolePermissionsTab() {
  const [roles, setRoles] = useState([]);
  const [available, setAvailable] = useState([]);
  const [selectedRole, setSelectedRole] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { showError, showSuccess } = useToast();

  useEffect(() => {
    Promise.all([permissionsService.getRolePermissions(), permissionsService.getAvailable()])
      .then(([roleRes, availRes]) => {
        if (roleRes.success) {
          const editable = roleRes.data.filter((r) => !r.always_allowed); // admins can't be restricted
          setRoles(editable); setSelectedRole(editable[0]?.role || "");
        }
        if (availRes.success) setAvailable(availRes.data);
      })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, []);

  const current = roles.find((r) => r.role === selectedRole);

  const save = async (nextPermissions) => {
    try {
      setSaving(true);
      const res = await permissionsService.updateRolePermissions(selectedRole, nextPermissions);
      if (res.success) setRoles((prev) => prev.map((r) => (r.role === selectedRole ? { ...r, permissions: nextPermissions, customised: true } : r)));
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const resetToStandard = async () => {
    try {
      setSaving(true);
      const res = await permissionsService.resetRolePermissions(selectedRole);
      if (res.success) {
        setRoles((prev) => prev.map((r) => (r.role === selectedRole ? { ...r, permissions: res.data.permissions, customised: false } : r)));
        showSuccess("Back to the standard permissions for this role");
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleToggle = (key) => {
    if (!current) return;
    const has = current.permissions.includes(key);
    save(has ? current.permissions.filter((p) => p !== key) : [...current.permissions, key]);
  };
  const handleCheckAll = (keys, checked) => {
    if (!current) return;
    const withoutThese = current.permissions.filter((p) => !keys.includes(p));
    save(checked ? [...withoutThese, ...keys] : withoutThese);
  };

  if (loading) return <div className="py-12 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>;

  return (
    <div className="space-y-4 pt-3">
      <h3 className="text-base text-left font-semibold text-gray-900">Role Permissions</h3>
      <p className="text-xs text-left text-gray-500">Super Admin and Admin always have full access, so they aren't listed. Every other role — the Principal included — can do exactly what is ticked here. What you see ticked is what the role can really do right now.</p>
      <Select label="Role" value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)}
        options={roles.map((r) => ({ value: r.role, label: r.role.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()) }))} />
      {current && (
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className={current.customised ? "text-amber-700" : "text-gray-500"}>{current.customised ? "Customised for this school" : "Standard permissions"}</span>
          {current.customised && <button type="button" onClick={resetToStandard} disabled={saving} className="text-primary hover:underline disabled:text-gray-400">Reset to standard</button>}
        </div>
      )}
      {current && <PermissionGrid available={available} granted={current.permissions} onToggle={handleToggle} onCheckAll={handleCheckAll} saving={saving} />}
    </div>
  );
}

function IndividualPermissionsTab() {
  const [staff, setStaff] = useState([]);
  const [available, setAvailable] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { showError } = useToast();

  useEffect(() => {
    Promise.all([permissionsService.getStaffPermissions(), permissionsService.getAvailable()])
      .then(([staffRes, availRes]) => {
        if (staffRes.success) { setStaff(staffRes.data); setSelectedUserId(staffRes.data[0]?.user_id || ""); }
        if (availRes.success) setAvailable(availRes.data);
      })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, []);

  const current = staff.find((s) => s.user_id === selectedUserId);

  const save = async (nextPermissions) => {
    try {
      setSaving(true);
      const res = await permissionsService.updateUserPermissions(selectedUserId, nextPermissions);
      if (res.success) setStaff((prev) => prev.map((s) => (s.user_id === selectedUserId ? { ...s, permissions: nextPermissions } : s)));
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleToggle = (key) => {
    if (!current) return;
    const has = current.permissions.includes(key);
    save(has ? current.permissions.filter((p) => p !== key) : [...current.permissions, key]);
  };
  const handleCheckAll = (keys, checked) => {
    if (!current) return;
    const withoutThese = current.permissions.filter((p) => !keys.includes(p));
    save(checked ? [...withoutThese, ...keys] : withoutThese);
  };

  if (loading) return <div className="py-12 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>;
  if (staff.length === 0) return <p className="text-sm text-gray-400 py-6">No active staff found.</p>;

  return (
    <div className="space-y-4 pt-3">
      <h3 className="text-base text-left font-semibold text-gray-900">Individual Overrides</h3>
      <p className="text-xs text-left text-gray-500">These add to whatever the person's role already grants — they never take anything away.</p>
      <Select label="Staff Member" value={selectedUserId} onChange={(e) => setSelectedUserId(e.target.value)}
        options={staff.map((s) => ({ value: s.user_id, label: `${s.name} (${s.role.replace("_", " ")})` }))} />
      {current && <PermissionGrid available={available} granted={current.permissions} onToggle={handleToggle} onCheckAll={handleCheckAll} saving={saving} />}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Academic Year & Term settings
// ─────────────────────────────────────────────────────────────────────────
function AcademicYearPanel() {
  const { showSuccess, showError } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [startYear, setStartYear] = useState('');
  const [terms, setTerms] = useState([]);

  useEffect(() => {
    settingsService.getOverview()
      .then((res) => {
        if (res.success) {
          setStartYear(String(res.data.academic_records_start_year || ''));
          setTerms(res.data.terms?.length ? res.data.terms : [{ name: '', start_date: '', end_date: '' }]);
        }
      })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const updateTerm = (index, field, value) => {
    setTerms((prev) => prev.map((t, i) => (i === index ? { ...t, [field]: value } : t)));
  };
  const addTerm = () => setTerms((prev) => [...prev, { name: '', start_date: '', end_date: '' }]);
  const removeTerm = (index) => setTerms((prev) => prev.filter((_, i) => i !== index));

  const handleSave = async () => {
    const year = parseInt(startYear, 10);
    if (!Number.isFinite(year) || year < 2000 || year > 2100) {
      return showError('Enter a valid 4-digit year');
    }
    const cleanTerms = terms.filter((t) => t.name.trim());
    for (const t of cleanTerms) {
      if (t.start_date && t.end_date && new Date(t.start_date) > new Date(t.end_date)) {
        return showError(`"${t.name}": end date is before its start date`);
      }
    }
    try {
      setSaving(true);
      const res = await settingsService.updateAcademicYear({ academic_records_start_year: year, terms: cleanTerms });
      if (res.success) {
        showSuccess('Academic year settings updated');
        setTerms(cleanTerms.length ? cleanTerms : [{ name: '', start_date: '', end_date: '' }]);
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  if (loading) return <div className="py-12 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>;

  return (
    <div className="w-full space-y-8 text-left">
      <div>
        <h3 className="text-base font-semibold text-gray-900 mb-1">System Start Year</h3>
        <p className="text-sm text-gray-500 mb-4">
          The earliest academic year this school has real records for in EduTrack. The year picker across the app
          never offers anything earlier, and historical/projected student data is never guessed before it.
        </p>
        <div className="max-w-xs">
          <NumberInput
            label="Start Year"
            name="startYear"
            value={startYear}
            onChange={(e) => setStartYear(e.target.value)}
            allowDecimals={false}
            placeholder="2024"
          />
        </div>
      </div>

      <div className="border-t border-gray-100 pt-6">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
          <h3 className="text-base font-semibold text-gray-900">Terms / Semesters</h3>
          <button onClick={addTerm} className="text-sm text-primary font-medium hover:opacity-80">+ Add Term</button>
        </div>
        <p className="text-sm text-gray-500 mb-4">
          Reference dates for each term this year — shown wherever the app displays the academic calendar.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {terms.map((term, i) => (
            <div key={i} className="border border-gray-200 rounded-lg p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <Input
                  className="flex-1"
                  value={term.name}
                  onChange={(e) => updateTerm(i, 'name', e.target.value)}
                  placeholder="e.g. Term 1"
                />
                {terms.length > 1 && (
                  <button onClick={() => removeTerm(i)} className="text-xs text-red-500 hover:text-red-700 flex-shrink-0">Remove</button>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <DatePicker label="Start Date" value={term.start_date} onChange={(e) => updateTerm(i, 'start_date', e.target.value)} />
                <DatePicker label="End Date" value={term.end_date} onChange={(e) => updateTerm(i, 'end_date', e.target.value)} />
              </div>
            </div>
          ))}
        </div>
      </div>

      <Button onClick={handleSave} loading={saving}>
        {saving ? 'Saving…' : 'Save Academic Year Settings'}
      </Button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Backup & Data Export
// ─────────────────────────────────────────────────────────────────────────
const EXPORT_TYPES = [
  { value: 'students', label: 'Students' },
  { value: 'staff', label: 'Staff' },
  { value: 'fees', label: 'Fee Structures' },
  { value: 'payments', label: 'Payments' },
  { value: 'all', label: 'All of the above (Excel)' },
];

function BackupExportPanel() {
  const { showSuccess, showError } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [exportingType, setExportingType] = useState('');
  const [schedule, setSchedule] = useState({ enabled: false, frequency: 'weekly' });

  useEffect(() => {
    settingsService.getOverview()
      .then((res) => { if (res.success) setSchedule(res.data.backup_schedule || { enabled: false, frequency: 'weekly' }); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const saveSchedule = async (next) => {
    try {
      setSaving(true);
      const res = await settingsService.updateBackupSchedule(next);
      if (res.success) { setSchedule(res.data); showSuccess('Backup preference saved'); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleExport = async (type) => {
    try {
      setExportingType(type);
      const res = await settingsService.exportData(type);
      if (!res.success) return showError('Export failed');

      const XLSX = await import('xlsx');
      const wb = XLSX.utils.book_new();
      const sheets = type === 'all' ? res.data : { [type]: res.data };

      Object.entries(sheets).forEach(([sheetName, rows]) => {
        const ws = rows && rows.length
          ? XLSX.utils.json_to_sheet(rows)
          : XLSX.utils.aoa_to_sheet([['No records']]);
        XLSX.utils.book_append_sheet(wb, ws, sheetName.slice(0, 31));
      });

      const stamp = new Date().toISOString().slice(0, 10);
      XLSX.writeFile(wb, `edutrack_${type}_backup_${stamp}.xlsx`);
      showSuccess('Export downloaded');
    } catch (err) { showError(err.response?.data?.message || err.message || 'Export failed'); }
    finally { setExportingType(''); }
  };

  if (loading) return <div className="py-12 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>;

  return (
    <div className="w-full space-y-8 text-left">
      <div>
        <h3 className="text-base font-semibold text-gray-900 mb-1">Download a Backup</h3>
        <p className="text-sm text-gray-500 mb-4">
          Exports the school's students, staff, fee structures and payments as an Excel workbook — one sheet per record
          type, handy for your own records. This is an export, not a full backup: EduTrack also makes a complete copy of
          the whole database automatically every day and tests that it can be restored.
        </p>
        <div className="flex flex-wrap gap-3">
          {EXPORT_TYPES.map((t) => (
            <Button
              key={t.value}
              onClick={() => handleExport(t.value)}
              disabled={!!exportingType}
              loading={exportingType === t.value}
              variant={t.value === 'all' ? 'primary' : 'secondary'}
            >
              {exportingType === t.value ? 'Exporting…' : t.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="border-t border-gray-100 pt-6">
        <h3 className="text-base font-semibold text-gray-900 mb-1">Automatic Backup Reminder</h3>
        <p className="text-sm text-gray-500 mb-4 max-w-2xl">
          A reminder to download the Excel export above at the chosen frequency. It doesn't download anything by
          itself. (The automatic full-database backup is separate and runs every day without any reminder.)
        </p>
        <div className="flex flex-wrap items-center gap-4">
          <button
            onClick={() => saveSchedule({ ...schedule, enabled: !schedule.enabled })}
            disabled={saving}
            className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${schedule.enabled ? 'bg-primary' : 'bg-gray-300'}`}
          >
            <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${schedule.enabled ? 'translate-x-5' : ''}`} />
          </button>
          <span className="text-sm text-gray-700">Remind about {schedule.enabled ? 'a' : 'an'} automatic backup</span>
          <Select
            value={schedule.frequency}
            onChange={(e) => saveSchedule({ ...schedule, frequency: e.target.value })}
            disabled={saving || !schedule.enabled}
            options={[
              { value: 'daily', label: 'Daily' },
              { value: 'weekly', label: 'Weekly' },
              { value: 'monthly', label: 'Monthly' },
            ]}
          />
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Audit Log / Activity History
// ─────────────────────────────────────────────────────────────────────────
function AuditLogPanel() {
  const { showError } = useToast();
  const { formatDateTime } = usePreferences();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [resourceTypes, setResourceTypes] = useState([]);
  const [filters, setFilters] = useState({ action: '', kind: '', resource_type: '', from: '', to: '' });
  const [pagination, setPagination] = useState({ currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 20 });
  const [openLogId, setOpenLogId] = useState(null);

  useEffect(() => {
    settingsService.getAuditLogResourceTypes()
      .then((res) => { if (res.success) setResourceTypes(res.data); })
      .catch(() => { /* filter dropdown just stays empty */ });
  }, []);

  useEffect(() => { load(); }, [filters, pagination.currentPage]); // eslint-disable-line react-hooks/exhaustive-deps

  const load = async () => {
    try {
      setLoading(true);
      const res = await settingsService.getAuditLogs({ ...filters, page: pagination.currentPage, limit: pagination.itemsPerPage });
      if (res.success) { setLogs(res.data); setPagination((p) => ({ ...p, ...res.pagination })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const updateFilter = (patch) => {
    setFilters((f) => ({ ...f, ...patch }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  // "Changed: Name, Capacity" under an update, so what happened is visible
  // without opening the entry.
  const changedSummary = (log) => {
    const fields = (log.changed_fields || []).map(fieldLabel);
    if (log.kind !== 'update' || fields.length === 0) return null;
    return `Changed: ${fields.slice(0, 4).join(', ')}${fields.length > 4 ? ` +${fields.length - 4} more` : ''}`;
  };

  return (
    <div className="w-full space-y-4 text-left">
      <div>
        <h3 className="text-base font-semibold text-gray-900 mb-1">Activity History</h3>
        <p className="text-sm text-gray-500">Every create, update, or delete made in the system, who made it, and exactly what changed. Open an entry to see the values before and after.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Input
          value={filters.action}
          onChange={(e) => updateFilter({ action: e.target.value })}
          placeholder="Search activity…"
        />
        <Select
          value={filters.kind}
          onChange={(e) => updateFilter({ kind: e.target.value })}
          options={[
            { value: '', label: 'All Activity' },
            { value: 'create', label: 'Created' },
            { value: 'update', label: 'Updated' },
            { value: 'delete', label: 'Deleted' },
            { value: 'auth', label: 'Sign-ins' },
            { value: 'action', label: 'Other actions' },
          ]}
        />
        <Select
          value={filters.resource_type}
          onChange={(e) => updateFilter({ resource_type: e.target.value })}
          options={[{ value: '', label: 'All Modules' }, ...resourceTypes.map((r) => ({ value: r, label: r.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()) }))]}
        />
        <DatePicker label="" placeholder="From date" value={filters.from} onChange={(e) => updateFilter({ from: e.target.value })} />
        <DatePicker label="" placeholder="To date" value={filters.to} onChange={(e) => updateFilter({ to: e.target.value })} />
      </div>

      <DataTable
        columns={[
          {
            key: 'action', label: 'Activity',
            render: (log) => (
              <div className="flex items-start gap-2.5 min-w-0">
                <span className="mt-0.5 flex-shrink-0"><KindBadge kind={log.kind} outcome={log.outcome} /></span>
                <div className="min-w-0">
                  <button
                    type="button"
                    onClick={() => setOpenLogId(log.id)}
                    className="text-sm text-left text-gray-900 hover:text-primary hover:underline break-words"
                  >
                    {log.action}
                  </button>
                  {changedSummary(log) && <p className="text-xs text-gray-500 mt-0.5">{changedSummary(log)}</p>}
                  {log.legacy && <p className="text-xs text-gray-400 mt-0.5">Older entry — limited detail</p>}
                </div>
              </div>
            ),
          },
          {
            key: 'resource_type', label: 'Module',
            render: (log) => <span className="text-sm capitalize">{(log.resource_type || '—').replace(/_/g, ' ')}</span>,
          },
          {
            key: 'user', label: 'By',
            render: (log) => <span className="text-sm">{log.user ? `${log.user.first_name} ${log.user.last_name}` : 'System'}</span>,
          },
          { key: 'date', label: 'When', render: (log) => <span className="text-sm">{formatDateTime(log.createdAt)}</span> },
        ]}
        data={logs}
        loading={loading}
        emptyMessage="No activity recorded for this filter"
        renderActions={(log) => (
          <RowActions actions={[{ label: 'View Details', variant: 'primary', icon: ACTION_ICONS.view, onClick: () => setOpenLogId(log.id) }]} />
        )}
        pagination={{ ...pagination, limit: pagination.itemsPerPage }}
        onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
      />

      {openLogId && <AuditLogDetailModal logId={openLogId} onClose={() => setOpenLogId(null)} />}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Session & Login Policy
// ─────────────────────────────────────────────────────────────────────────
function LoginPolicyPanel() {
  const { showSuccess, showError } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [policy, setPolicy] = useState({ idle_timeout_minutes: 30, max_login_attempts: 5, lockout_minutes: 15 });

  useEffect(() => {
    settingsService.getOverview()
      .then((res) => { if (res.success) setPolicy(res.data.session_policy); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSave = async () => {
    try {
      setSaving(true);
      const res = await settingsService.updateSessionPolicy(policy);
      if (res.success) { setPolicy(res.data); showSuccess('Login policy updated'); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  if (loading) return <div className="py-12 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>;

  const FIELDS = [
    { key: 'idle_timeout_minutes', label: 'Idle Auto-Logout', help: 'Minutes of inactivity before a user is signed out automatically. Range: 5–240.' },
    { key: 'max_login_attempts', label: 'Max Failed Attempts', help: 'Wrong-password attempts allowed before the account locks. Range: 3–10.' },
    { key: 'lockout_minutes', label: 'Lockout Duration', help: 'Minutes a locked account stays locked. Range: 5–1440.' },
  ];

  return (
    <div className="w-full space-y-6 text-left max-w-2xl">
      <div>
        <h3 className="text-base font-semibold text-gray-900 mb-1">Session & Login Policy</h3>
        <p className="text-sm text-gray-500">Applies to every user at this school, including admins.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {FIELDS.map((f) => (
          <div key={f.key}>
            <NumberInput
              label={f.label}
              name={f.key}
              value={String(policy[f.key])}
              onChange={(e) => setPolicy((p) => ({ ...p, [f.key]: e.target.value }))}
              allowDecimals={false}
              placeholder={f.label}
            />
            <p className="text-xs text-gray-500 mt-1">{f.help}</p>
          </div>
        ))}
      </div>

      <Button onClick={handleSave} loading={saving}>
        {saving ? 'Saving…' : 'Save Login Policy'}
      </Button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// SMS Gateway settings
// ─────────────────────────────────────────────────────────────────────────
const PROVIDERS = [
  { value: "simulated", label: "Simulated (no real SMS sent)" },
  { value: "beem_africa", label: "Beem Africa" },
  { value: "nextsms", label: "NextSMS" },
  { value: "meseji", label: "Meseji" },
  { value: "swalasms", label: "SwalaSMS" },
];
const IMPLEMENTED_PROVIDERS = ["simulated", "beem_africa", "nextsms", "meseji", "swalasms"];

// Each provider's credentials are remembered separately on the server, so the
// form just swaps between them when the provider changes. The secret is never
// sent to the browser — a saved one is shown as this placeholder, and sending
// the placeholder back means "keep the saved secret".
const SECRET_MASK = "••••••••";
const CRED_FIELDS = ["api_key", "api_secret", "sender_id", "system_sender_id"];
const FORM_FIELDS = ["provider", "is_active", ...CRED_FIELDS];
const pickFields = (obj, fields) => Object.fromEntries(fields.map((f) => [f, obj?.[f] ?? (f === "is_active" ? false : "")]));
const credentialsFor = (saved, provider) => {
  const c = saved?.[provider];
  return { api_key: c?.api_key || "", api_secret: c?.has_secret ? SECRET_MASK : "", sender_id: c?.sender_id || "", system_sender_id: c?.system_sender_id || "" };
};

function SmsGatewayPanel() {
  const { showSuccess, showError } = useToast();
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [senderIds, setSenderIds] = useState(null);
  const [senderForm, setSenderForm] = useState(null); // SwalaSMS: the "request a sender ID" form, when open
  const [senderBusy, setSenderBusy] = useState(false);

  // What the server last confirmed, to tell when the form has unsaved changes
  // (Test Connection checks the SAVED settings, not what is typed).
  const [savedSnapshot, setSavedSnapshot] = useState(null);
  // Credentials typed for a provider but not saved yet, so flipping the
  // dropdown back and forth doesn't throw away what was typed.
  const drafts = useRef({});

  const applyServerData = (data) => {
    drafts.current = {};
    setSettings(data);
    setSavedSnapshot(pickFields(data, FORM_FIELDS));
  };

  useEffect(() => {
    messagingService.getGatewaySettings()
      .then((res) => { if (res.success) applyServerData(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, []);

  const switchProvider = (next) => {
    if (next === settings.provider) return;
    drafts.current[settings.provider] = pickFields(settings, CRED_FIELDS);
    const creds = drafts.current[next] || credentialsFor(settings.saved_credentials, next);
    setSettings((s) => ({ ...s, provider: next, ...creds }));
    setTestResult(null);
    setSenderIds(null);
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      const res = await messagingService.updateGatewaySettings(pickFields(settings, FORM_FIELDS));
      if (res.success) {
        showSuccess("SMS gateway settings updated");
        applyServerData(res.data);
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleTest = async () => {
    try {
      setTesting(true);
      setTestResult(null);
      setSenderIds(null);
      const res = await messagingService.testGatewayConnection();
      setTestResult({ ok: true, message: res.message });

      try {
        const ids = await messagingService.getProviderSenderIds();
        if (ids.success) setSenderIds(ids.data || []);
      } catch {
        // Not fatal — the connection test result still stands.
      }
    } catch (err) {
      setTestResult({ ok: false, message: err.response?.data?.message || err.message });
    } finally {
      setTesting(false);
    }
  };

  const openSenderForm = async () => {
    setSenderForm({ sender_id: "", purpose: "Notification", sample_message: "", requirements: null });
    try {
      const res = await messagingService.getSenderIdRequirements();
      if (res.success) setSenderForm((f) => (f ? { ...f, requirements: res.data, purpose: res.data.purposes?.[0] || f.purpose } : f));
    } catch (err) { showError(err.response?.data?.message || err.message); }
  };

  const submitSenderRequest = async () => {
    try {
      setSenderBusy(true);
      const res = await messagingService.requestSenderId({ sender_id: senderForm.sender_id, purpose: senderForm.purpose, sample_message: senderForm.sample_message });
      if (res.success) {
        showSuccess(res.message || "Sender ID request submitted");
        setSenderForm(null);
        const ids = await messagingService.getProviderSenderIds();
        if (ids.success) setSenderIds(ids.data || []);
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSenderBusy(false); }
  };

  if (loading || !settings) return <div className="py-12 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>;

  const apiBase = import.meta.env.VITE_API_URL || "http://localhost:5000/api/v1";
  const webhookUrl = `${apiBase}${settings.nextsms_webhook_path || ""}`;
  const swalaWebhookUrl = `${apiBase}${settings.swalasms_webhook_path || ""}`;
  const swalaKeyMode = /^swl_live_/.test(settings.api_key || "") ? "live" : /^swl_test_/.test(settings.api_key || "") ? "sandbox" : null;
  const savedCredentials = settings.saved_credentials || {};
  const providerOptions = PROVIDERS.map((p) => ({
    ...p,
    label: savedCredentials[p.value] ? `${p.label} — credentials saved` : p.label,
  }));
  const isSimulated = settings.provider === "simulated";
  const dirty = savedSnapshot
    ? FORM_FIELDS.some((f) => (settings[f] ?? (f === "is_active" ? false : "")) !== savedSnapshot[f])
    : false;

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-base text-left font-semibold text-gray-900 mb-1">SMS Gateway</h3>
        <p className="text-sm text-left text-gray-500">Connect a real SMS provider so messages actually reach phones. Until then, sends are simulated — recorded in history, but not dispatched anywhere.</p>
      </div>

      <div className="space-y-4">
        <Select
          label="Provider"
          value={settings.provider}
          onChange={(e) => switchProvider(e.target.value)}
          options={providerOptions}
        />
        <p className="text-xs text-left text-gray-500 -mt-2">
          Each provider's credentials are saved separately, so you can switch gateways and switch back without entering them again.
        </p>

        {!IMPLEMENTED_PROVIDERS.includes(settings.provider) && (
          <div className="bg-amber-50 border border-amber-200 rounded px-4 py-3 text-sm text-amber-800">
            This provider isn't implemented in this build yet. You can save your credentials below for when it is, but "Active" can't be turned on until then.
          </div>
        )}
        {settings.provider === "beem_africa" && (
          <div className="bg-blue-50 border border-blue-200 rounded px-4 py-3 text-sm text-blue-800">
            API Key = Beem Africa API Key, API Secret = Beem Africa Secret Key, Sender ID = your approved Source Address.
          </div>
        )}
        {settings.provider === "nextsms" && (
          <div className="text-sm text-left text-gray-600 bg-blue-50 border border-blue-200 rounded px-4 py-3 leading-relaxed space-y-2">
            <p>
              Enter your NextSMS <strong>username</strong> as API Key and your NextSMS <strong>password</strong> as API Secret
              (the same ones you sign in to nextsms.co.tz with). Your <strong>Sender ID</strong> must already be registered and
              approved on your NextSMS account — leave it empty only to use NextSMS's default sender.
            </p>
            <p>
              After saving, press <strong>Test Connection</strong>: it checks the credentials and shows your live balance without sending an SMS.
            </p>
            <div>
              <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Delivery reports URL (webhook)</p>
              {settings.nextsms_webhook_path ? (
                <>
                  <div className="flex items-start gap-2">
                    <code className="block flex-1 bg-white px-2 py-1 rounded break-all select-all">{webhookUrl}</code>
                    <Button
                      type="button" variant="secondary"
                      onClick={() => navigator.clipboard?.writeText(webhookUrl).then(() => showSuccess("Webhook URL copied"), () => showError("Could not copy — select the URL and copy it by hand"))}
                    >
                      Copy
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Ready to use — it is unique to your school and needs nothing set up on the server. Paste it into your NextSMS dashboard as the
                    delivery-report callback so delivered / failed results arrive on their own.
                    {/localhost|127\.0\.0\.1/.test(webhookUrl) && " This is still a local address, which NextSMS can't reach; once the app is deployed (with VITE_API_URL pointing at it) this shows the public address to register."}
                    {" "}Until then, open a message and press <em>Refresh Delivery</em>.
                  </p>
                </>
              ) : (
                <p className="text-xs text-gray-500">Save the gateway settings to see the URL.</p>
              )}
            </div>
          </div>
        )}

        {settings.provider === "meseji" && (
          <div className="text-sm text-left text-gray-600 bg-blue-50 border border-blue-200 rounded px-4 py-3 leading-relaxed">
            Paste your Meseji <strong>API key</strong> into API Key — generate one in the Meseji dashboard under
            Developer Settings. It starts with <code className="bg-white px-1 rounded">zs_</code>. Leave API
            Secret empty; Meseji does not use one. Your <strong>Sender ID</strong> must already be approved on
            your Meseji account, otherwise sends will be refused.
          </div>
        )}

        {settings.provider === "swalasms" && (
          <div className="text-sm text-left text-gray-600 bg-blue-50 border border-blue-200 rounded px-4 py-3 leading-relaxed space-y-2">
            <p>
              Paste your SwalaSMS <strong>API key</strong> into API Key. Create it in the SwalaSMS dashboard under <strong>SMS → API Keys</strong>:
              a <strong>live</strong> key starts with <code className="bg-white px-1 rounded">swl_live_</code> and really sends; a <strong>sandbox</strong> key
              starts with <code className="bg-white px-1 rounded">swl_test_</code> and sends nothing. The key needs these permissions:
              sending, reading, sender IDs and (to buy credits here) the wallet.
            </p>
            <p>
              <strong>Sender ID</strong> is required. While yours is waiting for approval, type <code className="bg-white px-1 rounded">SWALATECH</code> — SwalaSMS's test sender —
              it delivers only to your registered test numbers. Once yours is approved, use it instead.
            </p>
            <p>
              API Secret is <strong>optional</strong>: if you create a webhook in the SwalaSMS dashboard it shows a signing secret once — paste it there, and delivery reports are
              only accepted when they carry a matching signature.
            </p>
            {swalaKeyMode === "sandbox" && (
              <p className="text-amber-800 bg-amber-50 border border-amber-200 rounded px-3 py-2">
                This is a <strong>sandbox</strong> key: SwalaSMS will answer as if messages were sent, but <strong>nothing reaches a phone</strong> and no credit is spent.
              </p>
            )}
            {swalaKeyMode === "live" && <p className="text-green-800 bg-green-50 border border-green-200 rounded px-3 py-2">This is a <strong>live</strong> key: messages really are sent and credits are spent.</p>}
            <div>
              <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Delivery reports URL (webhook)</p>
              {settings.swalasms_webhook_path ? (
                <>
                  <div className="flex items-start gap-2">
                    <code className="block flex-1 bg-white px-2 py-1 rounded break-all select-all">{swalaWebhookUrl}</code>
                    <Button
                      type="button" variant="secondary"
                      onClick={() => navigator.clipboard?.writeText(swalaWebhookUrl).then(() => showSuccess("Webhook URL copied"), () => showError("Could not copy — select the URL and copy it by hand"))}
                    >
                      Copy
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Unique to your school and ready to use. In the SwalaSMS dashboard open <strong>SMS → Webhooks</strong>, attach this URL to your API key and subscribe it to
                    <code className="bg-white px-1 rounded mx-1">sms.delivered</code>and<code className="bg-white px-1 rounded mx-1">sms.failed</code>so delivered / failed results arrive on their own.
                    {/localhost|127\.0\.0\.1/.test(swalaWebhookUrl) && " This is still a local address, which SwalaSMS can't reach; once the app is deployed (with VITE_API_URL pointing at it) this shows the public address to register."}
                    {" "}Until then, open a message and press <em>Refresh Delivery</em>.
                  </p>
                </>
              ) : (
                <p className="text-xs text-gray-500">Save the gateway settings to see the URL.</p>
              )}
            </div>
          </div>
        )}

        {!isSimulated && (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label={settings.provider === "nextsms" ? "Username" : settings.provider === "swalasms" ? "API Key (swl_live_… or swl_test_…)" : "API Key"}
                value={settings.api_key || ""}
                onChange={(e) => setSettings((s) => ({ ...s, api_key: e.target.value }))}
              />
              <Input
                label={settings.provider === "nextsms" ? "Password" : settings.provider === "meseji" ? "API Secret (not used by Meseji)" : settings.provider === "swalasms" ? "Webhook signing secret (optional)" : "API Secret"}
                type="password"
                value={settings.api_secret || ""}
                onChange={(e) => setSettings((s) => ({ ...s, api_secret: e.target.value }))}
              />
            </div>
            <Input
              label="Sender ID (messages from the school)"
              value={settings.sender_id || ""}
              onChange={(e) => setSettings((s) => ({ ...s, sender_id: e.target.value }))}
              placeholder={settings.provider === "swalasms" ? "e.g. your approved sender ID, or SWALATECH to test" : "e.g. your school's name, shown to recipients"}
            />
            <p className="text-xs text-left text-gray-500 -mt-2">
              Used for messages people send from Messages, and for automatic notices such as admissions, payments and results.
            </p>
            <Input
              label="System Sender ID (password resets and subscription)"
              value={settings.system_sender_id || ""}
              onChange={(e) => setSettings((s) => ({ ...s, system_sender_id: e.target.value }))}
              placeholder="e.g. EDUTRACK, shown on reset codes"
            />
            <p className="text-xs text-left text-gray-500 -mt-2">
              Used only for password-reset codes and subscription messages. Like the Sender ID above, it must already be registered with the provider. If you leave it empty, the Sender ID above is used.
            </p>
          </>
        )}

        <label className="flex items-center gap-2 cursor-pointer text-sm text-gray-700">
          <input
            type="checkbox" checked={settings.is_active}
            onChange={(e) => setSettings((s) => ({ ...s, is_active: e.target.checked }))}
            disabled={!IMPLEMENTED_PROVIDERS.includes(settings.provider)}
            className="accent-primary"
          />
          Active {settings.provider === "simulated" ? "(sends stay simulated either way)" : ""}
        </label>

        <div className="flex items-center gap-3 flex-wrap">
          <Button onClick={handleSave} loading={saving}>
            {saving ? "Saving…" : "Save Gateway Settings"}
          </Button>
          <Button onClick={handleTest} disabled={saving} loading={testing} variant="secondary">
            {testing ? "Testing…" : "Test Connection"}
          </Button>
        </div>

        {!isSimulated && dirty && (
          <p className="text-xs text-left text-amber-700 -mt-2">
            You have unsaved changes. Test Connection checks the <strong>saved</strong> settings, so save first.
          </p>
        )}

        {testResult && (
          <div className={`text-sm text-left rounded px-4 py-3 border ${testResult.ok ? "bg-green-50 border-green-200 text-green-700" : "bg-red-50 border-red-200 text-red-700"}`}>
            {testResult.message}
          </div>
        )}

        {senderIds && (
          <div className="border border-gray-200 rounded overflow-hidden">
            <div className="px-4 py-2.5 bg-gray-50 border-b border-gray-200">
              <p className="text-xs text-left font-semibold text-gray-600 uppercase tracking-wide">Sender IDs on your account</p>
            </div>
            {senderIds.length === 0 ? (
              <p className="text-sm text-gray-500 px-4 py-3 text-left">No sender IDs registered yet — request one from your {settings.provider === "swalasms" ? "SwalaSMS" : "Meseji"} dashboard{settings.provider === "swalasms" ? ", or use the form below" : ""}.</p>
            ) : (
              <ul className="divide-y divide-gray-100">
                {senderIds.map((sid) => {
                  const approved = sid.status === "approved";
                  return (
                    <li key={sid.id || sid.sender_id} className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 gap-3">
                      <div className="text-left min-w-0">
                        <p className="text-sm font-medium text-gray-900">{sid.sender_id}</p>
                        {sid.description && <p className="text-xs text-gray-400">{sid.description}</p>}
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {sid.is_trial && <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 border border-blue-300 text-blue-600">Test sender</span>}
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${approved ? "bg-green-100 border border-green-300 text-green-500" : sid.status === "rejected" || sid.status === "suspended" ? "bg-red-100 border border-red-300 text-red-500" : "bg-amber-100 border border-amber-300 text-amber-600"}`}>
                          {sid.status}
                        </span>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
            <p className="text-xs text-left text-gray-400 px-4 py-2.5 border-t border-gray-100">
              Only an <strong>approved</strong> sender ID delivers. Messages sent under a pending one are
              usually accepted by the API and then dropped by the network.
            </p>
            {settings.provider === "swalasms" && (
              <div className="px-4 py-3 border-t border-gray-100 text-left space-y-3">
                {!senderForm ? (
                  <Button type="button" variant="secondary" onClick={openSenderForm}>Request a new sender ID</Button>
                ) : (
                  <div className="space-y-3">
                    <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Request a sender ID</p>
                    {senderForm.requirements?.eligibility && !senderForm.requirements.eligibility.can_request && (
                      <p className="text-sm text-amber-800 bg-amber-50 border border-amber-200 rounded px-3 py-2">
                        SwalaSMS is not accepting a request yet: {senderForm.requirements.eligibility.reason || "buy more SMS credits first"}
                        {senderForm.requirements.eligibility.minimum_purchase_amount ? ` (minimum purchase ${senderForm.requirements.eligibility.currency || ""} ${Number(senderForm.requirements.eligibility.minimum_purchase_amount).toLocaleString()}).` : "."}
                      </p>
                    )}
                    <Input label="Sender ID" value={senderForm.sender_id} onChange={(e) => setSenderForm((f) => ({ ...f, sender_id: e.target.value }))}
                      placeholder={`${senderForm.requirements?.sender_id_rules?.min_length || 3}–${senderForm.requirements?.sender_id_rules?.max_length || 11} letters or numbers`} />
                    <Select label="Purpose" value={senderForm.purpose} onChange={(e) => setSenderForm((f) => ({ ...f, purpose: e.target.value }))}
                      options={(senderForm.requirements?.purposes || ["Notification", "Transactional", "OTP / Verification", "Alerts & Reminders", "Other"]).map((v) => ({ value: v, label: v }))} />
                    <Textarea label="Sample message" rows={3} value={senderForm.sample_message} onChange={(e) => setSenderForm((f) => ({ ...f, sample_message: e.target.value }))}
                      placeholder="A real example of the messages you will send. Reviewers read it." />
                    <p className="text-xs text-gray-500">
                      At least {senderForm.requirements?.sample_message_rules?.min_length || 50} characters. {senderForm.requirements?.documents_required && "SwalaSMS also needs supporting documents for this request — upload them in the SwalaSMS dashboard instead."}
                    </p>
                    <div className="flex gap-2">
                      <Button type="button" onClick={submitSenderRequest} loading={senderBusy} disabled={!senderForm.sender_id || !senderForm.sample_message || senderForm.requirements?.documents_required}>Submit for review</Button>
                      <Button type="button" variant="secondary" onClick={() => setSenderForm(null)}>Cancel</Button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}


// ─────────────────────────────────────────────────────────────────────────
// Email (SMTP) gateway settings
// ─────────────────────────────────────────────────────────────────────────
function EmailGatewayPanel() {
  const { showSuccess, showError } = useToast();
  const { user } = useAuth();
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [testing, setTesting] = useState(false);
  const [sendingTest, setSendingTest] = useState(false);
  const [sendTo, setSendTo] = useState(user?.email || "");
  const [testResult, setTestResult] = useState(null);
  // Did the settings currently in the form pass a test? Any edit clears it.
  const [testedOk, setTestedOk] = useState(false);
  const [sendAs, setSendAs] = useState("user"); // which sender the test email uses

  useEffect(() => {
    messagingService.getEmailGatewaySettings()
      .then((res) => { if (res.success) setSettings(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, []);

  const edit = (patch) => {
    setSettings((s) => ({ ...s, ...patch }));
    setTestedOk(false);
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      const res = await messagingService.updateEmailGatewaySettings(settings);
      if (res.success) { showSuccess("Email gateway settings updated"); setSettings(res.data); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  // Tests what is in the form right now — no need to save or activate first.
  // The server treats the masked password as "use the saved one".
  const runTest = async ({ send }) => {
    const setBusy = send ? setSendingTest : setTesting;
    try {
      setBusy(true);
      setTestResult(null);
      const res = await messagingService.testEmailGateway({
        smtp_host: settings.smtp_host || "",
        smtp_port: settings.smtp_port || 587,
        smtp_secure: !!settings.smtp_secure,
        smtp_username: settings.smtp_username || "",
        smtp_password: settings.smtp_password || "",
        from_email: settings.from_email || "",
        from_name: settings.from_name || "",
        system_from_email: settings.system_from_email || "",
        system_from_name: settings.system_from_name || "",
        ...(send && { send_to: sendTo, send_as: sendAs }),
      });
      setTestResult({ ok: true, message: res.message });
      setTestedOk(true);
    } catch (err) {
      setTestResult({ ok: false, message: err.response?.data?.message || err.message });
      setTestedOk(false);
    } finally { setBusy(false); }
  };

  if (loading || !settings) return <div className="py-12 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>;

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <h3 className="text-base text-left font-semibold text-gray-900 mb-1">Email Gateway (SMTP)</h3>
        <p className="text-sm text-left text-gray-500">Used for the Messages module's "Email" channel, plus system emails (welcome, password reset) if activated. Leave inactive to keep using the server's default .env SMTP settings.</p>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <Input
            className="col-span-2"
            label="SMTP Host"
            value={settings.smtp_host || ""}
            onChange={(e) => edit({ smtp_host: e.target.value })}
            placeholder="smtp.gmail.com"
          />
          <NumberInput
            label="Port"
            allowDecimals={false}
            value={settings.smtp_port || 587}
            onChange={(e) => edit({ smtp_port: Number(e.target.value) || 0 })}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input
            label="Username"
            value={settings.smtp_username || ""}
            onChange={(e) => edit({ smtp_username: e.target.value })}
          />
          <Input
            label="Password"
            type="password"
            value={settings.smtp_password || ""}
            onChange={(e) => edit({ smtp_password: e.target.value })}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input
            label="From Email"
            type="email"
            value={settings.from_email || ""}
            onChange={(e) => edit({ from_email: e.target.value })}
            placeholder="noreply@yourschool.ac.tz"
          />
          <Input
            label="From Name"
            value={settings.from_name || ""}
            onChange={(e) => edit({ from_name: e.target.value })}
            placeholder="e.g. your school's name"
          />
        </div>
        <p className="text-xs text-left text-gray-500 -mt-2">
          Used for messages people send from Messages, and for automatic notices such as admissions, payments and results.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input
            label="System From Email"
            type="email"
            value={settings.system_from_email || ""}
            onChange={(e) => edit({ system_from_email: e.target.value })}
            placeholder="e.g. no-reply@edutrack.com"
          />
          <Input
            label="System From Name"
            value={settings.system_from_name || ""}
            onChange={(e) => edit({ system_from_name: e.target.value })}
            placeholder="e.g. EduTrack"
          />
        </div>
        <p className="text-xs text-left text-gray-500 -mt-2">
          Used only for password-reset and subscription emails. The mail server must allow sending from this address. Leave both empty to use the From Email and From Name above.
        </p>

        <label className="flex text-left gap-2 cursor-pointer text-sm text-gray-700">
          <input type="checkbox" checked={settings.smtp_secure} onChange={(e) => edit({ smtp_secure: e.target.checked })} className="accent-primary" />
          Use TLS on connect (port 465) — leave off for STARTTLS (port 587), which most providers use
        </label>

        <label className="flex text-left gap-2 cursor-pointer text-sm text-gray-700">
          <input type="checkbox" checked={settings.is_active} onChange={(e) => setSettings((s) => ({ ...s, is_active: e.target.checked }))} className="accent-primary" />
          Active (use these settings instead of the server default)
        </label>

        {settings.is_active && !testedOk && (
          <p className="text-xs text-left text-amber-700 -mt-2">
            These settings haven't passed a test yet. Press <strong>Test Connection</strong> before relying on them — if they are wrong, school emails (including password-reset codes) will fail.
          </p>
        )}

        <div className="flex items-center gap-3 flex-wrap text-left mt-5">
          <Button onClick={handleSave} loading={saving} disabled={testing || sendingTest}>
            {saving ? "Saving…" : "Save Email Settings"}
          </Button>
          <Button onClick={() => runTest({ send: false })} loading={testing} disabled={saving || sendingTest || !settings.smtp_host} variant="secondary">
            {testing ? "Testing…" : "Test Connection"}
          </Button>
        </div>
        <p className="text-xs text-left text-gray-500 -mt-2">
          Test Connection checks what is in the form right now — you don't need to save or activate first. It logs in to the mail server without sending anything.
        </p>

        <div className="border border-gray-200 rounded px-4 py-3 space-y-3">
          <p className="text-xs text-left font-semibold text-gray-600 uppercase tracking-wide">Send a test email</p>
          <div className="flex items-end gap-3 flex-wrap">
            <Input
              className="flex-1 min-w-[14rem]"
              label="Send to"
              type="email"
              value={sendTo}
              onChange={(e) => setSendTo(e.target.value)}
              placeholder="an inbox you can open"
            />
            <div className="text-left">
              <label className="text-xs font-medium text-gray-700 block mb-1">Send as</label>
              <select
                value={sendAs} onChange={(e) => setSendAs(e.target.value)}
                className="border border-gray-300 rounded px-3 py-2.5 text-sm bg-white focus:outline-none focus:border-primary"
              >
                <option value="user">Messages sender</option>
                <option value="system">System sender</option>
              </select>
            </div>
            <Button onClick={() => runTest({ send: true })} loading={sendingTest} disabled={saving || testing || !settings.smtp_host || !sendTo.trim()} variant="secondary">
              {sendingTest ? "Sending…" : "Send Test Email"}
            </Button>
          </div>
          <p className="text-xs text-left text-gray-500">Sends one real message through these settings, which proves the From address is accepted and the mail actually arrives.</p>
        </div>

        {testResult && (
          <div className={`text-sm text-left rounded px-4 py-3 border ${testResult.ok ? "bg-green-50 border-green-200 text-green-700" : "bg-red-50 border-red-200 text-red-700"}`}>
            {testResult.message}
          </div>
        )}
      </div>
    </div>
  );
}

function SchoolBrandingPanel() {
  const { currentCampus, refreshCampuses } = useCampus();
  const { showSuccess, showError } = useToast();

  const [form, setForm] = useState({ email: '', phone: '', website: '', address: '' });
  const [logoUrl, setLogoUrl] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (!currentCampus) return;
    setForm({
      email: currentCampus.email || '',
      phone: currentCampus.phone || '',
      website: currentCampus.website || '',
      address: currentCampus.address || '',
    });
    setLogoUrl(currentCampus.logo_url || null);
  }, [currentCampus?.id, currentCampus?.logo_url]);

  if (!currentCampus) {
    return (
      <div className="text-center py-10">
        <p className="text-sm text-gray-500">No campus selected.</p>
        <p className="text-xs text-gray-400 mt-1">Pick a campus from the header to manage its branding.</p>
      </div>
    );
  }

  const handleLogoSelect = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      setUploading(true);
      const res = await campusService.uploadLogo(currentCampus.id, file);
      if (res.success) {
        setLogoUrl(res.data.logo_url);
        showSuccess('Logo uploaded successfully');
        refreshCampuses();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || 'Failed to upload logo');
    } finally {
      setUploading(false);
    }
  };

  const handleLogoRemove = async () => {
    try {
      setUploading(true);
      const res = await campusService.deleteLogo(currentCampus.id);
      if (res.success) {
        setLogoUrl(null);
        showSuccess('Logo removed');
        refreshCampuses();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || 'Failed to remove logo');
    } finally {
      setUploading(false);
    }
  };

  const handleSaveDetails = async () => {
    try {
      setSaving(true);
      // The campus update endpoint validates name + code, so they must be
      // sent back even though this panel doesn't edit them.
      const res = await campusService.update(currentCampus.id, {
        ...currentCampus,
        ...form,
      });
      if (res.success) {
        showSuccess('School details updated');
        refreshCampuses();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || 'Failed to update details');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-6 md:gap-0 md:space-x-12 md:flex-row">
      <div className="w-full md:w-1/2">
        <h3 className="text-base text-left font-semibold text-gray-900 mb-1">School Logo</h3>
        <p className="text-sm text-left text-gray-500 mb-4">
          Printed as the letterhead on payment receipts and report cards for <strong>{currentCampus.name}</strong>.
          Square images work best. JPG, PNG or WEBP, up to 5MB.
        </p>

        <div className="flex flex-col items-left gap-5 flex-wrap">
          <div className="w-56 h-56 border-2 border-dashed border-gray-300 rounded flex items-center justify-center bg-gray-50 flex-shrink-0 overflow-hidden">
            {logoUrl ? (
              <img src={logoUrl} alt="School logo" className="max-w-full max-h-full object-contain" />
            ) : (
              <span className="text-[10px] text-gray-400 uppercase tracking-wide text-center px-2">No logo yet</span>
            )}
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handleLogoSelect} />
            <Button onClick={() => fileInputRef.current?.click()} loading={uploading}>
              {uploading ? 'Uploading…' : logoUrl ? 'Replace Logo' : 'Upload Logo'}
            </Button>
            {logoUrl && (
              <Button onClick={handleLogoRemove} disabled={uploading} variant="lightDanger">
                Remove
              </Button>
            )}
          </div>
        </div>

        <p className="text-xs text-left text-gray-400 mt-4 leading-relaxed">
          Documents fall back to a text-only letterhead when no logo is set, so nothing breaks if you remove it.
        </p>
      </div>

      <div className="border"></div>

      <div className="w-full md:w-1/2">
        <h3 className="text-base text-left font-semibold text-gray-900 mb-1">Printed Contact Details</h3>
        <p className="text-sm text-left text-gray-500 mb-4">
          These appear under the school name on receipts and report cards.
        </p>

        <div className="space-y-4 text-left">
          <Input
            label="Address"
            value={form.address}
            onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))}
            placeholder="P.O. Box 123, Dar es Salaam"
          />
          <Input
            label="Phone"
            value={form.phone}
            onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
            placeholder="255700000000"
          />
          <Input
            label="Email"
            type="email"
            value={form.email}
            onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            placeholder="info@schoolname.co.tz"
          />
          <Input
            label="Website"
            value={form.website}
            onChange={(e) => setForm((f) => ({ ...f, website: e.target.value }))}
            placeholder="www.schoolname.co.tz"
          />

          <Button onClick={handleSaveDetails} loading={saving}>
            {saving ? 'Saving…' : 'Save Details'}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Security — the account controls that matter to the person signed in
// ─────────────────────────────────────────────────────────────────────────
function SecurityPanel() {
  const { user } = useAuth();
  const { showSuccess, showError } = useToast();

  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [saving, setSaving] = useState(false);
  const [show, setShow] = useState({ current: false, next: false });

  const strength = (() => {
    const pw = form.newPassword;
    if (!pw) return null;
    let score = 0;
    if (pw.length >= 8) score++;
    if (pw.length >= 12) score++;
    if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++;
    if (/\d/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;

    if (score <= 2) return { label: 'Weak', pct: 33, tone: 'bg-red-500', text: 'text-red-600' };
    if (score <= 3) return { label: 'Fair', pct: 66, tone: 'bg-amber-500', text: 'text-amber-600' };
    return { label: 'Strong', pct: 100, tone: 'bg-green-500', text: 'text-green-600' };
  })();

  const handleChangePassword = async () => {
    if (!form.currentPassword) return showError('Enter your current password');
    if (form.newPassword.length < 8) return showError('New password must be at least 8 characters');
    if (form.newPassword !== form.confirmPassword) return showError('The new passwords do not match');
    if (form.newPassword === form.currentPassword) return showError('The new password must be different from the current one');

    try {
      setSaving(true);
      // The API takes snake_case — camelCase silently fails validation.
      const res = await authService.changePassword({
        current_password: form.currentPassword,
        new_password: form.newPassword,
      });
      if (res.success) {
        showSuccess('Password changed successfully');
        setForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || 'Failed to change password');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-12 gap-y-8 text-left">
      <div>
        <h3 className="text-base font-semibold text-gray-900 mb-1">Change Password</h3>
        <p className="text-sm text-gray-500 mb-4">
          You will stay signed in on this device. Anyone else using your account will need the new password.
        </p>

        <div className="max-w-md space-y-4">
          <Input
            label="Current Password"
            type={show.current ? 'text' : 'password'}
            value={form.currentPassword}
            onChange={(e) => setForm((f) => ({ ...f, currentPassword: e.target.value }))}
            autoComplete="current-password"
            placeholder="Enter the current password"
            rightIcon={
              <button
                type="button"
                onClick={() => setShow((v) => ({ ...v, current: !v.current }))}
                className="pointer-events-auto text-xs text-gray-500 hover:text-gray-700"
              >
                {show.current ? 'Hide' : 'Show'}
              </button>
            }
          />

          <div>
            <Input
              label="New Password"
              type={show.next ? 'text' : 'password'}
              value={form.newPassword}
              onChange={(e) => setForm((f) => ({ ...f, newPassword: e.target.value }))}
              autoComplete="new-password"
              placeholder="Enter the new password"
              rightIcon={
                <button
                  type="button"
                  onClick={() => setShow((v) => ({ ...v, next: !v.next }))}
                  className="pointer-events-auto text-xs text-gray-500 hover:text-gray-700"
                >
                  {show.next ? 'Hide' : 'Show'}
                </button>
              }
            />

            {strength && (
              <div className="mt-2">
                <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full transition-all ${strength.tone}`} style={{ width: `${strength.pct}%` }} />
                </div>
                <p className={`text-xs mt-1 ${strength.text}`}>{strength.label} — at least 8 characters</p>
              </div>
            )}
          </div>

          <div>
            <Input
              label="Confirm New Password"
              type="password"
              value={form.confirmPassword}
              onChange={(e) => setForm((f) => ({ ...f, confirmPassword: e.target.value }))}
              autoComplete="new-password"
              placeholder="Re-enter the new password"
            />
            {form.confirmPassword && form.newPassword !== form.confirmPassword && (
              <p className="text-xs text-red-600 mt-1">The passwords do not match</p>
            )}
          </div>

          <Button onClick={handleChangePassword} loading={saving}>
            {saving ? 'Changing…' : 'Change Password'}
          </Button>
        </div>
      </div>

      <div className="space-y-8">
        <div>
          <h3 className="text-base font-semibold text-gray-900 mb-1">This Account</h3>
          <p className="text-sm text-gray-500 mb-4">Details of the account you are currently signed in as.</p>

          <div className="max-w-md grid grid-cols-[max-content_auto_1fr] items-center gap-x-3 gap-y-4">
            {[
              { label: 'Email', value: user?.email },
              { label: 'Role', value: user?.role?.replace('_', ' ') },
              { label: 'Last login', value: user?.last_login ? new Date(user.last_login).toLocaleString() : 'Not recorded' },
            ].map((row) => (
              <Fragment key={row.label}>
                <p className="text-xs text-gray-500">{row.label}</p>
                <p>:</p>
                <p className="text-sm text-gray-900 capitalize">{row.value || '—'}</p>
              </Fragment>
            ))}
          </div>
        </div>

        <div className="border-t border-gray-100 pt-6">
          <h3 className="text-base font-semibold text-gray-900 mb-1">Keeping the School Safe</h3>
          <p className="text-sm text-gray-500 mb-3">
            Most breaches of a school system are not clever attacks — they are shared passwords and accounts left
            active after someone leaves.
          </p>
          <ul className="text-sm text-gray-600 space-y-1.5 list-disc list-inside">
            <li>Give every staff member their own login. Shared accounts make it impossible to tell who did what.</li>
            <li>Deactivate staff the day they leave, in Staff → their profile → Deactivate.</li>
            <li>Review who holds Admin and Principal roles — those roles can see and change everything.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}