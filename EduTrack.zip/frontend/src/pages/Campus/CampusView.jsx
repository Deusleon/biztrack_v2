import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { campusService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { ConfirmModal, Button } from "../../components/ui";

export default function CampusView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const [campus, setCampus] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [confirmModal, setConfirmModal] = useState({
    isOpen: false,
    action: null,
  });

  useEffect(() => {
    fetchCampusData();
  }, [id]);

  const fetchCampusData = async () => {
    try {
      setLoading(true);
      const [campusResponse, statsResponse] = await Promise.all([
        campusService.getById(id),
        campusService.getStats(id),
      ]);

      if (campusResponse.success) {
        setCampus(campusResponse.data);
      }

      if (statsResponse.success) {
        setStats(statsResponse.data);
      }
    } catch (err) {
      showError(err.message || "Failed to fetch campus data");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-sm text-gray-600 mt-2">Loading campus data...</p>
        </div>
      </MainLayout>
    );
  }

  if (!campus) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center">
          <p className="text-gray-600">Campus not found</p>
          <div className="mt-4">
            <Button onClick={() => navigate("/campus")}>Back to List</Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">{campus.name}</h1>
            <p className="text-sm text-gray-500 mt-0.5">Code: {campus.code}</p>
          </div>

          <Button
            onClick={() => navigate("/campus")}
            variant="lightPrimary"
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to List
          </Button>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-gray-600">Total Students</p>
                  <p className="text-2xl text-left font-bold text-gray-900 mt-1">
                    {stats.totalStudents}
                  </p>
                </div>
                <div className="bg-primary-15 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-primary opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                    />
                  </svg>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-gray-600">Total Teachers</p>
                  <p className="text-2xl text-left font-bold text-gray-900 mt-1">
                    {stats.totalTeachers}
                  </p>
                </div>
                <div className="bg-indigo-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-indigo-500 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                    />
                  </svg>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-gray-600">Total Classes</p>
                  <p className="text-2xl text-left font-bold text-gray-900 mt-1">
                    {stats.totalClasses}
                  </p>
                </div>
                <div className="bg-green-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-green-600 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                    />
                  </svg>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded shadow">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-gray-600">Attendance Rate</p>
                  <p className="text-2xl text-left font-bold text-gray-900 mt-1">
                    {stats.attendanceRate}%
                  </p>
                </div>
                <div className="bg-yellow-100 p-3 rounded">
                  <svg
                    className="w-8 h-8 text-yellow-600 opacity-45"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        {(can("campus.update") || can("campus.delete")) && (
          <div className="flex items-center gap-3">
            {can("campus.update") && <Button variant="lightPrimary" onClick={() => navigate(`/campus/${id}/edit`)}>
              Edit Campus
            </Button>}
            {campus.status === "inactive" ? (can("campus.update") ? (
              <Button
                variant="success"
                onClick={async () => {
                  try {
                    await campusService.reactivate(id);
                    showSuccess("Campus reactivated");
                    fetchCampusData();
                  } catch (err) {
                    showError(err.message || "Failed");
                  }
                }}
              >
                Reactivate
              </Button>
            ) : null) : (can("campus.delete") ? (
              <Button
                variant="lightDanger"
                onClick={() =>
                  setConfirmModal({
                    isOpen: true,
                    action: "deactivate",
                    title: "Deactivate Campus",
                    message: "Deactivate this campus?",
                    variant: "danger",
                  })
                }
              >
                Deactivate
              </Button>
            ) : null)}
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded shadow">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {["overview", "details", "statistics"].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-5 py-3 border-b-2 font-medium text-sm capitalize ${activeTab === tab
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                    }`}
                >
                  {tab}
                </button>
              ))}
            </nav>
          </div>

          <div className="px-5 py-4 text-left">
            {activeTab === "overview" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="text-left">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                    Basic Information
                  </h3>
                  <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                    <p className="text-xs text-gray-500">Campus Name</p>
                    <p>:</p>
                    <p className="text-sm text-gray-900">{campus.name}</p>
                    <p className="text-xs text-gray-500">Campus Code</p>
                    <p>:</p>
                    <p className="text-sm text-gray-900">{campus.code}</p>
                    <p className="text-xs text-gray-500">Principal</p>
                    <p>:</p>
                    <p className="text-sm text-gray-900">
                      {campus.principal ? (
                        `${campus.principal.first_name} ${campus.principal.last_name}`
                      ) : (
                        <span className="text-gray-400">Not assigned</span>
                      )}
                    </p>
                    <p className="text-xs text-gray-500">Status</p>
                    <p>:</p>
                    <p>
                      <span
                        className={`px-2 py-0.5 text-xs font-semibold rounded-full capitalize ${campus.status === "active" ? "bg-green-100 border border-green-300 text-green-500" : "bg-gray-100 border border-gray-300 text-gray-500"}`}
                      >
                        {campus.status}
                      </span>
                    </p>
                  </div>
                </div>
                <div className="text-left">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                    Location
                  </h3>
                  <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                    <p className="text-xs text-gray-500">Address</p>
                    <p>:</p>
                    <p className="text-sm text-gray-900">
                      {campus.address || (
                        <span className="text-gray-400">—</span>
                      )}
                    </p>
                    {campus.city && (
                      <>
                        <p className="text-xs text-gray-500">City</p>
                        <p>:</p>
                        <p className="text-sm text-gray-900">{campus.city}</p>
                      </>
                    )}
                    {campus.state && (
                      <>
                        <p className="text-xs text-gray-500">State</p>
                        <p>:</p>
                        <p className="text-sm text-gray-900">{campus.state}</p>
                      </>
                    )}
                    {campus.country && (
                      <>
                        <p className="text-xs text-gray-500">Country</p>
                        <p>:</p>
                        <p className="text-sm text-gray-900">
                          {campus.country}
                        </p>
                      </>
                    )}
                    {campus.postal_code && (
                      <>
                        <p className="text-xs text-gray-500">Postal Code</p>
                        <p>:</p>
                        <p className="text-sm text-gray-900">
                          {campus.postal_code}
                        </p>
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}

            {activeTab === "details" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="text-left">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                    Contact Information
                  </h3>
                  <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                    <p className="text-xs text-gray-500">Phone</p>
                    <p>:</p>
                    <p className="text-sm text-gray-900">
                      {campus.phone || (
                        <span className="text-gray-400">Not provided</span>
                      )}
                    </p>
                    <p className="text-xs text-gray-500">Email</p>
                    <p>:</p>
                    <p className="text-sm text-gray-900">
                      {campus.email || (
                        <span className="text-gray-400">Not provided</span>
                      )}
                    </p>
                  </div>
                </div>
                <div className="text-left">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">
                    System Information
                  </h3>
                  <div className="grid items-center grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                    <p className="text-xs text-gray-500">Created At</p>
                    <p>:</p>
                    <p className="text-sm text-gray-900">
                      {new Date(campus.createdAt).toLocaleString()}
                    </p>
                    <p className="text-xs text-gray-500">Last Updated</p>
                    <p>:</p>
                    <p className="text-sm text-gray-900">
                      {new Date(campus.updatedAt).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "statistics" && stats && (
              <div className="space-y-6">
                <div className="text-left">
                  <h3 className="text-sm font-semibold text-gray-700 mb-4 pb-2 border-b border-gray-100">
                    Campus Statistics
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-50 rounded p-4">
                      <p className="text-xs text-gray-500 mb-1">
                        Active Students
                      </p>
                      <p className="text-xl font-bold text-gray-900">
                        {stats.activeStudents}
                      </p>
                    </div>
                    <div className="bg-gray-50 rounded p-4">
                      <p className="text-xs text-gray-500 mb-1">
                        Present Today
                      </p>
                      <p className="text-xl font-bold text-gray-900">
                        {stats.presentToday}
                      </p>
                    </div>
                    <div className="bg-gray-50 rounded p-4">
                      <p className="text-xs text-gray-500 mb-1">Absent Today</p>
                      <p className="text-xl font-bold text-gray-900">
                        {stats.absentToday}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded p-4">
                  <p className="text-sm text-blue-700">
                    Detailed statistics will be available once students and
                    classes are added to this campus.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
