import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { campusService } from '../../services/api';
import { usePersistedState } from '../../hooks/usePersistedState';
import MainLayout from '../../components/MainLayout';
import { Select, Input, ConfirmModal, DataTable, Button, RowActions, ACTION_ICONS, ActionLink } from '../../components/ui';

export default function CampusList() {
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const navigate = useNavigate();
  const [campuses, setCampuses] = useState([]);
  // Counts come from the server across ALL campuses. Deriving them from
  // `campuses` counted only the current page, and only what the filter
  // had left in it — so filtering to Active made "Inactive" read zero.
  const [summary, setSummary] = useState({ total: 0, active: 0, inactive: 0, totalStudents: 0 });
  const [loading, setLoading] = useState(true);
  const [selectedCampuses, setSelectedCampuses] = useState([]);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false, action: null, data: null });
  const [filters, setFilters] = usePersistedState('filters', {
    page: 1,
    limit: 10,
    search: '',
    status: '',
    city: '',
    state: '',
    country: '',
    sortBy: 'name',
    sortOrder: 'ASC',
  });
  const [pagination, setPagination] = usePersistedState('pagination', {
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
  });

  useEffect(() => {
    fetchCampuses();
  }, [filters.page, filters.limit, filters.status, filters.sortBy, filters.sortOrder, filters.search]);

  const fetchCampuses = async () => {
    try {
      setLoading(true);
      campusService.getSummary()
        .then((res) => { if (res.success) setSummary(res.data); })
        .catch(() => {});
      const response = await campusService.getAll(filters);
      if (response.success) {
        setCampuses(response.data);
        setPagination(response.pagination);
      }
    } catch (err) {
      showError(err.message || 'Failed to fetch campuses');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setFilters({ ...filters, page: 1 });
    fetchCampuses();
  };

  const handleDelete = (id) => {
    setConfirmModal({
      isOpen: true,
      action: 'delete',
      data: id,
      title: 'Deactivate Campus',
      message: 'Are you sure you want to deactivate this campus? This action can be reversed later.',
      variant: 'danger'
    });
  };

  const confirmDelete = async () => {
    try {
      const response = await campusService.delete(confirmModal.data);
      if (response.success) {
        showSuccess('Campus deactivated successfully');
        fetchCampuses();
      }
    } catch (err) {
      showError(err.message || 'Failed to delete campus');
    }
  };

  const handleBulkStatusUpdate = (status) => {
    if (selectedCampuses.length === 0) {
      setConfirmModal({
        isOpen: true,
        action: 'info',
        title: 'No Selection',
        message: 'Please select at least one campus to update.',
        variant: 'info',
        confirmText: 'OK',
        hideCancel: true
      });
      return;
    }

    setConfirmModal({
      isOpen: true,
      action: 'bulkUpdate',
      data: status,
      title: 'Bulk Status Update',
      message: `Are you sure you want to ${status === 'active' ? 'activate' : 'deactivate'} ${selectedCampuses.length} campus(es)?`,
      variant: 'info'
    });
  };

  const confirmBulkUpdate = async () => {
    try {
      const response = await campusService.bulkUpdateStatus({
        ids: selectedCampuses,
        status: confirmModal.data,
      });
      if (response.success) {
        showSuccess(`${selectedCampuses.length} campus(es) updated successfully`);
        setSelectedCampuses([]);
        fetchCampuses();
      }
    } catch (err) {
      showError(err.message || 'Failed to update campuses');
    }
  };

  const handleConfirm = () => {
    if (confirmModal.action === 'delete') {
      confirmDelete();
    } else if (confirmModal.action === 'bulkUpdate') {
      confirmBulkUpdate();
    }
  };

  const handleSelectAll = (e) => {
    if (e.target.checked) {
      setSelectedCampuses(campuses.map(c => c.id));
    } else {
      setSelectedCampuses([]);
    }
  };

  const handleSelectCampus = (id) => {
    setSelectedCampuses(prev =>
      prev.includes(id) ? prev.filter(cid => cid !== id) : [...prev, id]
    );
  };

  const getStatusColor = (status) => {
    return status === 'active'
      ? 'bg-green-100 border border-green-300 text-green-500'
      : 'bg-red-100 border border-red-300 text-red-500';
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Campus Management</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              Manage all campuses in your organization
            </p>
          </div>
          {can("campus.create") && (
            <ActionLink to="/campus/add" variant="primary">New Campus</ActionLink>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Total Campuses</p>
                <p className="text-2xl text-left font-bold text-primary mt-1">{summary.total}</p>
              </div>
              <div className="bg-primary-15 p-3 rounded">
                <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Active Campuses</p>
                <p className="text-2xl text-left font-bold text-green-600 mt-1">{summary.active}</p>
              </div>
              <div className="bg-green-100 p-3 rounded">
                <svg className="w-8 h-8 text-green-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Inactive Campuses</p>
                <p className="text-2xl text-left font-bold text-red-600 mt-1">{summary.inactive}</p>
              </div>
              <div className="bg-red-100 p-3 rounded">
                <svg className="w-8 h-8 text-red-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm text-left text-gray-600">Total Students</p>
                <p className="text-2xl text-left font-bold text-indigo-600 mt-1">{summary.totalStudents}</p>
              </div>
              <div className="bg-indigo-100 p-3 rounded">
                <svg className="w-8 h-8 text-indigo-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-5 rounded shadow">
          <form onSubmit={handleSearch} className="grid grid-cols-2 md:grid-cols-6 gap-4">
            <div className="md:col-span-2">
              <Input
                type="text"
                label="Search"
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                placeholder="Search by name, code, email..."
                leftIcon={
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                }
              />
            </div>

            <div>
              <Select
                label="Status"
                value={filters.status}
                onChange={(e) => setFilters({ ...filters, status: e.target.value, page: 1 })}
                placeholder="All Statuses"
                options={[
                  { value: '', label: 'All' },
                  { value: 'active', label: 'Active' },
                  { value: 'inactive', label: 'Inactive' }
                ]}
              />
            </div>

            <div>
              <Select
                label="Sort By"
                value={filters.sortBy}
                onChange={(e) => setFilters({ ...filters, sortBy: e.target.value, page: 1 })}
                options={[
                  { value: 'created_at', label: 'Date Created' },
                  { value: 'name', label: 'Name' },
                  { value: 'code', label: 'Code' },
                  { value: 'city', label: 'City' }
                ]}
              />
            </div>

            <div>
              <Select
                label="Order"
                value={filters.sortOrder}
                onChange={(e) => setFilters({ ...filters, sortOrder: e.target.value, page: 1 })}
                options={[
                  { value: 'DESC', label: 'Descending' },
                  { value: 'ASC', label: 'Ascending' }
                ]}
              />
            </div>

            <div className="flex items-end">
              <button
                type="submit"
                className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90"
              >
                Apply Filters
              </button>
            </div>
          </form>
        </div>

        {/* Bulk Actions */}
        {selectedCampuses.length > 0 && (can("campus.update") || can("campus.delete")) && (
          <div className="bg-primary-10 border border-primary-25 rounded p-4 px-5 flex flex-wrap items-center justify-between gap-2">
            <span className="text-sm font-medium text-gray-700">
              {selectedCampuses.length} campus(es) selected
            </span>
            <div className="flex space-x-2">
              <Button variant="success" onClick={() => handleBulkStatusUpdate('active')}>Activate</Button>
              <Button variant="danger" onClick={() => handleBulkStatusUpdate('inactive')}>Deactivate</Button>
            </div>
          </div>
        )}

        <DataTable
          columns={[
            {
              key: "name",
              label: "Campus",
              render: (campus) => (
                <div>
                  <div className="text-sm font-medium text-gray-900">{campus.name}</div>
                  <div className="text-sm text-gray-400">Code: {campus.code}</div>
                </div>
              ),
            },
            {
              key: "location",
              label: "Location",
              render: (campus) => (
                <div className="text-sm text-gray-500">
                  {[campus.city, campus.state, campus.country].filter(Boolean).join(', ') || <span className="text-gray-400">—</span>}
                </div>
              ),
            },
            {
              key: "contact",
              label: "Contact",
              render: (campus) => (
                <div className="text-sm text-gray-500">
                  {campus.phone && <div>{campus.phone}</div>}
                  {campus.email && <div>{campus.email}</div>}
                  {!campus.phone && !campus.email && <span className="text-gray-400">—</span>}
                </div>
              ),
            },
            {
              key: "principal",
              label: "Principal",
              render: (campus) => campus.principal
                ? <span className="text-sm text-gray-700">{campus.principal.first_name} {campus.principal.last_name}</span>
                : <span className="text-gray-400">Not assigned</span>,
            },
            {
              key: "status",
              label: "Status",
              render: (campus) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${getStatusColor(campus.status)}`}>
                  {campus.status}
                </span>
              ),
            },
          ]}
          data={campuses}
          loading={loading}
          emptyMessage="No campuses found"
          // selectable={['super_admin', 'admin'].includes(user?.role)}
          selectedIds={selectedCampuses}
          onSelectAll={handleSelectAll}
          onSelectRow={handleSelectCampus}
          renderActions={(campus) => {
            return (
              <RowActions
                actions={[
                  { label: 'View Details', variant: 'primary', icon: ACTION_ICONS.view, hidden: !can("campus.update"), onClick: () => navigate(`/campus/${campus.id}`) },
                  { label: 'Edit Campus', icon: ACTION_ICONS.edit, hidden: !can("campus.update"), onClick: () => navigate(`/campus/${campus.id}/edit`) },
                  { label: 'Deactivate', variant: 'danger', icon: ACTION_ICONS.remove, hidden: !can("campus.delete"), onClick: () => handleDelete(campus.id) },
                ]}
              />
            );
          }}
          pagination={{ currentPage: pagination.currentPage, totalPages: pagination.totalPages, totalItems: pagination.totalItems, limit: filters.limit }}
          onPageChange={(page) => setFilters(f => ({ ...f, page }))}
        />
      </div>

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ isOpen: false, action: null, data: null })}
        onConfirm={handleConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
        confirmText={confirmModal.confirmText || 'Confirm'}
        cancelText={confirmModal.cancelText || 'Cancel'}
      />
    </MainLayout>
  );
}
