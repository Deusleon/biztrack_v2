import { useState, useEffect, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { campusService, staffService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Select, Input, PhoneInput, Textarea, Button } from "../../components/ui";
import { useCampus } from "../../contexts/CampusContext";

export default function CampusForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();
  // Receipts and report cards read the logo straight off the active
  // campus, so refresh it after an upload — otherwise the new logo only
  // shows up after a full page reload.
  const { refreshCampuses } = useCampus();
  const isEdit = Boolean(id);

  const [loading, setLoading] = useState(false);
  const [fetchingData, setFetchingData] = useState(isEdit);
  const [principals, setPrincipals] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    code: "",
    address: "",
    city: "",
    state: "",
    country: "",
    postal_code: "",
    phone: "",
    email: "",
    website: "",
    principal_id: "",
    status: "active",
  });

  // Logo lives outside formData because it's uploaded through its own
  // multipart endpoint, not saved with the rest of the form.
  const [logoUrl, setLogoUrl] = useState(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const logoInputRef = useRef(null);

  useEffect(() => {
    if (isEdit) {
      fetchCampusData();
    }
    // Load principals for dropdown
    staffService.getAll({ limit: 200, status: 'active', role: 'principal' }).then((res) => {
      if (res.success) setPrincipals(res.data);
    }).catch(() => {});
  }, [id]);

  const fetchCampusData = async () => {
    try {
      setFetchingData(true);
      const response = await campusService.getById(id);
      if (response.success) {
        setFormData({
          name: response.data.name || "",
          code: response.data.code || "",
          address: response.data.address || "",
          city: response.data.city || "",
          state: response.data.state || "",
          country: response.data.country || "",
          postal_code: response.data.postal_code || "",
          phone: response.data.phone || "",
          email: response.data.email || "",
          website: response.data.website || "",
          principal_id: response.data.principal_id || "",
          status: response.data.status || "active",
        });
        setLogoUrl(response.data.logo_url || null);
      }
    } catch (err) {
      showError(err.message || "Failed to fetch campus data");
    } finally {
      setFetchingData(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  /** Uploads through the dedicated multipart endpoint rather than the main
   * form save, so the logo lands immediately and survives even if the user
   * later abandons the form without pressing Update. */
  const handleLogoSelect = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      setUploadingLogo(true);
      const res = await campusService.uploadLogo(id, file);
      if (res.success) {
        setLogoUrl(res.data.logo_url);
        showSuccess("Logo uploaded successfully");
        refreshCampuses();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || "Failed to upload logo");
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleLogoRemove = async () => {
    try {
      setUploadingLogo(true);
      const res = await campusService.deleteLogo(id);
      if (res.success) {
        setLogoUrl(null);
        showSuccess("Logo removed");
        refreshCampuses();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message || "Failed to remove logo");
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validation
    if (!formData.name.trim()) {
      showError("Campus name is required");
      return;
    }

    if (!formData.code.trim()) {
      showError("Campus code is required");
      return;
    }

    if (!/^[A-Z0-9_-]+$/.test(formData.code)) {
      showError(
        "Campus code must contain only uppercase letters, numbers, hyphens, and underscores"
      );
      return;
    }

    try {
      setLoading(true);
      const response = isEdit
        ? await campusService.update(id, formData)
        : await campusService.create(formData);

      if (response.success) {
        showSuccess(`Campus ${isEdit ? "updated" : "created"} successfully`);
        navigate("/campus");
      }
    } catch (err) {
      showError(
        err.message || `Failed to ${isEdit ? "update" : "create"} campus`
      );
    } finally {
      setLoading(false);
    }
  };

  if (fetchingData) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded-lg shadow text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-sm text-gray-600 mt-2">Loading campus data...</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Page Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">
              {isEdit ? "Edit Campus" : "Add New Campus"}
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {isEdit
                ? "Update campus information"
                : "Create a new campus in your organization"}
            </p>
          </div>
          <Button
            onClick={() => navigate("/campus")}
            variant="lightPrimary"
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to Campuses
          </Button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-white rounded shadow">
          <div className="p-5 space-y-10">
            {/* Basic Information */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Basic Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                <Input
                  type="text"
                  name="name"
                  label="Campus Name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  placeholder="Enter campus name"
                />

                <Input
                  type="text"
                  name="code"
                  label="Campus Code"
                  value={formData.code}
                  onChange={handleChange}
                  required
                  pattern="[A-Z0-9_-]+"
                  placeholder="e.g., MC-25001"
                  helperText="Use uppercase letters, numbers, hyphens, and underscores only"
                  //   className="uppercase"
                />

                <div className="md:col-span-2">
                  <Textarea
                    label="Address"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    rows={3}
                    placeholder="Enter full address"
                  />
                </div>
              </div>
            </div>

            {/* Location Information */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Location Details
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                <Input
                  type="text"
                  name="city"
                  label="City"
                  value={formData.city}
                  onChange={handleChange}
                  placeholder="Enter city"
                />

                <Input
                  type="text"
                  name="state"
                  label="State/Province"
                  value={formData.state}
                  onChange={handleChange}
                  placeholder="Enter state/province"
                />

                <Input
                  type="text"
                  name="country"
                  label="Country"
                  value={formData.country}
                  onChange={handleChange}
                  placeholder="Enter country"
                />

                <Input
                  type="text"
                  name="postal_code"
                  label="Postal Code"
                  value={formData.postal_code}
                  onChange={handleChange}
                  placeholder="Enter postal code"
                />
              </div>
            </div>

            {/* Contact Information */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Contact Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                <PhoneInput
                  name="phone"
                  label="Phone Number"
                  value={formData.phone}
                  onChange={handleChange}
                  leftIcon={
                    <svg
                      className="w-5 h-5 text-gray-400"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                      />
                    </svg>
                  }
                />

                <Input
                  type="email"
                  name="email"
                  label="Email Address"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="info@campus.com"
                  leftIcon={
                    <svg
                      className="w-5 h-5 text-gray-400"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                      />
                    </svg>
                  }
                />

                <div className="md:col-span-2">
                  <Input
                    type="text"
                    name="website"
                    label="Website"
                    value={formData.website}
                    onChange={handleChange}
                    placeholder="www.schoolname.co.tz"
                    helperText="Printed on payment receipts alongside the school's contact details"
                    leftIcon={
                      <svg
                        className="w-5 h-5 text-gray-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                        />
                      </svg>
                    }
                  />
                </div>
              </div>
            </div>

            {/* School Logo — only once the campus exists, since the upload
                endpoint needs an ID to attach the file to. */}
            {isEdit && (
              <div className="text-left">
                <h2 className="text-md font-semibold text-gray-900 mb-2">School Logo</h2>
                <p className="text-sm text-gray-500 mb-4">
                  Printed as the letterhead on payment receipts and report cards. Square images work best. JPG, PNG or WEBP, up to 5MB.
                </p>
                <div className="flex items-center gap-5 flex-wrap">
                  <div className="w-24 h-24 border-2 border-dashed border-gray-300 rounded flex items-center justify-center bg-gray-50 flex-shrink-0 overflow-hidden">
                    {logoUrl ? (
                      <img src={logoUrl} alt="School logo" className="max-w-full max-h-full object-contain" />
                    ) : (
                      <span className="text-[10px] text-gray-400 uppercase tracking-wide text-center px-2">No logo</span>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <input
                      ref={logoInputRef}
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                      onChange={handleLogoSelect}
                    />
                    <Button
                      type="button"
                      variant="secondary"
                      loading={uploadingLogo}
                      onClick={() => logoInputRef.current?.click()}
                    >
                      {logoUrl ? "Replace Logo" : "Upload Logo"}
                    </Button>
                    {logoUrl && (
                      <Button type="button" variant="lightDanger" disabled={uploadingLogo} onClick={handleLogoRemove}>
                        Remove
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Administrative Information */}
            <div className="text-left">
              <h2 className="text-md font-semibold text-gray-900 mb-2">
                Administrative Details
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                <Select
                  name="status"
                  label="Status"
                  value={formData.status}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, status: e.target.value }))
                  }
                  options={[
                    { value: "active", label: "Active" },
                    { value: "inactive", label: "Inactive" },
                  ]}
                />

                <Select
                  name="principal_id"
                  label="Principal (Optional)"
                  value={formData.principal_id}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      principal_id: e.target.value,
                    }))
                  }
                  placeholder="Select Principal"
                  options={[
                    { value: '', label: 'None' },
                    ...principals.map((s) => ({
                      value: s.user_id,
                      label: `${s.user?.first_name || ''} ${s.user?.last_name || ''}`.trim() || s.user?.email || s.id,
                    })),
                  ]}
                  helperText="Assign a principal to this campus"
                />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="px-5 py-4 bg-gray-50 border-t border-gray-200 rounded-b-lg flex items-center justify-end gap-4">
            <Button type="button" variant="secondary" onClick={() => navigate("/campus")}>Cancel</Button>
            <Button type="submit" loading={loading}>{isEdit ? "Update Campus" : "Create Campus"}</Button>
          </div>
        </form>

        {/* Help Text */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-left">
          <div className="flex">
            <svg
              className="w-5 h-5 text-blue-400 mt-0.5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-blue-800">Information</h3>
              <div className="mt-2 text-sm text-blue-700">
                <ul className="list-disc list-inside space-y-1">
                  <li>Campus code must be unique within your organization</li>
                  <li>
                    All students, classes, and staff will be associated with a
                    campus
                  </li>
                  <li>You can assign a principal to manage the campus</li>
                  <li>
                    Inactive campuses won't appear in active lists but data is
                    preserved
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
