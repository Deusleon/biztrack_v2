import { useState, useRef } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../contexts/ToastContext";
import { usePreferences } from "../contexts/PreferencesContext";
import { authService } from "../services/api";
import MainLayout from "../components/MainLayout";
import { Input, PhoneInput, Button } from "../components/ui";
import { isStrongPassword, PASSWORD_RULE_TEXT } from "../utils/passwordRules";

const ROLE_LABEL = (role) => (role || "").replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

export default function Profile() {
  const { user, updateUser } = useAuth();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();
  const [activeTab, setActiveTab] = useState("general");
  const fileInputRef = useRef(null);

  const [avatarUploading, setAvatarUploading] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileForm, setProfileForm] = useState({
    first_name: user?.first_name || "",
    middle_name: user?.middle_name || "",
    last_name: user?.last_name || "",
    phone: user?.phone || "",
  });

  const [savingPassword, setSavingPassword] = useState(false);
  const [passwordForm, setPasswordForm] = useState({ current_password: "", new_password: "", confirm_password: "" });

  const initials = `${user?.first_name?.charAt(0) || ""}${user?.last_name?.charAt(0) || ""}`.toUpperCase();
  const fullName = [user?.first_name, user?.middle_name, user?.last_name].filter(Boolean).join(" ");

  const handleAvatarClick = () => fileInputRef.current?.click();

  const handleAvatarChange = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      setAvatarUploading(true);
      const response = await authService.uploadAvatar(file);
      if (response.success) {
        updateUser({ avatar: response.data.avatar });
        showSuccess("Profile photo updated");
      }
    } catch (err) {
      showError(err.message || "Failed to upload photo");
    } finally {
      setAvatarUploading(false);
    }
  };

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setProfileForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    if (!profileForm.first_name.trim()) return showError("First name is required");
    if (!profileForm.last_name.trim()) return showError("Last name is required");
    try {
      setSavingProfile(true);
      const response = await authService.updateProfile(profileForm);
      if (response.success) {
        updateUser(response.data);
        showSuccess("Profile updated successfully");
      }
    } catch (err) {
      showError(err.message || "Failed to update profile");
    } finally {
      setSavingProfile(false);
    }
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordForm((prev) => ({ ...prev, [name]: value }));
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    if (!passwordForm.current_password) return showError("Current password is required");
    if (!isStrongPassword(passwordForm.new_password)) return showError(PASSWORD_RULE_TEXT);
    if (passwordForm.new_password !== passwordForm.confirm_password) return showError("New passwords do not match");
    try {
      setSavingPassword(true);
      const response = await authService.changePassword({
        current_password: passwordForm.current_password,
        new_password: passwordForm.new_password,
      });
      if (response.success) {
        showSuccess("Password changed successfully");
        setPasswordForm({ current_password: "", new_password: "", confirm_password: "" });
        updateUser({ must_change_password: false });
      }
    } catch (err) {
      showError(err.message || "Failed to change password");
    } finally {
      setSavingPassword(false);
    }
  };

  const tabs = [
    { id: "general", name: "General", icon: "\uD83D\uDC64" },
    { id: "security", name: "Security", icon: "\uD83D\uDD12" },
  ];

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="text-left">
          <h1 className="text-xl font-bold text-gray-900">My Profile</h1>
          <p className="text-sm text-gray-500 mt-0.5">Manage your personal information and account security</p>
        </div>

        {/* Profile header card */}
        <div className="bg-white rounded shadow p-5">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
            <div className="relative flex-shrink-0">
              <div className="w-20 h-20 rounded-full overflow-hidden gradient-primary flex items-center justify-center text-white text-2xl font-semibold">
                {user?.avatar ? (
                  <img src={user.avatar} alt={fullName} className="w-full h-full object-cover" />
                ) : (
                  initials || "?"
                )}
              </div>
              <button
                type="button"
                onClick={handleAvatarClick}
                disabled={avatarUploading}
                title="Change photo"
                className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-primary text-white flex items-center justify-center shadow hover:opacity-90 disabled:opacity-50"
              >
                {avatarUploading ? (
                  <svg className="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                ) : (
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                )}
              </button>
              <input ref={fileInputRef} type="file" accept=".jpg,.jpeg,.png,.webp" className="hidden" onChange={handleAvatarChange} />
            </div>

            <div className="flex-1 min-w-0">
              <h2 className="text-lg font-semibold text-gray-900">{fullName || "—"}</h2>
              <p className="text-sm text-gray-500">{user?.email}</p>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-2">
                <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-primary-10 text-primary capitalize">
                  {ROLE_LABEL(user?.role)}
                </span>
                {user?.last_login && (
                  <span className="text-xs text-gray-400">Last login: {formatDate(user.last_login)}</span>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded shadow-md overflow-hidden">
          {/* Tabs */}
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-3 px-5 text-center border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? "border-primary text-primary"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  {/* <span className="mr-2">{tab.icon}</span> */}
                  {tab.name}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-5 text-left">
            {activeTab === "general" && (
              <form onSubmit={handleProfileSubmit} className="max-w-xl space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Input label="First Name" name="first_name" value={profileForm.first_name} onChange={handleProfileChange} required />
                  <Input label="Middle Name" name="middle_name" value={profileForm.middle_name} onChange={handleProfileChange} placeholder="Optional" />
                  <Input label="Last Name" name="last_name" value={profileForm.last_name} onChange={handleProfileChange} required />
                  <PhoneInput label="Phone" name="phone" value={profileForm.phone} onChange={handleProfileChange} />
                </div>
                <div className="pt-2">
                  <Button type="submit" loading={savingProfile}>Save Changes</Button>
                </div>
              </form>
            )}

            {activeTab === "security" && (
              <form onSubmit={handlePasswordSubmit} className="max-w-md space-y-4">
                {user?.must_change_password && (
                  <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 text-sm rounded px-4 py-3">
                    Your account is using a system-generated password. Please set your own password below.
                  </div>
                )}
                <Input
                  label="Current Password"
                  type="password"
                  name="current_password"
                  value={passwordForm.current_password}
                  onChange={handlePasswordChange}
                  required
                />
                <Input
                  label="New Password"
                  type="password"
                  name="new_password"
                  value={passwordForm.new_password}
                  onChange={handlePasswordChange}
                  placeholder="At least 8 characters, letters and numbers"
                  required
                />
                <Input
                  label="Confirm New Password"
                  type="password"
                  name="confirm_password"
                  value={passwordForm.confirm_password}
                  onChange={handlePasswordChange}
                  required
                />
                <div className="pt-2">
                  <Button type="submit" loading={savingPassword}>Change Password</Button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
