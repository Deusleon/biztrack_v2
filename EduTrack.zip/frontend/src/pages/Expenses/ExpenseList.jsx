import { useState, useEffect, useRef } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { expenseService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { Select, Input, NumberInput, DataTable, ConfirmModal, Button, DatePicker, RowActions, ACTION_ICONS } from "../../components/ui";
import { formatMoney } from "../../utils/money";

const PAYMENT_METHODS = [
  { value: "cash", label: "Cash" }, { value: "bank_transfer", label: "Bank Transfer" },
  { value: "mobile_money", label: "Mobile Money" }, { value: "cheque", label: "Cheque" }, { value: "other", label: "Other" },
];


export default function ExpenseList() {
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();

  const [activeTab, setActiveTab] = useState("ledger");
  // The "new record" button lives in the page header like every other
  // module, so it has to be triggered from here even though the forms
  // themselves live inside each tab.
  const [createSignal, setCreateSignal] = useState({ tab: null, n: 0 });
  const requestCreate = () => setCreateSignal((c) => ({ tab: activeTab, n: c.n + 1 }));

  const isLedger = activeTab === "ledger";

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Page Header — title left, tab switcher and the primary action
            together on the right, matching the rest of the system. The tabs
            are a compact segmented control rather than a full-width strip in
            its own card, which left an awkward empty band across the page. */}
        <div className="page-header flex items-center justify-between flex-wrap gap-3">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Expenses</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {isLedger ? "Operational spending ledger" : "Group expenses under categories for reporting"}
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex rounded overflow-hidden p-1 border border-gray-400 text-sm">
              {[{ id: "ledger", label: "Ledger" }, { id: "categories", label: "Categories" }].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-5 py-1.5 rounded whitespace-nowrap transition-colors ${
                    activeTab === tab.id ? "bg-primary text-white" : "bg-white text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {can("expenses.create") && (
              <Button variant="primary" mobileLabel="New" onClick={requestCreate}>{isLedger ? "Record Expense" : "New Category"}</Button>
            )}
          </div>
        </div>

        {isLedger
          ? <LedgerTab formatDate={formatDate} showSuccess={showSuccess} showError={showError} createSignal={createSignal} />
          : <CategoriesTab showSuccess={showSuccess} showError={showError} createSignal={createSignal} />}
      </div>
    </MainLayout>
  );
}

function LedgerTab({ formatDate, showSuccess, showError, createSignal }) {
  const { can } = useAuth();
  const { currentAcademicYear } = useAcademicYear();
  const [expenses, setExpenses] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [totalAmount, setTotalAmount] = useState(0);
  const fileInputRef = useRef(null);
  const [uploadingFor, setUploadingFor] = useState(null);

  const [filters, setFilters] = usePersistedState("filters", { search: "", category_id: "", payment_method: "", start_date: "", end_date: "" });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 15 });

  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({ category_id: "", amount: "", expense_date: "", payee: "", description: "", payment_method: "cash", reference_number: "" });
  const [saving, setSaving] = useState(false);
  const [confirmVoid, setConfirmVoid] = useState({ isOpen: false });

  // School years run January to December, so the selected year is that
  // calendar year. Expenses carry a date, not an academic_year column, so
  // the year is applied as an outer date window.
  const yearBounds = (() => {
    const base = parseInt(String(currentAcademicYear || "").match(/\d{4}/)?.[0], 10);
    return base ? { start: `${base}-01-01`, end: `${base}-12-31` } : null;
  })();

  useEffect(() => { fetchExpenses(); }, [filters, pagination.currentPage, currentAcademicYear]);

  // A date filter left from another year would sit outside the new window
  // and silently return nothing.
  useEffect(() => {
    setFilters((f) => (f.start_date || f.end_date ? { ...f, start_date: "", end_date: "" } : f));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  }, [currentAcademicYear]);
  useEffect(() => { expenseService.getCategories({ status: "active" }).then((res) => { if (res.success) setCategories(res.data); }); }, []);

  const fetchExpenses = async () => {
    try {
      setLoading(true);
      // The year is the outer bound; any date the user picks narrows
      // within it and can never reach outside it.
      const res = await expenseService.getAll({
        ...filters,
        start_date: filters.start_date && filters.start_date > yearBounds?.start ? filters.start_date : yearBounds?.start,
        end_date: filters.end_date && filters.end_date < yearBounds?.end ? filters.end_date : yearBounds?.end,
        page: pagination.currentPage, limit: pagination.itemsPerPage,
      });
      if (res.success) { setExpenses(res.data); setPagination((p) => ({ ...p, ...res.pagination })); setTotalAmount(res.summary?.total_amount || 0); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((f) => ({ ...f, [name]: value }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const openCreate = () => {
    setForm({ category_id: categories[0]?.id || "", amount: "", expense_date: new Date().toISOString().slice(0, 10), payee: "", description: "", payment_method: "cash", reference_number: "" });
    setModal({ isOpen: true, mode: "create" });
  };

  // The header button lives in the parent, so it signals down rather than
  // calling openCreate directly. Keyed on a counter so pressing it twice in
  // a row still re-opens the modal.
  useEffect(() => {
    if (createSignal?.tab === "ledger" && createSignal.n > 0) openCreate();
  }, [createSignal?.n]); // eslint-disable-line react-hooks/exhaustive-deps
  const openEdit = (e) => {
    setForm({ category_id: e.category_id, amount: e.amount, expense_date: e.expense_date, payee: e.payee || "", description: e.description || "", payment_method: e.payment_method, reference_number: e.reference_number || "" });
    setModal({ isOpen: true, mode: "edit", id: e.id });
  };

  const handleSave = async () => {
    if (!form.category_id || !form.amount || !form.expense_date) { showError("Category, amount, and date are required"); return; }
    try {
      setSaving(true);
      const payload = { ...form, amount: Number(form.amount) };
      if (modal.mode === "edit") await expenseService.update(modal.id, payload);
      else await expenseService.create(payload);
      showSuccess(modal.mode === "edit" ? "Expense updated" : "Expense recorded");
      setModal({ isOpen: false });
      fetchExpenses();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleVoid = (e) => setConfirmVoid({ isOpen: true, id: e.id });
  const confirmVoidExpense = async () => {
    try {
      await expenseService.void(confirmVoid.id);
      showSuccess("Expense voided");
      fetchExpenses();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmVoid({ isOpen: false });
  };

  const openUploadReceipt = (expenseId) => {
    setUploadingFor(expenseId);
    fileInputRef.current?.click();
  };
  const handleReceiptSelect = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || !uploadingFor) return;
    try {
      const res = await expenseService.uploadReceipt(uploadingFor, file);
      if (res.success) { showSuccess("Receipt uploaded"); fetchExpenses(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setUploadingFor(null); }
  };

  // Drives the empty-state wording — "nothing recorded yet" and "nothing
  // matches your filters" are very different messages to land on.
  const hasActiveFilters = Object.values(filters).some(Boolean);

  return (
    <div className="space-y-4">
      <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handleReceiptSelect} />

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded shadow">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-sm text-left text-gray-600">Total Spent (filtered)</p>
              <p className="text-2xl text-left font-bold text-primary mt-1">{formatMoney(totalAmount)}</p>
            </div>
            <div className="bg-primary-15 p-3 rounded">
              <svg className="w-8 h-8 text-primary opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-white p-5 rounded shadow">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-sm text-left text-gray-600">Entries</p>
              <p className="text-2xl text-left font-bold text-indigo-600 mt-1">{pagination.totalItems}</p>
            </div>
            <div className="bg-indigo-100 p-3 rounded">
              <svg className="w-8 h-8 text-indigo-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-white p-5 rounded shadow">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-sm text-left text-gray-600">Categories</p>
              <p className="text-2xl text-left font-bold text-green-600 mt-1">{categories.length}</p>
            </div>
            <div className="bg-green-100 p-3 rounded">
              <svg className="w-8 h-8 text-green-600 opacity-45" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5a1.99 1.99 0 011.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.99 1.99 0 013 12V7a4 4 0 014-4z" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white p-5 rounded shadow">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Input
            label="Search" name="search" value={filters.search} onChange={handleFilterChange} placeholder="Payee, reference…"
            leftIcon={<svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>}
          />
          <Select label="Category" name="category_id" value={filters.category_id} onChange={handleFilterChange} options={[{ value: "", label: "All Categories" }, ...categories.map((c) => ({ value: c.id, label: c.name }))]} />
          <Select label="Payment Method" name="payment_method" value={filters.payment_method} onChange={handleFilterChange} options={[{ value: "", label: "All Methods" }, ...PAYMENT_METHODS]} />
          <DatePicker label="From" value={filters.start_date} min={yearBounds?.start} max={yearBounds?.end} onChange={(e) => handleFilterChange({ target: { name: "start_date", value: e.target.value } })} />
          <DatePicker label="To" value={filters.end_date} min={yearBounds?.start} max={yearBounds?.end} onChange={(e) => handleFilterChange({ target: { name: "end_date", value: e.target.value } })} />
        </div>
      </div>

      <DataTable
        columns={[
          { key: "expense_date", label: "Date", render: (e) => <span className="text-sm text-gray-600">{formatDate(e.expense_date)}</span> },
          { key: "category", label: "Category", render: (e) => <span className="text-sm text-gray-700">{e.category?.name}</span> },
          { key: "payee", label: "Paid To", render: (e) => <span className="text-sm text-gray-900">{e.payee || "—"}</span> },
          { key: "amount", label: "Amount", render: (e) => <span className="text-sm font-medium text-gray-900">{formatMoney(e.amount)}</span> },
          { key: "payment_method", label: "Method", render: (e) => <span className="text-xs text-gray-500 capitalize">{e.payment_method.replace("_", " ")}</span> },
          { key: "status", label: "Status", render: (e) => e.status === "void" ? <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 border border-red-300 text-red-500">Void</span> : <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full border border-green-300 bg-green-100 text-green-500">Recorded</span> },
          { key: "receipt", label: "Receipt", render: (e) => e.receipt_url ? <a href={e.receipt_url} target="_blank" rel="noreferrer" className="text-primary hover:underline text-xs" onClick={(ev) => ev.stopPropagation()}>View</a> : <span className="text-xs text-gray-300">—</span> },
        ]}
        data={expenses}
        loading={loading}
        emptyMessage={hasActiveFilters ? "No expenses match these filters" : "No expenses recorded yet"}
        renderActions={(can("expenses.update") || can("expenses.delete")) ? (e) => (
          e.status === "void" ? null : (
            <RowActions
              actions={[
                { label: e.receipt_url ? "Replace Receipt" : "Upload Receipt", variant: "primary", icon: ACTION_ICONS.upload, hidden: !can("expenses.update") || !can("expenses.update"), onClick: () => openUploadReceipt(e.id) },
                { label: "Edit Expense", icon: ACTION_ICONS.edit, hidden: !can("expenses.update"), onClick: () => openEdit(e) },
                { label: "Void Expense", variant: "danger", icon: ACTION_ICONS.remove, hidden: !can("expenses.delete"), onClick: () => handleVoid(e) },
              ]}
            />
          )
        ) : undefined}
        pagination={{ ...pagination, limit: pagination.itemsPerPage }}
        onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
      />

      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Expense" : "Record Expense"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Select label="Category" required value={form.category_id} onChange={(e) => setForm((f) => ({ ...f, category_id: e.target.value }))}
                  options={[{ value: "", label: "Select…" }, ...categories.map((c) => ({ value: c.id, label: c.name }))]} />
                <NumberInput label="Amount (TZS)" required value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} placeholder="Enter amount" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <DatePicker label="Date" required value={form.expense_date} onChange={(e) => setForm((f) => ({ ...f, expense_date: e.target.value }))} />
                <Select label="Payment Method" value={form.payment_method} onChange={(e) => setForm((f) => ({ ...f, payment_method: e.target.value }))} options={PAYMENT_METHODS} />
              </div>
              <Input label="Paid To" value={form.payee} onChange={(e) => setForm((f) => ({ ...f, payee: e.target.value }))} placeholder="Vendor, company, or person" />
              <Input label="Reference Number" value={form.reference_number} onChange={(e) => setForm((f) => ({ ...f, reference_number: e.target.value }))} placeholder="Receipt/invoice number (optional)" />
              <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} placeholder="Enter description (optional)" />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Record"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmVoid.isOpen} title="Void Expense" message="Void this expense? It stays in the ledger for audit purposes but no longer counts toward totals." variant="danger" onConfirm={confirmVoidExpense} onClose={() => setConfirmVoid({ isOpen: false })} />
    </div>
  );
}

function CategoriesTab({ showSuccess, showError, createSignal }) {
  const { can } = useAuth();
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({ name: "", description: "", status: "active" });
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState({ isOpen: false });

  const load = async () => {
    try {
      setLoading(true);
      const res = await expenseService.getCategories({});
      if (res.success) setCategories(res.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const openCreate = () => { setForm({ name: "", description: "", status: "active" }); setModal({ isOpen: true, mode: "create" }); };

  // Opened from the header button in the parent — see LedgerTab for why.
  useEffect(() => {
    if (createSignal?.tab === "categories" && createSignal.n > 0) openCreate();
  }, [createSignal?.n]); // eslint-disable-line react-hooks/exhaustive-deps
  const openEdit = (c) => { setForm({ name: c.name, description: c.description || "", status: c.status }); setModal({ isOpen: true, mode: "edit", id: c.id }); };

  const handleSave = async () => {
    if (!form.name) { showError("Name is required"); return; }
    try {
      setSaving(true);
      if (modal.mode === "edit") await expenseService.updateCategory(modal.id, form);
      else await expenseService.createCategory(form);
      showSuccess(modal.mode === "edit" ? "Category updated" : "Category created");
      setModal({ isOpen: false });
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (c) => setConfirmDelete({ isOpen: true, id: c.id, name: c.name });
  const confirmDeleteCategory = async () => {
    try {
      await expenseService.deleteCategory(confirmDelete.id);
      showSuccess("Category deleted");
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmDelete({ isOpen: false });
  };

  return (
    <div className="space-y-4">
      {/* Uses the shared DataTable rather than a hand-rolled <table> so this
          tab gets the same loading spinner and empty state as the rest of
          the system — previously an empty list rendered as a bare header
          row with nothing under it. */}
      <DataTable
        columns={[
          { key: "name", label: "Name", render: (c) => <span className="text-sm text-gray-900">{c.name}</span> },
          { key: "description", label: "Description", render: (c) => <span className="text-sm text-gray-600">{c.description || "—"}</span> },
          {
            key: "status", label: "Status",
            render: (c) => (
              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${c.status === "active" ? "bg-green-100 border border-green-300 text-green-500" : "bg-red-100 border border-red-300 text-red-500"}`}>
                {c.status}
              </span>
            ),
          },
        ]}
        data={categories}
        loading={loading}
        emptyMessage="No expense categories yet"
        renderActions={(can("expenses.update") || can("expenses.delete")) ? (c) => (
          <RowActions
            actions={[
              { label: "Edit Category", variant: "primary", icon: ACTION_ICONS.edit, hidden: !can("expenses.update"), onClick: () => openEdit(c) },
              { label: "Delete Category", variant: "danger", icon: ACTION_ICONS.delete, hidden: !can("expenses.delete"), onClick: () => handleDelete(c) },
            ]}
          />
        ) : undefined}
      />

      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-sm">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Category" : "New Category"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4">
              <Input label="Category name" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Enter category name" />
              <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} placeholder="Enter description (optional)" />
              <Select label="Status" value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))} options={[{ value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }]} />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Create"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmDelete.isOpen} title="Delete Category" message={`Delete "${confirmDelete.name}"?`} variant="danger" onConfirm={confirmDeleteCategory} onClose={() => setConfirmDelete({ isOpen: false })} />
    </div>
  );
}