import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { subscriptionService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { useSubscription } from "../../contexts/SubscriptionContext";
import { Select, PhoneInput, Button, DataTable, ConfirmModal } from "../../components/ui";
import { formatMoney } from "../../utils/money";

const STATUS_STYLES = {
  trial: "bg-blue-100 border border-blue-300 text-blue-500",
  active: "bg-green-100 border border-green-300 text-green-500",
  grace: "bg-amber-100 border border-amber-300 text-amber-600",
  expired: "bg-red-100 border border-red-300 text-red-500",
  cancelled: "bg-gray-100 border border-gray-300 text-gray-500",
  none: "bg-gray-100 border border-gray-300 text-gray-500",
};

const INVOICE_STATUS_STYLES = {
  pending: "bg-gray-100 border border-gray-300 text-gray-500",
  processing: "bg-amber-100 border border-amber-300 text-amber-600",
  paid: "bg-green-100 border border-green-300 text-green-500",
  failed: "bg-red-100 border border-red-300 text-red-500",
  cancelled: "bg-gray-100 border border-gray-300 text-gray-500",
};

const CYCLES = [
  { value: "monthly", label: "Monthly" },
  { value: "termly", label: "Per Term" },
  { value: "yearly", label: "Yearly" },
];

const PRICE_FIELD = { monthly: "price_monthly", termly: "price_termly", yearly: "price_yearly" };

const money = (n) => formatMoney(n);

export default function Subscription() {
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();
  const navigate = useNavigate();
  const { locked, status: lockStatus, refresh: refreshLock } = useSubscription();

  const [createdInvoice, setCreatedInvoice] = useState(null); // the invoice just made, so it can be previewed straight away
  const [payTarget, setPayTarget] = useState(null);           // an existing invoice being paid now
  const [cleanup, setCleanup] = useState(null);                // the clean-up dialog: { data } once the preview is in
  const [cleaning, setCleaning] = useState(false);
  const [confirmCancel, setConfirmCancel] = useState({ isOpen: false, invoice: null }); // our confirmation modal for cancelling an invoice
  const [loading, setLoading] = useState(true);
  const [subscription, setSubscription] = useState(null);
  const [plans, setPlans] = useState([]);
  const [studentCount, setStudentCount] = useState(0);
  const [invoices, setInvoices] = useState([]);

  const [cycle, setCycle] = useState("monthly");
  const [checkoutPlan, setCheckoutPlan] = useState(null);
  const [quote, setQuote] = useState(null);
  const [phone, setPhone] = useState("");
  const [paying, setPaying] = useState(false);
  const [pendingRef, setPendingRef] = useState(null);
  const [checkingStatus, setCheckingStatus] = useState(false);

  const isAdmin = can("subscription.manage");

  const load = async () => {
    try {
      const [meRes, plansRes, invRes] = await Promise.all([
        subscriptionService.getMine(),
        subscriptionService.getPlans(),
        subscriptionService.getInvoices({ limit: 10 }),
      ]);
      if (meRes.success) setSubscription(meRes.data);
      if (plansRes.success) {
        setPlans(plansRes.data.plans || []);
        setStudentCount(plansRes.data.student_count || 0);
      }
      if (invRes.success) setInvoices(invRes.data || []);
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const openCheckout = async (plan) => {
    setCheckoutPlan(plan);
    setQuote(null);
    try {
      const res = await subscriptionService.getQuote({ plan_id: plan.id, billing_cycle: cycle });
      if (res.success) setQuote(res.data);
    } catch (err) {
      showError(err.response?.data?.message || err.message);
      setCheckoutPlan(null);
    }
  };

  const gatewayReady = subscription?.gateway_configured !== false;

  const handlePay = async () => {
    if (gatewayReady && !phone) return showError("Enter the mobile money number to charge");
    try {
      setPaying(true);
      const res = await subscriptionService.checkout({
        plan_id: checkoutPlan.id, billing_cycle: cycle, phone: phone || undefined,
      });
      if (res.success) {
        showSuccess(res.message);
        setCreatedInvoice(res.data.invoice);
        if (res.data.payment_started) setPendingRef(res.data.invoice.order_reference);
        setCheckoutPlan(null);
        load();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    } finally {
      setPaying(false);
    }
  };

  // Asks first through the shared ConfirmModal; the cancel itself runs once confirmed.
  const handleCancelInvoice = (invoice) => setConfirmCancel({ isOpen: true, invoice });

  const doCancelInvoice = async () => {
    const invoice = confirmCancel.invoice;
    if (!invoice) return;
    try {
      const res = await subscriptionService.cancelInvoice(invoice.invoice_number);
      if (res.success) {
        showSuccess(res.message);
        if (createdInvoice?.invoice_number === invoice.invoice_number) setCreatedInvoice(null);
        load();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    }
  };

  const openCleanup = async () => {
    setCleanup({ loading: true });
    try {
      const res = await subscriptionService.previewInvoiceCleanup();
      setCleanup({ data: res.data });
    } catch (err) {
      setCleanup(null);
      showError(err.response?.data?.message || err.message);
    }
  };

  const runCleanup = async () => {
    try {
      setCleaning(true);
      const res = await subscriptionService.runInvoiceCleanup();
      showSuccess(res.message);
      setCleanup(null);
      load();
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    } finally {
      setCleaning(false);
    }
  };

  const handlePayExisting = async () => {
    if (!phone) return showError("Enter the mobile money number to charge");
    try {
      setPaying(true);
      const res = await subscriptionService.payInvoice(payTarget.invoice_number, { phone });
      if (res.success) {
        showSuccess(res.message);
        setPendingRef(res.data.invoice.order_reference);
        setCreatedInvoice(null);
        setPayTarget(null);
        load();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    } finally {
      setPaying(false);
    }
  };

  /** A webhook can be missed, so the school always has its own way to ask
   * whether the payment landed. */
  const handleCheckStatus = async (reference) => {
    try {
      setCheckingStatus(true);
      const res = await subscriptionService.checkStatus(reference);
      if (res.success) {
        showSuccess(res.message || "Status refreshed");
        if (res.data?.status === "paid") {
          setPendingRef(null);
          setCreatedInvoice(null);
          await refreshLock(); // unlocks the menu straight away
        }
        load();
      }
    } catch (err) {
      showError(err.response?.data?.message || err.message);
    } finally {
      setCheckingStatus(false);
    }
  };

  if (loading) {
    return <MainLayout><div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div></MainLayout>;
  }

  const evaluation = subscription?.evaluation || { status: "none" };
  const currentPlan = subscription?.plan;

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Subscription</h1>
            <p className="text-sm text-gray-500 mt-0.5">Your EduTrack plan and billing</p>
          </div>
        </div>

        {/* Grace and expiry are the two states worth shouting about. */}
        {evaluation.inGrace && (
          <div className="bg-amber-50 border border-amber-200 rounded px-4 py-3 text-sm text-left text-amber-800">
            Your subscription has ended and you are in the grace period —
            about <strong>{evaluation.graceHoursLeft} hour(s)</strong> of access remain. Renew now to avoid
            being locked out.
          </div>
        )}
        {(locked || evaluation.locked) && (
          <div className="bg-red-50 border border-red-200 rounded px-4 py-3 text-sm text-left text-red-700">
            <p className="font-semibold">EduTrack is locked</p>
            <p className="mt-0.5">
              {(lockStatus || evaluation.status) === "cancelled"
                ? "This subscription has been cancelled."
                : "This subscription has expired and the grace period has passed."}{" "}
              {isAdmin
                ? "Everything except this page stays closed until a payment is confirmed. Choose a plan below. You can still preview and download your invoices and receipts."
                : "Please ask your school administrator to renew it."}
            </p>
          </div>
        )}
        {!gatewayReady && isAdmin && (
          <div className="bg-blue-50 border border-blue-200 rounded px-4 py-3 text-sm text-left text-blue-800">
            Online payment is not switched on for this server yet. You can still create an invoice and preview or download it; the payment prompt starts working once the platform administrator adds the ClickPesa credentials.
          </div>
        )}
        {createdInvoice && (
          <div className="bg-white border border-green-200 rounded shadow-sm px-4 py-3 flex flex-wrap items-center justify-between gap-3">
            <div className="text-left">
              <p className="text-sm font-semibold text-gray-900">Invoice {createdInvoice.invoice_number} created</p>
              <p className="text-xs text-gray-500 mt-0.5">{money(createdInvoice.total)} · {createdInvoice.status === "pending" ? "unpaid" : createdInvoice.status}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" onClick={() => navigate(`/subscription/invoices/${createdInvoice.invoice_number}`)}>Preview invoice</Button>
              {gatewayReady && createdInvoice.status === "pending" && (
                <Button size="sm" variant="secondary" onClick={() => { setPhone(""); setPayTarget(createdInvoice); }}>Pay now</Button>
              )}
              {createdInvoice.status === "pending" && (
                <Button size="sm" variant="secondary" onClick={() => handleCancelInvoice(createdInvoice)}>Cancel invoice</Button>
              )}
              <Button size="sm" variant="secondary" onClick={() => setCreatedInvoice(null)}>Dismiss</Button>
            </div>
          </div>
        )}
        {subscription?.over_student_limit && (
          <div className="bg-amber-50 border border-amber-200 rounded px-4 py-3 text-sm text-left text-amber-800">
            You have {studentCount} active students, more than your plan allows. Existing students are
            unaffected, but you cannot admit new ones until you upgrade.
          </div>
        )}

        {/* Current status */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white text-left p-5 rounded shadow">
            <p className="text-sm text-left text-gray-600">Current Plan</p>
            <p className="text-xl text-left font-bold text-gray-900 mt-1">{currentPlan?.name || "None"}</p>
            <span className={`mt-2 px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${STATUS_STYLES[evaluation.status]}`}>
              {evaluation.status}
            </span>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <p className="text-sm text-left text-gray-600">Renews / Expires</p>
            <p className="text-xl text-left font-bold text-gray-900 mt-1">
              {subscription?.ends_at ? formatDate(subscription.ends_at) : "—"}
            </p>
            {evaluation.daysLeft > 0 && (
              <p className="text-xs text-left text-gray-400 mt-1">{evaluation.daysLeft} day(s) left</p>
            )}
          </div>
          <div className="bg-white p-5 rounded shadow">
            <p className="text-sm text-left text-gray-600">Active Students</p>
            <p className="text-xl text-left font-bold text-primary mt-1">{studentCount}</p>
            <p className="text-xs text-left text-gray-400 mt-1">
              {currentPlan?.student_limit === null ? "Unlimited" : currentPlan ? `Limit ${currentPlan.student_limit}` : "No plan"}
            </p>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <p className="text-sm text-left text-gray-600">Billing Cycle</p>
            <p className="text-xl text-left font-bold text-gray-900 mt-1 capitalize">{subscription?.billing_cycle || "—"}</p>
            <p className="text-xs text-left text-gray-400 mt-1">Last paid {money(subscription?.amount_paid)}</p>
          </div>
        </div>

        {pendingRef && (
          <div className="bg-blue-50 border border-blue-200 rounded px-4 py-3 flex items-center justify-between gap-3 flex-wrap">
            <p className="text-sm text-left text-blue-800">
              A payment is awaiting approval on the handset. Once approved, your plan activates automatically.
            </p>
            <Button size="sm" variant="secondary" loading={checkingStatus} onClick={() => handleCheckStatus(pendingRef)}>
              Check Payment Status
            </Button>
          </div>
        )}

        {/* Plans */}
        <div className="bg-white p-5 rounded shadow">
          <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
            <h2 className="text-md text-left font-semibold text-gray-900">Choose a Plan</h2>
            <div className="w-48">
              <Select value={cycle} onChange={(e) => setCycle(e.target.value)} options={CYCLES} />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {plans.map((plan) => {
              const isCurrent = currentPlan?.id === plan.id;
              const price = plan[PRICE_FIELD[cycle]];
              return (
                <div key={plan.id} className={`border rounded p-5 flex flex-col ${isCurrent ? "border-primary bg-primary-5" : "border-gray-200"}`}>
                  <div className="flex items-start justify-between">
                    <h3 className="text-base font-bold text-gray-900">{plan.name}</h3>
                    {isCurrent && (
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-primary-15 text-primary">Current</span>
                    )}
                  </div>
                  <p className="text-2xl font-extrabold text-primary mt-2 text-left">{money(price)}</p>
                  <p className="text-xs text-gray-400 text-left">
                    per {cycle === "monthly" ? "month" : cycle === "termly" ? "term" : "year"}
                  </p>
                  <p className="text-sm text-gray-600 text-left mt-3 flex-1">{plan.description}</p>
                  <p className="text-xs text-left text-gray-500 mt-3">
                    {plan.student_limit === null ? "Unlimited students" : `Up to ${plan.student_limit} students`}
                  </p>

                  {/* A plan smaller than the school can't be bought — saying
                      so here beats a rejection at the payment step. */}
                  {!plan.fits_school ? (
                    <p className="text-xs text-red-600 text-left mt-3">
                      Too small — you have {studentCount} students.
                    </p>
                  ) : isAdmin && (
                    <Button className="mt-4 w-full" onClick={() => openCheckout(plan)}>
                      {isCurrent ? "Renew" : currentPlan && plan.tier > currentPlan.tier ? "Upgrade" : "Choose Plan"}
                    </Button>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Invoices */}
        {isAdmin && (
          <div className="flex flex-wrap items-center justify-between gap-2 -mb-2">
            <h2 className="text-base font-semibold text-gray-900">Invoices</h2>
            <Button variant="secondary" size="sm" onClick={openCleanup}>Clean up old invoices</Button>
          </div>
        )}
        <DataTable
          columns={[
            { key: "invoice_number", label: "Invoice", render: (i) => <span className="text-sm font-medium text-gray-900">{i.invoice_number}</span> },
            { key: "plan", label: "Plan", render: (i) => <span className="text-sm text-gray-600">{i.plan?.name || "—"} <span className="text-gray-400 capitalize">({i.billing_cycle})</span></span> },
            { key: "total", label: "Amount", align: "right", render: (i) => <span className="text-sm font-medium text-gray-900">{money(i.total)}</span> },
            {
              key: "status", label: "Status", align: "center",
              render: (i) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${INVOICE_STATUS_STYLES[i.status]}`}>
                  {i.status}
                </span>
              ),
            },
            { key: "date", label: "Date", render: (i) => <span className="text-xs text-gray-500">{formatDate(i.createdAt)}</span> },
          ]}
          data={invoices}
          rowId="id"
          emptyMessage="No invoices yet"
          renderActions={(i) => (
            <div className="flex flex-wrap items-center justify-end gap-x-3 gap-y-1">
              <button onClick={() => navigate(`/subscription/invoices/${i.invoice_number}`)} className="text-primary hover:underline text-xs font-medium">
                {i.status === "paid" ? "Paid invoice" : "Preview"}
              </button>
              {i.status === "paid" && (
                <button onClick={() => navigate(`/subscription/invoices/${i.invoice_number}/receipt`)} className="text-primary hover:underline text-xs font-medium">
                  Receipt
                </button>
              )}
              {gatewayReady && isAdmin && (i.status === "pending" || i.status === "failed") && (
                <button onClick={() => { setPhone(""); setPayTarget(i); }} className="text-primary hover:underline text-xs font-medium">Pay</button>
              )}
              {isAdmin && (i.status === "pending" || i.status === "failed") && (
                <button onClick={() => handleCancelInvoice(i)} className="text-red-600 hover:underline text-xs font-medium">Cancel</button>
              )}
              {(i.status === "processing" || (i.status === "pending" && i.gateway)) && (
                <button onClick={() => handleCheckStatus(i.order_reference)} className="text-primary hover:underline text-xs font-medium">
                  Check Status
                </button>
              )}
            </div>
          )}
        />
      </div>

      {/* Checkout */}
      {checkoutPlan && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <div className="text-left">
                <h3 className="text-base font-semibold">{checkoutPlan.name} — {CYCLES.find((c) => c.value === cycle)?.label}</h3>
                <p className="text-xs text-gray-500 mt-0.5">Pay with mobile money</p>
              </div>
              <button onClick={() => setCheckoutPlan(null)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>

            <form onSubmit={(e) => { e.preventDefault(); handlePay(); }} className="px-5 py-4 space-y-4">
              {quote ? (
                <div className="bg-gray-50 border border-gray-200 rounded px-3 py-2.5 space-y-1.5 text-sm">
                  {quote.lineItems.map((li, idx) => (
                    <div key={idx} className="flex justify-between gap-3">
                      <span className={li.amount < 0 ? "text-green-600" : "text-gray-600"}>{li.label}</span>
                      <span className={li.amount < 0 ? "text-green-600" : "text-gray-800"}>{money(li.amount)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between border-t border-gray-200 pt-1.5">
                    <span className="font-medium text-gray-700">Total</span>
                    <span className="font-bold text-gray-900">{money(quote.total)}</span>
                  </div>
                </div>
              ) : (
                <div className="py-4 text-center"><div className="inline-block animate-spin rounded-full h-5 w-5 border-b-2 border-primary" /></div>
              )}

              {gatewayReady ? (
                <>
                  <PhoneInput label="Mobile Money Number" required value={phone} onChange={(e) => setPhone(e.target.value)} />
                  <p className="text-xs text-left text-gray-500">
                    An invoice is created and a prompt is sent to this number. Your plan activates only once the payment is confirmed.
                  </p>
                </>
              ) : (
                <p className="text-xs text-left text-gray-500">
                  An invoice will be created for you to preview and download. Online payment is not available on this server yet, so no prompt is sent.
                </p>
              )}

              <div className="flex gap-3">
                <Button type="submit" loading={paying} disabled={!quote}>{gatewayReady ? `Pay ${quote ? money(quote.total) : ""}` : "Create invoice"}</Button>
                <Button type="button" variant="secondary" onClick={() => setCheckoutPlan(null)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Clean up old invoices */}
      {cleanup && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md text-left">
            <div className="px-5 py-4 border-b border-gray-200">
              <h3 className="text-base font-semibold">Clean up old invoices</h3>
            </div>
            <div className="px-5 py-4 space-y-4 text-sm text-gray-700">
              {cleanup.loading ? (
                <div className="py-4 text-center"><div className="inline-block animate-spin rounded-full h-5 w-5 border-b-2 border-primary" /></div>
              ) : cleanup.data.total === 0 ? (
                <p>There is nothing to clean up. No invoices are cancelled, and none have stayed unpaid for over {cleanup.data.older_than_days} days.</p>
              ) : (
                <>
                  <p>These will be removed for good:</p>
                  <ul className="list-disc ml-5 space-y-1">
                    {cleanup.data.cancelled > 0 && <li><strong>{cleanup.data.cancelled}</strong> cancelled invoice{cleanup.data.cancelled === 1 ? "" : "s"}</li>}
                    {cleanup.data.unpaid_old > 0 && <li><strong>{cleanup.data.unpaid_old}</strong> unpaid invoice{cleanup.data.unpaid_old === 1 ? "" : "s"} older than {cleanup.data.older_than_days} days</li>}
                  </ul>
                  <p className="text-xs text-gray-500">e.g. {cleanup.data.sample.join(", ")}{cleanup.data.total > cleanup.data.sample.length ? ", …" : ""}</p>
                  <p className="text-xs text-gray-500">Paid invoices and receipts are never removed, and neither is an invoice whose payment is waiting for approval. Invoice numbers are not reused. The clean-up is recorded in the Audit Log.</p>
                </>
              )}
              <div className="flex gap-3 pt-1">
                {!cleanup.loading && cleanup.data.total > 0 && <Button onClick={runCleanup} loading={cleaning}>Remove {cleanup.data.total}</Button>}
                <Button variant="secondary" onClick={() => setCleanup(null)}>{!cleanup.loading && cleanup.data.total === 0 ? "Close" : "Cancel"}</Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Pay an invoice that already exists */}
      {payTarget && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <div className="text-left">
                <h3 className="text-base font-semibold">Pay invoice {payTarget.invoice_number}</h3>
                <p className="text-xs text-gray-500 mt-0.5">{money(payTarget.total)} · mobile money</p>
              </div>
              <button onClick={() => setPayTarget(null)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handlePayExisting(); }} className="px-5 py-4 space-y-4">
              <PhoneInput label="Mobile Money Number" required value={phone} onChange={(e) => setPhone(e.target.value)} />
              <p className="text-xs text-left text-gray-500">A prompt is sent to this number. Your plan activates only once the payment is confirmed.</p>
              <div className="flex gap-3">
                <Button type="submit" loading={paying}>Pay {money(payTarget.total)}</Button>
                <Button type="button" variant="secondary" onClick={() => setPayTarget(null)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal
        isOpen={confirmCancel.isOpen}
        title="Cancel Invoice"
        message={confirmCancel.invoice ? `Cancel invoice ${confirmCancel.invoice.invoice_number}? Its pay link will stop working. You can create a new invoice at any time.` : ""}
        confirmText="Cancel Invoice"
        cancelText="Keep Invoice"
        onConfirm={doCancelInvoice}
        onClose={() => setConfirmCancel({ isOpen: false, invoice: null })}
      />
    </MainLayout>
  );
}
