import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { subscriptionService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import SubscriptionDocument from "../../components/SubscriptionDocument";
import { buildDoc, exportSubscriptionDocPDF } from "../../utils/subscriptionDocs";
import { Button } from "../../components/ui";

/**
 * Preview, download and print one subscription invoice — or, with kind="receipt",
 * its payment receipt (only available once the invoice is paid).
 *   /subscription/invoices/:reference            → invoice
 *   /subscription/invoices/:reference/receipt    → receipt
 */
export default function InvoiceView({ kind = "invoice" }) {
  const { reference } = useParams();
  const navigate = useNavigate();
  const { showError } = useToast();
  const { formatDate } = usePreferences();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    setLoading(true);
    subscriptionService.getInvoice(reference)
      .then((res) => { if (res.success) setData(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, [reference]);

  const doc = useMemo(() => (data ? buildDoc(kind, data, formatDate) : null), [data, kind, formatDate]);
  const receiptBlocked = kind === "receipt" && data && data.invoice.status !== "paid";

  const download = async () => {
    try {
      setDownloading(true);
      await exportSubscriptionDocPDF(doc);
    } catch {
      showError("Could not create the PDF. Try Print instead.");
    } finally {
      setDownloading(false);
    }
  };

  const back = () => navigate("/subscription");

  if (loading) {
    return <MainLayout><div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div></MainLayout>;
  }

  if (!data || receiptBlocked) {
    return (
      <MainLayout>
        <div className="bg-white p-10 rounded shadow text-center text-gray-500 text-sm">
          <p>{receiptBlocked ? "A receipt is only issued once the invoice has been paid." : "Invoice not found."}</p>
          <div className="mt-4 flex justify-center gap-3">
            {receiptBlocked && <Button variant="secondary" onClick={() => navigate(`/subscription/invoices/${reference}`)}>View the invoice</Button>}
            <Button onClick={back}>Back to Subscription</Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  const paid = data.invoice.status === "paid";

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-3 print:hidden">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">{kind === "receipt" ? "Payment Receipt" : "Invoice"} {doc.number}</h1>
            <p className="text-sm text-gray-500 mt-0.5">Preview — what you see is what the PDF contains</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={download} loading={downloading}>Download PDF</Button>
            <Button variant="secondary" onClick={() => window.print()}>Print</Button>
            {kind === "receipt" ? (
              <Button variant="secondary" onClick={() => navigate(`/subscription/invoices/${data.invoice.invoice_number}`)}>View invoice</Button>
            ) : paid ? (
              <Button variant="secondary" onClick={() => navigate(`/subscription/invoices/${data.invoice.invoice_number}/receipt`)}>View receipt</Button>
            ) : null}
            <Button variant="secondary" onClick={back}>Back</Button>
          </div>
        </div>

        <SubscriptionDocument doc={doc} />
      </div>
    </MainLayout>
  );
}
