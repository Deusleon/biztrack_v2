import { useCallback, useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { payLinkService } from "../../services/api";
import { formatMoney } from "../../utils/money";
import BrandMark from "../../components/BrandMark";

const fmtDate = (d) => (d ? new Date(d).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "—");
const POLL_MS = 5000;

/**
 * Public page (no sign-in): what a "Scan to pay" QR code on a subscription invoice opens.
 * Shows what is being paid, takes a mobile-money number, sends the payment prompt, then waits
 * for it to be approved. The code in the link is the only proof needed — it is signed by the
 * server and tied to this invoice and amount.
 */
export default function PayInvoice() {
  const { number, code } = useParams();
  const [invoice, setInvoice] = useState(null);       // null = loading
  const [phone, setPhone] = useState("");
  const [paying, setPaying] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const timer = useRef(null);

  const load = useCallback(async () => {
    try {
      const res = await payLinkService.get(number, code);
      setInvoice(res.data);
    } catch {
      setInvoice({ valid: false, unreachable: true });
    }
  }, [number, code]);

  const poll = useCallback(async () => {
    try {
      const res = await payLinkService.status(number, code);
      if (res.data) setInvoice(res.data);
      if (res.message) setMessage(res.message);
    } catch { /* try again on the next tick */ }
  }, [number, code]);

  useEffect(() => { load(); }, [load]);

  // While a prompt is waiting on the phone, keep asking.
  useEffect(() => {
    clearInterval(timer.current);
    if (invoice?.status === "processing") timer.current = setInterval(poll, POLL_MS);
    return () => clearInterval(timer.current);
  }, [invoice?.status, poll]);

  const pay = async (e) => {
    e.preventDefault();
    setError(""); setMessage("");
    if (!phone.trim()) return setError("Enter the mobile money number to charge.");
    setPaying(true);
    try {
      const res = await payLinkService.pay(number, code, { phone });
      if (res.data) setInvoice(res.data);
      setMessage(res.message || "");
    } catch (err) {
      setError(err.response?.data?.message || "Could not start the payment. Please try again.");
      load();
    } finally {
      setPaying(false);
    }
  };

  const Row = ({ label, value, strong }) => (
    <div className="flex justify-between gap-4 py-2 border-b border-gray-100 text-sm">
      <span className="text-gray-500">{label}</span>
      <span className={`text-right ${strong ? "font-bold text-gray-900" : "font-medium text-gray-800"}`}>{value}</span>
    </div>
  );

  const loading = invoice === null;
  const invalid = invoice && invoice.valid === false;
  const status = invoice?.status;

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md bg-white rounded shadow-lg overflow-hidden text-left">
        <div className="gradient-primary-dark px-8 py-6 text-center">
          <BrandMark className="w-16 h-auto mx-auto mb-2" />
          <h1 className="text-xl font-bold tracking-tight text-white">Pay your EduTrack invoice</h1>
          <p className="text-xs text-white/80 mt-1">Secure mobile money payment</p>
        </div>

        <div className="p-8 space-y-5">
          {loading && <div className="text-center py-6"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>}

          {invalid && (
            <div className="rounded px-4 py-3 bg-red-50 border border-red-200 text-red-700 text-sm">
              <p className="font-bold">{invoice.unreachable ? "Could not reach EduTrack" : "This payment link is not valid"}</p>
              <p className="mt-1">{invoice.unreachable ? "Check your internet connection and try again." : "Ask the school to send you the invoice again, or contact EduTrack support."}</p>
            </div>
          )}

          {invoice?.valid && (
            <>
              <div>
                <Row label="Invoice" value={invoice.invoice_number} strong />
                <Row label="School" value={invoice.school || "—"} />
                <Row label="Plan" value={`${invoice.plan || "—"} (${invoice.billing_cycle})`} />
                <Row label="Service period" value={`${fmtDate(invoice.period_start)} to ${fmtDate(invoice.period_end)}`} />
                <Row label="Amount" value={formatMoney(invoice.amount, invoice.currency || "TZS")} strong />
              </div>

              {status === "paid" && (
                <div className="rounded px-4 py-3 bg-green-50 border border-green-200 text-green-700 text-sm">
                  <p className="font-bold">Paid. Thank you!</p>
                  <p className="mt-1">The subscription is active. Receipt {invoice.receipt_number} has been emailed to the school's administrators.</p>
                </div>
              )}

              {status === "cancelled" && (
                <div className="rounded px-4 py-3 bg-gray-50 border border-gray-200 text-gray-600 text-sm">This invoice was cancelled. Ask the school to create a new one.</div>
              )}

              {status === "processing" && (
                <div className="rounded px-4 py-3 bg-amber-50 border border-amber-200 text-amber-800 text-sm">
                  <p className="font-bold">Waiting for your approval</p>
                  <p className="mt-1">A payment prompt was sent to the phone. Enter your PIN to approve it. This page updates by itself.</p>
                  <button type="button" onClick={poll} className="mt-2 text-xs underline">Check now</button>
                </div>
              )}

              {(status === "pending" || status === "failed") && (
                invoice.payments_available ? (
                  <form onSubmit={pay} className="space-y-3">
                    {status === "failed" && <p className="text-xs text-red-600">The last attempt did not go through. You can try again.</p>}
                    <div>
                      <label className="text-xs font-medium text-gray-700 block mb-1">Mobile money number</label>
                      <input
                        inputMode="tel" autoComplete="tel" placeholder="255712345678" value={phone} onChange={(e) => setPhone(e.target.value)}
                        className="w-full border border-gray-300 rounded px-3 py-2.5 text-sm focus:outline-none focus:border-primary"
                      />
                      <p className="text-[11px] text-gray-500 mt-1">Airtel Money, Mixx by Yas or HaloPesa. A prompt is sent to this number.</p>
                    </div>
                    <button type="submit" disabled={paying} className="w-full bg-primary text-white text-sm font-semibold py-2.5 rounded hover:opacity-90 disabled:opacity-60">
                      {paying ? "Sending prompt…" : `Pay ${formatMoney(invoice.amount, invoice.currency || "TZS")}`}
                    </button>
                  </form>
                ) : (
                  <div className="rounded px-4 py-3 bg-blue-50 border border-blue-200 text-blue-800 text-sm">Online payment is not available yet. Please contact EduTrack support to pay this invoice.</div>
                )
              )}

              {message && <p className="text-sm text-green-700">{message}</p>}
              {error && <p className="text-sm text-red-600">{error}</p>}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
