// FILE PATH: frontend/src/pages/Dashboard.jsx
// Replaces the existing file at this exact path.
import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { usePreferences } from '../contexts/PreferencesContext';
import { useAcademicYear } from '../contexts/AcademicYearContext';
import { useCampus } from '../contexts/CampusContext';
import { useToast } from '../contexts/ToastContext';
import { Navigate, Link } from 'react-router-dom';
import { analyticsService, settingsService } from '../services/api';
import MainLayout from '../components/MainLayout';

const STATS_ROLES = ['super_admin', 'admin', 'principal'];

const greeting = () => {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
};

const Icon = {
  chevron: (p) => (
    <svg {...p} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clipRule="evenodd" /></svg>
  ),
  calendar: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
  ),
  students: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
  ),
  staff: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
  ),
  classes: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
  ),
  checklist: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg>
  ),
  leave: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
  ),
  exam: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
  ),
  cash: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
  ),
  expense: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4m0 0l6-6m-6 6l6 6" /></svg>
  ),
  debit: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v6m0 0l-3-3m3 3l3-3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
  ),
  bell: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
  ),
  reports: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
  ),
  addUser: (p) => (
    <svg {...p} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg>
  ),
};

const QUICK_ACTIONS = [
  { perm: 'students.create', label: 'Add student', to: '/students/admission', icon: Icon.addUser, roles: ['super_admin', 'admin', 'principal'] },
  { perm: 'attendance.create', label: 'Mark attendance', to: '/attendance/take', icon: Icon.checklist, roles: ['super_admin', 'admin', 'principal', 'teacher'] },
  { perm: 'exams.create', label: 'Create exam', to: '/exams', icon: Icon.exam, roles: ['super_admin', 'admin', 'principal', 'teacher'] },
  { perm: 'fees.create', label: 'Collect fee', to: '/fees/record', icon: Icon.cash, roles: ['super_admin', 'admin', 'principal', 'accountant'] },
  { perm: 'send_messages', label: 'Send notice', to: '/messages/compose', icon: Icon.bell, roles: ['super_admin', 'admin', 'principal'] },
  { perm: 'reports.access', label: 'View reports', to: '/reports', icon: Icon.reports, roles: ['super_admin', 'admin', 'principal', 'accountant'] },
];

/* Same colour tokens used across Classes/Subjects/Exams: a light-100
 * tint behind the icon, the matching -600 both on the icon and on the
 * value text, icon at opacity-45. "primary" maps to the tenant's own
 * theme colour instead of a fixed blue. */
const KPI_COLORS = {
  primary: { bg: 'bg-primary-15', text: 'text-primary' },
  indigo: { bg: 'bg-indigo-100', text: 'text-indigo-600' },
  purple: { bg: 'bg-purple-100', text: 'text-purple-600' },
  green: { bg: 'bg-green-100', text: 'text-green-600' },
  amber: { bg: 'bg-amber-100', text: 'text-amber-600' },
  red: { bg: 'bg-red-100', text: 'text-red-600' },
};

/** Stat card — matches the established pattern from ClassList/SubjectList/
 * ExamList: label + coloured value on the left, a tinted icon box on the
 * right, same card shell (bg-white p-5 rounded shadow). */
function Kpi({ label, value, sub, color = 'primary', icon: IconCmp, to }) {
  const c = KPI_COLORS[color] || KPI_COLORS.primary;
  return (
    <Link to={to} className="bg-white p-5 rounded shadow hover:shadow-md transition-shadow block">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="text-sm text-left text-gray-600">{label}</p>
          <p className={`text-2xl text-left font-bold mt-1 ${c.text}`}>{value}</p>
          {sub && <p className="text-xs text-left text-gray-400 mt-0.5">{sub}</p>}
        </div>
        <div className={`${c.bg} p-3 rounded flex-shrink-0`}>
          <IconCmp className={`w-8 h-8 ${c.text} opacity-45`} />
        </div>
      </div>
    </Link>
  );
}

/** One row of the "This year" snapshot list — label / value pair with a
 * hairline underneath instead of its own card, so related figures read
 * as one grouped summary rather than separate unrelated tiles. */
function SnapshotRow({ icon: IconCmp, label, value, sub, to }) {
  return (
    <Link to={to} className="flex items-center gap-4 py-3.5 px-1 hover:bg-gray-50 transition-colors group">
      <div className="w-9 h-9 rounded bg-primary-10 text-primary flex items-center justify-center flex-shrink-0">
        <IconCmp className="w-4 h-4" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm text-gray-700">{label}</p>
        {sub && <p className="text-xs text-gray-400 mt-0.5 truncate">{sub}</p>}
      </div>
      <p className="text-base font-semibold text-gray-900 flex-shrink-0">{value}</p>
      <Icon.chevron className="w-4 h-4 text-gray-300 group-hover:text-gray-400 flex-shrink-0" />
    </Link>
  );
}

/** One line of "Today's Highlights" — a real business event in plain
 * language, not an HTTP method and a path. */
function Highlight({ icon: IconCmp, text, sub, to, tone }) {
  const dotClass = tone === 'amber' ? 'bg-amber-500' : tone === 'red' ? 'bg-red-500' : 'bg-primary';
  const Wrapper = to ? Link : 'div';
  return (
    <Wrapper to={to} className={`flex items-start gap-3 py-2.5 ${to ? 'hover:bg-gray-50 -mx-1 px-1 rounded transition-colors' : ''}`}>
      <div className="w-7 h-7 rounded-full bg-primary-10 text-primary flex items-center justify-center flex-shrink-0 mt-0.5">
        <IconCmp className="w-3.5 h-3.5" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm text-gray-700 leading-snug">{text}</p>
        {sub && <p className="text-xs text-gray-400 mt-0.5">{sub}</p>}
      </div>
      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 mt-1.5 ${dotClass}`} />
    </Wrapper>
  );
}

export default function Dashboard() {
  const { user, isAuthenticated, can } = useAuth();
  const { formatMoney, formatDate } = usePreferences();
  const { currentAcademicYear } = useAcademicYear();
  const { currentCampus } = useCampus();
  const { showError } = useToast();

  // Statistics need the analytics permission too — holding the full Dashboard alone must not
  // trigger requests that would only come back as errors.
  const canSeeStats = Array.isArray(user?.effective_permissions) ? can('analytics.view') : STATS_ROLES.includes(user?.role);

  const [data, setData] = useState(null);
  const [loadingStats, setLoadingStats] = useState(canSeeStats);
  const [terms, setTerms] = useState(null);
  const [highlights, setHighlights] = useState(null);

  useEffect(() => {
    if (!canSeeStats) return;
    setLoadingStats(true);
    analyticsService.getDashboard({ academic_year: currentAcademicYear })
      .then((res) => { if (res.success) setData(res.data); })
      .catch((err) => showError(err.response?.data?.message || err.message))
      .finally(() => setLoadingStats(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentAcademicYear, canSeeStats]);

  useEffect(() => {
    settingsService.getOverview()
      .then((res) => { if (res.success) setTerms(res.data.terms || []); })
      .catch(() => { /* the calendar panel just won't render */ });
  }, []);

  useEffect(() => {
    if (!canSeeStats) return;
    analyticsService.getHighlights()
      .then((res) => { if (res.success) setHighlights(res.data); })
      .catch(() => { /* the highlights panel just won't render */ });
  }, [canSeeStats]);

  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  // A shortcut shows only if the person may actually do what it does.
  const quickActions = QUICK_ACTIONS.filter((a) => (Array.isArray(user?.effective_permissions) ? can(a.perm) : a.roles.includes(user?.role)));

  const today = new Date().toISOString().slice(0, 10);
  const sortedTerms = [...(terms || [])]
    .filter((t) => t.start_date && t.end_date)
    .sort((a, b) => a.start_date.localeCompare(b.start_date));
  const currentTermIndex = sortedTerms.findIndex((t) => t.start_date <= today && t.end_date >= today);
  const currentTerm = currentTermIndex >= 0 ? sortedTerms[currentTermIndex] : null;
  const nextTerm = sortedTerms.find((t) => t.start_date > today);

  let termProgress = null;
  let dayOfTerm = null;
  let totalTermDays = null;
  let daysLeftInTerm = null;
  if (currentTerm) {
    const start = new Date(currentTerm.start_date);
    const end = new Date(currentTerm.end_date);
    const now = new Date(today);
    totalTermDays = Math.round((end - start) / 86400000) + 1;
    dayOfTerm = Math.min(totalTermDays, Math.round((now - start) / 86400000) + 1);
    daysLeftInTerm = Math.max(0, Math.round((end - now) / 86400000));
    termProgress = Math.min(100, Math.max(0, Math.round((dayOfTerm / totalTermDays) * 100)));
  }

  const { overview, academic, financial } = data || {};

  // Build the highlights list only from real, non-empty signals — an
  // empty section beats a padded one with nothing to say.
  const highlightItems = [];
  if (highlights) {
    if (highlights.fees_today.count > 0) {
      highlightItems.push({
        icon: Icon.cash,
        text: `${formatMoney(highlights.fees_today.amount)} collected today`,
        sub: `${highlights.fees_today.count} payment${highlights.fees_today.count === 1 ? '' : 's'}`,
        to: '/fees/status',
      });
    }
    if (highlights.attendance_today.marked > 0) {
      highlightItems.push({
        icon: Icon.students,
        text: `${highlights.attendance_today.absent} student${highlights.attendance_today.absent === 1 ? '' : 's'} absent today`,
        sub: `of ${highlights.attendance_today.marked} marked so far`,
        to: '/attendance',
        tone: highlights.attendance_today.absent > 0 ? 'amber' : undefined,
      });
    }
    if (highlights.staff_on_leave_today > 0) {
      highlightItems.push({
        icon: Icon.leave,
        text: `${highlights.staff_on_leave_today} staff on approved leave today`,
        to: '/leave/approvals',
        tone: 'amber',
      });
    }
    if (highlights.admissions_today > 0) {
      highlightItems.push({
        icon: Icon.addUser,
        text: `${highlights.admissions_today} new admission${highlights.admissions_today === 1 ? '' : 's'} today`,
        to: '/students',
      });
    }
    for (const exam of highlights.recent_exams || []) {
      highlightItems.push({
        icon: Icon.exam,
        text: `Exam scheduled: ${exam.name}`,
        sub: exam.start_date ? `Starts ${formatDate(exam.start_date)}` : undefined,
        to: '/exams',
      });
    }
    for (const notice of highlights.recent_notices || []) {
      highlightItems.push({
        icon: Icon.bell,
        text: `Notice sent: ${notice.subject || notice.recipient_summary || 'Message'}`,
        sub: notice.recipient_summary,
        to: '/messages/history',
      });
    }
  }

  return (
    <MainLayout>
      <div className="space-y-5">
        {/* Header — plain text, no colour block. The number is the hero
            everywhere else on this page; this row just orients the person. */}
        <div className="page-header flex items-end justify-between flex-wrap gap-2">
          <div className="text-left">
            <h1 className="text-lg font-semibold text-gray-900">{greeting()}, {user?.first_name}</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {currentCampus?.name ? `Here's today's overview for ${currentCampus.name}.` : "Here's today's overview."}
            </p>
          </div>
          <p className="text-sm text-gray-400">{formatDate(new Date())}</p>
        </div>

        {/* Stat cards — admin/principal only. Same shell and icon
            treatment as Classes/Subjects/Exams: value + icon coloured
            together, icon boxed on the right at opacity-45. */}
        {canSeeStats && (
          loadingStats ? (
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              {[0, 1, 2, 3, 4].map((i) => <div key={i} className="bg-white shadow rounded h-24 animate-pulse" />)}
            </div>
          ) : overview ? (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Daily records — today's figures, not head-counts (those live on the Students / Staff pages). */}
              <Kpi
                label="Present Today"
                value={highlights ? highlights.attendance_today.present?.toLocaleString() ?? '—' : '…'}
                sub={highlights ? (highlights.attendance_today.marked > 0 ? `of ${highlights.attendance_today.marked} marked` : 'Attendance not marked yet') : undefined}
                icon={Icon.students}
                color="primary"
                to="/attendance"
              />
              <Kpi
                label="Collected Today"
                value={highlights ? formatMoney(highlights.fees_today.amount) : '…'}
                sub={highlights ? `${highlights.fees_today.count} payment${highlights.fees_today.count === 1 ? '' : 's'}` : undefined}
                icon={Icon.cash}
                color="green"
                to="/fees/status"
              />
              {/* <Kpi label="Active Classes" value={overview.total_classes.toLocaleString()} icon={Icon.classes} color="purple" to="/classes" /> */}
              <Kpi
                label="Attendance, 30 Days"
                value={academic.attendance_rate_30d !== null ? `${academic.attendance_rate_30d}%` : '—'}
                icon={Icon.checklist}
                color={academic.attendance_rate_30d !== null && academic.attendance_rate_30d < 85 ? 'amber' : 'green'}
                to="/attendance"
              />
              <Kpi
                label="Pending Leave Requests"
                value={overview.pending_leave_requests}
                icon={Icon.leave}
                color={overview.pending_leave_requests > 0 ? 'amber' : 'green'}
                to="/leave/approvals"
              />
            </div>
          ) : null
        )}

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
          {/* This term — enriched with day-count and a term-by-term strip,
              not just a name and a bar. */}
          <div className="lg:col-span-2 bg-white shadow rounded p-5 text-left">
            <h2 className="text-sm font-semibold text-gray-700 mb-3">This term</h2>
            {terms === null ? (
              <div className="h-32 animate-pulse bg-gray-100 rounded" />
            ) : sortedTerms.length === 0 ? (
              <p className="text-sm text-gray-400">
                No terms set up yet.{' '}
                {can('settings.academic_year') && (
                  <Link to="/settings" className="text-primary hover:opacity-80">Add them in Settings</Link>
                )}
              </p>
            ) : currentTerm ? (
              <div>
                <div className="flex items-baseline justify-between">
                  <p className="text-xl font-semibold text-gray-900">{currentTerm.name}</p>
                  <p className="text-xs text-gray-400">{formatDate(currentTerm.start_date)} – {formatDate(currentTerm.end_date)}</p>
                </div>

                <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden mt-3">
                  <div className="h-full bg-primary rounded-full" style={{ width: `${termProgress}%` }} />
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2 mt-1.5">
                  <p className="text-xs text-gray-500">Day {dayOfTerm} of {totalTermDays}</p>
                  <p className="text-xs text-gray-500">{daysLeftInTerm} day{daysLeftInTerm === 1 ? '' : 's'} left</p>
                </div>

                {/* Term-by-term strip — every configured term this year,
                    so the single progress bar sits inside real context
                    instead of floating alone on the card. */}
                <div className="flex items-center gap-1.5 mt-4">
                  {sortedTerms.map((t, i) => (
                    <div key={t.name + t.start_date} className="flex-1 min-w-0">
                      <div
                        className={`h-1.5 rounded-full ${i < currentTermIndex ? 'bg-primary-40' : i === currentTermIndex ? 'bg-primary' : 'bg-gray-100'}`}
                        title={t.name}
                      />
                      <p className={`text-[11px] mt-1 truncate ${i === currentTermIndex ? 'text-gray-700 font-medium' : 'text-gray-400'}`}>{t.name}</p>
                    </div>
                  ))}
                </div>

                {nextTerm && (
                  <p className="text-xs text-gray-400 mt-3">Next: {nextTerm.name}, from {formatDate(nextTerm.start_date)}</p>
                )}
              </div>
            ) : nextTerm ? (
              <div>
                <p className="text-xs text-gray-500">Upcoming</p>
                <p className="text-xl font-semibold text-gray-900">{nextTerm.name}</p>
                <p className="text-xs text-gray-400 mt-0.5">Starts {formatDate(nextTerm.start_date)}</p>
              </div>
            ) : (
              <p className="text-sm text-gray-400">No current or upcoming term on the calendar.</p>
            )}
          </div>

          {/* Today's Highlights — real business events, not raw audit
              log entries. Admin/principal only, since the underlying
              figures come from the same restricted endpoint. */}
          {canSeeStats && (
            <div className="lg:col-span-2 bg-white shadow rounded p-5 text-left">
              <h2 className="text-sm font-semibold text-gray-700 mb-1">Today's highlights</h2>
              {highlights === null ? (
                <div className="space-y-2.5 mt-2">
                  {[0, 1, 2].map((i) => <div key={i} className="h-9 animate-pulse bg-gray-100 rounded" />)}
                </div>
              ) : highlightItems.length === 0 ? (
                <p className="text-sm text-gray-400 py-6 text-center">Nothing notable yet today.</p>
              ) : (
                <div className="divide-y divide-gray-100">
                  {highlightItems.map((h, i) => <Highlight key={i} {...h} />)}
                </div>
              )}
            </div>
          )}
        </div>

        {/* This year at a glance — financial picture: what came in, what
            went out, what's still owed, and how enrolment moved. Half the
            page, paired with the expense breakdown on the right so the
            row doesn't stretch edge-to-edge on its own. */}
        {canSeeStats && financial && overview && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="bg-white shadow rounded px-5 text-left divide-y divide-gray-100">
              <h2 className="text-sm font-semibold text-gray-700 pt-4 pb-1">This year at a glance</h2>
              <SnapshotRow
                icon={Icon.cash}
                label="Fee collection"
                value={formatMoney(financial.fees_collected_ytd)}
                sub={financial.fee_collection_rate !== null ? `${financial.fee_collection_rate}% of expected` : undefined}
                to="/fees/status"
              />
              <SnapshotRow
                icon={Icon.expense}
                label="Expenses"
                value={formatMoney(financial.expenses_ytd)}
                sub="Year to date"
                to="/expenses"
              />
              <SnapshotRow
                icon={Icon.debit}
                label="Outstanding fees"
                value={formatMoney(financial.fees_outstanding_ytd)}
                sub={financial.fee_collection_rate !== null ? `${(100 - financial.fee_collection_rate).toFixed(1)}% still owed` : undefined}
                to="/fees/status"
              />
              <SnapshotRow
                icon={Icon.addUser}
                label="Admissions"
                value={overview.admissions_ytd.toLocaleString()}
                sub="Year to date"
                to="/students"
              />
            </div>

            {/* Expenses by category — the natural companion to the
                summary on the left: where the money on the "Expenses"
                row actually went. Same data the Analytics page charts,
                shown here as a simple ranked list. */}
            <div className="bg-white shadow rounded p-5 text-left">
              <h2 className="text-sm font-semibold text-gray-700 mb-3">Expenses by category</h2>
              {(!financial.expense_by_category || financial.expense_by_category.length === 0) ? (
                <p className="text-sm text-gray-400 py-6 text-center">No expenses recorded yet this year.</p>
              ) : (
                <div className="space-y-3">
                  {[...financial.expense_by_category]
                    .sort((a, b) => b.total - a.total)
                    .slice(0, 5)
                    .map((cat) => {
                      const max = Math.max(...financial.expense_by_category.map((c) => c.total));
                      const pct = max > 0 ? Math.round((cat.total / max) * 100) : 0;
                      return (
                        <div key={cat.category}>
                          <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                            <p className="text-sm text-gray-700">{cat.category}</p>
                            <p className="text-sm font-semibold text-gray-900">{formatMoney(cat.total)}</p>
                          </div>
                          <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                            <div className="h-full bg-primary rounded-full" style={{ width: `${pct}%` }} />
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Shortcuts — filtered to what this person's role can actually do */}
        {quickActions.length > 0 && (
          <div className="bg-white shadow rounded p-5 text-left">
            <h2 className="text-sm font-semibold text-gray-700 mb-3">Shortcuts</h2>
            <div className="flex flex-wrap gap-2">
              {quickActions.map((action) => (
                <Link
                  key={action.label}
                  to={action.to}
                  className="flex items-center gap-2 px-3.5 py-2 rounded border border-gray-200 text-sm text-gray-700 hover:border-primary hover:text-primary transition-colors"
                >
                  <action.icon className="w-4 h-4" />
                  {action.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}