import { useEffect, useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { authService } from "../services/api";
import { Input, Button } from "../components/ui";
import { isStrongPassword, passwordChecks } from "../utils/passwordRules";
import BrandMark from "../components/BrandMark";

const RESEND_SECONDS = 60;

/**
 * Reset your own password with a 6-digit code — no administrator needed. Where the
 * code goes is the school's choice (Settings → Notifications): email, SMS or either,
 * and this page asks only for what that allows. Two steps on one page:
 *   1. say who you are (email or phone number) → a code is sent;
 *   2. enter the code and a new password.
 * What the server answers never depends on whether the account exists, so this
 * page can't be used to find out who has one — and neither does it say where
 * the code went.
 */
export default function ForgotPassword() {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [identifier, setIdentifier] = useState("");
  const [form, setForm] = useState({ code: "", new_password: "", confirm_password: "" });
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  // 'email' | 'sms' | 'either' — what this school sends codes by. Until it is known
  // nothing is asked, so a phone number is never requested of an email-only school.
  const [mode, setMode] = useState(null);

  useEffect(() => {
    authService.forgotPasswordOptions()
      .then((res) => setMode(res.data?.mode || "either"))
      .catch(() => setMode("either"));
  }, []);

  useEffect(() => {
    if (cooldown <= 0) return undefined;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  if (isAuthenticated) return <Navigate to="/dashboard" replace />;

  const ASK = {
    email: { label: "Email address", type: "email", autoComplete: "email", placeholder: "you@school.co.tz",
      intro: "Enter the email address on your account. We'll email you a 6-digit code so you can choose a new password.",
      hint: "The code is emailed to the address on your account. A student's code is emailed to their parent. If nothing arrives, check your spam folder or ask your school's office." },
    sms: { label: "Phone number", type: "tel", autoComplete: "tel", placeholder: "255712345678",
      intro: "Enter the phone number on your account. We'll text you a 6-digit code so you can choose a new password.",
      hint: "The code is sent by SMS to the number on your account. If nothing arrives, ask your school's office." },
    either: { label: "Email or phone number", type: "text", autoComplete: "username", placeholder: "you@school.co.tz or 255712345678",
      intro: "Enter the email address or phone number on your account. We'll send you a 6-digit code so you can choose a new password.",
      hint: "The code is sent to the email and/or phone on your account. A student's code goes to their parent. If nothing arrives, check your spam folder or ask your school's office." },
  }[mode || "either"];

  const set = (field) => (e) => { setForm((f) => ({ ...f, [field]: e.target.value })); setError(""); };

  const sendCode = async (e) => {
    e?.preventDefault();
    if (!identifier.trim() || busy) return;
    try {
      setBusy(true); setError(""); setInfo("");
      const res = await authService.forgotPassword(identifier.trim());
      setInfo(res.message);
      setStep(2);
      setCooldown(RESEND_SECONDS);
    } catch (err) {
      setError(err.message || "Could not send the code. Please try again.");
    } finally { setBusy(false); }
  };

  const checks = [
    { ok: /^\d{6}$/.test(form.code.trim()), label: "The 6-digit code" },
    ...passwordChecks(form.new_password),
    { ok: form.confirm_password.length > 0 && form.new_password === form.confirm_password, label: "Both new passwords match" },
  ];
  const ready = isStrongPassword(form.new_password) && checks.every((c) => c.ok);

  const resetPassword = async (e) => {
    e.preventDefault();
    if (!ready || busy) return;
    try {
      setBusy(true); setError("");
      const res = await authService.resetPassword({ identifier: identifier.trim(), code: form.code.trim(), new_password: form.new_password });
      if (res.success) {
        try { sessionStorage.setItem("loginNotice", "Your password has been reset. Please sign in with your new password."); } catch { /* ignore */ }
        navigate("/login", { replace: true });
      }
    } catch (err) {
      setError(err.message || "Could not reset the password. Please try again.");
    } finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4 py-8">
      <div className="max-w-md w-full bg-white rounded shadow-lg overflow-hidden">
        <div className="gradient-primary-dark px-8 py-6 text-center">
          <BrandMark className="w-16 h-auto mx-auto mb-2" />
          <h1 className="text-xl font-bold tracking-tight text-white">Forgot your password?</h1>
          <p className="text-sm text-white opacity-80 mt-0.5">EduTrack</p>
        </div>

        <div className="p-8 space-y-4 text-left">
          {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded" role="alert">{error}</div>}

          {mode === null ? (
            <div className="py-8 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
          ) : step === 1 ? (
            <form onSubmit={sendCode} className="space-y-4">
              <p className="text-sm text-gray-700 leading-relaxed">{ASK.intro}</p>
              <Input
                label={ASK.label} type={ASK.type} required autoComplete={ASK.autoComplete} autoFocus
                value={identifier} onChange={(e) => { setIdentifier(e.target.value); setError(""); }}
                placeholder={ASK.placeholder}
              />
              <Button type="submit" loading={busy} disabled={!identifier.trim()} className="w-full">Send code</Button>
              <p className="text-xs text-gray-500">{ASK.hint}</p>
            </form>
          ) : (
            <form onSubmit={resetPassword} className="space-y-4">
              {info && <div className="bg-green-50 border border-green-200 text-green-700 text-sm px-4 py-3 rounded" role="status">{info}</div>}
              <Input
                label="6-digit code" required inputMode="numeric" autoComplete="one-time-code" maxLength={6} autoFocus
                value={form.code} onChange={set("code")}
              />
              <Input label="New password" type="password" required autoComplete="new-password" value={form.new_password} onChange={set("new_password")} />
              <Input label="Confirm new password" type="password" required autoComplete="new-password" value={form.confirm_password} onChange={set("confirm_password")} />
              <ul className="text-xs space-y-1">
                {checks.map((c) => <li key={c.label} className={c.ok ? "text-green-700" : "text-gray-500"}>{c.ok ? "✓" : "○"} {c.label}</li>)}
              </ul>
              <Button type="submit" loading={busy} disabled={!ready} className="w-full">Reset password</Button>
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <button type="button" disabled={cooldown > 0 || busy} onClick={sendCode} className="text-primary hover:underline disabled:text-gray-400 disabled:no-underline">
                  {cooldown > 0 ? `Send a new code in ${cooldown}s` : "Send a new code"}
                </button>
                <button type="button" onClick={() => { setStep(1); setError(""); setInfo(""); }} className="text-gray-500 hover:text-gray-700 underline">Use a different one</button>
              </div>
            </form>
          )}

          <div className="text-center pt-2 border-t border-gray-100">
            <Link to="/login" className="text-sm text-primary hover:underline">← Back to sign in</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
