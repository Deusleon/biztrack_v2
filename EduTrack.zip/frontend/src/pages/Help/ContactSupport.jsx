import { useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import MainLayout from "../../components/MainLayout";
import { Button, Input, Select, Textarea } from "../../components/ui";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { COMPANY } from "../../constants/company";

const TOPICS = [
  { value: "question", label: "A question about how to do something" },
  { value: "problem", label: "Something isn't working" },
  { value: "messaging", label: "SMS / messaging" },
  { value: "billing", label: "Subscription or billing" },
  { value: "feature", label: "A feature request" },
  { value: "other", label: "Something else" },
];

const MAX_MESSAGE = 1500; // keeps the email link within what mail apps accept
const MAILTO_LIMIT = 1900;

export default function ContactSupport() {
  const { user } = useAuth();
  const { showSuccess, showError } = useToast();
  const [params] = useSearchParams();
  // The page the person was on when they asked for help, so we can find the problem.
  const from = params.get("from") || "";

  const [topic, setTopic] = useState("question");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [includeDetails, setIncludeDetails] = useState(true);

  const topicLabel = TOPICS.find((t) => t.value === topic)?.label;

  const details = useMemo(() => {
    if (!includeDetails) return "";
    return [
      "— Details (added automatically) —",
      `Name: ${[user?.first_name, user?.last_name].filter(Boolean).join(" ") || "—"}`,
      `Email: ${user?.email || "—"}`,
      `Role: ${user?.role || "—"}`,
      `School ID: ${user?.tenant_id || "—"}`,
      from && `Page: ${from}`,
      `Browser: ${typeof navigator !== "undefined" ? navigator.userAgent : "—"}`,
      `Time: ${new Date().toISOString()}`,
    ].filter(Boolean).join("\n");
  }, [includeDetails, user, from]);

  const fullSubject = `[${COMPANY.productName}] ${subject.trim() || topicLabel}`;
  const fullBody = `${message.trim()}${details ? `\n\n${details}` : ""}`;
  const mailto = `mailto:${COMPANY.supportEmail}?subject=${encodeURIComponent(fullSubject)}&body=${encodeURIComponent(fullBody)}`;
  const tooLong = mailto.length > MAILTO_LIMIT;

  const validate = () => {
    if (!message.trim()) { showError("Please write your message first"); return false; }
    return true;
  };

  const handleSend = () => {
    if (!validate()) return;
    if (tooLong) { showError("That's too long for an email link — use “Copy message” and paste it into an email instead."); return; }
    window.location.href = mailto;
  };

  const handleCopy = async () => {
    if (!validate()) return;
    try {
      await navigator.clipboard.writeText(`To: ${COMPANY.supportEmail}\nSubject: ${fullSubject}\n\n${fullBody}`);
      showSuccess("Copied — paste it into an email to support");
    } catch {
      showError("Couldn't copy automatically. Select the text and copy it by hand.");
    }
  };

  return (
    <MainLayout>
      <div className="space-y-4 text-left">
        <div>
          <p className="text-xs text-gray-500"><Link to="/help" className="hover:text-primary">Help Center</Link> › Contact support</p>
          <h1 className="text-xl font-bold text-gray-900 mt-1">Contact support</h1>
          <p className="text-sm text-gray-500 mt-0.5">Tell us what you need and we'll help.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-white p-5 rounded shadow space-y-4">
            <Select label="What is it about?" value={topic} onChange={(e) => setTopic(e.target.value)} options={TOPICS} />
            <Input label="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="A few words — e.g. SMS to parents not delivered" />
            <Textarea
              label="Message"
              required
              rows={7}
              maxLength={MAX_MESSAGE}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="What were you trying to do, what happened, and what did you expect? Names of the page or student/class involved help us."
              helperText={`${message.length}/${MAX_MESSAGE}`}
            />

            <label className="flex items-start gap-2 text-sm text-gray-700 cursor-pointer">
              <input type="checkbox" checked={includeDetails} onChange={(e) => setIncludeDetails(e.target.checked)} className="accent-primary mt-0.5" />
              <span>
                Include my name, email, role and the page I came from, so support can find the problem faster.
                <span className="block text-xs text-gray-500">No passwords or school data are added.</span>
              </span>
            </label>

            {includeDetails && (
              <pre className="text-xs text-gray-500 bg-gray-50 border border-gray-200 rounded p-3 whitespace-pre-wrap break-words">{details}</pre>
            )}

            <div className="flex flex-wrap items-center gap-3">
              <Button onClick={handleSend}>Send by email</Button>
              <Button variant="secondary" onClick={handleCopy}>Copy message</Button>
            </div>
            <p className="text-xs text-gray-500">
              “Send by email” opens your email app with this message ready to go. If nothing opens, use “Copy message” and email it to{" "}
              <a href={`mailto:${COMPANY.supportEmail}`} className="text-primary hover:underline">{COMPANY.supportEmail}</a>.
            </p>
          </div>

          <div className="space-y-4">
            <div className="bg-white p-5 rounded shadow">
              <h2 className="text-sm font-semibold text-gray-800 mb-2">Reach us directly</h2>
              <ul className="text-sm text-gray-700 space-y-2">
                <li><span className="text-gray-500">Email</span><br /><a href={`mailto:${COMPANY.supportEmail}`} className="text-primary hover:underline break-all">{COMPANY.supportEmail}</a></li>
                {COMPANY.supportPhone && <li><span className="text-gray-500">Phone</span><br /><a href={`tel:${COMPANY.supportPhone.replace(/\s+/g, "")}`} className="text-primary hover:underline">{COMPANY.supportPhone}</a></li>}
                {COMPANY.supportWhatsapp && <li><span className="text-gray-500">WhatsApp</span><br /><a href={`https://wa.me/${COMPANY.supportWhatsapp.replace(/\D/g, "")}`} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Chat on WhatsApp</a></li>}
              </ul>
            </div>
            <div className="bg-white p-5 rounded shadow">
              <h2 className="text-sm font-semibold text-gray-800 mb-2">Before you write</h2>
              <ul className="text-xs text-gray-500 space-y-1.5 list-disc pl-4">
                <li>Try the <Link to="/help" className="text-primary hover:underline">Help Center</Link> — many questions are answered there.</li>
                <li>Say what you did, what you saw, and what you expected.</li>
                <li>For messages that didn't arrive, open the message in Messages → History and include what it says next to the recipient.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
