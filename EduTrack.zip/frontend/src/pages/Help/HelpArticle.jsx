import { useEffect } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import MainLayout from "../../components/MainLayout";
import { ActionLink } from "../../components/ui";
import DocContent from "../../components/docs/DocContent";
import { HELP_ARTICLES, HELP_CATEGORIES, findArticle } from "../../content/helpArticles";
import { SupportCallout } from "./HelpCenter";
import Icon from "../../components/ui/Icon";

export default function HelpArticle() {
  const { slug } = useParams();
  const { hash } = useLocation();
  const article = findArticle(slug);

  // /help/messaging#delivery should land on that section.
  useEffect(() => {
    if (!article) return;
    if (hash) document.getElementById(hash.slice(1))?.scrollIntoView({ behavior: "smooth", block: "start" });
    else window.scrollTo({ top: 0 });
  }, [slug, hash, article]);

  if (!article) {
    return (
      <MainLayout>
        <div className="bg-white p-8 rounded shadow text-center space-y-3">
          <h1 className="text-lg font-semibold text-gray-900">We couldn't find that help page</h1>
          <p className="text-sm text-gray-600">It may have been renamed or removed.</p>
          <ActionLink to="/help" variant="primary">Back to the Help Center</ActionLink>
        </div>
      </MainLayout>
    );
  }

  const category = HELP_CATEGORIES.find((c) => c.id === article.category);
  const related = (article.related || []).map(findArticle).filter(Boolean);

  return (
    <MainLayout>
      <div className="grid grid-cols-1 lg:grid-cols-[16rem_minmax(0,1fr)] gap-4 text-left">
        {/* Other articles, grouped like the Help Center home */}
        <nav aria-label="Help topics" className="bg-white rounded shadow p-4 h-fit lg:sticky lg:top-20">
          <Link to="/help" className="text-xs text-gray-500 hover:text-primary">All help topics</Link>
          <div className="mt-3 space-y-4">
            {HELP_CATEGORIES.map((c) => {
              const items = HELP_ARTICLES.filter((a) => a.category === c.id);
              if (items.length === 0) return null;
              return (
                <div key={c.id}>
                  <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{c.label}</p>
                  <ul>
                    {items.map((a) => (
                      <li key={a.slug}>
                        <Link
                          to={`/help/${a.slug}`}
                          className={`block text-sm py-1 ${a.slug === slug ? "text-primary font-medium" : "text-gray-600 hover:text-gray-900"}`}
                        >
                          {a.title}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </nav>

        <div className="space-y-4 min-w-0 mt-2">
          <article className="bg-white rounded shadow p-5">
            <p className="text-xs text-gray-500"><Link to="/help" className="hover:text-primary">Help Center</Link> › {category?.label}</p>
            <h1 className="text-xl font-bold text-gray-900 mt-1">{article.title}</h1>
            <p className="text-sm text-gray-500 mt-1">{article.summary}</p>

            {article.sections.length > 2 && (
              <div className="mt-4 bg-gray-50 border border-gray-200 rounded px-4 py-3">
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">On this page</p>
                <ul className="text-sm space-y-0.5">
                  {article.sections.map((s) => (
                    <li key={s.id}><a href={`#${s.id}`} className="text-primary hover:underline">{s.heading}</a></li>
                  ))}
                </ul>
              </div>
            )}

            <div className="mt-6"><DocContent sections={article.sections} /></div>

            {related.length > 0 && (
              <div className="mt-8 pt-4 border-t border-gray-100">
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Related</p>
                <ul className="text-sm space-y-0.5">
                  {related.map((a) => <li key={a.slug}><Link to={`/help/${a.slug}`} className="text-primary hover:underline">{a.title}</Link></li>)}
                </ul>
              </div>
            )}
          </article>

          <SupportCallout from={`/help/${slug}`} />
        </div>
      </div>
    </MainLayout>
  );
}
