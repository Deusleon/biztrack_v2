import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import MainLayout from "../../components/MainLayout";
import { Input } from "../../components/ui";
import { HELP_ARTICLES, HELP_CATEGORIES, searchArticles } from "../../content/helpArticles";

export function SupportCallout({ from }) {
  return (
    <div className="bg-white p-5 rounded shadow text-left flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
      <div>
        <h3 className="text-sm font-semibold text-gray-900">Still need help?</h3>
        <p className="text-sm text-gray-500 mt-0.5">Tell us what happened and we'll get back to you.</p>
      </div>
      <Link
        to={from ? `/help/contact?from=${encodeURIComponent(from)}` : "/help/contact"}
        className="bg-primary text-sm text-white px-5 py-2.5 rounded hover:opacity-90 text-center whitespace-nowrap"
      >
        Contact support
      </Link>
    </div>
  );
}

export default function HelpCenter() {
  const [query, setQuery] = useState("");
  const results = useMemo(() => searchArticles(query), [query]);
  const searching = query.trim().length > 0;

  return (
    <MainLayout>
      <div className="space-y-4 text-left">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Help Center</h1>
          <p className="text-sm text-gray-500 mt-0.5">Guides for everyday tasks in EduTrack</p>
        </div>

        <div className="bg-white p-5 rounded shadow">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search the help center — e.g. top up, template, role, bulk upload…"
          />
        </div>

        {searching ? (
          <div className="bg-white rounded shadow divide-y divide-gray-100">
            {results.length === 0 ? (
              <div className="p-5 text-sm text-gray-600">
                Nothing found for “{query}”. Try fewer or different words, or <Link to="/help/contact" className="text-primary hover:underline">contact support</Link>.
              </div>
            ) : results.map((a) => (
              <Link key={a.slug} to={`/help/${a.slug}`} className="block px-5 py-4 hover:bg-gray-50">
                <p className="text-sm font-medium text-gray-900">{a.title}</p>
                <p className="text-xs text-gray-500 mt-0.5">{a.summary}</p>
                <p className="text-xs text-gray-400 mt-1">{HELP_CATEGORIES.find((c) => c.id === a.category)?.label}</p>
              </Link>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {HELP_CATEGORIES.map((category) => {
              const articles = HELP_ARTICLES.filter((a) => a.category === category.id);
              if (articles.length === 0) return null;
              return (
                <div key={category.id} className="bg-white rounded shadow">
                  <h2 className="px-5 py-3 text-sm font-semibold text-gray-800 border-b border-gray-100">{category.label}</h2>
                  <ul className="divide-y divide-gray-100">
                    {articles.map((a) => (
                      <li key={a.slug}>
                        <Link to={`/help/${a.slug}`} className="block px-5 py-3 hover:bg-gray-50">
                          <p className="text-sm text-primary">{a.title}</p>
                          <p className="text-xs text-gray-500 mt-0.5">{a.summary}</p>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        )}

        <SupportCallout />
      </div>
    </MainLayout>
  );
}
