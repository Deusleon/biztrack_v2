import MainLayout from "../../components/MainLayout";

// The manual is a static PDF in /public/docs, so it is served as-is with no
// API call. BASE_URL keeps the link right if the app is hosted in a sub-folder.
const MANUAL_URL = `${import.meta.env.BASE_URL}docs/EduTrack_User_Manual.pdf`.replace(/\/{2,}/g, "/");
const FILE_NAME = "EduTrack_User_Manual.pdf";

export default function UserManual() {
  return (
    <MainLayout>
      <div className="space-y-4 text-left">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-gray-900">User Manual</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              Step-by-step guide to every part of EduTrack. Read it here or download the PDF.
            </p>
          </div>
          <div className="flex gap-2">
            <a
              href={MANUAL_URL}
              download={FILE_NAME}
              className="bg-primary text-sm text-white px-5 py-2.5 rounded hover:opacity-90 flex items-center space-x-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              <span>Download PDF</span>
            </a>
            <a
              href={MANUAL_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="border border-gray-300 text-sm text-gray-700 px-5 py-2.5 rounded hover:bg-gray-50 flex items-center space-x-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
              <span>Open in new tab</span>
            </a>
          </div>
        </div>

        {/* Reader. Phones cannot show a PDF inside a page, so they get the two buttons above and this card instead. */}
        <div className="hidden md:block bg-white rounded shadow overflow-hidden">
          <iframe
            title="EduTrack User Manual"
            src={`${MANUAL_URL}#view=FitH`}
            className="w-full border-0"
            style={{ height: "calc(100vh - 13rem)", minHeight: 520 }}
          />
        </div>
        <div className="md:hidden bg-white rounded shadow p-5 text-sm text-gray-600">
          Your phone's browser opens PDFs in its own viewer. Tap <span className="font-medium text-gray-800">Open in new tab</span> to
          read the manual, or <span className="font-medium text-gray-800">Download PDF</span> to keep a copy.
        </div>

        <p className="text-xs text-gray-400">
          English · PDF · October 2026 Edition. If the reader above stays blank, use <span className="text-gray-500">Open in new tab</span>.
        </p>
      </div>
    </MainLayout>
  );
}
