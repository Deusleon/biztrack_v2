import MainLayout from "../../components/MainLayout";
import { useAuth } from "../../contexts/AuthContext";
import { guideFor } from "../../utils/userGuides";

// The guide is a static PDF in /public/docs/guides — one per role — so it is served
// as-is with no API call. Each person gets the guide written for their own role.
const DownloadIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
  </svg>
);

export default function UserGuide() {
  const { user } = useAuth();
  const guide = guideFor(user?.role);

  if (!guide) {
    return (
      <MainLayout>
        <div className="bg-white rounded shadow p-5 text-left space-y-2">
          <h1 className="text-xl font-bold text-gray-900">User Guide</h1>
          <p className="text-sm text-gray-600">There is no user guide for your role yet. Open Help from the footer for short articles, or contact support.</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4 text-left">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-gray-900">User Guide <span className="text-gray-400 font-normal">· {guide.label}</span></h1>
            <p className="text-sm text-gray-500 mt-0.5">
              Written for your role: step-by-step help for what you can do in EduTrack, and nothing you can't. Read it here or download the PDF.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <a href={guide.pdfUrl} download={guide.pdfName} className="bg-primary text-sm text-white px-5 py-2.5 rounded hover:opacity-90 flex items-center space-x-2">
              <DownloadIcon /><span>Download PDF</span>
            </a>
            <a href={guide.pdfUrl} target="_blank" rel="noopener noreferrer" className="border border-gray-300 text-sm text-gray-700 px-5 py-2.5 rounded hover:bg-gray-50 flex items-center space-x-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
              <span>Open in new tab</span>
            </a>
          </div>
        </div>

        {/* Reader. Phones cannot show a PDF inside a page, so they get the buttons above and this card instead. */}
        <div className="hidden md:block bg-white rounded shadow overflow-hidden">
          <iframe title={`EduTrack User Guide — ${guide.label}`} src={`${guide.pdfUrl}#view=FitH`} className="w-full border-0" style={{ height: "calc(100vh - 13rem)", minHeight: 520 }} />
        </div>
        <div className="md:hidden bg-white rounded shadow p-5 text-sm text-gray-600">
          Your phone's browser opens PDFs in its own viewer. Tap <span className="font-medium text-gray-800">Open in new tab</span> to read the guide,
          or <span className="font-medium text-gray-800">Download PDF</span> to keep a copy.
        </div>

        <p className="text-xs text-gray-400">
          English · PDF · October 2026 Edition. Your menu follows the permissions your school has given you, so it may differ slightly from the guide.
          If the reader above stays blank, use <span className="text-gray-500">Open in new tab</span>.
        </p>
      </div>
    </MainLayout>
  );
}
