import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { useCampus } from "../../contexts/CampusContext";
import { transportService, campusService, vehicleService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { Select, Input, PhoneInput, DataTable, ConfirmModal, Button, RowActions, ACTION_ICONS } from "../../components/ui";

export default function RouteList() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { currentCampusId } = useCampus();
  const { showSuccess, showError } = useToast();

  const [routes, setRoutes] = useState([]);
  const [campuses, setCampuses] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);

  const [filters, setFilters] = usePersistedState("filters", { search: "", status: "" });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 15 });

  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({ name: "", route_number: "", vehicle_id: "", driver_name: "", driver_phone: "", vehicle_number: "", capacity: "", stops: [], campus_id: "", status: "active" });
  const [stopInput, setStopInput] = useState("");
  const [saving, setSaving] = useState(false);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false });

  useEffect(() => { fetchRoutes(); }, [filters, pagination.currentPage]);
  useEffect(() => { campusService.getAll({ limit: 100 }).then((res) => { if (res.success) { setCampuses(res.data); if (res.data.length === 1) setForm((f) => ({ ...f, campus_id: res.data[0].id })); } }); }, []);
  useEffect(() => { vehicleService.getAll({ limit: 200, status: "active" }).then((res) => { if (res.success) setVehicles(res.data); }); }, []);

  const fetchRoutes = async () => {
    try {
      setLoading(true);
      const res = await transportService.getRoutes({ ...filters, page: pagination.currentPage, limit: pagination.itemsPerPage });
      if (res.success) { setRoutes(res.data); setPagination((p) => ({ ...p, ...res.pagination })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((f) => ({ ...f, [name]: value }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const openCreate = () => {
    setForm({ name: "", route_number: "", vehicle_id: "", driver_name: "", driver_phone: "", vehicle_number: "", capacity: "", stops: [], campus_id: currentCampusId || campuses[0]?.id || "", status: "active" });
    setStopInput("");
    setModal({ isOpen: true, mode: "create" });
  };

  const openEdit = (r) => {
    setForm({ name: r.name, route_number: r.route_number || "", vehicle_id: r.vehicle_id || "", driver_name: r.driver_name || "", driver_phone: r.driver_phone || "", vehicle_number: r.vehicle_number || "", capacity: r.capacity || "", stops: r.stops || [], campus_id: r.campus_id, status: r.status });
    setStopInput("");
    setModal({ isOpen: true, mode: "edit", id: r.id });
  };

  const addStop = () => {
    const v = stopInput.trim();
    if (!v) return;
    setForm((f) => ({ ...f, stops: [...f.stops, v] }));
    setStopInput("");
  };
  const removeStop = (i) => setForm((f) => ({ ...f, stops: f.stops.filter((_, idx) => idx !== i) }));

  const handleSave = async () => {
    if (!form.name || !form.campus_id) { showError("Name and campus are required"); return; }
    try {
      setSaving(true);
      const payload = { ...form, capacity: form.capacity ? Number(form.capacity) : null };
      if (modal.mode === "edit") await transportService.updateRoute(modal.id, payload);
      else await transportService.createRoute(payload);
      showSuccess(modal.mode === "edit" ? "Route updated" : "Route created");
      setModal({ isOpen: false });
      fetchRoutes();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDelete = (r) => {
    setConfirmModal({ isOpen: true, id: r.id, title: "Delete Route", message: `Delete "${r.name}"? This can't be undone.` });
  };
  const confirmDelete = async () => {
    try {
      await transportService.deleteRoute(confirmModal.id);
      showSuccess("Route deleted");
      fetchRoutes();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmModal({ isOpen: false });
  };

  const totalCapacity = routes.reduce((sum, r) => sum + (r.capacity || 0), 0);
  const totalOccupancy = routes.reduce((sum, r) => sum + (r.occupancy || 0), 0);

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Transport Routes</h1>
            <p className="text-sm text-gray-500 mt-0.5">Manage bus routes, drivers, and student assignments</p>
          </div>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => navigate("/transport/vehicles")}>Vehicles</Button>
            {can("transport.create") && (
              <Button variant="primary" onClick={openCreate}>New Route</Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-5 rounded shadow">
            <p className="text-sm text-left text-gray-600">Routes</p>
            <p className="text-2xl text-left font-bold text-primary mt-1">{pagination.totalItems}</p>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <p className="text-sm text-left text-gray-600">Students on Transport (this page)</p>
            <p className="text-2xl text-left font-bold text-green-600 mt-1">{totalOccupancy}</p>
          </div>
          <div className="bg-white p-5 rounded shadow">
            <p className="text-sm text-left text-gray-600">Total Seats (this page)</p>
            <p className="text-2xl text-left font-bold text-gray-900 mt-1">{totalCapacity || "—"}</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded shadow">
          <form onSubmit={(e) => { e.preventDefault(); fetchRoutes(); }} className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <Input label="Search" name="search" value={filters.search} onChange={handleFilterChange} placeholder="Search by name, driver, vehicle…"
                leftIcon={<svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} />
            </div>
            <Select label="Status" name="status" value={filters.status} onChange={handleFilterChange} options={[{ value: "", label: "All Statuses" }, { value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }]} />
            <div className="flex items-end">
              <button type="submit" className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90">Apply Filters</button>
            </div>
          </form>
        </div>

        <DataTable
          columns={[
            {
              key: "name", label: "Route",
              render: (r) => (
                <div>
                  <p className="text-sm font-medium text-gray-900">{r.name}</p>
                  {r.route_number && <p className="text-xs text-gray-400">#{r.route_number}</p>}
                </div>
              ),
            },
            {
              key: "driver", label: "Driver / Vehicle",
              render: (r) => (
                <div>
                  <p className="text-sm text-gray-700">{r.driver_name || "—"}</p>
                  <p className="text-xs text-gray-400">{r.vehicle_number || ""}{r.driver_phone ? ` • ${r.driver_phone}` : ""}</p>
                </div>
              ),
            },
            {
              key: "occupancy", label: "Occupancy",
              render: (r) => (
                <span className={`text-sm font-medium ${r.capacity && r.occupancy >= r.capacity ? "text-red-600" : "text-gray-700"}`}>
                  {r.occupancy}{r.capacity ? ` / ${r.capacity}` : ""}
                </span>
              ),
            },
            { key: "status", label: "Status", render: (r) => <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${r.status === "active" ? "bg-green-100 border border-green-300 text-green-500" : "bg-red-100 border border-red-300 text-red-500"}`}>{r.status}</span> },
          ]}
          data={routes}
          loading={loading}
          emptyMessage="No routes found"
          renderActions={(r) => (
            <RowActions
              actions={[
                { label: 'Manage Students', variant: 'primary', icon: ACTION_ICONS.view, hidden: !can("transport.update"), onClick: () => navigate(`/transport/${r.id}/students`) },
                { label: 'Edit Route', icon: ACTION_ICONS.edit, hidden: !can("transport.update"), onClick: () => openEdit(r) },
                { label: 'Delete Route', variant: 'danger', icon: ACTION_ICONS.delete, hidden: !can("transport.delete"), onClick: () => handleDelete(r) },
              ]}
            />
          )}
          pagination={{ ...pagination, limit: pagination.itemsPerPage }}
          onPageChange={(page) => setPagination((p) => ({ ...p, currentPage: page }))}
        />
      </div>

      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Route" : "New Route"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Route Name" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Enter route name" />
                <Input label="Route Number" value={form.route_number} onChange={(e) => setForm((f) => ({ ...f, route_number: e.target.value }))} placeholder="Enter route number" />
              </div>

              <Select
                label="Vehicle" value={form.vehicle_id}
                onChange={(e) => {
                  const v = vehicles.find((vv) => vv.id === e.target.value);
                  setForm((f) => ({
                    ...f, vehicle_id: e.target.value,
                    driver_name: v ? (v.driver_name || f.driver_name) : f.driver_name,
                    driver_phone: v ? (v.driver_phone || f.driver_phone) : f.driver_phone,
                    vehicle_number: v ? v.registration_number : f.vehicle_number,
                  }));
                }}
                options={[{ value: "", label: "No vehicle linked — enter details manually below" }, ...vehicles.map((v) => ({ value: v.id, label: `${v.registration_number}${v.driver_name ? ` — ${v.driver_name}` : ""}` }))]}
                helperText={<>Manage the fleet under <button type="button" onClick={() => navigate("/transport/vehicles")} className="underline text-primary">Vehicles</button></>}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Driver Name" disabled={!!form.vehicle_id} value={form.driver_name} onChange={(e) => setForm((f) => ({ ...f, driver_name: e.target.value }))} />
                <PhoneInput label="Driver Phone" disabled={!!form.vehicle_id} value={form.driver_phone} onChange={(e) => setForm((f) => ({ ...f, driver_phone: e.target.value }))} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Vehicle Number" disabled={!!form.vehicle_id} value={form.vehicle_number} onChange={(e) => setForm((f) => ({ ...f, vehicle_number: e.target.value }))} placeholder="e.g. T123 ABC" />
                <Input label="Seat Capacity" type="number" min={1} value={form.capacity} onChange={(e) => setForm((f) => ({ ...f, capacity: e.target.value }))} placeholder="Optional" />
              </div>

              <div>
                <label className="text-xs text-left font-medium text-gray-700 block mb-1">Stops (in order)</label>
                <div className="space-y-1.5 mb-2">
                  {form.stops.map((s, i) => (
                    <div key={i} className="flex flex-wrap items-center justify-between gap-2 bg-gray-50 border border-gray-200 rounded px-3 py-1.5 text-sm">
                      <span className="text-gray-700">{i + 1}. {s}</span>
                      <button type="button" onClick={() => removeStop(i)} className="text-red-500 hover:text-red-700 text-xs">Remove</button>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    value={stopInput} onChange={(e) => setStopInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addStop(); } }}
                    placeholder="Stop name, then Enter" className="flex-1 border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-primary"
                  />
                  <Button type="button" variant="secondary" onClick={addStop}>Add</Button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {campuses.length > 1 && (
                  <Select label="Campus" required value={form.campus_id} onChange={(e) => setForm((f) => ({ ...f, campus_id: e.target.value }))}
                    options={[{ value: "", label: "Select campus…" }, ...campuses.map((c) => ({ value: c.id, label: c.name }))]} />
                )}
                <Select label="Status" value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}
                  options={[{ value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }]} />
              </div>

              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Create"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmModal.isOpen} title={confirmModal.title} message={confirmModal.message} variant="danger" onConfirm={confirmDelete} onClose={() => setConfirmModal({ isOpen: false })} />
    </MainLayout>
  );
}
