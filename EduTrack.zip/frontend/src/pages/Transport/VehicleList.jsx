import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { useCampus } from "../../contexts/CampusContext";
import { vehicleService, campusService } from "../../services/api";
import { usePersistedState } from "../../hooks/usePersistedState";
import MainLayout from "../../components/MainLayout";
import { Select, Input, PhoneInput, Button, DatePicker } from "../../components/ui";
import Icon from "../../components/ui/Icon";

const STATUS_STYLES = {
  active: "bg-green-100 border border-green-300 text-green-700",
  in_maintenance: "bg-amber-100 border border-amber-300 text-amber-700",
  inactive: "bg-gray-100 border border-gray-300 text-gray-600",
};

export default function VehicleList() {
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { currentCampusId } = useCampus();
  const { showSuccess, showError } = useToast();

  const [vehicles, setVehicles] = useState([]);
  const [campuses, setCampuses] = useState([]);
  const [loading, setLoading] = useState(true);

  const [filters, setFilters] = usePersistedState("filters", { search: "", status: "" });
  const [pagination, setPagination] = usePersistedState("pagination", { currentPage: 1, totalPages: 1, totalItems: 0, itemsPerPage: 12 });

  const [modal, setModal] = useState({ isOpen: false });
  const [form, setForm] = useState({ registration_number: "", make: "", model: "", year: "", capacity: "", description: "", driver_name: "", driver_phone: "", driver_license_number: "", insurance_expiry: "", inspection_expiry: "", campus_id: "", status: "active" });
  const [saving, setSaving] = useState(false);

  useEffect(() => { fetchVehicles(); }, [filters, pagination.currentPage]);
  useEffect(() => { campusService.getAll({ limit: 100 }).then((res) => { if (res.success) { setCampuses(res.data); if (res.data.length === 1) setForm((f) => ({ ...f, campus_id: res.data[0].id })); } }); }, []);

  const fetchVehicles = async () => {
    try {
      setLoading(true);
      const res = await vehicleService.getAll({ ...filters, page: pagination.currentPage, limit: pagination.itemsPerPage });
      if (res.success) { setVehicles(res.data); setPagination((p) => ({ ...p, ...res.pagination })); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((f) => ({ ...f, [name]: value }));
    setPagination((p) => ({ ...p, currentPage: 1 }));
  };

  const openCreate = () => {
    setForm({ registration_number: "", make: "", model: "", year: "", capacity: "", description: "", driver_name: "", driver_phone: "", driver_license_number: "", insurance_expiry: "", inspection_expiry: "", campus_id: currentCampusId || campuses[0]?.id || "", status: "active" });
    setModal({ isOpen: true, mode: "create" });
  };

  const handleSave = async () => {
    if (!form.registration_number || !form.campus_id) { showError("Registration number and campus are required"); return; }
    try {
      setSaving(true);
      const payload = { ...form, year: form.year ? Number(form.year) : null, capacity: form.capacity ? Number(form.capacity) : null };
      if (modal.mode === "edit") await vehicleService.update(modal.id, payload);
      else await vehicleService.create(payload);
      showSuccess(modal.mode === "edit" ? "Vehicle updated" : "Vehicle added");
      setModal({ isOpen: false });
      fetchVehicles();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">Vehicles</h1>
            <p className="text-sm text-gray-500 mt-0.5">The school's fleet — details, drivers, and service history</p>
          </div>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => navigate("/transport")}>Routes</Button>
            {can("transport.create") && (
              <Button variant="primary" onClick={openCreate}>New Vehicle</Button>
            )}
          </div>
        </div>

        <div className="bg-white p-5 rounded shadow">
          <form onSubmit={(e) => { e.preventDefault(); fetchVehicles(); }} className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <Input label="Search" name="search" value={filters.search} onChange={handleFilterChange} placeholder="Search by registration, make, driver…"
                leftIcon={<svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} />
            </div>
            <Select label="Status" name="status" value={filters.status} onChange={handleFilterChange}
              options={[{ value: "", label: "All Statuses" }, { value: "active", label: "Active" }, { value: "in_maintenance", label: "In Maintenance" }, { value: "inactive", label: "Inactive" }]} />
            <div className="flex items-end">
              <button type="submit" className="w-full bg-primary text-sm text-white px-4 py-[10.5px] rounded hover:opacity-90">Apply Filters</button>
            </div>
          </form>
        </div>

        {loading ? (
          <div className="bg-white p-16 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
        ) : vehicles.length === 0 ? (
          <div className="bg-white p-16 rounded shadow text-center text-gray-400 text-sm">No vehicles found.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {vehicles.map((v) => (
              <button key={v.id} onClick={() => navigate(`/transport/vehicles/${v.id}`)} className="bg-white rounded shadow overflow-hidden text-left hover:shadow-md transition-shadow">
                <div className="h-70 bg-gray-100 flex items-center justify-center overflow-hidden">
                  {v.photo_url ? (
                    <img src={v.photo_url} alt={v.registration_number} className="w-full h-full object-cover" />
                  ) : (
                    <svg className="w-12 h-12 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
                  )}
                </div>
                <div className="p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-gray-900">{v.registration_number}</p>
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${STATUS_STYLES[v.status]}`}>{v.status.replace("_", " ")}</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-0.5">{[v.make, v.model, v.year].filter(Boolean).join(" ") || "—"}</p>
                  {v.driver_name && <p className="text-xs text-gray-400 mt-1">Driver: {v.driver_name}</p>}
                  {v.routes?.length > 0 && <p className="text-xs text-primary mt-1">{v.routes.map((r) => r.name).join(", ")}</p>}
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {modal.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-lg">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">{modal.mode === "edit" ? "Edit Vehicle" : "New Vehicle"}</h3>
              <button onClick={() => setModal({ isOpen: false })} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Registration Number" required value={form.registration_number} onChange={(e) => setForm((f) => ({ ...f, registration_number: e.target.value }))} placeholder="Enter registration number" />
                <Input label="Seat Capacity" type="number" min={1} value={form.capacity} onChange={(e) => setForm((f) => ({ ...f, capacity: e.target.value }))} placeholder="Enter seat capacity" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input label="Make" value={form.make} onChange={(e) => setForm((f) => ({ ...f, make: e.target.value }))} placeholder="e.g. Toyota" />
                <Input label="Model" value={form.model} onChange={(e) => setForm((f) => ({ ...f, model: e.target.value }))} placeholder="e.g. Coaster" />
                <Input label="Year" type="number" value={form.year} onChange={(e) => setForm((f) => ({ ...f, year: e.target.value }))} placeholder="e.g. 2019" />
              </div>
              <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} placeholder="Optional notes about this vehicle" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Driver Name" value={form.driver_name} onChange={(e) => setForm((f) => ({ ...f, driver_name: e.target.value }))} placeholder="Enter driver name" />
                <PhoneInput label="Driver Phone" value={form.driver_phone} onChange={(e) => setForm((f) => ({ ...f, driver_phone: e.target.value }))} placeholder="Enter driver phone" />
              </div>
              <Input label="Driver License Number" value={form.driver_license_number} onChange={(e) => setForm((f) => ({ ...f, driver_license_number: e.target.value }))} placeholder="Enter driver license number" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <DatePicker label="Insurance Expiry" value={form.insurance_expiry} onChange={(e) => setForm((f) => ({ ...f, insurance_expiry: e.target.value }))} />
                <DatePicker label="Inspection Expiry" align="right" value={form.inspection_expiry} onChange={(e) => setForm((f) => ({ ...f, inspection_expiry: e.target.value }))} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {campuses.length > 1 && (
                  <Select label="Campus" required value={form.campus_id} onChange={(e) => setForm((f) => ({ ...f, campus_id: e.target.value }))}
                    options={[{ value: "", label: "Select campus…" }, ...campuses.map((c) => ({ value: c.id, label: c.name }))]} />
                )}
                <Select label="Status" value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}
                  options={[{ value: "active", label: "Active" }, { value: "in_maintenance", label: "In Maintenance" }, { value: "inactive", label: "Inactive" }]} />
              </div>
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>{modal.mode === "edit" ? "Update" : "Add Vehicle"}</Button>
                <Button type="button" variant="secondary" onClick={() => setModal({ isOpen: false })}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </MainLayout>
  );
}
