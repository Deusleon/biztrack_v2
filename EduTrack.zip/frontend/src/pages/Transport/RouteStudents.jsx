// frontend/src/pages/Transport/RouteStudents.jsx
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { transportService, classService, studentService } from "../../services/api";
import { useYearAwareClasses } from "../../hooks/useYearAwareClasses";
import MainLayout from "../../components/MainLayout";
import { Select, Input, NumberInput, Button, ConfirmModal, DataTable, RowActions, ACTION_ICONS } from "../../components/ui";
import { formatMoneyOrDash as formatMoney } from "../../utils/money";



export default function RouteStudents() {
  const { id: routeId } = useParams();
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();
  const { currentAcademicYear } = useAcademicYear();

  const [route, setRoute] = useState(null);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  const [assignModal, setAssignModal] = useState(false);
  const [sections, setSections] = useState([]);
  const [classStudents, setClassStudents] = useState([]);
  const [selectedClass, setSelectedClass] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [form, setForm] = useState({ student_id: "", pickup_point: "", drop_point: "", fee: "" });
  const [saving, setSaving] = useState(false);

  const classes = useYearAwareClasses({ selectedClassId: selectedClass, onRemap: setSelectedClass });

  const [confirmRemove, setConfirmRemove] = useState({ isOpen: false });

  const load = async () => {
    try {
      setLoading(true);
      const [routeRes, studentsRes] = await Promise.all([
        transportService.getRouteById(routeId),
        transportService.getRouteStudents(routeId, { academic_year: currentAcademicYear }),
      ]);
      if (routeRes.success) setRoute(routeRes.data);
      if (studentsRes.success) setStudents(studentsRes.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [routeId, currentAcademicYear]);

  useEffect(() => {
    const cls = classes.find((c) => c.id === selectedClass);
    setSections(cls?.sections || []);
    setSelectedSection("");
    setClassStudents([]);
  }, [selectedClass]);

  useEffect(() => {
    if (!selectedClass) return;
    // Only students whose admission record opts them into school transport.
    // Showing everyone invites allocating a service the family declined,
    // which the fee engine would then start billing them for.
    studentService.getAll({ class_id: selectedClass, section_id: selectedSection || undefined, status: "active", transport_required: true, limit: 200 }).then((res) => {
      if (res.success) setClassStudents(res.data);
    });
  }, [selectedClass, selectedSection]);

  const openAssign = () => {
    setSelectedClass(""); setSelectedSection("");
    setForm({ student_id: "", pickup_point: "", drop_point: "", fee: "" });
    setAssignModal(true);
  };

  const handleAssign = async () => {
    if (!form.student_id) { showError("Pick a student"); return; }
    try {
      setSaving(true);
      const res = await transportService.assignStudent({ ...form, route_id: routeId, fee: form.fee || undefined });
      if (res.success) {
        showSuccess(res.message);
        setAssignModal(false);
        load();
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleRemove = (allocationId) => setConfirmRemove({ isOpen: true, id: allocationId });
  const confirmRemoveStudent = async () => {
    try {
      await transportService.removeAllocation(confirmRemove.id);
      showSuccess("Student removed from route");
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmRemove({ isOpen: false });
  };

  const alreadyAssignedIds = new Set(students.map((s) => s.student_id));

  if (loading) return <MainLayout><div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div></MainLayout>;
  if (!route) return <MainLayout><div className="bg-white p-10 rounded shadow text-center text-gray-400">Route not found.</div></MainLayout>;

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">{route.name}</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {route.driver_name && `Driver: ${route.driver_name}`}{route.vehicle_number && ` • ${route.vehicle_number}`}
              {route.capacity && ` • ${students.length}/${route.capacity} seats`}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button onClick={openAssign}>Assign Student</Button>
            <Button
              onClick={() => navigate("/transport")}
              variant="lightPrimary"
              className="animate-pulse"
              leftIcon={
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 19l-7-7m0 0l7-7m-7 7h18"
                  />
                </svg>
              }>Back to Routes
            </Button>
          </div>
        </div>

        {route.stops?.length > 0 && (
          <div className="bg-white p-5 rounded shadow">
            <p className="text-sm text-left font-semibold text-gray-800 mb-2">Stops</p>
            <div className="flex flex-wrap gap-2">
              {route.stops.map((s, i) => (
                <span key={i} className="text-xs bg-gray-100 text-gray-700 px-2.5 py-1 rounded-full">{i + 1}. {s}</span>
              ))}
            </div>
          </div>
        )}

        <div className="bg-white rounded shadow overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
            <p className="text-sm text-left font-semibold text-gray-700">Assigned Students ({students.length})</p>
          </div>
        </div>

        {/* Shared DataTable, so this list matches the rest of the system's
            alignment, empty state and Actions column. */}
        <DataTable
          columns={[
            {
              key: "student", label: "Student",
              render: (a) => (
                <div>
                  <div className="text-sm text-gray-900">{a.student?.user?.first_name} {a.student?.user?.last_name}</div>
                  <div className="text-xs text-gray-400">{a.student?.admission_number}</div>
                </div>
              ),
            },
            {
              key: "class", label: "Class",
              render: (a) => (
                <span className="text-sm text-gray-600">
                  {a.student?.class?.name}{a.student?.section?.name ? ` — ${a.student.section.name}` : ""}
                </span>
              ),
            },
            { key: "pickup_point", label: "Pickup", render: (a) => <span className="text-sm text-gray-600">{a.pickup_point || <span className="text-gray-300">—</span>}</span> },
            { key: "drop_point", label: "Drop", render: (a) => <span className="text-sm text-gray-600">{a.drop_point || <span className="text-gray-300">—</span>}</span> },
            { key: "fee", label: "Fee", align: "right", render: (a) => <span className="text-sm font-medium text-gray-900">{formatMoney(a.fee)}</span> },
          ]}
          data={students}
          rowId="id"
          emptyMessage="No students assigned to this route yet"
          renderActions={(a) => (
            <RowActions
              actions={[
                { label: "Remove from Route", variant: "danger", icon: ACTION_ICONS.remove, onClick: () => handleRemove(a.id) },
              ]}
            />
          )}
        />
      </div>

      {assignModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Assign Student to {route.name}</h3>
              <button onClick={() => setAssignModal(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleAssign(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Select label="Class" required value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)}
                  options={[{ value: "", label: "Select…" }, ...classes.map((c) => ({ value: c.id, label: c.name }))]} />
                <Select label="Section" value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} disabled={!selectedClass}
                  options={[{ value: "", label: "All sections" }, ...sections.map((s) => ({ value: s.id, label: s.name }))]} />
              </div>
              <Select
                label="Student" required searchable value={form.student_id} onChange={(e) => setForm((f) => ({ ...f, student_id: e.target.value }))}
                disabled={!selectedClass}
                options={[
                  { value: "", label: "Select…" },
                  ...classStudents.map((s) => ({
                    value: s.id,
                    label: `${s.user?.first_name} ${s.user?.last_name} (${s.admission_number})${alreadyAssignedIds.has(s.id) ? " — already on this route" : ""}`,
                  })),
                ]}
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Pickup Point" value={form.pickup_point} onChange={(e) => setForm((f) => ({ ...f, pickup_point: e.target.value }))} placeholder="Optional" />
                <Input label="Drop Point" value={form.drop_point} onChange={(e) => setForm((f) => ({ ...f, drop_point: e.target.value }))} placeholder="Optional" />
              </div>
              <NumberInput label="Fee (TZS)" value={form.fee} onChange={(e) => setForm((f) => ({ ...f, fee: e.target.value }))} placeholder="Optional — for reference only" helperText="Actual billing happens in Fees → Fee Structures; this is just a note on the assignment" />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={saving}>Assign</Button>
                <Button type="button" variant="secondary" onClick={() => setAssignModal(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmRemove.isOpen} title="Remove Student" message="Remove this student from the route?" variant="danger" onConfirm={confirmRemoveStudent} onClose={() => setConfirmRemove({ isOpen: false })} />
    </MainLayout>
  );
}