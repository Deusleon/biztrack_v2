import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../contexts/ToastContext";
import { useAcademicYear } from "../../contexts/AcademicYearContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { vehicleService } from "../../services/api";
import MainLayout from "../../components/MainLayout";
import { Input, NumberInput, Select, Button, ConfirmModal, DatePicker } from "../../components/ui";
import { formatMoneyOrDash as formatMoney } from "../../utils/money";

const STATUS_STYLES = {
  active: "bg-green-100 text-green-700",
  in_maintenance: "bg-amber-100 text-amber-700",
  inactive: "bg-gray-100 text-gray-600",
};


const SERVICE_TYPES = ["Oil Change", "Full Service", "Tire Replacement", "Brake Service", "Battery Replacement", "Repair", "Inspection", "Other"];

// Small icon-box stat card, matching the convention used on
// Subject/Campus/Student detail pages (icon in a tinted box, label +
// number beside it).
function StatCard({ label, value, color, icon }) {
  return (
    <div className="bg-white p-5 rounded shadow">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="text-sm text-left text-gray-600">{label}</p>
          <p className={`text-2xl text-left font-bold mt-1 ${color.text}`}>{value}</p>
        </div>
        <div className={`${color.bg} p-3 rounded`}>
          <svg className={`w-8 h-8 ${color.text} opacity-45`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={icon} />
          </svg>
        </div>
      </div>
    </div>
  );
}

export default function VehicleView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { showSuccess, showError } = useToast();
  const { formatDate } = usePreferences();
  const fileInputRef = useRef(null);

  const [vehicle, setVehicle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  const [editModal, setEditModal] = useState(false);
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const [records, setRecords] = useState([]);
  const [recordModal, setRecordModal] = useState(false);
  const [recordForm, setRecordForm] = useState({ service_date: "", service_type: "Oil Change", cost: "", performed_by: "", next_service_date: "", notes: "" });
  const [savingRecord, setSavingRecord] = useState(false);
  const [confirmDeleteRecord, setConfirmDeleteRecord] = useState({ isOpen: false });
  const [activeTab, setActiveTab] = useState("overview");

  // Maintenance history is date-stamped, so it belongs to a year the same
  // way expenses do. The vehicle's own details aren't year-scoped — only
  // its servicing record is.
  const { currentAcademicYear } = useAcademicYear();
  const yearBounds = (() => {
    const base = parseInt(String(currentAcademicYear || "").match(/\d{4}/)?.[0], 10);
    return base ? { start: `${base}-01-01`, end: `${base}-12-31` } : null;
  })();

  const load = async () => {
    try {
      setLoading(true);
      const [vRes, mRes] = await Promise.all([
        vehicleService.getById(id),
        vehicleService.getMaintenanceRecords(id, { start_date: yearBounds?.start, end_date: yearBounds?.end }),
      ]);
      if (vRes.success) setVehicle(vRes.data);
      if (mRes.success) setRecords(mRes.data);
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [id, currentAcademicYear]);

  const handlePhotoSelect = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      setUploading(true);
      const res = await vehicleService.uploadPhoto(id, file);
      if (res.success) { showSuccess("Photo uploaded"); setVehicle(res.data); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setUploading(false); }
  };

  const openEdit = () => {
    setForm({
      registration_number: vehicle.registration_number, make: vehicle.make || "", model: vehicle.model || "", year: vehicle.year || "",
      capacity: vehicle.capacity || "", description: vehicle.description || "", driver_name: vehicle.driver_name || "", driver_phone: vehicle.driver_phone || "",
      driver_license_number: vehicle.driver_license_number || "", insurance_expiry: vehicle.insurance_expiry || "", inspection_expiry: vehicle.inspection_expiry || "",
      status: vehicle.status,
    });
    setEditModal(true);
  };

  const handleSaveEdit = async () => {
    try {
      setSaving(true);
      const payload = { ...form, year: form.year ? Number(form.year) : null, capacity: form.capacity ? Number(form.capacity) : null };
      const res = await vehicleService.update(id, payload);
      if (res.success) { showSuccess("Vehicle updated"); setEditModal(false); load(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSaving(false); }
  };

  const handleDeleteVehicle = async () => {
    try {
      await vehicleService.delete(id);
      showSuccess("Vehicle deleted");
      navigate("/transport/vehicles");
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmDelete(false);
  };

  const openAddRecord = () => {
    setRecordForm({ service_date: new Date().toISOString().slice(0, 10), service_type: "Oil Change", cost: "", performed_by: "", next_service_date: "", notes: "" });
    setRecordModal(true);
  };

  const handleSaveRecord = async () => {
    if (!recordForm.service_date || !recordForm.service_type) { showError("Service date and type are required"); return; }
    try {
      setSavingRecord(true);
      const res = await vehicleService.createMaintenanceRecord(id, { ...recordForm, cost: recordForm.cost || undefined });
      if (res.success) { showSuccess("Maintenance record added"); setRecordModal(false); load(); }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setSavingRecord(false); }
  };

  const handleDeleteRecord = (recordId) => setConfirmDeleteRecord({ isOpen: true, id: recordId });
  const confirmRemoveRecord = async () => {
    try {
      await vehicleService.deleteMaintenanceRecord(id, confirmDeleteRecord.id);
      showSuccess("Record deleted");
      load();
    } catch (err) { showError(err.response?.data?.message || err.message); }
    setConfirmDeleteRecord({ isOpen: false });
  };

  if (loading) return <MainLayout><div className="bg-white p-10 rounded shadow text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div></MainLayout>;
  if (!vehicle) return <MainLayout><div className="bg-white p-10 rounded shadow text-center text-gray-400">Vehicle not found.</div></MainLayout>;

  const totalMaintenanceCost = records.reduce((sum, r) => sum + Number(r.cost || 0), 0);

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Header */}
        <div className="page-header flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">View Vehicle</h1>
            <p className="text-sm text-gray-500 mt-0.5">{vehicle.registration_number} - {[vehicle.make, vehicle.model, vehicle.year].filter(Boolean).join(" ") || "No make/model set"}</p>
          </div>
          <Button
            onClick={() => navigate("/transport/vehicles")}
            variant="lightPrimary"
            className="animate-pulse"
            leftIcon={
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            }>Back to List
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <StatCard label="Status" value={<span className="capitalize">{vehicle.status.replace("_", " ")}</span>} color={{ bg: STATUS_STYLES[vehicle.status].split(" ")[0], text: STATUS_STYLES[vehicle.status].split(" ")[1] }}
            icon="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          <StatCard label="Service Records" value={records.length} color={{ bg: "bg-indigo-100", text: "text-indigo-600" }}
            icon="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          <StatCard label="Total Maintenance Spent" value={formatMoney(totalMaintenanceCost)} color={{ bg: "bg-amber-100", text: "text-amber-600" }}
            icon="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </div>

        {/* Action Buttons */}
        {(can("transport.update") || can("transport.delete")) && (
          <div className="flex items-center gap-3">
            {can("transport.update") && <Button variant="lightPrimary" onClick={openEdit}>Edit Vehicle</Button>}
            {can("transport.delete") && <Button variant="lightDanger" onClick={() => setConfirmDelete(true)}>Delete</Button>}
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded shadow">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {["overview", "maintenance"].map((tab) => (
                <button key={tab} onClick={() => setActiveTab(tab)}
                  className={`px-5 py-3 text-sm font-medium capitalize border-b-2 transition-colors ${activeTab === tab ? "border-primary text-primary" : "border-transparent text-gray-500 hover:text-gray-700"}`}>
                  {tab}
                </button>
              ))}
            </nav>
          </div>

          <div className="px-5 py-4 text-left">
            {activeTab === "overview" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div>
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">Photo</h3>
                    <div className="bg-gray-100 rounded overflow-hidden h-80 flex items-center justify-center">
                      {vehicle.photo_url ? (
                        <img src={vehicle.photo_url} alt={vehicle.registration_number} className="w-full h-full object-cover" />
                      ) : (
                        <svg className="w-14 h-14 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
                      )}
                    </div>
                    {can("transport.update") && (
                      <>
                        <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handlePhotoSelect} />
                        <button onClick={() => fileInputRef.current?.click()} disabled={uploading} className="w-full mt-2 text-sm border border-gray-300 rounded px-3 py-2 hover:bg-gray-50 disabled:opacity-50">
                          {uploading ? "Uploading…" : vehicle.photo_url ? "Change Photo" : "Upload Photo"}
                        </button>
                      </>
                    )}
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-sm text-left font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">Vehicle Information</h3>
                    <div className="grid items-center text-left grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-5">
                      <p className="text-xs text-gray-500">Make / Model</p><p>:</p><p className="text-sm text-gray-900">{[vehicle.make, vehicle.model].filter(Boolean).join(" ") || "Not set"}</p>
                      <p className="text-xs text-gray-500">Year</p><p>:</p><p className="text-sm text-gray-900">{vehicle.year || "Not set"}</p>
                      <p className="text-xs text-gray-500">Capacity</p><p>:</p><p className="text-sm text-gray-900">{vehicle.capacity ? `${vehicle.capacity} seats` : "Not set"}</p>
                      <p className="text-xs text-gray-500">Assigned Routes</p><p>:</p><p className="text-sm text-gray-900">{vehicle.routes?.length > 0 ? vehicle.routes.map((r) => r.name).join(", ") : "None"}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-sm font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">Driver & Compliance</h3>
                    <div className="grid items-center text-left grid-cols-[max-content_auto_1fr] gap-x-3 gap-y-4">
                      <p className="text-xs text-gray-500">Driver</p><p>:</p><p className="text-sm text-gray-900">{vehicle.driver_name || "Not set"}</p>
                      <p className="text-xs text-gray-500">Driver Phone</p><p>:</p><p className="text-sm text-gray-900">{vehicle.driver_phone || "Not set"}</p>
                      <p className="text-xs text-gray-500">License No.</p><p>:</p><p className="text-sm text-gray-900">{vehicle.driver_license_number || "Not set"}</p>
                      <p className="text-xs text-gray-500">Insurance Expiry</p><p>:</p><p className="text-sm text-gray-900">{vehicle.insurance_expiry ? formatDate(vehicle.insurance_expiry) : "Not set"}</p>
                      <p className="text-xs text-gray-500">Inspection Expiry</p><p>:</p><p className="text-sm text-gray-900">{vehicle.inspection_expiry ? formatDate(vehicle.inspection_expiry) : "Not set"}</p>
                    </div>
                  </div>
                </div>

                {vehicle.description && (
                  <div>
                    <h3 className="text-sm font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-100">Description</h3>
                    <p className="text-sm text-gray-600 rounded p-1.5">{vehicle.description}</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === "maintenance" && (
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                  <h3 className="text-sm font-semibold text-gray-700">Service & Maintenance History</h3>
                  {can("transport.create") && <Button variant="lightPrimary" onClick={openAddRecord} size="sm">Add Record</Button>}
                </div>
                {records.length === 0 ? (
                  <p className="text-sm text-gray-500 py-6 text-center">No maintenance records yet.</p>
                ) : (
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-4 py-2 text-left font-semibold text-gray-600 text-xs uppercase">Date</th>
                        <th className="px-4 py-2 text-left font-semibold text-gray-600 text-xs uppercase">Type</th>
                        <th className="px-4 py-2 text-left font-semibold text-gray-600 text-xs uppercase">Performed By</th>
                        <th className="px-4 py-2 text-left font-semibold text-gray-600 text-xs uppercase">Cost</th>
                        <th className="px-4 py-2 text-left font-semibold text-gray-600 text-xs uppercase">Next Due</th>
                        {can("transport.delete") && <th className="px-4 py-2 text-center font-semibold text-gray-600 text-xs uppercase">Actions</th>}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {records.map((r) => (
                        <tr key={r.id}>
                          <td className="px-4 py-2 text-gray-700">{formatDate(r.service_date)}</td>
                          <td className="px-4 py-2 text-gray-700">{r.service_type}</td>
                          <td className="px-4 py-2 text-gray-700">{r.performed_by || "—"}</td>
                          <td className="px-4 py-2 text-gray-700">{formatMoney(r.cost)}</td>
                          <td className="px-4 py-2 text-gray-700">{r.next_service_date ? formatDate(r.next_service_date) : "—"}</td>
                          {can("transport.delete") && (
                            <td className="px-4 py-2 text-center">
                              <Button variant="lightDanger" size="sm" onClick={() => handleDeleteRecord(r.id)} className="text-xs">Delete</Button>
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {editModal && form && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-lg">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Edit Vehicle</h3>
              <button onClick={() => setEditModal(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSaveEdit(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Registration Number" required value={form.registration_number} onChange={(e) => setForm((f) => ({ ...f, registration_number: e.target.value }))} />
                <Input label="Seat Capacity" type="number" min={1} value={form.capacity} onChange={(e) => setForm((f) => ({ ...f, capacity: e.target.value }))} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input label="Make" value={form.make} onChange={(e) => setForm((f) => ({ ...f, make: e.target.value }))} />
                <Input label="Model" value={form.model} onChange={(e) => setForm((f) => ({ ...f, model: e.target.value }))} />
                <Input label="Year" type="number" value={form.year} onChange={(e) => setForm((f) => ({ ...f, year: e.target.value }))} />
              </div>
              <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input label="Driver Name" value={form.driver_name} onChange={(e) => setForm((f) => ({ ...f, driver_name: e.target.value }))} />
                <Input label="Driver Phone" value={form.driver_phone} onChange={(e) => setForm((f) => ({ ...f, driver_phone: e.target.value }))} />
              </div>
              <Input label="Driver License Number" value={form.driver_license_number} onChange={(e) => setForm((f) => ({ ...f, driver_license_number: e.target.value }))} />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <DatePicker label="Insurance Expiry" value={form.insurance_expiry} onChange={(e) => setForm((f) => ({ ...f, insurance_expiry: e.target.value }))} />
                <DatePicker label="Inspection Expiry" value={form.inspection_expiry} onChange={(e) => setForm((f) => ({ ...f, inspection_expiry: e.target.value }))} />
              </div>
              <Select label="Status" value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}
                options={[{ value: "active", label: "Active" }, { value: "in_maintenance", label: "In Maintenance" }, { value: "inactive", label: "Inactive" }]} />
              <div className="flex gap-3 pt-1">
                <Button type="submit" loading={saving}>Update</Button>
                <Button type="button" variant="secondary" onClick={() => setEditModal(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {recordModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold">Add Maintenance Record</h3>
              <button onClick={() => setRecordModal(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSaveRecord(); }} className="px-5 py-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <DatePicker label="Service Date" required value={recordForm.service_date} onChange={(e) => setRecordForm((f) => ({ ...f, service_date: e.target.value }))} />
                <Select label="Service Type" required value={recordForm.service_type} onChange={(e) => setRecordForm((f) => ({ ...f, service_type: e.target.value }))}
                  options={SERVICE_TYPES.map((t) => ({ value: t, label: t }))} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <NumberInput label="Cost (TZS)" value={recordForm.cost} onChange={(e) => setRecordForm((f) => ({ ...f, cost: e.target.value }))} placeholder="Optional" />
                <Input label="Performed By" value={recordForm.performed_by} onChange={(e) => setRecordForm((f) => ({ ...f, performed_by: e.target.value }))} placeholder="Garage/mechanic" />
              </div>
              <DatePicker label="Next Service Due" value={recordForm.next_service_date} onChange={(e) => setRecordForm((f) => ({ ...f, next_service_date: e.target.value }))} />
              <Input label="Notes" value={recordForm.notes} onChange={(e) => setRecordForm((f) => ({ ...f, notes: e.target.value }))} placeholder="Optional" />
              <div className="flex justify-end gap-3 pt-1">
                <Button type="submit" loading={savingRecord}>Add Record</Button>
                <Button type="button" variant="secondary" onClick={() => setRecordModal(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmDelete} title="Delete Vehicle" message={`Delete "${vehicle.registration_number}"? This can't be undone.`} variant="danger" onConfirm={handleDeleteVehicle} onClose={() => setConfirmDelete(false)} />
      <ConfirmModal isOpen={confirmDeleteRecord.isOpen} title="Delete Record" message="Delete this maintenance record?" variant="danger" onConfirm={confirmRemoveRecord} onClose={() => setConfirmDeleteRecord({ isOpen: false })} />
    </MainLayout>
  );
}