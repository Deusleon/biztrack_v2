import { useState, useEffect, useRef } from "react";
import { useAcademicYear } from "../contexts/AcademicYearContext";
import { classService } from "../services/api";

/**
 * A "Class" dropdown backed by classes for the CURRENTLY selected global
 * academic year — and, critically, one that keeps an already-made
 * selection correct when the year changes underneath it.
 *
 * Why this needs to exist at all: a class ROW belongs to exactly one
 * year (a new "Form I" row is created every year — see Promotion /
 * "Create missing classes"). So a `selectedClassId` picked while viewing
 * 2026 is that YEAR's Form I specifically. If the person then switches
 * the global selector to 2027 without touching the Class field again,
 * two things must both happen, not just one:
 *   1. The dropdown's OPTIONS must refresh to 2027's classes (handled by
 *      simply re-fetching with the new academic_year).
 *   2. The already-chosen "Form I" must be RE-POINTED at 2027's Form I
 *      row — otherwise the field still displays "Form I" (label
 *      unchanged, exactly as expected) while every query underneath it
 *      keeps using 2026's class_id, so fees/roster/etc. silently never
 *      update to match the year actually showing on screen.
 *
 * This hook does both, matched by grade + education_level + campus_id —
 * the one thing that stays constant across a class's yearly rows.
 *
 * Usage:
 *   const [classId, setClassId] = useState("");
 *   const classes = useYearAwareClasses({ selectedClassId: classId, onRemap: setClassId });
 */
export function useYearAwareClasses({
  selectedClassId,
  onRemap,
  extraParams,
} = {}) {
  const { currentAcademicYear } = useAcademicYear();
  const [classes, setClasses] = useState([]);
  const prevClassesRef = useRef([]);
  const extraParamsKey = JSON.stringify(extraParams || {});

  useEffect(() => {
    let cancelled = false;
    classService
      .getAll({ limit: 200, status: "active", academic_year: currentAcademicYear, ...(extraParams || {}) })
      .then((res) => {
        if (cancelled || !res.success) return;
        const nextClasses = res.data;

        if (selectedClassId && onRemap && !nextClasses.some((c) => c.id === selectedClassId)) {
          const prevSelected = prevClassesRef.current.find((c) => c.id === selectedClassId);
          const equivalent = prevSelected
            ? nextClasses.find(
                (c) => c.grade === prevSelected.grade
                  && c.education_level === prevSelected.education_level
                  && c.campus_id === prevSelected.campus_id,
              )
            : null;
          // Falls back to clearing the field (rather than leaving a
          // now-invalid id selected) when that grade doesn't exist yet
          // for the new year — the same "create it first" situation
          // Promotion surfaces, just here instead of staying silently wrong.
          onRemap(equivalent ? equivalent.id : "");
        }

        prevClassesRef.current = nextClasses;
        setClasses(nextClasses);
      });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentAcademicYear, extraParamsKey]);

  return classes;
}
