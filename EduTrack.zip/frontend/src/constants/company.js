// Who is behind the product, and how to reach them. Shown on the Help,
// Privacy and Terms pages. Everything can be overridden per deployment in the
// frontend .env (VITE_…) without touching code; blank values are simply left
// out of the pages rather than shown as empty placeholders.
const env = import.meta.env;

export const COMPANY = {
  productName: 'EduTrack',
  legalName: env.VITE_COMPANY_NAME || 'EduTrack',
  supportEmail: env.VITE_SUPPORT_EMAIL || 'support@edutrack.co.tz',
  supportPhone: env.VITE_SUPPORT_PHONE || '',
  supportWhatsapp: env.VITE_SUPPORT_WHATSAPP || '', // digits with country code, e.g. 255712345678
  address: env.VITE_COMPANY_ADDRESS || '',
  website: env.VITE_COMPANY_WEBSITE || '',
  taxId: env.VITE_COMPANY_TIN || '', // printed on invoices and receipts when set
};

/** Bump when the Privacy Policy or Terms of Service text changes. */
export const LEGAL_LAST_UPDATED = 'October 2026';
