// Invoice and receipt for a subscription payment — the browser side.
//
// The model and the PDF drawing live in subscriptionDocumentCore.js (shared, byte for byte,
// with the server that attaches the same PDFs to emails). This file only supplies what a
// browser knows: the school's money/date settings, the seller details from the .env, the
// logo, and the QR image — and saves the result.
import { COMPANY } from "../constants/company";
import { formatNumber } from "./money";
import { qrDataUrl } from "./qrDataUrl";
import emblemUrl from "../assets/brand/edutrack-emblem.png";
import {
  NAVY, GREEN, statusStyle,
  buildDoc as buildCoreDoc, drawSubscriptionDocument, documentFileName,
} from "./subscriptionDocumentCore";

export { NAVY, GREEN, statusStyle };

/** kind: "invoice" | "receipt"; data: the response of GET /subscription/invoices/:reference */
export function buildDoc(kind, data, formatDate) {
  return buildCoreDoc(kind, data, {
    formatDate,
    formatNumber: (n) => formatNumber(n), // follows Settings → Money Decimals
    seller: {
      name: COMPANY.legalName,
      lines: [COMPANY.address, COMPANY.supportPhone && `Tel: ${COMPANY.supportPhone}`, COMPANY.supportEmail, COMPANY.website, COMPANY.taxId && `TIN: ${COMPANY.taxId}`].filter(Boolean),
    },
    origin: window.location.origin,
  });
}

const toDataUrl = async (url) => {
  const blob = await (await fetch(url)).blob();
  return new Promise((resolve) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => resolve(null);
    r.readAsDataURL(blob);
  });
};

/** Builds and downloads the PDF for an invoice or a receipt. */
export async function exportSubscriptionDocPDF(doc, filename) {
  const { default: jsPDF } = await import("jspdf");
  const { default: autoTable } = await import("jspdf-autotable");
  const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
  drawSubscriptionDocument(pdf, autoTable, doc, {
    emblem: await toDataUrl(emblemUrl).catch(() => null),
    qr: doc.qr ? qrDataUrl(doc.qr.url, 360) : null,
    contact: [COMPANY.supportEmail, COMPANY.supportPhone].filter(Boolean).join("   |   "),
  });
  pdf.save(filename ? `${filename}.pdf` : documentFileName(doc));
}
