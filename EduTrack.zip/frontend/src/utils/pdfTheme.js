// Shared PDF theming helpers — used by every PDF export in the app
// (attendance, staff profile, exam report cards/results) so a printed
// document uses the SAME color language the school sees on screen,
// rather than a color baked into the export code that never changes
// even when the school picks a different theme in Settings.

const FALLBACK = { primary: '#2563eb', primaryDark: '#1e40af', primaryLight: '#3b82f6', accent: '#06b6d4' };

const hexToRgb = (hex) => {
  const clean = String(hex || '').trim().replace('#', '');
  if (!/^[0-9a-fA-F]{6}$/.test(clean)) return null;
  const num = parseInt(clean, 16);
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
};

/** Blends an [r,g,b] color toward white by (1 - amount) — a cheap
 * stand-in for the app's own `bg-primary-15`-style CSS (color-mix
 * against transparent over a white page). amount=1 returns the color
 * unchanged; amount=0 returns white. */
export const tint = (rgb, amount) => rgb.map((c) => Math.round(255 + (c - 255) * amount));

/** Reads the school's ACTUAL current theme (set via ThemeContext /
 * CampusContext, live in the DOM as CSS custom properties) rather than
 * a fixed guess — a school running the "Forest Emerald" theme gets
 * green PDFs, one running "Royal Purple" gets purple ones, matching
 * exactly what they see everywhere else in the app. Falls back to the
 * app's own default blue if, for any reason, nothing is set yet. */
export function getThemeColors() {
  const style = typeof document !== 'undefined' ? getComputedStyle(document.documentElement) : null;
  const read = (varName, fallback) => {
    const raw = style?.getPropertyValue(varName)?.trim();
    return hexToRgb(raw) || hexToRgb(fallback);
  };
  return {
    primary: read('--color-primary', FALLBACK.primary),
    primaryDark: read('--color-primary-dark', FALLBACK.primaryDark),
    primaryLight: read('--color-primary-light', FALLBACK.primaryLight),
    accent: read('--color-accent', FALLBACK.accent),
  };
}

/** Attendance status colors — deliberately mirror
 * ATTENDANCE_STATUS_COLORS / STATUS_COLORS already used on-screen
 * (see StudentView.jsx, AttendanceView.jsx), so a printed register
 * "looks like" the calendar the reader already knows from the app.
 * `excused` is intentionally theme-driven rather than fixed (same as
 * AttendanceView.jsx), so it changes with the school's theme like
 * everything else — call attendancePdfColors() to get it resolved. */
const FIXED_STATUS_COLORS = {
  present: { fill: [220, 252, 231], text: [21, 128, 61] },   // green-100 / green-700
  absent: { fill: [254, 226, 226], text: [185, 28, 28] },    // red-100 / red-700
  late: { fill: [254, 249, 195], text: [161, 98, 7] },       // yellow-100 / yellow-700
  half_day: { fill: [243, 232, 255], text: [126, 34, 206] }, // purple-100 / purple-700
};

export function attendancePdfColors(theme = getThemeColors()) {
  return {
    ...FIXED_STATUS_COLORS,
    excused: { fill: tint(theme.primary, 0.15), text: theme.primaryDark },
  };
}

/** Loads an <img> URL into a PNG data-URL jsPDF can embed, resolving to
 * null (rather than throwing) on any failure — a missing/broken logo
 * should never stop a document from generating. */
export const loadImageDataUrl = (url) =>
  new Promise((resolve) => {
    if (!url) return resolve(null);
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        canvas.getContext('2d').drawImage(img, 0, 0);
        resolve({ dataUrl: canvas.toDataURL('image/png'), width: img.naturalWidth, height: img.naturalHeight });
      } catch {
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = url;
  });

/** Draws the shared letterhead every export uses: a thin page border,
 * the school's logo (if any) + name + address/contact line, and — for
 * documents that want one — a colored title banner underneath, filled
 * with the school's own theme color rather than a fixed one. Returns
 * the Y position just below whatever it drew, so the caller knows
 * where its own content can safely start. */
export async function drawLetterhead(doc, { school, title, theme = getThemeColors(), pageBorder = true } = {}) {
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginX = 14;
  let y = 16;

  if (pageBorder) {
    doc.setDrawColor(210, 210, 210);
    doc.setLineWidth(0.4);
    doc.rect(6, 6, pageWidth - 12, pageHeight - 12);
  }

  const logo = await loadImageDataUrl(school?.logo_url);
  if (logo) {
    const logoHeight = 14;
    const logoWidth = Math.min((logo.width / logo.height) * logoHeight, 40);
    doc.addImage(logo.dataUrl, 'PNG', marginX, y - 5, logoWidth, logoHeight);
  }

  doc.setFont(undefined, 'bold');
  doc.setFontSize(14);
  doc.setTextColor(20, 20, 20);
  doc.text(school?.name || 'School', pageWidth / 2, y, { align: 'center' });
  y += 5;

  doc.setFont(undefined, 'normal');
  doc.setFontSize(8);
  doc.setTextColor(110, 110, 110);
  const addressLine = [school?.address, school?.city, school?.country].filter(Boolean).join(', ');
  if (addressLine) { doc.text(addressLine, pageWidth / 2, y, { align: 'center' }); y += 4; }
  const contactLine = [school?.phone, school?.email].filter(Boolean).join('   •   ');
  if (contactLine) { doc.text(contactLine, pageWidth / 2, y, { align: 'center' }); y += 4; }
  doc.setTextColor(0, 0, 0);

  y += 1.5;
  doc.setDrawColor(...theme.primary);
  doc.setLineWidth(0.8);
  doc.line(marginX, y, pageWidth - marginX, y);
  y += 8;

  if (title) {
    doc.setFillColor(...theme.primary);
    doc.setFont(undefined, 'bold');
    doc.setFontSize(11);
    const bannerWidth = doc.getTextWidth(title) + 18;
    doc.roundedRect((pageWidth - bannerWidth) / 2, y - 5.5, bannerWidth, 8, 1, 1, 'F');
    doc.setTextColor(255, 255, 255);
    doc.text(title, pageWidth / 2, y, { align: 'center' });
    doc.setTextColor(0, 0, 0);
    doc.setFont(undefined, 'normal');
    y += 8;
  }

  return y;
}

/** Draws a small footer — generation timestamp, centered — consistent
 * across every export. Call once per page (or once at the very end for
 * single-page documents). */
export function drawPdfFooter(doc) {
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  doc.setFontSize(7);
  doc.setTextColor(140, 140, 140);
  doc.text(
    `Generated on ${new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}`,
    pageWidth / 2, pageHeight - 8, { align: 'center' },
  );
  doc.setTextColor(0, 0, 0);
}