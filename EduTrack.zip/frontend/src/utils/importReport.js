// FILE PATH: frontend/src/utils/importReport.js
const LABELS = { ready: "Ready", possible_duplicate: "Possible duplicate", error: "Has errors" };

/** Downloads the rows that need attention (errors, possible duplicates, warnings) as Excel, so the file can be fixed. */
export async function downloadIssueReport({ rows, idLabel, fileName }) {
  const XLSX = await import("xlsx");
  const flagged = rows.filter((r) => r.status !== "ready" || r.warnings.length > 0);
  const data = flagged.map((r) => ({
    "Excel row": r.row,
    Name: r.name,
    [idLabel]: r.admission_number || r.employee_number || "",
    Check: LABELS[r.status],
    "Problems (must fix)": r.errors.join("; "),
    "Warnings (check)": r.warnings.join("; "),
  }));
  const ws = XLSX.utils.json_to_sheet(data.length ? data : [{ Note: "Nothing needs attention" }]);
  ws["!cols"] = [{ wch: 10 }, { wch: 26 }, { wch: 18 }, { wch: 20 }, { wch: 70 }, { wch: 60 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Needs attention");
  XLSX.writeFile(wb, fileName);
}
