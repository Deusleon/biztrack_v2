import { createElement } from "react";
import { flushSync } from "react-dom";
import { createRoot } from "react-dom/client";
import { QRCodeCanvas } from "qrcode.react";

/**
 * A QR code as a PNG data URL, for putting into a PDF. It renders the same
 * <QRCodeCanvas> used on screen into a hidden element, reads the pixels, and cleans up,
 * so no extra QR library is needed.
 */
export function qrDataUrl(text, size = 320) {
  const host = document.createElement("div");
  host.style.cssText = "position:fixed;left:-10000px;top:0;pointer-events:none";
  document.body.appendChild(host);
  const root = createRoot(host);
  try {
    flushSync(() => root.render(createElement(QRCodeCanvas, { value: text, size, level: "M", marginSize: 0, bgColor: "#ffffff", fgColor: "#111827" })));
    return host.querySelector("canvas").toDataURL("image/png");
  } finally {
    root.unmount();
    host.remove();
  }
}
