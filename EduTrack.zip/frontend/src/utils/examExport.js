// Shared PDF/Excel export helpers for exam result matrices (Class Results,
// Term Summary) and the individual student Report Card. Kept in one place
// so exports stay in exactly the same format instead of drifting apart.

// Shared PDF/Excel export helpers for exam result matrices (Class Results,
// Term Summary) and the individual student Report Card. Kept in one place
// so exports stay in exactly the same format instead of drifting apart.
// PDFs use the shared letterhead/theme helpers in utils/pdfTheme.js so a
// results sheet or report card looks like a real school document —
// school letterhead, the school's own theme color — not a plain table.

import { getThemeColors, drawLetterhead, drawPdfFooter, loadImageDataUrl } from './pdfTheme';

export async function exportResultsPDF({ school, title, subtitle, subjects, students, filename }) {
  const { default: jsPDF } = await import("jspdf");
  const { default: autoTable } = await import("jspdf-autotable");
  const doc = new jsPDF({ orientation: "landscape" });
  const theme = getThemeColors();

  let y = await drawLetterhead(doc, { school, title, theme });
  if (subtitle) {
    doc.setFontSize(9);
    doc.setTextColor(100);
    doc.text(subtitle, doc.internal.pageSize.getWidth() / 2, y, { align: "center" });
    doc.setTextColor(0);
    y += 6;
  }

  const head = [["#", "Adm No.", "Student", ...subjects.map((s) => s.code || s.name), "Total", "Avg %", "Grade", "Rank"]];
  const body = students.map((r, i) => [
    i + 1,
    r.admission_number,
    r.name,
    ...r.subjects.map((sg) => (sg.marks_obtained !== null && sg.marks_obtained !== undefined ? sg.marks_obtained : "—")),
    r.total_obtained !== null ? r.total_obtained : "—",
    r.average !== null ? `${r.average}%` : "—",
    r.overall_grade || "—",
    r.position || "—",
  ]);

  autoTable(doc, {
    head, body, startY: y,
    styles: { fontSize: 7, cellPadding: 1.5 },
    headStyles: { fillColor: theme.primary, textColor: 255 },
  });

  drawPdfFooter(doc);
  doc.save(`${filename}.pdf`);
}


export async function exportResultsExcel({ title, subjects, students, filename }) {
  const XLSX = await import("xlsx");

  const wsData = [
    [title],
    [],
    ["#", "Adm No.", "Student", ...subjects.map((s) => s.code || s.name), "Total", "Average %", "Grade", "Rank"],
    ...students.map((r, i) => [
      i + 1,
      r.admission_number,
      r.name,
      ...r.subjects.map((sg) => (sg.marks_obtained !== null && sg.marks_obtained !== undefined ? sg.marks_obtained : "")),
      r.total_obtained !== null ? r.total_obtained : "",
      r.average !== null ? r.average : "",
      r.overall_grade || "",
      r.position || "",
    ]),
  ];

  const ws = XLSX.utils.aoa_to_sheet(wsData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Results");
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

const GRADE_REMARKS = { A: "Excellent", B: "Good", C: "Satisfactory", D: "Needs Improvement", F: "Fail" };

/** Loads the school logo as a data URL so jsPDF can embed it.
 *
 * jsPDF needs actual image bytes, not a URL, and the logo is served from
 * the backend's /uploads path — a different origin in most deployments.
 * `crossOrigin = "anonymous"` lets the canvas read it without tainting;
 * if that fails (no CORS header, network error, missing file) we resolve
 * null so the PDF simply falls back to the text-only letterhead rather
 * than failing the whole export over a decorative image. */
const loadLogoDataUrl = (url) =>
  new Promise((resolve) => {
    if (!url) return resolve(null);
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        canvas.getContext("2d").drawImage(img, 0, 0);
        resolve({ dataUrl: canvas.toDataURL("image/png"), width: img.naturalWidth, height: img.naturalHeight });
      } catch {
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = url;
  });

/** Builds a formal, letterhead-style single-student report card as a PDF —
 * mirrors the on-screen ReportCard page (school letterhead, subject table,
 * summary boxes, grading key, signature lines) using jsPDF + autoTable
 * directly, so it needs no extra dependencies beyond what's already used
 * for the other exports. */
export async function exportReportCardPDF({ school, exam, student, subjects, basis, total_obtained, average, overall_grade, position, class_size, filename }) {
  const { default: jsPDF } = await import("jspdf");
  const { default: autoTable } = await import("jspdf-autotable");
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const theme = getThemeColors();
  const pageWidth = doc.internal.pageSize.getWidth();
  const marginX = 16;
  let y = 18;

  // Outer frame
  doc.setDrawColor(20, 20, 20);
  doc.setLineWidth(0.6);
  doc.rect(8, 8, pageWidth - 16, doc.internal.pageSize.getHeight() - 16);

  // Letterhead — logo first (when the school has uploaded one), scaled to
  // a fixed height so wide and tall logos both sit sensibly.
  const logo = await loadLogoDataUrl(school?.logo_url);
  if (logo) {
    const logoHeight = 18;
    const logoWidth = Math.min((logo.width / logo.height) * logoHeight, 50);
    doc.addImage(logo.dataUrl, "PNG", (pageWidth - logoWidth) / 2, y - 4, logoWidth, logoHeight);
    y += logoHeight + 1;
  }

  doc.setFont(undefined, "bold");
  doc.setFontSize(16);
  doc.text(school?.name || "School Name", pageWidth / 2, y, { align: "center" });
  y += 6;
  doc.setFont(undefined, "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(90);
  const addressLine = [school?.address, school?.city, school?.country].filter(Boolean).join(", ");
  if (addressLine) { doc.text(addressLine, pageWidth / 2, y, { align: "center" }); y += 4; }
  const contactLine = [school?.phone, school?.email].filter(Boolean).join("   •   ");
  if (contactLine) { doc.text(contactLine, pageWidth / 2, y, { align: "center" }); y += 4; }
  doc.setTextColor(0);

  y += 2;
  doc.setDrawColor(...theme.primary);
  doc.setLineWidth(0.8);
  doc.line(marginX, y, pageWidth - marginX, y);
  y += 7;

  // Banner
  doc.setFillColor(...theme.primary);
  const bannerText = "STUDENT ACADEMIC REPORT";
  doc.setFont(undefined, "bold");
  doc.setFontSize(11);
  const bannerWidth = doc.getTextWidth(bannerText) + 16;
  doc.roundedRect((pageWidth - bannerWidth) / 2, y - 5, bannerWidth, 8, 1, 1, "F");
  doc.setTextColor(255, 255, 255);
  doc.text(bannerText, pageWidth / 2, y, { align: "center" });
  doc.setTextColor(0);
  y += 10;

  // Exam meta
  doc.setFont(undefined, "bold");
  doc.setFontSize(10);
  doc.text(exam?.name || "", marginX, y);
  doc.setFont(undefined, "normal");
  doc.setFontSize(8.5);
  doc.text(
    [exam?.academic_year, exam?.term, exam?.exam_type].filter(Boolean).join("  •  "),
    pageWidth - marginX, y, { align: "right" }
  );
  y += 3;
  doc.setDrawColor(180);
  doc.setLineWidth(0.2);
  doc.line(marginX, y, pageWidth - marginX, y);
  y += 7;

  // Student info (two columns)
  doc.setFontSize(9.5);
  const col2X = pageWidth / 2 + 5;
  const infoRow = (label1, val1, label2, val2, yy) => {
    doc.setTextColor(110); doc.text(label1, marginX, yy);
    doc.setTextColor(0); doc.setFont(undefined, "bold"); doc.text(String(val1 ?? "—"), marginX + 26, yy); doc.setFont(undefined, "normal");
    doc.setTextColor(110); doc.text(label2, col2X, yy);
    doc.setTextColor(0); doc.setFont(undefined, "bold"); doc.text(String(val2 ?? "—"), col2X + 26, yy); doc.setFont(undefined, "normal");
  };
  infoRow("Student Name:", student?.name, "Admission No.:", student?.admission_number, y);
  y += 6;
  infoRow("Class:", `${student?.class || ""}${student?.section ? ` — ${student.section}` : ""}`, "Gender:", student?.gender, y);
  y += 9;

  // Subjects table
  // Test = average of the term's tests, Exam = the final exam, Average = the two averaged.
  const pctText = (v) => (v === null || v === undefined ? "—" : `${v}%`);
  const head = [["#", "Subject", "Test", "Exam", "Average", "Grade", "Remark"]];
  const body = subjects.length === 0
    ? [["", "No marks recorded yet.", "", "", "", "", ""]]
    : subjects.map((s, i) => [
        i + 1,
        s.subject,
        pctText(s.test_average),
        // raw marks sit on a second line when the paper was not marked out of 100
        s.exam_max && s.exam_max !== 100 ? `${pctText(s.exam_percentage)}\n${s.exam_score}/${s.exam_max}` : pctText(s.exam_percentage),
        pctText(s.average),
        s.grade || "—",
        s.grade ? GRADE_REMARKS[s.grade] : "—",
      ]);
  // Same look as the on-screen report card: dark header, bordered cells, zebra rows,
  // and every column — header included — aligned the same way as its figures.
  const COL_ALIGN = ["left", "left", "center", "center", "center", "center", "center"];
  const GRADE_COLORS = { A: [21, 128, 61], B: [29, 78, 216], C: [161, 98, 7], D: [194, 65, 12], F: [185, 28, 28] };
  autoTable(doc, {
    head, body, startY: y,
    margin: { left: marginX, right: marginX },
    theme: "grid",
    styles: { fontSize: 9, cellPadding: { top: 2.6, bottom: 2.6, left: 3, right: 3 }, lineColor: [209, 213, 219], lineWidth: 0.2, valign: "middle", textColor: 20 },
    headStyles: { fillColor: [17, 24, 39], textColor: 255, fontStyle: "bold", fontSize: 8, lineColor: [17, 24, 39] },
    alternateRowStyles: { fillColor: [249, 250, 251] },
    columnStyles: {
      0: { cellWidth: 9 },
      1: { cellWidth: "auto" },
      2: { cellWidth: 22 },
      3: { cellWidth: 26 },
      4: { cellWidth: 24, fontStyle: "bold" },
      5: { cellWidth: 18, fontStyle: "bold" },
      6: { cellWidth: 36 },
    },
    didParseCell: (d) => {
      d.cell.styles.halign = COL_ALIGN[d.column.index];
      if (d.section === "head") d.cell.text = d.cell.text.map((t) => t.toUpperCase());
      if (d.section === "body" && subjects.length > 0 && (d.column.index === 5 || d.column.index === 6)) {
        const grade = subjects[d.row.index]?.grade;
        if (grade && GRADE_COLORS[grade]) d.cell.styles.textColor = GRADE_COLORS[grade];
        if (d.column.index === 6) d.cell.styles.fontSize = 8;
      }
      if (d.section === "body" && subjects.length === 0) d.cell.styles.halign = d.column.index === 1 ? "center" : "left";
    },
  });
  y = doc.lastAutoTable.finalY + 2;

  // What the columns are built from
  if (subjects.length > 0) {
    const testNames = basis?.tests?.length ? `${basis.tests.length} test${basis.tests.length === 1 ? "" : "s"} (${basis.tests.map((t) => t.name).join(", ")})` : "the term's tests (none recorded)";
    const note = `Test = average of ${testNames}.  Exam = ${basis?.final ? basis.final.name : "final exam (not recorded yet)"}.  Average = average of Test and Exam. All figures are percentages.`;
    doc.setFontSize(7);
    doc.setTextColor(110);
    const lines = doc.splitTextToSize(note, pageWidth - marginX * 2);
    doc.text(lines, marginX, y + 3);
    doc.setTextColor(0);
    y += 3 + lines.length * 3;
  }
  y += 6;
  y = doc.lastAutoTable.finalY + 8;

  // Summary boxes
  if (subjects.length > 0) {
    const boxes = [
      { label: "Total Score", value: total_obtained !== null ? String(total_obtained) : "—" },
      { label: "Average", value: average !== null ? `${average}%` : "—" },
      { label: "Overall Grade", value: overall_grade || "—" },
      { label: "Class Position", value: position ? `${position}${class_size ? ` of ${class_size}` : ""}` : "—" },
    ];
    const boxWidth = (pageWidth - marginX * 2 - 9) / 4;
    boxes.forEach((b, i) => {
      const bx = marginX + i * (boxWidth + 3);
      doc.setDrawColor(200);
      doc.setLineWidth(0.2);
      doc.rect(bx, y, boxWidth, 16);
      doc.setFont(undefined, "bold");
      doc.setFontSize(12);
      doc.setTextColor(...theme.primaryDark);
      doc.text(b.value, bx + boxWidth / 2, y + 8, { align: "center" });
      doc.setTextColor(0);
      doc.setFont(undefined, "normal");
      doc.setFontSize(7);
      doc.setTextColor(110);
      doc.text(b.label.toUpperCase(), bx + boxWidth / 2, y + 13, { align: "center" });
      doc.setTextColor(0);
    });
    y += 22;
  }

  // Grading key
  doc.setFontSize(7.5);
  doc.setTextColor(110);
  doc.text("GRADING KEY:  A = Excellent   B = Good   C = Satisfactory   D = Needs Improvement   F = Fail", marginX, y);
  doc.setTextColor(0);
  y += 10;

  // Remarks
  doc.setFontSize(8);
  doc.setTextColor(110);
  doc.text("Class Teacher's Remarks:", marginX, y);
  doc.text("Head Teacher's Remarks:", col2X, y);
  doc.setDrawColor(180);
  doc.line(marginX, y + 8, marginX + (col2X - marginX - 6), y + 8);
  doc.line(col2X, y + 8, pageWidth - marginX, y + 8);
  doc.setTextColor(0);
  y += 20;

  // Signatures
  const sigLabels = ["Class Teacher", "Head Teacher / Principal", "Parent / Guardian"];
  const sigWidth = (pageWidth - marginX * 2 - 10) / 3;
  sigLabels.forEach((label, i) => {
    const sx = marginX + i * (sigWidth + 5);
    doc.line(sx, y, sx + sigWidth, y);
    doc.setFontSize(7.5);
    doc.setTextColor(110);
    doc.text(label, sx + sigWidth / 2, y + 4, { align: "center" });
    doc.text("Date: ____________", sx + sigWidth / 2, y + 8, { align: "center" });
    doc.setTextColor(0);
  });

  doc.setFontSize(7);
  doc.setTextColor(150);
  doc.text(`Generated by EduTrack on ${new Date().toLocaleDateString()}`, pageWidth / 2, doc.internal.pageSize.getHeight() - 12, { align: "center" });

  doc.save(`${filename}.pdf`);
}