// One User Guide per role. Only the PDF is published (public/docs/guides); the editable Word masters stay in the project
// (tools/guide-generator/word-editable) and are never offered for download. A person is shown the guide for THEIR role, so a parent never reads the administrator's
// steps and a student never reads the teacher's.
export const USER_GUIDES = {
  super_admin: { label: "Super Admin", file: "Super_Admin" },
  admin: { label: "Administrator", file: "Administrator" },
  principal: { label: "Principal", file: "Principal" },
  teacher: { label: "Teacher", file: "Teacher" },
  accountant: { label: "Accountant", file: "Accountant" },
  librarian: { label: "Librarian", file: "Librarian" },
  hr: { label: "HR Manager", file: "HR_Manager" },
  transport_manager: { label: "Transport Manager", file: "Transport_Manager" },
  hostel_warden: { label: "Hostel Warden", file: "Hostel_Warden" },
  student: { label: "Student", file: "Student" },
  parent: { label: "Parent", file: "Parent" },
};

const base = (path) => `${import.meta.env.BASE_URL}${path}`.replace(/\/{2,}/g, "/");

/** { label, pdfUrl, pdfName } for a role, or null if the role has no guide. */
export const guideFor = (role) => {
  const g = USER_GUIDES[role];
  if (!g) return null;
  const name = `EduTrack_User_Guide_${g.file}`;
  return { label: g.label, pdfUrl: base(`docs/guides/${name}.pdf`), pdfName: `${name}.pdf` };
};
