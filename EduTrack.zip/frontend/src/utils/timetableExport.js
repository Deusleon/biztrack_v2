// PDF export for a single class/section's timetable — mirrors the on-screen
// Class View grid (periods, breaks/lunch with their times, and the
// end-of-day activities row) as a landscape table, in the same
// letterhead style as the other exports in utils/examExport.js.

const DAY_COLUMNS = [
  { value: "monday", label: "Monday" },
  { value: "tuesday", label: "Tuesday" },
  { value: "wednesday", label: "Wednesday" },
  { value: "thursday", label: "Thursday" },
  { value: "friday", label: "Friday" },
];

/** Loads an image (school logo) as a data URL so jsPDF can embed it; falls
 * back to `null` on any failure so the PDF just skips the logo instead of
 * failing the whole export over a decorative image. */
const loadLogoDataUrl = (url) =>
  new Promise((resolve) => {
    if (!url) return resolve(null);
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        canvas.getContext("2d").drawImage(img, 0, 0);
        resolve({ dataUrl: canvas.toDataURL("image/png"), width: img.naturalWidth, height: img.naturalHeight });
      } catch {
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = url;
  });

/**
 * @param {object} params
 * @param {object} params.school - campus/tenant info for the letterhead (name, address, city, country, logo_url)
 * @param {string} params.className, params.sectionName, params.academicYear
 * @param {{regular: Array, friday: Array}} params.grid - computeDayGrid() output for a normal day and for Friday
 * @param {object} params.entryMap - "day-period" -> TimetableEntry (with .subject, .teacher populated)
 * @param {object} params.dailyActivities - { [day]: string[] }
 */
export async function exportClassTimetablePDF({ school, className, sectionName, academicYear, grid, entryMap, dailyActivities, filename }) {
  const { default: jsPDF } = await import("jspdf");
  const { default: autoTable } = await import("jspdf-autotable");
  const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 14;

  const logo = await loadLogoDataUrl(school?.logo_url);
  if (logo) {
    const logoHeight = 14;
    const logoWidth = Math.min((logo.width / logo.height) * logoHeight, 40);
    doc.addImage(logo.dataUrl, "PNG", (pageWidth - logoWidth) / 2, y - 3, logoWidth, logoHeight);
    y += logoHeight - 1;
  }

  doc.setFont(undefined, "bold");
  doc.setFontSize(14);
  doc.text(school?.name || "School Timetable", pageWidth / 2, y, { align: "center" });
  y += 6;
  const addressLine = [school?.address, school?.city, school?.country].filter(Boolean).join(", ");
  if (addressLine) {
    doc.setFont(undefined, "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(90);
    doc.text(addressLine, pageWidth / 2, y, { align: "center" });
    doc.setTextColor(0);
    y += 5;
  }

  doc.setFont(undefined, "bold");
  doc.setFontSize(12);
  doc.text(`${className} ${sectionName} — Class Timetable`, pageWidth / 2, y, { align: "center" });
  y += 5;
  doc.setFont(undefined, "normal");
  doc.setFontSize(9);
  doc.setTextColor(90);
  doc.text(`Academic Year ${academicYear}`, pageWidth / 2, y, { align: "center" });
  doc.setTextColor(0);
  y += 4;

  // Build rows the same way the on-screen grid does: walk row-by-row
  // through the longer of the two day-shapes (regular vs Friday), reading
  // each day's OWN slot list at that row index so a day with a
  // differently-placed break still lines up sensibly.
  const maxRows = Math.max(grid.regular.length, grid.friday.length);
  const cellText = (day, slot) => {
    if (!slot) return "";
    if (slot.type !== "period") return `${slot.label}\n${slot.start_time}–${slot.end_time}`;
    const entry = entryMap[`${day}-${slot.period_number}`];
    const time = `${slot.start_time}–${slot.end_time}`;
    if (!entry?.subject) return `FREE\n${time}`;
    const teacherName = entry.teacher ? `${entry.teacher.first_name} ${entry.teacher.last_name}` : "";
    return [entry.subject.name, teacherName, time].filter(Boolean).join("\n");
  };

  const body = [];
  for (let rowIdx = 0; rowIdx < maxRows; rowIdx++) {
    const refSlot = grid.regular[rowIdx] || grid.friday[rowIdx];
    const timeLabel = refSlot ? `${refSlot.start_time}–${refSlot.end_time}` : "";
    body.push([
      timeLabel,
      ...DAY_COLUMNS.map((d) => cellText(d.value, (d.value === "friday" ? grid.friday : grid.regular)[rowIdx])),
    ]);
  }
  const hasActivities = Object.values(dailyActivities || {}).some((a) => (a || []).length > 0);
  if (hasActivities) {
    body.push([
      "Activities",
      ...DAY_COLUMNS.map((d) => {
        const acts = dailyActivities?.[d.value] || [];
        if (acts.length === 0) return "";
        const dayGrid = d.value === "friday" ? grid.friday : grid.regular;
        const lastSlot = dayGrid[dayGrid.length - 1];
        const fromTime = lastSlot ? `From ${lastSlot.end_time}` : "";
        return [acts.join(", "), fromTime].filter(Boolean).join("\n");
      }),
    ]);
  }

  autoTable(doc, {
    startY: y + 3,
    head: [["Time", ...DAY_COLUMNS.map((d) => d.label)]],
    body,
    styles: { fontSize: 7.5, cellPadding: 2, valign: "middle", halign: "center", lineColor: [210, 210, 210] },
    headStyles: { fillColor: [99, 102, 241], textColor: 255, fontStyle: "bold" },
    columnStyles: { 0: { cellWidth: 26, fontStyle: "bold", fontSize: 7 } },
    didParseCell: (data) => {
      if (data.section !== "body") return;
      const raw = data.cell.raw || "";
      if (raw.startsWith("FREE")) { data.cell.styles.textColor = [156, 163, 175]; }
      else if (raw.startsWith("Break") || raw.startsWith("Lunch")) { data.cell.styles.fillColor = [255, 251, 235]; data.cell.styles.textColor = [180, 130, 20]; }
      else if (data.column.index === 0) { /* time column already styled */ }
      else if (raw && data.row.raw[0] !== "Activities") { data.cell.styles.fillColor = [245, 247, 255]; }
    },
  });

  const finalY = doc.lastAutoTable.finalY + 8;
  doc.setFontSize(8);
  doc.setTextColor(120);
  doc.text(`Generated ${new Date().toLocaleDateString()} — EduTrack School Management`, 14, finalY);

  doc.save(`${filename}.pdf`);
}
