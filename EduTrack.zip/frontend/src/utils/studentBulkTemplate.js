// Shared definition for the "Bulk Admission" Excel template — one place
// so the template we generate for download and the parser that reads a
// filled-in copy back never drift apart from each other.
//
// Columns intentionally mirror the single-student Admission Form
// (frontend/src/pages/Student/AdmissionForm.jsx) field-for-field, except
// Campus/Class/Section are typed as plain names here (a human fills a
// spreadsheet cell with a name, not a UUID) — the backend resolves those
// names to the tenant's real records and reports back a clear per-row
// error if a name doesn't match anything.

export const BULK_UPLOAD_COLUMNS = [
  { key: 'first_name', header: 'First Name*', required: true, example: 'Amina' },
  { key: 'middle_name', header: 'Middle Name', required: false, example: '' },
  { key: 'last_name', header: 'Last Name*', required: true, example: 'Juma' },
  { key: 'gender', header: 'Gender (Male/Female/Other)*', required: true, example: 'Female' },
  { key: 'date_of_birth', header: 'Date of Birth (YYYY-MM-DD)*', required: true, example: '2012-04-18' },
  { key: 'admission_number', header: 'Admission Number*', required: true, example: 'ADM-2026-0001' },
  { key: 'admission_date', header: 'Admission Date (YYYY-MM-DD)*', required: true, example: '2026-01-15' },
  { key: 'campus_name', header: 'Campus*', required: true, example: '' },
  { key: 'class_name', header: 'Class', required: false, example: '' },
  { key: 'section_name', header: 'Section', required: false, example: '' },
  { key: 'parent_name', header: 'Parent/Guardian Name', required: false, example: 'Juma Amani' },
  { key: 'parent_phone', header: 'Parent Phone', required: false, example: '255712345678' },
  { key: 'parent_email', header: 'Parent Email', required: false, example: '' },
  { key: 'parent_address', header: 'Parent Address', required: false, example: '' },
  { key: 'address', header: 'Student Address', required: false, example: '' },
  { key: 'city', header: 'City', required: false, example: '' },
  { key: 'state', header: 'Region/State', required: false, example: '' },
  { key: 'country', header: 'Country', required: false, example: 'Tanzania' },
  { key: 'postal_code', header: 'Postal Code', required: false, example: '' },
  { key: 'emergency_contact', header: 'Emergency Contact', required: false, example: '' },
  { key: 'transport_required', header: 'Transport Required (Yes/No)', required: false, example: 'No' },
  { key: 'hostel_required', header: 'Hostel Required (Yes/No)', required: false, example: 'No' },
  { key: 'other_notes', header: 'Other Notes', required: false, example: '' },
];

const HEADER_TO_KEY = new Map(BULK_UPLOAD_COLUMNS.map((c) => [c.header.trim().toLowerCase(), c.key]));
// Also accept the header with its trailing "*" stripped, in case someone
// retypes the header by hand without the asterisk.
BULK_UPLOAD_COLUMNS.forEach((c) => {
  const bare = c.header.replace(/\*$/, '').trim().toLowerCase();
  if (!HEADER_TO_KEY.has(bare)) HEADER_TO_KEY.set(bare, c.key);
});

/** Builds and downloads the .xlsx template, with a "Students" sheet to
 * fill in and a reference sheet listing the exact Campus/Class/Section
 * names this tenant has, so there's no guessing (or typo-ing) required. */
export async function downloadBulkUploadTemplate({ campuses = [], classes = [] }) {
  const XLSX = await import('xlsx');

  const headerRow = BULK_UPLOAD_COLUMNS.map((c) => c.header);
  const exampleRow = BULK_UPLOAD_COLUMNS.map((c) => c.example);
  const studentsSheet = XLSX.utils.aoa_to_sheet([headerRow, exampleRow]);
  studentsSheet['!cols'] = BULK_UPLOAD_COLUMNS.map(() => ({ wch: 22 }));

  const instructionsSheet = XLSX.utils.aoa_to_sheet([
    ['Maelekezo / Instructions'],
    [],
    ['1. Usibadilishe majina ya vichwa vya safu (columns) kwenye sheet ya "Students".'],
    ['   Do not rename the column headers on the "Students" sheet.'],
    ['2. Safu zenye alama ya * ni lazima zijazwe (required).'],
    ['   Columns marked with * are required.'],
    ['3. Andika Campus, Class na Section KAMA YALIVYO kwenye sheet ya "Reference" — herufi kubwa/ndogo hazijalishi lakini majina yanapaswa yafanane.'],
    ['   Type Campus, Class and Section exactly as shown on the "Reference" sheet (case-insensitive, but must match).'],
    ['4. Tarehe ziandikwe kama YYYY-MM-DD, mfano 2026-01-15.'],
    ['   Dates must be written as YYYY-MM-DD, e.g. 2026-01-15.'],
    ['5. Gender iandikwe Male, Female au Other.'],
    ['   Gender must be Male, Female or Other.'],
    ['6. Futa mstari wa mfano (row 2) kabla ya ku-upload, au liache — halitachukuliwa kama halina Admission Number halisi.'],
    ['   Delete the example row (row 2) before uploading, or leave it — it will fail validation harmlessly since it has no real admission number once you overwrite it.'],
  ]);
  instructionsSheet['!cols'] = [{ wch: 100 }];

  const refRowCount = Math.max(campuses.length, classes.length);
  const refRows = [['Campus', 'Class', 'Class Academic Year']];
  for (let i = 0; i < refRowCount; i += 1) {
    refRows.push([
      campuses[i]?.name || '',
      classes[i]?.name || '',
      classes[i]?.academic_year || '',
    ]);
  }
  const referenceSheet = XLSX.utils.aoa_to_sheet(refRows);
  referenceSheet['!cols'] = [{ wch: 22 }, { wch: 22 }, { wch: 18 }];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, studentsSheet, 'Students');
  XLSX.utils.book_append_sheet(wb, referenceSheet, 'Reference');
  XLSX.utils.book_append_sheet(wb, instructionsSheet, 'Maelekezo (Instructions)');
  XLSX.writeFile(wb, 'EduTrack_Bulk_Admission_Template.xlsx');
}

/** Normalizes an Excel date cell — which may arrive as a JS Date (when
 * the cell is formatted as a date), a serial number, or plain text — to
 * a plain YYYY-MM-DD string the backend expects. */
const normalizeDateCell = (value) => {
  if (!value) return '';
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  const str = String(value).trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(str)) return str.slice(0, 10);
  const parsed = new Date(str);
  return Number.isNaN(parsed.getTime()) ? str : parsed.toISOString().slice(0, 10);
};

/** Reads a filled-in template (a browser File) and returns an array of
 * plain row objects keyed by BULK_UPLOAD_COLUMNS' canonical keys, ready
 * to send to studentService.bulkCreate. Rows that are entirely blank are
 * skipped. Throws with a friendly message if the "Students" sheet or its
 * header row can't be found/understood. */
export async function parseBulkUploadFile(file) {
  const XLSX = await import('xlsx');
  const buffer = await file.arrayBuffer();
  const wb = XLSX.read(buffer, { type: 'array', cellDates: true });

  const sheetName = wb.SheetNames.find((n) => n.trim().toLowerCase() === 'students') || wb.SheetNames[0];
  const sheet = wb.Sheets[sheetName];
  if (!sheet) throw new Error('Could not find a "Students" sheet in this file.');

  const aoa = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: false, dateNF: 'yyyy-mm-dd' });
  if (aoa.length === 0) throw new Error('The "Students" sheet is empty.');

  const headerRow = aoa[0].map((h) => String(h || '').trim().toLowerCase());
  const keyForColumn = headerRow.map((h) => HEADER_TO_KEY.get(h) || null);
  if (!keyForColumn.some((k) => k === 'first_name')) {
    throw new Error('This doesn\'t look like the EduTrack bulk admission template — column headers don\'t match. Please download a fresh template.');
  }

  const rows = [];
  for (let r = 1; r < aoa.length; r += 1) {
    const line = aoa[r];
    const isBlank = !line || line.every((cell) => String(cell || '').trim() === '');
    if (isBlank) continue;

    // The real row number in the spreadsheet (row 1 is the header), so messages point at the right line
    // even when blank rows were skipped.
    const row = { __row: r + 1 };
    keyForColumn.forEach((key, colIdx) => {
      if (!key) return;
      let value = line[colIdx];
      if (key === 'date_of_birth' || key === 'admission_date') value = normalizeDateCell(value);
      row[key] = typeof value === 'string' ? value.trim() : value;
    });
    rows.push(row);
  }

  if (rows.length === 0) throw new Error('No student rows were found below the header row.');
  return rows;
}
