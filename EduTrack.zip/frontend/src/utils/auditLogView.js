// Shared by the Activity History list and its detail modal.

export const KIND_STYLES = {
  create: { label: "Created", cls: "bg-green-100 text-green-700 border-green-200" },
  update: { label: "Updated", cls: "bg-blue-100 text-blue-700 border-blue-200" },
  delete: { label: "Deleted", cls: "bg-red-100 text-red-700 border-red-200" },
  auth: { label: "Sign-in", cls: "bg-purple-100 text-purple-700 border-purple-200" },
  action: { label: "Action", cls: "bg-amber-100 text-amber-700 border-amber-200" },
};

export const fieldLabel = (field) => {
  const text = String(field || "").replace(/_id$/, "").replace(/[_-]+/g, " ").trim();
  return text ? text.charAt(0).toUpperCase() + text.slice(1) : String(field);
};
