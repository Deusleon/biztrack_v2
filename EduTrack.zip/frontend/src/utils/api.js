// frontend/src/utils/api.js
import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  // Without a limit a stalled request (slow mobile network, server waking up) leaves the page on "Loading…" forever.
  // After 30 s the request fails with a readable message and the page can offer a retry.
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

/**
 * Turns any axios failure into an object with a readable `.message`.
 *
 * Four shapes arrive here and only the first two used to survive:
 *   1. JSON error body      → { success: false, message: '...' }
 *   2. validation body      → same, plus field errors
 *   3. no response at all   → network failure, timeout, server restarting
 *   4. non-JSON body        → an HTML 502 page from a proxy
 *
 * The original object is preserved on `.original` so anything that needs
 * the status code or response body can still reach it.
 */
const normalizeApiError = (error) => {
  const data = error.response?.data;

  // A JSON body that already explains itself.
  if (data && typeof data === 'object' && data.message) {
    return { ...data, status: error.response.status, original: error };
  }

  // A body that isn't JSON (an HTML error page, usually from a proxy).
  if (data && typeof data !== 'object') {
    return {
      success: false,
      status: error.response.status,
      message: `Server error (HTTP ${error.response.status}). The response wasn't valid JSON.`,
      original: error,
    };
  }

  // JSON, but with no message in it.
  if (data && typeof data === 'object') {
    return {
      ...data,
      success: false,
      status: error.response.status,
      message: data.error || `Request failed (HTTP ${error.response.status}).`,
      original: error,
    };
  }

  // No response reached us at all.
  const offline = typeof navigator !== 'undefined' && navigator.onLine === false;
  const timedOut = error.code === 'ECONNABORTED';
  return {
    success: false,
    status: null,
    message: offline
      ? "You appear to be offline. Check your internet connection and try again."
      : timedOut
        ? 'The server took too long to respond. Try again in a moment.'
        : "Couldn't reach the server. It may be restarting — try again in a moment.",
    original: error,
  };
};

// Response interceptor
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    // The account is waiting for its owner to choose a password. Let the app show
    // the "choose a new password" screen instead of an error on whatever page asked.
    if (error.response?.status === 403 && error.response?.data?.code === 'PASSWORD_CHANGE_REQUIRED') {
      window.dispatchEvent(new CustomEvent('edutrack:password-change-required'));
    }

    if (error.response?.status === 401) {
      // Only clear auth and redirect if we have a token but it's invalid
      // Don't redirect if there's no token (user not logged in)
      const token = localStorage.getItem('token');
      if (token) {
        // Say why, once, on the sign-in page — otherwise the person is just dropped there.
        if (error.response?.data?.code === 'SESSION_EXPIRED') {
          try { sessionStorage.setItem('loginNotice', error.response.data.message); } catch { /* ignore */ }
        }
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        // Only redirect if not already on login page
        if (!window.location.pathname.includes('/login')) {
          window.location.href = '/login';
        }
      }
    }

    // 402 = the tenant's subscription has lapsed past its grace period.
    // Without this, every page would just show a generic error and the
    // school would have no idea why the system stopped working — or where
    // to go to fix it. The subscription page is the one place that still
    // works, so send them there.
    if (error.response?.status === 402 && error.response?.data?.code === 'SUBSCRIPTION_EXPIRED') {
      // The app locks itself (SubscriptionContext) and ProtectedRoute shows the
      // Subscription page — no hard reload needed.
      window.dispatchEvent(new CustomEvent('edutrack:subscription-locked'));
    }

    // Every page reads `err.response?.data?.message || err.message`, so
    // whatever is rejected here MUST carry a `.message`. Rejecting a bare
    // string (which is what a network failure produced) gave those pages
    // `undefined` and showed an empty toast — the error the user actually
    // needed to see was the one they never got.
    return Promise.reject(normalizeApiError(error));
  }
);

export default api;