// PDF/Excel export helpers for the Reports hub. Follows the same
// jsPDF + jspdf-autotable / xlsx pattern as examExport.js so all
// downloadable documents in the app look and behave consistently.

import { formatNumber as formatMoney } from './money';

async function withPDF(orientation = "portrait") {
  const { default: jsPDF } = await import("jspdf");
  const { default: autoTable } = await import("jspdf-autotable");
  const doc = new jsPDF({ orientation });
  return { doc, autoTable };
}

function titleBlock(doc, title, subtitle) {
  doc.setFontSize(14);
  doc.text(title, 14, 15);
  if (subtitle) {
    doc.setFontSize(9);
    doc.setTextColor(100);
    doc.text(subtitle, 14, 21);
    doc.setTextColor(0);
  }
  return subtitle ? 26 : 22;
}

export async function exportFinancialSummaryPDF({ year, rows, totals, filename }) {
  const { doc, autoTable } = await withPDF();
  const startY = titleBlock(doc, `Financial Summary — ${year}`, "Income vs Expenses vs Payroll, by month");
  autoTable(doc, {
    startY,
    head: [["Month", "Income", "Expenses", "Payroll", "Net"]],
    body: rows.map((r) => [r.month_name, formatMoney(r.income), formatMoney(r.expenses), formatMoney(r.payroll), formatMoney(r.net)]),
    foot: [["Total", formatMoney(totals.income), formatMoney(totals.expenses), formatMoney(totals.payroll), formatMoney(totals.net)]],
    styles: { fontSize: 9 },
    headStyles: { fillColor: [99, 102, 241] },
    footStyles: { fillColor: [240, 240, 240], textColor: 20, fontStyle: "bold" },
  });
  doc.save(`${filename}.pdf`);
}

export async function exportFinancialSummaryExcel({ year, rows, totals, filename }) {
  const XLSX = await import("xlsx");
  const wsData = [
    [`Financial Summary — ${year}`], [],
    ["Month", "Income", "Expenses", "Payroll", "Net"],
    ...rows.map((r) => [r.month_name, r.income, r.expenses, r.payroll, r.net]),
    [],
    ["Total", totals.income, totals.expenses, totals.payroll, totals.net],
  ];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Financial Summary");
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

export async function exportFeeCollectionPDF({ rows, totals, filename }) {
  const { doc, autoTable } = await withPDF();
  const startY = titleBlock(doc, "Fee Collection Report", "Expected vs Collected vs Outstanding, by class");
  autoTable(doc, {
    startY,
    head: [["Class", "Students", "Expected", "Collected", "Outstanding", "Rate"]],
    body: rows.map((r) => [r.class_name, r.students, formatMoney(r.expected), formatMoney(r.collected), formatMoney(r.outstanding), r.collection_rate !== null ? `${r.collection_rate}%` : "—"]),
    foot: [["Total", "", formatMoney(totals.expected), formatMoney(totals.collected), formatMoney(totals.outstanding), ""]],
    styles: { fontSize: 9 },
    headStyles: { fillColor: [99, 102, 241] },
    footStyles: { fillColor: [240, 240, 240], textColor: 20, fontStyle: "bold" },
  });
  doc.save(`${filename}.pdf`);
}

export async function exportFeeCollectionExcel({ rows, totals, filename }) {
  const XLSX = await import("xlsx");
  const wsData = [
    ["Fee Collection Report"], [],
    ["Class", "Students", "Expected", "Collected", "Outstanding", "Rate %"],
    ...rows.map((r) => [r.class_name, r.students, r.expected, r.collected, r.outstanding, r.collection_rate]),
    [],
    ["Total", "", totals.expected, totals.collected, totals.outstanding, ""],
  ];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Fee Collection");
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

export async function exportAttendanceSummaryPDF({ start_date, end_date, rows, filename }) {
  const { doc, autoTable } = await withPDF();
  const startY = titleBlock(doc, "Attendance Summary Report", `${start_date} to ${end_date}, by class`);
  autoTable(doc, {
    startY,
    head: [["Class", "Records", "Present", "Absent", "Excused", "Rate"]],
    body: rows.map((r) => [r.class_name, r.total_records, r.present, r.absent, r.excused, `${r.attendance_rate}%`]),
    styles: { fontSize: 9 },
    headStyles: { fillColor: [99, 102, 241] },
  });
  doc.save(`${filename}.pdf`);
}

export async function exportAttendanceSummaryExcel({ start_date, end_date, rows, filename }) {
  const XLSX = await import("xlsx");
  const wsData = [
    [`Attendance Summary — ${start_date} to ${end_date}`], [],
    ["Class", "Records", "Present", "Absent", "Excused", "Rate %"],
    ...rows.map((r) => [r.class_name, r.total_records, r.present, r.absent, r.excused, r.attendance_rate]),
  ];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Attendance Summary");
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

export async function exportEnrollmentPDF({ rows, totals, filename }) {
  const { doc, autoTable } = await withPDF();
  const startY = titleBlock(doc, "Enrollment Report", "Students per class, by gender");
  autoTable(doc, {
    startY,
    head: [["Class", "Level", "Total", "Male", "Female"]],
    body: rows.map((r) => [r.class_name, r.education_level, r.total, r.male, r.female]),
    foot: [["Total", "", totals.total, totals.male, totals.female]],
    styles: { fontSize: 9 },
    headStyles: { fillColor: [99, 102, 241] },
    footStyles: { fillColor: [240, 240, 240], textColor: 20, fontStyle: "bold" },
  });
  doc.save(`${filename}.pdf`);
}

export async function exportEnrollmentExcel({ rows, totals, filename }) {
  const XLSX = await import("xlsx");
  const wsData = [
    ["Enrollment Report"], [],
    ["Class", "Level", "Total", "Male", "Female"],
    ...rows.map((r) => [r.class_name, r.education_level, r.total, r.male, r.female]),
    [],
    ["Total", "", totals.total, totals.male, totals.female],
  ];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Enrollment");
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

// ── Detailed Payments ───────────────────────────────────────────────────
export async function exportDetailedPaymentsPDF({ start_date, end_date, rows, total, filename }) {
  const { doc, autoTable } = await withPDF();
  const startY = titleBlock(doc, "Detailed Payments Report", `${start_date} to ${end_date} — every transaction`);
  autoTable(doc, {
    startY,
    head: [["Date", "Student", "Adm No.", "Fee", "Amount", "Method", "Reference"]],
    body: rows.map((r) => [r.payment_date, r.student_name, r.admission_number, r.fee_structure, formatMoney(r.amount), r.payment_method, r.transaction_id]),
    foot: [["Total", "", "", "", formatMoney(total), "", ""]],
    styles: { fontSize: 8 },
    headStyles: { fillColor: [99, 102, 241] },
    footStyles: { fillColor: [240, 240, 240], textColor: 20, fontStyle: "bold" },
  });
  doc.save(`${filename}.pdf`);
}

export async function exportDetailedPaymentsExcel({ start_date, end_date, rows, total, filename }) {
  const XLSX = await import("xlsx");
  const wsData = [
    [`Detailed Payments — ${start_date} to ${end_date}`], [],
    ["Date", "Student", "Adm No.", "Fee", "Amount", "Method", "Reference"],
    ...rows.map((r) => [r.payment_date, r.student_name, r.admission_number, r.fee_structure, r.amount, r.payment_method, r.transaction_id]),
    [],
    ["Total", "", "", "", total, "", ""],
  ];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Detailed Payments");
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

// ── Detailed Expenses ───────────────────────────────────────────────────
export async function exportDetailedExpensesPDF({ start_date, end_date, rows, total, filename }) {
  const { doc, autoTable } = await withPDF();
  const startY = titleBlock(doc, "Detailed Expenses Report", `${start_date} to ${end_date} — every transaction`);
  autoTable(doc, {
    startY,
    head: [["Date", "Category", "Paid To", "Amount", "Method", "Reference"]],
    body: rows.map((r) => [r.expense_date, r.category, r.payee, formatMoney(r.amount), r.payment_method, r.reference_number]),
    foot: [["Total", "", "", formatMoney(total), "", ""]],
    styles: { fontSize: 8 },
    headStyles: { fillColor: [99, 102, 241] },
    footStyles: { fillColor: [240, 240, 240], textColor: 20, fontStyle: "bold" },
  });
  doc.save(`${filename}.pdf`);
}

export async function exportDetailedExpensesExcel({ start_date, end_date, rows, total, filename }) {
  const XLSX = await import("xlsx");
  const wsData = [
    [`Detailed Expenses — ${start_date} to ${end_date}`], [],
    ["Date", "Category", "Paid To", "Amount", "Method", "Reference", "Description"],
    ...rows.map((r) => [r.expense_date, r.category, r.payee, r.amount, r.payment_method, r.reference_number, r.description]),
    [],
    ["Total", "", "", total, "", "", ""],
  ];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Detailed Expenses");
  XLSX.writeFile(wb, `${filename}.xlsx`);
}
