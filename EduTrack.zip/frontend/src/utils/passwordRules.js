// The password rule, as the server applies it (backend utils/passwords.js): at
// least 8 characters with both letters and numbers. Used for the live checklists
// and the quick checks before submitting — the server is the real judge.
export const MIN_PASSWORD_LENGTH = 8;
export const PASSWORD_RULE_TEXT = `Use at least ${MIN_PASSWORD_LENGTH} characters, with both letters and numbers.`;

export const hasLetter = (v) => /[A-Za-z]/.test(v);
export const hasNumber = (v) => /\d/.test(v);
export const isStrongPassword = (v) => typeof v === 'string' && v.length >= MIN_PASSWORD_LENGTH && hasLetter(v) && hasNumber(v);

/** The checklist lines shown under a "new password" field. */
export const passwordChecks = (value) => [
  { ok: value.length >= MIN_PASSWORD_LENGTH, label: `At least ${MIN_PASSWORD_LENGTH} characters` },
  { ok: hasLetter(value), label: 'Contains letters' },
  { ok: hasNumber(value), label: 'Contains numbers' },
];
