// Shared PDF/Excel export helpers for attendance downloads — both the
// whole-class register (AttendanceView.jsx) and a single student's
// attendance (StudentView.jsx). PDFs use the shared letterhead/theme
// helpers in utils/pdfTheme.js so they look like a real school document
// (logo, colored banner, colored status cells matching the app's own
// P/A/L/E/H colors) rather than a plain data dump.

import { getThemeColors, attendancePdfColors, drawLetterhead, drawPdfFooter } from './pdfTheme';

export const STATUS_CODE = { present: 'P', absent: 'A', late: 'L', excused: 'E', half_day: 'H' };
export const STATUS_LABEL = { present: 'Present', absent: 'Absent', late: 'Late', excused: 'Excused', half_day: 'Half Day' };
const CODE_TO_STATUS = Object.fromEntries(Object.entries(STATUS_CODE).map(([k, v]) => [v, k]));
const STATUS_ORDER = ['present', 'absent', 'late', 'excused', 'half_day'];

/** Every calendar date in a "YYYY-MM" month, as ISO strings — used so a
 * register always shows the whole month's columns (including days no
 * one was marked on, e.g. weekends or a day attendance wasn't taken),
 * not just the days that happen to have data. */
export function daysInMonthList(yyyyMm) {
  const [y, m] = yyyyMm.split('-').map(Number);
  const count = new Date(y, m, 0).getDate();
  return Array.from({ length: count }, (_, i) => `${yyyyMm}-${String(i + 1).padStart(2, '0')}`);
}

/** Turns a flat list of Attendance records (each with student/user/date/
 * status) into a day-by-day matrix: one row per student, one column per
 * date — the classic paper-register shape.
 *
 * By default the date columns are only the ones actually present in the
 * records. Pass `fullDates` (e.g. from daysInMonthList) to force every
 * calendar day of the month to get its own column even when nobody was
 * marked that day — the day just shows as blank rather than being left
 * out of the register entirely. Either way, the attendance-rate totals
 * are always computed only from real records, never from the blank
 * filler days. */
export function pivotClassRegister(records, { fullDates } = {}) {
  const studentsById = new Map();
  const datesSet = new Set(fullDates || []);
  const matrix = {}; // studentId -> { date -> status }
  const remarks = {}; // studentId -> { date -> remarks text }
  const totals = {}; // studentId -> counts

  records.forEach((r) => {
    const sid = r.student_id || r.student?.id;
    if (!sid) return;
    if (!studentsById.has(sid)) {
      studentsById.set(sid, {
        id: sid,
        name: `${r.student?.user?.first_name || ''} ${r.student?.user?.last_name || ''}`.trim() || 'Unknown',
        admission_number: r.student?.admission_number || '',
      });
      matrix[sid] = {};
      remarks[sid] = {};
      totals[sid] = { present: 0, absent: 0, late: 0, excused: 0, half_day: 0, total: 0 };
    }
    const date = String(r.date).slice(0, 10);
    datesSet.add(date);
    matrix[sid][date] = r.status;
    if (r.remarks && String(r.remarks).trim()) remarks[sid][date] = String(r.remarks).trim();
    if (totals[sid][r.status] !== undefined) totals[sid][r.status] += 1;
    totals[sid].total += 1;
  });

  Object.values(totals).forEach((t) => {
    const attended = t.total - t.absent;
    t.pct = t.total > 0 ? Math.round((attended / t.total) * 1000) / 10 : 0;
  });

  const students = [...studentsById.values()].sort((a, b) => a.name.localeCompare(b.name));
  const dates = [...datesSet].sort();
  return { students, dates, matrix, remarks, totals };
}

/** Groups the same flat records into a per-student, per-month summary —
 * used for the "whole year" export's quick-overview page. Month keys
 * are "YYYY-MM". */
export function buildMonthlySummary(records) {
  const studentsById = new Map();
  const monthsSet = new Set();
  const byStudentMonth = {};

  records.forEach((r) => {
    const sid = r.student_id || r.student?.id;
    if (!sid) return;
    if (!studentsById.has(sid)) {
      studentsById.set(sid, {
        id: sid,
        name: `${r.student?.user?.first_name || ''} ${r.student?.user?.last_name || ''}`.trim() || 'Unknown',
        admission_number: r.student?.admission_number || '',
      });
      byStudentMonth[sid] = {};
    }
    const month = String(r.date).slice(0, 7);
    monthsSet.add(month);
    if (!byStudentMonth[sid][month]) byStudentMonth[sid][month] = { present: 0, absent: 0, late: 0, excused: 0, half_day: 0, total: 0 };
    const bucket = byStudentMonth[sid][month];
    if (bucket[r.status] !== undefined) bucket[r.status] += 1;
    bucket.total += 1;
  });

  const students = [...studentsById.values()].sort((a, b) => a.name.localeCompare(b.name));
  const months = [...monthsSet].sort();
  return { students, months, byStudentMonth };
}

const monthLabelOf = (yyyyMm) => {
  const [y, m] = yyyyMm.split('-').map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
};
const dayLabel = (isoDate) => {
  const d = new Date(isoDate);
  return String(d.getDate());
};

function collectRemarks(pivoted) {
  const rows = [];
  pivoted.students.forEach((s) => {
    Object.entries(pivoted.remarks[s.id] || {}).forEach(([date, text]) => {
      rows.push({ date, name: s.name, admission_number: s.admission_number, text });
    });
  });
  return rows.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name));
}

const markCell = (pivoted, sid, date) => {
  const status = pivoted.matrix[sid]?.[date];
  if (!status) return '—';
  const code = STATUS_CODE[status] || '?';
  return pivoted.remarks[sid]?.[date] ? `${code}*` : code;
};

const colorDayColumns = (dayColStart, dayColEnd, colors) => (data) => {
  if (data.section !== 'body') return;
  if (data.column.index < dayColStart || data.column.index > dayColEnd) return;
  const raw = String(data.cell.raw ?? '').trim();
  if (!raw || raw === '—') return;
  const status = CODE_TO_STATUS[raw[0]];
  const colorSet = status ? colors[status] : null;
  if (colorSet) {
    data.cell.styles.fillColor = colorSet.fill;
    data.cell.styles.textColor = colorSet.text;
    data.cell.styles.fontStyle = 'bold';
    data.cell.styles.halign = 'center';
  }
};

function drawColorLegend(doc, colors, x, y) {
  doc.setFontSize(7.5);
  let cx = x;
  STATUS_ORDER.forEach((status) => {
    const c = colors[status];
    doc.setFillColor(...c.fill);
    doc.setDrawColor(...c.text);
    doc.setLineWidth(0.2);
    doc.rect(cx, y - 2.6, 3, 3, 'FD');
    doc.setTextColor(60, 60, 60);
    const label = `${STATUS_CODE[status]} = ${STATUS_LABEL[status]}`;
    doc.text(label, cx + 4.5, y);
    cx += doc.getTextWidth(label) + 10;
  });
  doc.setTextColor(120, 120, 120);
  doc.text('* = has a remark, see below', cx, y);
  doc.setTextColor(0, 0, 0);
  return y + 5;
}

function drawMonthRegisterTable(doc, autoTable, { className, sectionName, mLabel, pivoted, startY, theme, colors }) {
  doc.setFontSize(11);
  doc.setFont(undefined, 'bold');
  doc.setTextColor(...theme.primaryDark);
  doc.text(`${className}${sectionName ? ` ${sectionName}` : ''} — ${mLabel}`, 14, startY);
  doc.setTextColor(0, 0, 0);
  doc.setFont(undefined, 'normal');

  const dayColStart = 3;
  const dayColEnd = dayColStart + pivoted.dates.length - 1;
  const head = [['#', 'Adm No.', 'Student', ...pivoted.dates.map(dayLabel), 'Present %']];
  const body = pivoted.students.map((s, i) => [
    i + 1, s.admission_number, s.name,
    ...pivoted.dates.map((d) => markCell(pivoted, s.id, d)),
    `${pivoted.totals[s.id]?.pct ?? 0}%`,
  ]);

  autoTable(doc, {
    head, body, startY: startY + 4,
    margin: { left: 14, right: 14 },
    styles: { fontSize: 6.5, cellPadding: 1 },
    headStyles: { fillColor: theme.primary, textColor: 255 },
    columnStyles: { 0: { cellWidth: 7 }, 2: { cellWidth: 32 } },
    didParseCell: colorDayColumns(dayColStart, dayColEnd, colors),
  });

  let y = doc.lastAutoTable.finalY + 5;
  y = drawColorLegend(doc, colors, 14, y);

  const remarkRows = collectRemarks(pivoted);
  if (remarkRows.length > 0) {
    doc.setFontSize(8);
    doc.setFont(undefined, 'bold');
    doc.text('Remarks:', 14, y);
    doc.setFont(undefined, 'normal');
    y += 4;
    remarkRows.forEach((r) => {
      doc.setFontSize(7.5);
      doc.text(`${dayLabel(r.date)}/${r.date.slice(5, 7)} — ${r.name}: ${r.text}`, 16, y);
      y += 3.6;
    });
  }
  return y + 4;
}

const estimateMonthBlockHeight = (studentCount, remarkCount = 0) =>
  6 + 5 + studentCount * 4.4 + 5 + 6 + (remarkCount > 0 ? 8 + remarkCount * 3.6 : 0) + 8;

export async function exportClassRegisterPDF({ school, className, sectionName, monthLabel: mLabel, pivoted, filename }) {
  const { default: jsPDF } = await import('jspdf');
  const { default: autoTable } = await import('jspdf-autotable');
  const doc = new jsPDF({ orientation: 'landscape' });
  const theme = getThemeColors();
  const colors = attendancePdfColors(theme);

  let y = await drawLetterhead(doc, { school, title: 'ATTENDANCE REGISTER', theme });
  doc.setFontSize(10);
  doc.setTextColor(90, 90, 90);
  doc.text(`${className}${sectionName ? ` ${sectionName}` : ''} — ${mLabel}`, doc.internal.pageSize.getWidth() / 2, y, { align: 'center' });
  doc.setTextColor(0, 0, 0);
  y += 6;

  const dayColStart = 3;
  const dayColEnd = dayColStart + pivoted.dates.length - 1;
  const head = [['#', 'Adm No.', 'Student', ...pivoted.dates.map(dayLabel), 'Present %']];
  const body = pivoted.students.map((s, i) => [
    i + 1, s.admission_number, s.name,
    ...pivoted.dates.map((d) => markCell(pivoted, s.id, d)),
    `${pivoted.totals[s.id]?.pct ?? 0}%`,
  ]);

  autoTable(doc, {
    head, body, startY: y,
    margin: { left: 14, right: 14 },
    styles: { fontSize: 6.5, cellPadding: 1 },
    headStyles: { fillColor: theme.primary, textColor: 255 },
    columnStyles: { 0: { cellWidth: 7 }, 2: { cellWidth: 32 } },
    didParseCell: colorDayColumns(dayColStart, dayColEnd, colors),
  });

  let ly = doc.lastAutoTable.finalY + 6;
  ly = drawColorLegend(doc, colors, 14, ly);

  const remarkRows = collectRemarks(pivoted);
  if (remarkRows.length > 0) {
    doc.setFontSize(8.5);
    doc.setFont(undefined, 'bold');
    doc.text('Remarks:', 14, ly);
    doc.setFont(undefined, 'normal');
    ly += 4.5;
    remarkRows.forEach((r) => {
      if (ly > doc.internal.pageSize.getHeight() - 12) { doc.addPage(); ly = 15; }
      doc.setFontSize(8);
      doc.text(`${dayLabel(r.date)}/${r.date.slice(5, 7)} — ${r.name}: ${r.text}`, 16, ly);
      ly += 4;
    });
  }

  drawPdfFooter(doc);
  doc.save(`${filename}.pdf`);
}

export async function exportClassRegisterExcel({ school, className, sectionName, monthLabel: mLabel, pivoted, filename }) {
  const XLSX = await import('xlsx');
  const remarkRows = collectRemarks(pivoted);
  const legendLine = STATUS_ORDER.map((s) => `${STATUS_CODE[s]} = ${STATUS_LABEL[s]}`).join('   ') + '   |   * = has a remark, see below';
  const wsData = [
    [`${school?.name || 'School'} — Attendance Register`],
    [`${className}${sectionName ? ` ${sectionName}` : ''} — ${mLabel}`],
    [],
    ['#', 'Adm No.', 'Student', ...pivoted.dates, 'Present %'],
    ...pivoted.students.map((s, i) => [
      i + 1, s.admission_number, s.name,
      ...pivoted.dates.map((d) => markCell(pivoted, s.id, d)),
      pivoted.totals[s.id]?.pct ?? 0,
    ]),
    [],
    [legendLine],
    ...(remarkRows.length > 0
      ? [[], ['Remarks:'], ['Date', 'Student', 'Admission No.', 'Remark'],
        ...remarkRows.map((r) => [r.date, r.name, r.admission_number, r.text])]
      : []),
  ];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Register');
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

export async function exportYearlySummaryPDF({ school, className, sectionName, year, records, filename }) {
  const { default: jsPDF } = await import('jspdf');
  const { default: autoTable } = await import('jspdf-autotable');
  const doc = new jsPDF({ orientation: 'landscape' });
  const theme = getThemeColors();
  const colors = attendancePdfColors(theme);
  const PAGE_BOTTOM = doc.internal.pageSize.getHeight() - 12;

  const summary = buildMonthlySummary(records);

  let y = await drawLetterhead(doc, { school, title: 'YEARLY ATTENDANCE SUMMARY', theme });
  doc.setFontSize(10);
  doc.setTextColor(90, 90, 90);
  doc.text(`${className}${sectionName ? ` ${sectionName}` : ''} — ${year}`, doc.internal.pageSize.getWidth() / 2, y, { align: 'center' });
  doc.setTextColor(0, 0, 0);
  y += 6;

  const head = [['#', 'Adm No.', 'Student', ...summary.months.map(monthLabelOf), 'Overall %']];
  const body = summary.students.map((s, i) => {
    const monthPcts = summary.months.map((m) => {
      const b = summary.byStudentMonth[s.id]?.[m];
      if (!b || b.total === 0) return '—';
      return `${Math.round(((b.total - b.absent) / b.total) * 100)}%`;
    });
    const all = summary.months.reduce((acc, m) => {
      const b = summary.byStudentMonth[s.id]?.[m];
      if (b) { acc.total += b.total; acc.absent += b.absent; }
      return acc;
    }, { total: 0, absent: 0 });
    const overall = all.total > 0 ? Math.round(((all.total - all.absent) / all.total) * 100) : 0;
    return [i + 1, s.admission_number, s.name, ...monthPcts, `${overall}%`];
  });

  autoTable(doc, {
    head, body, startY: y,
    styles: { fontSize: 8, cellPadding: 1.5 },
    headStyles: { fillColor: theme.primary, textColor: 255 },
  });

  let ny = doc.lastAutoTable.finalY + 10;
  summary.months.forEach((month) => {
    const monthRecords = records.filter((r) => String(r.date).slice(0, 7) === month);
    const pivoted = pivotClassRegister(monthRecords, { fullDates: daysInMonthList(month) });

    if (ny + estimateMonthBlockHeight(pivoted.students.length, collectRemarks(pivoted).length) > PAGE_BOTTOM) {
      doc.addPage();
      ny = 15;
    }
    ny = drawMonthRegisterTable(doc, autoTable, { className, sectionName, mLabel: monthLabelOf(month), pivoted, startY: ny, theme, colors }) + 4;
  });

  drawPdfFooter(doc);
  doc.save(`${filename}.pdf`);
}

export async function exportYearlySummaryExcel({ school, className, sectionName, year, records, filename }) {
  const XLSX = await import('xlsx');
  const summary = buildMonthlySummary(records);
  const wb = XLSX.utils.book_new();
  const legendLine = STATUS_ORDER.map((s) => `${STATUS_CODE[s]} = ${STATUS_LABEL[s]}`).join('   ') + '   |   * = has a remark, see below';

  const summaryData = [
    [`${school?.name || 'School'} — Yearly Attendance Summary`],
    [`${className}${sectionName ? ` ${sectionName}` : ''} — ${year}`],
    [],
    ['#', 'Adm No.', 'Student', ...summary.months.map(monthLabelOf), 'Overall %'],
    ...summary.students.map((s, i) => {
      const monthPcts = summary.months.map((m) => {
        const b = summary.byStudentMonth[s.id]?.[m];
        return b && b.total > 0 ? Math.round(((b.total - b.absent) / b.total) * 100) : '';
      });
      const all = summary.months.reduce((acc, m) => {
        const b = summary.byStudentMonth[s.id]?.[m];
        if (b) { acc.total += b.total; acc.absent += b.absent; }
        return acc;
      }, { total: 0, absent: 0 });
      const overall = all.total > 0 ? Math.round(((all.total - all.absent) / all.total) * 100) : '';
      return [i + 1, s.admission_number, s.name, ...monthPcts, overall];
    }),
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(summaryData), 'Summary');

  summary.months.forEach((month) => {
    const monthRecords = records.filter((r) => String(r.date).slice(0, 7) === month);
    const pivoted = pivotClassRegister(monthRecords, { fullDates: daysInMonthList(month) });
    const remarkRows = collectRemarks(pivoted);
    const sheetData = [
      [`${school?.name || 'School'} — ${monthLabelOf(month)}`],
      [`${className}${sectionName ? ` ${sectionName}` : ''}`],
      [],
      ['#', 'Adm No.', 'Student', ...pivoted.dates, 'Present %'],
      ...pivoted.students.map((s, i) => [
        i + 1, s.admission_number, s.name,
        ...pivoted.dates.map((d) => markCell(pivoted, s.id, d)),
        pivoted.totals[s.id]?.pct ?? 0,
      ]),
      [],
      [legendLine],
      ...(remarkRows.length > 0
        ? [[], ['Remarks:'], ['Date', 'Student', 'Admission No.', 'Remark'],
          ...remarkRows.map((r) => [r.date, r.name, r.admission_number, r.text])]
        : []),
    ];
    const sheetName = monthLabelOf(month).replace(/\s+/g, ' ').slice(0, 31);
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(sheetData), sheetName);
  });

  XLSX.writeFile(wb, `${filename}.xlsx`);
}

export async function exportStudentAttendancePDF({ school, student, rangeLabel, records, filename }) {
  const { default: jsPDF } = await import('jspdf');
  const { default: autoTable } = await import('jspdf-autotable');
  const doc = new jsPDF({ orientation: 'portrait' });
  const theme = getThemeColors();
  const colors = attendancePdfColors(theme);

  let y = await drawLetterhead(doc, { school, title: 'STUDENT ATTENDANCE', theme });
  doc.setFontSize(10);
  doc.setTextColor(90, 90, 90);
  doc.text(`${student.name} (${student.admission_number}) — ${rangeLabel}`, doc.internal.pageSize.getWidth() / 2, y, { align: 'center' });
  doc.setTextColor(0, 0, 0);
  y += 6;

  const sorted = [...records].sort((a, b) => String(a.date).localeCompare(String(b.date)));
  const hasRemarks = sorted.some((r) => r.remarks && String(r.remarks).trim());

  if (hasRemarks) {
    const head = [['#', 'Date', 'Status', 'Remarks']];
    const body = sorted.map((r, i) => [i + 1, String(r.date).slice(0, 10), STATUS_CODE[r.status] || r.status, r.remarks || '—']);
    autoTable(doc, {
      head, body, startY: y,
      styles: { fontSize: 9, cellPadding: 2 },
      headStyles: { fillColor: theme.primary, textColor: 255 },
      didParseCell: (data) => {
        if (data.section !== 'body' || data.column.index !== 2) return;
        const status = CODE_TO_STATUS[String(data.cell.raw ?? '')];
        const colorSet = status ? colors[status] : null;
        if (colorSet) {
          data.cell.styles.fillColor = colorSet.fill;
          data.cell.styles.textColor = colorSet.text;
          data.cell.styles.fontStyle = 'bold';
        }
      },
    });
  } else {
    const COLS = 7;
    const rows = [];
    for (let i = 0; i < sorted.length; i += COLS) {
      const chunk = sorted.slice(i, i + COLS);
      const row = chunk.map((r) => `${String(r.date).slice(8, 10)}\n${STATUS_CODE[r.status] || '?'}`);
      while (row.length < COLS) row.push('');
      rows.push(row);
    }
    autoTable(doc, {
      body: rows, startY: y,
      styles: { fontSize: 10, cellPadding: 3, halign: 'center', valign: 'middle', minCellHeight: 14 },
      theme: 'grid',
      didParseCell: (data) => {
        if (data.section !== 'body') return;
        const raw = String(data.cell.raw ?? '');
        const code = raw.split('\n')[1];
        const status = code ? CODE_TO_STATUS[code] : null;
        const colorSet = status ? colors[status] : null;
        if (colorSet) {
          data.cell.styles.fillColor = colorSet.fill;
          data.cell.styles.textColor = colorSet.text;
          data.cell.styles.fontStyle = 'bold';
        }
      },
    });
  }

  let ly = doc.lastAutoTable.finalY + 6;
  ly = drawColorLegend(doc, colors, 14, ly);
  ly += 3;

  const counts = { present: 0, absent: 0, late: 0, excused: 0, half_day: 0 };
  sorted.forEach((r) => { if (counts[r.status] !== undefined) counts[r.status] += 1; });
  const total = sorted.length;
  const pct = total > 0 ? Math.round(((total - counts.absent) / total) * 1000) / 10 : 0;

  doc.setFontSize(9.5);
  doc.text(`P: ${counts.present}   A: ${counts.absent}   L: ${counts.late}   E: ${counts.excused}   H: ${counts.half_day}`, 14, ly);
  ly += 6;
  doc.setFont(undefined, 'bold');
  doc.setTextColor(...theme.primaryDark);
  doc.text(`Attendance Rate: ${pct}%`, 14, ly);
  doc.setTextColor(0, 0, 0);
  doc.setFont(undefined, 'normal');

  drawPdfFooter(doc);
  doc.save(`${filename}.pdf`);
}

export async function exportStudentAttendanceExcel({ school, student, rangeLabel, records, filename }) {
  const XLSX = await import('xlsx');
  const sorted = [...records].sort((a, b) => String(a.date).localeCompare(String(b.date)));
  const hasRemarks = sorted.some((r) => r.remarks && String(r.remarks).trim());
  const legendLine = STATUS_ORDER.map((s) => `${STATUS_CODE[s]} = ${STATUS_LABEL[s]}`).join('   ');

  const header = [
    [`${school?.name || 'School'} — Student Attendance`],
    [`${student.name} (${student.admission_number}) — ${rangeLabel}`],
    [],
  ];

  let bodyRows;
  if (hasRemarks) {
    bodyRows = [
      ['#', 'Date', 'Status', 'Remarks'],
      ...sorted.map((r, i) => [i + 1, String(r.date).slice(0, 10), STATUS_CODE[r.status] || r.status, r.remarks || '']),
    ];
  } else {
    const COLS = 7;
    const headerRow = [];
    for (let c = 0; c < COLS; c += 1) headerRow.push('Day', 'St.');
    bodyRows = [headerRow];
    for (let i = 0; i < sorted.length; i += COLS) {
      const chunk = sorted.slice(i, i + COLS);
      const row = [];
      chunk.forEach((r) => { row.push(String(r.date).slice(8, 10), STATUS_CODE[r.status] || '?'); });
      while (row.length < COLS * 2) row.push('');
      bodyRows.push(row);
    }
  }

  const wsData = [...header, ...bodyRows, [], [legendLine]];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Attendance');
  XLSX.writeFile(wb, `${filename}.xlsx`);
}