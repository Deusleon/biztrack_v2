/**
 * Academic year formatting — handles schools that use a single-year format
 * for Primary/O-Level ("2025") and a two-year span for A-Level ("2025-2026").
 * Mirrors backend/src/utils/academicYear.js so both sides agree.
 */

export const usesYearSpan = (educationLevel) => educationLevel === 'a_level';

export const formatAcademicYear = (baseYear, educationLevel) => {
  const year = parseInt(baseYear, 10);
  if (Number.isNaN(year)) return '';
  return usesYearSpan(educationLevel) ? `${year}-${year + 1}` : `${year}`;
};

export const currentBaseYear = () => new Date().getFullYear();

export const extractBaseYear = (academicYearString) => {
  const match = String(academicYearString || '').match(/^\d{4}/);
  return match ? parseInt(match[0], 10) : currentBaseYear();
};

/** Given the school-wide "current academic year" (as picked in the header —
 * always stored/displayed as a range, e.g. "2025-2026") and a specific
 * class's education level, returns the correctly-formatted academic year
 * for THAT class — the way a single global year selector stays useful for
 * a school mixing Primary/O-Level (single-year) and A-Level (span) classes. */
export const resolveAcademicYearForLevel = (globalAcademicYear, educationLevel) =>
  formatAcademicYear(extractBaseYear(globalAcademicYear), educationLevel);

/** Generate selectable academic years around the current one, formatted
 * for the given education level ('primary' | 'o_level' | 'a_level'). */
export const academicYearOptions = (educationLevel, span = 2) => {
  const base = currentBaseYear();
  const options = [];
  for (let y = base - span; y <= base + span; y++) {
    options.push(formatAcademicYear(y, educationLevel));
  }
  return options;
};

export const EDUCATION_LEVELS = [
  { value: 'primary', label: 'Primary (Kindergarten – Std 6)' },
  { value: 'o_level', label: 'O-Level (Form 1 – 4)' },
  { value: 'a_level', label: 'A-Level (Form 5 – 6)' },
];
