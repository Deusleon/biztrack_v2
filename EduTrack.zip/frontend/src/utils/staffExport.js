// Builds a formal, letterhead-style "Staff Profile" PDF — the CV-like
// document Admin/HR can hand to the staff member or file for records.
// Mirrors the layout conventions of the exam Report Card (utils/examExport.js):
// jsPDF + autoTable directly, school letterhead at top, boxed sections below.
// Colors come from the school's own live theme (utils/pdfTheme.js) rather
// than a fixed color, so this matches whatever the school has picked in
// Settings — same as every other export in the app.

import { getThemeColors, tint, loadImageDataUrl } from './pdfTheme';

const fmtDate = (d) => {
  if (!d) return null;
  try { return new Date(d).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }); }
  catch { return d; }
};

export async function exportStaffProfilePDF({ school, staff }) {
  const { default: jsPDF } = await import("jspdf");
  const { default: autoTable } = await import("jspdf-autotable");
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const theme = getThemeColors();
  const pageWidth = doc.internal.pageSize.getWidth();
  const marginX = 16;
  let y = 18;

  doc.setDrawColor(20, 20, 20);
  doc.setLineWidth(0.6);
  doc.rect(8, 8, pageWidth - 16, doc.internal.pageSize.getHeight() - 16);

  // Letterhead
  const logo = await loadImageDataUrl(school?.logo_url);
  if (logo) {
    const logoHeight = 16;
    const logoWidth = Math.min((logo.width / logo.height) * logoHeight, 46);
    doc.addImage(logo.dataUrl, "PNG", marginX, y - 6, logoWidth, logoHeight);
  }
  doc.setFont(undefined, "bold");
  doc.setFontSize(15);
  doc.text(school?.name || "School Name", pageWidth / 2, y, { align: "center" });
  y += 6;
  doc.setFont(undefined, "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(90);
  const addressLine = [school?.address, school?.city, school?.country].filter(Boolean).join(", ");
  if (addressLine) { doc.text(addressLine, pageWidth / 2, y, { align: "center" }); y += 4; }
  const contactLine = [school?.phone, school?.email].filter(Boolean).join("   •   ");
  if (contactLine) { doc.text(contactLine, pageWidth / 2, y, { align: "center" }); y += 4; }
  doc.setTextColor(0);
  y += 2;
  doc.setDrawColor(...theme.primary);
  doc.setLineWidth(0.8);
  doc.line(marginX, y, pageWidth - marginX, y);
  y += 7;

  // Banner
  doc.setFillColor(...theme.primary);
  const bannerText = "STAFF PROFILE";
  doc.setFont(undefined, "bold");
  doc.setFontSize(11);
  const bannerWidth = doc.getTextWidth(bannerText) + 16;
  doc.roundedRect((pageWidth - bannerWidth) / 2, y - 5, bannerWidth, 8, 1, 1, "F");
  doc.setTextColor(255, 255, 255);
  doc.text(bannerText, pageWidth / 2, y, { align: "center" });
  doc.setTextColor(0);
  y += 12;

  const fullName = [staff.user?.first_name, staff.user?.middle_name, staff.user?.last_name].filter(Boolean).join(" ");

  // Photo (top-right) + name/role block (left)
  const photo = await loadImageDataUrl(staff.user?.avatar);
  const photoSize = 28;
  if (photo) {
    doc.setDrawColor(180);
    doc.rect(pageWidth - marginX - photoSize, y - 4, photoSize, photoSize);
    doc.addImage(photo.dataUrl, "PNG", pageWidth - marginX - photoSize, y - 4, photoSize, photoSize);
  }
  doc.setFont(undefined, "bold");
  doc.setFontSize(14);
  doc.text(fullName || "—", marginX, y + 2);
  doc.setFont(undefined, "normal");
  doc.setFontSize(10);
  doc.setTextColor(90);
  doc.text(staff.designation || staff.user?.role?.replace("_", " ") || "", marginX, y + 8);
  doc.setTextColor(0);
  y += photo ? photoSize + 2 : 14;

  doc.setDrawColor(180);
  doc.setLineWidth(0.2);
  doc.line(marginX, y, pageWidth - marginX, y);
  y += 7;

  const col2X = pageWidth / 2 + 5;
  const labelColWidth = 30;
  const sectionHeaderFill = tint(theme.primary, 0.12);
  const sectionHeader = (title) => {
    doc.setFont(undefined, "bold");
    doc.setFontSize(10.5);
    doc.setFillColor(...sectionHeaderFill);
    doc.rect(marginX, y - 4.5, pageWidth - marginX * 2, 6.5, "F");
    doc.setTextColor(...theme.primaryDark);
    doc.text(title, marginX + 2, y);
    doc.setTextColor(0);
    doc.setFont(undefined, "normal");
    y += 8;
  };
  const twoColRows = (rows) => {
    for (let i = 0; i < rows.length; i += 2) {
      const [l1, v1] = rows[i];
      const right = rows[i + 1];
      doc.setFontSize(9);
      doc.setTextColor(110); doc.text(l1, marginX, y);
      doc.setTextColor(0); doc.text(String(v1 ?? "—"), marginX + labelColWidth, y);
      if (right) {
        const [l2, v2] = right;
        doc.setTextColor(110); doc.text(l2, col2X, y);
        doc.setTextColor(0); doc.text(String(v2 ?? "—"), col2X + labelColWidth, y);
      }
      doc.setTextColor(0);
      y += 6;
    }
    y += 2;
  };

  sectionHeader("PERSONAL INFORMATION");
  twoColRows([
    ["Email:", staff.user?.email], ["Phone:", staff.user?.phone],
    ["Date of Birth:", fmtDate(staff.date_of_birth)], ["Gender:", staff.gender],
    ["Marital Status:", staff.marital_status], ["National ID:", staff.national_id],
    ["Blood Group:", staff.blood_group], ["", ""],
  ]);

  sectionHeader("EMPLOYMENT DETAILS");
  twoColRows([
    ["Employee No.:", staff.employee_number], ["Campus:", staff.campus?.name],
    ["Department:", staff.department], ["Designation:", staff.designation],
    ["Contract Type:", staff.contract_type?.replace("_", " ")], ["Joining Date:", fmtDate(staff.joining_date)],
    ["Experience:", staff.experience_years != null ? `${staff.experience_years} yrs` : null], ["Status:", staff.status],
  ]);

  if (Array.isArray(staff.qualifications) && staff.qualifications.length > 0) {
    sectionHeader("QUALIFICATIONS");
    autoTable(doc, {
      startY: y - 3,
      margin: { left: marginX, right: marginX },
      head: [["Qualification", "Institution", "Year"]],
      body: staff.qualifications.map((q) => [
        q.qualification || q.name || "—", q.institution || "—", q.year || q.year_completed || "—",
      ]),
      styles: { fontSize: 8.5, cellPadding: 1.8, lineColor: [200, 200, 200], lineWidth: 0.2 },
      headStyles: { fillColor: theme.primary, textColor: 255 },
    });
    y = doc.lastAutoTable.finalY + 6;
  }

  sectionHeader("ADDRESS & EMERGENCY CONTACT");
  const addr = [staff.address, staff.city, staff.country].filter(Boolean).join(", ") || "Not recorded";
  doc.setFontSize(9);
  doc.setTextColor(110); doc.text("Address:", marginX, y);
  doc.setTextColor(0);
  const addrLines = doc.splitTextToSize(addr, pageWidth - marginX * 2 - labelColWidth);
  doc.text(addrLines, marginX + labelColWidth, y);
  y += addrLines.length * 4.5 + 2;
  twoColRows([
    ["Emergency Contact:", staff.emergency_contact_name || null],
    ["Phone:", staff.emergency_contact],
  ]);

  if (staff.notes) {
    sectionHeader("NOTES");
    doc.setFontSize(9);
    const noteLines = doc.splitTextToSize(staff.notes, pageWidth - marginX * 2);
    doc.text(noteLines, marginX, y);
    y += noteLines.length * 4.5 + 4;
  }

  // Footer / signature area — fixed to bottom of the printable area
  const pageHeight = doc.internal.pageSize.getHeight();
  const sigY = pageHeight - 26;
  doc.setDrawColor(150);
  doc.setLineWidth(0.2);
  doc.line(marginX, sigY, marginX + 55, sigY);
  doc.line(pageWidth - marginX - 55, sigY, pageWidth - marginX, sigY);
  doc.setFontSize(8);
  doc.setTextColor(100);
  doc.text("Staff Signature", marginX, sigY + 4);
  doc.text("Authorized Signature (HR/Admin)", pageWidth - marginX - 55, sigY + 4);
  doc.text(`Generated on ${new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}`, pageWidth / 2, pageHeight - 12, { align: "center" });

  const safeName = (fullName || "staff").replace(/[^a-z0-9]+/gi, "_");
  doc.save(`Staff_Profile_${safeName}.pdf`);
}