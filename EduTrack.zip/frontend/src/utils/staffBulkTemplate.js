// Shared definition for the "Bulk Staff Upload" Excel template — one place, so the template we
// generate for download and the parser that reads a filled-in copy back never drift apart.
// Campus is typed as a plain name (a human fills a spreadsheet cell with a name, not an id) and
// the server resolves it. Teaching subjects, documents and "reports to" are added afterwards on
// the staff record (Staff → Edit), because they need picking from lists.

export const STAFF_UPLOAD_COLUMNS = [
  { key: 'first_name', header: 'First Name*', required: true, example: 'Neema' },
  { key: 'middle_name', header: 'Middle Name', required: false, example: '' },
  { key: 'last_name', header: 'Last Name*', required: true, example: 'Mushi' },
  { key: 'email', header: 'Email (login)*', required: true, example: 'neema.mushi@school.example' },
  { key: 'phone', header: 'Phone', required: false, example: '255712345678' },
  { key: 'role', header: 'Role*', required: true, example: 'Teacher' },
  { key: 'employee_number', header: 'Employee Number*', required: true, example: 'EMP-001' },
  { key: 'campus_name', header: 'Campus*', required: true, example: '' },
  { key: 'department', header: 'Department', required: false, example: 'Sciences' },
  { key: 'designation', header: 'Designation', required: false, example: 'Biology Teacher' },
  { key: 'joining_date', header: 'Joining Date (YYYY-MM-DD)', required: false, example: '2026-01-05' },
  { key: 'contract_type', header: 'Contract Type (Permanent/Contract/Part-Time)', required: false, example: 'Permanent' },
  { key: 'contract_end_date', header: 'Contract End Date (YYYY-MM-DD)', required: false, example: '' },
  { key: 'salary', header: 'Salary (TZS)', required: false, example: '800000' },
  { key: 'experience_years', header: 'Years of Experience', required: false, example: '3' },
  { key: 'date_of_birth', header: 'Date of Birth (YYYY-MM-DD)', required: false, example: '1992-08-14' },
  { key: 'gender', header: 'Gender (Male/Female/Other)', required: false, example: 'Female' },
  { key: 'marital_status', header: 'Marital Status (Single/Married/Divorced/Widowed)', required: false, example: 'Single' },
  { key: 'national_id', header: 'National ID (NIDA)', required: false, example: '' },
  { key: 'tin_number', header: 'TIN Number', required: false, example: '' },
  { key: 'nssf_number', header: 'NSSF Number', required: false, example: '' },
  { key: 'bank_name', header: 'Bank Name', required: false, example: '' },
  { key: 'bank_account_number', header: 'Bank Account Number', required: false, example: '' },
  { key: 'address', header: 'Address', required: false, example: '' },
  { key: 'city', header: 'City', required: false, example: '' },
  { key: 'country', header: 'Country', required: false, example: 'Tanzania' },
  { key: 'emergency_contact_name', header: 'Emergency Contact Name', required: false, example: '' },
  { key: 'emergency_contact_relation', header: 'Emergency Contact Relationship', required: false, example: '' },
  { key: 'emergency_contact', header: 'Emergency Contact Phone', required: false, example: '' },
  { key: 'notes', header: 'Notes', required: false, example: '' },
];

const DATE_KEYS = new Set(['joining_date', 'contract_end_date', 'date_of_birth']);
const ROLES = ['Teacher', 'Principal', 'Admin', 'Accountant', 'Librarian', 'HR Manager', 'Transport Manager', 'Hostel Warden'];

const HEADER_TO_KEY = new Map(STAFF_UPLOAD_COLUMNS.map((c) => [c.header.trim().toLowerCase(), c.key]));
STAFF_UPLOAD_COLUMNS.forEach((c) => {
  const bare = c.header.replace(/\*$/, '').trim().toLowerCase();
  if (!HEADER_TO_KEY.has(bare)) HEADER_TO_KEY.set(bare, c.key);
});

/** Builds and downloads the .xlsx template: a "Staff" sheet to fill in, a "Reference" sheet with this school's exact
 * campus names and the roles that can be used, and the instructions. */
export async function downloadStaffUploadTemplate({ campuses = [] }) {
  const XLSX = await import('xlsx');
  const staffSheet = XLSX.utils.aoa_to_sheet([STAFF_UPLOAD_COLUMNS.map((c) => c.header), STAFF_UPLOAD_COLUMNS.map((c) => c.example)]);
  staffSheet['!cols'] = STAFF_UPLOAD_COLUMNS.map(() => ({ wch: 24 }));

  const instructions = XLSX.utils.aoa_to_sheet([
    ['Maelekezo / Instructions'],
    [],
    ['1. Usibadilishe majina ya vichwa vya safu (columns) kwenye sheet ya "Staff".'],
    ['   Do not rename the column headers on the "Staff" sheet.'],
    ['2. Safu zenye alama ya * ni lazima zijazwe (required).'],
    ['   Columns marked with * are required.'],
    ['3. Email ndiyo login ya mfanyakazi, na lazima iwe ya kipekee. Mfanyakazi ataingia kwa nenosiri la kawaida la wafanyakazi na ataombwa kulibadilisha mara ya kwanza.'],
    ['   The email is the staff member\'s login and must be unique. They sign in with the standard staff password and are asked to choose their own the first time.'],
    ['4. Role, Campus: andika kama ilivyo kwenye sheet ya "Reference" (herufi kubwa/ndogo hazijalishi).'],
    ['   Role and Campus: type them as shown on the "Reference" sheet (case does not matter).'],
    ['5. Tarehe ziandikwe kama YYYY-MM-DD, mfano 2026-01-05.'],
    ['   Dates must be written as YYYY-MM-DD, e.g. 2026-01-05.'],
    ['6. Employee Number lazima iwe ya kipekee. Kila safu itakaguliwa kabla ya kuingizwa — utaona makosa na marudio kwanza.'],
    ['   Employee Number must be unique. Every row is checked before anything is saved — you will see errors and duplicates first.'],
    ['7. Masomo ya kufundisha, nyaraka na "Reports to" huongezwa baadaye kwenye Staff → Edit.'],
    ['   Teaching subjects, documents and "Reports to" are added afterwards in Staff → Edit.'],
    ['8. Futa mstari wa mfano (row 2) kabla ya ku-upload.'],
    ['   Delete the example row (row 2) before uploading.'],
  ]);
  instructions['!cols'] = [{ wch: 110 }];

  const n = Math.max(campuses.length, ROLES.length);
  const ref = [['Campus', 'Role']];
  for (let i = 0; i < n; i += 1) ref.push([campuses[i]?.name || '', ROLES[i] || '']);
  const reference = XLSX.utils.aoa_to_sheet(ref);
  reference['!cols'] = [{ wch: 28 }, { wch: 22 }];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, staffSheet, 'Staff');
  XLSX.utils.book_append_sheet(wb, reference, 'Reference');
  XLSX.utils.book_append_sheet(wb, instructions, 'Maelekezo (Instructions)');
  XLSX.writeFile(wb, 'EduTrack_Bulk_Staff_Template.xlsx');
}

const normalizeDateCell = (value) => {
  if (!value) return '';
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  const str = String(value).trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(str)) return str.slice(0, 10);
  const parsed = new Date(str);
  return Number.isNaN(parsed.getTime()) ? str : parsed.toISOString().slice(0, 10);
};

/** Reads a filled-in staff template (a browser File) into plain row objects, each carrying its real spreadsheet row
 * number as `__row`. Blank rows are skipped. Throws a friendly message if the sheet or its headers cannot be read. */
export async function parseStaffUploadFile(file) {
  const XLSX = await import('xlsx');
  const wb = XLSX.read(await file.arrayBuffer(), { type: 'array', cellDates: true });
  const sheetName = wb.SheetNames.find((n) => n.trim().toLowerCase() === 'staff') || wb.SheetNames[0];
  const sheet = wb.Sheets[sheetName];
  if (!sheet) throw new Error('Could not find a "Staff" sheet in this file.');

  const aoa = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: false, dateNF: 'yyyy-mm-dd' });
  if (aoa.length === 0) throw new Error('The "Staff" sheet is empty.');
  const keyForColumn = aoa[0].map((h) => HEADER_TO_KEY.get(String(h || '').trim().toLowerCase()) || null);
  if (!keyForColumn.includes('employee_number') || !keyForColumn.includes('email')) {
    throw new Error('This doesn\'t look like the EduTrack bulk staff template — column headers don\'t match. Please download a fresh template.');
  }

  const rows = [];
  for (let r = 1; r < aoa.length; r += 1) {
    const line = aoa[r];
    if (!line || line.every((cell) => String(cell || '').trim() === '')) continue;
    const row = { __row: r + 1 };
    keyForColumn.forEach((key, i) => {
      if (!key) return;
      let value = line[i];
      if (DATE_KEYS.has(key)) value = normalizeDateCell(value);
      row[key] = typeof value === 'string' ? value.trim() : value;
    });
    rows.push(row);
  }
  if (rows.length === 0) throw new Error('No staff rows were found below the header row.');
  return rows;
}
