// Which "Open …" permission is the key to which part of the app. The menu and the
// page guard both read this, so what you see in the menu and what you can open can
// never disagree. (Admins hold every permission, so nothing is ever closed to them.)
//
// Keys are in backend/src/utils/permissionCatalog.js. A path matches by its longest
// prefix, so /students/inquiries is "Online Applications", not "Students".
export const ACCESS_FOR_PATH = {
  '/students': 'students.access',
  '/students/inquiries': 'inquiries.access',
  '/promotion': 'promotions.access',
  '/attendance': 'attendance.access',
  '/classes': 'classes.access',
  '/subjects': 'subjects.access',
  '/timetable': 'timetable.access',
  '/exams': 'exams.access',
  '/results': 'results.access',
  '/fees': 'fees.access',
  '/expenses': 'expenses.access',
  '/payroll': 'payroll.access',
  '/library': 'library.access',
  '/transport': 'transport.access',
  '/hostel': 'hostel.access',
  '/inventory': 'inventory.access',
  '/notifications': 'notifications.access',
  '/staff': 'staff.access',
  '/leave': 'leave.access',
  '/messages': 'messages.access',
  '/analytics': 'analytics.access',
  '/reports': 'reports.access',
  '/documents/id-card': 'documents.id_cards',
  '/documents/certificates': 'documents.certificates',
  '/campus': 'campus.access',
  '/subscription': 'subscription.access',
  '/settings': 'settings.access',
};

/** The permission needed to open this address, or null if it is open to everyone signed in. */
export const accessKeyFor = (pathname) => {
  const match = Object.keys(ACCESS_FOR_PATH)
    .filter((prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`))
    .sort((a, b) => b.length - a.length)[0];
  return match ? ACCESS_FOR_PATH[match] : null;
};

// ── What each module is, for the personal dashboard's "your modules" cards ──
export const MODULE_INFO = {
  '/students': ['Students', 'Admissions, records and student profiles'],
  '/students/inquiries': ['Online Applications', 'Admission requests from your website'],
  '/promotion': ['Promotion', 'Move students up to the next class'],
  '/attendance': ['Attendance', 'Take and review daily attendance'],
  '/classes': ['Classes', 'Classes, sections and class teachers'],
  '/subjects': ['Subjects', 'The subjects taught at your school'],
  '/timetable': ['Timetable', 'Who teaches what, and when'],
  '/exams': ['Exams', 'Exams and marks'],
  '/results': ['Results', 'Exam results and report cards'],
  '/fees': ['Fee Management', 'Fee structures, payments and balances'],
  '/expenses': ['Expenses', 'Money the school spends'],
  '/payroll': ['Payroll', 'Salaries and payslips'],
  '/library': ['Library', 'Books and loans'],
  '/transport': ['Transport', 'Routes, vehicles and who rides'],
  '/hostel': ['Hostel', 'Hostels, rooms and boarders'],
  '/inventory': ['Inventory', 'Assets and consumable stock'],
  '/staff': ['Staff', 'Staff records and roles'],
  '/leave': ['Leave', 'Request and approve leave'],
  '/messages': ['Messages', 'SMS and email to parents and staff'],
  '/analytics': ['Analytics', 'Charts and trends'],
  '/reports': ['Reports', 'Printable reports'],
  '/documents/id-card': ['ID Cards', 'Print student and staff ID cards'],
  '/documents/certificates': ['Certificates', 'Print certificates'],
  '/campus': ['Campus', 'Your school\'s campuses'],
  '/subscription': ['Subscription', 'Your EduTrack plan and billing'],
  '/settings': ['Settings', 'School settings, security and permissions'],
  '/notifications': ['Notifications', 'Everything the system has told you'],
};

// ── Pages that need MORE than the module's "Open …" key ───────────────────────
// A form to add or edit something needs the permission to do it, so someone who
// can look but not change is never shown the form (and a typed-in address
// doesn't open it either). First match wins.
const PAGE_NEEDS = [
  [/^\/students\/(admission|bulk-upload)$/, 'students.create'],
  [/^\/students\/[^/]+\/edit$/, 'students.update'],
  [/^\/staff\/(add|bulk-upload)$/, 'staff.create'],
  [/^\/staff\/[^/]+\/edit$/, 'staff.update'],
  [/^\/classes\/add$/, 'academics.create'],
  [/^\/classes\/[^/]+\/edit$/, 'academics.update'],
  [/^\/subjects\/add$/, 'academics.create'],
  [/^\/subjects\/[^/]+\/edit$/, 'academics.update'],
  [/^\/campus\/add$/, 'campus.create'],
  [/^\/campus\/[^/]+\/edit$/, 'campus.update'],
  [/^\/promotion$/, 'promotions.manage'],
  [/^\/attendance\/take$/, 'attendance.create'],
  [/^\/fees\/record$/, 'fees.create'],
  [/^\/timetable\/setup$/, 'timetable.update'],
  [/^\/leave\/(types|setup)$/, 'leave.view'],
  [/^\/leave\/balances$/, 'leave.view'],
  [/^\/messages\/compose$/, 'send_messages'],
  [/^\/messages\/(contacts|groups|history|templates|balance)(\/.*)?$/, 'messages.view'],
  [/^\/messages\/inquiries$/, 'inquiries.view'],
];

/** The extra permission a page needs beyond its module's "Open …" key, or null. */
export const pageNeeds = (pathname) => PAGE_NEEDS.find(([pattern]) => pattern.test(pathname))?.[1] || null;
