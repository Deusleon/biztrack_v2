// FILE PATH: frontend/src/App.jsx
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { CampusProvider } from './contexts/CampusContext';
import { AcademicYearProvider } from './contexts/AcademicYearContext';
import { PreferencesProvider } from './contexts/PreferencesContext';
import ProtectedRoute from './components/ProtectedRoute';
import { HelpCenter, HelpArticle, ContactSupport, UserGuide } from './pages/Help';
import { PrivacyPolicy, TermsOfService } from './pages/Legal';
import ForgotPassword from './pages/ForgotPassword';
import Login from './pages/Login';
import VerifyReceipt from './pages/Fees/VerifyReceipt';
import VerifySubscriptionReceipt from './pages/Fees/VerifySubscriptionReceipt';
import DashboardHome from './pages/DashboardHome';
import { SubscriptionProvider } from './contexts/SubscriptionContext';

import './App.css';
import { lazy, Suspense } from 'react';

/** Route pages load on demand, so the first screen no longer waits for the whole app (≈1.9 MB) to download.
 * If a chunk cannot be fetched (a new release replaced the old files, or the connection dropped), reload once
 * to pick up the fresh build instead of leaving the screen on a spinner. */
const lazyPage = (loader, name) => lazy(() => loader()
  .then((m) => { sessionStorage.removeItem('edutrack:chunk-reload'); return { default: name ? m[name] : m.default }; })
  .catch((err) => {
    const key = 'edutrack:chunk-reload';
    if (!sessionStorage.getItem(key)) { sessionStorage.setItem(key, '1'); window.location.reload(); return new Promise(() => {}); }
    sessionStorage.removeItem(key);
    throw err;
  }));

const PageFallback = () => (
  <div className="min-h-screen flex items-center justify-center bg-gray-100">
    <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
  </div>
);

const MessagesIndex = lazyPage(() => import('./pages/Messages/MessagesNav'), 'MessagesIndex');
const Profile = lazyPage(() => import('./pages/Profile'));
const AttendanceList = lazyPage(() => import('./pages/Attendance'), 'AttendanceList');
const AttendanceTake = lazyPage(() => import('./pages/Attendance'), 'AttendanceTake');
const AttendanceView = lazyPage(() => import('./pages/Attendance'), 'AttendanceView');
const ClassList = lazyPage(() => import('./pages/Classes'), 'ClassList');
const ClassForm = lazyPage(() => import('./pages/Classes'), 'ClassForm');
const ClassView = lazyPage(() => import('./pages/Classes'), 'ClassView');
const SubjectList = lazyPage(() => import('./pages/Subjects'), 'SubjectList');
const SubjectForm = lazyPage(() => import('./pages/Subjects'), 'SubjectForm');
const SubjectView = lazyPage(() => import('./pages/Subjects'), 'SubjectView');
const CampusList = lazyPage(() => import('./pages/Campus'), 'CampusList');
const CampusForm = lazyPage(() => import('./pages/Campus'), 'CampusForm');
const CampusView = lazyPage(() => import('./pages/Campus'), 'CampusView');
const StudentList = lazyPage(() => import('./pages/Student'), 'StudentList');
const AdmissionForm = lazyPage(() => import('./pages/Student'), 'AdmissionForm');
const StudentView = lazyPage(() => import('./pages/Student'), 'StudentView');
const Promotion = lazyPage(() => import('./pages/Student'), 'Promotion');
const InquiryList = lazyPage(() => import('./pages/Student'), 'InquiryList');
const BulkUpload = lazyPage(() => import('./pages/Student'), 'BulkUpload');
const StaffList = lazyPage(() => import('./pages/Staff'), 'StaffList');
const StaffForm = lazyPage(() => import('./pages/Staff'), 'StaffForm');
const StaffView = lazyPage(() => import('./pages/Staff'), 'StaffView');
const StaffBulkUpload = lazyPage(() => import('./pages/Staff'), 'StaffBulkUpload');
const TimetableGrid = lazyPage(() => import('./pages/Timetable'), 'TimetableGrid');
const TimetableSetup = lazyPage(() => import('./pages/Timetable'), 'TimetableSetup');
const RouteList = lazyPage(() => import('./pages/Transport'), 'RouteList');
const RouteStudents = lazyPage(() => import('./pages/Transport'), 'RouteStudents');
const VehicleList = lazyPage(() => import('./pages/Transport'), 'VehicleList');
const VehicleView = lazyPage(() => import('./pages/Transport'), 'VehicleView');
const BookList = lazyPage(() => import('./pages/Library'), 'BookList');
const LoanList = lazyPage(() => import('./pages/Library'), 'LoanList');
const MyBooks = lazyPage(() => import('./pages/Library'), 'MyBooks');
const MyLeave = lazyPage(() => import('./pages/Leave'), 'MyLeave');
const Approvals = lazyPage(() => import('./pages/Leave'), 'Approvals');
const LeaveTypes = lazyPage(() => import('./pages/Leave'), 'LeaveTypes');
const StaffBalances = lazyPage(() => import('./pages/Leave'), 'StaffBalances');
const Subscription = lazyPage(() => import('./pages/Subscription'), 'Subscription');
const InvoiceView = lazyPage(() => import('./pages/Subscription'), 'InvoiceView');
const PayInvoice = lazyPage(() => import('./pages/Subscription'), 'PayInvoice');
const ExpenseList = lazyPage(() => import('./pages/Expenses'), 'ExpenseList');
const HostelList = lazyPage(() => import('./pages/Hostel'), 'HostelList');
const HostelRooms = lazyPage(() => import('./pages/Hostel'), 'HostelRooms');
const PayrollHome = lazyPage(() => import('./pages/Payroll'), 'PayrollHome');
const PayrollDetail = lazyPage(() => import('./pages/Payroll'), 'PayrollDetail');
const ItemList = lazyPage(() => import('./pages/Inventory'), 'ItemList');
const InventoryHistory = lazyPage(() => import('./pages/Inventory'), 'InventoryHistory');
const Analytics = lazyPage(() => import('./pages/Analytics'), 'Analytics');
const Reports = lazyPage(() => import('./pages/Reports'), 'Reports');
const IDCard = lazyPage(() => import('./pages/Documents'), 'IDCard');
const Certificates = lazyPage(() => import('./pages/Documents'), 'Certificates');
const ExamList = lazyPage(() => import('./pages/Exams'), 'ExamList');
const MarksEntry = lazyPage(() => import('./pages/Exams'), 'MarksEntry');
const ResultsHome = lazyPage(() => import('./pages/Exams'), 'ResultsHome');
const ReportCard = lazyPage(() => import('./pages/Exams'), 'ReportCard');
const TermSummary = lazyPage(() => import('./pages/Exams'), 'TermSummary');
const FeeStructureList = lazyPage(() => import('./pages/Fees'), 'FeeStructureList');
const RecordPayment = lazyPage(() => import('./pages/Fees'), 'RecordPayment');
const FeeStatus = lazyPage(() => import('./pages/Fees'), 'FeeStatus');
const StudentFeeSummary = lazyPage(() => import('./pages/Fees'), 'StudentFeeSummary');
const PaymentReceipt = lazyPage(() => import('./pages/Fees'), 'PaymentReceipt');
const ContactList = lazyPage(() => import('./pages/Messages'), 'ContactList');
const GroupList = lazyPage(() => import('./pages/Messages'), 'GroupList');
const Compose = lazyPage(() => import('./pages/Messages'), 'Compose');
const MessageHistory = lazyPage(() => import('./pages/Messages'), 'MessageHistory');
const MessageDetail = lazyPage(() => import('./pages/Messages'), 'MessageDetail');
const TemplateList = lazyPage(() => import('./pages/Messages'), 'TemplateList');
const SmsBalance = lazyPage(() => import('./pages/Messages'), 'SmsBalance');
const ContactInquiryList = lazyPage(() => import('./pages/Messages'), 'InquiryList');
const NotificationList = lazyPage(() => import('./pages/NotificationList'));
const Settings = lazyPage(() => import('./pages/index.jsx'), 'Settings');

function AppRoutes() {
  const { loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <Suspense fallback={<PageFallback />}>
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      {/* Public — readable before signing in (linked from the sign-in page). */}
      <Route path="/privacy" element={<PrivacyPolicy />} />
      <Route path="/terms" element={<TermsOfService />} />
      <Route path="/verify-receipt" element={<VerifyReceipt />} />
      <Route path="/verify-receipt/:paymentId/:code" element={<VerifyReceipt />} />
      <Route path="/pay/:number/:code" element={<PayInvoice />} />
      <Route path="/verify-subscription-receipt" element={<VerifySubscriptionReceipt />} />
      <Route path="/verify-subscription-receipt/:number/:code" element={<VerifySubscriptionReceipt />} />

      <Route element={<ProtectedRoute />}>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardHome />} />
        <Route path="/profile" element={<Profile />} />
        {/* Help Center. "contact" must come before :slug or it is read as an article. */}
        <Route path="/help" element={<HelpCenter />} />
        <Route path="/help/contact" element={<ContactSupport />} />
        <Route path="/help/:slug" element={<HelpArticle />} />
        {/* User Guide — a PDF served from /public/docs, open to everyone signed in. */}
        <Route path="/user-guide" element={<UserGuide />} />
        <Route path="/user-manual" element={<Navigate to="/user-guide" replace />} />{/* the old address */}
      
      {/* Academic Routes */}
      <Route path="/students" element={<StudentList />} />
      <Route path="/students/admission" element={<AdmissionForm />} />
      <Route path="/students/bulk-upload" element={<BulkUpload />} />
      <Route path="/students/inquiries" element={<InquiryList />} />
      {/* Must precede /students/:id — otherwise "promotion" is read as a
          student id and this page never renders. */}
      <Route path="/promotion" element={<Promotion />} />
      <Route path="/students/:id" element={<StudentView />} />
      <Route path="/students/:id/edit" element={<AdmissionForm />} />
      <Route path="/attendance" element={<AttendanceList />} />
      <Route path="/attendance/take" element={<AttendanceTake />} />
      <Route path="/attendance/session" element={<AttendanceView />} />
      <Route path="/classes" element={<ClassList />} />
      <Route path="/classes/add" element={<ClassForm />} />
      <Route path="/classes/:id" element={<ClassView />} />
      <Route path="/classes/:id/edit" element={<ClassForm />} />
      <Route path="/subjects" element={<SubjectList />} />
      <Route path="/subjects/add" element={<SubjectForm />} />
      <Route path="/subjects/:id" element={<SubjectView />} />
      <Route path="/subjects/:id/edit" element={<SubjectForm />} />
      <Route path="/timetable" element={<TimetableGrid />} />
      <Route path="/timetable/setup" element={<TimetableSetup />} />
      
      {/* Campus Routes */}
      <Route path="/campus" element={<CampusList />} />
      <Route path="/campus/add" element={<CampusForm />} />
      <Route path="/campus/:id" element={<CampusView />} />
      <Route path="/campus/:id/edit" element={<CampusForm />} />
      
      {/* Examination Routes */}
      <Route path="/exams" element={<ExamList />} />
      <Route path="/exams/:id/marks-entry" element={<MarksEntry />} />
      <Route path="/results" element={<ResultsHome />} />
      <Route path="/results/term-summary" element={<TermSummary />} />
      <Route path="/results/:id/report-card/:studentId" element={<ReportCard />} />
      
      {/* Finance Routes */}
      <Route path="/fees" element={<FeeStructureList />} />
      <Route path="/fees/record" element={<RecordPayment />} />
      <Route path="/fees/status" element={<FeeStatus />} />
      <Route path="/fees/student/:studentId" element={<StudentFeeSummary />} />
      <Route path="/fees/receipt/:id" element={<PaymentReceipt />} />
      
      {/* Facilities Routes */}
      <Route path="/library" element={<BookList />} />
      <Route path="/library/loans" element={<LoanList />} />
      <Route path="/library/my-books" element={<MyBooks />} />
      <Route path="/leave" element={<MyLeave />} />
      <Route path="/leave/approvals" element={<Approvals />} />
      <Route path="/leave/types" element={<LeaveTypes />} />
      <Route path="/subscription" element={<Subscription />} />
      <Route path="/subscription/invoices/:reference" element={<InvoiceView kind="invoice" />} />
      <Route path="/subscription/invoices/:reference/receipt" element={<InvoiceView kind="receipt" />} />
      <Route path="/leave/balances" element={<StaffBalances />} />
      {/* Old bookmarks and any lingering links still land somewhere useful */}
      <Route path="/leave/setup" element={<Navigate to="/leave/types" replace />} />
      <Route path="/expenses" element={<ExpenseList />} />
      <Route path="/transport" element={<RouteList />} />
      <Route path="/transport/:id/students" element={<RouteStudents />} />
      <Route path="/transport/vehicles" element={<VehicleList />} />
      <Route path="/transport/vehicles/:id" element={<VehicleView />} />
      <Route path="/hostel" element={<HostelList />} />
      <Route path="/hostel/:id/rooms" element={<HostelRooms />} />
      <Route path="/payroll" element={<PayrollHome />} />
      <Route path="/payroll/:id" element={<PayrollDetail />} />
      <Route path="/inventory" element={<ItemList />} />
      <Route path="/inventory/history" element={<InventoryHistory />} />
      
      {/* HR Routes */}
      <Route path="/staff" element={<StaffList />} />
      <Route path="/staff/add" element={<StaffForm />} />
      <Route path="/staff/bulk-upload" element={<StaffBulkUpload />} />
      <Route path="/staff/:id" element={<StaffView />} />
      <Route path="/staff/:id/edit" element={<StaffForm />} />
      
      {/* Communication Routes */}
      <Route path="/notifications" element={<NotificationList />} />
      <Route path="/messages" element={<MessagesIndex />} />
      <Route path="/messages/contacts" element={<ContactList />} />
      <Route path="/messages/groups" element={<GroupList />} />
      <Route path="/messages/compose" element={<Compose />} />
      <Route path="/messages/history" element={<MessageHistory />} />
      <Route path="/messages/history/:id" element={<MessageDetail />} />
      <Route path="/messages/templates" element={<TemplateList />} />
      <Route path="/messages/balance" element={<SmsBalance />} />
      <Route path="/messages/inquiries" element={<ContactInquiryList />} />
      
      {/* System Routes */}
      <Route path="/analytics" element={<Analytics />} />
      <Route path="/reports" element={<Reports />} />
      <Route path="/documents/id-card" element={<IDCard />} />
      <Route path="/documents/certificates" element={<Certificates />} />
      <Route path="/settings" element={<Settings />} />
      
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>
    </Routes>
    </Suspense>
  );
}

function App() {
  return (
    <Router>
      <ThemeProvider>
        <AuthProvider>
          <SubscriptionProvider>
          <CampusProvider>
            <AcademicYearProvider>
              <PreferencesProvider>
                <AppRoutes />
              </PreferencesProvider>
            </AcademicYearProvider>
          </CampusProvider>
          </SubscriptionProvider>
        </AuthProvider>
      </ThemeProvider>
    </Router>
  );
}

export default App;