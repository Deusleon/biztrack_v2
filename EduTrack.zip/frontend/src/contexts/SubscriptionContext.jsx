import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useAuth } from "./AuthContext";
import { subscriptionService } from "../services/api";

/**
 * Knows whether this school's subscription has lapsed past its grace period.
 *
 * The server is the real lock — every API area answers 402 — but without this the
 * app would still draw its menu and fire dozens of requests that all fail. Here the
 * answer is fetched once after sign-in; ProtectedRoute uses it to show only the
 * Subscription page, and the sidebar shows nothing else.
 *
 * If the check itself fails, the app stays open: failing closed would lock a paid
 * school out over a network blip (the server still enforces the real lock).
 */
const SubscriptionContext = createContext(null);

export function SubscriptionProvider({ children }) {
  const { isAuthenticated, user } = useAuth();
  const [state, setState] = useState({ loaded: false, locked: false, status: null, evaluation: null });

  const refresh = useCallback(async () => {
    try {
      const res = await subscriptionService.getMine();
      if (res?.success) {
        const evaluation = res.data.evaluation;
        const enforced = res.data.enforced !== false; // false only for the platform developer
        setState({ loaded: true, locked: enforced && !!evaluation?.locked, status: evaluation?.status || null, evaluation });
        return;
      }
    } catch { /* fall through: stay open */ }
    setState((s) => ({ ...s, loaded: true }));
  }, []);

  useEffect(() => {
    if (!isAuthenticated || user?.must_change_password) {
      setState({ loaded: false, locked: false, status: null, evaluation: null });
      return;
    }
    refresh();
  }, [isAuthenticated, user?.id, user?.must_change_password, refresh]);

  // Any API area answering "402 subscription expired" (the subscription ended while
  // the person was working) locks the app straight away.
  useEffect(() => {
    const onLocked = () => setState((s) => ({ ...s, loaded: true, locked: true, status: s.status === "cancelled" ? "cancelled" : "expired" }));
    window.addEventListener("edutrack:subscription-locked", onLocked);
    return () => window.removeEventListener("edutrack:subscription-locked", onLocked);
  }, []);

  const value = useMemo(() => ({ ...state, refresh }), [state, refresh]);
  return <SubscriptionContext.Provider value={value}>{children}</SubscriptionContext.Provider>;
}

export function useSubscription() {
  const ctx = useContext(SubscriptionContext);
  // Outside the provider (tests, harnesses): behave as "open".
  return ctx || { loaded: true, locked: false, status: null, evaluation: null, refresh: async () => {} };
}
