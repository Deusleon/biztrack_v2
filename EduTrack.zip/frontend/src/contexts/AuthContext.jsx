import { createContext, useContext, useState, useEffect } from 'react';
import { authService, settingsService } from '../services/api';

const AuthContext = createContext(null);

/** Reset on any of these — mirrors what Settings → Login Policy's idle
 * timeout describes to the admin: "no mouse, keyboard, or touch activity". */
const IDLE_EVENTS = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart'];

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const token = localStorage.getItem('token');
        const storedUser = localStorage.getItem('user');
        
        if (token && storedUser) {
          // Set user from localStorage first
          const parsedUser = JSON.parse(storedUser);
          setUser(parsedUser);
          
          // Optionally validate token with backend
          try {
            const response = await authService.getMe();
            if (response.success) {
              setUser(response.data);
              localStorage.setItem('user', JSON.stringify(response.data));
            }
          } catch (error) {
            // If token validation fails, keep the stored user
            // The API interceptor will handle 401 errors
            console.log('Token validation skipped or failed:', error);
          }
        }
      } catch (error) {
        console.error('Error loading user:', error);
      } finally {
        setLoading(false);
      }
    };

    loadUser();
  }, []);

  const login = async (credentials) => {
    const response = await authService.login(credentials);
    setUser(response.data);
    return response;
  };

  const register = async (userData) => {
    const response = await authService.register(userData);
    setUser(response.data);
    return response;
  };

  const logout = () => {
    authService.logout();
    setUser(null);
  };

  // Idle-timeout auto-logout, driven by Settings → Login Policy
  // (tenants.settings.session_policy.idle_timeout_minutes, default 30).
  // Fetched once per login rather than baked into the login/getMe payload
  // since it's an admin-tunable preference, not user identity.
  const [idleTimeoutMinutes, setIdleTimeoutMinutes] = useState(null);

  useEffect(() => {
    if (!user) { setIdleTimeoutMinutes(null); return; }
    settingsService.getOverview()
      .then((res) => { if (res.success) setIdleTimeoutMinutes(res.data.session_policy?.idle_timeout_minutes ?? null); })
      .catch(() => { /* non-fatal — idle logout just won't be enforced this session */ });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  useEffect(() => {
    if (!user || !idleTimeoutMinutes) return undefined;
    let timer;
    const reset = () => {
      clearTimeout(timer);
      timer = setTimeout(() => { logout(); }, idleTimeoutMinutes * 60000);
    };
    IDLE_EVENTS.forEach((evt) => window.addEventListener(evt, reset));
    reset();
    return () => {
      clearTimeout(timer);
      IDLE_EVENTS.forEach((evt) => window.removeEventListener(evt, reset));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, idleTimeoutMinutes]);

  // The server says this account must choose a password first (a stale copy of
  // the user, e.g. an account marked after they signed in). Show that screen.
  useEffect(() => {
    const onRequired = () => setUser((prev) => (prev ? { ...prev, must_change_password: true } : prev));
    window.addEventListener('edutrack:password-change-required', onRequired);
    return () => window.removeEventListener('edutrack:password-change-required', onRequired);
  }, []);

  /** Merges partial updates (e.g. after editing the profile or changing
   * the avatar) into both the in-memory user and localStorage, so the
   * rest of the app (sidebar, header, etc.) reflects the change immediately
   * without needing a full page reload. */
  const updateUser = (partial) => {
    setUser((prev) => {
      const next = { ...prev, ...partial };
      try { localStorage.setItem('user', JSON.stringify(next)); } catch { /* ignore */ }
      return next;
    });
  };

  /** Does this person hold the permission? (The server decides every action;
   * this only decides which buttons to show.) '*' means everything — admins. */
  const can = (key) => {
    const granted = user?.effective_permissions;
    return Array.isArray(granted) && (granted.includes('*') || granted.includes(key));
  };
  /** Does this person hold ANY way of changing this module (add / edit / delete)?
   * Used to decide whether to show a module's management controls at all. */
  const canAny = (module) => ['create', 'update', 'delete'].some((verb) => can(`${module}.${verb}`));

  const value = {
    user,
    can,
    canAny,
    login,
    register,
    logout,
    updateUser,
    loading,
    isAuthenticated: !!user,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
