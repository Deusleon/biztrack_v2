/**
 * CampusContext — Tracks which campus the current user is working on.
 *
 * - Admins / Principals: can switch campus; selection stored in localStorage
 *   so it survives page refreshes and persists until explicitly changed.
 * - Teachers / Staff: campus comes from their staff profile (campus_id on User
 *   if returned by /auth/me, or chosen once and stored).
 * - Students / Parents: same read-only campus derivation.
 *
 * All forms and API calls that need campus_id should read from useCampus().
 */
import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { campusService } from '../services/api';
import { useAuth } from './AuthContext';

const CampusContext = createContext(null);

// Roles that can freely switch between campuses
const MULTI_CAMPUS_ROLES = ['super_admin', 'admin', 'principal'];
const STORAGE_KEY = 'edutrack_current_campus';

export const CampusProvider = ({ children }) => {
  const { user, isAuthenticated } = useAuth();
  const [campuses, setCampuses]           = useState([]);
  const [currentCampus, setCurrentCampusState] = useState(null);
  const [loading, setLoading]             = useState(false);
  const [campusVersion, setCampusVersion] = useState(0); // increments on every campus switch

  const isMultiCampusRole = MULTI_CAMPUS_ROLES.includes(user?.role);

  // Persist selection to localStorage
  const setCurrentCampus = useCallback((campus) => {
    setCurrentCampusState(campus);
    setCampusVersion((v) => v + 1);
    if (campus) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ id: campus.id, name: campus.name, code: campus.code }));
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, []);

  // Load campuses and resolve the active one
  useEffect(() => {
    if (!isAuthenticated || !user) return;

    const init = async () => {
      setLoading(true);
      try {
        if (isMultiCampusRole) {
          // Admins: fetch all active campuses for the tenant
          const res = await campusService.getAll({ status: 'active', limit: 100 });
          const list = res?.success ? (res.data?.campuses || res.data || []) : [];
          setCampuses(list);

          // Try to restore last selection from localStorage
          const stored = localStorage.getItem(STORAGE_KEY);
          if (stored) {
            try {
              const parsed = JSON.parse(stored);
              // Make sure the stored campus still exists in the fresh list
              const match = list.find((c) => c.id === parsed.id);
              if (match) {
                setCurrentCampusState(match);
                setLoading(false);
                return;
              }
            } catch {
              // ignore bad localStorage value
            }
          }

          // Default to the first active campus if nothing stored
          if (list.length > 0) {
            setCurrentCampus(list[0]);
          }
        } else {
          // Non-admin: derive campus from the user's profile
          // The /auth/me response may include campus_id directly or via staff profile
          const campusId = user.campus_id;
          if (campusId) {
            try {
              const res = await campusService.getById(campusId);
              if (res?.success) {
                setCurrentCampusState(res.data);
                setCampuses([res.data]);
              }
            } catch {
              // campus lookup failed — leave null, pages can handle gracefully
            }
          }
        }
      } finally {
        setLoading(false);
      }
    };

    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, user?.id, user?.role]);

  /** Re-fetches the active campus so freshly-changed details (a new logo,
   * updated address, etc.) show up on receipts and report cards without
   * needing a full page reload. */
  const refreshCampuses = useCallback(async () => {
    if (!isAuthenticated || !user) return;
    try {
      if (isMultiCampusRole) {
        const res = await campusService.getAll({ status: 'active', limit: 100 });
        const list = res?.success ? (res.data?.campuses || res.data || []) : [];
        setCampuses(list);
        // Keep pointing at the same campus, but with its refreshed data.
        setCurrentCampusState((current) => {
          if (!current) return current;
          return list.find((c) => c.id === current.id) || current;
        });
      } else if (user.campus_id) {
        const res = await campusService.getById(user.campus_id);
        if (res?.success) {
          setCurrentCampusState(res.data);
          setCampuses([res.data]);
        }
      }
    } catch {
      // Non-fatal — the stale copy stays in place until the next load.
    }
  }, [isAuthenticated, user, isMultiCampusRole]);

  return (
    <CampusContext.Provider
      value={{
        /** Full campus object that is currently active */
        currentCampus,
        /** Shorthand id — the value most API calls need */
        currentCampusId: currentCampus?.id ?? null,
        /** Only meaningful for admin roles */
        campuses,
        /** Switch to a different campus (admin only) */
        setCurrentCampus,
        /** Re-fetch campus data after it's been edited elsewhere */
        refreshCampuses,
        /** True while campuses are being fetched */
        loading,
        /** Whether the user can switch between campuses */
        canSwitchCampus: isMultiCampusRole,
        /**
         * Incrementing counter — add to useEffect deps to re-fetch data
         * whenever the active campus changes.
         */
        campusVersion,
      }}
    >
      {children}
    </CampusContext.Provider>
  );
};

export const useCampus = () => {
  const context = useContext(CampusContext);
  if (!context) {
    throw new Error('useCampus must be used within a CampusProvider');
  }
  return context;
};
