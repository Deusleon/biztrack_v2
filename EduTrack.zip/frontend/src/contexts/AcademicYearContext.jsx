/**
 * AcademicYearContext — Tracks the currently active academic year.
 *
 * The academic year is set once and applies globally to all pages
 * (attendance, timetable, allocation rules, etc.) so the user doesn't
 * have to enter it on every form.
 *
 * Format: "YYYY-YYYY+1", e.g. "2025-2026"
 * Stored in localStorage so it persists across sessions.
 */
import { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { useAuth } from './AuthContext';

const AcademicYearContext = createContext(null);

const STORAGE_KEY = 'edutrack_academic_year';

/**
 * The academic year to show by default.
 *
 * Tanzanian school years run JANUARY TO DECEMBER, so the current academic
 * year is simply the current calendar year. This previously assumed a
 * September start (the Northern-hemisphere convention), which meant that
 * for eight months of every year — January through August — the picker
 * defaulted to the PREVIOUS year. Classes, fees and results for the year
 * actually in progress then appeared to be missing entirely.
 */
function defaultAcademicYear() {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) return stored;

  const startYear = new Date().getFullYear();
  return `${startYear}-${startYear + 1}`;
}

/** Generate a list of selectable academic years (±2 from current),
 * clamped so nothing before `minBaseYear` is ever offered — there's
 * nothing real to show for a year before the school even started using
 * the system (see utils/academicYear.js "systemStartBaseYear" on the
 * backend, which enforces the same floor server-side regardless of what
 * the picker offers). */
function generateYearOptions(minBaseYear) {
  // Same January-start rule as defaultAcademicYear above.
  const currentStart = new Date().getFullYear();

  const floor = minBaseYear != null ? Math.max(minBaseYear, currentStart - 2) : currentStart - 2;
  const options = [];
  for (let y = floor; y <= currentStart + 2; y++) {
    options.push(`${y}-${y + 1}`);
  }
  return options;
}

export const AcademicYearProvider = ({ children }) => {
  const { user } = useAuth();
  // Sent back on every profile fetch (see authController.getMe) — null
  // until the user is loaded, in which case we simply don't clamp yet
  // rather than briefly showing a wrong, over-restricted list.
  const minBaseYear = user?.academic_records_start_year ?? null;

  const [currentAcademicYear, setCurrentAcademicYearState] = useState(defaultAcademicYear);
  const [academicYearVersion, setAcademicYearVersion] = useState(0);

  const setCurrentAcademicYear = useCallback((year) => {
    setCurrentAcademicYearState(year);
    setAcademicYearVersion((v) => v + 1);
    if (year) {
      localStorage.setItem(STORAGE_KEY, year);
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, []);

  // If the selected year (possibly restored from a previous session)
  // turns out to be earlier than the school's actual start year — e.g.
  // an admin only just set the override, or this was carried over from
  // before this floor existed — bump it up rather than leaving the
  // picker showing a year it won't even offer as an option.
  useEffect(() => {
    if (minBaseYear == null) return;
    const selectedBaseYear = parseInt(String(currentAcademicYear).slice(0, 4), 10);
    if (Number.isFinite(selectedBaseYear) && selectedBaseYear < minBaseYear) {
      setCurrentAcademicYear(`${minBaseYear}-${minBaseYear + 1}`);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [minBaseYear]);

  return (
    <AcademicYearContext.Provider
      value={{
        /** Currently active academic year string (e.g. "2025-2026") */
        currentAcademicYear,
        /** Change the active academic year */
        setCurrentAcademicYear,
        /** Incrementing counter — add to useEffect deps to re-fetch on year change */
        academicYearVersion,
        /** Pre-built list of year options for dropdowns — never includes
         * a year before the school started using the system. */
        yearOptions: generateYearOptions(minBaseYear),
        /** The earliest base year the picker will offer, or null if not
         * yet known — exposed in case a page wants to explain why an
         * older year isn't selectable. */
        minBaseYear,
      }}
    >
      {children}
    </AcademicYearContext.Provider>
  );
};

export const useAcademicYear = () => {
  const context = useContext(AcademicYearContext);
  if (!context) {
    throw new Error('useAcademicYear must be used within an AcademicYearProvider');
  }
  return context;
};
