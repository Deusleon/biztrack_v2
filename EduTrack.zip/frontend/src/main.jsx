import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { ToastProvider } from './contexts/ToastContext'
import PwaStatus from './components/PwaStatus'
import { registerPwa } from './utils/pwa'
import { fillScreenOnLaunch } from './utils/desktopWindow'

registerPwa()
fillScreenOnLaunch()

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ToastProvider>
      <App />
      <PwaStatus />
    </ToastProvider>
  </StrictMode>,
)
