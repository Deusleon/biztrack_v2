import { useEffect, useState } from "react";
import { settingsService } from "../services/api";
import { usePreferences } from "../contexts/PreferencesContext";
import { useToast } from "../contexts/ToastContext";

// ── Presentation ────────────────────────────────────────────────────────

import { KIND_STYLES, fieldLabel } from "../utils/auditLogView";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const ISO_DATETIME = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/;

export function KindBadge({ kind, outcome }) {
  // A refused or failed sign-in is the one thing in the log worth catching the eye.
  const style = outcome === "failed"
    ? { label: "Failed sign-in", cls: "bg-red-100 text-red-700 border-red-200" }
    : (KIND_STYLES[kind] || KIND_STYLES.action);
  return <span className={`inline-flex items-center text-xs font-semibold px-2 py-0.5 rounded-full border ${style.cls}`}>{style.label}</span>;
}

/** One stored value, shown the way a person would say it. */
function Value({ value, lookups, formatDateTime, tone }) {
  if (value === null || value === undefined || value === "") return <span className="text-gray-400 italic">empty</span>;
  if (value === "[hidden]") return <span className="text-gray-500 italic">hidden for security</span>;
  if (typeof value === "boolean") return <span className={tone}>{value ? "Yes" : "No"}</span>;
  if (typeof value === "object") return <code className={`text-xs break-all ${tone}`}>{JSON.stringify(value)}</code>;
  if (typeof value === "string" && UUID_RE.test(value)) {
    const name = lookups?.[value];
    return name
      ? <span className={tone} title={value}>{name}</span>
      : <span className={`${tone} font-mono text-xs`} title={value}>{value.slice(0, 8)}…</span>;
  }
  if (typeof value === "string" && ISO_DATETIME.test(value)) return <span className={tone}>{formatDateTime(value)}</span>;
  // snake_case words (o_level, partially_sent) read better with spaces
  if (typeof value === "string" && /^[a-z]+(_[a-z]+)+$/.test(value)) return <span className={tone}>{value.replace(/_/g, " ")}</span>;
  return <span className={`${tone} break-words`}>{String(value)}</span>;
}

/** { field: value } as a two-column list. */
function KeyValueList({ data, lookups, formatDateTime }) {
  const entries = Object.entries(data || {}).filter(([, v]) => v !== null && v !== undefined && v !== "");
  if (entries.length === 0) return <p className="text-sm text-gray-400 italic">Nothing recorded.</p>;
  return (
    <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
      {entries.map(([field, value]) => (
        <div key={field} className="min-w-0">
          <dt className="text-xs text-gray-500">{fieldLabel(field)}</dt>
          <dd className="text-sm text-gray-900"><Value value={value} lookups={lookups} formatDateTime={formatDateTime} tone="" /></dd>
        </div>
      ))}
    </dl>
  );
}

const OP_TEXT = { create: "Created", update: "Updated", delete: "Deleted", bulk_update: "Updated", bulk_delete: "Deleted" };

function ChangeSection({ change, lookups, formatDateTime }) {
  const kind = change.op === "create" ? "create" : change.op?.includes("delete") ? "delete" : "update";
  const heading = `${OP_TEXT[change.op] || "Changed"} ${change.label || "record"}${change.name ? ` “${change.name}”` : ""}`;

  return (
    <section className="border border-gray-200 rounded">
      <header className="flex items-center gap-2 px-4 py-2.5 bg-gray-50 border-b border-gray-200">
        <KindBadge kind={kind} />
        <h4 className="text-sm font-semibold text-gray-900 truncate">{heading}</h4>
      </header>

      <div className="px-4 py-3">
        {change.op === "update" && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-gray-500 text-left">
                  <th className="py-1.5 pr-4 font-medium w-1/4">Field</th>
                  <th className="py-1.5 pr-4 font-medium">Before</th>
                  <th className="py-1.5 font-medium">After</th>
                </tr>
              </thead>
              <tbody>
                {(change.fields || []).map((f) => (
                  <tr key={f.field} className="border-t border-gray-100 align-top">
                    <td className="py-2 pr-4 text-gray-600">{fieldLabel(f.field)}</td>
                    <td className="py-2 pr-4">
                      <span className="inline-block rounded bg-red-50 px-2 py-0.5">
                        <Value value={f.before} lookups={lookups} formatDateTime={formatDateTime} tone="text-red-800" />
                      </span>
                    </td>
                    <td className="py-2">
                      <span className="inline-block rounded bg-green-50 px-2 py-0.5">
                        <Value value={f.after} lookups={lookups} formatDateTime={formatDateTime} tone="text-green-800" />
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {(change.op === "create" || change.op === "delete") && (
          <>
            <p className="text-xs text-gray-500 mb-2">
              {change.op === "create" ? "Created with these details:" : "This is what the record looked like when it was deleted:"}
            </p>
            <KeyValueList data={change.data} lookups={lookups} formatDateTime={formatDateTime} />
          </>
        )}

        {(change.op === "bulk_update" || change.op === "bulk_delete") && (
          <div className="space-y-2">
            <p className="text-sm text-gray-700">
              {change.count ? `Applied to ${change.count} ${change.label} record${change.count === 1 ? "" : "s"}` : `Applied to several ${change.label} records`}
              {change.op === "bulk_update" ? ", setting:" : "."}
            </p>
            {change.op === "bulk_update" && <KeyValueList data={change.set} lookups={lookups} formatDateTime={formatDateTime} />}
            <p className="text-xs text-gray-400">
              Individual before-values aren&apos;t available for changes made to many records at once.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

/** Everything about one entry — shared by the modal and the tests. */
export function AuditEntryView({ entry, formatDateTime, showTechnical = false, onToggleTechnical = () => {} }) {
  const details = entry?.details;
  const lookups = entry?.lookups || {};
  const changes = details?.changes || [];
  const overflow = details?.overflow || [];
  const request = details?.request;
  const submitted = request?.body && Object.keys(request.body).length > 0 ? request.body : null;
  const who = entry?.user ? `${entry.user.first_name} ${entry.user.last_name}` : "System";

  return (
    <>
      <dl className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-gray-50 border border-gray-200 rounded px-4 py-3">
        <div><dt className="text-xs text-gray-500">Done by</dt><dd className="text-sm text-gray-900">{who}</dd>{entry.user?.role && <dd className="text-xs text-gray-500 capitalize">{entry.user.role.replace(/_/g, " ")}</dd>}</div>
        <div><dt className="text-xs text-gray-500">When</dt><dd className="text-sm text-gray-900">{formatDateTime(entry.createdAt)}</dd></div>
        <div><dt className="text-xs text-gray-500">Module</dt><dd className="text-sm text-gray-900 capitalize">{(entry.resource_type || "—").replace(/_/g, " ")}</dd></div>
        <div><dt className="text-xs text-gray-500">From</dt><dd className="text-sm text-gray-900">{entry.ip_address || "—"}</dd></div>
      </dl>

      {entry.legacy && (
        <div className="bg-amber-50 border border-amber-200 rounded px-4 py-3 text-sm text-amber-800">
          This entry was recorded before field-by-field history existed, so only what was submitted can be shown — not what the values were before.
        </div>
      )}

      {changes.map((change, i) => (
        <ChangeSection key={`${change.model}-${change.id || i}-${i}`} change={change} lookups={lookups} formatDateTime={formatDateTime} />
      ))}

      {overflow.length > 0 && (
        <ul className="text-sm text-gray-600 list-disc pl-5 space-y-0.5">
          {overflow.map((o) => (
            <li key={`${o.model}-${o.op}`}>…and {o.count} more {o.label} record{o.count === 1 ? "" : "s"} {OP_TEXT[o.op]?.toLowerCase() || "changed"}</li>
          ))}
        </ul>
      )}

      {changes.length === 0 && (
        <div>
          <p className="text-xs text-gray-500 mb-2">
            {entry.legacy ? "Submitted data:" : submitted ? "No record in the database was changed by this action. What was submitted:" : "No record in the database was changed by this action."}
          </p>
          {submitted && <KeyValueList data={submitted} lookups={lookups} formatDateTime={formatDateTime} />}
        </div>
      )}

      <div className="border-t border-gray-100 pt-3">
        <button onClick={() => onToggleTechnical()} className="text-xs text-gray-500 hover:text-gray-700 inline-flex items-center gap-1">
          <svg className={`w-3 h-3 transition-transform ${showTechnical ? "rotate-90" : ""}`} fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" /></svg>
          Technical details
        </button>
        {showTechnical && (
          <dl className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5 text-xs">
            <div><dt className="text-gray-500">Request</dt><dd className="font-mono text-gray-800 break-all">{request?.method} {request?.path}</dd></div>
            <div><dt className="text-gray-500">Device</dt><dd className="text-gray-800 break-all">{entry.user_agent || "—"}</dd></div>
            <div><dt className="text-gray-500">Record ID</dt><dd className="font-mono text-gray-800 break-all">{entry.resource_id || "—"}</dd></div>
            <div><dt className="text-gray-500">Entry ID</dt><dd className="font-mono text-gray-800 break-all">{entry.id}</dd></div>
          </dl>
        )}
      </div>
    </>
  );
}

// ── The modal ───────────────────────────────────────────────────────────

export default function AuditLogDetailModal({ logId, onClose }) {
  const { formatDateTime } = usePreferences();
  const { showError } = useToast();
  const [entry, setEntry] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showTechnical, setShowTechnical] = useState(false);

  useEffect(() => {
    if (!logId) return undefined;
    let cancelled = false;
    settingsService.getAuditLog(logId)
      .then((res) => { if (!cancelled && res.success) setEntry(res.data); })
      .catch((err) => { if (!cancelled) { showError(err.response?.data?.message || err.message); onClose(); } })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [logId]);

  useEffect(() => {
    if (!logId) return undefined;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = "unset"; };
  }, [logId, onClose]);

  if (!logId) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="bg-white rounded shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col text-left" role="dialog" aria-modal="true" aria-label="Activity details">
        <div className="flex items-start justify-between gap-4 px-5 py-4 border-b border-gray-200">
          <div className="min-w-0">
            <div className="flex items-center gap-2 mb-1">
              {entry && <KindBadge kind={entry.kind} outcome={entry.outcome} />}
              {entry?.legacy && <span className="text-xs text-gray-500 bg-gray-100 border border-gray-200 rounded-full px-2 py-0.5">Older entry</span>}
            </div>
            <h3 className="text-base font-semibold text-gray-900 break-words">{entry ? entry.action : "Activity details"}</h3>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 flex-shrink-0" aria-label="Close">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="px-5 py-4 overflow-y-auto space-y-5">
          {loading && (
            <div className="py-10 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>
          )}

          {entry && (
            <AuditEntryView entry={entry} formatDateTime={formatDateTime} showTechnical={showTechnical} onToggleTechnical={() => setShowTechnical((v) => !v)} />
          )}
        </div>

        <div className="flex justify-end px-5 py-3 border-t border-gray-200">
          <button onClick={onClose} className="px-4 py-2 text-sm border border-gray-300 rounded text-gray-700 hover:bg-gray-50">Close</button>
        </div>
      </div>
    </div>
  );
}
