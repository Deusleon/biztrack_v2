import { Link } from "react-router-dom";

/**
 * Renders the structured text used by the Help articles and the legal pages.
 *
 * A document is a list of sections: { id, heading, blocks: [...] }, and a
 * block is one of
 *   { p: "text" }                      a paragraph
 *   { ul: ["…", "…"] }                 a bulleted list
 *   { ol: ["…", "…"] }                 a numbered list (steps)
 *   { note: "text", tone: "tip"|"warn" }   a call-out
 *   { table: { head: [...], rows: [[...], ...] } }
 * Inside any text: **bold**, *italic*, `code`, and [label](/app/path or https://…).
 */
const INLINE = /(\*\*[^*]+\*\*|\*[^*\s][^*]*\*|`[^`]+`|\[[^\]]+\]\([^)]+\))/g;

export function Inline({ text }) {
  return String(text).split(INLINE).filter(Boolean).map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) return <strong key={i} className="font-semibold text-gray-900">{part.slice(2, -2)}</strong>;
    if (part.startsWith("*") && part.endsWith("*") && part.length > 2) return <em key={i}>{part.slice(1, -1)}</em>;
    if (part.startsWith("`") && part.endsWith("`")) return <code key={i} className="bg-gray-100 px-1 py-0.5 rounded text-[0.85em] text-gray-800">{part.slice(1, -1)}</code>;
    const link = part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (link) {
      const [, label, href] = link;
      return /^(https?:|mailto:|tel:)/.test(href)
        ? <a key={i} href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer" className="text-primary hover:underline">{label}</a>
        : <Link key={i} to={href} className="text-primary hover:underline">{label}</Link>;
    }
    return part;
  });
}

const NOTE_STYLES = {
  tip: "bg-blue-50 border-blue-200 text-blue-900",
  warn: "bg-amber-50 border-amber-200 text-amber-900",
};

function Block({ block }) {
  if (block.p) return <p className="text-sm text-gray-700 leading-relaxed"><Inline text={block.p} /></p>;
  if (block.ul) return <ul className="list-disc pl-5 space-y-1.5 text-sm text-gray-700 leading-relaxed">{block.ul.map((t, i) => <li key={i}><Inline text={t} /></li>)}</ul>;
  if (block.ol) return <ol className="list-decimal pl-5 space-y-1.5 text-sm text-gray-700 leading-relaxed">{block.ol.map((t, i) => <li key={i}><Inline text={t} /></li>)}</ol>;
  if (block.note) {
    return (
      <div className={`border rounded px-4 py-3 text-sm leading-relaxed ${NOTE_STYLES[block.tone] || NOTE_STYLES.tip}`}>
        <Inline text={block.note} />
      </div>
    );
  }
  if (block.table) {
    return (
      <div className="overflow-x-auto">
        <table className="w-full text-sm border border-gray-200 rounded">
          <thead className="bg-gray-50">
            <tr>{block.table.head.map((h) => <th key={h} className="text-left font-semibold text-gray-700 px-3 py-2 border-b border-gray-200">{h}</th>)}</tr>
          </thead>
          <tbody>
            {block.table.rows.map((row, r) => (
              <tr key={r} className="align-top">
                {row.map((cell, c) => <td key={c} className="px-3 py-2 border-b border-gray-100 text-gray-700"><Inline text={cell} /></td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
  return null;
}

export default function DocContent({ sections }) {
  return (
    <div className="space-y-8">
      {sections.map((section) => (
        <section key={section.id} id={section.id} className="scroll-mt-24 space-y-3">
          {section.heading && <h2 className="text-base font-semibold text-gray-900">{section.heading}</h2>}
          {section.blocks.map((block, i) => <Block key={i} block={block} />)}
        </section>
      ))}
    </div>
  );
}
