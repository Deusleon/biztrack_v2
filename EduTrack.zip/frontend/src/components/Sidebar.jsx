// FILE PATH: frontend/src/components/Sidebar.jsx
import { useState, useRef, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { ACCESS_FOR_PATH } from '../utils/moduleAccess';
import BrandMark from './BrandMark';
import { useSubscription } from '../contexts/SubscriptionContext';

const Sidebar = ({ isOpen, toggleSidebar, isCollapsed }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, can } = useAuth();
  const { locked } = useSubscription();
  const navRef = useRef(null);
  const isNavigatingRef = useRef(false);

  const isActive = (path) => {
    // Exact match for dashboard and home routes
    if (path === '/dashboard' || path === '/') {
      return location.pathname === path;
    }
    if (location.pathname === path) return true;
    if (!location.pathname.startsWith(`${path}/`)) return false;

    // Don't stay highlighted on a sub-path that has its own, more
    // specific nav entry — e.g. /students shouldn't stay active on
    // /students/inquiries, which is its own item below.
    const allPaths = navigationItems.flatMap((section) => section.items.map((item) => item.path));
    const hasMoreSpecificMatch = allPaths.some(
      (other) => other !== path && other.startsWith(`${path}/`) && location.pathname.startsWith(other)
    );
    return !hasMoreSpecificMatch;
  };

  // Restore scroll position on mount
  useEffect(() => {
    const savedPosition = sessionStorage.getItem('sidebarScrollPosition');
    if (navRef.current && savedPosition && !isNavigatingRef.current) {
      navRef.current.scrollTop = parseInt(savedPosition, 10);
    }
    isNavigatingRef.current = false;
  }, []);

  // Save scroll position on scroll
  useEffect(() => {
    const navElement = navRef.current;
    if (navElement) {
      const handleScroll = () => {
        sessionStorage.setItem('sidebarScrollPosition', navElement.scrollTop.toString());
      };

      navElement.addEventListener('scroll', handleScroll, { passive: true });
      return () => navElement.removeEventListener('scroll', handleScroll);
    }
  }, []);

  // Handle navigation with preserved scroll
  const handleNavigation = (e, path) => {
    e.preventDefault();
    isNavigatingRef.current = true;

    // Save current scroll position
    if (navRef.current) {
      sessionStorage.setItem('sidebarScrollPosition', navRef.current.scrollTop.toString());
    }

    // Navigate programmatically
    navigate(path);

    // Close sidebar on mobile
    if (window.innerWidth < 1024) {
      toggleSidebar();
    }
  };

  // Navigation items based on user roles
  const navigationItems = [
    {
      section: 'Main',
      items: [
        {
          name: 'Dashboard',
          path: '/dashboard',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'teacher', 'student', 'parent', 'accountant', 'librarian', 'hr', 'transport_manager', 'hostel_warden'],
        },
      ],
    },
    {
      section: 'Academic',
      items: [
        {
          name: 'Students',
          path: '/students',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'teacher'],
        },
        {
          name: 'Online Applications',
          path: '/students/inquiries',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal'],
        },
        {
          name: 'Promotion',
          path: '/promotion',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal'],
        },
        {
          name: 'Attendance',
          path: '/attendance',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'teacher'],
        },
        {
          name: 'Classes',
          path: '/classes',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal'],
        },
        {
          name: 'Subjects',
          path: '/subjects',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'teacher'],
        },
        {
          name: 'Timetable',
          path: '/timetable',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'teacher', 'student'],
        },
      ],
    },
    {
      section: 'Examinations',
      items: [
        {
          name: 'Exams',
          path: '/exams',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'teacher', 'student'],
        },
        {
          name: 'Results',
          path: '/results',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'teacher', 'student', 'parent'],
        },
      ],
    },
    {
      section: 'Finance',
      items: [
        {
          name: 'Fee Management',
          path: '/fees',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'accountant', 'parent'],
        },
        {
          name: 'Expenses',
          path: '/expenses',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'accountant'],
        },
        {
          name: 'Payroll',
          path: '/payroll',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'hr', 'accountant', 'principal', 'teacher', 'librarian', 'transport_manager', 'hostel_warden'],
        },
      ],
    },
    {
      section: 'Facilities',
      items: [
        {
          name: 'Library',
          path: '/library',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'librarian', 'teacher', 'student', 'parent'],
        },
        {
          name: 'Transport',
          path: '/transport',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'transport_manager', 'student', 'parent'],
        },
        {
          name: 'Hostel',
          path: '/hostel',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'hostel_warden', 'student', 'parent'],
        },
        {
          name: 'Inventory',
          path: '/inventory',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
            </svg>
          ),
          roles: ['super_admin', 'admin'],
        },
      ],
    },
    {
      section: 'HR',
      items: [
        {
          name: 'Staff',
          path: '/staff',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'hr'],
        },
        {
          name: 'Leave',
          path: '/leave',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'hr', 'teacher', 'accountant', 'librarian', 'transport_manager', 'hostel_warden', 'student'],
        },
      ],
    },
    {
      section: 'Communication',
      items: [
        {
          name: 'Notifications',
          path: '/notifications',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'teacher', 'student', 'parent'],
        },
        {
          name: 'Messages',
          path: '/messages',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'teacher', 'accountant', 'librarian', 'hr', 'transport_manager', 'hostel_warden'],
        },
      ],
    },
    {
      section: 'Reports',
      items: [
        {
          name: 'Analytics',
          path: '/analytics',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal'],
        },
        {
          name: 'Reports',
          path: '/reports',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'accountant'],
        },
      ],
    },
    {
      section: 'Documents',
      items: [
        {
          name: 'ID Cards',
          path: '/documents/id-card',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7zM3 5h18a1 1 0 011 1v12a1 1 0 01-1 1H3a1 1 0 01-1-1V6a1 1 0 011-1z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal'],
        },
        {
          name: 'Certificates',
          path: '/documents/certificates',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal'],
        },
      ],
    },
    {
      section: 'Settings',
      items: [
        {
          name: 'Campus',
          path: '/campus',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
          ),
          roles: ['super_admin', 'admin'],
        },
        {
          name: 'Subscription',
          path: '/subscription',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal'],
        },
        {
          name: 'Settings',
          path: '/settings',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal'],
        },
      ],
    },
    {
      // Open to everyone who is signed in: no "Open …" permission, so it follows the roles list.
      section: 'Help',
      items: [
        {
          name: 'User Guide',
          path: '/user-guide',
          icon: (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          ),
          roles: ['super_admin', 'admin', 'principal', 'teacher', 'student', 'parent', 'accountant', 'librarian', 'hr', 'transport_manager', 'hostel_warden'],
        },
      ],
    },
  ];

  // A module is in the menu if the person holds its "Open …" permission
  // (Settings → Permissions): untick it and the module disappears. Items with no
  // such permission (Dashboard, Notifications) show for the roles they were built
  // for. If the server hasn't said what this person may do yet (an old session
  // that has not reloaded), fall back to the roles so the menu is never empty.
  const knowsPermissions = Array.isArray(user?.effective_permissions);
  const showItem = (item) => {
    // A locked school sees the Subscription page and nothing else.
    if (locked) return item.path === '/subscription';
    const key = ACCESS_FOR_PATH[item.path];
    if (key && knowsPermissions) return can(key);
    return item.roles.includes(user?.role);
  };
  const filteredNavigation = navigationItems.map(section => ({
    ...section,
    items: section.items.filter(showItem)
  })).filter(section => section.items.length > 0);

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={toggleSidebar}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 z-30 h-screen transition-all duration-300 ease-in-out print:hidden ${isOpen ? 'translate-x-0' : '-translate-x-full'
          } lg:translate-x-0 ${isCollapsed ? 'lg:w-20' : 'lg:w-64'} w-64`}
      >
        <div className="h-full flex flex-col gradient-primary-dark text-white shadow-2xl sidebar-edge">
          {/* Logo & Brand */}
          <div className={`flex items-center border-b border-primary-dark transition-all duration-300 ${isCollapsed ? 'lg:justify-center p-4 lg:py-2.5 lg:px-4' : 'justify-between py-2.5 px-5'
            }`}>
            <div className={`flex items-center space-x-3 ${isCollapsed ? 'lg:space-x-0' : ''}`}>
              <BrandMark className="w-12 h-auto flex-shrink-0" />
              <div className={`${isCollapsed ? 'lg:hidden' : ''}`}>
                <h1 className="text-xl font-bold tracking-tight">EduTrack</h1>
                <p className="text-xs text-white opacity-80">School Management</p>
              </div>
            </div>
            <button
              onClick={toggleSidebar}
              className="lg:hidden text-white hover:bg-primary-dark hover:opacity-80 p-2 rounded"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Navigation */}
          <nav ref={navRef} className="flex-1 overflow-y-auto py-6 px-3 space-y-6 scrollbar-thin scrollbar-thumb-primary-dark scrollbar-track-transparent hover:scrollbar-thumb-primary">
            {filteredNavigation.map((section) => (
              <div key={section.section}>
                <h3 className={`px-4 mb-2 text-xs text-left font-semibold text-white opacity-70 uppercase tracking-wider ${isCollapsed ? 'lg:hidden' : ''
                  }`}>
                  {section.section}
                </h3>
                <div className="space-y-1">
                  {section.items.map((item) => (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={(e) => handleNavigation(e, item.path)}
                      title={isCollapsed ? item.name : ''}
                      className={`flex items-center py-2.5 text-sm font-medium rounded transition-all duration-200 ${isCollapsed ? 'lg:justify-center lg:px-2' : 'px-4'
                        } ${isActive(item.path)
                          ? 'bg-white text-primary-dark shadow-lg'
                          : 'text-white opacity-90 hover:bg-primary-dark hover:opacity-100'
                        }`}
                    >
                      <span className={`${isCollapsed ? 'lg:mr-0' : 'mr-3'}`}>{item.icon}</span>
                      <span className={`${isCollapsed ? 'lg:hidden' : ''}`}>{item.name}</span>
                      {isActive(item.path) && !isCollapsed && (
                        <span className="ml-auto w-2 h-2 bg-primary rounded-full"></span>
                      )}
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </nav>

          {/* User Profile */}
          <div className={`p-4 border-t border-primary-dark ${isCollapsed ? 'lg:px-2' : ''}`}>
            <div className={`flex items-center rounded bg-primary-dark bg-opacity-50 transition-all duration-300 ${isCollapsed ? 'lg:flex-col lg:space-x-0 lg:space-y-2 lg:py-3 px-2 py-3' : 'space-x-3 px-2 py-3'
              }`}>
              <div className="w-10 h-10 rounded-full gradient-primary flex items-center justify-center text-white font-semibold flex-shrink-0">
                {user?.first_name?.charAt(0)}{user?.last_name?.charAt(0)}
              </div>
              <div className={`flex-1 min-w-0 ${isCollapsed ? 'lg:hidden' : ''}`}>
                <p className="text-sm font-medium text-white truncate">
                  {user?.first_name} {user?.last_name}
                </p>
                <p className="text-xs text-white opacity-80 truncate capitalize">
                  {user?.role?.replace('_', ' ')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;