import emblemWhite from "../assets/brand/edutrack-emblem-white.png";
import emblemColor from "../assets/brand/edutrack-emblem.png";
import logoFull from "../assets/brand/edutrack-logo.png";

/**
 * The EduTrack logo.
 *
 * variant="white"  – the emblem in white, for the coloured gradient headers
 *                    (Sidebar, sign-in, password pages). Set the size with
 *                    Tailwind width classes, e.g. className="w-12 h-auto".
 * variant="color"  – the full-colour emblem, for white backgrounds.
 * variant="full"   – the full-colour logo with the "EduTrack SYSTEM" wordmark.
 */
const SOURCES = { white: emblemWhite, color: emblemColor, full: logoFull };

export default function BrandMark({ variant = "white", className = "", alt = "EduTrack" }) {
  return <img src={SOURCES[variant] || emblemWhite} alt={alt} className={className} draggable={false} />;
}
