// FILE PATH: frontend/src/components/ExcelImportPage.jsx
/**
 * The page behind "Bulk Upload" for students and for staff. Same four steps for both:
 *   1. download the template   2. upload the filled file   3. CHECK it (errors, duplicates — nothing saved yet)
 *   4. choose what to import and confirm
 * What differs between students and staff is passed in as `config`.
 */
import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../contexts/ToastContext";
import MainLayout from "./MainLayout";
import { Button, ConfirmModal } from "./ui";
import ImportPreviewTable from "./ImportPreviewTable";
import { downloadIssueReport } from "../utils/importReport";
import Icon from "../components/ui/Icon";

const addInto = (target, source) => {
  Object.entries(source || {}).forEach(([k, v]) => {
    if (typeof v === "number") target[k] = (target[k] || 0) + v;
    else if (v && typeof v === "object") { target[k] = target[k] || {}; addInto(target[k], v); }
  });
};

function Tile({ label, value, tone = "gray", hint }) {
  const tones = { gray: "text-gray-900", green: "text-green-600", red: "text-red-600", amber: "text-amber-600" };
  return (
    <div className="border border-gray-200 rounded p-3 bg-white" title={hint}>
      <div className={`text-2xl font-semibold ${tones[tone]}`}>{value}</div>
      <div className="text-xs text-gray-500 mt-0.5">{label}</div>
    </div>
  );
}

export default function ExcelImportPage({ config }) {
  const { noun, nounPlural, idKey, idLabel, detailKey, detailLabel, chunkSize = 25, importVerb, importedWord } = config;
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();
  const fileInputRef = useRef(null);

  const [preparingTemplate, setPreparingTemplate] = useState(false);
  const [fileName, setFileName] = useState("");
  const [parsedRows, setParsedRows] = useState(null);
  const [checking, setChecking] = useState(false);
  const [preview, setPreview] = useState(null); // { summary, rows }
  const [selected, setSelected] = useState(new Set());
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState(null);

  const reset = () => {
    setFileName(""); setParsedRows(null); setPreview(null); setSelected(new Set()); setResults(null); setProgress(0);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleDownloadTemplate = async () => {
    try {
      setPreparingTemplate(true);
      await config.downloadTemplate();
      showSuccess("Template downloaded");
    } catch (err) { showError(err.message || "Failed to prepare the template"); } finally { setPreparingTemplate(false); }
  };

  const runCheck = async (rows) => {
    try {
      setChecking(true);
      const res = await config.preview(rows);
      if (!res.success) throw new Error(res.message || "The check failed");
      setPreview(res.data);
      // Ready rows start ticked. Possible duplicates start UNticked: a person decides. Errors can never be ticked.
      setSelected(new Set(res.data.rows.filter((r) => r.status === "ready").map((r) => r.row)));
    } catch (err) {
      setPreview(null);
      showError(err.message || "The file could not be checked");
    } finally { setChecking(false); }
  };

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setResults(null); setPreview(null); setFileName(file.name);
    try {
      const rows = await config.parseFile(file);
      setParsedRows(rows);
      await runCheck(rows);
    } catch (err) {
      setParsedRows(null);
      showError(err.message || "Failed to read the uploaded file");
    }
  };

  const toImport = parsedRows && preview ? parsedRows.filter((r) => selected.has(r.__row)) : [];
  const chosenDuplicates = preview ? preview.rows.filter((r) => r.status === "possible_duplicate" && selected.has(r.row)).length : 0;
  const skipped = preview ? preview.summary.total - toImport.length : 0;
  const readyWithWarnings = preview ? preview.rows.filter((r) => r.status === "ready" && r.warnings.length > 0).length : 0;

  // Sent in chunks so the progress bar shows something real: each finished chunk is rows genuinely processed.
  const handleImport = async () => {
    try {
      setUploading(true); setProgress(0);
      const total = toImport.length;
      const summary = { total, created: 0, failed: 0 };
      const all = [];
      for (let start = 0; start < total; start += chunkSize) {
        const chunk = toImport.slice(start, start + chunkSize);
        try {
          const response = await config.importChunk(chunk);
          if (response.success) { addInto(summary, { ...response.data.summary, total: 0 }); all.push(...response.data.results); }
        } catch (chunkErr) {
          // A whole chunk failing (network blip, server refusing) never aborts the rest.
          chunk.forEach((row) => all.push({ row: row.__row, name: `${row.first_name || ""} ${row.last_name || ""}`.trim() || `Row ${row.__row}`, [idKey]: row[idKey] || null, status: "failed", message: chunkErr.message || "This batch could not be submitted" }));
          summary.failed += chunk.length;
          // If the server refused because a safety backup could not be made, every other chunk would fail the same way.
          if (chunkErr.code === "BACKUP_REQUIRED") {
            toImport.slice(start + chunkSize).forEach((row) => all.push({ row: row.__row, name: `${row.first_name || ""} ${row.last_name || ""}`.trim(), [idKey]: row[idKey] || null, status: "failed", message: "Not attempted — the safety backup could not be made" }));
            summary.failed += Math.max(0, total - start - chunkSize);
            break;
          }
        }
        setProgress(Math.round((Math.min(start + chunkSize, total) / total) * 100));
      }
      setResults({ summary, results: all.sort((a, b) => a.row - b.row) });
      if (summary.failed === 0) showSuccess(`All ${summary.created} ${summary.created === 1 ? noun : nounPlural} ${importedWord} successfully`);
      else showError(`${summary.created} ${importedWord}, ${summary.failed} failed — see the table below`);
    } catch (err) { showError(err.message || "The import failed"); } finally { setUploading(false); }
  };

  const s = preview?.summary;
  const extraCol = config.resultExtra;

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 gap-3">
          <div className="text-left">
            <h1 className="text-xl font-bold text-gray-900">{config.title}</h1>
            <p className="text-sm text-gray-500 mt-0.5">{config.subtitle}</p>
          </div>
          <button onClick={() => navigate(config.backPath)} className="border border-gray-300 text-sm text-gray-700 px-4 py-2 rounded hover:bg-gray-50 whitespace-nowrap">{config.backLabel}</button>
        </div>

        {/* Step 1 */}
        <div className="bg-white p-5 rounded shadow space-y-2 text-left">
          <h2 className="font-semibold text-gray-900">Step 1: Download the Template</h2>
          <p className="text-sm text-gray-500">{config.templateHelp}</p>
          <Button onClick={handleDownloadTemplate} disabled={preparingTemplate}>{preparingTemplate ? "Preparing..." : "Download Template (.xlsx)"}</Button>
        </div>

        {/* Step 2 */}
        <div className="bg-white p-5 rounded shadow space-y-3 text-left">
          <h2 className="font-semibold text-gray-900">Step 2: Upload the Filled Template</h2>
          <input ref={fileInputRef} type="file" accept=".xlsx,.xls" onChange={handleFileChange} disabled={uploading || checking}
            className="block w-full text-sm text-gray-700 border border-gray-300 rounded p-2 disabled:opacity-50" />
          {fileName && !results && (
            <div className="flex flex-wrap items-center justify-between gap-2 text-sm bg-gray-50 border border-gray-200 rounded p-3">
              <span><strong>{fileName}</strong>{parsedRows ? ` — ${parsedRows.length} row(s) read` : ""}</span>
              {!uploading && <button onClick={reset} className="text-gray-500 hover:text-gray-700 text-xs underline">Remove</button>}
            </div>
          )}
          {checking && (
            <div className="flex items-center gap-3">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary flex-shrink-0" />
              <p className="text-sm text-gray-500">Checking every row — nothing is saved yet…</p>
            </div>
          )}
          {parsedRows && !preview && !checking && !results && (
            <Button variant="secondary" onClick={() => runCheck(parsedRows)}>Check the file again</Button>
          )}
        </div>

        {/* Step 3 — the check */}
        {preview && !results && (
          <div className="bg-white p-5 rounded shadow space-y-4 text-left">
            <div>
              <h2 className="font-semibold text-gray-900">Step 3: Check the File</h2>
              <p className="text-sm text-gray-500 mt-0.5">Nothing has been saved. Rows with errors cannot be imported — fix them in Excel and upload again, or import the good rows now and the rest later.</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <Tile label="Rows in the file" value={s.total} />
              <Tile label="Ready to import" value={s.ready} tone="green" />
              <Tile label="Possible duplicates" value={s.possible_duplicates} tone={s.possible_duplicates ? "amber" : "gray"} hint="Same name and date of birth (or national ID) already exists, or repeats in the file. Unticked until you decide." />
              <Tile label="Rows with errors" value={s.errors} tone={s.errors ? "red" : "gray"} />
              <Tile label="Duplicates blocked" value={s.blocked_duplicates} tone={s.blocked_duplicates ? "red" : "gray"} hint="Same admission number / employee number / email / phone as someone already saved, or repeated in the file." />
            </div>

            {s.slots_left !== null && s.slots_left !== undefined && (
              <p className={`text-sm ${s.over_limit ? "text-red-600" : "text-gray-600"}`}>
                Your subscription plan allows {s.plan_limit} students; there is room for {s.slots_left} more.
                {s.over_limit > 0 && ` ${s.over_limit} row(s) are beyond the limit and cannot be imported until the plan is upgraded.`}
              </p>
            )}
            {readyWithWarnings > 0 && <p className="text-sm text-amber-600">{readyWithWarnings} ready row(s) have warnings — they will still be imported, but look at them first.</p>}

            <ImportPreviewTable rows={preview.rows} selected={selected} onChange={setSelected} idKey={idKey} idLabel={idLabel} detailKey={detailKey} detailLabel={detailLabel} />

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <Button onClick={() => setConfirmOpen(true)} disabled={uploading || toImport.length === 0}>
                {uploading ? "Importing…" : `${importVerb} ${toImport.length} ${toImport.length === 1 ? noun : nounPlural}`}
              </Button>
              {(s.errors > 0 || s.possible_duplicates > 0 || readyWithWarnings > 0) && (
                <Button variant="secondary" onClick={() => downloadIssueReport({ rows: preview.rows, idLabel, fileName: `${config.reportName}_issues.xlsx` })}>Download the problems (Excel)</Button>
              )}
              <Button variant="secondary" onClick={reset} disabled={uploading}>Start over</Button>
              <span className="text-xs text-gray-500">{toImport.length} of {s.total} rows will be imported{skipped > 0 ? `; ${skipped} left out` : ""}.</span>
            </div>

            {uploading && (
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary flex-shrink-0" />
                  <p className="text-sm text-gray-500">Importing {toImport.length} {nounPlural}… {progress}% done. Please don't close this page.</p>
                </div>
                <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden"><div className="h-full bg-primary rounded-full transition-all duration-300" style={{ width: `${progress}%` }} /></div>
              </div>
            )}
          </div>
        )}

        {/* Results */}
        {results && (
          <div className="bg-white p-5 rounded shadow space-y-3 text-left">
            <h2 className="font-semibold text-gray-900">Results</h2>
            <div className="flex gap-4 text-sm">
              <span className="text-gray-600">Tried: <strong>{results.summary.total}</strong></span>
              <span className="text-green-700">{importedWord[0].toUpperCase() + importedWord.slice(1)}: <strong>{results.summary.created}</strong></span>
              <span className="text-red-700">Failed: <strong>{results.summary.failed}</strong></span>
              {skipped > 0 && <span className="text-gray-500">Left out: <strong>{skipped}</strong></span>}
            </div>
            {config.resultSummaryExtra && config.resultSummaryExtra(results.summary)}
            <div className="overflow-x-auto border border-gray-200 rounded">
              <table className="min-w-full text-sm">
                <thead className="bg-gray-50"><tr>
                  <th className="px-3 py-2 text-left">Row</th><th className="px-3 py-2 text-left">Name</th><th className="px-3 py-2 text-left">{idLabel}</th><th className="px-3 py-2 text-left">Status</th>
                  {extraCol && <th className="px-3 py-2 text-left">{extraCol.header}</th>}
                  <th className="px-3 py-2 text-left">Message</th>
                </tr></thead>
                <tbody>
                  {results.results.map((r) => (
                    <tr key={r.row} className="border-t border-gray-100">
                      <td className="px-3 py-2">{r.row}</td><td className="px-3 py-2">{r.name}</td><td className="px-3 py-2">{r[idKey] || "—"}</td>
                      <td className="px-3 py-2"><span className={`px-2 py-0.5 rounded text-xs ${r.status === "created" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>{r.status === "created" ? "Created" : "Failed"}</span></td>
                      {extraCol && <td className="px-3 py-2 text-gray-600">{r.status === "created" ? extraCol.render(r) : "—"}</td>}
                      <td className="px-3 py-2 text-gray-600">{r.message}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => navigate(config.backPath)}>{config.goToList}</Button>
              <button onClick={reset} className="border border-gray-300 text-sm text-gray-700 px-4 py-2 rounded hover:bg-gray-50 max-sm:px-3" aria-label="Upload Another File" title="Upload Another File"><Icon name="upload" className="w-4 h-4 sm:hidden" /><span className="hidden sm:inline">Upload Another File</span></button>
            </div>
          </div>
        )}
      </div>

      <ConfirmModal
        isOpen={confirmOpen}
        variant="info"
        title={`${importVerb} ${toImport.length} ${toImport.length === 1 ? noun : nounPlural}?`}
        message={`${toImport.length} ${toImport.length === 1 ? noun : nounPlural} will be saved${chosenDuplicates > 0 ? `, including ${chosenDuplicates} marked as possible duplicates that you chose to keep` : ""}. ${skipped > 0 ? `${skipped} row(s) are left out. ` : ""}A safety backup of the whole database is made first.`}
        confirmText={`${importVerb} now`}
        cancelText="Go back"
        onConfirm={handleImport}
        onClose={() => setConfirmOpen(false)}
      />
    </MainLayout>
  );
}
