import { useState, useEffect, useRef } from "react";
import { useLocation, Link, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useSubscription } from "../contexts/SubscriptionContext";
import { useCampus } from "../contexts/CampusContext";
import { useAcademicYear } from "../contexts/AcademicYearContext";
import { notificationService, subscriptionService, searchService } from "../services/api";
import Sidebar from "./Sidebar";
import { Select } from "./ui";
import TimeAgo from "./TimeAgo";
import Icon from "./ui/Icon";
import InstallBanner from "./InstallBanner";
import { isStandalone } from "../utils/pwa";
import { attachPullToRefresh } from "../utils/pullToRefresh";

// Colour-codes each result so the type is readable before the text is.
const SEARCH_TYPE_STYLES = {
  student: "bg-blue-100 text-blue-600",
  staff: "bg-purple-100 text-purple-600",
  class: "bg-green-100 text-green-600",
  book: "bg-amber-100 text-amber-700",
  contact: "bg-gray-100 text-gray-600",
};

const MainLayout = ({ children }) => {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => {
    // Persist collapsed state in localStorage
    const saved = localStorage.getItem("sidebarCollapsed");
    return saved === "true";
  });
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [subscriptionWarning, setSubscriptionWarning] = useState(null);

  // Phones and tablets: search and the campus / year pickers do not fit in the bar, so they open on demand.
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  // Phones: search / year+campus / reload share one "more" dropdown instead of three separate icons.
  const [moreOpen, setMoreOpen] = useState(false);
  const moreRef = useRef(null);
  const notifRef = useRef(null);
  // The installed app has no browser bar, so it gets its own reload button — and, on touch screens, pull-to-refresh.
  const [installed] = useState(() => isStandalone());
  const [reloading, setReloading] = useState(false);
  useEffect(() => {
    // Android's installed app already pulls to refresh; iPhones and iPads have no way to reload at all.
    const ios = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    if (!installed || !ios) return undefined;
    return attachPullToRefresh();
  }, [installed]);
  const reloadApp = () => { setReloading(true); window.location.reload(); };

  useEffect(() => {
    if (!notificationOpen && !moreOpen) return undefined;
    const onPointerDown = (e) => {
      if (notificationOpen && notifRef.current && !notifRef.current.contains(e.target)) setNotificationOpen(false);
      if (moreOpen && moreRef.current && !moreRef.current.contains(e.target)) setMoreOpen(false);
    };
    const onKeyDown = (e) => { if (e.key === "Escape") { setNotificationOpen(false); setMoreOpen(false); } };
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("touchstart", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("touchstart", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [notificationOpen, moreOpen]);

  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searching, setSearching] = useState(false);
  const searchRef = useRef(null);

  // Profile menu opens on click, not hover — hovering over the picture on the
  // way to something else kept popping it open. It closes on a click anywhere
  // else, on Escape, or when an item in it is chosen.
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef(null);
  useEffect(() => {
    if (!profileOpen) return undefined;
    const onPointerDown = (e) => { if (profileRef.current && !profileRef.current.contains(e.target)) setProfileOpen(false); };
    const onKeyDown = (e) => { if (e.key === "Escape") setProfileOpen(false); };
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [profileOpen]);

  // Debounced so typing a name doesn't fire a request per keystroke.
  // Queries under two characters are skipped entirely — a single letter
  // matches most of the school and is never what someone meant.
  useEffect(() => {
    const term = searchQuery.trim();
    if (term.length < 2) {
      setSearchResults([]);
      setSearchOpen(false);
      return undefined;
    }

    setSearching(true);
    setSearchOpen(true);
    const timer = setTimeout(() => {
      searchService.search(term)
        .then((res) => { if (res?.success) setSearchResults(res.data.results || []); })
        .catch(() => setSearchResults([]))
        .finally(() => setSearching(false));
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Close on a click anywhere outside the box.
  useEffect(() => {
    if (!searchOpen) return undefined;
    const handler = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target)) setSearchOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [searchOpen]);

  // A two-day grace period nobody can see isn't a grace period — the
  // school would simply be working one day and locked out the next. This
  // checks once per mount and only renders when there's something to say.
  useEffect(() => {
    let cancelled = false;
    subscriptionService.getMine()
      .then((res) => {
        if (cancelled || !res?.success) return;
        const { evaluation, over_student_limit: overLimit, plan } = res.data;

        if (evaluation?.inGrace) {
          setSubscriptionWarning({
            tone: "danger",
            text: `Your subscription has ended. About ${evaluation.graceHoursLeft} hour(s) of access remain before EduTrack locks.`,
          });
        } else if (evaluation?.daysLeft > 0 && evaluation.daysLeft <= 7) {
          setSubscriptionWarning({
            tone: "warning",
            text: `Your ${plan?.name || "EduTrack"} subscription expires in ${evaluation.daysLeft} day(s).`,
          });
        } else if (overLimit) {
          setSubscriptionWarning({
            tone: "warning",
            text: "You have more active students than your plan allows. You can't admit new students until you upgrade.",
          });
        }
      })
      .catch(() => {
        // Silent: a failed check must never get in the way of using the app.
      });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    const loadUnread = () => {
      notificationService.getUnreadCount().then((res) => { if (res.success) setUnreadCount(res.data.count); }).catch(() => {});
    };
    loadUnread();
    const interval = setInterval(loadUnread, 60000); // refresh every minute
    return () => clearInterval(interval);
  }, []);

  const toggleNotifications = () => {
    const opening = !notificationOpen;
    setNotificationOpen(opening);
    if (opening) {
      notificationService.getMyNotifications({ limit: 6 }).then((res) => { if (res.success) setNotifications(res.data); }).catch(() => {});
    }
  };

  const handleNotificationClick = async (n) => {
    if (!n.is_read) {
      try { await notificationService.markAsRead(n.id); setUnreadCount((c) => Math.max(0, c - 1)); } catch { /* ignore */ }
    }
  };

  const { user, logout, can } = useAuth();
  const { locked } = useSubscription();
  // Without the Notifications permission the bell isn't shown at all.
  const showBell = !Array.isArray(user?.effective_permissions) || can('notifications.access');
  const { currentCampus, campuses, setCurrentCampus, canSwitchCampus, loading: campusLoading } = useCampus();
  const { currentAcademicYear, setCurrentAcademicYear, yearOptions } = useAcademicYear();
  const location = useLocation();

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);
  const toggleSidebarCollapse = () => {
    const newState = !sidebarCollapsed;
    setSidebarCollapsed(newState);
    localStorage.setItem("sidebarCollapsed", newState.toString());
  };

  const isRouteParam = (segment) => {
    const isNumber = /^\d+$/.test(segment);

    // UUID v4 / generic UUID
    const isUUID =
      /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(
        segment
      );

    return isNumber || isUUID;
  };

  // Breadcrumb configuration
  const getBreadcrumbs = () => {
    const paths = location.pathname.split("/").filter(Boolean);
    const breadcrumbs = [{ name: "Home", path: "/dashboard" }];

    let currentPath = "";

    paths.forEach((segment) => {
      // ❌ Skip UUIDs & numeric IDs
      if (isRouteParam(segment)) return;

      currentPath += `/${segment}`;

      const name = segment
        .replace(/-/g, " ")
        .replace(/\b\w/g, (c) => c.toUpperCase());

      breadcrumbs.push({
        name,
        path: currentPath,
      });
    });

    return breadcrumbs;
  };

  const breadcrumbs = getBreadcrumbs();

  // Keep the trail short. Everything above the last two levels is reachable
  // from the sidebar anyway, so showing it only costs space.
  const visibleBreadcrumbs = breadcrumbs.length > 2 ? breadcrumbs.slice(-2) : breadcrumbs;

  return (
    <div className=" bg-gray-100">
      {/* Sidebar */}
      <Sidebar
        isOpen={sidebarOpen}
        toggleSidebar={toggleSidebar}
        isCollapsed={sidebarCollapsed}
      />

      {/* Main Content */}
      <div
        className={`flex flex-col min-h-screen transition-all duration-300 print:!pl-0 ${
          sidebarCollapsed ? "lg:pl-20" : "lg:pl-64"
        }`}
      >
        {/* Top Header */}
        <header className="sticky top-0 z-10 bg-white shadow-sm border-b border-gray-200 print:hidden safe-top">
          <div className="flex items-center justify-between gap-2 px-3 sm:px-4 md:px-5 py-2.5">
            {/* Left Section */}
            <div className="flex items-center space-x-3 sm:space-x-4 min-w-0">
              {/* Desktop Sidebar Toggle */}
              <button
                onClick={toggleSidebarCollapse}
                className="hidden lg:block text-gray-600 hover:text-gray-900 focus:outline-none"
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                </svg>
              </button>

              {/* Mobile Menu Button */}
              <button
                onClick={toggleSidebar}
                className="lg:hidden text-gray-600 hover:text-gray-900 focus:outline-none"
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                </svg>
              </button>

              {/* Breadcrumbs — only from xl up, and only the last two levels.
                  With the campus picker, year picker and search all sharing
                  this row, a full trail was the first thing to crowd it out;
                  the deepest couple of levels carry nearly all the meaning. */}
              {/* Phones / tablets: just the name of the page you are on. */}
              <span className="xl:hidden text-sm font-semibold text-gray-900 truncate min-w-0">
                {visibleBreadcrumbs[visibleBreadcrumbs.length - 1]?.name}
              </span>

              <nav className="hidden xl:flex items-center space-x-2 text-sm min-w-0">
                {visibleBreadcrumbs.map((crumb, index) => (
                  <div key={crumb.path} className="flex items-center">
                    {index > 0 && (
                      <svg
                        className="w-4 h-4 mx-2 text-gray-400"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    )}
                    {index === visibleBreadcrumbs.length - 1 ? (
                      <span className="text-gray-900 font-medium truncate max-w-[200px]">
                        {crumb.name}
                      </span>
                    ) : (
                      <Link
                        to={crumb.path}
                        className="text-gray-500 hover:text-gray-700"
                      >
                        {crumb.name}
                      </Link>
                    )}
                  </div>
                ))}
              </nav>
            </div>

            {/* Campus Selector — shown only for admin/principal roles */}
            {canSwitchCampus && (
              <div className="hidden xl:flex items-center space-x-2 border-l border-gray-200 pl-4">
                <svg className="w-4 h-4 text-gray-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-2 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
                {campusLoading ? (
                  <span className="text-xs text-gray-400">Loading…</span>
                ) : campuses.length === 0 ? (
                  <span className="text-xs text-gray-400 italic">No campuses</span>
                ) : campuses.length === 1 ? (
                  // A single campus is context, not a choice — labelled and
                  // truncated so a long school name can't push the rest of
                  // the bar off screen.
                  <div className="min-w-0">
                    <p className="text-[10px] text-left uppercase tracking-wide text-gray-400 leading-none">Campus</p>
                    <p className="text-sm font-medium text-gray-800 truncate max-w-[180px] leading-tight" title={currentCampus?.name ?? campuses[0].name}>
                      {currentCampus?.name ?? campuses[0].name}
                    </p>
                  </div>
                ) : (
                  <Select
                    size="sm"
                    title="Switch working campus"
                    className="w-[200px]"
                    dropdownClassName="min-w-[240px]"
                    value={currentCampus?.id ?? ''}
                    onChange={(e) => {
                      const selected = campuses.find((c) => c.id === e.target.value);
                      if (selected) setCurrentCampus(selected);
                    }}
                    options={campuses.map((c) => ({ value: c.id, label: `${c.name}${c.code ? ` (${c.code})` : ''}` }))}
                  />
                )}
              </div>
            )}

            {/* Academic Year Selector */}
            <div className="hidden xl:flex items-center space-x-2 border-l border-gray-200 pl-4">
              <svg className="w-4 h-4 text-gray-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <Select
                size="sm"
                title="Academic Year"
                className="w-[130px]"
                dropdownClassName="min-w-[130px]"
                value={currentAcademicYear}
                onChange={(e) => setCurrentAcademicYear(e.target.value)}
                options={yearOptions.map((y) => ({ value: y, label: y }))}
              />
            </div>

            {/* Right Section */}
            <div className="flex items-center space-x-1 sm:space-x-4 flex-shrink-0">
              {/* Phones: search, year/campus and reload live in one dropdown */}
              <div className="relative xl:hidden" ref={moreRef}>
                <button type="button" onClick={() => { setMoreOpen((o) => !o); setNotificationOpen(false); }} className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded" aria-label="More" aria-haspopup="menu" aria-expanded={moreOpen} title="More">
                  <Icon name="dots" className="w-5 h-5" />
                </button>
                {moreOpen && (
                  <div role="menu" className="absolute right-0 mt-2 w-56 bg-white rounded shadow-lg border border-gray-200 py-1 z-50">
                    {!locked && (
                      <button type="button" role="menuitem" onClick={() => { setMoreOpen(false); setMobileSearchOpen(true); }} className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-3">
                        <Icon name="search" className="w-4 h-4" /> Search
                      </button>
                    )}
                    <button type="button" role="menuitem" onClick={() => { setMoreOpen(false); setFiltersOpen(true); }} className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-3">
                      <Icon name="sliders" className="w-4 h-4" /> Academic year &amp; campus
                    </button>
                    {installed && (
                      <button type="button" role="menuitem" onClick={() => { setMoreOpen(false); reloadApp(); }} className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-3">
                        <Icon name="refresh" className={`w-4 h-4 ${reloading ? "animate-spin" : ""}`} /> Reload page
                      </button>
                    )}
                  </div>
                )}
              </div>
              {installed && (
                <button type="button" onClick={reloadApp} className="hidden xl:inline-flex p-2 text-gray-600 hover:text-gray-900" aria-label="Reload" title="Reload the page">
                  <Icon name="refresh" className={`w-5 h-5 ${reloading ? "animate-spin" : ""}`} />
                </button>
              )}

              {/* Search Bar */}
              <div
                className={locked ? "hidden" : mobileSearchOpen
                  ? "fixed inset-x-0 top-0 z-40 bg-white p-3 shadow-lg xl:static xl:p-0 xl:shadow-none xl:block"
                  : "hidden xl:block relative"}
                ref={searchRef}
              >
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onFocus={() => searchResults.length > 0 && setSearchOpen(true)}
                    onKeyDown={(e) => { if (e.key === "Escape") setSearchOpen(false); }}
                    placeholder="Search students, staff, classes…"
                autoFocus={mobileSearchOpen}
                    className="w-full xl:w-64 pl-10 pr-8 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 ring-primary focus:border-transparent"
                  />
                  <svg
                    className="absolute left-3 top-2.5 w-5 h-5 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                  </svg>
                  {searchQuery && (
                    <button
                      onClick={() => { setSearchQuery(""); setSearchOpen(false); }}
                      className="absolute right-2 top-2.5 text-gray-400 hover:text-gray-600"
                      aria-label="Clear search"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  )}
                </div>

                {searchOpen && (
                  <div className="absolute left-3 right-3 xl:left-auto xl:right-0 mt-1 xl:w-96 bg-white rounded shadow-lg border border-gray-100 z-50 max-h-[70vh] xl:max-h-96 overflow-y-auto">
                    {searching ? (
                      <div className="py-6 text-center">
                        <div className="inline-block animate-spin rounded-full h-5 w-5 border-b-2 border-primary" />
                      </div>
                    ) : searchResults.length === 0 ? (
                      <p className="px-4 py-5 text-sm text-gray-500 text-center">
                        Nothing found for &ldquo;{searchQuery}&rdquo;
                      </p>
                    ) : (
                      <ul className="divide-y divide-gray-50">
                        {searchResults.map((r, idx) => (
                          <li key={idx}>
                            <button
                              onClick={() => {
                                setSearchOpen(false);
                                setMobileSearchOpen(false);
                                setSearchQuery("");
                                navigate(r.path);
                              }}
                              className="w-full text-left px-4 py-2.5 hover:bg-gray-50 flex items-center gap-3"
                            >
                              <span className={`px-2 py-0.5 text-[10px] font-semibold rounded-full capitalize flex-shrink-0 ${SEARCH_TYPE_STYLES[r.type] || "bg-gray-100 text-gray-600"}`}>
                                {r.type}
                              </span>
                              <span className="min-w-0">
                                <span className="block text-sm text-gray-900 truncate">{r.label}</span>
                                {r.sublabel && <span className="block text-xs text-gray-400 truncate">{r.sublabel}</span>}
                              </span>
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
              </div>

              {/* Notifications */}
              {showBell && (
              <div className="relative" ref={notifRef}>
                <button
                  onClick={() => { setMoreOpen(false); setProfileOpen(false); toggleNotifications(); }}
                  aria-label="Notifications" aria-haspopup="menu" aria-expanded={notificationOpen}
                  className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded focus:outline-none"
                >
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
                    />
                  </svg>
                  {unreadCount > 0 && (
                    <span className="absolute top-0.5 right-0.5 min-w-[16px] h-4 px-1 bg-red-500 rounded-full text-white text-[10px] font-bold flex items-center justify-center">
                      {unreadCount > 9 ? "9+" : unreadCount}
                    </span>
                  )}
                </button>

                {/* Notification Dropdown */}
                {notificationOpen && (
                  <div className="fixed md:absolute left-3 right-3 md:left-auto md:right-0 top-14 md:top-auto mt-2 md:w-80 bg-white rounded shadow-lg border border-gray-200 z-50">
                    <div className="p-4 border-b border-gray-200">
                      <h3 className="font-semibold text-gray-900">
                        Notifications
                      </h3>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.length === 0 ? (
                        <div className="p-5 text-center text-sm text-gray-400">No notifications yet.</div>
                      ) : (
                        notifications.map((n) => (
                          <Link
                            to="/notifications"
                            key={n.id}
                            onClick={() => handleNotificationClick(n)}
                            className={`block p-4 hover:bg-gray-50 border-b border-gray-100 cursor-pointer ${!n.is_read ? "bg-primary-5" : ""}`}
                          >
                            <div className="flex text-left items-start space-x-3">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                                n.type === "success" ? "bg-green-100 text-green-600" :
                                n.type === "warning" ? "bg-yellow-100 text-yellow-600" :
                                n.type === "error" ? "bg-red-100 text-red-600" : "bg-primary-15 text-primary"
                              }`}>
                                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                  <path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
                                </svg>
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className={`text-sm ${!n.is_read ? "font-semibold text-gray-900" : "text-gray-700"}`}>{n.title}</p>
                                <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{n.message}</p>
                                <p className="text-xs text-gray-400 mt-1"><TimeAgo value={n.createdAt ?? n.created_at} /></p>
                              </div>
                              {!n.is_read && <span className="w-2 h-2 bg-primary rounded-full flex-shrink-0 mt-1.5" />}
                            </div>
                          </Link>
                        ))
                      )}
                    </div>
                    <div className="p-3 border-t border-gray-200 text-center">
                      <Link
                        to="/notifications"
                        onClick={() => setNotificationOpen(false)}
                        className="text-sm text-primary hover:opacity-80 font-medium"
                      >
                        View all notifications
                      </Link>
                    </div>
                  </div>
                )}
              </div>
              )}

              {/* Profile Dropdown */}
              <div className="flex items-center space-x-3 pl-2 sm:pl-4 sm:border-l border-gray-200">
                <div className="hidden md:block text-right">
                  <p className="text-sm font-medium text-gray-900">
                    {user?.first_name} {user?.last_name}
                  </p>
                  <p className="text-xs text-gray-500 capitalize">
                    {user?.role?.replace("_", " ")}
                  </p>
                </div>
                <div className="relative" ref={profileRef}>
                  <button
                    type="button"
                    onClick={() => setProfileOpen((open) => !open)}
                    aria-haspopup="menu"
                    aria-expanded={profileOpen}
                    className="flex items-center space-x-2 focus:outline-none"
                  >
                    <div className="w-10 h-10 rounded-full overflow-hidden gradient-primary flex items-center justify-center text-white font-semibold">
                      {user?.avatar ? (
                        <img src={user.avatar} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <>
                          {user?.first_name?.charAt(0)}
                          {user?.last_name?.charAt(0)}
                        </>
                      )}
                    </div>
                    <svg
                      className={`w-4 h-4 text-gray-400 hidden md:block transition-transform duration-200 ${profileOpen ? "rotate-180" : ""}`}
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </button>

                  {/* Dropdown Menu */}
                  <div
                    role="menu"
                    aria-hidden={!profileOpen}
                    className={`absolute right-0 mt-2 w-48 bg-white rounded shadow-lg border border-gray-200 py-1 transition-all duration-200 z-50 ${profileOpen ? "opacity-100 visible" : "opacity-0 invisible"}`}
                  >
                    <Link
                      to="/settings"
                      onClick={() => setProfileOpen(false)}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      <div className="flex items-center">
                        <svg
                          className="w-4 h-4 mr-3"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                          />
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                          />
                        </svg>
                        Settings
                      </div>
                    </Link>
                    <Link
                      to="/profile"
                      onClick={() => setProfileOpen(false)}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      <div className="flex items-center">
                        <svg
                          className="w-4 h-4 mr-3"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                          />
                        </svg>
                        Profile
                      </div>
                    </Link>
                    <hr className="my-1" />
                    <button
                      onClick={() => { setProfileOpen(false); logout(); }}
                      className="w-full text-left px-4 py-2 text-sm text-red-700 hover:bg-red-50"
                    >
                      <div className="flex items-center">
                        <svg
                          className="w-4 h-4 mr-3"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                          />
                        </svg>
                        Logout
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Phones: closing the full-width search */}
        {mobileSearchOpen && (
          <div className="xl:hidden fixed inset-0 z-[9] bg-black/40" onClick={() => { setMobileSearchOpen(false); setSearchOpen(false); }} />
        )}

        {/* Phones: academic year and campus */}
        {filtersOpen && (
          <div className="xl:hidden fixed inset-0 z-40 flex items-end bg-black/40 print:hidden" onClick={() => setFiltersOpen(false)}>
            <div className="w-full bg-white rounded-t-xl p-4 pb-6 space-y-4 text-left" style={{ paddingBottom: "max(1.5rem, env(safe-area-inset-bottom))" }} onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between">
                <h3 className="text-base font-semibold text-gray-900">Working on</h3>
                <button type="button" onClick={() => setFiltersOpen(false)} className="p-1 text-gray-500" aria-label="Close"><Icon name="x" className="w-5 h-5" /></button>
              </div>
              <Select
                label="Academic year"
                value={currentAcademicYear}
                onChange={(e) => setCurrentAcademicYear(e.target.value)}
                options={yearOptions.map((y) => ({ value: y, label: y }))}
              />
              {canSwitchCampus && campuses.length > 1 && (
                <Select
                  label="Campus"
                  value={currentCampus?.id ?? ""}
                  onChange={(e) => { const selected = campuses.find((c) => c.id === e.target.value); if (selected) setCurrentCampus(selected); }}
                  options={campuses.map((c) => ({ value: c.id, label: `${c.name}${c.code ? ` (${c.code})` : ""}` }))}
                />
              )}
              {canSwitchCampus && campuses.length === 1 && (
                <p className="text-sm text-gray-600">Campus: <span className="font-medium text-gray-900">{currentCampus?.name ?? campuses[0].name}</span></p>
              )}
              <button type="button" onClick={() => setFiltersOpen(false)} className="w-full bg-primary text-white rounded py-2.5 text-sm font-medium">Done</button>
            </div>
          </div>
        )}

        {/* Page Content */}
        {subscriptionWarning && !locked && (
          <div className={`px-4 py-2.5 text-sm flex items-center justify-between gap-3 flex-wrap print:hidden border-b ${
            subscriptionWarning.tone === "danger"
              ? "bg-red-50 border-red-200 text-red-700"
              : "bg-amber-50 border-amber-200 text-amber-800"
          }`}>
            <span className="text-left">{subscriptionWarning.text}</span>
            <Link to="/subscription" className="font-semibold underline whitespace-nowrap">
              Manage subscription
            </Link>
          </div>
        )}

        <InstallBanner />

        <main className="flex-1 px-4 py-3 print:p-0">{children}</main>

        {/* Footer */}
        <footer className="bg-white border-t border-gray-200 py-3 px-4 md:px-5 print:hidden">
          <div className="flex flex-col md:flex-row justify-between items-center text-sm text-gray-600">
            <p>© {new Date().getFullYear()} EduTrack. All rights reserved.</p>
            <div className="flex space-x-4 mt-2 md:mt-0">
              <Link to="/help" className="hover:text-primary">
                Help
              </Link>
              <Link to="/privacy" className="hover:text-primary">
                Privacy
              </Link>
              <Link to="/terms" className="hover:text-primary">
                Terms
              </Link>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default MainLayout;
