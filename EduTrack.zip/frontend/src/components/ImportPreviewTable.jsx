// FILE PATH: frontend/src/components/ImportPreviewTable.jsx
import { useMemo, useState } from "react";

const STATUS = {
  ready: { label: "Ready", cls: "bg-green-100 border border-green-300 text-green-600" },
  possible_duplicate: { label: "Possible duplicate", cls: "bg-amber-100 border border-amber-300 text-amber-600" },
  error: { label: "Has errors", cls: "bg-red-100 border border-red-300 text-red-600" },
};

const SHOW_FIRST = 200;

/**
 * The "check your file" table shown before anything is imported.
 *   rows       preview rows from the server (row, name, status, errors[], warnings[], duplicate, …)
 *   selected   Set of row numbers that will be imported
 *   onChange   (nextSet) => void
 * Rows with errors cannot be ticked. Possible duplicates start unticked so a person decides.
 */
export default function ImportPreviewTable({ rows, selected, onChange, idKey, idLabel, detailKey, detailLabel }) {
  const [filter, setFilter] = useState("all");
  const [showAll, setShowAll] = useState(false);

  const counts = useMemo(() => ({
    all: rows.length,
    ready: rows.filter((r) => r.status === "ready").length,
    possible_duplicate: rows.filter((r) => r.status === "possible_duplicate").length,
    error: rows.filter((r) => r.status === "error").length,
  }), [rows]);

  const visible = rows.filter((r) => filter === "all" || r.status === filter);
  const shown = showAll ? visible : visible.slice(0, SHOW_FIRST);
  const selectable = visible.filter((r) => r.status !== "error");
  const allTicked = selectable.length > 0 && selectable.every((r) => selected.has(r.row));

  const toggle = (row) => {
    const next = new Set(selected);
    if (next.has(row)) next.delete(row); else next.add(row);
    onChange(next);
  };
  const toggleAll = () => {
    const next = new Set(selected);
    selectable.forEach((r) => (allTicked ? next.delete(r.row) : next.add(r.row)));
    onChange(next);
  };

  const tabs = [
    ["all", `All (${counts.all})`],
    ["ready", `Ready (${counts.ready})`],
    ["possible_duplicate", `Possible duplicates (${counts.possible_duplicate})`],
    ["error", `Errors (${counts.error})`],
  ];

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {tabs.map(([key, label]) => (
          <button key={key} type="button" onClick={() => { setFilter(key); setShowAll(false); }}
            className={`text-xs px-3 py-1.5 rounded border ${filter === key ? "bg-primary text-white border-primary" : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"}`}>
            {label}
          </button>
        ))}
      </div>

      <div className="overflow-x-auto border border-gray-200 rounded">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 text-left text-gray-600">
            <tr>
              <th className="px-3 py-2 w-10">
                <input type="checkbox" checked={allTicked} onChange={toggleAll} disabled={selectable.length === 0} aria-label="Select all rows shown" />
              </th>
              <th className="px-3 py-2 font-medium">Row</th>
              <th className="px-3 py-2 font-medium">Name</th>
              <th className="px-3 py-2 font-medium">{idLabel}</th>
              <th className="px-3 py-2 font-medium">{detailLabel}</th>
              <th className="px-3 py-2 font-medium">Check</th>
              <th className="px-3 py-2 font-medium">What to know</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {shown.map((r) => (
              <tr key={r.row} className={`align-top ${r.status === "error" ? "bg-red-50/40" : ""}`}>
                <td className="px-3 py-2">
                  <input type="checkbox" checked={selected.has(r.row)} disabled={r.status === "error"} onChange={() => toggle(r.row)} aria-label={`Include row ${r.row}`} />
                </td>
                <td className="px-3 py-2 whitespace-nowrap">{r.row}</td>
                <td className="px-3 py-2">{r.name}</td>
                <td className="px-3 py-2 whitespace-nowrap">{r[idKey] || "—"}</td>
                <td className="px-3 py-2 whitespace-nowrap">{r[detailKey] || "—"}</td>
                <td className="px-3 py-2 whitespace-nowrap"><span className={`inline-block text-xs px-2 py-0.5 rounded ${STATUS[r.status].cls}`}>{STATUS[r.status].label}</span></td>
                <td className="px-3 py-2 min-w-[18rem]">
                  {r.errors.map((e) => <div key={e} className="text-xs text-red-600">{e}</div>)}
                  {r.warnings.map((w) => <div key={w} className="text-xs text-amber-600">{w}</div>)}
                  {r.errors.length === 0 && r.warnings.length === 0 && <span className="text-xs text-gray-400">No problems</span>}
                </td>
              </tr>
            ))}
            {shown.length === 0 && <tr><td colSpan={7} className="px-3 py-6 text-center text-gray-500">No rows in this group.</td></tr>}
          </tbody>
        </table>
      </div>

      {!showAll && visible.length > SHOW_FIRST && (
        <button type="button" onClick={() => setShowAll(true)} className="text-xs text-primary hover:underline">Show all {visible.length} rows</button>
      )}
    </div>
  );
}
