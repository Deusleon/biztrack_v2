import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import ForcePasswordChange from '../pages/ForcePasswordChange';
import NoAccess from '../pages/NoAccess';
import SubscriptionLocked from '../pages/SubscriptionLocked';
import { useSubscription } from '../contexts/SubscriptionContext';
import { accessKeyFor, pageNeeds } from '../utils/moduleAccess';

/**
 * Wraps every protected route. Without this, logging out (or a stale/
 * missing token) just leaves `user` as null while the current protected
 * page stays mounted — no redirect happens, so the sidebar/page render
 * broken with a null user. This sends the person to /login the moment
 * they're not authenticated, and back on every route change after that.
 */
export default function ProtectedRoute() {
  const { isAuthenticated, user, can } = useAuth();
  const { pathname } = useLocation();
  const { loaded, locked } = useSubscription();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  // First sign-in with the standard starting password: nothing else in the app is
  // shown (or loaded) until a new password has been chosen.
  if (user?.must_change_password) return <ForcePasswordChange />;

  // ── Subscription lock ──
  // Until the answer is in, show nothing — otherwise the page would flash and fire
  // requests the server is about to refuse.
  if (!loaded) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }
  // Locked: the school can pay, see its invoices and receipts, edit its own profile and
  // ask support for help. Everything else is closed until a payment is confirmed.
  if (locked) {
    const allowed = pathname === '/subscription' || pathname.startsWith('/subscription/')
      || pathname === '/profile' || pathname === '/help/contact';
    if (!can('subscription.access')) return <SubscriptionLocked />;
    if (!allowed) return <Navigate to="/subscription?expired=1" replace />;
  }
  // The module's "Open …" permission is the key to its door — without it the
  // pages are closed, not just hidden from the menu. (Only enforced once the server
  // has told the app what this person may do.)
  const needed = accessKeyFor(pathname);
  const extra = pageNeeds(pathname);
  if (Array.isArray(user?.effective_permissions) && ((needed && !can(needed)) || (extra && !can(extra)))) return <NoAccess />;
  return <Outlet />;
}
