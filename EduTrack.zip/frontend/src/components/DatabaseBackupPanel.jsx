// FILE PATH: frontend/src/components/DatabaseBackupPanel.jsx
import { useCallback, useEffect, useState } from "react";
import { backupService } from "../services/api";
import { useToast } from "../contexts/ToastContext";
import { usePreferences } from "../contexts/PreferencesContext";
import { Button, Input, Select, ConfirmModal } from "./ui";

const TRIGGERS = { scheduled: "Daily", manual: "Manual", before_action: "Before a risky action", command_line: "Command line" };
const HOURS = Array.from({ length: 24 }, (_, h) => ({ value: String(h), label: `${String(h).padStart(2, "0")}:00` }));
const KEEP = [7, 14, 30, 60, 90, 180, 365].map((d) => ({ value: String(d), label: `${d} days` }));

const bytes = (n) => (n == null ? "—" : n < 1048576 ? `${Math.max(1, Math.round(n / 1024))} KB` : `${(n / 1048576).toFixed(1)} MB`);

const BADGE = {
  ok: "bg-green-100 border border-green-300 text-green-600",
  bad: "bg-red-100 border border-red-300 text-red-600",
  wait: "bg-amber-100 border border-amber-300 text-amber-600",
  off: "bg-gray-100 border border-gray-300 text-gray-500",
};
const Badge = ({ tone, children, title }) => <span title={title} className={`inline-block text-xs px-2 py-0.5 rounded ${BADGE[tone]}`}>{children}</span>;

function Toggle({ on, onChange, disabled }) {
  return (
    <button type="button" onClick={onChange} disabled={disabled} aria-pressed={on}
      className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 disabled:opacity-50 ${on ? "bg-primary" : "bg-gray-300"}`}>
      <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${on ? "translate-x-5" : ""}`} />
    </button>
  );
}

/** Settings → Database Backup. Platform developer only. */
export default function DatabaseBackupPanel() {
  const { showSuccess, showError } = useToast();
  const { formatDateTime } = usePreferences();
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState("");
  const [creds, setCreds] = useState({ client_id: "", client_secret: "" });
  const [editCreds, setEditCreds] = useState(false);
  const [confirm, setConfirm] = useState({ isOpen: false });
  const [copied, setCopied] = useState(false);
  const [now, setNow] = useState(0); // "now" as of the last refresh, so rendering stays pure

  const load = useCallback(async () => {
    try {
      const res = await backupService.overview();
      if (res.success) { setData(res.data); setNow(Date.now()); }
    } catch (err) { showError(err.message); }
  }, [showError]);

  // load() sets state only after the request returns, never synchronously.
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { load(); }, [load]);

  // Back from Google: say how it went, then tidy the address bar.
  useEffect(() => {
    const q = new URLSearchParams(window.location.search);
    if (q.get("drive")) {
      if (q.get("drive") === "connected") showSuccess("Google Drive connected");
      else showError(q.get("message") || "Google Drive could not be connected");
      window.history.replaceState({}, "", `${window.location.pathname}?tab=database_backup`);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // While a backup or restore test is running, keep looking.
  const working = data && (data.running || data.backups.some((b) => b.verify_status === "pending"));
  useEffect(() => {
    if (!working) return undefined;
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, [working, load]);

  const act = async (key, fn, okMsg) => {
    try {
      setBusy(key);
      const res = await fn();
      if (okMsg !== null) showSuccess(res.message || okMsg);
      await load();
      return res;
    } catch (err) { showError(err.message); await load(); return null; } finally { setBusy(""); }
  };

  const saveSettings = (patch) => act("settings", () => backupService.updateSettings(patch), "Saved");

  const download = async (b) => {
    try {
      setBusy(`dl-${b.id}`);
      const blob = await backupService.download(b.id);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = b.file_name; a.click();
      URL.revokeObjectURL(url);
    } catch (err) { showError(err.message); } finally { setBusy(""); }
  };

  const connect = async () => {
    try {
      setBusy("connect");
      const res = await backupService.driveAuthUrl();
      window.location.href = res.data.url;
    } catch (err) { showError(err.message); setBusy(""); }
  };

  const saveCreds = async () => {
    const res = await act("creds", () => backupService.saveDriveCredentials(creds), "Saved");
    if (res?.success) { setCreds({ client_id: "", client_secret: "" }); setEditCreds(false); }
  };

  if (!data) return <div className="py-12 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>;

  const { settings, drive, backups, last_good: lastGood } = data;
  const lastAttempt = backups[0];
  const stale = !lastGood || now - new Date(lastGood.created_at).getTime() > 36 * 3600000;

  return (
    <div className="w-full space-y-8 text-left">
      {/* ── Status ─────────────────────────────────────────────────────── */}
      <div className={`rounded border p-4 ${lastGood && !stale ? "border-green-200 bg-green-50" : "border-amber-300 bg-amber-50"}`}>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-gray-900">
              {data.running ? "Backing up now…" : lastGood ? (stale ? "The last good backup is more than a day old" : "Your database is backed up") : "No successful backup yet"}
            </h3>
            {lastGood ? (
              <p className="text-sm text-gray-600 mt-0.5">
                Last good backup: <span className="font-medium">{formatDateTime(lastGood.created_at)}</span> · {lastGood.table_count} tables · {lastGood.row_count?.toLocaleString()} rows · {bytes(lastGood.size_bytes)} · restore test passed
              </p>
            ) : <p className="text-sm text-gray-600 mt-0.5">Press <span className="font-medium">Back up now</span> to make the first one.</p>}
            {lastAttempt?.status === "failed" && !data.running && (
              <p className="text-sm text-red-600 mt-1">The latest attempt failed: {lastAttempt.error}</p>
            )}
          </div>
          <Button onClick={() => act("run", backupService.runNow, "Backup started")} loading={busy === "run" || data.running} disabled={data.running}>
            {data.running ? "Working…" : "Back up now"}
          </Button>
        </div>
      </div>

      <p className="text-sm text-gray-500 max-w-3xl">
        Every backup is a <span className="font-medium text-gray-700">complete copy of the whole database</span> (every table, every school), not just selected records.
        Right after it is made, EduTrack proves it works by restoring it into a scratch area and comparing every table with the live data. Only a backup that passes this test counts as good.
        This page is visible to the platform developer only.
      </p>

      {/* ── Schedule ───────────────────────────────────────────────────── */}
      <div className="border-t border-gray-100 pt-6 space-y-5">
        <h3 className="text-base font-semibold text-gray-900">Automatic backups</h3>
        <div className="flex items-start gap-3">
          <Toggle on={settings.enabled} disabled={busy === "settings"} onChange={() => saveSettings({ enabled: !settings.enabled })} />
          <div>
            <p className="text-sm font-medium text-gray-800">Back up every day</p>
            <p className="text-xs text-gray-500">If the server is asleep at the set time, the backup is made as soon as it wakes up.</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl">
          <Select label={`Time of day (${settings.time_zone})`} value={String(settings.run_at_hour)} options={HOURS} disabled={!settings.enabled || busy === "settings"}
            onChange={(e) => saveSettings({ run_at_hour: Number(e.target.value) })} />
          <Select label="Keep backups for" value={String(settings.retention_days)} options={KEEP} disabled={busy === "settings"}
            onChange={(e) => saveSettings({ retention_days: Number(e.target.value) })} />
        </div>
        <div className="flex items-start gap-3">
          <Toggle on={settings.protect_risky_actions} disabled={busy === "settings"} onChange={() => saveSettings({ protect_risky_actions: !settings.protect_risky_actions })} />
          <div>
            <p className="text-sm font-medium text-gray-800">Back up before risky actions</p>
            <p className="text-xs text-gray-500 max-w-xl">
              Before a student promotion (or reverting one) and before a database update, EduTrack first makes a fresh tested backup. If that backup cannot be made, the action does not run.
            </p>
          </div>
        </div>
        <p className="text-xs text-gray-500">The newest 3 good backups are always kept, whatever the retention says.</p>
      </div>

      {/* ── Google Drive ───────────────────────────────────────────────── */}
      <div className="border-t border-gray-100 pt-6 space-y-4">
        <h3 className="text-base font-semibold text-gray-900">Copy backups to Google Drive</h3>

        {drive.last_error && (
          <div className="rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700">
            {drive.last_error}
            <div className="mt-2"><Button size="sm" onClick={connect} loading={busy === "connect"}>Reconnect Google Drive</Button></div>
          </div>
        )}

        {drive.connected ? (
          <div className="space-y-4">
            <div className="rounded border border-gray-200 p-4 text-sm">
              <p className="text-gray-800">Connected to <span className="font-medium">{drive.account_email || "your Google account"}</span></p>
              <p className="text-gray-500 text-xs mt-0.5">Files go to a folder named “{drive.folder_name}”. EduTrack can only see files it created itself, never the rest of your Drive.</p>
              <div className="flex flex-wrap gap-2 mt-3">
                <Button size="sm" variant="secondary" onClick={() => act("test", backupService.driveTest, "Works")} loading={busy === "test"}>Test connection</Button>
                <Button size="sm" variant="secondary" onClick={() => setEditCreds((v) => !v)}>Change credentials</Button>
                <Button size="sm" variant="danger" onClick={() => setConfirm({ isOpen: true, kind: "disconnect" })}>Disconnect</Button>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Toggle on={drive.enabled} disabled={busy === "settings"} onChange={() => saveSettings({ drive_enabled: !drive.enabled })} />
              <div>
                <p className="text-sm font-medium text-gray-800">Copy every tested backup to Google Drive</p>
                <p className="text-xs text-gray-500">Old copies are removed from Drive after the retention period, like the ones on the server.</p>
              </div>
            </div>
          </div>
        ) : drive.configured ? (
          <div className="space-y-3">
            <p className="text-sm text-gray-600">Google credentials are saved. Click Connect, sign in with the Google account whose Drive should hold the backups, and allow access.</p>
            <div className="flex gap-2">
              <Button onClick={connect} loading={busy === "connect"}>Connect Google Drive</Button>
              <Button variant="secondary" onClick={() => setEditCreds((v) => !v)}>Change credentials</Button>
            </div>
          </div>
        ) : (
          <p className="text-sm text-gray-600">Not set up yet. Follow the four steps below (about 10 minutes, once).</p>
        )}

        {(!drive.configured || editCreds) && (
          <ol className="text-sm text-gray-700 space-y-4 list-decimal pl-5 max-w-3xl">
            <li>
              Open <span className="font-medium">console.cloud.google.com</span>, create a project (any name, e.g. “EduTrack Backups”), then go to
              <span className="font-medium"> APIs &amp; Services → Library</span> and enable <span className="font-medium">Google Drive API</span>.
            </li>
            <li>
              Go to <span className="font-medium">OAuth consent screen</span>: choose <span className="font-medium">External</span>, fill in the app name and your email, and add yourself as a test user.
              Then set the publishing status to <span className="font-medium text-red-600">“In production”</span>. In “Testing” mode Google cancels the link after 7 days and backups would silently stop going to Drive.
            </li>
            <li>
              Go to <span className="font-medium">Credentials → Create credentials → OAuth client ID → Web application</span>. Under <span className="font-medium">Authorised redirect URIs</span> add exactly this address:
              <div className="mt-2 flex items-center gap-2">
                <code className="text-xs bg-gray-100 border border-gray-200 rounded px-2 py-1 break-all">{drive.redirect_uri}</code>
                <Button size="xs" variant="secondary" onClick={async () => { try { await navigator.clipboard.writeText(drive.redirect_uri); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch { showError("Copy it by hand"); } }}>{copied ? "Copied" : "Copy"}</Button>
              </div>
              <p className="text-xs text-gray-500 mt-1">If it starts with http://localhost or the wrong website, set BACKEND_PUBLIC_URL on the server to your real API address and reload this page.</p>
            </li>
            <li>
              Copy the <span className="font-medium">Client ID</span> and <span className="font-medium">Client secret</span> Google shows you and paste them here:
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2 max-w-2xl">
                <Input label="Client ID" value={creds.client_id} onChange={(e) => setCreds({ ...creds, client_id: e.target.value })} placeholder={drive.client_id || "123…apps.googleusercontent.com"} />
                <Input label="Client secret" type="password" value={creds.client_secret} onChange={(e) => setCreds({ ...creds, client_secret: e.target.value })} placeholder={drive.has_secret ? "•••••••• (saved)" : "GOCSPX-…"} />
              </div>
              <div className="mt-3"><Button onClick={saveCreds} loading={busy === "creds"} disabled={!creds.client_id && !creds.client_secret}>Save credentials</Button></div>
              <p className="text-xs text-gray-500 mt-1">The secret is stored encrypted and never shown again. Saving new credentials disconnects the old link.</p>
            </li>
          </ol>
        )}
      </div>

      {/* ── History ────────────────────────────────────────────────────── */}
      <div className="border-t border-gray-100 pt-6">
        <h3 className="text-base font-semibold text-gray-900 mb-3">Backup history</h3>
        {backups.length === 0 ? <p className="text-sm text-gray-500">No backups yet.</p> : (
          <div className="overflow-x-auto border border-gray-200 rounded">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 text-gray-600 text-left">
                <tr>
                  <th className="px-3 py-2 font-medium">When</th>
                  <th className="px-3 py-2 font-medium">Type</th>
                  <th className="px-3 py-2 font-medium">Contents</th>
                  <th className="px-3 py-2 font-medium">Restore test</th>
                  <th className="px-3 py-2 font-medium">Google Drive</th>
                  <th className="px-3 py-2 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {backups.map((b) => (
                  <tr key={b.id} className="align-top">
                    <td className="px-3 py-2 whitespace-nowrap">{formatDateTime(b.created_at)}</td>
                    <td className="px-3 py-2">
                      {TRIGGERS[b.trigger] || b.trigger}
                      {b.reason && b.trigger === "before_action" && <div className="text-xs text-gray-500 max-w-[14rem]">{b.reason}</div>}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap">
                      {b.status === "running" ? <Badge tone="wait">Running…</Badge>
                        : b.status === "failed" && !b.file_name ? <Badge tone="bad" title={b.error}>Failed</Badge>
                          : <>{b.table_count} tables · {b.row_count?.toLocaleString()} rows<div className="text-xs text-gray-500">{bytes(b.size_bytes)}{!b.file_available && " · file removed"}</div></>}
                      {b.status === "failed" && b.error && <div className="text-xs text-red-600 max-w-[16rem] whitespace-normal">{b.error}</div>}
                    </td>
                    <td className="px-3 py-2">
                      {b.verify_status === "passed" ? <Badge tone="ok" title={`${b.verify_detail?.tables} tables, ${b.verify_detail?.rows} rows matched`}>Passed</Badge>
                        : b.verify_status === "failed" ? <Badge tone="bad" title={(b.verify_detail?.problems || []).join("\n")}>Failed</Badge>
                          : b.status === "running" || b.verify_status === "pending" ? <Badge tone="wait">Testing…</Badge> : <Badge tone="off">—</Badge>}
                    </td>
                    <td className="px-3 py-2">
                      {b.drive_status === "uploaded" ? <Badge tone="ok">Copied</Badge>
                        : b.drive_status === "failed" ? <Badge tone="bad" title={b.drive_error}>Failed</Badge>
                          : b.drive_status === "pending" ? <Badge tone="wait">Copying…</Badge> : <Badge tone="off">Not copied</Badge>}
                    </td>
                    <td className="px-3 py-2 text-right whitespace-nowrap space-x-2">
                      {b.file_available && b.status === "success" && (
                        <>
                          <button className="text-primary hover:underline text-xs font-medium" disabled={busy === `dl-${b.id}`} onClick={() => download(b)}>Download</button>
                          <button className="text-primary hover:underline text-xs font-medium" onClick={() => act(`v-${b.id}`, () => backupService.verify(b.id), "Restore test started")}>Test again</button>
                          {drive.connected && b.verify_status === "passed" && b.drive_status !== "uploaded" && (
                            <button className="text-primary hover:underline text-xs font-medium" onClick={() => act(`d-${b.id}`, () => backupService.copyToDrive(b.id), "Copied")}>Copy to Drive</button>
                          )}
                        </>
                      )}
                      {b.file_available && (
                        <button className="text-red-600 hover:underline text-xs font-medium" onClick={() => setConfirm({ isOpen: true, kind: "delete", backup: b })}>Delete</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ── Restoring ──────────────────────────────────────────────────── */}
      <div className="border-t border-gray-100 pt-6 text-sm text-gray-600 space-y-2 max-w-3xl">
        <h3 className="text-base font-semibold text-gray-900">If you ever need to restore</h3>
        <p>Restoring replaces the live database, so it is done from the server on purpose, never from this page. In the <code className="bg-gray-100 px-1 rounded">backend</code> folder run:</p>
        <pre className="bg-gray-900 text-gray-100 text-xs rounded p-3 overflow-x-auto">{`npm run db:backup:list                      # see the backup files
npm run db:backup:verify -- latest          # run the restore test again
npm run db:restore -- latest --wipe         # REPLACE the database with the latest backup`}</pre>
        <p>The restore runs as one all-or-nothing step and checks every table against the backup. If anything is wrong, the database is left exactly as it was. Download a file from Google Drive or the table above to put it back in <code className="bg-gray-100 px-1 rounded">backend/backups</code> first.</p>
        <p className="text-xs text-gray-500">Student photos and uploaded documents are files on the server, not in the database, so they are not part of this backup.</p>
      </div>

      <ConfirmModal
        isOpen={confirm.isOpen}
        variant="danger"
        title={confirm.kind === "disconnect" ? "Disconnect Google Drive" : "Delete backup"}
        message={confirm.kind === "disconnect"
          ? "Backups will stay on the server only until you connect again. Files already on Google Drive are not deleted."
          : `Delete the backup from ${confirm.backup ? formatDateTime(confirm.backup.created_at) : ""}? This also removes its copy on Google Drive.`}
        confirmText={confirm.kind === "disconnect" ? "Disconnect" : "Delete"}
        onConfirm={() => (confirm.kind === "disconnect"
          ? act("disc", backupService.driveDisconnect, "Disconnected")
          : act("del", () => backupService.remove(confirm.backup.id), "Deleted"))}
        onClose={() => setConfirm({ isOpen: false })}
      />
    </div>
  );
}
