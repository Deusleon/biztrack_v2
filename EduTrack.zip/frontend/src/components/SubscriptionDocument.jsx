import { QRCodeSVG } from "qrcode.react";
import BrandMark from "./BrandMark";
import { statusStyle, NAVY, GREEN } from "../utils/subscriptionDocs";

const rgb = (c) => `rgb(${c.join(",")})`;

/**
 * On-screen preview of a subscription invoice or receipt. Takes the model from
 * buildDoc() — the same one the PDF is drawn from — so what is previewed is
 * what is downloaded.
 */
export default function SubscriptionDocument({ doc }) {
  const st = statusStyle(doc.status);
  const accent = rgb(doc.isReceipt ? GREEN : NAVY);
  const { money, signed } = doc;

  return (
    <div className="relative bg-white shadow print:shadow-none border border-gray-200 print:border-0 mx-auto w-full max-w-3xl text-left overflow-hidden" style={{ fontSize: 13 }}>
      <div className="relative px-8 pt-8 pb-6">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 pb-4" style={{ borderBottom: `2px solid ${accent}` }}>
          <div className="flex items-center gap-3">
            <BrandMark variant="color" className="w-16 h-auto" />
            <div>
              <p className="text-xl font-extrabold leading-tight" style={{ color: rgb(NAVY) }}>EduTrack</p>
              <p className="text-[11px] text-gray-500">School Management System</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-3xl font-extrabold tracking-tight leading-none" style={{ color: accent }}>{doc.title}</p>
            <span className="inline-block mt-2 text-[11px] font-bold tracking-wider text-white rounded-full px-3 py-1" style={{ background: st.hex }}>{st.label}</span>
          </div>
        </div>

        {/* Seller + facts */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-5">
          <div>
            <p className="font-bold text-gray-900">{doc.seller.name}</p>
            {doc.seller.lines.map((l) => <p key={l} className="text-xs text-gray-500">{l}</p>)}
          </div>
          <dl className="text-xs space-y-1.5">
            {(doc.isReceipt
              ? [["Receipt No.", doc.number], ["Date paid", doc.paidAt], ["Invoice No.", doc.invoiceNumber], ["Reference", doc.orderRef]]
              : [["Invoice No.", doc.number], ["Issue date", doc.issued], ["Service period", doc.periodText], ["Reference", doc.orderRef]]
            ).map(([k, v]) => (
              <div key={k} className="flex gap-3">
                <dt className="w-28 flex-shrink-0 text-gray-500">{k}</dt>
                <dd className="font-semibold text-gray-900 break-all">{v}</dd>
              </div>
            ))}
          </dl>
        </div>

        {/* Bill to */}
        <div className="mt-6 rounded-sm px-4 py-3" style={{ background: "#F4F7FC" }}>
          <p className="text-[10px] font-bold tracking-widest" style={{ color: accent }}>{doc.isReceipt ? "RECEIVED FROM" : "BILL TO"}</p>
          <p className="text-base font-bold text-gray-900 mt-1">{doc.school.name}</p>
          {doc.school.address && <p className="text-xs text-gray-500">{doc.school.address}</p>}
          <p className="text-xs text-gray-500">{[doc.school.phone, doc.school.email].filter(Boolean).join("   |   ")}</p>
        </div>

        {!doc.isReceipt ? (
          <>
            <div className="mt-5 overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="text-white text-left" style={{ background: rgb(NAVY) }}>
                    <th className="px-3 py-2 w-10 text-center text-xs font-semibold">#</th>
                    <th className="px-3 py-2 text-xs font-semibold">Description</th>
                    <th className="px-3 py-2 text-xs font-semibold">Service period</th>
                    <th className="px-3 py-2 text-right text-xs font-semibold whitespace-nowrap">Amount ({doc.currency})</th>
                  </tr>
                </thead>
                <tbody>
                  {doc.lines.map((l, i) => (
                    <tr key={i} className={i % 2 ? "bg-gray-50" : "bg-white"}>
                      <td className="px-3 py-2.5 border border-gray-200 text-center text-gray-500">{i + 1}</td>
                      <td className="px-3 py-2.5 border border-gray-200 text-gray-900">{l.label}</td>
                      <td className="px-3 py-2.5 border border-gray-200 text-xs text-gray-500">{i === 0 ? <>{doc.periodText}<br />{doc.cycle}</> : ""}</td>
                      <td className="px-3 py-2.5 border border-gray-200 text-right font-semibold" style={{ color: l.amount < 0 ? rgb(GREEN) : "#111827" }}>{signed(l.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-4 ml-auto w-full sm:w-72 text-sm">
              <div className="flex justify-between py-1"><span className="text-gray-500">Subtotal</span><span className="font-semibold">{doc.currency} {money(doc.subtotal)}</span></div>
              {doc.credit > 0 && (
                <div className="flex justify-between py-1" style={{ color: rgb(GREEN) }}><span>Credit for unused time</span><span className="font-semibold">-{doc.currency} {money(doc.credit)}</span></div>
              )}
              <div className="flex justify-between items-center mt-1 px-3 py-2.5 text-white font-bold" style={{ background: doc.paid ? rgb(GREEN) : rgb(NAVY) }}>
                <span className="text-xs">{doc.paid ? "TOTAL PAID" : "TOTAL DUE"}</span>
                <span className="text-base">{doc.currency} {money(doc.total)}</span>
              </div>
            </div>
            <p className="mt-3 text-xs italic text-gray-500">Amount in words: {doc.words}</p>

            {doc.paid ? (
              <div className="mt-5 px-4 py-3 flex items-start justify-between gap-4" style={{ background: "#EAF5E6", borderLeft: `4px solid ${rgb(GREEN)}` }}>
                <div>
                  <p className="text-[11px] font-bold tracking-widest" style={{ color: rgb(GREEN) }}>PAYMENT RECEIVED</p>
                  <p className="text-xs text-gray-800 mt-1">Paid in full on {doc.paidAt} by {doc.method}.</p>
                  <p className="text-xs text-gray-800">Transaction reference: {doc.transactionRef}. Receipt: {doc.receiptNumber || "—"}.</p>
                  {doc.verificationCode && <p className="text-xs text-gray-500 mt-2">Verification code: {doc.verificationCode}</p>}
                </div>
                <QrBlock doc={doc} accent={rgb(GREEN)} />
              </div>
            ) : (
              <div className="mt-5 px-4 py-3 flex items-start justify-between gap-4" style={{ background: "#FDF1E1", borderLeft: "4px solid #C96F08" }}>
                <div>
                  <p className="text-[11px] font-bold tracking-widest" style={{ color: "#C96F08" }}>{doc.status === "failed" ? "PAYMENT NOT COMPLETED" : "HOW TO PAY"}</p>
                  <p className="text-xs text-gray-800 mt-1 leading-relaxed">
                    {doc.status === "failed" && doc.failureReason
                      ? `The last attempt failed: ${doc.failureReason}. Choose Pay to try again.`
                      : "Scan the QR code with your phone to pay with mobile money (Airtel Money, Mixx by Yas, HaloPesa), or choose Pay on this invoice in EduTrack. Your subscription starts as soon as the payment is confirmed."}
                  </p>
                  <p className="text-[11px] text-gray-500 mt-1.5">Quote {doc.invoiceNumber} when you contact support.</p>
                </div>
                <QrBlock doc={doc} accent="#C96F08" />
              </div>
            )}
          </>
        ) : (
          <>
            <div className="mt-5 px-5 py-4" style={{ background: "#EAF5E6", borderLeft: `4px solid ${rgb(GREEN)}` }}>
              <p className="text-[11px] font-bold tracking-widest" style={{ color: rgb(GREEN) }}>AMOUNT RECEIVED</p>
              <p className="text-3xl font-extrabold text-gray-900 mt-1">{doc.currency} {money(doc.total)}</p>
              <p className="text-xs italic text-gray-500 mt-1">{doc.words}</p>
            </div>
            <dl className="mt-4 text-sm divide-y divide-gray-100">
              {[
                ["Payment for", `${doc.planName} plan, ${String(doc.cycle).toLowerCase()}`],
                ["Service period", doc.periodText],
                ["Invoice", doc.invoiceNumber],
                ["Payment method", doc.method],
                ["Paid from", doc.payerPhone],
                ["Transaction reference", doc.transactionRef],
                ["Order reference", doc.orderRef],
                ["Date paid", doc.paidAt],
              ].map(([k, v]) => (
                <div key={k} className="flex gap-4 py-2">
                  <dt className="w-44 flex-shrink-0 text-gray-500">{k}</dt>
                  <dd className="font-semibold text-gray-900 break-all">{v}</dd>
                </div>
              ))}
            </dl>
            {doc.qr && (
              <div className="mt-5 px-4 py-3 flex items-start justify-between gap-4" style={{ background: "#F4F7FC", borderLeft: `4px solid ${rgb(GREEN)}` }}>
                <div>
                  <p className="text-[11px] font-bold tracking-widest" style={{ color: rgb(GREEN) }}>VERIFY THIS RECEIPT</p>
                  <p className="text-xs text-gray-700 mt-1 leading-relaxed">
                    Scan the QR code to confirm with EduTrack that this payment was really received. Or open <span className="font-semibold">{doc.verifyPage}</span> and enter the receipt number and verification code.
                  </p>
                  <p className="text-xs font-bold text-gray-900 mt-2">Receipt No.: {doc.receiptNumber}</p>
                  <p className="text-xs font-bold text-gray-900">Verification code: {doc.verificationCode}</p>
                </div>
                <QrBlock doc={doc} accent={rgb(GREEN)} />
              </div>
            )}
          </>
        )}

        <p className="mt-6 text-[11px] text-gray-500 leading-relaxed">
          {doc.isReceipt
            ? "Thank you for your payment. This receipt confirms that the amount above was received and applied to your EduTrack subscription."
            : doc.paid
              ? "Thank you. This invoice has been paid in full; a payment receipt is available in EduTrack under Subscription."
              : "This invoice is payable on receipt. Your subscription is not extended until the payment is confirmed. Amounts are in Tanzanian shillings."}
        </p>
      </div>

      <div className="relative px-8 py-3 border-t border-gray-200 flex flex-wrap justify-between gap-2 text-[11px] text-gray-500">
        <span>Generated electronically by EduTrack. No signature is required.</span>
        <span>{doc.isReceipt ? "Receipt" : "Invoice"} {doc.number}</span>
      </div>

      {/* Last child, above every card: the cards are opaque, so a watermark behind them would
          vanish. It is faint enough that the text underneath stays fully readable. */}
      {doc.paid && (
        <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center select-none" aria-hidden="true">
          <span className="font-black tracking-widest" style={{ fontSize: 150, color: rgb(GREEN), opacity: 0.07, transform: "rotate(-30deg)" }}>PAID</span>
        </div>
      )}
    </div>
  );
}

function QrBlock({ doc, accent }) {
  if (!doc.qr) return null;
  return (
    <div className="flex-shrink-0 text-center">
      <div className="bg-white border border-gray-300 p-1.5 inline-block">
        <QRCodeSVG value={doc.qr.url} size={92} level="M" />
      </div>
      <p className="text-[11px] font-bold mt-1" style={{ color: accent }}>{doc.qr.caption}</p>
      <p className="text-[10px] text-gray-500 leading-tight max-w-[110px] mx-auto">{doc.qr.hint}</p>
    </div>
  );
}
