// FILE PATH: frontend/src/components/SwalaTopUpModal.jsx
import { useEffect, useRef, useState } from "react";
import { messagingService } from "../services/api";
import { useToast } from "../contexts/ToastContext";
import { Button, Input, NumberInput, PhoneInput, Select } from "./ui";

const money = (amount, currency) => (amount === null || amount === undefined || amount === "" ? "" : `${currency || ""} ${Number(amount).toLocaleString()}`.trim());
const POLL_MS = 4000;
const POLL_TRIES = 45; // about three minutes — enough to approve a mobile money prompt

/**
 * Buy SMS credits at SwalaSMS: pick a fixed package or a custom number of credits, see the price, choose how to pay,
 * and follow the order until the credits arrive. The page that opens this re-reads the balance when it is paid.
 */
export default function SwalaTopUpModal({ onClose, onPaid }) {
  const { showSuccess, showError } = useToast();
  const [options, setOptions] = useState(null);
  const [loadError, setLoadError] = useState("");
  const [form, setForm] = useState({ country_uid: "", mode: "custom", package_uid: "", units: "", payment_gateway: "", phone: "" });
  const [quote, setQuote] = useState(null);
  const [busy, setBusy] = useState(false);
  const [order, setOrder] = useState(null); // { orderUid, status, payment:{…}, message }
  const timer = useRef(null);

  const load = async (countryUid) => {
    try {
      const res = await messagingService.getWalletOptions(countryUid ? { country_uid: countryUid } : undefined);
      if (!res.success) return;
      const d = res.data;
      setOptions(d);
      setForm((f) => ({
        ...f,
        country_uid: d.country_uid || f.country_uid,
        mode: d.packages?.length && !f.units ? "package" : f.mode,
        package_uid: d.packages?.[0]?.uid || "",
        payment_gateway: d.payment_methods?.some((m) => m.code === f.payment_gateway) ? f.payment_gateway : (d.payment_methods?.[0]?.code || ""),
      }));
    } catch (err) { setLoadError(err.response?.data?.message || err.message); }
  };
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { load(); return () => clearInterval(timer.current); }, []);

  const method = options?.payment_methods?.find((m) => m.code === form.payment_gateway);
  const needsPhone = method ? method.requires_phone !== false : true;

  const checkPrice = async () => {
    if (!(Number(form.units) >= 1)) return showError("Enter how many credits you want first");
    try {
      setBusy(true);
      const res = await messagingService.quoteWalletTopUp({ country_uid: form.country_uid, units: Number(form.units) });
      if (res.success) setQuote(res.data);
    } catch (err) { setQuote(null); showError(err.response?.data?.message || err.message); }
    finally { setBusy(false); }
  };

  // Follows the order: SwalaSMS credits the wallet the moment the payment clears.
  const follow = (orderUid) => {
    let tries = 0;
    clearInterval(timer.current);
    timer.current = setInterval(async () => {
      tries += 1;
      try {
        const res = await messagingService.checkTopUpStatus(orderUid);
        const o = res.data;
        if (o?.status === "paid") {
          clearInterval(timer.current);
          setOrder((cur) => ({ ...cur, status: "paid" }));
          showSuccess("Payment received — your SMS credits have been added");
          onPaid?.();
        } else if (o?.payment?.status === "failed") {
          clearInterval(timer.current);
          setOrder((cur) => ({ ...cur, status: "failed" }));
        }
      } catch { /* a missed poll is fine; the next one tries again */ }
      if (tries >= POLL_TRIES) clearInterval(timer.current);
    }, POLL_MS);
  };

  const pay = async () => {
    const usingPackage = form.mode === "package" && form.package_uid;
    if (!usingPackage && !(Number(form.units) >= 1)) return showError("Enter how many credits you want, or choose a package");
    if (!form.payment_gateway) return showError("Choose a payment method");
    if (needsPhone && !form.phone) return showError("Enter the mobile money phone number to charge");
    try {
      setBusy(true);
      const res = await messagingService.topUpProvider({
        country_uid: form.country_uid, payment_gateway: form.payment_gateway, phone: needsPhone ? form.phone : undefined,
        ...(usingPackage ? { package_uid: form.package_uid } : { units: Number(form.units) }),
      });
      if (res.success) {
        const d = res.data;
        setOrder({ orderUid: d.orderUid, status: d.status || "pending", payment: d.payment, sandbox: d.sandbox, message: res.message });
        if (d.orderUid && d.status !== "paid" && !d.sandbox) follow(d.orderUid);
      }
    } catch (err) { showError(err.response?.data?.message || err.message); }
    finally { setBusy(false); }
  };

  const packages = options?.packages || [];
  const countries = options?.countries || [];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded shadow-xl w-full max-w-md max-h-[92vh] overflow-y-auto">
        <div className="px-5 py-4 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-base font-semibold">Buy SMS Credits · SwalaSMS</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600" aria-label="Close">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="px-5 py-4 space-y-4 text-left">
          {loadError && <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">{loadError}</p>}
          {!options && !loadError && <div className="py-8 text-center"><div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary" /></div>}

          {options && !order && (
            <>
              {countries.length > 1 && (
                <Select label="Country" value={form.country_uid} onChange={(e) => { setForm((f) => ({ ...f, country_uid: e.target.value })); setQuote(null); load(e.target.value); }}
                  options={countries.map((c) => ({ value: c.uid, label: c.name || c.iso2 }))} />
              )}

              {packages.length > 0 && (
                <div className="flex gap-2">
                  {[["package", "A package"], ["custom", "Custom amount"]].map(([key, label]) => (
                    <button key={key} type="button" onClick={() => setForm((f) => ({ ...f, mode: key }))}
                      className={`flex-1 text-sm px-3 py-2 rounded border ${form.mode === key ? "bg-primary text-white border-primary" : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"}`}>{label}</button>
                  ))}
                </div>
              )}

              {form.mode === "package" && packages.length > 0 ? (
                <Select label="Package" value={form.package_uid} onChange={(e) => setForm((f) => ({ ...f, package_uid: e.target.value }))}
                  options={packages.map((p) => ({ value: p.uid, label: `${p.name ? `${p.name} — ` : ""}${Number(p.units).toLocaleString()} credits${p.amount ? ` · ${money(p.amount, p.currency)}` : ""}` }))} />
              ) : (
                <div className="space-y-2">
                  <NumberInput label="Number of SMS credits" allowDecimals={false} value={form.units} onChange={(e) => { setForm((f) => ({ ...f, units: e.target.value })); setQuote(null); }} placeholder="e.g. 5000 (1 to 1,000,000)" />
                  <div className="flex items-center gap-3">
                    <Button type="button" variant="secondary" onClick={checkPrice} loading={busy} disabled={!form.units}>Check price</Button>
                    {quote && <span className="text-sm text-gray-700">{Number(quote.units || form.units).toLocaleString()} credits cost <strong>{money(quote.amount ?? quote.total, quote.currency)}</strong></span>}
                  </div>
                </div>
              )}

              <Select label="Payment method" value={form.payment_gateway} onChange={(e) => setForm((f) => ({ ...f, payment_gateway: e.target.value }))}
                options={(options.payment_methods || []).map((m) => ({ value: m.code, label: m.name || m.label || m.code }))} />
              {needsPhone && <PhoneInput label="Mobile Money Number" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} />}
              {!needsPhone && form.payment_gateway && <p className="text-xs text-gray-500">You will be given a link to finish paying by card.</p>}

              <div className="flex justify-end gap-3 pt-1">
                <Button type="button" onClick={pay} loading={busy}>Pay</Button>
                <Button type="button" variant="secondary" onClick={onClose}>Close</Button>
              </div>
            </>
          )}

          {order && (
            <div className="space-y-3">
              <div className={`rounded px-3 py-3 text-sm border ${order.status === "paid" ? "bg-green-50 border-green-200 text-green-800" : order.status === "failed" ? "bg-red-50 border-red-200 text-red-700" : "bg-blue-50 border-blue-200 text-blue-800"}`}>
                {order.status === "paid" ? (order.sandbox ? "Sandbox top-up recorded — nothing was charged and no credits were added." : "Paid. Your SMS credits have been added.")
                  : order.status === "failed" ? "The payment failed. Close this and try again — the same order is reused."
                    : order.message}
              </div>
              {order.payment?.redirectUrl && order.status !== "paid" && (
                <a href={order.payment.redirectUrl} target="_blank" rel="noopener noreferrer" className="inline-block bg-primary text-white text-sm px-4 py-2 rounded hover:opacity-90">Open the payment page</a>
              )}
              {order.status === "pending" && !order.sandbox && (
                <p className="text-xs text-gray-500 flex items-center gap-2">
                  <span className="inline-block animate-spin rounded-full h-3 w-3 border-b-2 border-primary" /> Waiting for the payment to be approved… this page updates by itself.
                </p>
              )}
              <div className="flex justify-end"><Button type="button" variant="secondary" onClick={onClose}>Close</Button></div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
