// Settings → Website: the form a school uses to change what its PUBLIC website shows.
// Every field is optional — a blank one keeps the website's built-in wording.
import { useEffect, useState } from 'react';
import { settingsService } from '../services/api';
import { useToast } from '../contexts/ToastContext';
import { Input, Textarea, Button } from './ui';

const EMPTY = {
  site: { name: '', tagline: '', phone: '', phone2: '', email: '', admissions_email: '', address: '', hours: '', facebook: '', instagram: '', youtube: '', whatsapp: '' },
  hero: { badge: '', headline: '', headline_highlight: '', subheadline: '', primary_label: '', primary_link: '', secondary_label: '', secondary_link: '' },
  stats: [], about: { title: '', body: '' }, testimonials: [], news: [], notice: { enabled: false, text: '', link: '' },
};

function Section({ title, hint, children }) {
  return (
    <section className="bg-white rounded shadow p-5 text-left space-y-4">
      <div>
        <h2 className="text-base font-semibold text-gray-900">{title}</h2>
        {hint && <p className="text-xs text-gray-500 mt-0.5">{hint}</p>}
      </div>
      {children}
    </section>
  );
}

/** A list of small cards (stats, testimonials, news) with add / remove. */
function RepeatList({ items, onChange, max, addLabel, blank, children }) {
  const update = (i, patch) => onChange(items.map((it, idx) => (idx === i ? { ...it, ...patch } : it)));
  return (
    <div className="space-y-3">
      {items.map((it, i) => (
        <div key={i} className="border border-gray-200 rounded p-3 space-y-3">
          {children(it, (patch) => update(i, patch))}
          <div className="flex justify-end">
            <Button variant="lightDanger" size="sm" onClick={() => onChange(items.filter((_, idx) => idx !== i))}>Remove</Button>
          </div>
        </div>
      ))}
      {items.length < max && (
        <div className="flex justify-end">
          <Button variant="lightPrimary" size="sm" onClick={() => onChange([...items, { ...blank }])}>{addLabel}</Button>
        </div>
      )}
    </div>
  );
}

export default function WebsiteContentPanel() {
  const { showSuccess, showError } = useToast();
  const [form, setForm] = useState(EMPTY);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    settingsService.getWebsiteContent()
      .then((res) => { if (res.success) setForm({ ...EMPTY, ...res.data }); })
      .catch((err) => showError(err.message || 'Could not load the website content'))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const set = (group, key) => (e) => setForm((f) => ({ ...f, [group]: { ...f[group], [key]: e.target.value } }));

  const save = async () => {
    try {
      setSaving(true);
      const res = await settingsService.updateWebsiteContent(form);
      if (res.success) { setForm({ ...EMPTY, ...res.data }); showSuccess(res.message || 'Website content saved'); }
    } catch (err) { showError(err.message || 'Could not save'); }
    finally { setSaving(false); }
  };

  if (loading) return <div className="bg-white rounded shadow p-10 text-center"><div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary" /></div>;

  return (
    <div className="space-y-5">
      <div className="rounded px-4 py-3 text-sm text-left bg-blue-50 border border-blue-200 text-blue-800">
        What you save here appears on the school's public website within a minute. Leave a field empty to keep the website's own wording.
      </div>

      <Section title="School & contact details" hint="Shown in the website's footer and on the Contact page.">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input label="School name" value={form.site.name} onChange={set('site', 'name')} />
          <Input label="Tagline" value={form.site.tagline} onChange={set('site', 'tagline')} />
          <Input label="Phone" value={form.site.phone} onChange={set('site', 'phone')} placeholder="+255 …" />
          <Input label="Second phone" value={form.site.phone2} onChange={set('site', 'phone2')} />
          <Input label="Email" type="email" value={form.site.email} onChange={set('site', 'email')} />
          <Input label="Admissions email" type="email" value={form.site.admissions_email} onChange={set('site', 'admissions_email')} />
          <Input label="WhatsApp number" value={form.site.whatsapp} onChange={set('site', 'whatsapp')} />
          <Input label="Opening hours" value={form.site.hours} onChange={set('site', 'hours')} placeholder="Mon - Fri: 7:00 AM - 4:00 PM" />
          <Textarea className="md:col-span-2" label="Address" rows={2} value={form.site.address} onChange={set('site', 'address')} />
          <Input label="Facebook link" value={form.site.facebook} onChange={set('site', 'facebook')} placeholder="https://…" />
          <Input label="Instagram link" value={form.site.instagram} onChange={set('site', 'instagram')} placeholder="https://…" />
          <Input label="YouTube link" value={form.site.youtube} onChange={set('site', 'youtube')} placeholder="https://…" />
        </div>
      </Section>

      <Section title="Home page — top banner" hint="The first thing visitors see.">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input className="md:col-span-2" label="Small badge text" value={form.hero.badge} onChange={set('hero', 'badge')} placeholder="Excellence in Education Since 2010" />
          <Input label="Headline" value={form.hero.headline} onChange={set('hero', 'headline')} placeholder="Nurturing Young Minds for a" />
          <Input label="Highlighted words" value={form.hero.headline_highlight} onChange={set('hero', 'headline_highlight')} placeholder="Brighter Future" />
          <Textarea className="md:col-span-2" label="Sub-headline" rows={3} value={form.hero.subheadline} onChange={set('hero', 'subheadline')} />
          <Input label="Main button text" value={form.hero.primary_label} onChange={set('hero', 'primary_label')} />
          <Input label="Main button link" value={form.hero.primary_link} onChange={set('hero', 'primary_link')} placeholder="/admissions" />
          <Input label="Second button text" value={form.hero.secondary_label} onChange={set('hero', 'secondary_label')} />
          <Input label="Second button link" value={form.hero.secondary_link} onChange={set('hero', 'secondary_link')} placeholder="https://…" />
        </div>
      </Section>

      <Section title="Announcement bar" hint="A short notice across the top of every page (for example: Admissions open for 2027).">
        <label className="flex items-center gap-2 text-sm text-gray-700">
          <input type="checkbox" checked={form.notice.enabled} onChange={(e) => setForm((f) => ({ ...f, notice: { ...f.notice, enabled: e.target.checked } }))} />
          Show the announcement bar
        </label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input label="Text" value={form.notice.text} onChange={set('notice', 'text')} />
          <Input label="Link (optional)" value={form.notice.link} onChange={set('notice', 'link')} placeholder="/admissions" />
        </div>
      </Section>

      <Section title="Numbers (home page)" hint="Up to 6, for example 500+ Students Enrolled. Replaces the default four.">
        <RepeatList items={form.stats} max={6} addLabel="Add number" blank={{ value: '', label: '' }} onChange={(stats) => setForm((f) => ({ ...f, stats }))}>
          {(it, upd) => (
            <div className="grid grid-cols-2 gap-3">
              <Input label="Number" value={it.value} onChange={(e) => upd({ value: e.target.value })} placeholder="500+" />
              <Input label="Label" value={it.label} onChange={(e) => upd({ label: e.target.value })} placeholder="Students Enrolled" />
            </div>
          )}
        </RepeatList>
      </Section>

      <Section title="About the school" hint="Used on the About section of the website.">
        <Input label="Title" value={form.about.title} onChange={set('about', 'title')} />
        <Textarea label="Text" rows={6} value={form.about.body} onChange={set('about', 'body')} />
      </Section>

      <Section title="Testimonials" hint="Up to 12. Replaces the default ones when at least one is added.">
        <RepeatList items={form.testimonials} max={12} addLabel="Add testimonial" blank={{ quote: '', author: '', role: '' }} onChange={(testimonials) => setForm((f) => ({ ...f, testimonials }))}>
          {(it, upd) => (
            <>
              <Textarea label="What they said" rows={3} value={it.quote} onChange={(e) => upd({ quote: e.target.value })} />
              <div className="grid grid-cols-2 gap-3">
                <Input label="Name" value={it.author} onChange={(e) => upd({ author: e.target.value })} />
                <Input label="Who they are" value={it.role} onChange={(e) => upd({ role: e.target.value })} placeholder="Parent of Grade 3 student" />
              </div>
            </>
          )}
        </RepeatList>
      </Section>

      <Section title="News & events" hint="Up to 20. The newest three show on the home page.">
        <RepeatList items={form.news} max={20} addLabel="Add news item" blank={{ title: '', date: '', excerpt: '', type: 'News' }} onChange={(news) => setForm((f) => ({ ...f, news }))}>
          {(it, upd) => (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <Input className="sm:col-span-2" label="Title" value={it.title} onChange={(e) => upd({ title: e.target.value })} />
                <Input label="Date" value={it.date} onChange={(e) => upd({ date: e.target.value })} placeholder="April 15, 2027" />
              </div>
              <Textarea label="Short description" rows={2} value={it.excerpt} onChange={(e) => upd({ excerpt: e.target.value })} />
              <div className="flex gap-4 text-sm text-gray-700">
                {['News', 'Event'].map((t) => (
                  <label key={t} className="flex items-center gap-1.5"><input type="radio" checked={it.type === t} onChange={() => upd({ type: t })} /> {t}</label>
                ))}
              </div>
            </>
          )}
        </RepeatList>
      </Section>

      <div className="flex justify-end">
        <Button onClick={save} loading={saving} mobileIcon={false}>Save website content</Button>
      </div>
    </div>
  );
}
