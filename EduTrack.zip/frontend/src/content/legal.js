/**
 * Privacy Policy and Terms of Service text (rendered by pages/Legal).
 *
 * Written to describe what EduTrack actually does. It is a working policy, not
 * legal advice — have it reviewed by a lawyer before relying on it, and keep it
 * in step with the product (bump LEGAL_LAST_UPDATED in constants/company.js
 * when it changes). The company's contact details come from COMPANY.
 */
import { COMPANY } from "../constants/company";

const contactLines = () => [
  COMPANY.supportEmail && `Email: [${COMPANY.supportEmail}](mailto:${COMPANY.supportEmail})`,
  COMPANY.supportPhone && `Phone: ${COMPANY.supportPhone}`,
  COMPANY.address && `Address: ${COMPANY.address}`,
].filter(Boolean);

export const privacyPolicy = () => ({
  title: "Privacy Policy",
  intro: `This policy explains what personal information ${COMPANY.productName} handles, why, who can see it, and the choices you have. ${COMPANY.productName} is school-management software: it helps a school keep its records, collect fees, and keep in touch with parents.`,
  sections: [
    {
      id: "who",
      heading: "1. Who is responsible for the information",
      blocks: [
        { p: `Each school that uses ${COMPANY.productName} decides what information about its students, parents and staff goes into the system and what it is used for — so the **school** is responsible for that information. ${COMPANY.legalName} provides the software and handles the information **on the school's behalf** and on its instructions.` },
        { p: "If you are a parent, student or staff member and want to see, correct or delete information about you, please start with your school's office. We will help the school do it." },
      ],
    },
    {
      id: "what",
      heading: "2. The information involved",
      blocks: [
        { p: "Depending on how your school uses the system, it can include:" },
        { ul: [
          "**Students** — name, admission number, date of birth, gender, class, address, photo, documents the school uploads (such as a birth certificate), attendance, exam results and fee records.",
          "**Parents and guardians** — name, phone number, email address, and their link to a student.",
          "**Staff** — name, contact details, role, employment details the school records (such as contract, qualifications and payroll information), and photo.",
          "**Fees and finances** — fee structures, payments and receipts, expenses and payroll records.",
          "**Messages** — the messages the school sends, the phone numbers or emails they go to, and the delivery result of each.",
          "**Account and security details** — login email, a scrambled (hashed) form of the password, sign-in activity, and an activity history recording who created, changed or deleted what, when, from which device and network address.",
        ] },
        { p: "Some of this is about children. It is entered by the school for educational and administrative purposes." },
      ],
    },
    {
      id: "why",
      heading: "3. How the information is used",
      blocks: [
        { ul: [
          "To run the features the school has chosen: admissions, classes and timetables, attendance, exams and reports, fees and receipts, library, transport, hostel, inventory, payroll and messaging.",
          "To send messages the school asks for, and automatic ones it has switched on — for example telling a parent that an admission is complete or a payment was recorded.",
          "To keep the system secure: sign-in checks, lockout after repeated wrong passwords, automatic sign-out when idle, and the activity history.",
          "To provide support when the school asks for help, and to keep the service running.",
        ] },
        { p: "We do not sell personal information and we do not use it for advertising." },
      ],
    },
    {
      id: "sharing",
      heading: "4. Who else receives it",
      blocks: [
        { p: "Information is shared only as needed to provide the service:" },
        { ul: [
          "**Within the school** — staff see what their role allows. Parents and students see only their own information.",
          "**SMS and email providers** — when a school sends a message, the recipient's phone number or email address and the message text pass to the provider the school has connected. Those providers have their own privacy practices.",
          "**Payment services** — when credits are bought by mobile money, the payment details you enter go to the payment service (for example Payment Gateway Provider or your mobile-money operator).",
          "**Where the law requires it**, such as a valid request from a court or authority.",
        ] },
        { p: "Schools are kept apart: one school cannot see another school's information." },
      ],
    },
    {
      id: "security",
      heading: "5. How it is protected",
      blocks: [
        { ul: [
          "Access needs a login, and what a person can see and do depends on their role and permissions.",
          "Passwords are stored in hashed form and cannot be read by anyone. New staff and students must choose their own password at first sign-in, and changing or resetting a password signs out every other session.",
          "If you forget your password, a one-time code is sent by email and/or SMS (as your school chooses) to the address or number on your account (for a student, to their parent's). It is stored only in scrambled form, works once, and expires after 15 minutes.",
          "Successful and failed sign-ins are recorded in the activity history (when, from which device and network address) so administrators can spot attempts to get into an account. The password that was tried is never kept.",
          "Administrators can set an idle auto-logout, a limit on failed sign-in attempts and the lockout time.",
          "Every create, update and delete is recorded in an activity history that administrators can review. Passwords and other secrets are never written to it.",
        ] },
        { p: "No system can be made perfectly secure. If you think your account has been misused, tell your school's administrator and us straight away." },
      ],
    },
    {
      id: "keeping",
      heading: "6. How long it is kept, and getting it out",
      blocks: [
        { p: "A school's information is kept while the school uses the service, so that its records stay complete. Administrators can export the school's data from **Settings → Backup & Export**. When a school stops using the service, it can ask for its information to be deleted, subject to anything the law requires us to keep." },
      ],
    },
    {
      id: "rights",
      heading: "7. Your rights",
      blocks: [
        { p: "Under data-protection law, including Tanzania's Personal Data Protection Act, 2022, you can generally ask to see the information held about you, to have mistakes corrected, to have it deleted where it is no longer needed, and to object to certain uses. For a child, a parent or guardian can usually act for them." },
        { p: "Please start with your school. If you need to reach us, see section 10." },
      ],
    },
    {
      id: "browser",
      heading: "8. What is stored in your browser",
      blocks: [
        { p: `${COMPANY.productName} keeps your sign-in session and your display preferences (such as the collapsed sidebar and your last-used filters) in your browser's storage on your device. We do not use advertising or tracking cookies.` },
      ],
    },
    {
      id: "changes",
      heading: "9. Changes to this policy",
      blocks: [
        { p: "If we change this policy we will update the date at the top. If a change is significant we will tell schools through the app." },
      ],
    },
    {
      id: "contact",
      heading: "10. Contact",
      blocks: [
        { p: "Questions about this policy or about how information is handled:" },
        { ul: contactLines() },
      ],
    },
  ],
});

export const termsOfService = () => ({
  title: "Terms of Service",
  intro: `These terms are the agreement between you and ${COMPANY.legalName} about using ${COMPANY.productName}. By signing in or using the service you accept them. If you use ${COMPANY.productName} on behalf of a school, you confirm you are allowed to accept them for that school.`,
  sections: [
    {
      id: "service",
      heading: "1. The service",
      blocks: [
        { p: `${COMPANY.productName} is school-management software: admissions, classes, attendance, exams, fees, library, transport, hostel, inventory, payroll, messaging and related tools. Which features a school has depends on its subscription plan. We may improve, change or retire features over time.` },
      ],
    },
    {
      id: "accounts",
      heading: "2. Accounts and access",
      blocks: [
        { ul: [
          "Each person uses their own account. Keep your password private and change the default password when you first sign in.",
          "You are responsible for what is done with your account. Tell your school's administrator and us if you think it has been used without your permission.",
          "A school's administrators decide who gets an account and which role and permissions it has. Give people only the access their work needs.",
        ] },
      ],
    },
    {
      id: "school-data",
      heading: "3. The school's information",
      blocks: [
        { ul: [
          "The information a school puts into the system stays **the school's**. We use it only to provide the service.",
          "The school is responsible for having the right to collect and use that information — including informing parents and guardians about it — and for keeping it accurate.",
          "The school can export its data at any time from **Settings → Backup & Export**.",
          "How we handle personal information is described in the [Privacy Policy](/privacy).",
        ] },
      ],
    },
    {
      id: "acceptable",
      heading: "4. Acceptable use",
      blocks: [
        { p: "You agree not to:" },
        { ul: [
          "use the service for anything unlawful, or to harass, threaten or defraud anyone;",
          "send messages that are spam, misleading, or to people who have not been told the school may contact them;",
          "try to get into another school's information, or into parts of the system you have not been given access to;",
          "interfere with the service, probe it for weaknesses without permission, or copy or resell it.",
        ] },
      ],
    },
    {
      id: "messaging",
      heading: "5. Messaging and other providers",
      blocks: [
        { p: "Text messages and emails are carried by providers and mobile networks that we do not control. \"Accepted\" by a provider is not the same as \"delivered to the phone\", and we cannot guarantee that a message will arrive or arrive on time. The school is responsible for the content of the messages it sends and for the credits it buys from its provider." },
      ],
    },
    {
      id: "subscription",
      heading: "6. Subscription and payment",
      blocks: [
        { p: "The service is provided under a subscription plan. Access may be limited when a subscription expires, after any grace period shown in the app. Prices and plans are as agreed with the school or shown in the app at the time." },
      ],
    },
    {
      id: "availability",
      heading: "7. Availability and responsibility",
      blocks: [
        { p: "We work to keep the service available and the information safe, but it is provided \"as is\" and we do not promise it will always be uninterrupted or error-free. Keep your own copies of anything critical — the export tool is there for this." },
        { p: "To the extent the law allows, we are not responsible for indirect or consequential loss, or for loss caused by things outside our reasonable control (such as network or provider failures). Nothing in these terms limits liability that cannot lawfully be limited." },
      ],
    },
    {
      id: "ending",
      heading: "8. Ending use",
      blocks: [
        { p: "A school can stop using the service at any time. We may suspend or end access that breaks these terms or puts the service or others at risk. When use ends, the school can export its data first, and may ask us to delete it afterwards." },
      ],
    },
    {
      id: "changes",
      heading: "9. Changes",
      blocks: [
        { p: "We may update these terms. The date above shows the latest version, and continuing to use the service after a change means you accept it. If a change is significant we will tell schools through the app." },
      ],
    },
    {
      id: "law",
      heading: "10. Governing law",
      blocks: [
        { p: "These terms are governed by the laws of the United Republic of Tanzania." },
      ],
    },
    {
      id: "contact",
      heading: "11. Contact",
      blocks: [
        { p: "Questions about these terms:" },
        { ul: contactLines() },
      ],
    },
  ],
});
