/**
 * Help Center articles. Written for the people who use EduTrack day to day, and
 * kept to what the app actually does — when a screen or rule changes, change the
 * article with it. Text format is described in components/docs/DocContent.jsx.
 */

export const HELP_CATEGORIES = [
  { id: "start", label: "Getting started" },
  { id: "people", label: "People & admissions" },
  { id: "finance", label: "Fees" },
  { id: "operations", label: "Inventory" },
  { id: "messaging", label: "Messaging" },
  { id: "security", label: "Security & settings" },
];

export const HELP_ARTICLES = [
  // ───────────────────────────────────────────────────────────── Getting started
  {
    slug: "getting-started",
    category: "start",
    title: "Getting started with EduTrack",
    summary: "Find your way around: the top bar, campus and academic year, search, notifications and your profile menu.",
    keywords: ["start", "navigation", "top bar", "campus", "academic year", "search", "notifications", "profile", "logout", "roles"],
    related: ["staff-and-roles", "security-and-audit"],
    sections: [
      {
        id: "top-bar",
        heading: "The top bar: campus and academic year",
        blocks: [
          { p: "Two choices at the top of every page decide what you see:" },
          { ul: [
            "**Campus** — the campus whose records you are working with.",
            "**Academic year** — the school year whose students, classes, fees and reports are shown. Switch it to look back at a past year.",
          ] },
          { note: "If something looks missing — a student, a class, a payment — check these two first. Changing either one changes what every page shows.", tone: "tip" },
        ],
      },
      {
        id: "search",
        heading: "Search",
        blocks: [
          { p: "The search box in the top bar finds **students, staff, classes, library books and contacts** in one go. Type at least two letters; results are labelled by type, and clicking one opens it." },
        ],
      },
      {
        id: "notifications",
        heading: "Notifications",
        blocks: [
          { p: "The bell shows alerts such as a payment being recorded or exam marks being entered. An administrator chooses which alerts are switched on, and whether each one also goes out by SMS or email, in **Settings → Notifications**." },
        ],
      },
      {
        id: "profile-menu",
        heading: "Your profile menu",
        blocks: [
          { p: "Click your picture at the top right to open the menu — **Settings**, **Profile** and **Logout**. It closes when you click anywhere else, press **Esc**, or choose an item." },
        ],
      },
      {
        id: "roles",
        heading: "What you can see depends on your role",
        blocks: [
          { p: "Admins and Principals manage the whole school. Other roles — teacher, accountant, librarian, HR, transport manager, hostel warden — see the modules that match their work." },
          { p: "If a page you need is missing from the menu, ask an administrator to check your role or your permissions in **Settings → Permissions**." },
        ],
      },
    ],
  },

  // ───────────────────────────────────────────────────────── People & admissions
  {
    slug: "staff-and-roles",
    category: "people",
    title: "Adding staff and choosing their role",
    summary: "How to add a staff member, which roles exist, and who is allowed to change a role.",
    keywords: ["staff", "role", "teacher", "admin", "principal", "accountant", "librarian", "hr", "permission", "password", "photo", "login"],
    related: ["security-and-audit", "getting-started"],
    sections: [
      {
        id: "adding",
        heading: "Adding a staff member",
        blocks: [
          { ol: [
            "Open **Staff** and choose to add a staff member.",
            "Fill in their name, **email** and **phone**. The email is their login.",
            "Choose their **Role**. It isn't pre-selected — pick what this person does at the school.",
            "Choose their campus, give them an employee number, and save.",
          ] },
          { p: "They sign in with their email and the default staff password, and are asked to choose their own password the first time." },
        ],
      },
      {
        id: "roles",
        heading: "The roles you can give",
        blocks: [
          { ul: ["Teacher", "Principal", "Admin", "Accountant", "Librarian", "HR Manager", "Transport Manager", "Hostel Warden"] },
        ],
      },
      {
        id: "changing-roles",
        heading: "Changing someone's role",
        blocks: [
          { p: "Open the person, choose **Edit**, change the **Role**, and save. Their access changes straight away on the server; their menu updates the next time they sign in or refresh the page." },
          { p: "To keep the school safe, there are a few rules:" },
          { ul: [
            "**Administrators** can give any staff role.",
            "**Principals and HR managers** can change everyday roles (teacher, accountant, librarian and so on) but **cannot give or take away Admin or Principal**.",
            "**Nobody can change their own role** — ask another administrator.",
            "A **super admin's** role can't be changed from this screen.",
            "Every other role can't change roles. The Role field is locked and says why.",
          ] },
          { note: "Every change — including a role change, with the old and new value — is recorded in the activity history (**Settings → Audit Log**).", tone: "tip" },
        ],
      },
      {
        id: "photo",
        heading: "Profile picture",
        blocks: [
          { p: "Open a staff member and click the ✎ on their picture (Admin, Principal and Super Admin). JPG, PNG or WEBP, up to 2 MB." },
        ],
      },
    ],
  },
  {
    slug: "admissions",
    category: "people",
    title: "Admitting students and the parent notice",
    summary: "Admit one student or many at once, add a photo, and understand the message parents receive.",
    keywords: ["admission", "student", "bulk upload", "template", "excel", "photo", "parent", "sms", "notice", "import"],
    related: ["messaging", "sms-balance"],
    sections: [
      {
        id: "single",
        heading: "Admitting one student",
        blocks: [
          { ol: [
            "Open **Students → Add Admission** and fill in the student's details.",
            "Enter the **parent's phone** (and email if you have it).",
            "Save. The student's admission number and login details are shown on screen.",
          ] },
        ],
      },
      {
        id: "parent-notice",
        heading: "The message parents receive",
        blocks: [
          { p: "When a parent's phone or email is entered, EduTrack sends them an **Admission Completed** notice with the admission number and class. After saving you are told what happened:" },
          { ul: [
            "**Parent notified** — the message went to the SMS gateway / email provider.",
            "**A warning with the reason** — it could not be sent (for example the provider refused it).",
            "**\"No SMS gateway is active\"** — nothing was actually sent. Until a real gateway is connected, messages are only recorded, never delivered.",
            "**\"Switched off\"** — an administrator turned this notice off in **Settings → Notifications**.",
          ] },
          { note: "\"Accepted\" by the gateway is not the same as \"delivered to the phone\". See [Messaging](/help/messaging) for delivery results.", tone: "tip" },
        ],
      },
      {
        id: "bulk",
        heading: "Admitting many students (bulk upload)",
        blocks: [
          { ol: [
            "Open **Students → Bulk Upload** and download the template.",
            "Fill in the **Students** sheet, one student per row. Columns marked with * are required: first name, last name, gender, date of birth, admission number, admission date and campus.",
            "Write dates as **YYYY-MM-DD** (for example 2019-03-27).",
            "Upload the file. Each row is checked and admitted on its own — a row with a mistake is reported and the rest still go through.",
          ] },
          { ul: [
            "The **Class** column is optional, but when you fill it in the name must match a class that exists for that academic year. The **Reference** sheet in the template lists them.",
            "One upload can hold up to **500 students**; split larger files.",
            "The results table has a **Parent Notice** column showing, for each student, whether the parent's message was sent, not sent (no gateway), failed, or skipped (no contact).",
          ] },
        ],
      },
      {
        id: "photo",
        heading: "Student photo",
        blocks: [
          { p: "Open the student and click the ✎ on the picture (Admin, Principal and Super Admin). JPG, PNG or WEBP, up to 2 MB. It is the same photo used on the student's ID card." },
        ],
      },
    ],
  },

  // ─────────────────────────────────────────────────────────────────────── Fees
  {
    slug: "fee-structures",
    category: "finance",
    title: "Fee structures, scenarios and variants",
    summary: "Filter fees by Standard, Transport or Hostel, and pick between prices when one fee has several (for example Transport by route).",
    keywords: ["fee", "fees", "structure", "transport", "hostel", "scenario", "variant", "route", "price", "total"],
    related: ["getting-started"],
    sections: [
      {
        id: "structures",
        heading: "Fee structures",
        blocks: [
          { p: "Each fee structure has a name, an amount, how often it is charged, the class it is for, and **who it applies to**: everyone in the class, only students using **Transport**, only students in the **Hostel**, or **selected students** you assign." },
        ],
      },
      {
        id: "scenario",
        heading: "Filtering by scenario",
        blocks: [
          { p: "In **Fee Management → Fee Structures**, the **Fee Scenario** filter shows the fees that apply in a given situation:" },
          { ul: [
            "**All fee items** — everything.",
            "**Standard fees only** — fees for everyone.",
            "**Include Transport only** — standard fees plus the Transport fees.",
            "**Include Hostel only** — standard fees plus the Hostel fees.",
          ] },
        ],
      },
      {
        id: "variants",
        heading: "When one fee has several prices",
        blocks: [
          { p: "A school often has one fee name with different prices — for example **Transport Fee** costs a different amount on each route. After you choose a scenario, if any fee in it has more than one price, an extra selector appears on the same row (it is named after the fee, e.g. *Transport Fee*)." },
          { ul: [
            "Choose the price (or prices) you want. The list and the **Total Value** card follow your choice.",
            "Choose nothing and the total counts each fee name **once, at its highest price** — it does not add every route together.",
            "The selector only appears when a price choice actually exists.",
          ] },
        ],
      },
    ],
  },

  // ─────────────────────────────────────────────────────────────────── Inventory
  {
    slug: "inventory",
    category: "operations",
    title: "Inventory: fixed assets and consumables",
    summary: "Two kinds of stock behave differently — assets are tracked by condition, consumables by quantity and reorder level.",
    keywords: ["inventory", "asset", "consumable", "stock", "reorder", "low stock", "condition", "receive", "issue", "chalk", "desk"],
    related: ["getting-started"],
    sections: [
      {
        id: "types",
        heading: "Two kinds of stock",
        blocks: [
          { table: {
            head: ["", "Fixed asset", "Consumable"],
            rows: [
              ["Examples", "Desks, projectors, microscopes", "Chalk, exercise books, cleaning supplies"],
              ["What matters", "How many, and in what **condition**", "How many are **left**, and when to restock"],
              ["Condition", "Tracked: new / good / fair / poor", "Not tracked — one pool of stock"],
              ["Reorder level", "Not used", "Yes — flagged **Low** at or below it, **Out of stock** at 0"],
              ["Movements", "Received, Assigned, Damaged, Lost, Adjusted", "Received, Issued / Used, Damaged / Expired, Lost, Adjusted"],
            ],
          } },
        ],
      },
      {
        id: "using",
        heading: "Using the Inventory page",
        blocks: [
          { ul: [
            "The tabs **All Items / Fixed Assets / Consumables** show how many of each you have.",
            "**New Item** asks which type it is first; the form then shows only what applies (reorder level for consumables, starting condition for assets).",
            "**Receive Items** records a delivery of several items at once.",
            "For a consumable, **Adjusted** sets the exact quantity after a stock count. For an asset it corrects the count for one condition.",
            "Issuing or using more than is on hand is refused.",
            "**Low stock only** and the dashboard's low-stock figure count consumables only.",
          ] },
          { note: "Chose the wrong type? Edit the item and change **Item Type**. Moving an item to Asset clears its reorder level.", tone: "tip" },
        ],
      },
    ],
  },

  // ─────────────────────────────────────────────────────────────────── Messaging
  {
    slug: "messaging",
    category: "messaging",
    title: "Messaging documentation",
    summary: "Contacts, groups, sending SMS or email, and what each delivery status means.",
    keywords: ["messaging", "sms", "email", "contacts", "groups", "compose", "history", "delivery", "delivered", "failed", "retry", "gateway", "broadcast"],
    related: ["messaging-templates", "sms-balance"],
    sections: [
      {
        id: "overview",
        heading: "Overview",
        blocks: [
          { p: "**Messages** has a tab for each step: **Contacts**, **Groups**, **Compose**, **History**, **Website Inquiries**, **Templates** and **Info** (the SMS balance)." },
        ],
      },
      {
        id: "contacts",
        heading: "Contacts",
        blocks: [
          { p: "Anyone you can message: parents, staff, suppliers, others. Add them by hand, or choose **Sync from System** to bring in every parent and staff member already in EduTrack (people already synced are skipped)." },
        ],
      },
      {
        id: "groups",
        heading: "Groups",
        blocks: [
          { ul: [
            "**Static groups** — you choose the members.",
            "**Smart groups** — members are worked out from a filter (for example, every parent of Form I), so newly admitted students' parents are included automatically.",
          ] },
          { p: "A group can have **subgroups**, such as \"All Parents\" → \"Form I Parents\"." },
        ],
      },
      {
        id: "sending",
        heading: "Sending a message",
        blocks: [
          { ol: [
            "Open **Messages → Compose**.",
            "Choose **Send To**: a single contact, a group, a subgroup, everyone of a type, or custom phone numbers (one per line or separated by commas).",
            "Choose the **channel** (SMS or email). Optionally start from a [template](/help/messaging-templates).",
            "Click **Preview recipients** to see exactly who will get it and what it will cost.",
            "Write your message — use `{{name}}` to put each person's name in — and send.",
          ] },
          { p: "Sending needs an admin-level role, or the *send messages* permission on your account." },
        ],
      },
      {
        id: "delivery",
        heading: "After sending: delivery results",
        blocks: [
          { p: "Open the message in **History** to see every recipient and what happened to their copy:" },
          { table: {
            head: ["Status", "Meaning"],
            rows: [
              ["**Queued**", "Handed to the SMS provider; waiting for its answer."],
              ["**Accepted**", "The provider took it, but delivery to the phone is not confirmed."],
              ["**Delivered**", "Confirmed delivered to the handset."],
              ["**Failed**", "Rejected or undeliverable. The reason is shown beside it."],
            ],
          } },
          { ul: [
            "**Refresh Delivery** asks the provider for the latest results and tells you what it found — or why it couldn't check.",
            "With some providers the page keeps checking by itself for a few minutes after sending.",
            "**Retry Failed** tries the failed recipients again.",
            "A recipient stays **Queued** until the provider reports back — EduTrack never guesses.",
          ] },
        ],
      },
      {
        id: "automatic",
        heading: "Messages EduTrack sends for you",
        blocks: [
          { p: "Some events send messages automatically — for example the **Admission Completed** notice to a parent. They use the same SMS gateway. An administrator chooses which are on, and by which channel, in **Settings → Notifications**." },
        ],
      },
      // {
      //   id: "gateway",
      //   heading: "If messages aren't really being delivered",
      //   blocks: [
      //     { p: "Until a real SMS provider is connected, EduTrack only **records** messages — nothing leaves the system. The provider (Meseji, NextSMS or Beem Africa) is connected by the platform developer in **Settings → Messages**, where **Test Connection** checks the details and shows the live balance." },
      //   ],
      // },
    ],
  },
  {
    slug: "messaging-templates",
    category: "messaging",
    title: "Templates guide",
    summary: "Save messages you send often, and personalise them with placeholders.",
    keywords: ["template", "templates", "placeholder", "name", "student_name", "balance", "fee reminder", "category", "sms length"],
    related: ["messaging", "sms-balance"],
    sections: [
      {
        id: "what",
        heading: "What a template is",
        blocks: [
          { p: "A template is a message you've saved so you don't retype it — a fee reminder, an exam-results notice, an event invitation. You choose it when composing, edit it if you like, and send." },
        ],
      },
      {
        id: "create",
        heading: "Creating one",
        blocks: [
          { ol: [
            "Open **Messages → Templates** and choose **New Template**.",
            "Give it a **name** you'll recognise.",
            "Pick a **category**: Fee Reminder, Exam Result, Attendance, General, Event or Custom.",
            "Pick the **channel**: SMS, Email or In-App (email templates also have a subject).",
            "Write the message and save.",
          ] },
          { p: "To use it, open **Compose** and choose it under **Template**. Choose *None* to write from scratch." },
        ],
      },
      {
        id: "placeholders",
        heading: "Placeholders",
        blocks: [
          { p: "Put a placeholder in double curly braces and EduTrack fills it in separately for each recipient." },
          { table: {
            head: ["Placeholder", "Becomes", "Available in"],
            rows: [
              ["`{{name}}`", "The recipient's name", "Every message"],
              ["`{{student_name}}`", "The name of the child the message is about", "Fee reminders sent from **Fees → Fee Status**"],
              ["`{{balance}}`", "The amount that child still owes", "Fee reminders sent from **Fees → Fee Status**"],
            ],
          } },
          { note: "A placeholder that isn't available in that kind of send is **not removed** — it goes out exactly as typed, e.g. \"{{balance}}\". Always check the preview before sending.", tone: "warn" },
        ],
      },
      {
        id: "tips",
        heading: "Writing good SMS",
        blocks: [
          { ul: [
            "One SMS holds about **160 characters**. Longer messages are split into parts and can use more than one credit each.",
            "Say who it is from (the school's name) and keep it short.",
            "Include one clear thing to do — pay by a date, attend at a time.",
            "Write for the parent: plain Kiswahili or English, no abbreviations they might not know.",
          ] },
        ],
      },
    ],
  },
  {
    slug: "sms-balance",
    category: "messaging",
    title: "SMS balance and top-up",
    summary: "Where to see your credits, how top-up works for each provider, and what to do when a send is refused.",
    keywords: ["sms", "balance", "credits", "top up", "topup", "buy", "meseji", "nextsms", "swalasms", "swala", "beem", "zenopay", "ussd", "mobile money", "insufficient"],
    related: ["messaging", "messaging-templates"],
    sections: [
      {
        id: "where",
        heading: "Where to see it",
        blocks: [
          { p: "Open **Messages → Info**. With a live provider it also shows the sender name your messages go out under. While composing, the side panel shows your balance and the cost of the message you've previewed, and warns you if it isn't enough." },
        ],
      },
      {
        id: "by-provider",
        heading: "What the balance means",
        blocks: [
          { p: "It depends on how SMS is connected for your school:" },
          { table: {
            head: ["Setup", "Where the credits live", "How you add credits"],
            rows: [
              ["**Not connected** (simulated)", "A balance kept inside EduTrack. Nothing is actually sent.", "An administrator records credits with **Top Up Balance**."],
              ["**Meseji**", "At Meseji — the page shows your live balance.", "**Buy Credits** on the same page (below)."],
              ["**NextSMS**", "At NextSMS — the page shows your live balance.", "Buy credits in your NextSMS account at nextsms.co.tz. They appear here as soon as they are added."],
              ["**SwalaSMS**", "At SwalaSMS — the page shows your live balance (and whether the key is a sandbox one).", "**Buy Credits** on the same page: choose how many credits and how to pay (below)."],
              ["**Beem Africa**", "A balance kept inside EduTrack.", "An administrator records credits with **Top Up Balance**."],
            ],
          } },
        ],
      },
      {
        id: "meseji-topup",
        heading: "Buying credits (Meseji)",
        blocks: [
          { ol: [
            "On **Messages → Info**, choose **Buy Credits**.",
            "Enter the **amount** and the **mobile-money phone number** to charge.",
            "Choose how to pay: **USSD push** (you approve a prompt on that phone) or **ZenoPay** (a Lipa Namba / QR link is shown).",
            "Complete the payment. The credits are added once it is confirmed.",
          ] },
        ],
      },
      {
        id: "swalasms-topup",
        heading: "Buying credits (SwalaSMS)",
        blocks: [
          { ol: [
            "On **Messages → Info**, choose **Buy Credits**.",
            "Choose a **package**, or **Custom** and type how many credits you want. **Check price** shows what it will cost first.",
            "Choose the **payment method**. For mobile money enter the phone number to charge; for a card you are given a link to open.",
            "Click **Pay**, then approve the prompt on the phone (or finish on the card page). The page follows the order and the balance updates when it is paid.",
          ] },
          { p: "A **sandbox** key (it starts with `swl_test_`) never charges anyone and never sends a real SMS — it is only for trying things out. Use a **live** key (`swl_live_`) for real messages." },
        ],
      },
      {
        id: "cost",
        heading: "How many credits a message costs",
        blocks: [
          { ul: [
            "Roughly **one credit per recipient** for a normal SMS of up to about 160 characters.",
            "Longer messages are split into parts and use more.",
            "Messages that fail to send are not charged in EduTrack's own record.",
          ] },
        ],
      },
      {
        id: "refused",
        heading: "If a send is refused for low balance",
        blocks: [
          { ol: [
            "Add credits as above.",
            "Open the message in **Messages → History**.",
            "Choose **Retry Failed** to send to the people who didn't get it.",
          ] },
        ],
      },
    ],
  },

  // ─────────────────────────────────────────────────────────── Security & settings
  {
    slug: "security-and-audit",
    category: "security",
    title: "Security, login policy and the activity history",
    summary: "How passwords and sign-in are protected, and how to see who changed what.",
    keywords: ["security", "password", "login policy", "lockout", "idle", "audit", "audit log", "activity", "history", "who changed", "permissions"],
    related: ["staff-and-roles", "getting-started"],
    sections: [
      {
        id: "passwords",
        heading: "Passwords",
        blocks: [
          { p: "A password needs at least 8 characters, with both letters and numbers. Passwords are stored scrambled (hashed) and can't be read by anyone — not by administrators, and not in the activity history. Change yours any time in **Settings → Security**. When you change it you stay signed in here, but every other place you were signed in is signed out." },
        ],
      },
      {
        id: "first-sign-in",
        heading: "Your first sign-in",
        blocks: [
          { p: "New staff and students are given a standard starting password. The first time you sign in with it, EduTrack asks you to **choose a new password** before showing anything else:" },
          { ol: [
            "Enter the starting password you were given as the *current* password.",
            "Choose a new password — at least 8 characters, with both letters and numbers, and not the starting one — and type it twice.",
            "You are then signed out. Sign in again with your new password.",
          ] },
        ],
      },
      {
        id: "forgot-password",
        heading: "If you forget your password",
        blocks: [
          { p: "You don't need to ask an administrator:" },
          { ol: [
            "On the sign-in page choose **Forgot password?**",
            "Enter what the page asks for — your **email address**, your **phone number**, or either, depending on how your school has set it up.",
            "A 6-digit code is sent to you (by email or SMS — your school chooses). It is valid for **15 minutes** and works once.",
            "Enter the code and a new password. You can then sign in.",
          ] },
          { ul: [
            "Nothing arriving? Check your spam folder (for email), wait a minute and ask for a new code — the old one stops working.",
            "After 5 wrong codes you must ask for a new one.",
            "A student's code goes to their **parent** (their email and/or phone).",
            "If no email or phone is recorded for you (or your parent), no code can be sent — ask your school's office.",
            "**Administrators:** choose where codes go in **Settings → Notifications → Password reset codes** — email only (the default and free), SMS only, or either. The Forgot password page then asks only for that.",
          ] },
          { note: "For your safety the page always gives the same answer, whether or not an account matches — so it never tells you whether an email or number is registered.", tone: "tip" },
        ],
      },
      {
        id: "login-policy",
        heading: "Login policy (administrators)",
        blocks: [
          { p: "In **Settings → Login Policy** an administrator sets:" },
          { ul: [
            "**Idle auto-logout** — minutes of inactivity before someone is signed out (5–240).",
            "**Max failed attempts** — wrong passwords allowed before the account locks (3–10).",
            "**Lockout duration** — how long a locked account stays locked (5–1440 minutes).",
          ] },
        ],
      },
      {
        id: "audit-log",
        heading: "The activity history",
        blocks: [
          { p: "**Settings → Audit Log** (administrators) lists every create, update and delete, who did it, and when — in words, such as *Updated class \"Form 1A\"*. Under an update you can see which fields changed." },
          { p: "Open an entry with **View Details** to see:" },
          { ul: [
            "**Updates** — a table of each field with its value **before** and **after**.",
            "**Creates** — everything the record was created with.",
            "**Deletes** — what the record looked like when it was deleted.",
          ] },
          { p: "You can filter by type (created, updated, deleted, sign-ins), module and date. Sign-ins that failed — a wrong password, a locked or deactivated account — are listed too, in red, so you can see if someone is trying to get in. Passwords and other secrets are never shown — they appear as \"hidden for security\"." },
        ],
      },
      {
        id: "permissions-simple",
        heading: "Permissions in plain words",
        blocks: [
          { p: "Think of your school as a **building with rooms** — Students, Fees, Library, Payroll… Each room has a **door**, and inside it there are **things you can do**. A *permission* is a key. There are two kinds:" },
          { table: {
            head: ["Kind of key", "Looks like", "What it does"],
            rows: [
              ["**Door key**", "*Open Students (shows it in the menu)*", "Without it the module is **missing from the menu** and its pages are closed — even if someone types the address."],
              ["**Action keys**", "*View / Create / Update / Delete Students*", "What a person can **do inside** the room: look, add, change, remove."],
            ],
          } },
          { ul: [
            "**Admins can always do everything** — it can't be switched off, so no one can lock the school out.",
            "Every other role (Principal, Teacher, Accountant, Librarian, HR, Transport Manager, Hostel Warden — and Student and Parent) can do exactly what its keys allow. They **start with the standard keys for their job**, so nothing changes until an Admin changes it.",
            "To take a module away from a role, untick its **Open …** key in **Settings → Permissions**. To stop one action, untick that action (for example *Delete Students*).",
            "To let just **one person** do something extra, use *Individual Overrides* (these only add — to remove something, change the role).",
            "*Your own records* aren't permissions: parents always see their children, and everyone sees their own payslip.",
            "If someone isn't given an action, its **button isn't shown at all** — no \"New payroll period\" for a person who may only view payroll.",
            "Everyone has a dashboard. The **full Dashboard** (statistics) needs its own permission; without it, a simple personal dashboard (your shortcuts, your modules, your notifications) is shown — never an error.",
          ] },
          { note: "The full step-by-step guide, with examples and the complete list of permissions, is in the file **PERMISSIONS_GUIDE.md** that comes with EduTrack (in Swahili).", tone: "tip" },
        ],
      },
      {
        id: "permissions",
        heading: "Permissions",
        blocks: [
          { p: "Everything people can do in EduTrack — view, add, edit, delete, in every module — is a **permission**, not a job title. **Admins can always do everything.** Every other role (the Principal too) can do exactly what is ticked for it in **Settings → Permissions**:" },
          { ul: [
            "**Role Permissions** — tick to allow, untick to take away, for a whole role. What you see ticked is what that role can really do now. *Reset to standard* puts the role back to how it started.",
            "**Individual Overrides** — give one person extra permissions on top of their role (for example, one teacher who may delete).",
            "Deleting follows the module's *Delete* permission — including deleting for good. It isn't reserved for one special role.",
          ] },
          { note: "A parent or student always sees their own records, whatever the permissions say — that is about whose record it is, not what they may do. After you change someone's permissions they see the change the next time their page loads.", tone: "tip" },
        ],
      },
    ],
  },
];

export const findArticle = (slug) => HELP_ARTICLES.find((a) => a.slug === slug) || null;

/** Plain text of an article — what search looks through. */
const articleText = (a) => [
  a.title, a.summary, ...(a.keywords || []),
  ...a.sections.flatMap((s) => [s.heading, ...s.blocks.flatMap((b) => [
    b.p, b.note, ...(b.ul || []), ...(b.ol || []),
    ...(b.table ? [...b.table.head, ...b.table.rows.flat()] : []),
  ])]),
].filter(Boolean).join(" ").toLowerCase();

/** Articles matching every word typed, best (title) matches first. */
export const searchArticles = (query) => {
  const words = String(query || "").toLowerCase().split(/\s+/).filter(Boolean);
  if (words.length === 0) return [];
  return HELP_ARTICLES
    .map((a) => {
      const text = articleText(a);
      if (!words.every((w) => text.includes(w))) return null;
      const title = a.title.toLowerCase();
      return { article: a, score: words.filter((w) => title.includes(w)).length };
    })
    .filter(Boolean)
    .sort((x, y) => y.score - x.score)
    .map((r) => r.article);
};
