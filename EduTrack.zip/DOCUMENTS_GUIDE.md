# Documents — Guide

ID Cards and Certificates, grouped under one "Documents" section since
both are print-and-hand-out documents rather than records tracked over
time (no backend storage for certificates -- they're generated fresh
each time from whatever you type in).

## ID Card (`/documents/id-card`)

Pick Class -> Section -> Student, then print. The card shows photo,
name, admission number, class/section, date of birth, and blood group
if on file -- sized to a real CR80 card (85.6mm x 54mm) so the print
preview roughly matches what comes out of the printer.

Upload Photo sets the student's photo (stored on their account, so it
shows up anywhere else in the app that displays a profile picture too,
not just here).

QR/barcode was left out of this first version (it was marked optional in
the request) to avoid pulling in a new dependency for something not yet
needed -- straightforward to add later if wanted.

## Certificates (`/documents/certificates`)

Four designs -- Classic Gold, Modern Minimal, Formal Blue, Elegant Black
-- sharing one fill-in form: title, recipient name, body text, date, and
two signatory lines. Not tied to a specific student record, so it works
for staff, guests, or any occasion, not just students.

## How to test

1. Documents -> ID Cards -> pick a class/section with students -> pick
   one -> confirm the card preview shows their name, admission number,
   and class.
2. Upload Photo -> pick an image -> confirm it appears on the card
   immediately.
3. Print Card -> confirm the print preview is sized like a real ID card,
   not a full page.
4. Documents -> Certificates -> fill in a recipient name -> switch
   between the four designs -> confirm each looks visually distinct.
5. Print Certificate -> confirm it prints as A4 landscape.
