# Upgrade notes — permissions, security, passwords, signed files

Copy the files in this folder over your project (same paths), then:

1. `cd backend && npm run db:migrate` — adds the `password_resets` table (used only by "Forgot password").
2. Restart the backend, rebuild the frontend.
3. **`server.js` — if yours differs from the one in this folder, apply these three small changes by hand:**
   ```js
   import { requireSignedFile, jsonReplacer } from './utils/signedFiles.js';   // with the other imports
   app.set('json replacer', jsonReplacer);                                       // just before app.use(express.json())
   app.use('/uploads', requireSignedFile, express.static(path.resolve(process.env.UPLOAD_PATH || './uploads'), {
     dotfiles: 'deny', index: false, setHeaders: (res) => res.setHeader('Cache-Control', 'private, max-age=3600'),
   }));                                                                          // replaces the old /uploads line
   ```
4. Optional `.env`: `WEBHOOK_SECRET`, `FILE_URL_SECRET` (both fall back to `JWT_SECRET`), `CLICKPESA_WEBHOOK_SECRET`,
   `DEVELOPER_EMAILS`; frontend: `VITE_SUPPORT_EMAIL`, `VITE_SUPPORT_PHONE`, `VITE_SUPPORT_WHATSAPP`.

## What changes for people

**Permissions (the big one)**
- Every action follows a **permission**, not a job title. **Admin and super admin can always do everything.** Every other role —
  the Principal included — can do exactly what is ticked in **Settings → Permissions**; tick to allow, untick to take away,
  "Reset to standard" to undo. One person can be given extra permissions too. 106 permissions are listed.
- **Buttons follow the exact permission.** Someone who may only *view* payroll sees no "New payroll period" button; no Create → no Add/New buttons, no Update → no Edit/Reactivate, no Delete → no Delete/Deactivate. Form pages (add/edit) are closed too.
- **Dashboard and Notifications have their own permissions.** Everyone has a dashboard: the full one needs `dashboard.access` (principal by default); everyone else gets a simple personal dashboard that can't show errors. Messages tabs and Settings tabs each have their own permission; `settings.manage` was split into `settings.academic_year`, `settings.backup` and `settings.login_policy`; contacts/groups and templates now have their own permissions (`messages.manage_contacts`, `messages.manage_templates`) separate from sending.
- **Every module has an "Open …" permission** (the key to its door). Untick it in Settings → Permissions and the module disappears from that role's menu and its pages are closed. This works for every role, including Student and Parent. Dashboard shortcuts also follow permissions. A beginner's guide (Swahili) is in `PERMISSIONS_GUIDE.md`.
- Each role starts with the permissions that match what it could already do, so nothing changes until an admin changes it —
  **except**: deleting (permanent delete included) now follows the `*.delete` permission instead of being super-admin-only
  (so by default the principal can permanently delete students/classes/subjects, and HR can delete staff for good), HR may
  change staff photos, and the principal can now be restricted like any other role.
- Saved role settings from before keep working (they only ever listed extras); the first time an admin saves a role in the new
  screen, it becomes that role's complete set.
- Students and parents see **only their own records** (unless explicitly granted `students.view`). Staff pay, national ID and bank
  details need `staff.view_sensitive`.
- The menu, the pages and the management buttons follow permissions. A person sees a change when their page reloads
  (the server applies it immediately).

**Passwords and sign-in**
- First sign-in with the standard starting password forces a new password, then signs the person out. Changing or resetting a
  password signs out every other session.
- **Passwords need at least 8 characters, with letters and numbers.**
- **Forgot password:** where the code goes is a school setting — Settings → Notifications → *Password reset codes* —
  **email only by default**, SMS only, or either. The page asks only for what is allowed. A student's code goes to their parent.
- **Failed sign-ins are recorded** in Settings → Audit Log (filter "Sign-ins"; red).
- **Uploaded files need a signed link.** The app adds it automatically; an old copied link stops working after 6–12 hours.

**Security fixes**
- `POST /auth/register` used to let anyone create a super admin in any school. It now needs a signed-in administrator.
- The ClickPesa payment webhook confirms every payment with ClickPesa instead of believing the request.
- Many routes (students, staff, payroll, expenses, inquiries, documents, attendance…) had no role check at all; all are now guarded.

## Developers
`cd backend && npm test`. **Add a line to `backend/tests/helpers/routePolicy.js` for every route you add** — the suite fails until
you do. New permissions go in `utils/permissionCatalog.js` (with the roles that get them by default).
