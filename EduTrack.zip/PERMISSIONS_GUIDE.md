# Mwongozo wa Ruhusa (Permissions) — kwa mwanzilishi kabisa

> Mwongozo huu unaeleza, hatua kwa hatua na kwa mifano, ruhusa ni nini, zinavyofanya kazi, na jinsi ya kuzitumia
> kwenye EduTrack. Huhitaji kujua chochote kuhusu kompyuta ili kuuelewa.

---

## 1. Wazo kuu: shule ni jengo lenye milango na vyumba

Fikiria shule yako kama **jengo lenye vyumba vingi**: chumba cha Wanafunzi, chumba cha Ada, chumba cha Maktaba,
chumba cha Mishahara, na kadhalika. Kila chumba kina **mlango**, na ndani ya chumba kuna **kazi** mtu anazoweza kufanya.

**Ruhusa (permission)** ni *ufunguo*. Kuna aina mbili za funguo:

| Aina ya ufunguo | Mfano | Kinachotokea |
|---|---|---|
| 🚪 **Ufunguo wa mlango** — huanza na neno **"Open"** | *Open Students (shows it in the menu)* | Bila huu, chumba hakionekani kwenye menyu (sidebar), na hata mtu akiandika anwani yake moja kwa moja anaambiwa "huna ruhusa". |
| 🔧 **Funguo za kazi** — **View, Create, Update, Delete** | *Update Students* | Zinaamua mtu **anaweza kufanya nini ndani ya chumba**: kuona, kuongeza, kubadilisha, kufuta. |

**Mfano rahisi:** Mwalimu John ana ufunguo wa mlango wa "Students", na kazi ya "View" tu.
Ataona chumba cha Wanafunzi kwenye menyu na ataweza **kuangalia** wanafunzi, lakini hataona kitufe cha kuongeza,
kubadilisha wala kufuta — na hata kama atajaribu kwa njia nyingine, mfumo utamkatalia.

> **Kumbuka:** ukiondoa ufunguo wa **mlango**, chumba kinapotea kwenye menyu. Ukiondoa kazi moja tu (kwa mfano "Delete"),
> chumba kinabaki lakini kitendo hicho kinakatazwa.

---

## 2. Nani ana uwezo gani kwa kawaida?

- 👑 **Admin na Super Admin: wanaweza kila kitu, daima.** Huwezi kuwaondolea ruhusa. Hii ni makusudi — ili mtu
  asiweze kujifungia nje ya mfumo wake mwenyewe kwa bahati mbaya.
- 👥 **Role nyingine zote** (Mkuu wa shule, Mwalimu, Mhasibu, Mkutubi, HR, Meneja wa usafiri, Mlezi wa hosteli,
  **pamoja na Mwanafunzi na Mzazi**) zinaweza kufanya **kile tu ambacho funguo zao zinaruhusu**.
- ✅ Kila role huanza na **funguo za kawaida** zinazolingana na kazi yake (mfano: Mhasibu anapewa Ada, Matumizi, Mishahara).
  Kwa hiyo **hakuna kinachobadilika mpaka wewe (Admin) ubadilishe**.

### Funguo za mlango za kawaida (nani anaona menyu gani)

| Role | Sehemu anazoziona kwa kawaida |
|---|---|
| Mkuu wa shule (principal) | Analytics, Attendance, Classes, Dashboard kamili, Certificates, ID Cards, Exams, Online Applications, Leave, Messages, Notifications, Payroll, Promotion, Reports, Results, Settings, Students, Subjects, Subscription, Timetable |
| Mwalimu | Attendance, Exams, Leave, Library, Messages, Notifications, Payroll, Results, Students, Subjects, Timetable |
| Mhasibu | Expenses, Fee Management, Leave, Messages, Notifications, Payroll, Reports |
| Mkutubi | Leave, Library, Messages, Notifications, Payroll |
| HR | Leave, Messages, Notifications, Payroll, Staff |
| Meneja wa usafiri | Leave, Messages, Notifications, Payroll, Transport |
| Mlezi wa hosteli | Hostel, Leave, Messages, Notifications, Payroll |
| Mwanafunzi | Exams, Hostel, Leave, Library, Notifications, Results, Timetable, Transport |
| Mzazi | Fee Management, Hostel, Library, Notifications, Results, Transport |

(Kila mtu huona **Help** pia. *Dashboard* na *Notifications* zina funguo zake — angalia sehemu 2B.)

---

## 2B. Dashboard, Notifications, Messages na Settings

### Dashboard — kila mtu ana dashboard yake
- **Open the full Dashboard** (`dashboard.access`): dashboard **kamili** yenye takwimu na chati. Kwa kawaida ni Admin na Mkuu wa shule.
- **Asiyekuwa na ufunguo huo hapati ujumbe wa makosa.** Anapata **dashboard rahisi ya kibinafsi** inayofanya kazi kikamilifu:
  salamu na tarehe (na muhula wa sasa), **njia za mkato** za kazi anazoruhusiwa kufanya, **kadi za module zake** (anazoweza kufungua),
  **arifa zake za karibuni**, na — kwa mzazi — **watoto wake**.
- Takwimu za dashboard kamili pia zinahitaji ruhusa ya **View Analytics**; mtu mwenye dashboard kamili lakini bila Analytics hapati makosa — takwimu hazionekani tu.

### Notifications
- **Open Notifications** (`notifications.access`): kengele iliyo juu na ukurasa wa Notifications. Kila role huanza nayo.
  Ukiiondoa, kengele inapotea.
- **Manage notifications** (`notifications.manage`): kuchagua arifa zipi zitumwe kiotomatiki, kwa njia gani, na pia **code ya kubadilisha password itumwe wapi**
  (email — chaguo la kawaida, SMS, au zote). Hii ni sehemu ya Settings → Notifications.

### Messages — kila kichupo kina ruhusa yake
| Kichupo | Kinahitaji |
|---|---|
| Contacts, Groups, History, Templates, Info | **View Messages** (`messages.view`) — kusoma tu |
| Compose (kutuma ujumbe) | **Send messages** (`send_messages`) |
| Website Inquiries | **View inquiries** (`inquiries.view`) |
| Kuongeza/kubadilisha/kufuta contacts na groups | **Add, edit and delete contacts and groups** (`messages.manage_contacts`) |
| Kuongeza/kubadilisha/kufuta templates | **Manage templates** (`messages.manage_templates`) |
| Kununua credits za SMS | **Buy SMS credits** (`messages.billing`) |

Kuruhusiwa kutuma ujumbe **hakumpi** ruhusa ya kubadilisha orodha ya contacts au templates — ni funguo tatu tofauti.

### Settings — kila mpangilio una ruhusa yake
| Kichupo cha Settings | Kinahitaji | Kinaonekana kwa |
|---|---|---|
| School, General, Theme & Colors, Security | (mapendeleo ya kuonyesha na nenosiri lako mwenyewe) | kila mwenye ufunguo wa **Open Settings** |
| Notifications | **Manage notifications** | Admin, Mkuu wa shule |
| Permissions | **Manage permissions** | Admin pekee |
| Academic Year | **Change the academic year** (`settings.academic_year`) | Admin pekee |
| Backup & Export | **Backups and export** (`settings.backup`) | Admin pekee |
| Login Policy | **Sign-in security rules** (`settings.login_policy`) | Admin pekee |
| Audit Log | **View the audit log** (`audit.view`) | Admin pekee |

Kila kichupo ambacho mtu hana ruhusa yake **hakionekani kabisa**.

---

## 2C. Vitufe vya Ongeza / Badilisha / Futa vinafichwa

Mtu asipokuwa na ruhusa ya kitendo, **kitufe hakionyeshwi kabisa** — hata hajaribu kukifungua.

- Hana **Create** → hakuna kitufe cha "Add / New / Record…".
- Hana **Update** → hakuna "Edit", "Reactivate", "Upload", n.k.
- Hana **Delete** → hakuna "Delete", "Deactivate", "Remove", n.k.
- Mfano: mtu aliyepewa **View Payroll** tu **haoni** "New Payroll Period" wala "Process"/"Mark Paid".
- **Kurasa za fomu** (mfano `/students/admission`, `/staff/add`, `/classes/add`, `/fees/record`) pia hazifunguki mtu asipokuwa na ruhusa ya kitendo hicho — hata akiandika anwani yake.
- Seva bado inakagua kila kitendo, kwa hiyo hakuna njia ya kukwepa kwa kutumia njia nyingine.

---

## 3. Njia mbili za kumpa mtu ruhusa

1. **Kwa role nzima** — *Role Permissions*. Ukimpa role "Mwalimu" ruhusa, **walimu wote** wanaipata.
   Hii ndiyo njia kuu, na ndiyo inayotumika mara nyingi.
2. **Kwa mtu mmoja** — *Individual Overrides*. Unampa **mtu mmoja tu** ruhusa za ziada juu ya zile za role yake.
   Inafaa kwa tofauti: mfano, **mwalimu mmoja tu** apewe ruhusa ya kufuta.

> Ruhusa ya mtu = **ruhusa za role yake + ruhusa alizopewa yeye binafsi**.
>
> ⚠️ *Individual Overrides* ni za **kuongeza tu**. Ukitaka kumzuia mtu mmoja kitu ambacho role yake inaruhusu,
> huwezi kukiondoa kwa yeye peke yake — ondoa kwenye **role** (inaathiri wote wa role hiyo), au mpe mtu huyo role nyingine.

---

## 4. Jinsi ya kubadilisha ruhusa (hatua kwa hatua)

Unahitaji kuwa **Admin**.

### A. Kubadilisha ruhusa za role nzima
1. Ingia, bofya **Settings** kwenye menyu, kisha tab ya **Permissions**.
2. Upande wa kushoto, chini ya **Role Permissions**, chagua **Role** (mfano: Teacher).
3. Utaona orodha ya modules (Dashboard, Students, Fees, Library…). Chagua module. Ndani yake utaona **tiki** kwa kila ruhusa.
   - **Tiki iliyowekwa ✔ = role hiyo INAWEZA.**
   - **Tiki iliyotolewa ☐ = role hiyo HAIWEZI.**
4. Weka au toa tiki. **Inahifadhiwa papo hapo.** Hakuna kitufe cha "Save".
5. Ukikosea au unataka kurudi kwenye mpangilio wa awali: bofya **Reset to standard**.
   Karibu na jina la role utaona **"Customised for this school"** kama umeshabadilisha, au **"Standard permissions"** kama haujabadilisha.

### B. Kumpa mtu mmoja ruhusa
1. Settings → Permissions, upande wa kulia, chini ya **Individual Overrides**.
2. Chagua mtu (mfanyakazi).
3. Weka tiki za ruhusa za ziada unazotaka ampewe.

### C. Mtu ataona mabadiliko lini?
Mara moja anapofungua ukurasa upya (refresh) au anapoingia tena. Kwa upande wa seva, mabadiliko yana nguvu papo hapo.

---

## 5. Mifano halisi (mapishi)

**① Mwalimu aweze kufuta wanafunzi.**
Settings → Permissions → Role: *Teacher* → module *Students* → weka tiki **Delete Students**.
(Walimu wote wataweza.) Au, kwa mwalimu mmoja tu: *Individual Overrides* → chagua mwalimu → **Delete Students**.

**② Mhasibu asirekodi malipo mapya, aangalie tu.**
Role: *Accountant* → module *Fees* → toa tiki **Create Fees**. (Ataendelea kuona malipo, hawezi kuongeza mapya.)

**③ Kuficha kabisa module kutoka kwa role.**
Mfano: usitake Wazazi waone *Hostel*. Role: *Parent* → module *Hostel* → toa tiki **Open Hostel (shows it in the menu)**.
Hosteli itapotea kwenye menyu ya wazazi wote, na hawataweza kuifungua hata kwa anwani.

**④ Mtu aone module ambayo hajazoea kuiona.**
Mfano: karani (role ya Teacher) aone *Fees*. *Individual Overrides* → chagua karani → weka **Open Fee Management** na **View Fees**.

**⑤ Mkuu wa shule asiweze kubadilisha mipangilio ya SMS.**
Role: *Principal* → module *Messages* → toa tiki **Buy SMS credits & set SMS cost**.

**⑥ Mtu aone mishahara ya wafanyakazi.**
Weka **See staff pay, ID and bank details** (kwenye module *Staff*). Bila hii, mtu huona majina na mawasiliano tu, si mshahara wala benki.

---

## 6. Sheria za dhahabu (soma hizi!)

1. 👑 **Admin hawezi kuzuiwa.** Hata ukitoa kila tiki, Admin anafanya kila kitu. Hii ndiyo kinga yako.
2. 🚪 **"Open" = mlango.** Ukiondoa, module inapotea. Ukitoa kazi (View/Create/…) peke yake, module inabaki.
3. 🔒 **Rekodi zako mwenyewe si ruhusa.** Mzazi huona watoto wake, mwanafunzi huona matokeo yake, mfanyakazi huona
   payslip yake — **bila kujali ruhusa** (kuona rekodi *yako* hakuhitaji ufunguo wa kazi). Hii ni kuhusu *rekodi ni ya nani*, si *anaruhusiwa nini*.
   *(Isipokuwa: mzazi au mwanafunzi akipewa makusudi "View Students", ataona wanafunzi wote.)*
4. 🧩 **Kutoa na kuongeza vyote vinawezekana.** Unaweza kuondoa ruhusa ya kawaida ya role (mfano toa "Create Fees" kwa Mhasibu),
   si kuongeza tu.
5. 🧭 **Kufuta kabisa** (kisichorudi) kinafuata ruhusa ya **Delete** ya module hiyo. Mpe mtu "Delete" kwa tahadhari — ni kama kumpa
   ufunguo wa kuchoma faili.
6. 🕵️ **Kila kitu kinarekodiwa.** Angalia **Settings → Audit Log** kuona nani alifuta/alibadilisha nini.
7. 🔄 **Rudi nyuma kwa urahisi:** kitufe cha **Reset to standard** kinarudisha role kwenye mpangilio wa awali.

---

## 7. Maswali ya kawaida

**Nimeondoa ruhusa lakini mtu bado anaona module.**
Mwambie apakie ukurasa upya (refresh) au aingie tena. Kumbuka: lazima uondoe tiki ya **"Open …"** ya module hiyo (ya mlango).
Pia hakikisha mtu huyo hana ruhusa ya ziada binafsi (Individual Overrides) wala si Admin.

**Mtu anaona module lakini hawezi kufanya kitu.**
Ana ufunguo wa mlango lakini hana funguo za kazi. Mpe View/Create/Update/Delete anazohitaji.

**Mimi ni Admin lakini role ya "Admin" haipo kwenye orodha ya Role Permissions.**
Ni makusudi — Admin hana kikomo, kwa hiyo hakuna cha kuchagua.

**Nimekosea na sikumbuki mpangilio wa awali.**
Chagua role, bofya **Reset to standard**.

**Kwa nini Mhasibu bado anaweza kuchagua mwanafunzi kwenye Ada ingawa haoni module ya Wanafunzi?**
Kuchagua jina la mwanafunzi ni sehemu ya kazi ya Ada. Ruhusa ya "View Students" ni tofauti na "Open Students" (mlango).

**Je, ruhusa zinatumika pia kwenye simu/API?**
Ndiyo. Seva ndiyo inayoamua kila kitendo. Hata kama mtu atajaribu kupitia njia isiyo ya skrini, ataambiwa
*"You don't have permission to do this (jina-la-ruhusa)"* — jina hilo la ruhusa ndilo unalolitafuta kwenye orodha hapa chini.

---

## 8. Orodha kamili ya ruhusa

Imepangwa kwa module. Safu ya mwisho inaonyesha **nani anapewa kwa kawaida** (Admin daima ana zote).
Jina kwenye mabano `like.this` ndilo jina la ndani la ruhusa (linaonekana kwenye ujumbe wa kukataliwa).


### Dashboard

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open the full Dashboard (statistics & charts) — everyone else gets a simple personal dashboard** (`dashboard.access`) | Kufungua Dashboard KAMILI (takwimu na chati). Asiyekuwa nayo hupata Dashboard rahisi ya kibinafsi — haitoi makosa | Mkuu |

### Wanafunzi

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Students (shows it in the menu)** (`students.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu, Mwalimu |
| **Create Students** (`students.create`) | Kuongeza wanafunzi | Mkuu |
| **Update Students** (`students.update`) | Kubadilisha wanafunzi | Mkuu |
| **Delete Students** (`students.delete`) | Kufuta wanafunzi (pamoja na kufuta kabisa) | Mkuu |
| **View & upload student documents** (`students.documents`) | Kuona na kupakia hati za mwanafunzi (cheti cha kuzaliwa n.k.) na kubadilisha picha yake | Mkuu |
| **View Students** (`students.view`) | Kuona orodha ya wanafunzi wote na taarifa zao (bila hii, mzazi/mwanafunzi huona wake tu) | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli |

### Wafanyakazi (Staff)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Staff (shows it in the menu)** (`staff.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | HR |
| **View Staff** (`staff.view`) | Kuona orodha ya wafanyakazi (majina na mawasiliano; si mishahara) | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli |
| **See staff pay, ID and bank details** (`staff.view_sensitive`) | Kuona mshahara, namba ya kitambulisho, akaunti ya benki na taarifa binafsi za mfanyakazi | Mkuu, HR |
| **Create Staff** (`staff.create`) | Kuongeza wafanyakazi | Mkuu, HR |
| **Update Staff** (`staff.update`) | Kubadilisha wafanyakazi | Mkuu, HR |
| **Delete Staff** (`staff.delete`) | Kufuta wafanyakazi (pamoja na kufuta kabisa) | Mkuu, HR |

### Mahudhurio

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Attendance (shows it in the menu)** (`attendance.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu, Mwalimu |
| **Create Attendance** (`attendance.create`) | Kuongeza mahudhurio | Mkuu, Mwalimu |
| **View Attendance** (`attendance.view`) | Kuona mahudhurio | Mkuu, Mwalimu |
| **Update Attendance** (`attendance.update`) | Kubadilisha mahudhurio | Mkuu, Mwalimu |

### Matawi (Campus)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Campus (shows it in the menu)** (`campus.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | — (Admin pekee) |
| **View campus statistics** (`campus.view`) | Kuona takwimu za tawi | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli |
| **Create Campus** (`campus.create`) | Kuongeza matawi | — (Admin pekee) |
| **Update Campus** (`campus.update`) | Kubadilisha matawi | — (Admin pekee) |
| **Delete Campus** (`campus.delete`) | Kufuta matawi (pamoja na kufuta kabisa) | — (Admin pekee) |

### Madarasa na Masomo

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Subjects (shows it in the menu)** (`subjects.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu, Mwalimu |
| **Open Classes (shows it in the menu)** (`classes.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu |
| **Create Classes & Subjects** (`academics.create`) | Kuongeza madarasa na masomo | Mkuu |
| **View class & subject statistics** (`academics.view`) | Kuona takwimu za darasa/somo | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli |
| **Update Classes & Subjects** (`academics.update`) | Kubadilisha madarasa na masomo | Mkuu |
| **Delete Classes & Subjects** (`academics.delete`) | Kufuta madarasa na masomo (pamoja na kufuta kabisa) | Mkuu |

### Ratiba (Timetable)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Timetable (shows it in the menu)** (`timetable.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu, Mwalimu, Mwanafunzi |
| **View timetable setup** (`timetable.view`) | Kuona mipangilio ya ratiba | Mkuu, Mwalimu |
| **Edit timetable setup** (`timetable.update`) | Kubadilisha mipangilio ya ratiba | Mkuu |
| **Edit individual timetable periods** (`timetable.entry`) | Kubadilisha vipindi vya ratiba kimoja kimoja | Mkuu, Mwalimu |

### Mitihani na Matokeo

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Results (shows it in the menu)** (`results.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu, Mwalimu, Mwanafunzi, Mzazi |
| **Open Exams (shows it in the menu)** (`exams.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu, Mwalimu, Mwanafunzi |
| **Enter & view marks sheets** (`exams.marks`) | Kuingiza na kuona alama za mitihani (marks sheet) | Mkuu, Mwalimu |
| **Create Exams & Grades** (`exams.create`) | Kuongeza mitihani | Mkuu |
| **Update Exams & Grades** (`exams.update`) | Kubadilisha mitihani | Mkuu |
| **Delete Exams & Grades** (`exams.delete`) | Kufuta mitihani (pamoja na kufuta kabisa) | Mkuu |

### Ada (Fees)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Fee Management (shows it in the menu)** (`fees.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mhasibu, Mzazi |
| **View Fees** (`fees.view`) | Kuona ada | Mkuu, Mhasibu |
| **Create Fees** (`fees.create`) | Kuongeza ada | Mkuu, Mhasibu |
| **Update Fees** (`fees.update`) | Kubadilisha ada | Mkuu, Mhasibu |
| **Delete Fees** (`fees.delete`) | Kufuta ada (pamoja na kufuta kabisa) | Mkuu, Mhasibu |

### Ujumbe (Messages)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Messages (shows it in the menu)** (`messages.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli |
| **View messages, contacts & groups** (`messages.view`) | Kuona kichupo cha Contacts, Groups, History, Templates na Info (kusoma tu) | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli |
| **Add, edit and delete contacts and groups** (`messages.manage_contacts`) | Kuongeza, kubadilisha na kufuta contacts na makundi (groups) | Mkuu |
| **Send messages & manage contacts, groups, templates** (`send_messages`) | Kutuma ujumbe (SMS/barua pepe) kupitia kichupo cha Compose | Mkuu |
| **Buy SMS credits & set SMS cost** (`messages.billing`) | Kununua credits za SMS na kuweka gharama ya SMS | Mkuu |
| **Manage templates** (`messages.manage_templates`) | Kuongeza, kubadilisha na kufuta violezo vya ujumbe (templates) | Mkuu |

### Arifa (Notifications)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Notifications (the bell and the page)** (`notifications.access`) | Kuona kengele ya arifa na ukurasa wa Notifications | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli, Mwanafunzi, Mzazi |
| **Choose which notifications are sent** (`notifications.manage`) | Kuchagua arifa zipi zitumwe, kwa njia gani, na code ya password itumwe wapi (email / SMS) | Mkuu |

### Usafiri

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Transport (shows it in the menu)** (`transport.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Usafiri, Mwanafunzi, Mzazi |
| **Create Transport** (`transport.create`) | Kuongeza usafiri | Mkuu, Usafiri |
| **Update Transport** (`transport.update`) | Kubadilisha usafiri | Mkuu, Usafiri |
| **Delete Transport** (`transport.delete`) | Kufuta usafiri (pamoja na kufuta kabisa) | Mkuu, Usafiri |
| **View Transport** (`transport.view`) | Kuona usafiri | Mkuu, Usafiri |

### Maktaba

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Library (shows it in the menu)** (`library.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mwalimu, Mkutubi, Mwanafunzi, Mzazi |
| **Create Library** (`library.create`) | Kuongeza maktaba | Mkuu, Mkutubi |
| **Update Library** (`library.update`) | Kubadilisha maktaba | Mkuu, Mkutubi |
| **Delete Library** (`library.delete`) | Kufuta maktaba (pamoja na kufuta kabisa) | Mkuu, Mkutubi |
| **View Library** (`library.view`) | Kuona maktaba | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli |

### Likizo (Leave)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Leave (shows it in the menu)** (`leave.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli, Mwanafunzi |
| **Request leave & act on approvals** (`leave.request`) | Kuomba likizo na kufanya kazi za idhini (approvals) | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli, Mwanafunzi |
| **Create Leave** (`leave.create`) | Kuongeza likizo | Mkuu, HR |
| **Update Leave** (`leave.update`) | Kubadilisha likizo | Mkuu, HR |
| **Delete Leave** (`leave.delete`) | Kufuta likizo (pamoja na kufuta kabisa) | Mkuu, HR |
| **View Leave** (`leave.view`) | Kuona likizo | Mkuu, HR |

### Matumizi (Expenses)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Expenses (shows it in the menu)** (`expenses.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mhasibu |
| **View Expenses** (`expenses.view`) | Kuona matumizi | Mkuu, Mhasibu |
| **Create Expenses** (`expenses.create`) | Kuongeza matumizi | Mkuu |
| **Update Expenses** (`expenses.update`) | Kubadilisha matumizi | Mkuu |
| **Delete Expenses** (`expenses.delete`) | Kufuta matumizi (pamoja na kufuta kabisa) | Mkuu |

### Hosteli

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Hostel (shows it in the menu)** (`hostel.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Hosteli, Mwanafunzi, Mzazi |
| **Create Hostel** (`hostel.create`) | Kuongeza hosteli | Mkuu, Hosteli |
| **Update Hostel** (`hostel.update`) | Kubadilisha hosteli | Mkuu, Hosteli |
| **Delete Hostel** (`hostel.delete`) | Kufuta hosteli (pamoja na kufuta kabisa) | Mkuu, Hosteli |
| **View Hostel** (`hostel.view`) | Kuona hosteli | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli |

### Usajili wa shule (Subscription)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Subscription (shows it in the menu)** (`subscription.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu |
| **Manage the school subscription** (`subscription.manage`) | Kusimamia usajili (subscription) wa shule | Mkuu |

### Kupandisha madarasa

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Promotion (shows it in the menu)** (`promotions.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu |
| **Run & revert student promotions** (`promotions.manage`) | Kupandisha wanafunzi darasa na kurudisha nyuma | Mkuu |

### Mishahara (Payroll)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Payroll (shows it in the menu)** (`payroll.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli |
| **View Payroll** (`payroll.view`) | Kuona mishahara | Mhasibu, HR |
| **Create Payroll** (`payroll.create`) | Kuongeza mishahara | Mhasibu, HR |
| **Delete Payroll** (`payroll.delete`) | Kufuta mishahara (pamoja na kufuta kabisa) | Mhasibu, HR |
| **Update Payroll** (`payroll.update`) | Kubadilisha mishahara | Mhasibu, HR |

### Mali na Vifaa (Inventory)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Inventory (shows it in the menu)** (`inventory.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | — (Admin pekee) |
| **View Inventory** (`inventory.view`) | Kuona vifaa/mali | Mkuu, Mwalimu, Mhasibu, Mkutubi, HR, Usafiri, Hosteli |
| **Create Inventory** (`inventory.create`) | Kuongeza vifaa/mali | Mkuu |
| **Update Inventory** (`inventory.update`) | Kubadilisha vifaa/mali | Mkuu |
| **Delete Inventory** (`inventory.delete`) | Kufuta vifaa/mali (pamoja na kufuta kabisa) | Mkuu |

### Takwimu (Analytics)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Analytics (shows it in the menu)** (`analytics.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu |
| **View Analytics** (`analytics.view`) | Kuona takwimu (Analytics) — pia zinatumika kwenye Dashboard kamili | Mkuu |

### Ripoti

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Reports (shows it in the menu)** (`reports.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu, Mhasibu |
| **View Reports** (`reports.view`) | Kuona ripoti | Mkuu, Mhasibu |

### Ruhusa (Permissions)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Manage permissions** (`permissions.manage`) | Kusimamia ruhusa (ukurasa huu) | — (Admin pekee) |

### Mipangilio (Settings)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Settings (shows it in the menu)** (`settings.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu |
| **Change the academic year and terms** (`settings.academic_year`) | Kubadilisha mwaka wa masomo na mihula (terms) | — (Admin pekee) |
| **Set up backups and export the school\'s data** (`settings.backup`) | Kuweka ratiba ya backup na kuhamisha (export) data yote ya shule | — (Admin pekee) |
| **Change the sign-in security rules (auto sign-out, lockout)** (`settings.login_policy`) | Kubadilisha sheria za usalama wa kuingia (kutoka kiotomatiki, kufungwa akaunti) | — (Admin pekee) |

### Kumbukumbu za shughuli (Audit Log)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **View the audit log** (`audit.view`) | Kuona kumbukumbu za shughuli (Audit Log) | — (Admin pekee) |

### Maombi ya mtandaoni

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Open Online Applications (shows it in the menu)** (`inquiries.access`) | FUNGUO YA MLANGO: kuonyesha sehemu hii kwenye menyu na kuruhusu kufungua kurasa zake | Mkuu |
| **View admission & contact inquiries** (`inquiries.view`) | Kuona maombi ya admission na ujumbe kutoka tovuti | Mkuu |
| **Update inquiries** (`inquiries.update`) | Kujibu/kubadilisha hali ya maombi hayo | Mkuu |

### Hati (ID Cards na Vyeti)

| Ruhusa | Inaruhusu | Wanaopewa kwa kawaida |
|---|---|---|
| **Generate ID cards** (`documents.id_cards`) | Kutengeneza kadi za utambulisho (ID Cards) — pia ndiyo ufunguo wa ukurasa huo | Mkuu |
| **Generate certificates** (`documents.certificates`) | Kutengeneza vyeti — pia ndiyo ufunguo wa ukurasa huo | Mkuu |

---

*Mwongozo huu unaonyesha mpangilio wa kawaida wa EduTrack. Kinachotumika kwenye shule yako ni kile ulichoweka kwenye Settings → Permissions.*
