# Contributing to EduTrack

Thank you for considering contributing to EduTrack! We welcome contributions from the community to help make this school management system better.

## Table of Contents
- [Code of Conduct](#code-of-conduct)
- [How Can I Contribute?](#how-can-i-contribute)
- [Development Setup](#development-setup)
- [Coding Standards](#coding-standards)
- [Commit Guidelines](#commit-guidelines)
- [Pull Request Process](#pull-request-process)

## Code of Conduct

This project and everyone participating in it is governed by a code of conduct. By participating, you are expected to uphold this code:

- Be respectful and inclusive
- Welcome newcomers and help them learn
- Focus on what is best for the community
- Show empathy towards other community members

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check the existing issues to avoid duplicates. When you create a bug report, include as many details as possible:

- **Use a clear and descriptive title**
- **Describe the exact steps to reproduce the problem**
- **Provide specific examples**
- **Describe the behavior you observed and what you expected**
- **Include screenshots if relevant**
- **Include your environment details** (OS, Node version, browser, etc.)

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion:

- **Use a clear and descriptive title**
- **Provide a detailed description of the suggested enhancement**
- **Explain why this enhancement would be useful**
- **List any alternative solutions you've considered**

### Your First Code Contribution

Unsure where to begin? Look for issues labeled:
- `good first issue` - Good for newcomers
- `help wanted` - Extra attention is needed

### Pull Requests

1. Fork the repo and create your branch from `main`
2. Make your changes
3. Ensure your code follows the coding standards
4. Test your changes thoroughly
5. Update documentation as needed
6. Submit your pull request

## Development Setup

1. **Clone your fork:**
```bash
git clone https://github.com/your-username/EduTrack.git
cd EduTrack
```

2. **Set up the backend:**
```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your database credentials
npm run seed  # Optional: Load demo data
npm run dev
```

3. **Set up the frontend:**
```bash
cd ../frontend
npm install
cp .env.example .env
npm run dev
```

4. **Create a branch:**
```bash
git checkout -b feature/your-feature-name
```

## Coding Standards

### JavaScript/Node.js (Backend)

- Use ES6+ features
- Use async/await for asynchronous code
- Follow REST API conventions
- Use meaningful variable and function names
- Add JSDoc comments for functions
- Handle errors properly
- Validate all inputs
- Use Sequelize ORM for database operations

**Example:**
```javascript
/**
 * Create a new student
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware
 */
export const createStudent = async (req, res, next) => {
  try {
    // Implementation
  } catch (error) {
    next(error);
  }
};
```

### React (Frontend)

- Use functional components with hooks
- Use meaningful component and variable names
- Keep components focused and single-purpose
- Use PropTypes or TypeScript for type checking
- Handle loading and error states
- Follow React best practices

**Example:**
```jsx
import { useState, useEffect } from 'react';

export default function StudentList() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchStudents();
  }, []);

  // Component implementation
}
```

### General Guidelines

- **File Naming:**
  - Components: PascalCase (e.g., `StudentList.jsx`)
  - Utilities: camelCase (e.g., `apiHelper.js`)
  - Models: PascalCase (e.g., `Student.js`)

- **Code Organization:**
  - Keep files under 300 lines
  - Extract reusable logic into utility functions
  - Group related files in appropriate directories

- **Comments:**
  - Write self-documenting code
  - Add comments for complex logic
  - Keep comments up-to-date

- **Error Handling:**
  - Always handle errors
  - Provide meaningful error messages
  - Log errors appropriately

## Commit Guidelines

We follow [Conventional Commits](https://www.conventionalcommits.org/):

### Commit Message Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types

- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, etc.)
- `refactor`: Code refactoring
- `test`: Adding or updating tests
- `chore`: Maintenance tasks

### Examples

```
feat(students): add bulk student import functionality

Add ability to import multiple students from CSV file.
Includes validation and error reporting.

Closes #123
```

```
fix(attendance): resolve date filtering issue

Fixed bug where date range filter was not working correctly
for attendance records.

Fixes #456
```

## Pull Request Process

1. **Update Documentation**
   - Update README.md if needed
   - Update API documentation
   - Add inline code comments

2. **Test Your Changes**
   - Manually test all affected features
   - Ensure existing functionality still works
   - Test edge cases

3. **Create Pull Request**
   - Use a clear and descriptive title
   - Fill out the PR template completely
   - Link related issues
   - Add screenshots for UI changes

4. **Code Review**
   - Address reviewer feedback
   - Make requested changes
   - Keep discussion professional and constructive

5. **Merge**
   - Squash commits if requested
   - Ensure CI passes
   - Wait for approval from maintainers

## Testing

### Backend Tests

```bash
cd backend
npm test
```

### Frontend Tests

```bash
cd frontend
npm test
```

## Database Changes

When making database changes:

1. Create migrations (don't use sync in production)
2. Update models
3. Update seeders if applicable
4. Document the changes

## Security

- Never commit sensitive data (passwords, API keys, etc.)
- Use environment variables for configuration
- Validate and sanitize all inputs
- Follow OWASP security guidelines
- Report security vulnerabilities privately

## Documentation

- Keep README.md up-to-date
- Document new features
- Update API documentation
- Add inline comments for complex logic
- Include examples where helpful

## Questions?

Feel free to:
- Open an issue for questions
- Join our community chat (if available)
- Email maintainers directly

## Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes
- Project website (if available)

Thank you for contributing to EduTrack! 🎉
