# Exams & Grades — Guide

A simple, working implementation replacing the old "Coming Soon" placeholder
pages. Kept intentionally simple (same lesson learned from the Timetable
module): one clear workflow, no configurable grading-scale UI, no extra
setup screens.

## How it works

### 1. Create an Exam — `/exams`
Admin/Principal only. Name, type (Midterm/Final/Mock/Quiz/CA), term,
academic year (locked to whatever's selected in the top navigation bar —
same fix as the Timetable module, so this can't silently mismatch), dates,
status. Simple CRUD list + modal form.

### 2. Enter Marks — `/exams/:id/marks-entry`
Admins and teachers. Pick a Class, (optionally) a Section, and a Subject,
set "out of" (max marks), click **Load Students** — a grid appears with
every active student in that class/section and an input box for their
marks. Grade letter previews live as you type. **Save Marks** upserts one
row per student (safe to reopen and edit later — it pre-fills whatever was
already saved).

Grading scale (fixed, not configurable in the UI on purpose):
`A ≥ 75%`, `B ≥ 65%`, `C ≥ 45%`, `D ≥ 30%`, else `F`.

### 3. Results — `/results`
Adapts to who's looking:
- **Admin/Principal/Teacher**: pick Exam + Class (+ Section) → a full
  mark-sheet matrix (every student × every subject that has marks for that
  exam), with Total, Average %, Overall Grade, and a simple class Rank.
  Each row links to that student's printable Report Card.
- **Parent**: pick a child (auto-selected if there's only one) + an exam →
  **View Report Card**.
- **Student**: sees a list of exams they already have marks for → tap one
  to open their own Report Card.

### 4. Report Card — `/results/:examId/report-card/:studentId`
One student, one exam: subject-by-subject marks/grades, total, average,
overall grade. Has a **Print** button.

## Access control
- Marks entry and the class-results matrix are staff-only (admin,
  principal, teacher).
- A Report Card can only be opened by: staff (any student), the student
  themselves, or a parent linked to that student (`Student.parent_id`
  matches the logged-in user). Anyone else gets a 403 — this closes a gap
  that existed in the placeholder-era routing (nothing enforced this
  before, because nothing real existed yet).

## How to test

The seed script (`npm run seed`) now creates **two exams** — "Midterm
Examination" and "Final Examination" — with real marks already filled in
for **every subject**, across **every section of Form I, II and III**
(~5,800 grade records in total). This means you can explore Results and
Report Cards immediately without entering anything by hand:

1. Log in as `admin@lucylameck.ac.tz` (or your seeded admin).
2. Go straight to **Results** → pick "Midterm Examination" + Form I (or II
   or III) + a section → **View Results** — confirm the matrix shows all
   13 subjects, with Total/Average/Grade/Rank computed correctly, and that
   switching to "Final Examination" shows different (but equally
   complete) marks.
3. Click **Report Card** on any row — confirm every subject appears, the
   totals/average/overall grade match the matrix, class position looks
   right, and **Print** opens a clean, professional-looking result form.
4. Compare a student's rank on the same exam across two different
   sections of the same Form to sanity-check the ranking math (each
   section is ranked independently).
5. Log in as the seeded student (see credentials below) — confirm
   `/results` lists **both** exams and opens correctly for each.

Then try the manual flow end-to-end for a class that has no seeded exam
data yet (Form IV or above):

6. **Exams** → create a new exam (e.g. "Midterm 2026").
7. Click **Enter Marks** → pick a class/section/subject, "out of" 100 →
   **Load Students** → type a few marks → **Save Marks**. Repeat for 1–2
   more subjects.
8. **Results** → pick that exam + class → confirm the new marks appear
   alongside the seeded ones structurally the same way.
9. Log in as a **teacher** account — confirm **Enter Marks** still works,
   but Edit/Delete are hidden for non-admin roles on `/exams`.
10. Try to guess another student's ID in the report-card URL while logged
    in as a student — confirm you get a "not allowed" message instead of
    their data.

## What's still a placeholder
Fees, Library, Transport, Hostel, Reports/Analytics, Notifications, and
Messages are unchanged — still "Coming Soon" pages with no backend, same
as before this round of work.

## Report card columns (term report card)

A report card is for a whole **term**, whichever exam of that term it is opened from. Per subject it shows:

| Column | Meaning |
| --- | --- |
| Test | Average (as a percentage) of the student's results in every **test** of the term. A test is any exam in the same academic year and term, applicable to the class, whose type is **not** `Final`. |
| Exam | The student's result in the term's `Final` exam (the latest one, if several exist), as a percentage. |
| Average | The average of Test and Exam. If only one of them exists it is used on its own; a missing column is never counted as 0. |
| Grade / Remark | Grade for the Average, using the same scale as above, with its remark. |

Percentages are used so that papers marked out of different totals count equally. The summary shows Total Score (sum of subject averages), Average, Overall Grade and Class Position (ranked on the term average). The calculation lives in `backend/src/utils/reportCardCalc.js`.
