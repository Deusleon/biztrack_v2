EduTrack update 8 - copy these files over the same paths in your project.

DELETE these old files:
  frontend/src/pages/Help/UserManual.jsx            (now UserGuide.jsx)
  frontend/public/docs/EduTrack_User_Manual.pdf     (now EduTrack_User_Guide.pdf)
  frontend/public/icon-maskable-512.png             (the installed app icon has no background now)

BACKEND
 1. npm install                 (nothing new this time, but harmless)
 2. npm run db:migrate          (two migrations: system sender IDs, invoice number sequence)
 3. Restart.
 4. Settings -> Messages (platform developer only): fill in "System Sender ID" for SMS and
    "System From Email / Name" for email. Until you do, system messages use the school's sender.

NEW PRODUCTION DATABASE
    npm run db:migrate
    SEED_SCHOOL_NAME=... SEED_ADMIN_EMAIL=... SEED_ADMIN_PASSWORD=... npm run seed:production
    (see DEPLOYMENT.md, "Setting up a new production database")
    npm run seed:dev  (or npm run seed)  = the demo school, development only.
    The demo seed and db:empty now refuse to run when NODE_ENV=production.

FRONTEND
 5. Rebuild. Browsers may keep the old tab icon for a while; hard-refresh, or remove and re-add the bookmark.
    An already-installed app keeps its old icon until it is reinstalled.
