import express from 'express';
import { body, validationResult } from 'express-validator';
const app = express();
app.use(express.json());
const DAYS = ['monday','tuesday','wednesday','thursday','friday'];
app.put('/entry', [ body('day').isIn(DAYS).withMessage('Invalid day') ], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  res.json({ ok: true });
});
app.listen(5999, () => console.log('up'));
