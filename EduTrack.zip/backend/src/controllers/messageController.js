import { familyContactsFor } from '../utils/familyContacts.js';
import { notifyEvent } from '../services/notificationService.js';
import { Op } from 'sequelize';
import {
  MessageTemplate, Message, MessageRecipient, Contact, ContactGroup,
  SmsBalance, SmsTransaction, SmsGatewaySettings, EmailGatewaySettings, User, Student,
} from '../models/index.js';
import { resolveGroupContacts } from './contactController.js';
import { can } from '../utils/permissionEngine.js';
import {
  sendSmsViaGateway, sendManyViaMeseji, getMesejiBalance, getMesejiBatchStats,
  sendManyViaNextSms, getNextSmsBalance, getNextSmsDeliveryReport, normalizeTzPhone,
  sendManyViaSwalaSms, getSwalaBalance, getSwalaDeliveryReport,
} from '../services/smsService.js';
import { sendEmail } from '../services/emailService.js';
import { applyRecipientUpdate } from './webhookController.js';
import { moneyFormatterFor } from '../utils/tenantDisplay.js';

const ADMIN_TIER_ROLES = ['super_admin', 'admin', 'principal'];

/** Anyone in an admin-tier role can always send. Everyone else needs
 * the 'send_messages' permission — granted either at the role level
 * (Settings → Permissions → Role Permissions, the primary mechanism) or
 * as an individual override on their own account (secondary, on top of
 * whatever their role already grants). */
export const canSendMessages = async (user, tenantId) => can(user, tenantId, 'send_messages');

const requireSendPermission = async (req, res) => {
  if (!(await canSendMessages(req.user, req.tenantId))) {
    res.status(403).json({ success: false, message: 'You do not have permission to send messages. Ask an administrator to grant it.' });
    return false;
  }
  return true;
};

/** Fills {{placeholders}} in a template/body with values from a context object. */
const applyPlaceholders = (text, context = {}) =>
  text.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, key) => (context[key] !== undefined ? String(context[key]) : `{{${key}}}`));

// ═══════════════════════════════════════════════════════════════════════════
// TEMPLATES
// ═══════════════════════════════════════════════════════════════════════════

export const getTemplates = async (req, res, next) => {
  try {
    const { category = '', channel = '', status = '' } = req.query;
    const where = { tenant_id: req.tenantId };
    if (category) where.category = category;
    if (channel) where.channel = channel;
    if (status) where.status = status;
    const templates = await MessageTemplate.findAll({ where, order: [['name', 'ASC']] });
    res.json({ success: true, data: templates });
  } catch (error) { next(error); }
};

export const createTemplate = async (req, res, next) => {
  try {
    const { name, category, channel, subject, body } = req.body;
    if (!name || !body) return res.status(400).json({ success: false, message: 'name and body are required' });
    const template = await MessageTemplate.create({
      tenant_id: req.tenantId, name, category: category || 'general', channel: channel || 'sms',
      subject: subject || null, body, created_by: req.user.id,
    });
    res.status(201).json({ success: true, message: 'Template created', data: template });
  } catch (error) { next(error); }
};

export const updateTemplate = async (req, res, next) => {
  try {
    const template = await MessageTemplate.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!template) return res.status(404).json({ success: false, message: 'Template not found' });
    const { name, category, channel, subject, body, status } = req.body;
    await template.update({
      ...(name !== undefined && { name }),
      ...(category !== undefined && { category }),
      ...(channel !== undefined && { channel }),
      ...(subject !== undefined && { subject }),
      ...(body !== undefined && { body }),
      ...(status !== undefined && { status }),
    });
    res.json({ success: true, message: 'Template updated', data: template });
  } catch (error) { next(error); }
};

export const deleteTemplate = async (req, res, next) => {
  try {
    const template = await MessageTemplate.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!template) return res.status(404).json({ success: false, message: 'Template not found' });
    await template.destroy();
    res.json({ success: true, message: 'Template deleted' });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// RECIPIENT RESOLUTION (shared by preview + actual send)
// ═══════════════════════════════════════════════════════════════════════════

async function resolveRecipients(tenantId, { recipient_type, target_id, role, custom_numbers, contact_ids, student_ids, student_balances, channel }) {
  // {{balance}} in a fee reminder follows the school's Money Decimals setting.
  const fmtMoney = await moneyFormatterFor(tenantId);
  if (recipient_type === 'individual') {
    if (!target_id) return [];
    const contact = await Contact.findOne({ where: { id: target_id, tenant_id: tenantId } });
    return contact ? [contact] : [];
  }
  if (recipient_type === 'group' || recipient_type === 'subgroup') {
    if (!target_id) return [];
    const group = await ContactGroup.findOne({ where: { id: target_id, tenant_id: tenantId } });
    if (!group) return [];
    return resolveGroupContacts(tenantId, group);
  }
  if (recipient_type === 'role_broadcast') {
    if (!role) return [];
    return Contact.findAll({ where: { tenant_id: tenantId, type: role, status: 'active' } });
  }
  if (recipient_type === 'custom_numbers') {
    return (custom_numbers || []).map((n) => ({ id: null, name: n, phone: n, email: null }));
  }
  if (recipient_type === 'selected_contacts') {
    // Contacts ticked by hand in Compose. Scoped to the tenant (ids from the
    // client are never trusted on their own) and to active contacts, the same
    // as an "Everyone of a Type" broadcast — a contact deactivated after a
    // draft was saved is skipped rather than texted.
    // Only well-formed UUIDs reach the query — a malformed id would make Postgres
    // throw (invalid input syntax for type uuid) and turn a bad request into a 500.
    const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const ids = [...new Set(Array.isArray(contact_ids) ? contact_ids.filter((id) => typeof id === 'string' && UUID_RE.test(id)) : [])];
    if (ids.length === 0) return [];
    return Contact.findAll({ where: { id: ids, tenant_id: tenantId, status: 'active' }, order: [['name', 'ASC']] });
  }
  if (recipient_type === 'student_parents') {
    // Used by Fee Status → "Send Reminder": one recipient entry per STUDENT (not per parent), so a parent with two children on the
    // list gets two personalised texts, each naming the right child and their own balance ({{student_name}} / {{balance}}).
    // `student_balances` (studentId → amount owed) comes from the caller: Fee Status already computed them.
    //
    // Who is reached is decided by utils/familyContacts.js: the parent's own account first, then the parent details typed on the
    // admission form. (This used to need a messaging Contact tied to the parent's login — which admissions never created — so
    // students with a perfectly good parent number were silently skipped.) A student with no usable parent contact is NOT dropped
    // silently: the reason is returned in `recipients.skipped`, and the caller tells the user who was left out.
    if (!student_ids || student_ids.length === 0) return Object.assign([], { skipped: [] });
    const families = await familyContactsFor(tenantId, student_ids);
    const wantEmail = channel === 'email';
    const contacts = await Contact.findAll({ where: { tenant_id: tenantId, status: 'active' }, attributes: ['id', 'phone', 'email', 'linked_user_id'] });
    const contactByUser = new Map(contacts.filter((c) => c.linked_user_id).map((c) => [c.linked_user_id, c]));
    const contactByPhone = new Map(contacts.filter((c) => c.phone).map((c) => [normalizeTzPhone(c.phone), c]));

    const recipients = []; const skipped = [];
    for (const id of student_ids) {
      const f = families.get(id);
      if (!f) { skipped.push({ student_id: id, student_name: null, reason: 'student not found' }); continue; }
      const reach = wantEmail ? f.email : f.phone;
      if (!reach) { skipped.push({ student_id: id, student_name: f.studentName, reason: wantEmail ? 'no parent email on file' : 'no parent phone number on file' }); continue; }
      const contact = (f.userId && contactByUser.get(f.userId)) || (f.phone && contactByPhone.get(normalizeTzPhone(f.phone))) || null;
      const balance = student_balances && student_balances[id] !== undefined ? Number(student_balances[id]) : null;
      recipients.push({
        id: contact?.id || null, name: f.name, phone: f.phone, email: f.email || contact?.email || null,
        student_name: f.studentName, balance: balance !== null ? fmtMoney(balance) : '', parent_user_id: f.userId,
      });
    }
    return Object.assign(recipients, { skipped });
  }
  return [];
}

/** POST /messages/preview-recipients — resolves a target into the actual
 * contact list + count before sending, so the compose screen can show
 * "This will reach 24 people" before the admin commits. */
export const previewRecipients = async (req, res, next) => {
  try {
    const contacts = await resolveRecipients(req.tenantId, req.body);
    res.json({
      success: true,
      data: {
        count: contacts.length,
        contacts: contacts.slice(0, 50).map((c) => ({ id: c.id, name: c.name, phone: c.phone, email: c.email })),
        truncated: contacts.length > 50,
        skipped: contacts.skipped || [],
      },
    });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// MESSAGES — draft, send, history
// ═══════════════════════════════════════════════════════════════════════════

export const getMessages = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, status = '', channel = '', search = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (status) where.status = status;
    if (channel) where.channel = channel;
    if (search) where.body = { [Op.iLike]: `%${search}%` };

    const { count, rows } = await Message.findAndCountAll({
      where,
      include: [{ model: User, as: 'sender', attributes: ['id', 'first_name', 'last_name'] }],
      limit: parseInt(limit), offset: parseInt(offset),
      order: [['created_at', 'DESC']],
      distinct: true,
    });

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

/**
 * NextSMS: every recipient has its OWN message id, so unlike a Meseji batch
 * each one can be checked and marked individually.
 *
 * Only recipients still waiting on a final answer (sent / pending) are asked
 * about — delivered and failed are final — and at most CHECK_LIMIT per call,
 * five at a time, so opening a big broadcast can't turn into hundreds of
 * requests. The delivery-report webhook (webhookController.js) normally gets
 * there first; this is the fallback for when it can't reach the server.
 */
const NEXTSMS_CHECK_LIMIT = 200;
const syncPerRecipientDelivery = async (settings, message, { getReport, label }) => {
  const open = await MessageRecipient.findAll({
    where: { message_id: message.id, status: { [Op.in]: ['sent', 'pending'] } },
    limit: NEXTSMS_CHECK_LIMIT,
  });

  // What this check did — returned to the caller and logged, so "status never
  // changes" can be traced to a reason instead of guessed at.
  const check = { checked: 0, delivered: 0, failed: 0, still_pending: 0, no_report: 0, no_message_id: 0, errors: [] };

  // Phase 1 — ask the provider, five recipients at a time.
  const answers = [];
  for (let i = 0; i < open.length; i += 5) {
    await Promise.all(open.slice(i, i + 5).map(async (recipient) => {
      if (!recipient.provider_message_id) { check.no_message_id += 1; return; }
      check.checked += 1;
      try {
        const report = await getReport(settings, recipient.provider_message_id);
        if (!report) { check.no_report += 1; return; }
        if (report.status === 'pending') { check.still_pending += 1; return; }
        answers.push({ recipient, report });
      } catch (err) {
        if (!check.errors.includes(err.message)) check.errors.push(err.message);
      }
    }));
  }

  // Phase 2 — record the final answers, one at a time. Each failure also
  // adjusts the message's own failed/sent counts (so the "Retry Failed"
  // button and the Failed figure are right), and doing that in parallel would
  // have the updates overwrite each other.
  for (const { recipient, report } of answers) {
    if (report.status === 'delivered') {
      check.delivered += 1;
      await applyRecipientUpdate(recipient, 'delivered');
      if (report.doneAt) await recipient.update({ delivered_at: new Date(report.doneAt) });
    } else {
      check.failed += 1;
      await applyRecipientUpdate(recipient, 'failed', report.error || report.detail || 'Provider reported delivery failure');
    }
  }

  const [delivered, providerFailed] = await Promise.all([
    MessageRecipient.count({ where: { message_id: message.id, status: 'delivered' } }),
    // Failed AFTER the provider accepted it (it has a message id) — as opposed
    // to a rejection at send time.
    MessageRecipient.count({ where: { message_id: message.id, status: 'failed', provider_message_id: { [Op.ne]: null } } }),
  ]);
  await message.update({ delivered_count: delivered, provider_failed_count: providerFailed, delivery_checked_at: new Date() });

  console.log(`[sms:${label}] delivery check for message ${message.id}:`, JSON.stringify(check));
  message.deliveryCheck = check; // read by refreshMessageDelivery, not stored
  return message;
};
const syncNextSmsDelivery = (settings, message) => syncPerRecipientDelivery(settings, message, { getReport: getNextSmsDeliveryReport, label: 'nextsms' });
const syncSwalaSmsDelivery = (settings, message) => syncPerRecipientDelivery(settings, message, { getReport: getSwalaDeliveryReport, label: 'swalasms' });

/**
 * Pulls the real delivery outcome for a message back from the provider.
 *
 * Meseji's /sms/stats/:batch_id returns AGGREGATE figures for a batch
 * (total_sent / successful / failed) — not a per-recipient breakdown. So:
 *
 *   - all successful  → every recipient in that batch really was delivered
 *   - all failed      → every recipient failed
 *   - mixed           → the counts are recorded, but individual recipients
 *                       are left as "sent", because marking any particular
 *                       one delivered would be inventing information the
 *                       provider never gave us.
 *
 * Never throws: a failed delivery check must not break viewing a message.
 */
export const syncMessageDelivery = async (tenantId, message) => {
  try {
    // `deliveryCheck` is only ever read by the Refresh Delivery button, which
    // shows it. Every early exit below says why nothing was checked — silence
    // here used to look exactly like "checked, nothing changed".
    if (message.channel !== 'sms') {
      message.deliveryCheck = { skipped: 'Only SMS messages have delivery tracking.' };
      return message;
    }

    const settings = await SmsGatewaySettings.findOne({ where: { tenant_id: tenantId } });
    if (settings?.is_active && settings.provider === 'nextsms') return await syncNextSmsDelivery(settings, message);
    if (settings?.is_active && settings.provider === 'swalasms') return await syncSwalaSmsDelivery(settings, message);
    if (!settings?.is_active || settings.provider !== 'meseji') {
      message.deliveryCheck = {
        skipped: !settings?.is_active
          ? 'The SMS gateway is not active (Settings → Messages), so there is no provider to ask about delivery.'
          : `Delivery for ${settings.provider} is reported by the provider's webhook only — it can't be checked on demand.`,
      };
      return message;
    }

    // Every recipient of a batch shares its batch id.
    const recipients = await MessageRecipient.findAll({ where: { message_id: message.id } });
    const batchIds = [...new Set(recipients.map((r) => r.provider_message_id).filter(Boolean))];
    if (batchIds.length === 0) return message;

    let delivered = 0;
    let failed = 0;

    for (const batchId of batchIds) {
      const stats = await getMesejiBatchStats(settings, batchId);
      console.log(`[sms] batch ${batchId} stats:`, stats); // Debugging line
      const successful = Number(stats.delivered ?? 0);
      const batchFailed = Number(stats.failed ?? 0);
      const totalSent = Number(stats.total ?? successful + batchFailed);

      delivered += successful;
      failed += batchFailed;

      const batchRecipients = recipients.filter((r) => r.provider_message_id === batchId);

      if (totalSent > 0 && successful === totalSent) {
        await MessageRecipient.update(
          { status: 'delivered', delivered_at: new Date() },
          { where: { message_id: message.id, provider_message_id: batchId } },
        );
      } else if (totalSent > 0 && batchFailed === totalSent) {
        await MessageRecipient.update(
          { status: 'failed', error_message: 'Provider reported delivery failure' },
          { where: { message_id: message.id, provider_message_id: batchId } },
        );
      }
      void batchRecipients;
    }

    await message.update({
      delivered_count: delivered,
      provider_failed_count: failed,
      delivery_checked_at: new Date(),
    });

    return message;
  } catch (err) {
    console.warn('[sms] delivery sync failed:', err.message);
    message.deliveryCheck = { errors: [err.message] };
    return message;
  }
};

/** POST /messages/:id/refresh-delivery — re-checks delivery on demand. */
export const refreshMessageDelivery = async (req, res, next) => {
  try {
    const message = await Message.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!message) return res.status(404).json({ success: false, message: 'Message not found' });

    const synced = await syncMessageDelivery(req.tenantId, message);
    const delivery_check = synced?.deliveryCheck || null; // NextSMS only
    await message.reload();

    res.json({ success: true, message: 'Delivery status refreshed', data: message, ...(delivery_check && { delivery_check }) });
  } catch (error) { next(error); }
};

export const getMessageById = async (req, res, next) => {
  try {
    const message = await Message.findOne({
      where: { id: req.params.id, tenant_id: req.tenantId },
      include: [
        { model: User, as: 'sender', attributes: ['id', 'first_name', 'last_name'] },
        { model: MessageTemplate, as: 'template', attributes: ['id', 'name'] },
      ],
    });
    if (!message) return res.status(404).json({ success: false, message: 'Message not found' });

    // Refresh on open when the last check is older than two minutes. A
    // recipient list showing "pending" long after delivery is the single
    // most misleading thing this page can do.
    //
    // NextSMS reports a message within seconds and gives each recipient a
    // report of their own, so it is re-checked far more often than the
    // two minutes that suit Meseji's batch statistics.
    const gateway = message.channel === 'sms' ? await SmsGatewaySettings.findOne({ where: { tenant_id: req.tenantId } }) : null;
    // NextSMS and SwalaSMS report each recipient separately, within seconds.
    const nextSmsLive = Boolean(gateway?.is_active && ['nextsms', 'swalasms'].includes(gateway?.provider));
    const STALE_MS = nextSmsLive ? 15 * 1000 : 2 * 60 * 1000;
    const stale = !message.delivery_checked_at || (Date.now() - new Date(message.delivery_checked_at).getTime()) > STALE_MS;
    if (message.channel === 'sms' && message.status !== 'draft' && stale) {
      await syncMessageDelivery(req.tenantId, message);
      await message.reload();
    }

    // Tells the page whether recipients are still waiting on a final answer,
    // so it knows to keep checking until they arrive.
    let delivery_polling = false;
    if (nextSmsLive) {
      delivery_polling = (await MessageRecipient.count({ where: { message_id: message.id, status: { [Op.in]: ['sent', 'pending'] } } })) > 0;
    }

    res.json({ success: true, data: { ...message.toJSON(), delivery_polling, delivery_provider: nextSmsLive ? gateway.provider : null } });
  } catch (error) { next(error); }
};

/** GET /messages/:id/recipients — paginated, since a broadcast can have
 * hundreds/thousands of recipients that shouldn't all load into one table. */
export const getMessageRecipients = async (req, res, next) => {
  try {
    const message = await Message.findOne({ where: { id: req.params.id, tenant_id: req.tenantId }, attributes: ['id'] });
    if (!message) return res.status(404).json({ success: false, message: 'Message not found' });

    const { page = 1, limit = 20, status = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = { message_id: message.id };
    if (status) where.status = status;

    const { count, rows } = await MessageRecipient.findAndCountAll({
      where,
      include: [{ model: Contact, as: 'contact', attributes: ['id', 'name', 'type'] }],
      limit: parseInt(limit), offset: parseInt(offset),
      order: [['name_snapshot', 'ASC']],
    });

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

export const saveDraft = async (req, res, next) => {
  try {
    if (!(await requireSendPermission(req, res))) return;
    const { draft_id, campus_id, channel, subject, body, template_id, recipient_type, target_id, role, custom_numbers, contact_ids } = req.body;
    if (!body) return res.status(400).json({ success: false, message: 'body is required' });

    const payload = {
      campus_id: campus_id || null, sender_id: req.user.id,
      channel: channel || 'sms', subject: subject || null, body, template_id: template_id || null,
      recipient_type: recipient_type || 'individual',
      recipient_summary: JSON.stringify({ target_id, role, custom_numbers, contact_ids }),
      status: 'draft',
    };

    let draft;
    if (draft_id) {
      draft = await Message.findOne({ where: { id: draft_id, tenant_id: req.tenantId, status: 'draft' } });
      if (!draft) return res.status(404).json({ success: false, message: 'Draft not found' });
      await draft.update(payload);
    } else {
      draft = await Message.create({ tenant_id: req.tenantId, ...payload });
    }
    res.status(201).json({ success: true, message: 'Draft saved', data: draft });
  } catch (error) { next(error); }
};

export const deleteMessage = async (req, res, next) => {
  try {
    const message = await Message.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!message) return res.status(404).json({ success: false, message: 'Message not found' });
    if (message.status !== 'draft') return res.status(400).json({ success: false, message: 'Only drafts can be deleted — sent messages stay in history.' });
    await message.destroy();
    res.json({ success: true, message: 'Draft deleted' });
  } catch (error) { next(error); }
};

/** POST /messages/send — compose-and-send (or send an existing draft via
 * body.draft_id) in one call. Fans out to every resolved recipient,
 * deducts SMS balance per recipient for SMS-channel sends, and records a
 * MessageRecipient row (with delivery status) for each one. */
export const sendMessage = async (req, res, next) => {
  try {
    if (!(await requireSendPermission(req, res))) return;

    const { draft_id, campus_id, channel, subject, body: rawBody, template_id,
      recipient_type, target_id, role, custom_numbers, contact_ids, student_ids, student_balances, scheduled_at } = req.body;

    let message;
    if (draft_id) {
      message = await Message.findOne({ where: { id: draft_id, tenant_id: req.tenantId } });
      if (!message) return res.status(404).json({ success: false, message: 'Draft not found' });
    }

    const body = rawBody ?? message?.body;
    const finalChannel = channel || message?.channel || 'sms';
    if (!body) return res.status(400).json({ success: false, message: 'body is required' });

    const contacts = await resolveRecipients(req.tenantId, { recipient_type: recipient_type || message?.recipient_type, target_id, role, custom_numbers, contact_ids, student_ids, student_balances, channel: channel || message?.channel || 'sms' });
    const skippedStudents = contacts.skipped || [];
    if (contacts.length === 0) {
      if (skippedStudents.length > 0) {
        const names = skippedStudents.slice(0, 5).map((x) => x.student_name || 'a student').join(', ');
        const why = [...new Set(skippedStudents.map((x) => x.reason))].join(' / ');
        return res.status(400).json({
          success: false,
          message: `None of the ${skippedStudents.length} selected student(s) can be reached: ${why} (${names}${skippedStudents.length > 5 ? ', …' : ''}). Add the parent's contact on the student's record, then try again.`,
          data: { skipped_students: skippedStudents },
        });
      }
      return res.status(400).json({ success: false, message: 'No recipients matched your selection. Check the group/contact you picked.' });
    }

    // Loaded before the balance check, which needs to know whether a real
    // gateway is active before deciding which balance is authoritative.
    const gatewaySettings = finalChannel === 'sms' ? await SmsGatewaySettings.findOne({ where: { tenant_id: req.tenantId } }) : null;

    // ── Balance check ───────────────────────────────────────────────────
    // Two balances exist and only one of them is real:
    //   - the internal `sms_balances` counter, which an admin tops up by
    //     hand and which starts at 0
    //   - the credits actually held at the provider
    // Blocking on the internal counter meant a school with a funded Meseji
    // account was refused a send it could well afford. When a real gateway
    // is active, the provider's balance is authoritative and the internal
    // counter is kept only as a local usage log.
    let smsBalance = null;
    if (finalChannel === 'sms') {
      smsBalance = await SmsBalance.findOne({ where: { tenant_id: req.tenantId } });
      const costPerSms = Number(smsBalance?.cost_per_sms ?? 1);
      const totalCost = costPerSms * contacts.length;

      const usingLiveGateway = gatewaySettings?.is_active && gatewaySettings?.provider === 'meseji';
      const usingNextSms = gatewaySettings?.is_active && gatewaySettings?.provider === 'nextsms';
      const usingSwalaSms = gatewaySettings?.is_active && gatewaySettings?.provider === 'swalasms';

      if (usingLiveGateway) {
        try {
          // getMesejiBalance hands back Meseji's whole stats body, not a
          // number — so comparing it to a count (as this used to) was always
          // false and the check never blocked anything. The credit figure
          // sits at summary.balance.
          const statsBody = await getMesejiBalance(gatewaySettings);
          const rawCredits = statsBody?.summary?.balance ?? statsBody?.balance;
          // An empty value must not turn into 0 and block a send.
          const credits = (rawCredits === undefined || rawCredits === null || rawCredits === '') ? NaN : Number(rawCredits);
          const providerBalance = Number.isFinite(credits) ? credits : null;
          // null means the balance couldn't be read, not that it's empty.
          // Blocking on an unknown balance would refuse sends from a funded
          // account — Meseji itself returns 402 if the credits really are
          // short, so an unreadable balance is safe to send through.
          if (providerBalance !== null && providerBalance < contacts.length) {
            return res.status(400).json({
              success: false,
              message: `Not enough SMS credits at Meseji. This send needs ${contacts.length} but your account has ${providerBalance}. Top up at meseji.co.tz.`,
            });
          }
        } catch (err) {
          // Couldn't read the provider balance — don't block the send over
          // a failed balance lookup. Meseji will refuse it anyway if the
          // credits genuinely aren't there.
          console.warn('[sms] could not read provider balance, sending anyway:', err.message);
        }
      } else if (usingNextSms) {
        // Same reasoning as Meseji: the credits held at NextSMS are the real
        // balance, not the local counter (which starts at 0 and would refuse a
        // funded account). A message can take more than one credit if it is
        // long, so this checks for the minimum — one per recipient — and lets
        // NextSMS refuse anything it truly can't cover.
        try {
          const credits = await getNextSmsBalance(gatewaySettings);
          if (credits !== null && credits < contacts.length) {
            return res.status(400).json({
              success: false,
              message: `Not enough SMS credits at NextSMS. This send needs at least ${contacts.length} but your account has ${credits}. Top up at nextsms.co.tz.`,
            });
          }
        } catch (err) {
          console.warn('[sms] could not read NextSMS balance, sending anyway:', err.message);
        }
      } else if (usingSwalaSms) {
        // Same reasoning as NextSMS: the credits held at SwalaSMS are the real balance. One credit per recipient is the
        // minimum (a long message costs more); SwalaSMS itself refuses, naming the units needed, if it truly can't cover it.
        try {
          const credits = await getSwalaBalance(gatewaySettings);
          if (credits !== null && credits < contacts.length) {
            return res.status(400).json({
              success: false,
              message: `Not enough SMS credits at SwalaSMS. This send needs at least ${contacts.length} but your account has ${credits}. Top up in Messages → SMS Balance or at swalasms.com.`,
            });
          }
        } catch (err) {
          console.warn('[sms] could not read SwalaSMS balance, sending anyway:', err.message);
        }
      } else if (!smsBalance || Number(smsBalance.balance) < totalCost) {
        return res.status(400).json({
          success: false,
          message: `Not enough SMS balance. This send needs ${totalCost} credit(s) but only ${Number(smsBalance?.balance ?? 0)} are available. Top up in Messages → SMS Balance.`,
        });
      }
    }

    if (message) {
      await message.update({
        campus_id: campus_id || message.campus_id, channel: finalChannel, subject: subject ?? message.subject,
        body, template_id: template_id ?? message.template_id, recipient_type: recipient_type || message.recipient_type,
        status: 'sending', total_recipients: contacts.length,
        recipient_summary: `${contacts.length} recipient(s)`,
        scheduled_at: scheduled_at || null,
      });
    } else {
      message = await Message.create({
        tenant_id: req.tenantId, campus_id: campus_id || null, sender_id: req.user.id,
        channel: finalChannel, subject: subject || null, body, template_id: template_id || null,
        recipient_type: recipient_type || 'individual', recipient_summary: `${contacts.length} recipient(s)`,
        status: 'sending', total_recipients: contacts.length, scheduled_at: scheduled_at || null,
      });
    }

    const emailGatewaySettings = finalChannel === 'email' ? await EmailGatewaySettings.findOne({ where: { tenant_id: req.tenantId } }) : null;

    let sentCount = 0, failedCount = 0, totalCost = 0;
    const costPerSms = Number(smsBalance?.cost_per_sms ?? 1);

    // ── SMS: batched by message text ────────────────────────────────────
    // Meseji's /sms/send takes many recipients in one call and bills them
    // as a single batch. Pushing 200 parents through 200 separate HTTP
    // requests would be slow, would risk the rate limiter, and would leave
    // 200 unrelated batch ids instead of one trackable batch.
    //
    // Recipients are grouped by their FINAL message text, because a body
    // containing {{name}} produces a different message per person and
    // those genuinely cannot share a batch.
    const canBatchSms = finalChannel === 'sms'
      && gatewaySettings?.is_active
      && gatewaySettings?.provider === 'meseji';

    const canBatchNextSms = finalChannel === 'sms'
      && gatewaySettings?.is_active
      && gatewaySettings?.provider === 'nextsms';

    const canBatchSwala = finalChannel === 'sms'
      && gatewaySettings?.is_active
      && gatewaySettings?.provider === 'swalasms';

    const personalizedFor = (contact) =>
      applyPlaceholders(body, { name: contact.name, student_name: contact.student_name, balance: contact.balance });

    // 'sent' = accepted immediately (simulated, or email, which has no
    // separate delivery-confirmation step here). 'pending' = a real SMS
    // gateway accepted the request, but delivery to the handset isn't
    // confirmed yet — that arrives later via a delivery-report webhook
    // (see webhookController.js). 'failed' = rejected or errored.
    const recipientRows = [];

    if (canBatchSwala) {
      // SwalaSMS takes up to 1000 numbers per request and answers with a message_uid for EACH one, so every recipient
      // keeps its own id (what status checks and delivery webhooks are matched on) and a refused number never fails the rest.
      const groups = new Map(); // message text → contacts
      for (const contact of contacts) {
        if (!contact.phone) {
          failedCount++;
          recipientRows.push({ contact, status: 'failed', errorMessage: 'No phone number on file', providerMessageId: null });
          continue;
        }
        const text = personalizedFor(contact);
        if (!groups.has(text)) groups.set(text, []);
        groups.get(text).push(contact);
      }

      for (const [text, groupContacts] of groups) {
        try {
          const { results } = await sendManyViaSwalaSms(gatewaySettings, { recipients: groupContacts.map((c) => c.phone), message: text, campaignName: subject || undefined });
          const byPhone = new Map(results.map((r) => [r.to, r]));
          // Two contacts sharing one number (siblings with one parent) get one SMS between them, charged once.
          const charged = new Set();
          groupContacts.forEach((contact) => {
            const phoneKey = normalizeTzPhone(contact.phone);
            const r = byPhone.get(phoneKey);
            if (r && r.status !== 'failed') {
              sentCount++;
              if (!charged.has(phoneKey)) { charged.add(phoneKey); totalCost += costPerSms * (r.smsCount || 1); }
              recipientRows.push({ contact, status: 'pending', errorMessage: null, providerMessageId: r.messageId });
            } else {
              failedCount++;
              recipientRows.push({ contact, status: 'failed', errorMessage: r?.error || 'SwalaSMS returned no result for this number', providerMessageId: null });
            }
          });
        } catch (err) {
          failedCount += groupContacts.length;
          groupContacts.forEach((contact) => {
            recipientRows.push({ contact, status: 'failed', errorMessage: err.message, providerMessageId: null });
          });
        }
      }
    } else if (canBatchNextSms) {
      // NextSMS takes many numbers per call but hands back a result and a
      // message id for EACH one, so every recipient keeps its own id (which is
      // what delivery reports are matched on) and one refused number doesn't
      // fail the rest.
      const groups = new Map(); // message text → contacts
      for (const contact of contacts) {
        if (!contact.phone) {
          failedCount++;
          recipientRows.push({ contact, status: 'failed', errorMessage: 'No phone number on file', providerMessageId: null });
          continue;
        }
        const text = personalizedFor(contact);
        if (!groups.has(text)) groups.set(text, []);
        groups.get(text).push(contact);
      }

      for (const [text, groupContacts] of groups) {
        try {
          const { results } = await sendManyViaNextSms(gatewaySettings, { recipients: groupContacts.map((c) => c.phone), message: text });
          const byPhone = new Map(results.map((r) => [r.to, r]));
          // Two contacts sharing one number (siblings with the same parent)
          // get one SMS between them, so it is only charged once.
          const charged = new Set();
          groupContacts.forEach((contact) => {
            const phoneKey = normalizeTzPhone(contact.phone);
            const r = byPhone.get(phoneKey);
            if (r && r.status !== 'failed') {
              sentCount++;
              if (!charged.has(phoneKey)) { charged.add(phoneKey); totalCost += costPerSms * (r.smsCount || 1); }
              recipientRows.push({ contact, status: 'pending', errorMessage: null, providerMessageId: r.messageId });
            } else {
              failedCount++;
              recipientRows.push({ contact, status: 'failed', errorMessage: r?.error || 'NextSMS returned no result for this number', providerMessageId: null });
            }
          });
        } catch (err) {
          failedCount += groupContacts.length;
          groupContacts.forEach((contact) => {
            recipientRows.push({ contact, status: 'failed', errorMessage: err.message, providerMessageId: null });
          });
        }
      }
    } else if (canBatchSms) {
      const groups = new Map(); // message text → contacts
      const missingPhone = [];

      for (const contact of contacts) {
        if (!contact.phone) { missingPhone.push(contact); continue; }
        const text = personalizedFor(contact);
        if (!groups.has(text)) groups.set(text, []);
        groups.get(text).push(contact);
      }

      missingPhone.forEach((contact) => {
        failedCount++;
        recipientRows.push({ contact, status: 'failed', errorMessage: 'No phone number on file', providerMessageId: null });
      });

      for (const [text, groupContacts] of groups) {
        try {
          const result = await sendManyViaMeseji(gatewaySettings, {
            recipients: groupContacts.map((c) => c.phone),
            message: text,
          });
          totalCost += costPerSms * groupContacts.length;
          sentCount += groupContacts.length;
          // Every recipient in the batch shares the batch id, which is what
          // /sms/stats/:batch_id is keyed on.
          groupContacts.forEach((contact) => {
            recipientRows.push({ contact, status: 'pending', errorMessage: null, providerMessageId: result.batchId });
          });
        } catch (err) {
          failedCount += groupContacts.length;
          groupContacts.forEach((contact) => {
            recipientRows.push({ contact, status: 'failed', errorMessage: err.message, providerMessageId: null });
          });
        }
      }
    } else {
      for (const contact of contacts) {
        const personalizedBody = personalizedFor(contact);
        let recipientStatus = 'sent', errorMessage = null, providerMessageId = null;

        try {
          if (finalChannel === 'sms') {
            if (!contact.phone) throw new Error('No phone number on file');
            const result = await sendSmsViaGateway(gatewaySettings, { to: contact.phone, message: personalizedBody });
            totalCost += costPerSms;
            providerMessageId = result?.messageId || null;
            if (!result?.simulated) recipientStatus = 'pending';
          } else if (finalChannel === 'email') {
            if (!contact.email) throw new Error('No email on file');
            await sendEmail({ to: contact.email, subject: subject || message.subject || 'Message from School', html: `<p>${personalizedBody}</p>` }, emailGatewaySettings);
          }
          sentCount++;
        } catch (err) {
          recipientStatus = 'failed';
          errorMessage = err.message;
          failedCount++;
        }

        recipientRows.push({ contact, status: recipientStatus, errorMessage, providerMessageId });
      }
    }

    await MessageRecipient.bulkCreate(recipientRows.map(({ contact, status, errorMessage, providerMessageId }) => ({
      message_id: message.id, contact_id: contact.id || null,
      name_snapshot: contact.name, phone_snapshot: contact.phone || null, email_snapshot: contact.email || null,
      status, error_message: errorMessage, provider_message_id: providerMessageId,
      sent_at: status !== 'failed' ? new Date() : null,
    })));

    // Deduct actual SMS cost incurred (failed sends aren't charged)
    if (finalChannel === 'sms' && totalCost > 0 && smsBalance) {
      // Never let the local log go negative — with a live gateway it's a
      // usage record, not the authority on what can be spent.
      const newBalance = Math.max(0, Number(smsBalance.balance) - totalCost);
      await smsBalance.update({ balance: newBalance });
      await SmsTransaction.create({
        tenant_id: req.tenantId, type: 'deduction', amount: -totalCost, balance_after: newBalance,
        reference: message.id, description: `Message: "${body.slice(0, 40)}${body.length > 40 ? '…' : ''}"`, created_by: req.user.id,
      });
    }

    await message.update({
      status: failedCount === 0 ? 'sent' : sentCount > 0 ? 'partially_sent' : 'failed',
      sent_at: new Date(), sent_count: sentCount, failed_count: failedCount, cost: totalCost,
    });

    // A fee reminder also leaves an in-app copy for the parent (Settings → Notifications → Outstanding Fee Reminder). The SMS / email
    // itself was just sent above, so that channel is skipped here — no second text for the same reminder.
    if ((recipient_type || message?.recipient_type) === 'student_parents') {
      for (const { contact, status } of recipientRows) {
        if (status === 'failed' || !contact.parent_user_id) continue;
        await notifyEvent(req.tenantId, 'fee_balance_reminder', {
          parties: {
            family: {
              recipientUserId: contact.parent_user_id, skipChannels: [finalChannel],
              title: 'Fee Reminder',
              message: `A fee reminder was sent about ${contact.student_name || 'your child'}${contact.balance ? `. Balance due: ${contact.balance}` : ''}.`,
            },
          },
        });
      }
    }

    res.json({
      success: true,
      message: `Sent to ${sentCount} of ${contacts.length} recipient(s)` + (failedCount > 0 ? ` (${failedCount} failed)` : '')
        + (skippedStudents.length > 0 ? `. ${skippedStudents.length} student(s) were left out — ${[...new Set(skippedStudents.map((x) => x.reason))].join(' / ')}: ${skippedStudents.slice(0, 5).map((x) => x.student_name || 'a student').join(', ')}${skippedStudents.length > 5 ? ', …' : ''}` : ''),
      data: message,
      skipped_students: skippedStudents,
    });
  } catch (error) { next(error); }
};

/** POST /messages/:id/retry — re-attempts sending to just the recipients
 * who failed on the original send (e.g. a temporary gateway hiccup).
 * Recipients who already succeeded (sent/pending/delivered) are left
 * untouched — this only touches 'failed' rows. */
export const retryFailedRecipients = async (req, res, next) => {
  try {
    if (!(await requireSendPermission(req, res))) return;

    const message = await Message.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!message) return res.status(404).json({ success: false, message: 'Message not found' });

    const failedRecipients = await MessageRecipient.findAll({ where: { message_id: message.id, status: 'failed' } });
    if (failedRecipients.length === 0) {
      return res.status(400).json({ success: false, message: 'There are no failed recipients to retry.' });
    }

    const gatewaySettings = message.channel === 'sms' ? await SmsGatewaySettings.findOne({ where: { tenant_id: req.tenantId } }) : null;
    // With a live gateway (Meseji or NextSMS), the credits held at the provider
    // are the real balance, not the local counter — which would refuse a retry
    // the account can afford. The provider itself refuses the send if the
    // credits truly aren't there.
    const liveGateway = Boolean(gatewaySettings?.is_active && ['meseji', 'nextsms', 'swalasms'].includes(gatewaySettings?.provider));

    let smsBalance = null;
    const costPerSms = message.channel === 'sms' ? Number((await SmsBalance.findOne({ where: { tenant_id: req.tenantId } }))?.cost_per_sms ?? 1) : 0;
    if (message.channel === 'sms') {
      smsBalance = await SmsBalance.findOne({ where: { tenant_id: req.tenantId } });
      const totalCost = costPerSms * failedRecipients.length;
      if (!liveGateway && (!smsBalance || Number(smsBalance.balance) < totalCost)) {
        return res.status(400).json({ success: false, message: `Not enough SMS balance to retry — needs ${totalCost} credit(s).` });
      }
    }

    const emailGatewaySettings = message.channel === 'email' ? await EmailGatewaySettings.findOne({ where: { tenant_id: req.tenantId } }) : null;

    let recovered = 0, stillFailed = 0, totalCost = 0;
    for (const recipient of failedRecipients) {
      const personalizedBody = applyPlaceholders(message.body, { name: recipient.name_snapshot });
      let status = 'sent', errorMessage = null, providerMessageId = null;

      try {
        if (message.channel === 'sms') {
          if (!recipient.phone_snapshot) throw new Error('No phone number on file');
          const result = await sendSmsViaGateway(gatewaySettings, { to: recipient.phone_snapshot, message: personalizedBody });
          totalCost += costPerSms;
          providerMessageId = result?.messageId || null;
          if (!result?.simulated) status = 'pending';
        } else if (message.channel === 'email') {
          if (!recipient.email_snapshot) throw new Error('No email on file');
          await sendEmail({ to: recipient.email_snapshot, subject: message.subject || 'Message from School', html: `<p>${personalizedBody}</p>` }, emailGatewaySettings);
        }
        recovered++;
      } catch (err) {
        status = 'failed';
        errorMessage = err.message;
        stillFailed++;
      }

      await recipient.update({ status, error_message: errorMessage, provider_message_id: providerMessageId, sent_at: status !== 'failed' ? new Date() : recipient.sent_at });
    }

    if (totalCost > 0 && smsBalance) {
      // With a live gateway this is only a usage log, so it never goes negative.
      const newBalance = liveGateway ? Math.max(0, Number(smsBalance.balance) - totalCost) : Number(smsBalance.balance) - totalCost;
      await smsBalance.update({ balance: newBalance });
      await SmsTransaction.create({
        tenant_id: req.tenantId, type: 'deduction', amount: -totalCost, balance_after: newBalance,
        reference: message.id, description: 'Retry failed recipients', created_by: req.user.id,
      });
    }

    await message.update({
      sent_count: message.sent_count + recovered,
      failed_count: message.failed_count - recovered,
      status: message.failed_count - recovered <= 0 ? 'sent' : 'partially_sent',
    });

    res.json({ success: true, message: `Recovered ${recovered} of ${failedRecipients.length} — ${stillFailed} still failed`, data: message });
  } catch (error) { next(error); }
};
