import crypto from 'crypto';
import { Op } from 'sequelize';
import sequelize from '../config/database.js';
import {
  SubscriptionPlan, SubscriptionAddOn, Subscription, SubscriptionInvoice,
  Student, Tenant, Campus,
} from '../models/index.js';
import { bypassesSubscription } from '../utils/developerAccess.js';
import { moneyFormatterFor } from '../utils/tenantDisplay.js';
import { loadInvoiceDocumentData } from '../services/subscriptionDocuments.js';
import {
  generateSubscriptionReceiptCode, isValidSubscriptionReceiptCode, isValidSubscriptionPayCode,
} from '../utils/receiptSecurity.js';
import { normalizePhone } from '../utils/phone.js';
import { nextInvoiceNumber } from '../utils/invoiceNumber.js';
import { logSystemEvent } from '../middleware/auditLog.js';
import { emailInvoiceCreated, emailReceipt } from '../services/subscriptionNotifier.js';
import {
  isClickPesaConfigured, testClickPesaConnection, previewPayment,
  initiatePayment, getPaymentStatus, mapPaymentStatus,
} from '../services/clickpesaService.js';

const ADMIN_ROLES = ['super_admin', 'admin', 'principal'];

const CYCLE_DAYS = { monthly: 30, termly: 120, yearly: 365 };
const PRICE_FIELD = { monthly: 'price_monthly', termly: 'price_termly', yearly: 'price_yearly' };

const round2 = (n) => Math.round(Number(n) * 100) / 100;

/** How many students the plan limit is actually measured against. */
const activeStudentCount = (tenantId) =>
  Student.count({ where: { tenant_id: tenantId, status: 'active' } });

/**
 * Works out where a subscription stands RIGHT NOW.
 *
 * Status is derived from dates rather than trusted from the stored column,
 * because nothing runs at midnight to flip it — a subscription that
 * expired overnight would otherwise still read "active" until someone
 * happened to save it.
 */
export const evaluateSubscription = (subscription) => {
  if (!subscription) return { status: 'none', daysLeft: 0, inGrace: false, locked: true };
  if (subscription.status === 'cancelled') return { status: 'cancelled', daysLeft: 0, inGrace: false, locked: true };
  if (!subscription.ends_at) return { status: subscription.status, daysLeft: 0, inGrace: false, locked: subscription.status !== 'trial' };

  const now = Date.now();
  const endsAt = new Date(subscription.ends_at).getTime();
  const graceMs = (subscription.grace_days ?? 2) * 86400000;
  const graceEndsAt = endsAt + graceMs;

  const daysLeft = Math.ceil((endsAt - now) / 86400000);

  if (now <= endsAt) {
    return { status: subscription.status === 'trial' ? 'trial' : 'active', daysLeft, inGrace: false, locked: false, graceEndsAt };
  }
  if (now <= graceEndsAt) {
    return {
      status: 'grace', daysLeft: 0, inGrace: true, locked: false, graceEndsAt,
      graceHoursLeft: Math.ceil((graceEndsAt - now) / 3600000),
    };
  }
  return { status: 'expired', daysLeft: 0, inGrace: false, locked: true, graceEndsAt };
};

/** Fetches (or lazily creates) the tenant's subscription row. */
export const getOrCreateSubscription = async (tenantId) => {
  const [subscription] = await Subscription.findOrCreate({
    where: { tenant_id: tenantId },
    defaults: { tenant_id: tenantId, status: 'trial', grace_days: 2 },
  });
  return subscription;
};

/**
 * Prices a plan + add-ons for a cycle, and works out any proration credit.
 *
 * On an UPGRADE the school has already paid for time they haven't used, so
 * that value is credited against the new plan. Without it, upgrading
 * mid-term would mean paying twice for the same days — which is the
 * quickest way to make sure nobody ever upgrades.
 */
export const priceSubscription = async ({ plan, billingCycle, addonCodes = [], currentSubscription = null }) => {
  const field = PRICE_FIELD[billingCycle];
  if (!field) throw new Error('Invalid billing cycle');

  const lineItems = [{
    label: `${plan.name} plan — ${billingCycle}`,
    amount: round2(plan[field]),
  }];

  let subtotal = round2(plan[field]);

  if (addonCodes.length > 0) {
    const addons = await SubscriptionAddOn.findAll({ where: { code: addonCodes, status: 'active' } });
    addons.forEach((addon) => {
      const price = round2(addon[field]);
      lineItems.push({ label: `${addon.name} (add-on) — ${billingCycle}`, amount: price });
      subtotal = round2(subtotal + price);
    });
  }

  // ── Proration ────────────────────────────────────────────────────────
  let prorationCredit = 0;
  const evaluation = evaluateSubscription(currentSubscription);

  if (currentSubscription && !evaluation.locked && evaluation.daysLeft > 0 && Number(currentSubscription.amount_paid) > 0) {
    const cycleDays = CYCLE_DAYS[currentSubscription.billing_cycle] || 30;
    const unusedRatio = Math.min(1, evaluation.daysLeft / cycleDays);
    prorationCredit = round2(Number(currentSubscription.amount_paid) * unusedRatio);
    // Never credit more than the new purchase is worth — an upgrade
    // shouldn't be able to produce a negative invoice.
    prorationCredit = Math.min(prorationCredit, subtotal);

    if (prorationCredit > 0) {
      lineItems.push({
        label: `Credit for ${evaluation.daysLeft} unused day(s) on your current plan`,
        amount: -prorationCredit,
      });
    }
  }

  return {
    lineItems,
    subtotal,
    prorationCredit,
    total: round2(subtotal - prorationCredit),
  };
};

// ═══════════════════════════════════════════════════════════════════════════
// PLANS
// ═══════════════════════════════════════════════════════════════════════════

/** GET /subscription/plans — public to any signed-in user so an expired
 * school can still see what it needs to buy. */
export const getPlans = async (req, res, next) => {
  try {
    const [plans, addons, studentCount] = await Promise.all([
      SubscriptionPlan.findAll({ where: { status: 'active' }, order: [['tier', 'ASC']] }),
      SubscriptionAddOn.findAll({ where: { status: 'active' }, order: [['name', 'ASC']] }),
      activeStudentCount(req.tenantId),
    ]);

    res.json({
      success: true,
      data: {
        plans: plans.map((p) => ({
          ...p.toJSON(),
          // Flagged here rather than in the UI so the same rule applies to
          // every caller: a plan smaller than the school cannot be bought.
          fits_school: p.student_limit === null || studentCount <= p.student_limit,
        })),
        addons,
        student_count: studentCount,
      },
    });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// CURRENT SUBSCRIPTION
// ═══════════════════════════════════════════════════════════════════════════

export const getMySubscription = async (req, res, next) => {
  try {
    const subscription = await getOrCreateSubscription(req.tenantId);
    const [plan, studentCount] = await Promise.all([
      subscription.plan_id ? SubscriptionPlan.findByPk(subscription.plan_id) : null,
      activeStudentCount(req.tenantId),
    ]);

    const evaluation = evaluateSubscription(subscription);
    const overLimit = plan?.student_limit !== null && plan?.student_limit !== undefined
      ? studentCount > plan.student_limit
      : false;

    res.json({
      success: true,
      data: {
        ...subscription.toJSON(),
        plan,
        evaluation,
        student_count: studentCount,
        over_student_limit: overLimit,
        gateway_configured: isClickPesaConfigured(),
        // False only for the platform developer, who is never locked out. The app
        // locks itself when evaluation.locked AND enforced.
        enforced: !bypassesSubscription(req.user),
      },
    });
  } catch (error) { next(error); }
};

/** POST /subscription/quote — what a given plan/cycle would cost, including
 * any upgrade credit. Lets a school see the price before committing. */
export const getQuote = async (req, res, next) => {
  try {
    const { plan_id, billing_cycle = 'monthly', addons = [] } = req.body;

    const plan = await SubscriptionPlan.findOne({ where: { id: plan_id, status: 'active' } });
    if (!plan) return res.status(404).json({ success: false, message: 'Plan not found' });

    const studentCount = await activeStudentCount(req.tenantId);
    if (plan.student_limit !== null && studentCount > plan.student_limit) {
      return res.status(400).json({
        success: false,
        message: `Your school has ${studentCount} active students, which is more than the ${plan.name} plan allows (${plan.student_limit}). Choose a larger plan.`,
      });
    }

    const subscription = await getOrCreateSubscription(req.tenantId);
    const quote = await priceSubscription({
      plan, billingCycle: billing_cycle, addonCodes: addons, currentSubscription: subscription,
    });

    res.json({ success: true, data: { ...quote, plan, billing_cycle, student_count: studentCount } });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// CHECKOUT
// ═══════════════════════════════════════════════════════════════════════════


/** ClickPesa requires an alphanumeric reference. */
const buildOrderReference = () =>
  `EDU${Date.now()}${Math.random().toString(36).slice(2, 6)}`.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();

/**
 * POST /subscription/checkout — creates an invoice and pushes a payment
 * prompt to the payer's phone.
 *
 * The subscription is NOT extended here. It is extended only when the
 * payment is confirmed (webhook or a status poll), because a USSD prompt
 * that is never approved must not buy anyone a month of service.
 */
export const checkout = async (req, res, next) => {
  try {
    // Online payment needs the gateway. Without it the school can still get its
    // INVOICE (to preview, download or pay another way); only the payment prompt is skipped.
    const gatewayReady = isClickPesaConfigured();

    const { plan_id, billing_cycle = 'monthly', addons = [], phone } = req.body;
    if (gatewayReady && !phone) return res.status(400).json({ success: false, message: 'A mobile money phone number is required.' });

    const plan = await SubscriptionPlan.findOne({ where: { id: plan_id, status: 'active' } });
    if (!plan) return res.status(404).json({ success: false, message: 'Plan not found' });

    const studentCount = await activeStudentCount(req.tenantId);
    if (plan.student_limit !== null && studentCount > plan.student_limit) {
      return res.status(400).json({
        success: false,
        message: `Your school has ${studentCount} active students; the ${plan.name} plan allows ${plan.student_limit}.`,
      });
    }

    const subscription = await getOrCreateSubscription(req.tenantId);
    const quote = await priceSubscription({
      plan, billingCycle: billing_cycle, addonCodes: addons, currentSubscription: subscription,
    });

    // An upgrade replaces the current plan; a renewal extends the same one.
    const currentPlan = subscription.plan_id ? await SubscriptionPlan.findByPk(subscription.plan_id) : null;
    const kind = !currentPlan ? 'new'
      : currentPlan.id === plan.id ? 'renewal'
        : 'upgrade';

    // A renewal starts when the current window ends, so paying early never
    // costs the school days. Everything else starts now.
    const evaluation = evaluateSubscription(subscription);
    const startsAt = (kind === 'renewal' && !evaluation.locked && subscription.ends_at)
      ? new Date(subscription.ends_at)
      : new Date();
    const periodEnd = new Date(startsAt.getTime() + (CYCLE_DAYS[billing_cycle] || 30) * 86400000);

    const orderReference = buildOrderReference();

    const invoice = await SubscriptionInvoice.create({
      tenant_id: req.tenantId,
      subscription_id: subscription.id,
      plan_id: plan.id,
      invoice_number: await nextInvoiceNumber(),
      line_items: quote.lineItems,
      billing_cycle,
      subtotal: quote.subtotal,
      proration_credit: quote.prorationCredit,
      total: quote.total,
      kind,
      order_reference: orderReference,
      gateway: gatewayReady ? 'clickpesa' : null,
      payer_phone: phone || null,
      period_start: startsAt,
      period_end: periodEnd,
      status: 'pending',
    });

    if (!gatewayReady) {
      res.status(201).json({
        success: true,
        message: `Invoice ${invoice.invoice_number} created. Online payment is not available on this server yet, so no payment prompt was sent. You can preview or download the invoice, and pay once payments are switched on.`,
        data: { invoice, quote, payment_started: false },
      });
      // The PDF goes to the school's administrators; it never delays the answer.
      emailInvoiceCreated(invoice);
      return undefined;
    }

    try {
      // Preview first — catches an unsupported amount before the school is
      // told to expect a prompt.
      await previewPayment({ amount: quote.total, orderReference });

      const payment = await initiatePayment({
        amount: quote.total,
        orderReference,
        phoneNumber: phone,
      });

      await invoice.update({
        status: 'processing',
        gateway_payment_id: payment.paymentId,
        gateway_status: payment.status,
        gateway_response: payment.raw,
      });

      res.status(201).json({
        success: true,
        message: `A payment prompt for ${(await moneyFormatterFor(req.tenantId)).withCurrency(quote.total)} has been sent to ${phone}. Approve it on the handset to activate your subscription.`,
        data: { invoice, quote, payment_started: true },
      });
      emailInvoiceCreated(invoice);
      return undefined;
    } catch (err) {
      await invoice.update({ status: 'failed', failure_reason: err.message });
      await logSystemEvent({ tenantId: req.tenantId, userId: req.user?.id, title: `Payment could not be started: invoice ${invoice.invoice_number}`, resourceId: invoice.id, reason: err.message });
      emailInvoiceCreated(invoice); // the invoice still exists and can be paid later
      return res.status(400).json({ success: false, message: err.message, data: { invoice } });
    }
  } catch (error) { next(error); }
};

/**
 * Applies a successful payment: extends or upgrades the subscription.
 *
 * Idempotent — a webhook and a status poll can both report the same
 * payment, and applying it twice would hand out double the time.
 */
/**
 * The one place a confirmed payment lands: it extends the subscription and marks the invoice
 * paid, then records it and emails the receipt.
 *
 * It can be reached twice at once — the gateway's webhook and the school's own status check
 * often arrive within a second of each other — so the invoice row is locked inside a
 * transaction and re-read: the second caller sees "paid" and does nothing. That is what
 * stops a payment being applied, audited and emailed twice.
 *
 *   source  who confirmed it: "webhook" | "status check" | "pay page" | "test"
 *   awaitNotifications  wait for the audit entry and the receipt email (scripts, tests);
 *                       a request normally lets them finish in the background.
 */
export const applyPaidInvoice = async (invoiceInput, { source = 'gateway', awaitNotifications = false } = {}) => {
  let applied = false;
  let wasLocked = false;
  let subscription = null;

  // Counted BEFORE the transaction. Inside it, this second query would need a second database
  // connection while the first is held; with several confirmations arriving together every
  // connection ends up held by a transaction waiting for the row lock, and none is left for
  // the query the lock-holder is waiting on. (An integration test found this.)
  const studentCount = await activeStudentCount(invoiceInput.tenant_id);

  await sequelize.transaction(async (t) => {
    const locked = await SubscriptionInvoice.findByPk(invoiceInput.id, { transaction: t, lock: t.LOCK.UPDATE });
    if (!locked || locked.status === 'paid') return;

    subscription = await Subscription.findByPk(locked.subscription_id, { transaction: t, lock: t.LOCK.UPDATE });
    if (!subscription) return;

    wasLocked = evaluateSubscription(subscription).locked;

    await subscription.update({
      plan_id: locked.plan_id,
      billing_cycle: locked.billing_cycle,
      status: 'active',
      starts_at: locked.period_start,
      ends_at: locked.period_end,
      amount_paid: locked.total,
      student_count_at_purchase: studentCount,
      cancelled_at: null,
      // A new paid window starts: its reminders have not been sent yet.
      reminders_sent: {},
    }, { transaction: t });

    await locked.update({ status: 'paid', paid_at: new Date() }, { transaction: t });
    applied = true;
  });

  await invoiceInput.reload();
  if (!applied) return invoiceInput;

  const tell = (async () => {
    const fmt = await moneyFormatterFor(invoiceInput.tenant_id);
    await logSystemEvent({
      tenantId: invoiceInput.tenant_id,
      title: `Payment confirmed: invoice ${invoiceInput.invoice_number} (${fmt.withCurrency(invoiceInput.total, invoiceInput.currency)}) paid`,
      resourceId: invoiceInput.id,
      reason: `Confirmed by: ${source}`,
    });
    if (wasLocked) {
      await logSystemEvent({
        tenantId: invoiceInput.tenant_id,
        title: 'Subscription unlocked: access restored after payment',
        resourceId: subscription?.id,
      });
    }
    await emailReceipt(invoiceInput);
  })().catch((err) => console.error('Payment follow-up error:', err));

  if (awaitNotifications) await tell;
  return invoiceInput;
};

/** GET /subscription/invoices/:reference/status — polls the gateway.
 *
 * A webhook can be missed (server restart, network blip), so the school
 * must always have a way to ask "did my payment go through?" themselves.
 */
/**
 * Asks the gateway where an invoice stands and brings the invoice (and the subscription)
 * up to date. Throws if the gateway cannot be asked (not set up, or unreachable) — the
 * invoice is left exactly as it was.
 */
export const refreshInvoiceFromGateway = async (invoice, { source = 'status check' } = {}) => {
  if (invoice.status === 'paid') return { invoice, message: 'Payment confirmed.' };

  const result = await getPaymentStatus(invoice.order_reference);
  const mapped = mapPaymentStatus(result.status);
  await invoice.update({ gateway_status: result.status, gateway_response: result.raw });

  if (mapped === 'paid') {
    await applyPaidInvoice(invoice, { source });
    return { invoice, message: 'Payment confirmed — your subscription is active.' };
  }
  if (mapped === 'failed') {
    await invoice.update({ status: 'failed', failure_reason: `Gateway reported ${result.status}` });
    await invoice.reload();
    await logSystemEvent({ tenantId: invoice.tenant_id, title: `Payment failed: invoice ${invoice.invoice_number}`, resourceId: invoice.id, reason: `Gateway reported ${result.status}` });
    return { invoice, message: 'Payment failed or was cancelled.' };
  }
  return { invoice, message: 'Payment is still processing.' };
};

export const checkInvoiceStatus = async (req, res, next) => {
  try {
    const invoice = await SubscriptionInvoice.findOne({
      where: { order_reference: req.params.reference, tenant_id: req.tenantId },
    });
    if (!invoice) return res.status(404).json({ success: false, message: 'Invoice not found' });
    if (invoice.status === 'paid') return res.json({ success: true, data: invoice });

    try {
      const { message } = await refreshInvoiceFromGateway(invoice, { source: 'status check' });
      return res.json({ success: true, message, data: invoice });
    } catch (err) {
      return res.status(400).json({ success: false, message: err.message, data: invoice });
    }
  } catch (error) { next(error); }
};

export const getInvoices = async (req, res, next) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const { count, rows } = await SubscriptionInvoice.findAndCountAll({
      where: { tenant_id: req.tenantId },
      include: [{ model: SubscriptionPlan, as: 'plan', attributes: ['id', 'name', 'code'] }],
      limit: parseInt(limit), offset: (page - 1) * limit,
      order: [['created_at', 'DESC']],
    });

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

/**
 * POST /subscription/invoices/:reference/pay — sends the payment prompt for an
 * invoice that already exists (created while online payment was off, or one whose
 * earlier attempt failed). The amount and plan are the invoice's own; nothing is
 * re-priced. A fresh order reference is used for every attempt, because a gateway
 * refuses to reuse one — so link to invoices by invoice_number, not by reference.
 */
/**
 * Sends the mobile-money prompt for an invoice that already exists. A fresh order reference
 * is used every time (a gateway refuses to reuse one). Never throws for a gateway problem:
 * it marks the invoice failed, records why, and says so.
 */
const startGatewayPayment = async (invoice, phone) => {
  const orderReference = buildOrderReference();
  try {
    await previewPayment({ amount: Number(invoice.total), orderReference });
    const payment = await initiatePayment({ amount: Number(invoice.total), orderReference, phoneNumber: phone });
    await invoice.update({
      order_reference: orderReference, gateway: 'clickpesa', payer_phone: phone,
      status: 'processing', failure_reason: null,
      gateway_payment_id: payment.paymentId, gateway_status: payment.status, gateway_response: payment.raw,
    });
    return { ok: true };
  } catch (err) {
    await invoice.update({ status: 'failed', failure_reason: err.message });
    await logSystemEvent({ tenantId: invoice.tenant_id, title: `Payment could not be started: invoice ${invoice.invoice_number}`, resourceId: invoice.id, reason: err.message });
    return { ok: false, error: err.message };
  }
};

export const payInvoice = async (req, res, next) => {
  try {
    if (!isClickPesaConfigured()) {
      return res.status(400).json({ success: false, message: 'Online payment is not available on this server yet. Ask the platform administrator to set the ClickPesa credentials.' });
    }
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ success: false, message: 'A mobile money phone number is required.' });

    const ref = String(req.params.reference || '');
    const invoice = await SubscriptionInvoice.findOne({
      where: { tenant_id: req.tenantId, [Op.or]: [{ invoice_number: ref }, { order_reference: ref }] },
    });
    if (!invoice) return res.status(404).json({ success: false, message: 'Invoice not found' });
    if (invoice.status === 'paid') return res.status(400).json({ success: false, message: 'This invoice is already paid.' });
    if (invoice.status === 'processing') return res.status(400).json({ success: false, message: 'A payment for this invoice is already awaiting approval on the handset. Use Check Payment Status.' });
    if (invoice.status === 'cancelled') return res.status(400).json({ success: false, message: 'This invoice was cancelled. Create a new one.' });
    if (Date.now() - new Date(invoice.createdAt).getTime() > 7 * 86400000) {
      return res.status(400).json({ success: false, message: 'This invoice is more than 7 days old, so its prices and dates may be out of date. Create a new invoice.' });
    }

    const started = await startGatewayPayment(invoice, phone);
    if (!started.ok) return res.status(400).json({ success: false, message: started.error, data: { invoice } });
    return res.json({
      success: true,
      message: `A payment prompt for ${(await moneyFormatterFor(req.tenantId)).withCurrency(invoice.total, invoice.currency)} has been sent to ${phone}. Approve it on the handset to activate your subscription.`,
      data: { invoice },
    });
  } catch (error) { next(error); }
};

/**
 * Cleaning up the invoice list.
 *
 * What counts as clutter: invoices that were CANCELLED, and invoices still unpaid (waiting, or
 * failed) after STALE_UNPAID_DAYS. What is never touched: a PAID invoice (it is the record of a
 * payment and the source of its receipt) and one whose payment prompt is awaiting approval (the
 * money may be on its way). Invoice numbers are never reused, so a cleaned-up list simply has gaps.
 */
export const STALE_UNPAID_DAYS = 30;

export const cleanupWhere = (tenantId, now = Date.now()) => ({
  tenant_id: tenantId,
  [Op.or]: [
    { status: 'cancelled' },
    { status: { [Op.in]: ['pending', 'failed'] }, createdAt: { [Op.lt]: new Date(now - STALE_UNPAID_DAYS * 86400000) } },
  ],
});

/** GET /subscription/invoice-cleanup — what a clean-up would remove, without removing anything. */
export const previewInvoiceCleanup = async (req, res, next) => {
  try {
    const rows = await SubscriptionInvoice.findAll({ where: cleanupWhere(req.tenantId), attributes: ['invoice_number', 'status', 'total'], order: [['createdAt', 'ASC']] });
    const cancelled = rows.filter((r) => r.status === 'cancelled').length;
    res.json({
      success: true,
      data: {
        cancelled,
        unpaid_old: rows.length - cancelled,
        total: rows.length,
        older_than_days: STALE_UNPAID_DAYS,
        sample: rows.slice(0, 8).map((r) => r.invoice_number),
      },
    });
  } catch (error) { next(error); }
};

/** POST /subscription/invoice-cleanup — removes them, and records exactly which. */
export const runInvoiceCleanup = async (req, res, next) => {
  try {
    const removed = await sequelize.transaction(async (t) => {
      const rows = await SubscriptionInvoice.findAll({
        where: cleanupWhere(req.tenantId), attributes: ['id', 'invoice_number', 'status'], transaction: t, lock: t.LOCK.UPDATE,
      });
      if (rows.length === 0) return [];
      await SubscriptionInvoice.destroy({ where: { id: rows.map((r) => r.id), tenant_id: req.tenantId }, transaction: t });
      return rows;
    });

    if (removed.length > 0) {
      await logSystemEvent({
        tenantId: req.tenantId, userId: req.user.id,
        title: `Cleaned up ${removed.length} old invoice${removed.length === 1 ? '' : 's'} (cancelled or unpaid for over ${STALE_UNPAID_DAYS} days)`,
        reason: 'Paid invoices and receipts are never removed.',
        extra: { invoices: removed.slice(0, 200).map((r) => `${r.invoice_number} (${r.status})`), count: removed.length },
      });
    }
    res.json({
      success: true,
      message: removed.length ? `${removed.length} old invoice${removed.length === 1 ? '' : 's'} removed.` : 'There was nothing to clean up.',
      data: { removed: removed.length },
    });
  } catch (error) { next(error); }
};

/**
 * POST /subscription/invoices/:reference/cancel — withdraws an invoice that has not been paid
 * (still waiting, or whose payment failed). It stays in the list as "Cancelled" so the
 * numbering has no gaps, and its pay link stops working. An invoice whose payment prompt is
 * awaiting approval is NOT cancelled: the money may be on its way; check its status first.
 */
export const cancelInvoice = async (req, res, next) => {
  try {
    const ref = String(req.params.reference || '');
    const invoice = await SubscriptionInvoice.findOne({
      where: { tenant_id: req.tenantId, [Op.or]: [{ invoice_number: ref }, { order_reference: ref }] },
    });
    if (!invoice) return res.status(404).json({ success: false, message: 'Invoice not found' });
    if (invoice.status === 'paid') return res.status(400).json({ success: false, message: 'A paid invoice cannot be cancelled.' });
    if (invoice.status === 'cancelled') return res.status(400).json({ success: false, message: 'This invoice is already cancelled.' });
    if (invoice.status === 'processing') {
      return res.status(400).json({ success: false, message: 'A payment for this invoice is awaiting approval on the handset. Use Check Payment Status first; you can cancel the invoice if the payment fails.' });
    }
    await invoice.update({ status: 'cancelled', failure_reason: `Cancelled by ${req.user.first_name || ''} ${req.user.last_name || ''}`.trim() });
    res.json({ success: true, message: `Invoice ${invoice.invoice_number} cancelled.`, data: { invoice } });
  } catch (error) { next(error); }
};

/**
 * PUBLIC (no login) — the page a "Scan to pay" QR code opens.
 *   GET  /public/subscription-pay/:invoiceNumber/:code           what is being paid
 *   POST /public/subscription-pay/:invoiceNumber/:code           { phone } send the mobile-money prompt
 *   GET  /public/subscription-pay/:invoiceNumber/:code/status    has it been paid yet?
 * The code is an HMAC of the invoice (see utils/receiptSecurity.js), so only someone holding
 * the invoice can use it, and it stops working if the invoice is re-priced.
 */
const findPayableInvoice = async (req) => {
  const invoice = await SubscriptionInvoice.findOne({
    where: { invoice_number: String(req.params.invoiceNumber || '').toUpperCase() },
    include: [{ model: SubscriptionPlan, as: 'plan', attributes: ['name'] }],
  });
  if (!invoice || !isValidSubscriptionPayCode(invoice, req.params.code)) return null;
  return invoice;
};

const publicInvoiceView = async (invoice) => {
  const tenant = await Tenant.findByPk(invoice.tenant_id, { attributes: ['name'] });
  return {
    valid: true,
    invoice_number: invoice.invoice_number,
    school: tenant?.name || null,
    plan: invoice.plan?.name || null,
    billing_cycle: invoice.billing_cycle,
    amount: Number(invoice.total),
    currency: invoice.currency,
    status: invoice.status,
    period_start: invoice.period_start,
    period_end: invoice.period_end,
    receipt_number: invoice.status === 'paid' ? invoice.invoice_number.replace(/^INV-/, 'RCT-') : null,
    payments_available: isClickPesaConfigured(),
  };
};

export const getPublicPayInvoice = async (req, res, next) => {
  try {
    const invoice = await findPayableInvoice(req);
    if (!invoice) return res.json({ success: true, data: { valid: false } });
    res.json({ success: true, data: await publicInvoiceView(invoice) });
  } catch (error) { next(error); }
};

export const startPublicPayment = async (req, res, next) => {
  try {
    const invoice = await findPayableInvoice(req);
    if (!invoice) return res.status(404).json({ success: false, message: 'This payment link is not valid.' });
    if (!isClickPesaConfigured()) {
      return res.status(400).json({ success: false, message: 'Online payment is not available yet. Please contact EduTrack support.' });
    }
    if (invoice.status === 'paid') return res.status(400).json({ success: false, message: 'This invoice has already been paid. Thank you!' });
    if (invoice.status === 'cancelled') return res.status(400).json({ success: false, message: 'This invoice was cancelled. Ask the school to create a new one.' });
    if (invoice.status === 'processing') {
      return res.status(400).json({ success: false, message: 'A payment prompt was already sent for this invoice. Approve it on the phone, then check the status.' });
    }
    const phone = normalizePhone(req.body?.phone);
    if (!phone || !/^\d{9,15}$/.test(phone)) {
      return res.status(400).json({ success: false, message: 'Enter the mobile money number to charge, for example 255712345678.' });
    }
    const started = await startGatewayPayment(invoice, phone);
    if (!started.ok) return res.status(400).json({ success: false, message: started.error });
    res.json({ success: true, message: `A payment prompt has been sent to ${phone}. Approve it on the phone to complete the payment.`, data: await publicInvoiceView(invoice) });
  } catch (error) { next(error); }
};

export const getPublicPayStatus = async (req, res, next) => {
  try {
    const invoice = await findPayableInvoice(req);
    if (!invoice) return res.status(404).json({ success: false, message: 'This payment link is not valid.' });
    let message = null;
    if (invoice.status === 'processing' && isClickPesaConfigured()) {
      try { ({ message } = await refreshInvoiceFromGateway(invoice, { source: 'pay page' })); } catch { /* ask again shortly */ }
    }
    res.json({ success: true, message, data: await publicInvoiceView(invoice) });
  } catch (error) { next(error); }
};

/**
 * PUBLIC (no login) — GET /verify/subscription-receipt/:invoiceNumber/:code
 *                     GET /verify/subscription-receipt?receipt_no=RCT-…&code=…
 * Lets anyone holding a subscription receipt confirm it is genuine. Only a paid invoice
 * can be verified, and only with the HMAC code printed on (and encoded in the QR of)
 * the receipt, so a doctored amount or date fails. Exposes just what is on the receipt.
 */
export const verifySubscriptionReceipt = async (req, res, next) => {
  try {
    const raw = String(req.params.invoiceNumber || req.query.receipt_no || '').trim().toUpperCase();
    const code = String(req.params.code || req.query.code || '').trim();
    const invoiceNumber = raw.replace(/^RCT-/, 'INV-');
    if (!/^INV-[A-Z0-9-]{3,40}$/.test(invoiceNumber) || !code) {
      return res.json({ success: true, data: { valid: false } });
    }
    const invoice = await SubscriptionInvoice.findOne({
      where: { invoice_number: invoiceNumber, status: 'paid' },
      include: [{ model: SubscriptionPlan, as: 'plan', attributes: ['name'] }],
    });
    if (!invoice || !isValidSubscriptionReceiptCode(invoice, code)) {
      return res.json({ success: true, data: { valid: false } });
    }
    const tenant = await Tenant.findByPk(invoice.tenant_id, { attributes: ['name'] });
    res.json({
      success: true,
      data: {
        valid: true,
        receipt_number: invoice.invoice_number.replace(/^INV-/, 'RCT-'),
        invoice_number: invoice.invoice_number,
        school: tenant?.name || null,
        plan: invoice.plan?.name || null,
        billing_cycle: invoice.billing_cycle,
        amount: Number(invoice.total),
        currency: invoice.currency,
        paid_at: invoice.paid_at,
        period_start: invoice.period_start,
        period_end: invoice.period_end,
      },
    });
  } catch (error) { next(error); }
};

/**
 * GET /subscription/invoices/:reference — everything needed to show or print one
 * invoice (or, once paid, its receipt): the invoice, the plan, the school it is
 * billed to, and the receipt number. `reference` may be the order reference, the
 * invoice number or the invoice id.
 */
export const getInvoiceDetail = async (req, res, next) => {
  try {
    const ref = String(req.params.reference || '');
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(ref);
    const invoice = await SubscriptionInvoice.findOne({
      where: {
        tenant_id: req.tenantId,
        [Op.or]: [{ order_reference: ref }, { invoice_number: ref }, ...(isUuid ? [{ id: ref }] : [])],
      },
      include: [{ model: SubscriptionPlan, as: 'plan', attributes: ['id', 'name', 'code', 'description', 'student_limit'] }],
    });
    if (!invoice) return res.status(404).json({ success: false, message: 'Invoice not found' });

    res.json({ success: true, data: await loadInvoiceDocumentData(invoice) });
  } catch (error) { next(error); }
};

/** POST /subscription/cancel — stops auto-renewal. Access continues to the
 * end of the paid window; a school that has paid for a term keeps it. */
export const cancelSubscription = async (req, res, next) => {
  try {
    const subscription = await getOrCreateSubscription(req.tenantId);
    await subscription.update({ auto_renew: false, cancelled_at: new Date() });

    res.json({
      success: true,
      message: subscription.ends_at
        ? `Auto-renewal is off. You keep access until ${new Date(subscription.ends_at).toDateString()}.`
        : 'Auto-renewal is off.',
      data: subscription,
    });
  } catch (error) { next(error); }
};

/** POST /subscription/gateway/test — developer-only credential check. */
export const testGateway = async (req, res, next) => {
  try {
    if (req.user.role !== 'super_admin') {
      return res.status(403).json({ success: false, message: 'Restricted to the platform developer.' });
    }
    try {
      const result = await testClickPesaConnection();
      return res.json({ success: true, message: result.message });
    } catch (err) {
      return res.status(400).json({ success: false, message: err.message });
    }
  } catch (error) { next(error); }
};

/**
 * POST /webhooks/clickpesa — payment notification.
 *
 * Mounted outside the authenticated routes: the gateway has no session.
 * Always returns 200, because a non-2xx makes ClickPesa retry, and a retry
 * storm caused by our own bug helps nobody.
 */
export const handleClickPesaWebhook = async (req, res) => {
  try {
    const secret = process.env.CLICKPESA_WEBHOOK_SECRET;
    if (secret) {
      const provided = String(req.headers['x-clickpesa-signature'] || req.headers['x-webhook-secret'] || '');
      const a = Buffer.from(provided);
      const b = Buffer.from(secret);
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
        console.warn('[clickpesa] webhook rejected: bad signature');
        return res.status(200).json({ received: true });
      }
    }

    const payload = req.body?.data || req.body || {};
    const orderReference = payload.orderReference || payload.order_reference;
    if (!orderReference) return res.status(200).json({ received: true });

    const invoice = await SubscriptionInvoice.findOne({ where: { order_reference: orderReference } });
    if (!invoice) {
      console.warn('[clickpesa] webhook for unknown reference:', orderReference);
      return res.status(200).json({ received: true });
    }

    if (invoice.status === 'paid') return res.status(200).json({ received: true });

    // The callback only says WHICH invoice to look at. Whether it was paid is
    // asked of ClickPesa directly — this URL has no login, so anyone can post to
    // it, and trusting `status: SUCCESS` in the body meant a school could mark
    // its own invoice paid, and switch its subscription on, without paying. If
    // ClickPesa can't be asked (not configured, or unreachable), nothing changes;
    // the school's own status check (or ClickPesa's retry) settles it later.
    let confirmed;
    try {
      confirmed = await getPaymentStatus(invoice.order_reference);
    } catch (err) {
      console.warn('[clickpesa] could not confirm payment with the gateway, leaving invoice unchanged:', err.message);
      return res.status(200).json({ received: true });
    }

    const mapped = mapPaymentStatus(confirmed.status);
    await invoice.update({ gateway_status: confirmed.status, gateway_response: confirmed.raw });

    if (mapped === 'paid') {
      await applyPaidInvoice(invoice, { source: 'webhook' });
    } else if (mapped === 'failed') {
      await invoice.update({ status: 'failed', failure_reason: `Gateway reported ${confirmed.status}` });
      await logSystemEvent({ tenantId: invoice.tenant_id, title: `Payment failed: invoice ${invoice.invoice_number}`, resourceId: invoice.id, reason: `Gateway reported ${confirmed.status}` });
    }

    return res.status(200).json({ received: true });
  } catch (error) {
    console.error('[clickpesa] webhook error:', error);
    return res.status(200).json({ received: true });
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// PLATFORM ADMIN (developer)
// ═══════════════════════════════════════════════════════════════════════════

/** PUT /subscription/plans/:id — plan pricing is the platform's business,
 * not any one school's, so it's restricted to the developer. */
export const upsertPlan = async (req, res, next) => {
  try {
    if (req.user.role !== 'super_admin') {
      return res.status(403).json({ success: false, message: 'Restricted to the platform developer.' });
    }
    const plan = await SubscriptionPlan.findByPk(req.params.id);
    if (!plan) return res.status(404).json({ success: false, message: 'Plan not found' });

    const allowed = ['name', 'description', 'student_limit', 'price_monthly', 'price_termly', 'price_yearly', 'included_modules', 'tier', 'status'];
    const updates = {};
    allowed.forEach((key) => { if (req.body[key] !== undefined) updates[key] = req.body[key]; });

    await plan.update(updates);
    res.json({ success: true, message: 'Plan updated', data: plan });
  } catch (error) { next(error); }
};

/** GET /subscription/tenants — every school and where their subscription
 * stands. The developer's view of the business. */
export const getAllSubscriptions = async (req, res, next) => {
  try {
    if (req.user.role !== 'super_admin') {
      return res.status(403).json({ success: false, message: 'Restricted to the platform developer.' });
    }

    const subscriptions = await Subscription.findAll({
      include: [
        { model: Tenant, as: 'tenant', attributes: ['id', 'name', 'slug'] },
        { model: SubscriptionPlan, as: 'plan', attributes: ['id', 'name', 'code'] },
      ],
      order: [['ends_at', 'ASC']],
    });

    res.json({
      success: true,
      data: subscriptions.map((s) => ({ ...s.toJSON(), evaluation: evaluateSubscription(s) })),
    });
  } catch (error) { next(error); }
};

/** Reconciles subscriptions whose window has passed, so the stored status
 * matches reality. Safe to run on a schedule. */
export const reconcileExpiredSubscriptions = async () => {
  const now = new Date();
  const due = await Subscription.findAll({
    where: { status: { [Op.in]: ['active', 'trial', 'grace'] }, ends_at: { [Op.lt]: now } },
  });

  for (const subscription of due) {
    const evaluation = evaluateSubscription(subscription);
    if (evaluation.status !== subscription.status) {
      await subscription.update({ status: evaluation.status });
    }
  }
  return due.length;
};
