import { Campus, User, Tenant, Student, Staff, Class, Attendance } from '../models/index.js';
import { Op } from 'sequelize';
import { normalizePhone } from '../utils/phone.js';
import { publicUrlFor } from '../middleware/upload.js';

export const campusController = {
  // Get all campuses with filters and pagination
  async getAll(req, res, next) {
    try {
      const {
        page = 1,
        limit = 10,
        search = '',
        status = '',
        city = '',
        state = '',
        country = '',
        sortBy = 'name',
        sortOrder = 'ASC',
      } = req.query;

      const offset = (page - 1) * limit;
      const where = { tenant_id: req.tenantId };

      // Add search filter
      if (search) {
        where[Op.or] = [
          { name: { [Op.iLike]: `%${search}%` } },
          { code: { [Op.iLike]: `%${search}%` } },
          { email: { [Op.iLike]: `%${search}%` } },
          { phone: { [Op.iLike]: `%${search}%` } },
        ];
      }

      // Add status filter
      if (status) {
        where.status = status;
      }

      // Add location filters
      if (city) {
        where.city = { [Op.iLike]: `%${city}%` };
      }
      if (state) {
        where.state = { [Op.iLike]: `%${state}%` };
      }
      if (country) {
        where.country = { [Op.iLike]: `%${country}%` };
      }

      const { count, rows: campuses } = await Campus.findAndCountAll({
        where,
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [[sortBy, sortOrder]],
        include: [
          {
            model: User,
            as: 'principal',
            attributes: ['id', 'first_name', 'last_name', 'email', 'phone'],
          },
          {
            model: Tenant,
            as: 'tenant',
            attributes: ['id', 'name'],
          },
        ],
      });

      res.json({
        success: true,
        data: campuses,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(count / limit),
          totalItems: count,
          itemsPerPage: parseInt(limit),
        },
      });
    } catch (error) {
      next(error);
    }
  },

  // Get single campus by ID
  async getById(req, res, next) {
    try {
      const { id } = req.params;

      const campus = await Campus.findOne({
        where: {
          id,
          tenant_id: req.tenantId,
        },
        include: [
          {
            model: User,
            as: 'principal',
            attributes: ['id', 'first_name', 'last_name', 'email', 'phone'],
          },
          {
            model: Tenant,
            as: 'tenant',
            attributes: ['id', 'name'],
          },
        ],
      });

      if (!campus) {
        return res.status(404).json({
          success: false,
          message: 'Campus not found',
        });
      }

      res.json({
        success: true,
        data: campus,
      });
    } catch (error) {
      next(error);
    }
  },

  // Create new campus
  async create(req, res, next) {
    try {
      const {
        name,
        code,
        address,
        city,
        state,
        country,
        postal_code,
        phone,
        email,
        website,
        principal_id,
        status = 'active',
      } = req.body;

      // Check if campus code already exists for this tenant
      const existingCampus = await Campus.findOne({
        where: {
          code,
          tenant_id: req.tenantId,
        },
      });

      if (existingCampus) {
        return res.status(400).json({
          success: false,
          message: 'Campus code already exists',
        });
      }

      // Verify principal exists if provided
      if (principal_id) {
        const principal = await User.findOne({
          where: {
            id: principal_id,
            tenant_id: req.tenantId,
            role: 'principal',
          },
        });

        if (!principal) {
          return res.status(400).json({
            success: false,
            message: 'Invalid principal ID',
          });
        }
      }

      const campus = await Campus.create({
        tenant_id: req.tenantId,
        name,
        code,
        address,
        city,
        state,
        country,
        postal_code,
        phone: normalizePhone(phone),
        email,
        website: website || null,
        principal_id: principal_id || null,
        status,
      });

      const createdCampus = await Campus.findByPk(campus.id, {
        include: [
          {
            model: User,
            as: 'principal',
            attributes: ['id', 'first_name', 'last_name', 'email', 'phone'],
          },
        ],
      });

      res.status(201).json({
        success: true,
        message: 'Campus created successfully',
        data: createdCampus,
      });
    } catch (error) {
      next(error);
    }
  },

  // Update campus
  async update(req, res, next) {
    try {
      const { id } = req.params;
      const {
        name,
        code,
        address,
        city,
        state,
        country,
        postal_code,
        phone,
        email,
        website,
        principal_id,
        status,
      } = req.body;

      const campus = await Campus.findOne({
        where: {
          id,
          tenant_id: req.tenantId,
        },
      });

      if (!campus) {
        return res.status(404).json({
          success: false,
          message: 'Campus not found',
        });
      }

      // Check if new code conflicts with existing campus
      if (code && code !== campus.code) {
        const existingCampus = await Campus.findOne({
          where: {
            code,
            tenant_id: req.tenantId,
            id: { [Op.ne]: id },
          },
        });

        if (existingCampus) {
          return res.status(400).json({
            success: false,
            message: 'Campus code already exists',
          });
        }
      }

      // Verify principal exists if provided
      if (principal_id) {
        const principal = await User.findOne({
          where: {
            id: principal_id,
            tenant_id: req.tenantId,
            role: 'principal',
          },
        });

        if (!principal) {
          return res.status(400).json({
            success: false,
            message: 'Invalid principal ID',
          });
        }
      }

      await campus.update({
        name,
        code,
        address,
        city,
        state,
        country,
        postal_code,
        phone: normalizePhone(phone),
        email,
        website: website || null,
        principal_id: principal_id || null,
        status,
      });

      const updatedCampus = await Campus.findByPk(id, {
        include: [
          {
            model: User,
            as: 'principal',
            attributes: ['id', 'first_name', 'last_name', 'email', 'phone'],
          },
        ],
      });

      res.json({
        success: true,
        message: 'Campus updated successfully',
        data: updatedCampus,
      });
    } catch (error) {
      next(error);
    }
  },

  // Delete campus (soft delete by setting status to inactive)
  async delete(req, res, next) {
    try {
      const { id } = req.params;

      const campus = await Campus.findOne({
        where: {
          id,
          tenant_id: req.tenantId,
        },
      });

      if (!campus) {
        return res.status(404).json({
          success: false,
          message: 'Campus not found',
        });
      }

      // Soft delete by setting status to inactive
      await campus.update({ status: 'inactive' });

      res.json({
        success: true,
        message: 'Campus deactivated successfully',
      });
    } catch (error) {
      next(error);
    }
  },

  // Permanently delete campus (hard delete)
  async permanentDelete(req, res, next) {
    try {
      const { id } = req.params;

      const campus = await Campus.findOne({
        where: {
          id,
          tenant_id: req.tenantId,
        },
      });

      if (!campus) {
        return res.status(404).json({
          success: false,
          message: 'Campus not found',
        });
      }

      await campus.destroy();

      res.json({
        success: true,
        message: 'Campus permanently deleted',
      });
    } catch (error) {
      next(error);
    }
  },

  // Reactivate campus
  async reactivate(req, res, next) {
    try {
      const { id } = req.params;

      const campus = await Campus.findOne({
        where: {
          id,
          tenant_id: req.tenantId,
        },
      });

      if (!campus) {
        return res.status(404).json({
          success: false,
          message: 'Campus not found',
        });
      }

      await campus.update({ status: 'active' });

      res.json({
        success: true,
        message: 'Campus reactivated successfully',
        data: campus,
      });
    } catch (error) {
      next(error);
    }
  },

  // Get campus statistics
  async getStats(req, res, next) {
    try {
      const { id } = req.params;

      const campus = await Campus.findOne({
        where: {
          id,
          tenant_id: req.tenantId,
        },
      });

      if (!campus) {
        return res.status(404).json({
          success: false,
          message: 'Campus not found',
        });
      }

      // These were hard-coded zeros behind a TODO, which meant the campus
      // page reported an empty school no matter how much was in it.
      const scope = { tenant_id: req.tenantId, campus_id: id };
      const today = new Date().toISOString().slice(0, 10);

      const [totalStudents, activeStudents, totalStaff, totalTeachers, totalClasses, presentToday, absentToday] = await Promise.all([
        Student.count({ where: scope }),
        Student.count({ where: { ...scope, status: 'active' } }),
        Staff.count({ where: { ...scope, status: 'active' } }),
        Staff.count({
          where: { ...scope, status: 'active' },
          include: [{ model: User, as: 'user', attributes: [], where: { role: 'teacher' } }],
        }),
        Class.count({ where: scope }),
        Attendance.count({
          where: { tenant_id: req.tenantId, date: today, status: 'present' },
          include: [{ model: Student, as: 'student', attributes: [], where: { campus_id: id } }],
        }),
        Attendance.count({
          where: { tenant_id: req.tenantId, date: today, status: 'absent' },
          include: [{ model: Student, as: 'student', attributes: [], where: { campus_id: id } }],
        }),
      ]);

      const marked = presentToday + absentToday;
      const stats = {
        totalStudents,
        activeStudents,
        totalStaff,
        totalTeachers,
        totalClasses,
        presentToday,
        absentToday,
        // Of those actually marked today — not of the whole roll, which
        // would read as mass absence before registers are taken.
        attendanceRate: marked > 0 ? Math.round((presentToday / marked) * 100) : 0,
      };

      res.json({
        success: true,
        data: stats,
      });
    } catch (error) {
      next(error);
    }
  },

  /** GET /campus/stats/summary — totals across ALL campuses.
   *
   * The list page was deriving these from the campuses currently on
   * screen, so the figures changed with the filter and the page number:
   * filtering to Active made "Inactive" read 0, and page 2 counted only
   * page 2. Counts belong on the server, where the whole set is visible.
   */
  async getSummary(req, res, next) {
    try {
      const scope = { tenant_id: req.tenantId };

      const [total, active, inactive, totalStudents] = await Promise.all([
        Campus.count({ where: scope }),
        Campus.count({ where: { ...scope, status: 'active' } }),
        Campus.count({ where: { ...scope, status: 'inactive' } }),
        Student.count({ where: { ...scope, status: 'active' } }),
      ]);

      res.json({ success: true, data: { total, active, inactive, totalStudents } });
    } catch (error) {
      next(error);
    }
  },

  // Bulk operations
  async bulkUpdateStatus(req, res, next) {
    try {
      const { ids, status } = req.body;

      if (!ids || !Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Invalid campus IDs',
        });
      }

      if (!['active', 'inactive'].includes(status)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid status',
        });
      }

      const result = await Campus.update(
        { status },
        {
          where: {
            id: { [Op.in]: ids },
            tenant_id: req.tenantId,
          },
        }
      );

      res.json({
        success: true,
        message: `${result[0]} campus(es) updated successfully`,
        updatedCount: result[0],
      });
    } catch (error) {
      next(error);
    }
  },

  /** POST /campus/:id/logo — multipart upload, field name "logo".
   *
   * The uploaded image becomes the school's letterhead on printed
   * documents (payment receipts, report cards), so it's stored per
   * campus rather than per tenant — a multi-campus school can brand each
   * campus separately. */
  async uploadLogo(req, res, next) {
    try {
      const campus = await Campus.findOne({
        where: { id: req.params.id, tenant_id: req.tenantId },
      });

      if (!campus) {
        return res.status(404).json({ success: false, message: 'Campus not found' });
      }

      if (!req.file) {
        return res.status(400).json({ success: false, message: 'No logo uploaded' });
      }

      const url = publicUrlFor(req, 'campus-logos', req.file.filename);
      await campus.update({ logo_url: url });

      res.json({ success: true, message: 'Logo uploaded successfully', data: campus });
    } catch (error) {
      next(error);
    }
  },

  /** DELETE /campus/:id/logo — clears the logo so printed documents fall
   * back to the text-only letterhead. */
  async deleteLogo(req, res, next) {
    try {
      const campus = await Campus.findOne({
        where: { id: req.params.id, tenant_id: req.tenantId },
      });

      if (!campus) {
        return res.status(404).json({ success: false, message: 'Campus not found' });
      }

      await campus.update({ logo_url: null });

      res.json({ success: true, message: 'Logo removed successfully', data: campus });
    } catch (error) {
      next(error);
    }
  },
};
