// FILE PATH: backend/src/controllers/contactInquiryController.js
import { Op } from 'sequelize';
import { Tenant, ContactInquiry, EmailGatewaySettings } from '../models/index.js';
import { sendEmail } from '../services/emailService.js';


// ─────────────────────────────────────────────────────────────────────────
// Public — no login required. Called from the tenant's public website
// (see website/frontend/src/services/api.js). Scoped by :tenantSlug in
// the URL rather than a JWT, and rate-limited (publicFormLimiter, wired
// in routes/publicRoutes.js) since anyone on the internet can reach it.
// ─────────────────────────────────────────────────────────────────────────
export const submitPublicContact = async (req, res, next) => {
  try {
    const tenant = await Tenant.findOne({ where: { slug: req.params.tenantSlug } });
    if (!tenant) {
      // Deliberately vague — this endpoint is public, so we don't want to
      // let someone enumerate valid tenant slugs by probing responses.
      return res.status(404).json({ success: false, message: 'This contact form is not available.' });
    }

    const { name, email, phone, subject, message } = req.body;

    if (!name?.trim() || !email?.trim() || !subject?.trim() || !message?.trim()) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, subject, and message are all required.',
      });
    }
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) {
      return res.status(400).json({ success: false, message: 'Enter a valid email address.' });
    }

    const inquiry = await ContactInquiry.create({
      tenant_id: tenant.id,
      name: name.trim(),
      email: email.trim(),
      phone: phone?.trim() || null,
      subject: subject.trim(),
      message: message.trim(),
      source: 'website',
    });

    // Best-effort notification to the school office — a slow or failed
    // email must never block the visitor's confirmation, so this is
    // fire-and-forget rather than awaited.
    notifyOfficeOfNewContact(tenant, inquiry).catch(() => { /* logged inside the helper */ });

    res.status(201).json({
      success: true,
      message: 'Thank you for your message! We will get back to you soon.',
    });
  } catch (error) { next(error); }
};

async function notifyOfficeOfNewContact(tenant, inquiry) {
  try {
    const gatewaySettings = await EmailGatewaySettings.findOne({ where: { tenant_id: tenant.id } });
    await sendEmail({
      to: tenant.email,
      subject: `New website message: ${inquiry.subject}`,
      text: [
        `A new message was submitted through the website contact form.`,
        ``,
        `From: ${inquiry.name}`,
        `Email: ${inquiry.email}`,
        inquiry.phone ? `Phone: ${inquiry.phone}` : null,
        `Subject: ${inquiry.subject}`,
        ``,
        inquiry.message,
        ``,
        `View it in EduTrack under Messages → Website Inquiries.`,
      ].filter(Boolean).join('\n'),
    }, gatewaySettings);
  } catch (error) {
    // Notification failing shouldn't surface to the visitor or the
    // caller — the message itself is already saved and visible in
    // EduTrack regardless of whether this email goes out.
    console.error('Failed to send contact inquiry notification email:', error.message);
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Staff-facing — authenticated, tenant-scoped (mounted behind
// authenticate + checkTenant in routes/contactInquiryRoutes.js).
// ─────────────────────────────────────────────────────────────────────────
export const listContactInquiries = async (req, res, next) => {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 20));
    const { status, search } = req.query;

    const where = { tenant_id: req.tenantId };
    if (status) where.status = status;
    if (search) {
      where[Op.or] = [
        { name: { [Op.iLike]: `%${search}%` } },
        { email: { [Op.iLike]: `%${search}%` } },
        { phone: { [Op.iLike]: `%${search}%` } },
        { subject: { [Op.iLike]: `%${search}%` } },
      ];
    }

    const { rows, count } = await ContactInquiry.findAndCountAll({
      where,
      order: [['createdAt', 'DESC']],
      limit,
      offset: (page - 1) * limit,
    });

    res.json({
      success: true,
      data: rows,
      pagination: { currentPage: page, itemsPerPage: limit, totalItems: count, totalPages: Math.ceil(count / limit) || 1 },
    });
  } catch (error) { next(error); }
};

export const getContactInquiryCounts = async (req, res, next) => {
  try {
    const rows = await ContactInquiry.findAll({
      where: { tenant_id: req.tenantId },
      attributes: ['status'],
      raw: true,
    });
    const counts = { new: 0, read: 0, replied: 0 };
    for (const r of rows) counts[r.status] = (counts[r.status] || 0) + 1;
    res.json({ success: true, data: counts });
  } catch (error) { next(error); }
};

export const updateContactInquiryStatus = async (req, res, next) => {
  try {
    const { status, staff_notes } = req.body;
    if (status && !['new', 'read', 'replied'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status' });
    }

    const inquiry = await ContactInquiry.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!inquiry) return res.status(404).json({ success: false, message: 'Message not found' });

    await inquiry.update({
      ...(status !== undefined ? { status } : {}),
      ...(staff_notes !== undefined ? { staff_notes } : {}),
    });

    res.json({ success: true, message: 'Updated', data: inquiry });
  } catch (error) { next(error); }
};