import { Op } from 'sequelize';
import { Notification, NotificationSetting } from '../models/index.js';
import { NOTIFICATION_EVENTS, CHANNELS, getEvent, getEventDefaults, defaultAudience, resolveAudience } from '../utils/notificationEvents.js';

const ADMIN_ROLES = ['super_admin', 'admin', 'principal'];

/**
 * Every role-broadcast notification in the codebase (see notifyEvent
 * call sites across the controllers) targets roles like 'admin',
 * 'principal', 'accountant', 'hr' — never 'super_admin' specifically,
 * since super_admin is the tenant's top-level account rather than a
 * day-to-day operational role anyone would think to list explicitly.
 * The result: a super_admin's bell was ALWAYS empty, for every event,
 * by omission — not a bug in any one notification, a gap in all of them.
 *
 * Rather than editing every notifyEvent call site to also list
 * 'super_admin' (fragile — the next new event would repeat the same
 * mistake), a super_admin simply also sees whatever 'admin' would see,
 * here at the query boundary. super_admin is a strict superset of admin
 * everywhere else in the app's permission model, so this is the one
 * place that needed to reflect that, not the many places notifications
 * get created.
 */
const notificationRolesFor = (role) => (role === 'super_admin' ? ['super_admin', 'admin'] : [role]);

// ═══════════════════════════════════════════════════════════════════════════
// IN-APP NOTIFICATIONS (bell icon)
// ═══════════════════════════════════════════════════════════════════════════

/** GET /notifications — everything addressed to me, either directly
 * (recipient_id) or via a role broadcast (recipient_role = my role). */
export const getMyNotifications = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, unread_only = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = {
      tenant_id: req.tenantId,
      [Op.or]: [{ recipient_id: req.user.id }, { recipient_role: { [Op.in]: notificationRolesFor(req.user.role) } }],
    };
    if (unread_only === 'true') where.is_read = false;

    const { count, rows } = await Notification.findAndCountAll({
      where, limit: parseInt(limit), offset: parseInt(offset),
      order: [['created_at', 'DESC']],
    });

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

export const getUnreadCount = async (req, res, next) => {
  try {
    const count = await Notification.count({
      where: {
        tenant_id: req.tenantId, is_read: false,
        [Op.or]: [{ recipient_id: req.user.id }, { recipient_role: { [Op.in]: notificationRolesFor(req.user.role) } }],
      },
    });
    res.json({ success: true, data: { count } });
  } catch (error) { next(error); }
};

export const markAsRead = async (req, res, next) => {
  try {
    const notification = await Notification.findOne({
      where: {
        id: req.params.id, tenant_id: req.tenantId,
        [Op.or]: [{ recipient_id: req.user.id }, { recipient_role: { [Op.in]: notificationRolesFor(req.user.role) } }],
      },
    });
    if (!notification) return res.status(404).json({ success: false, message: 'Notification not found' });
    await notification.update({ is_read: true });
    res.json({ success: true, message: 'Marked as read' });
  } catch (error) { next(error); }
};

export const markAllAsRead = async (req, res, next) => {
  try {
    await Notification.update(
      { is_read: true },
      { where: { tenant_id: req.tenantId, is_read: false, [Op.or]: [{ recipient_id: req.user.id }, { recipient_role: { [Op.in]: notificationRolesFor(req.user.role) } }] } },
    );
    res.json({ success: true, message: 'All notifications marked as read' });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// NOTIFICATION SETTINGS — which automatic events fire, and on which channels
// ═══════════════════════════════════════════════════════════════════════════

/**
 * What the Settings → Notifications screen shows. Each event lists its PARTIES (who can be told) and, for each, whether the
 * school has it on and through which channels. An event with no parties (the password-reset code) just has `channels`.
 */
export const getNotificationSettings = async (req, res, next) => {
  try {
    const stored = await NotificationSetting.findAll({ where: { tenant_id: req.tenantId } });
    const byKey = Object.fromEntries(stored.map((s) => [s.event_key, s]));

    const data = NOTIFICATION_EVENTS.map((evt) => {
      const existing = byKey[evt.key];
      const audience = resolveAudience(evt, existing?.audience);
      return {
        event_key: evt.key, label: evt.label, description: evt.description,
        enabled: evt.key === 'password_reset' ? true : (existing ? existing.enabled : evt.default_enabled),
        channels: existing ? existing.channels : getEventDefaults(evt.key).default_channels,
        parties: evt.parties.map((p) => ({
          key: p.key, label: p.label, description: p.description || null, roles: p.roles || null,
          enabled: Array.isArray(audience[p.key]) && audience[p.key].length > 0,
          channels: audience[p.key]?.length ? audience[p.key] : p.default_channels,
        })),
      };
    });
    res.json({ success: true, data });
  } catch (error) { next(error); }
};

export const updateNotificationSetting = async (req, res, next) => {
  try {
    const { event_key, enabled, channels, audience } = req.body;
    if (!event_key) return res.status(400).json({ success: false, message: 'event_key is required' });
    const evt = getEvent(event_key);
    if (!evt) return res.status(404).json({ success: false, message: 'Unknown notification' });
    const defaults = getEventDefaults(event_key);

    // Password reset codes: a choice of where they go, never an on/off switch.
    if (event_key === 'password_reset') {
      if (channels !== undefined) {
        const valid = Array.isArray(channels) && channels.length > 0 && channels.every((c) => ['email', 'sms'].includes(c));
        if (!valid) return res.status(400).json({ success: false, message: 'Choose email, SMS, or both for password reset codes.' });
      }
      req.body.enabled = true;
    }

    const [setting] = await NotificationSetting.findOrCreate({
      where: { tenant_id: req.tenantId, event_key },
      defaults: { tenant_id: req.tenantId, event_key, enabled: defaults.default_enabled, channels: defaults.default_channels, audience: evt.parties.length ? defaultAudience(evt) : null },
    });

    // Who is told, and how: { party: [channels] }. A party that is left out is not notified.
    let nextAudience;
    if (audience !== undefined && evt.parties.length) {
      if (!audience || typeof audience !== 'object' || Array.isArray(audience)) return res.status(400).json({ success: false, message: 'audience must be an object of party → channels.' });
      const valid = new Set(evt.parties.map((p) => p.key));
      const clean = {};
      for (const [party, chs] of Object.entries(audience)) {
        if (!valid.has(party)) return res.status(400).json({ success: false, message: `"${party}" is not someone this notification can reach.` });
        if (!Array.isArray(chs) || chs.some((c) => !CHANNELS.includes(c))) return res.status(400).json({ success: false, message: 'Channels must be In-App, SMS or Email.' });
        if (chs.length === 0) {
          const label = evt.parties.find((p) => p.key === party).label;
          return res.status(400).json({ success: false, message: `Choose at least one way to notify "${label}" (In-App, SMS or Email), or untick them.` });
        }
        clean[party] = [...new Set(chs)];
      }
      const willBeEnabled = req.body.enabled !== undefined ? req.body.enabled : setting.enabled;
      if (Object.keys(clean).length === 0 && willBeEnabled) {
        return res.status(400).json({ success: false, message: 'Choose at least one person to notify, or switch this notification off.' });
      }
      nextAudience = clean;
    }
    // An older client that only sends `channels` for a notification with parties: apply them to every party that is on.
    if (nextAudience === undefined && channels !== undefined && evt.parties.length) {
      const current = resolveAudience(evt, setting.audience);
      nextAudience = Object.fromEntries(Object.keys(current).map((k) => [k, [...new Set(channels)]]));
    }

    await setting.update({
      ...(req.body.enabled !== undefined && { enabled: req.body.enabled }),
      ...(nextAudience !== undefined && { audience: nextAudience, channels: [...new Set(Object.values(nextAudience).flat())] }),
      ...(nextAudience === undefined && channels !== undefined && { channels: event_key === 'password_reset' ? [...new Set(channels)] : channels }),
    });
    res.json({ success: true, message: 'Notification setting updated', data: setting });
  } catch (error) { next(error); }
};
