import { Op } from 'sequelize';
import { Hostel, HostelRoom, HostelAllocation, Student, User, Class, Section } from '../models/index.js';
import { isOwnStudentRecord, SELF_SERVICE_ROLES } from '../middleware/access.js';

const MANAGE_ROLES = ['super_admin', 'admin', 'principal', 'hostel_warden'];

// ═══════════════════════════════════════════════════════════════════════════
// HOSTELS
// ═══════════════════════════════════════════════════════════════════════════

export const getHostels = async (req, res, next) => {
  try {
    const { search = '', type = '', status = '', campus_id = '' } = req.query;
    const where = { tenant_id: req.tenantId };
    if (type) where.type = type;
    if (status) where.status = status;
    if (campus_id) where.campus_id = campus_id;
    if (search) where.name = { [Op.iLike]: `%${search}%` };

    const hostels = await Hostel.findAll({
      where,
      include: [
        { model: User, as: 'warden', attributes: ['id', 'first_name', 'last_name'] },
        { model: HostelRoom, as: 'rooms', attributes: ['id', 'capacity', 'occupied'] },
      ],
      order: [['name', 'ASC']],
    });

    const data = hostels.map((h) => {
      const rooms = h.rooms || [];
      const totalCapacity = rooms.reduce((sum, r) => sum + r.capacity, 0);
      const totalOccupied = rooms.reduce((sum, r) => sum + r.occupied, 0);
      return { ...h.toJSON(), room_count: rooms.length, total_capacity: totalCapacity, total_occupied: totalOccupied };
    });

    res.json({ success: true, data });
  } catch (error) { next(error); }
};

export const getHostelById = async (req, res, next) => {
  try {
    const hostel = await Hostel.findOne({
      where: { id: req.params.id, tenant_id: req.tenantId },
      include: [
        { model: User, as: 'warden', attributes: ['id', 'first_name', 'last_name', 'phone'] },
        { model: HostelRoom, as: 'rooms' },
      ],
    });
    if (!hostel) return res.status(404).json({ success: false, message: 'Hostel not found' });
    res.json({ success: true, data: hostel });
  } catch (error) { next(error); }
};

export const createHostel = async (req, res, next) => {
  try {
    const { campus_id, name, type, warden_id, total_rooms, address, status } = req.body;
    if (!campus_id || !name || !type) return res.status(400).json({ success: false, message: 'campus_id, name and type are required' });
    const hostel = await Hostel.create({
      tenant_id: req.tenantId, campus_id, name, type, warden_id: warden_id || null,
      total_rooms: total_rooms || null, address: address || null, status: status || 'active',
    });
    res.status(201).json({ success: true, message: 'Hostel created', data: hostel });
  } catch (error) { next(error); }
};

export const updateHostel = async (req, res, next) => {
  try {
    const hostel = await Hostel.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!hostel) return res.status(404).json({ success: false, message: 'Hostel not found' });
    const { campus_id, name, type, warden_id, total_rooms, address, status } = req.body;
    await hostel.update({
      ...(campus_id !== undefined && { campus_id }),
      ...(name !== undefined && { name }),
      ...(type !== undefined && { type }),
      ...(warden_id !== undefined && { warden_id: warden_id || null }),
      ...(total_rooms !== undefined && { total_rooms }),
      ...(address !== undefined && { address }),
      ...(status !== undefined && { status }),
    });
    res.json({ success: true, message: 'Hostel updated', data: hostel });
  } catch (error) { next(error); }
};

export const deleteHostel = async (req, res, next) => {
  try {
    const hostel = await Hostel.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!hostel) return res.status(404).json({ success: false, message: 'Hostel not found' });
    const roomCount = await HostelRoom.count({ where: { hostel_id: hostel.id } });
    if (roomCount > 0) return res.status(400).json({ success: false, message: `This hostel has ${roomCount} room(s). Remove them first.` });
    await hostel.destroy();
    res.json({ success: true, message: 'Hostel deleted' });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// ROOMS
// ═══════════════════════════════════════════════════════════════════════════

export const getRooms = async (req, res, next) => {
  try {
    const { hostel_id = '', status = '' } = req.query;
    const where = { tenant_id: req.tenantId };
    if (hostel_id) where.hostel_id = hostel_id;
    if (status) where.status = status;
    const rooms = await HostelRoom.findAll({ where, order: [['room_number', 'ASC']] });
    res.json({ success: true, data: rooms });
  } catch (error) { next(error); }
};

export const createRoom = async (req, res, next) => {
  try {
    const { hostel_id, room_number, capacity, floor, status } = req.body;
    if (!hostel_id || !room_number) return res.status(400).json({ success: false, message: 'hostel_id and room_number are required' });
    const room = await HostelRoom.create({
      tenant_id: req.tenantId, hostel_id, room_number, capacity: capacity || 1,
      occupied: 0, floor: floor || null, status: status || 'available',
    });
    res.status(201).json({ success: true, message: 'Room created', data: room });
  } catch (error) { next(error); }
};

export const updateRoom = async (req, res, next) => {
  try {
    const room = await HostelRoom.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!room) return res.status(404).json({ success: false, message: 'Room not found' });
    const { room_number, capacity, floor, status } = req.body;
    if (capacity !== undefined && Number(capacity) < room.occupied) {
      return res.status(400).json({ success: false, message: `Cannot set capacity below current occupancy (${room.occupied} student(s) already assigned).` });
    }
    await room.update({
      ...(room_number !== undefined && { room_number }),
      ...(capacity !== undefined && { capacity }),
      ...(floor !== undefined && { floor }),
      ...(status !== undefined && { status }),
    });
    res.json({ success: true, message: 'Room updated', data: room });
  } catch (error) { next(error); }
};

export const deleteRoom = async (req, res, next) => {
  try {
    const room = await HostelRoom.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!room) return res.status(404).json({ success: false, message: 'Room not found' });
    if (room.occupied > 0) return res.status(400).json({ success: false, message: `${room.occupied} student(s) are assigned to this room. Vacate them first.` });
    await room.destroy();
    res.json({ success: true, message: 'Room deleted' });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// STUDENT ALLOCATIONS
// ═══════════════════════════════════════════════════════════════════════════

const studentInclude = {
  model: Student, as: 'student',
  attributes: ['id', 'admission_number', 'class_id', 'section_id'],
  include: [
    { model: User, as: 'user', attributes: ['id', 'first_name', 'last_name', 'phone'] },
    { model: Class, as: 'class', attributes: ['id', 'name', 'grade'] },
    { model: Section, as: 'section', attributes: ['id', 'name'] },
  ],
};

export const getRoomStudents = async (req, res, next) => {
  try {
    const room = await HostelRoom.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!room) return res.status(404).json({ success: false, message: 'Room not found' });
    const allocations = await HostelAllocation.findAll({
      where: { tenant_id: req.tenantId, room_id: room.id, status: 'active' },
      include: [studentInclude],
      order: [['createdAt', 'ASC']],
    });
    res.json({ success: true, data: allocations });
  } catch (error) { next(error); }
};

export const getStudentAllocation = async (req, res, next) => {
  try {
    // Staff may look up anyone; a student sees only their own allocation and a
    // parent only their children's.
    if (SELF_SERVICE_ROLES.includes(req.user.role)) {
      const student = await Student.findOne({ where: { id: req.params.studentId, tenant_id: req.tenantId }, attributes: ['id', 'user_id', 'parent_id'] });
      if (!isOwnStudentRecord(req.user, student)) {
        return res.status(403).json({ success: false, message: 'You can only view your own allocation' });
      }
    }
    const allocation = await HostelAllocation.findOne({
      where: { tenant_id: req.tenantId, student_id: req.params.studentId, status: 'active' },
      include: [{ model: HostelRoom, as: 'room', include: [{ model: Hostel, as: 'hostel', attributes: ['id', 'name'] }] }],
    });
    res.json({ success: true, data: allocation });
  } catch (error) { next(error); }
};

export const assignStudent = async (req, res, next) => {
  try {
    const { student_id, room_id, fee } = req.body;
    if (!student_id || !room_id) return res.status(400).json({ success: false, message: 'student_id and room_id are required' });

    const room = await HostelRoom.findOne({ where: { id: room_id, tenant_id: req.tenantId } });
    if (!room) return res.status(404).json({ success: false, message: 'Room not found' });

    // A student whose admission record says they don't board must not be
    // given a bed. Allocating one bills the family for a service they
    // declined, and the fee engine reads this same flag — so the charge
    // would appear on their statement with nothing to explain it.
    const student = await Student.findOne({ where: { id: student_id, tenant_id: req.tenantId }, include: [{ model: User, as: 'user', attributes: ['first_name', 'last_name'] }] });
    if (!student) return res.status(404).json({ success: false, message: 'Student not found' });
    if (student.hostel_required === false) {
      const name = `${student.user?.first_name || ''} ${student.user?.last_name || ''}`.trim() || 'This student';
      return res.status(400).json({
        success: false,
        message: `${name} is not registered for hostel accommodation. Update their admission record to require hostel before allocating a room.`,
      });
    }

    if (room.status === 'maintenance') {
      return res.status(400).json({ success: false, message: 'This room is under maintenance and cannot take occupants.' });
    }

    const existingHere = await HostelAllocation.findOne({ where: { tenant_id: req.tenantId, student_id, room_id, status: 'active' } });
    if (!existingHere && room.occupied >= room.capacity) {
      return res.status(400).json({ success: false, message: `This room is full (${room.occupied}/${room.capacity}).` });
    }

    const previous = await HostelAllocation.findOne({ where: { tenant_id: req.tenantId, student_id, status: 'active', room_id: { [Op.ne]: room_id } } });
    if (previous) {
      await previous.update({ status: 'vacated' });
      const prevRoom = await HostelRoom.findByPk(previous.room_id);
      if (prevRoom) await prevRoom.update({ occupied: Math.max(0, prevRoom.occupied - 1), status: prevRoom.status === 'maintenance' ? 'maintenance' : 'available' });
    }

    let allocation = existingHere;
    if (!allocation) {
      allocation = await HostelAllocation.create({
        tenant_id: req.tenantId, student_id, room_id,
        allocation_date: new Date().toISOString().slice(0, 10), fee: fee || null, status: 'active',
      });
      await room.update({ occupied: room.occupied + 1, status: room.occupied + 1 >= room.capacity ? 'occupied' : room.status });
    } else if (fee !== undefined) {
      await allocation.update({ fee });
    }

    const full = await HostelAllocation.findByPk(allocation.id, { include: [studentInclude, { model: HostelRoom, as: 'room' }] });
    res.status(201).json({ success: true, message: 'Student assigned to room', data: full });
  } catch (error) { next(error); }
};

export const vacateStudent = async (req, res, next) => {
  try {
    const allocation = await HostelAllocation.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!allocation) return res.status(404).json({ success: false, message: 'Allocation not found' });
    if (allocation.status !== 'active') return res.status(400).json({ success: false, message: 'This allocation is not active.' });

    await allocation.update({ status: 'vacated' });
    const room = await HostelRoom.findByPk(allocation.room_id);
    if (room) await room.update({ occupied: Math.max(0, room.occupied - 1), status: room.status === 'maintenance' ? 'maintenance' : 'available' });

    res.json({ success: true, message: 'Student vacated from room' });
  } catch (error) { next(error); }
};
