// FILE PATH: backend/src/controllers/backupController.js
/**
 * Full-database backup — platform developer only.
 *
 * A full backup holds EVERY school's data, so (like the SMS/email gateway settings) it is not open to any
 * school role, not even super_admin: only an email listed in DEVELOPER_EMAILS. School admins keep the
 * ordinary per-school exports in Settings → Backup & Export.
 */
import crypto from 'crypto';
import { DatabaseBackup } from '../models/index.js';
import { isDeveloper } from '../utils/developerAccess.js';
import * as drive from '../services/backup/driveStorage.js';
import * as svc from '../services/backup/backupService.js';

export const DEV_ONLY = { success: false, message: 'Database backups are restricted to the platform developer.' };

export const requireDeveloper = (req, res, next) => (isDeveloper(req.user) ? next() : res.status(403).json(DEV_ONLY));

const rowView = (b) => ({
  id: b.id, trigger: b.trigger, reason: b.reason, status: b.status, file_name: b.file_name,
  size_bytes: b.size_bytes === null ? null : Number(b.size_bytes), table_count: b.table_count,
  row_count: b.row_count === null ? null : Number(b.row_count), duration_ms: b.duration_ms,
  verify_status: b.verify_status, verify_detail: b.verify_detail, verified_at: b.verified_at,
  drive_status: b.drive_status, drive_error: b.drive_error, error: b.error, warnings: b.warnings,
  file_available: Boolean(svc.filePathFor(b)), created_at: b.createdAt,
});

const driveView = (s, req) => {
  const { clientId, clientSecret } = drive.credentialsOf(s);
  return {
    configured: Boolean(clientId && clientSecret),
    client_id: clientId || '',
    has_secret: Boolean(clientSecret),
    connected: drive.isConnected(s),
    enabled: s.drive_enabled,
    account_email: s.drive_account_email,
    folder_name: drive.FOLDER_NAME,
    connected_at: s.drive_connected_at,
    last_error: s.drive_last_error,
    redirect_uri: drive.redirectUriFor(req),
  };
};

export const getOverview = async (req, res, next) => {
  try {
    await svc.markStale();
    const s = await drive.getSettings();
    const backups = await DatabaseBackup.findAll({ order: [['createdAt', 'DESC']], limit: 40 });
    const lastGood = backups.find((b) => b.status === 'success' && b.verify_status === 'passed') || null;
    res.json({
      success: true,
      data: {
        settings: { enabled: s.enabled, run_at_hour: s.run_at_hour, retention_days: s.retention_days, protect_risky_actions: s.protect_risky_actions, time_zone: process.env.SCHOOL_TIME_ZONE || 'Africa/Dar_es_Salaam' },
        schedule_text: svc.nextRunText(s),
        running: backups.some((b) => b.status === 'running'),
        last_good: lastGood ? rowView(lastGood) : null,
        backups: backups.map(rowView),
        drive: driveView(s, req),
      },
    });
  } catch (error) { next(error); }
};

export const updateSettings = async (req, res, next) => {
  try {
    const { enabled, run_at_hour, retention_days, protect_risky_actions, drive_enabled } = req.body;
    const s = await drive.getSettings();
    const patch = {};
    if (enabled !== undefined) patch.enabled = Boolean(enabled);
    if (protect_risky_actions !== undefined) patch.protect_risky_actions = Boolean(protect_risky_actions);
    if (run_at_hour !== undefined) {
      const h = Number(run_at_hour);
      if (!Number.isInteger(h) || h < 0 || h > 23) return res.status(400).json({ success: false, message: 'Choose an hour from 0 to 23.' });
      patch.run_at_hour = h;
    }
    if (retention_days !== undefined) {
      const d = Number(retention_days);
      if (!Number.isInteger(d) || d < 3 || d > 365) return res.status(400).json({ success: false, message: 'Keep backups for 3 to 365 days.' });
      patch.retention_days = d;
    }
    if (drive_enabled !== undefined) {
      if (drive_enabled && !drive.isConnected(s)) return res.status(400).json({ success: false, message: 'Connect Google Drive first.' });
      patch.drive_enabled = Boolean(drive_enabled);
    }
    await s.update(patch);
    res.json({ success: true, message: 'Saved' });
  } catch (error) { next(error); }
};

export const runNow = async (req, res, next) => {
  try {
    const running = await DatabaseBackup.findOne({ where: { status: 'running' } });
    if (running) return res.status(409).json({ success: false, message: 'A backup is already running.' });
    const row = await svc.startBackupInBackground({ trigger: 'manual', reason: 'started from Settings', userId: req.user.id });
    res.status(202).json({ success: true, message: 'Backup started', data: rowView(row) });
  } catch (error) { next(error); }
};

export const verifyOne = async (req, res, next) => {
  try {
    const row = await DatabaseBackup.findByPk(req.params.id);
    if (!row) return res.status(404).json({ success: false, message: 'Backup not found' });
    if (!svc.filePathFor(row)) return res.status(410).json({ success: false, message: 'That backup file is no longer on the server.' });
    await row.update({ verify_status: 'pending' });
    svc.verifyExisting(row.id).catch((e) => console.error('Verify crashed:', e));
    res.status(202).json({ success: true, message: 'Restore test started' });
  } catch (error) { next(error); }
};

export const downloadOne = async (req, res, next) => {
  try {
    const row = await DatabaseBackup.findByPk(req.params.id);
    const file = row && svc.filePathFor(row);
    if (!file) return res.status(404).json({ success: false, message: 'That backup file is no longer on the server.' });
    res.download(file, row.file_name);
  } catch (error) { next(error); }
};

export const removeOne = async (req, res, next) => {
  try {
    const ok = await svc.deleteBackup(req.params.id);
    if (!ok) return res.status(404).json({ success: false, message: 'Backup not found' });
    res.json({ success: true, message: 'Backup deleted' });
  } catch (error) { next(error); }
};

export const retryDriveUpload = async (req, res, next) => {
  try {
    const row = await DatabaseBackup.findByPk(req.params.id);
    if (!row || row.status !== 'success') return res.status(404).json({ success: false, message: 'Backup not found' });
    if (row.verify_status !== 'passed') return res.status(400).json({ success: false, message: 'Only a backup that passed its restore test is copied to Google Drive.' });
    if (!svc.filePathFor(row)) return res.status(410).json({ success: false, message: 'That backup file is no longer on the server.' });
    const done = await svc.uploadToDrive(row);
    res.json({ success: done.drive_status === 'uploaded', message: done.drive_status === 'uploaded' ? 'Copied to Google Drive' : (done.drive_error || 'Upload failed') });
  } catch (error) { next(error); }
};

// ── Google Drive ────────────────────────────────────────────────────────────

export const saveDriveCredentials = async (req, res, next) => {
  try {
    const { client_id, client_secret } = req.body;
    if (!client_id && !client_secret) return res.status(400).json({ success: false, message: 'Enter the Client ID and Client Secret from Google.' });
    await drive.saveCredentials({ clientId: client_id, clientSecret: client_secret });
    res.json({ success: true, message: 'Google credentials saved. Now click Connect Google Drive.' });
  } catch (error) { next(error); }
};

export const driveAuthUrl = async (req, res, next) => {
  try {
    res.json({ success: true, data: { url: await drive.buildAuthUrl({ req, userId: req.user.id }) } });
  } catch (error) {
    if (error instanceof drive.DriveError) return res.status(400).json({ success: false, message: error.message });
    next(error);
  }
};

export const driveTest = async (req, res, next) => {
  try {
    const r = await drive.testConnection();
    res.json({ success: true, message: `Google Drive works. Backups go to the "${drive.FOLDER_NAME}" folder in ${r.email || 'your Drive'}.` });
  } catch (error) {
    if (error instanceof drive.DriveError) return res.status(400).json({ success: false, message: error.message });
    next(error);
  }
};

export const driveDisconnect = async (req, res, next) => {
  try { await drive.disconnect(); res.json({ success: true, message: 'Google Drive disconnected. Backups stay on the server only.' }); } catch (error) { next(error); }
};

// ── No-login endpoints (mounted under /webhooks, each protected by its own secret) ──

/** Google sends the browser here after the owner approves. The signed `state` proves who started it. */
export const driveCallback = async (req, res) => {
  const front = (process.env.FRONTEND_URL || 'http://localhost:5173').split(',')[0].replace(/\/+$/, '');
  const back = (q) => res.redirect(`${front}/settings?tab=database_backup&${q}`);
  try {
    if (req.query.error) return back(`drive=error&message=${encodeURIComponent(req.query.error === 'access_denied' ? 'You did not allow access.' : String(req.query.error))}`);
    await drive.completeAuthorisation({ code: String(req.query.code || ''), state: String(req.query.state || '') });
    return back('drive=connected');
  } catch (error) {
    return back(`drive=error&message=${encodeURIComponent(error.message)}`);
  }
};

/** For a hosting cron job: POST /api/v1/webhooks/backup-cron with header x-backup-token (BACKUP_CRON_TOKEN). */
export const cronRun = async (req, res, next) => {
  try {
    const want = process.env.BACKUP_CRON_TOKEN || '';
    const got = String(req.headers['x-backup-token'] || '');
    const ok = want.length >= 16 && got.length === want.length && crypto.timingSafeEqual(Buffer.from(got), Buffer.from(want));
    if (!ok) return res.status(401).json({ success: false, message: 'Not allowed.' });
    const row = await svc.runDueBackup();
    res.json({ success: true, message: row ? `Backup ${row.status}` : 'No backup was due.' });
  } catch (error) { next(error); }
};
