import { Op } from 'sequelize';
import { Vehicle, VehicleMaintenanceRecord, Route, User } from '../models/index.js';
import { publicUrlFor } from '../middleware/upload.js';
import { normalizePhone } from '../utils/phone.js';

// ═══════════════════════════════════════════════════════════════════════════
// VEHICLES
// ═══════════════════════════════════════════════════════════════════════════

export const getVehicles = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, search = '', status = '', campus_id = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (status) where.status = status;
    if (campus_id) where.campus_id = campus_id;
    if (search) {
      where[Op.or] = [
        { registration_number: { [Op.iLike]: `%${search}%` } },
        { make: { [Op.iLike]: `%${search}%` } },
        { model: { [Op.iLike]: `%${search}%` } },
        { driver_name: { [Op.iLike]: `%${search}%` } },
      ];
    }

    const { count, rows } = await Vehicle.findAndCountAll({
      where,
      include: [{ model: Route, as: 'routes', attributes: ['id', 'name'] }],
      limit: parseInt(limit), offset: parseInt(offset),
      order: [['registration_number', 'ASC']],
      distinct: true,
    });

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

export const getVehicleById = async (req, res, next) => {
  try {
    const vehicle = await Vehicle.findOne({
      where: { id: req.params.id, tenant_id: req.tenantId },
      include: [{ model: Route, as: 'routes', attributes: ['id', 'name', 'route_number'] }],
    });
    if (!vehicle) return res.status(404).json({ success: false, message: 'Vehicle not found' });
    res.json({ success: true, data: vehicle });
  } catch (error) { next(error); }
};

export const createVehicle = async (req, res, next) => {
  try {
    const { campus_id, registration_number, make, model, year, capacity, description, driver_name, driver_phone, driver_license_number, insurance_expiry, inspection_expiry, status } = req.body;
    if (!campus_id || !registration_number) return res.status(400).json({ success: false, message: 'campus_id and registration_number are required' });
    const vehicle = await Vehicle.create({
      tenant_id: req.tenantId, campus_id, registration_number,
      make: make || null, model: model || null, year: year || null, capacity: capacity || null,
      description: description || null, driver_name: driver_name || null, driver_phone: normalizePhone(driver_phone) || null,
      driver_license_number: driver_license_number || null,
      insurance_expiry: insurance_expiry || null, inspection_expiry: inspection_expiry || null,
      status: status || 'active',
    });
    res.status(201).json({ success: true, message: 'Vehicle added', data: vehicle });
  } catch (error) { next(error); }
};

export const updateVehicle = async (req, res, next) => {
  try {
    const vehicle = await Vehicle.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!vehicle) return res.status(404).json({ success: false, message: 'Vehicle not found' });
    const { campus_id, registration_number, make, model, year, capacity, description, driver_name, driver_phone, driver_license_number, insurance_expiry, inspection_expiry, status } = req.body;
    await vehicle.update({
      ...(campus_id !== undefined && { campus_id }),
      ...(registration_number !== undefined && { registration_number }),
      ...(make !== undefined && { make }),
      ...(model !== undefined && { model }),
      ...(year !== undefined && { year: year || null }),
      ...(capacity !== undefined && { capacity: capacity || null }),
      ...(description !== undefined && { description }),
      ...(driver_name !== undefined && { driver_name }),
      ...(driver_phone !== undefined && { driver_phone: normalizePhone(driver_phone) }),
      ...(driver_license_number !== undefined && { driver_license_number }),
      ...(insurance_expiry !== undefined && { insurance_expiry: insurance_expiry || null }),
      ...(inspection_expiry !== undefined && { inspection_expiry: inspection_expiry || null }),
      ...(status !== undefined && { status }),
    });
    res.json({ success: true, message: 'Vehicle updated', data: vehicle });
  } catch (error) { next(error); }
};

export const deleteVehicle = async (req, res, next) => {
  try {
    const vehicle = await Vehicle.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!vehicle) return res.status(404).json({ success: false, message: 'Vehicle not found' });
    const routeCount = await Route.count({ where: { vehicle_id: vehicle.id } });
    if (routeCount > 0) {
      return res.status(400).json({ success: false, message: `This vehicle is linked to ${routeCount} route(s). Unlink it from those routes first.` });
    }
    await VehicleMaintenanceRecord.destroy({ where: { vehicle_id: vehicle.id } });
    await vehicle.destroy();
    res.json({ success: true, message: 'Vehicle deleted' });
  } catch (error) { next(error); }
};

/** POST /transport/vehicles/:id/photo — multipart upload, field name "photo". */
export const uploadVehiclePhoto = async (req, res, next) => {
  try {
    const vehicle = await Vehicle.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!vehicle) return res.status(404).json({ success: false, message: 'Vehicle not found' });
    if (!req.file) return res.status(400).json({ success: false, message: 'No photo uploaded' });

    const url = publicUrlFor(req, 'vehicles', req.file.filename);
    await vehicle.update({ photo_url: url });
    res.json({ success: true, message: 'Photo uploaded', data: vehicle });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// MAINTENANCE RECORDS
// ═══════════════════════════════════════════════════════════════════════════

export const getMaintenanceRecords = async (req, res, next) => {
  try {
    const vehicle = await Vehicle.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!vehicle) return res.status(404).json({ success: false, message: 'Vehicle not found' });
    // Maintenance history is date-stamped, so it scopes to a year the same
    // way expenses do — a 2027 view should not list 2026 servicing.
    const { start_date = '', end_date = '' } = req.query;
    const where = { tenant_id: req.tenantId, vehicle_id: vehicle.id };
    if (start_date || end_date) {
      where.service_date = {};
      if (start_date) where.service_date[Op.gte] = start_date;
      if (end_date) where.service_date[Op.lte] = end_date;
    }

    const records = await VehicleMaintenanceRecord.findAll({
      where,
      include: [{ model: User, as: 'creator', attributes: ['id', 'first_name', 'last_name'] }],
      order: [['service_date', 'DESC']],
    });
    res.json({ success: true, data: records });
  } catch (error) { next(error); }
};

export const createMaintenanceRecord = async (req, res, next) => {
  try {
    const vehicle = await Vehicle.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!vehicle) return res.status(404).json({ success: false, message: 'Vehicle not found' });
    const { service_date, service_type, cost, performed_by, next_service_date, notes } = req.body;
    if (!service_date || !service_type) return res.status(400).json({ success: false, message: 'service_date and service_type are required' });
    const record = await VehicleMaintenanceRecord.create({
      tenant_id: req.tenantId, vehicle_id: vehicle.id, service_date, service_type,
      cost: cost || null, performed_by: performed_by || null, next_service_date: next_service_date || null,
      notes: notes || null, created_by: req.user.id,
    });
    res.status(201).json({ success: true, message: 'Maintenance record added', data: record });
  } catch (error) { next(error); }
};

export const updateMaintenanceRecord = async (req, res, next) => {
  try {
    const record = await VehicleMaintenanceRecord.findOne({ where: { id: req.params.recordId, tenant_id: req.tenantId, vehicle_id: req.params.id } });
    if (!record) return res.status(404).json({ success: false, message: 'Maintenance record not found' });
    const { service_date, service_type, cost, performed_by, next_service_date, notes } = req.body;
    await record.update({
      ...(service_date !== undefined && { service_date }),
      ...(service_type !== undefined && { service_type }),
      ...(cost !== undefined && { cost: cost || null }),
      ...(performed_by !== undefined && { performed_by }),
      ...(next_service_date !== undefined && { next_service_date: next_service_date || null }),
      ...(notes !== undefined && { notes }),
    });
    res.json({ success: true, message: 'Maintenance record updated', data: record });
  } catch (error) { next(error); }
};

export const deleteMaintenanceRecord = async (req, res, next) => {
  try {
    const record = await VehicleMaintenanceRecord.findOne({ where: { id: req.params.recordId, tenant_id: req.tenantId, vehicle_id: req.params.id } });
    if (!record) return res.status(404).json({ success: false, message: 'Maintenance record not found' });
    await record.destroy();
    res.json({ success: true, message: 'Maintenance record deleted' });
  } catch (error) { next(error); }
};