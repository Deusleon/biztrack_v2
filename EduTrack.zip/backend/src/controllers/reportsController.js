import { Op } from 'sequelize';
import {
  Student, Class,
  Attendance,
  FeeStructure, Payment,
  Expense, ExpenseCategory,
  PayrollPeriod, PayrollItem,
  Tenant, User,
  TransportAllocation, HostelAllocation,
} from '../models/index.js';
import { applyAcademicYearFilter, academicYearDateRange } from '../utils/academicYear.js';
import { findStudentsEnrolledInClass } from '../utils/classRoster.js';

const MONTH_NAMES = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

// Mirrors the same fee-annualization and opt-in-fee logic used in
// feeController.js (Fee Status), so this report's numbers always agree
// with what the Fee Status page shows for the same class.
const FREQUENCY_MULTIPLIER = { one_time: 1, monthly: 12, quarterly: 4, annually: 1 };
const billingCycles = (structure) => {
  if (structure.frequency === 'one_time' || structure.frequency === 'annually') return 1;
  return structure.billing_cycles || FREQUENCY_MULTIPLIER[structure.frequency] || 1;
};
const annualizedAmount = (structure) => Number(structure.amount || 0) * billingCycles(structure);
const usesOptionalService = (student, hasActiveAllocation, requiredFlag) =>
  hasActiveAllocation || student?.[requiredFlag] === true;
const applicableStructures = (structures, { usesTransport, usesHostel }) =>
  structures.filter((s) => s.applies_to === 'all' || (s.applies_to === 'transport' && usesTransport) || (s.applies_to === 'hostel' && usesHostel));

/** GET /reports/year-range — bounds for any "pick a year" report filter:
 * from the year this school started using the system (tenant creation)
 * to the current year. Keeps every report's year picker consistent and
 * stops anyone from accidentally generating a report for a year with no
 * data, or a year that hasn't happened yet. */
export const getYearRange = async (req, res, next) => {
  try {
    const tenant = await Tenant.findByPk(req.tenantId, { attributes: ['createdAt'] });
    const startYear = tenant ? new Date(tenant.createdAt).getFullYear() : new Date().getFullYear();
    const currentYear = new Date().getFullYear();
    res.json({ success: true, data: { start_year: Math.min(startYear, currentYear), end_year: currentYear } });
  } catch (error) { next(error); }
};

export const getFinancialSummary = async (req, res, next) => {
  try {
    const tenantId = req.tenantId;
    const tenant = await Tenant.findByPk(tenantId, { attributes: ['createdAt'] });
    const startYear = tenant ? new Date(tenant.createdAt).getFullYear() : new Date().getFullYear();
    const currentYear = new Date().getFullYear();
    const requestedYear = parseInt(req.query.year) || currentYear;
    const year = Math.min(Math.max(requestedYear, startYear), currentYear);

    const [payments, expenses, payrollPeriods] = await Promise.all([
      Payment.findAll({ where: { tenant_id: tenantId, payment_date: { [Op.gte]: `${year}-01-01`, [Op.lte]: `${year}-12-31` } }, attributes: ['amount', 'payment_date'], raw: true }),
      Expense.findAll({ where: { tenant_id: tenantId, status: { [Op.ne]: 'void' }, expense_date: { [Op.gte]: `${year}-01-01`, [Op.lte]: `${year}-12-31` } }, attributes: ['amount', 'expense_date'], raw: true }),
      PayrollPeriod.findAll({ where: { tenant_id: tenantId, year, status: 'paid' }, attributes: ['id', 'month'] }),
    ]);

    const payrollTotals = {};
    for (const period of payrollPeriods) {
      const total = await PayrollItem.sum('net_pay', { where: { payroll_period_id: period.id } });
      payrollTotals[period.month] = Number(total) || 0;
    }

    const rows = [];
    for (let m = 1; m <= 12; m++) {
      const income = payments.filter((p) => new Date(p.payment_date).getMonth() + 1 === m).reduce((s, p) => s + Number(p.amount), 0);
      const expense = expenses.filter((e) => new Date(e.expense_date).getMonth() + 1 === m).reduce((s, e) => s + Number(e.amount), 0);
      const payroll = payrollTotals[m] || 0;
      rows.push({ month: m, month_name: MONTH_NAMES[m], income, expenses: expense, payroll, net: income - expense - payroll });
    }

    const totals = rows.reduce((acc, r) => ({
      income: acc.income + r.income, expenses: acc.expenses + r.expenses, payroll: acc.payroll + r.payroll, net: acc.net + r.net,
    }), { income: 0, expenses: 0, payroll: 0, net: 0 });

    res.json({ success: true, data: { year, rows, totals } });
  } catch (error) { next(error); }
};

export const getFeeCollectionReport = async (req, res, next) => {
  try {
    const tenantId = req.tenantId;
    const { academic_year = '' } = req.query;

    const classes = await Class.findAll({ where: { tenant_id: tenantId, status: 'active' }, order: [['name', 'ASC']] });
    const rows = [];
    for (const cls of classes) {
      const structureWhere = { tenant_id: tenantId, class_id: cls.id, status: 'active' };
      applyAcademicYearFilter(structureWhere, academic_year);
      const structures = await FeeStructure.findAll({ where: structureWhere, attributes: ['id', 'amount', 'frequency', 'billing_cycles', 'applies_to'] });
      if (structures.length === 0) continue;

      const students = await Student.findAll({ where: { tenant_id: tenantId, class_id: cls.id, status: 'active' }, attributes: ['id', 'transport_required', 'hostel_required'] });
      const studentIds = students.map((s) => s.id);

      // Per-student applicability (transport/hostel are opt-in — see
      // applicableStructures) so this report's "expected" matches what
      // Fee Status shows for the same class, instead of assuming every
      // student owes every fee tied to their class.
      const [transportAllocs, hostelAllocs] = await Promise.all([
        TransportAllocation.findAll({ where: { tenant_id: tenantId, student_id: studentIds, status: 'active' }, attributes: ['student_id'] }),
        HostelAllocation.findAll({ where: { tenant_id: tenantId, student_id: studentIds, status: 'active' }, attributes: ['student_id'] }),
      ]);
      const transportSet = new Set(transportAllocs.map((a) => a.student_id));
      const hostelSet = new Set(hostelAllocs.map((a) => a.student_id));

      const expected = students.reduce((sum, s) => {
        const usesTransport = usesOptionalService(s, transportSet.has(s.id), 'transport_required');
        const usesHostel = usesOptionalService(s, hostelSet.has(s.id), 'hostel_required');
        const applicable = applicableStructures(structures, { usesTransport, usesHostel });
        return sum + applicable.reduce((sSum, f) => sSum + annualizedAmount(f), 0);
      }, 0);

      const structureIds = structures.map((f) => f.id);
      const collected = await Payment.sum('amount', { where: { tenant_id: tenantId, fee_structure_id: structureIds } }) || 0;

      rows.push({
        class_name: cls.name, grade: cls.grade, students: studentIds.length,
        expected, collected: Number(collected), outstanding: expected - Number(collected),
        collection_rate: expected > 0 ? Math.round((Number(collected) / expected) * 1000) / 10 : null,
      });
    }

    const totals = rows.reduce((acc, r) => ({ expected: acc.expected + r.expected, collected: acc.collected + r.collected, outstanding: acc.outstanding + r.outstanding }), { expected: 0, collected: 0, outstanding: 0 });

    res.json({ success: true, data: { rows, totals } });
  } catch (error) { next(error); }
};

/**
 * GET /reports/attendance-summary?start_date=&end_date=&academic_year=
 * Attendance rate by class over a date range. If no explicit dates are
 * given but an academic_year is, the range defaults to that year's real
 * calendar window (Sept–Aug) instead of "the last 30 days" — so
 * switching the global year selector actually changes what this shows,
 * the same way it already does for Fee Status.
 */
export const getAttendanceSummaryReport = async (req, res, next) => {
  try {
    const tenantId = req.tenantId;
    const { academic_year = '' } = req.query;
    const yearRange = academic_year ? academicYearDateRange(academic_year) : null;
    const endDate = req.query.end_date || yearRange?.end || new Date().toISOString().slice(0, 10);
    const startDate = req.query.start_date || yearRange?.start
      || new Date(new Date(endDate).getTime() - 29 * 86400000).toISOString().slice(0, 10);

    const classWhere = { tenant_id: tenantId, status: 'active' };
    // Only THIS year's class rows, when a year is given — otherwise a
    // school with several years of classes would double up "Form I"
    // (2025), "Form I" (2026), ... as separate rows for what should be
    // one line covering the requested window.
    if (academic_year) applyAcademicYearFilter(classWhere, academic_year);
    const classes = await Class.findAll({ where: classWhere, order: [['name', 'ASC']] });
    const rows = [];
    for (const cls of classes) {
      const records = await Attendance.findAll({ where: { tenant_id: tenantId, class_id: cls.id, date: { [Op.gte]: startDate, [Op.lte]: endDate } }, attributes: ['status'], raw: true });
      if (records.length === 0) continue;
      const present = records.filter((r) => r.status === 'present' || r.status === 'late').length;
      const absent = records.filter((r) => r.status === 'absent').length;
      const excused = records.filter((r) => r.status === 'excused').length;
      rows.push({
        class_name: cls.name, grade: cls.grade, total_records: records.length,
        present, absent, excused, attendance_rate: Math.round((present / records.length) * 1000) / 10,
      });
    }

    res.json({ success: true, data: { start_date: startDate, end_date: endDate, rows } });
  } catch (error) { next(error); }
};

/**
 * GET /reports/enrollment?academic_year= — student counts per class, by
 * gender. Scoped to ONE academic year (previously it wasn't scoped at
 * all — every class the tenant has ever had, from every year, was
 * counted together in one undifferentiated list). Each class's roster
 * uses the same historical resolution as Fee Status / Marks Sheet /
 * Class Results (see utils/classRoster.js), so a past year's enrollment
 * still reflects who was actually there, not who's in that class today.
 */
export const getEnrollmentReport = async (req, res, next) => {
  try {
    const tenantId = req.tenantId;
    const { academic_year = '' } = req.query;
    const classWhere = { tenant_id: tenantId, status: 'active' };
    applyAcademicYearFilter(classWhere, academic_year);
    const classes = await Class.findAll({ where: classWhere, order: [['name', 'ASC']] });

    const rows = [];
    for (const cls of classes) {
      const { students } = await findStudentsEnrolledInClass({ tenantId, classId: cls.id });
      const male = students.filter((s) => s.gender === 'male').length;
      const female = students.filter((s) => s.gender === 'female').length;
      rows.push({ class_name: cls.name, grade: cls.grade, education_level: cls.education_level, total: students.length, male, female });
    }

    const totals = rows.reduce((acc, r) => ({ total: acc.total + r.total, male: acc.male + r.male, female: acc.female + r.female }), { total: 0, male: 0, female: 0 });

    res.json({ success: true, data: { rows, totals } });
  } catch (error) { next(error); }
};

/** GET /reports/detailed-payments?start_date=&end_date=&academic_year= —
 * every individual payment transaction in the range, not aggregated —
 * for audit-level detail beyond the Financial Summary's monthly totals.
 * Defaults its range to the selected academic year's calendar window
 * when no explicit dates are given (see academicYearDateRange). */
export const getDetailedPayments = async (req, res, next) => {
  try {
    const tenantId = req.tenantId;
    const { academic_year = '' } = req.query;
    const yearRange = academic_year ? academicYearDateRange(academic_year) : null;
    const endDate = req.query.end_date || yearRange?.end || new Date().toISOString().slice(0, 10);
    const startDate = req.query.start_date || yearRange?.start || `${new Date(endDate).getFullYear()}-01-01`;

    const payments = await Payment.findAll({
      where: { tenant_id: tenantId, payment_date: { [Op.gte]: startDate, [Op.lte]: endDate } },
      include: [
        { model: Student, as: 'student', attributes: ['id', 'admission_number'], include: [{ model: User, as: 'user', attributes: ['first_name', 'last_name'] }] },
        { model: FeeStructure, as: 'feeStructure', attributes: ['name'] },
      ],
      order: [['payment_date', 'DESC']],
    });

    const rows = payments.map((p) => ({
      payment_date: p.payment_date,
      student_name: p.student?.user ? `${p.student.user.first_name} ${p.student.user.last_name}` : 'Unknown',
      admission_number: p.student?.admission_number || '—',
      fee_structure: p.feeStructure?.name || '—',
      amount: Number(p.amount),
      payment_method: p.payment_method,
      transaction_id: p.transaction_id || '—',
    }));
    const total = rows.reduce((s, r) => s + r.amount, 0);

    res.json({ success: true, data: { start_date: startDate, end_date: endDate, rows, total } });
  } catch (error) { next(error); }
};

/** GET /reports/detailed-expenses?start_date=&end_date=&academic_year= —
 * every individual expense transaction in the range, not aggregated.
 * Defaults its range to the selected academic year's calendar window
 * when no explicit dates are given (see academicYearDateRange). */
export const getDetailedExpenses = async (req, res, next) => {
  try {
    const tenantId = req.tenantId;
    const { academic_year = '' } = req.query;
    const yearRange = academic_year ? academicYearDateRange(academic_year) : null;
    const endDate = req.query.end_date || yearRange?.end || new Date().toISOString().slice(0, 10);
    const startDate = req.query.start_date || yearRange?.start || `${new Date(endDate).getFullYear()}-01-01`;

    const expenses = await Expense.findAll({
      where: { tenant_id: tenantId, status: { [Op.ne]: 'void' }, expense_date: { [Op.gte]: startDate, [Op.lte]: endDate } },
      include: [{ model: ExpenseCategory, as: 'category', attributes: ['name'] }],
      order: [['expense_date', 'DESC']],
    });

    const rows = expenses.map((e) => ({
      expense_date: e.expense_date,
      category: e.category?.name || 'Uncategorized',
      payee: e.payee || '—',
      amount: Number(e.amount),
      payment_method: e.payment_method,
      reference_number: e.reference_number || '—',
      description: e.description || '',
    }));
    const total = rows.reduce((s, r) => s + r.amount, 0);

    res.json({ success: true, data: { start_date: startDate, end_date: endDate, rows, total } });
  } catch (error) { next(error); }
};
