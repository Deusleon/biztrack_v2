import { Op, fn, col } from 'sequelize';
import { notifyEvent } from '../services/notificationService.js';
import { Expense, ExpenseCategory, User } from '../models/index.js';
import { publicUrlFor } from '../middleware/upload.js';
import { moneyFormatterFor } from '../utils/tenantDisplay.js';

// Authorization now happens at the route level via requirePermission()
// (see expenseRoutes.js).

// ═══════════════════════════════════════════════════════════════════════════
// CATEGORIES
// ═══════════════════════════════════════════════════════════════════════════

export const getCategories = async (req, res, next) => {
  try {
    const { status = '' } = req.query;
    const where = { tenant_id: req.tenantId };
    if (status) where.status = status;
    const categories = await ExpenseCategory.findAll({ where, order: [['name', 'ASC']] });
    res.json({ success: true, data: categories });
  } catch (error) { next(error); }
};

export const createCategory = async (req, res, next) => {
  try {
    const { name, description, status } = req.body;
    if (!name) return res.status(400).json({ success: false, message: 'name is required' });
    const category = await ExpenseCategory.create({ tenant_id: req.tenantId, name, description: description || null, status: status || 'active' });
    res.status(201).json({ success: true, message: 'Category created', data: category });
  } catch (error) { next(error); }
};

export const updateCategory = async (req, res, next) => {
  try {
    const category = await ExpenseCategory.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!category) return res.status(404).json({ success: false, message: 'Category not found' });
    const { name, description, status } = req.body;
    await category.update({
      ...(name !== undefined && { name }),
      ...(description !== undefined && { description }),
      ...(status !== undefined && { status }),
    });
    res.json({ success: true, message: 'Category updated', data: category });
  } catch (error) { next(error); }
};

export const deleteCategory = async (req, res, next) => {
  try {
    const category = await ExpenseCategory.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!category) return res.status(404).json({ success: false, message: 'Category not found' });
    const used = await Expense.count({ where: { category_id: category.id } });
    if (used > 0) return res.status(400).json({ success: false, message: `${used} expense(s) already use this category — deactivate it instead of deleting.` });
    await category.destroy();
    res.json({ success: true, message: 'Category deleted' });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// EXPENSES
// ═══════════════════════════════════════════════════════════════════════════

const expenseInclude = [
  { model: ExpenseCategory, as: 'category', attributes: ['id', 'name'] },
  { model: User, as: 'recordedBy', attributes: ['id', 'first_name', 'last_name'] },
];

export const getExpenses = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, search = '', category_id = '', payment_method = '', status = '', start_date = '', end_date = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    where.status = status || { [Op.ne]: 'void' };
    if (category_id) where.category_id = category_id;
    if (payment_method) where.payment_method = payment_method;
    if (start_date || end_date) {
      where.expense_date = {};
      if (start_date) where.expense_date[Op.gte] = start_date;
      if (end_date) where.expense_date[Op.lte] = end_date;
    }
    if (search) {
      where[Op.or] = [
        { payee: { [Op.iLike]: `%${search}%` } },
        { description: { [Op.iLike]: `%${search}%` } },
        { reference_number: { [Op.iLike]: `%${search}%` } },
      ];
    }

    const { count, rows } = await Expense.findAndCountAll({
      where, include: expenseInclude,
      limit: parseInt(limit), offset: parseInt(offset),
      order: [['expense_date', 'DESC']],
    });

    const totalResult = await Expense.sum('amount', { where });

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
      summary: { total_amount: Number(totalResult) || 0 },
    });
  } catch (error) { next(error); }
};

export const getExpenseById = async (req, res, next) => {
  try {
    const expense = await Expense.findOne({ where: { id: req.params.id, tenant_id: req.tenantId }, include: expenseInclude });
    if (!expense) return res.status(404).json({ success: false, message: 'Expense not found' });
    res.json({ success: true, data: expense });
  } catch (error) { next(error); }
};

export const createExpense = async (req, res, next) => {
  try {
    const { campus_id, category_id, amount, expense_date, payee, description, payment_method, reference_number } = req.body;
    if (!category_id || !amount || !expense_date) {
      return res.status(400).json({ success: false, message: 'category_id, amount and expense_date are required' });
    }
    const expense = await Expense.create({
      tenant_id: req.tenantId, campus_id: campus_id || null, category_id, amount, expense_date,
      payee: payee || null, description: description || null, payment_method: payment_method || 'cash',
      reference_number: reference_number || null, recorded_by: req.user.id, status: 'recorded',
    });
    const full = await Expense.findByPk(expense.id, { include: expenseInclude });
    const fmtMoney = await moneyFormatterFor(req.tenantId);
    const expenseNotice = { title: 'Expense Recorded', message: `${fmtMoney(full.amount)} recorded for ${full.category?.name || 'an expense'}${full.payee ? ` — ${full.payee}` : ''}.` };
    await notifyEvent(req.tenantId, 'expense_recorded', { parties: { accountants: expenseNotice, admins: expenseNotice } });

    res.status(201).json({ success: true, message: 'Expense recorded', data: full });
  } catch (error) { next(error); }
};

export const updateExpense = async (req, res, next) => {
  try {
    const expense = await Expense.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!expense) return res.status(404).json({ success: false, message: 'Expense not found' });
    const { campus_id, category_id, amount, expense_date, payee, description, payment_method, reference_number } = req.body;
    await expense.update({
      ...(campus_id !== undefined && { campus_id }),
      ...(category_id !== undefined && { category_id }),
      ...(amount !== undefined && { amount }),
      ...(expense_date !== undefined && { expense_date }),
      ...(payee !== undefined && { payee }),
      ...(description !== undefined && { description }),
      ...(payment_method !== undefined && { payment_method }),
      ...(reference_number !== undefined && { reference_number }),
    });
    const full = await Expense.findByPk(expense.id, { include: expenseInclude });
    res.json({ success: true, message: 'Expense updated', data: full });
  } catch (error) { next(error); }
};

export const voidExpense = async (req, res, next) => {
  try {
    const expense = await Expense.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!expense) return res.status(404).json({ success: false, message: 'Expense not found' });
    await expense.update({ status: 'void' });
    res.json({ success: true, message: 'Expense voided' });
  } catch (error) { next(error); }
};

export const uploadReceipt = async (req, res, next) => {
  try {
    const expense = await Expense.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!expense) return res.status(404).json({ success: false, message: 'Expense not found' });
    if (!req.file) return res.status(400).json({ success: false, message: 'No receipt uploaded' });
    const url = publicUrlFor(req, 'expenses', req.file.filename);
    await expense.update({ receipt_url: url });
    res.json({ success: true, message: 'Receipt uploaded', data: expense });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// SUMMARY
// ═══════════════════════════════════════════════════════════════════════════

export const getSummary = async (req, res, next) => {
  try {
    const { start_date = '', end_date = '' } = req.query;
    const where = { tenant_id: req.tenantId, status: { [Op.ne]: 'void' } };
    if (start_date || end_date) {
      where.expense_date = {};
      if (start_date) where.expense_date[Op.gte] = start_date;
      if (end_date) where.expense_date[Op.lte] = end_date;
    }

    const byCategory = await Expense.findAll({
      where, include: [{ model: ExpenseCategory, as: 'category', attributes: ['name'] }],
      attributes: ['category_id', [fn('SUM', col('amount')), 'total']],
      group: ['category_id', 'category.id', 'category.name'],
      order: [[fn('SUM', col('amount')), 'DESC']],
      raw: true, nest: true,
    });

    const total = await Expense.sum('amount', { where });

    res.json({
      success: true,
      data: {
        total_amount: Number(total) || 0,
        by_category: byCategory.map((r) => ({ category: r.category?.name || 'Uncategorized', total: Number(r.total) })),
      },
    });
  } catch (error) { next(error); }
};
