// FILE PATH: backend/src/controllers/smsController.js
import { SmsBalance, SmsTransaction, SmsGatewaySettings } from '../models/index.js';
import {
  testMesejiConnection, describeGatewayError, getMesejiSenderIds, getMesejiBatchStats,
  getMesejiBalance, buyMesejiCredits, createMesejiZenoPayOrder, checkMesejiZenoPayStatus,
  testNextSmsConnection, getNextSmsBalance,
  getSwalaAccount, testSwalaConnection, getSwalaSenderIds, getSwalaSenderRequirements, requestSwalaSenderId,
  getSwalaWalletOptions, quoteSwalaTopUp, createSwalaTopUp, getSwalaTopUp, swalaKeyMode,
} from '../services/smsService.js';
import { webhookSignature } from '../utils/webhookSignature.js';
import { isDeveloper } from '../utils/developerAccess.js';
import { planGatewayUpdate, missingCredentials, publicGatewayView } from '../utils/smsCredentialVault.js';

const ADMIN_ROLES = ['super_admin', 'admin', 'principal'];

/** Every tenant gets a lazily-created balance row the first time it's asked for. */
const getOrCreateBalance = async (tenantId) => {
  const [balance] = await SmsBalance.findOrCreate({
    where: { tenant_id: tenantId },
    defaults: { tenant_id: tenantId, balance: 0, cost_per_sms: 1 },
  });
  return balance;
};

export const getBalance = async (req, res, next) => {
  try {
    const balance = await getOrCreateBalance(req.tenantId);
    const settings = await SmsGatewaySettings.findOne({ where: { tenant_id: req.tenantId } });

    // The local row is a usage log. When a real gateway is configured, the
    // number that decides whether a send goes through lives at the
    // provider — so that is what gets shown, and the local figure is kept
    // only for reference.
    let providerBalance = null;
    let providerCredits = null; // plain number of credits — NextSMS
    let providerError = null;

    if (settings?.is_active && settings.provider === 'meseji') {
      try {
        providerBalance = await getMesejiBalance(settings);
      } catch (err) {
        providerError = describeGatewayError(err, settings.provider);
      }
    }

    if (settings?.is_active && settings.provider === 'nextsms') {
      try {
        providerCredits = await getNextSmsBalance(settings);
      } catch (err) {
        providerError = describeGatewayError(err, settings.provider);
      }
    }

    // SwalaSMS: one number (credits across the account) plus a wallet per country, and whether the key is a sandbox one.
    let swala = null;
    if (settings?.is_active && settings.provider === 'swalasms') {
      try {
        swala = await getSwalaAccount(settings);
        providerCredits = swala.balance;
      } catch (err) {
        providerError = describeGatewayError(err, settings.provider);
      }
    }

    res.json({
      success: true,
      data: {
        ...balance.toJSON(),
        provider: settings?.provider || null,
        provider_wallets: swala?.countries || null,
        provider_mode: swala?.mode || (settings?.provider === 'swalasms' ? swalaKeyMode(settings.api_key) : null),
        provider_active: Boolean(settings?.is_active) && settings?.provider !== 'simulated',
        provider_balance: providerBalance,
        provider_credits: providerCredits,
        sender_id: settings?.sender_id || null,
        provider_error: providerError,
      },
    });
  } catch (error) { next(error); }
};

/** POST /sms/top-up — starts a real top-up at the provider.
 *
 * Distinct from `purchaseBalance`, which only writes a number into the
 * local ledger. This one actually moves money: Meseji pushes a USSD
 * prompt to the payer's phone, or returns a ZenoPay checkout link.
 */
export const topUpProviderBalance = async (req, res, next) => {
  try {
    const gateway = await SmsGatewaySettings.findOne({ where: { tenant_id: req.tenantId } });
    if (gateway?.is_active && gateway.provider === 'swalasms') return await topUpSwalaSms(req, res, gateway);

    const { amount, phone, method = 'ussd', buyer_name } = req.body;
    if (!(Number(amount) > 0)) {
      return res.status(400).json({ success: false, message: 'Enter an amount greater than 0.' });
    }
    if (!phone) {
      return res.status(400).json({ success: false, message: 'A mobile money phone number is required.' });
    }

    const settings = await SmsGatewaySettings.findOne({ where: { tenant_id: req.tenantId } });
    if (!settings?.is_active || settings.provider !== 'meseji') {
      return res.status(400).json({ success: false, message: 'Top-up is only available when the Meseji gateway is active.' });
    }

    try {
      if (method === 'zenopay') {
        const order = await createMesejiZenoPayOrder(settings, {
          amount, buyerName: buyer_name || 'School', buyerPhone: phone,
        });
        return res.json({
          success: true,
          message: 'Payment order created. Complete it using the link or TAN number.',
          data: { method: 'zenopay', ...order },
        });
      }

      const result = await buyMesejiCredits(settings, { amountTzs: amount, phone });
      return res.json({
        success: true,
        message: `A USSD prompt has been sent to ${phone}. Approve it on the handset to receive the credits.`,
        data: { method: 'ussd', ...result },
      });
    } catch (err) {
      console.error('[sms:topup]', err?.cause || err);
      return res.status(400).json({ success: false, message: describeGatewayError(err, settings.provider) });
    }
  } catch (error) { next(error); }
};

/** GET /sms/top-up/:orderId — polls a ZenoPay order. Meseji credits the
 * account itself once the payment completes. */
export const checkTopUpStatus = async (req, res, next) => {
  try {
    const settings = await SmsGatewaySettings.findOne({ where: { tenant_id: req.tenantId } });
    if (settings?.provider === 'swalasms') {
      try { return res.json({ success: true, data: await getSwalaTopUp(settings, req.params.orderId) }); }
      catch (err) { return res.status(400).json({ success: false, message: describeGatewayError(err, settings.provider) }); }
    }
    if (!settings || settings.provider !== 'meseji') {
      return res.status(400).json({ success: false, message: 'Only available for the Meseji provider.' });
    }
    try {
      const data = await checkMesejiZenoPayStatus(settings, req.params.orderId);
      return res.json({ success: true, data });
    } catch (err) {
      return res.status(400).json({ success: false, message: describeGatewayError(err, settings.provider) });
    }
  } catch (error) { next(error); }
};

/** SwalaSMS top-up: the school buys `units` credits (or a fixed package) and pays by mobile money prompt or a card link. */
const topUpSwalaSms = async (req, res, settings) => {
  const { units, package_uid, payment_gateway, phone, country_uid } = req.body;
  if (!package_uid && !(Number.isInteger(Number(units)) && Number(units) >= 1 && Number(units) <= 1000000)) {
    return res.status(400).json({ success: false, message: 'Enter how many SMS credits to buy (a whole number from 1 to 1,000,000), or choose a package.' });
  }
  if (!payment_gateway) return res.status(400).json({ success: false, message: 'Choose a payment method.' });
  try {
    const order = await createSwalaTopUp(settings, { countryUid: country_uid, units, packageUid: package_uid, paymentGateway: payment_gateway, billingPhone: phone });
    const redirect = order.payment?.redirectUrl;
    const message = order.sandbox
      ? 'Sandbox top-up recorded. Nothing was charged and no credits were added (a "swl_test_" key never spends real money).'
      : redirect
        ? 'Top-up created. Open the payment link to finish paying; the credits arrive once the payment clears.'
        : `A payment prompt has been sent${phone ? ` to ${phone}` : ''}. Approve it on the handset to receive the credits.`;
    return res.json({ success: true, message, data: order });
  } catch (err) {
    console.error('[sms:swalasms:topup]', err?.cause || err);
    return res.status(400).json({ success: false, message: describeGatewayError(err, 'swalasms') });
  }
};

const activeSwala = async (req, res) => {
  const settings = await SmsGatewaySettings.findOne({ where: { tenant_id: req.tenantId } });
  if (!settings?.is_active || settings.provider !== 'swalasms') {
    res.status(400).json({ success: false, message: 'This is only available when the SwalaSMS gateway is active.' });
    return null;
  }
  return settings;
};

/** GET /messaging/sms/wallet/options — what can be bought and how it can be paid (SwalaSMS). */
export const getWalletOptions = async (req, res, next) => {
  try {
    const settings = await activeSwala(req, res); if (!settings) return;
    try { return res.json({ success: true, data: await getSwalaWalletOptions(settings, { countryUid: req.query.country_uid }) }); }
    catch (err) { return res.status(400).json({ success: false, message: describeGatewayError(err, 'swalasms') }); }
  } catch (error) { next(error); }
};

/** POST /messaging/sms/wallet/quote — what `units` credits would cost, before paying (SwalaSMS). */
export const quoteWalletTopUp = async (req, res, next) => {
  try {
    const settings = await activeSwala(req, res); if (!settings) return;
    const { country_uid, units } = req.body;
    if (!country_uid || !(Number.isInteger(Number(units)) && Number(units) >= 1)) {
      return res.status(400).json({ success: false, message: 'Choose a country and enter how many credits.' });
    }
    try { return res.json({ success: true, data: await quoteSwalaTopUp(settings, { countryUid: country_uid, units }) }); }
    catch (err) { return res.status(400).json({ success: false, message: describeGatewayError(err, 'swalasms') }); }
  } catch (error) { next(error); }
};

/** POST /sms/purchase — records a top-up. There's no real payment
 * processor wired in here (see the module guide) — this simply credits
 * the tenant's internal balance and logs the transaction, the same way
 * an admin recording a bank deposit received outside the system would. */
export const purchaseBalance = async (req, res, next) => {
  try {
    const { amount, reference, description } = req.body;
    if (!amount || Number(amount) <= 0) return res.status(400).json({ success: false, message: 'amount must be greater than 0' });

    const balance = await getOrCreateBalance(req.tenantId);
    const newBalance = Number(balance.balance) + Number(amount);
    await balance.update({ balance: newBalance });

    const transaction = await SmsTransaction.create({
      tenant_id: req.tenantId, type: 'purchase', amount: Number(amount), balance_after: newBalance,
      reference: reference || null, description: description || 'Manual top-up', created_by: req.user.id,
    });

    res.status(201).json({ success: true, message: `${amount} credit(s) added`, data: { balance, transaction } });
  } catch (error) { next(error); }
};

export const updateCostPerSms = async (req, res, next) => {
  try {
    const { cost_per_sms } = req.body;
    if (!cost_per_sms || Number(cost_per_sms) <= 0) return res.status(400).json({ success: false, message: 'cost_per_sms must be greater than 0' });
    const balance = await getOrCreateBalance(req.tenantId);
    await balance.update({ cost_per_sms });
    res.json({ success: true, message: 'Cost per SMS updated', data: balance });
  } catch (error) { next(error); }
};

export const getTransactions = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, type = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (type) where.type = type;
    const { count, rows } = await SmsTransaction.findAndCountAll({
      where, limit: parseInt(limit), offset: parseInt(offset),
      order: [['created_at', 'DESC']],
    });
    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// SMS GATEWAY SETTINGS
// ═══════════════════════════════════════════════════════════════════════════

export const getGatewaySettings = async (req, res, next) => {
  try {
    if (!isDeveloper(req.user)) {
      return res.status(403).json({ success: false, message: 'SMS gateway configuration is restricted to the platform developer.' });
    }
    const [settings] = await SmsGatewaySettings.findOrCreate({
      where: { tenant_id: req.tenantId },
      defaults: { tenant_id: req.tenantId, provider: 'simulated', is_active: false },
    });
    // Never send a secret back to the client: the live secret is masked and
    // the per-provider vault is reduced to "does a secret exist" flags.
    const data = publicGatewayView(settings);
    // This school's delivery-report URL (path only — the browser knows the
    // host). Signed, so it exists already; see utils/webhookSignature.js.
    data.nextsms_webhook_path = `/webhooks/dlr/nextsms/${req.tenantId}/${webhookSignature(req.tenantId)}`;
    data.swalasms_webhook_path = `/webhooks/dlr/swalasms/${req.tenantId}/${webhookSignature(req.tenantId, 'swalasms-dlr')}`;
    res.json({ success: true, data });
  } catch (error) { next(error); }
};

const IMPLEMENTED_PROVIDERS = ['simulated', 'beem_africa', 'nextsms', 'meseji', 'swalasms'];

export const updateGatewaySettings = async (req, res, next) => {
  try {
    if (!isDeveloper(req.user)) {
      return res.status(403).json({ success: false, message: 'SMS gateway configuration is restricted to the platform developer.' });
    }
    const { provider, is_active } = req.body;
    if (is_active && provider && !IMPLEMENTED_PROVIDERS.includes(provider)) {
      return res.status(400).json({
        success: false,
        message: `The "${provider}" provider isn't implemented in this build yet — keep "Simulated" active, or contact support to add a real provider integration.`,
      });
    }
    const [settings] = await SmsGatewaySettings.findOrCreate({
      where: { tenant_id: req.tenantId },
      defaults: { tenant_id: req.tenantId },
    });

    // Work out the credentials that will be live after this save. Each
    // provider keeps its own saved set (utils/smsCredentialVault.js), so
    // switching gateway swaps credentials in and out instead of overwriting
    // them — and a provider switched to for the first time starts empty rather
    // than inheriting the previous provider's key.
    const plan = planGatewayUpdate(settings, req.body);
    const effectiveActive = is_active !== undefined ? is_active : settings.is_active;

    // A half-filled form used to save happily and then fail on the first real
    // send. Refuse to switch a provider on until what it needs is present
    // (what is already saved for it counts).
    if (effectiveActive) {
      const problem = missingCredentials(plan.provider, plan.live);
      if (problem) return res.status(400).json({ success: false, message: problem });
    }

    await settings.update({
      provider: plan.provider,
      api_key: plan.live.api_key,
      api_secret: plan.live.api_secret,
      sender_id: plan.live.sender_id,
      system_sender_id: plan.live.system_sender_id,
      saved_credentials: plan.vault,
      ...(is_active !== undefined && { is_active }),
    });
    // Same masking as the GET above — the saved secret must not travel back
    // to the browser in the clear every time settings are saved.
    const data = publicGatewayView(settings);
    data.nextsms_webhook_path = `/webhooks/dlr/nextsms/${req.tenantId}/${webhookSignature(req.tenantId)}`;
    data.swalasms_webhook_path = `/webhooks/dlr/swalasms/${req.tenantId}/${webhookSignature(req.tenantId, 'swalasms-dlr')}`;
    res.json({ success: true, message: 'Gateway settings updated', data });
  } catch (error) { next(error); }
};

/** POST /messaging/sms/gateway/test — checks the configured gateway without
 * sending an SMS.
 *
 * Previously the only way to find out whether credentials worked was to
 * send a real message to a real person and read the failure afterwards.
 * This hits a read-only endpoint instead: it proves the host resolves, TLS
 * works and the token is accepted, and it costs nothing.
 */
export const testGatewayConnection = async (req, res, next) => {
  try {
    if (!isDeveloper(req.user)) {
      return res.status(403).json({ success: false, message: 'SMS gateway configuration is restricted to the platform developer.' });
    }

    const settings = await SmsGatewaySettings.findOne({ where: { tenant_id: req.tenantId } });
    if (!settings) {
      return res.status(400).json({ success: false, message: 'No SMS gateway configured yet.' });
    }
    if (settings.provider === 'simulated') {
      return res.json({ success: true, message: 'Simulated provider — messages are logged, not delivered. Nothing to test.' });
    }

    try {
      let result;
      switch (settings.provider) {
        case 'meseji':
          result = await testMesejiConnection(settings);
          break;
        case 'nextsms':
          result = await testNextSmsConnection(settings);
          break;
        case 'swalasms':
          result = await testSwalaConnection(settings);
          break;
        default:
          return res.status(400).json({
            success: false,
            message: `Connection testing isn't implemented for "${settings.provider}" yet. Send a single test message instead.`,
          });
      }

      // The live balance is the number that actually decides whether a
      // send goes through, so it's worth showing right here.
      const balanceNote = result?.balance !== null && result?.balance !== undefined
        ? ` Account balance: ${Number(result.balance).toLocaleString()} credit(s).`
        : '';

      return res.json({
        success: true,
        message: `Connected to ${settings.provider} successfully — ${settings.provider === 'nextsms' ? 'username and password accepted' : 'API key accepted'}.${balanceNote}${settings.provider === 'swalasms' && result.key_mode === 'sandbox' ? ' This is a SANDBOX key (swl_test_…): SwalaSMS answers as if it sent, but no SMS reaches a phone and no credit is spent. Use a live key (swl_live_…) for real sends.' : ''}${settings.provider === 'nextsms' && !settings.sender_id ? ' No Sender ID is set — sends will use NextSMS\'s default sender.' : ''}`,
        data: result,
      });
    } catch (err) {
      console.error(`[sms:test:${settings.provider}]`, err?.cause || err);
      // A failed test is a valid answer, not a server fault — report it as
      // a result the admin can act on rather than a 500.
      return res.status(400).json({ success: false, message: describeGatewayError(err, settings.provider) });
    }
  } catch (error) { next(error); }
};

/** GET /messaging/sms/gateway/sender-ids — the sender IDs registered on the
 * provider account and whether each is approved.
 *
 * A sender ID that is still `pending` is one of the most common reasons a
 * message is accepted by the API but never lands on a handset, and nothing
 * in EduTrack made that visible.
 */
export const getProviderSenderIds = async (req, res, next) => {
  try {
    if (!isDeveloper(req.user)) {
      return res.status(403).json({ success: false, message: 'SMS gateway configuration is restricted to the platform developer.' });
    }
    const settings = await SmsGatewaySettings.findOne({ where: { tenant_id: req.tenantId } });
    if (settings?.provider === 'swalasms') {
      try { return res.json({ success: true, data: await getSwalaSenderIds(settings) }); }
      catch (err) {
        console.error('[sms:sender-ids:swalasms]', err?.cause || err);
        return res.status(400).json({ success: false, message: describeGatewayError(err, settings.provider) });
      }
    }
    if (!settings || settings.provider !== 'meseji') {
      return res.status(400).json({ success: false, message: 'Sender ID lookup is only available for the Meseji and SwalaSMS providers.' });
    }

    try {
      const data = await getMesejiSenderIds(settings);
      const list = Array.isArray(data) ? data : (data.sender_ids || data.data || []);
      return res.json({ success: true, data: list });
    } catch (err) {
      console.error('[sms:sender-ids]', err?.cause || err);
      return res.status(400).json({ success: false, message: describeGatewayError(err, settings.provider) });
    }
  } catch (error) { next(error); }
};

/** GET /messaging/sms/gateway/sender-requirements — what a SwalaSMS sender-ID request needs (developer only). */
export const getSenderIdRequirements = async (req, res, next) => {
  try {
    if (!isDeveloper(req.user)) return res.status(403).json({ success: false, message: 'SMS gateway configuration is restricted to the platform developer.' });
    const settings = await activeSwala(req, res); if (!settings) return;
    try { return res.json({ success: true, data: await getSwalaSenderRequirements(settings) }); }
    catch (err) { return res.status(400).json({ success: false, message: describeGatewayError(err, 'swalasms') }); }
  } catch (error) { next(error); }
};

/** POST /messaging/sms/gateway/sender-ids — asks SwalaSMS to review a new sender ID (developer only). */
export const requestSenderId = async (req, res, next) => {
  try {
    if (!isDeveloper(req.user)) return res.status(403).json({ success: false, message: 'SMS gateway configuration is restricted to the platform developer.' });
    const settings = await activeSwala(req, res); if (!settings) return;
    const { sender_id, purpose, sample_message, country_uid } = req.body;
    if (!sender_id || !purpose || !sample_message) {
      return res.status(400).json({ success: false, message: 'A sender ID, its purpose and a sample message are all required.' });
    }
    try {
      const out = await requestSwalaSenderId(settings, { senderId: String(sender_id).trim(), purpose, sampleMessage: String(sample_message).trim(), countryUid: country_uid });
      return res.status(201).json({ success: true, message: out.message, data: out.data });
    } catch (err) { return res.status(400).json({ success: false, message: describeGatewayError(err, 'swalasms') }); }
  } catch (error) { next(error); }
};

/** GET /messaging/sms/batch/:batchId — delivery outcome for a sent batch.
 *
 * "Sent" only means the gateway accepted it. This is what answers the
 * question that actually matters: did it reach the phone?
 */
export const getBatchDeliveryStats = async (req, res, next) => {
  try {
    const settings = await SmsGatewaySettings.findOne({ where: { tenant_id: req.tenantId } });
    if (!settings || settings.provider !== 'meseji') {
      return res.status(400).json({ success: false, message: 'Delivery stats are only available for the Meseji provider.' });
    }

    try {
      const data = await getMesejiBatchStats(settings, req.params.batchId);
      return res.json({ success: true, data });
    } catch (err) {
      console.error('[sms:batch-stats]', err?.cause || err);
      return res.status(400).json({ success: false, message: describeGatewayError(err, settings.provider) });
    }
  } catch (error) { next(error); }
};