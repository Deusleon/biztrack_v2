import { can } from '../utils/permissionEngine.js';
import { Op } from 'sequelize';
import { Student, Staff, User, Class, Book, Contact } from '../models/index.js';

/**
 * GET /search?q=...
 *
 * One endpoint behind the header search box, which until now was an input
 * that did nothing at all.
 *
 * Deliberately narrow: it searches the handful of things a person actually
 * hunts for by name or number — a student, a staff member, a class, a book
 * — and returns a few of each with a link. It is not a report builder; a
 * search box that tries to search everything returns a mess.
 *
 * Results are filtered by role: a teacher searching should not be able to
 * enumerate staff salary records, and a student should find neither.
 */

const PER_TYPE_LIMIT = 5;


export const globalSearch = async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();

    // Two characters is the shortest query worth running — a single letter
    // matches most of the school and helps nobody.
    if (q.length < 2) {
      return res.json({ success: true, data: { query: q, results: [], total: 0 } });
    }

    const like = { [Op.iLike]: `%${q}%` };
    const tenantWhere = { tenant_id: req.tenantId };
    const results = [];
    const seeStudents = await can(req.user, req.tenantId, 'students.view');
    const seeStaff = await can(req.user, req.tenantId, 'staff.view_sensitive');
    const seeContacts = await can(req.user, req.tenantId, 'messages.view');

    // ── Students ────────────────────────────────────────────────────────
    if (seeStudents) {
      const students = await Student.findAll({
        where: {
          ...tenantWhere,
          [Op.or]: [
            { admission_number: like },
            { '$user.first_name$': like },
            { '$user.last_name$': like },
          ],
        },
        include: [
          { model: User, as: 'user', attributes: ['first_name', 'last_name'] },
          { model: Class, as: 'class', attributes: ['name'] },
        ],
        limit: PER_TYPE_LIMIT,
      });

      students.forEach((s) => results.push({
        type: 'student',
        label: `${s.user?.first_name || ''} ${s.user?.last_name || ''}`.trim(),
        sublabel: [s.admission_number, s.class?.name].filter(Boolean).join(' · '),
        path: `/students/${s.id}`,
      }));
    }

    // ── Staff ───────────────────────────────────────────────────────────
    if (seeStaff) {
      const staff = await Staff.findAll({
        where: {
          ...tenantWhere,
          [Op.or]: [
            { employee_number: like },
            { '$user.first_name$': like },
            { '$user.last_name$': like },
          ],
        },
        include: [{ model: User, as: 'user', attributes: ['first_name', 'last_name'] }],
        limit: PER_TYPE_LIMIT,
      });

      staff.forEach((s) => results.push({
        type: 'staff',
        label: `${s.user?.first_name || ''} ${s.user?.last_name || ''}`.trim(),
        sublabel: [s.employee_number, s.designation].filter(Boolean).join(' · '),
        path: `/staff/${s.id}`,
      }));
    }

    // ── Classes ─────────────────────────────────────────────────────────
    if (seeStudents) {
      const classes = await Class.findAll({
        where: { ...tenantWhere, name: like },
        limit: PER_TYPE_LIMIT,
      });

      classes.forEach((c) => results.push({
        type: 'class',
        label: c.name,
        sublabel: [c.grade, c.academic_year].filter(Boolean).join(' · '),
        path: `/classes/${c.id}`,
      }));
    }

    // ── Library books ───────────────────────────────────────────────────
    const books = await Book.findAll({
      where: {
        ...tenantWhere,
        [Op.or]: [{ title: like }, { author: like }, { isbn: like }],
      },
      limit: PER_TYPE_LIMIT,
    });

    books.forEach((b) => results.push({
      type: 'book',
      label: b.title,
      sublabel: [b.author, `${b.available_copies}/${b.total_copies} available`].filter(Boolean).join(' · '),
      path: '/library/books',
    }));

    // ── Messaging contacts ──────────────────────────────────────────────
    if (seeContacts) {
      const contacts = await Contact.findAll({
        where: {
          ...tenantWhere,
          [Op.or]: [{ name: like }, { phone: like }],
        },
        limit: PER_TYPE_LIMIT,
      });

      contacts.forEach((c) => results.push({
        type: 'contact',
        label: c.name,
        sublabel: [c.phone, c.type].filter(Boolean).join(' · '),
        path: '/messages/contacts',
      }));
    }

    res.json({ success: true, data: { query: q, results, total: results.length } });
  } catch (error) { next(error); }
};
