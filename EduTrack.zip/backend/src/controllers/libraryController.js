// backend/src/controllers/libraryController.js
import { Op } from 'sequelize';
import { Book, BookIssue, User, Student, StudentCharge, Class, LibrarySettings } from '../models/index.js';
import { moneyFormatterFor } from '../utils/tenantDisplay.js';
import { notifyEvent } from '../services/notificationService.js';
import { familyContactsFor } from '../utils/familyContacts.js';

// ── Fine policy ───────────────────────────────────────────────────────────
// A loan can be charged for two separate things, and they are NOT the same:
//   1. Lateness  — a daily rate, capped so a forgotten book can't accrue an
//                  unpayable fine over a long holiday.
//   2. Loss      — the book's replacement cost, charged once when a copy is
//                  written off.
// Both land in `fine_amount`, which is what actually gets collected.
//
// These were hard-coded constants, so every school on the platform fined
// TZS 500 a day and lent for 14 days whether they had agreed to it or not.
// They now come from per-tenant settings; the values below are only the
// defaults a brand-new school starts with.
const FALLBACK_SETTINGS = {
  default_loan_days: 14,
  fine_per_day: 500,
  max_fine_days: 60,
  default_replacement_cost: 0,
  max_books_per_borrower: null,
};

/** Reads (or creates) a tenant's lending rules. */
export const getLibrarySettingsFor = async (tenantId) => {
  const [settings] = await LibrarySettings.findOrCreate({
    where: { tenant_id: tenantId },
    defaults: { tenant_id: tenantId, ...FALLBACK_SETTINGS },
  });
  return settings;
};

const daysOverdue = (dueDate, asOf = new Date()) =>
  Math.max(0, Math.floor((asOf.getTime() - new Date(dueDate).getTime()) / 86400000));

/** Lateness charge, using the school's own rate and cap. */
const overdueFineFor = (dueDate, settings, asOf = new Date()) => {
  const perDay = Number(settings?.fine_per_day ?? FALLBACK_SETTINGS.fine_per_day);
  const cap = Number(settings?.max_fine_days ?? FALLBACK_SETTINGS.max_fine_days);
  if (!(perDay > 0)) return 0; // a school that doesn't fine at all
  return Math.min(daysOverdue(dueDate, asOf), cap) * perDay;
};

/** Mirrors a loan's fine onto the borrower's fee account.
 *
 * A fine that exists only inside the Library module is invisible to the
 * bursar collecting fees, so it never actually gets paid. Raising a
 * StudentCharge puts it on the student's balance, in the payment form and
 * on the receipt — described in plain words, so a parent can see exactly
 * what the money is for.
 *
 * Only students get charged: staff borrowers have no fee account to bill.
 * Idempotent — re-run whenever a loan's charges change and it updates the
 * existing charge rather than stacking duplicates.
 */
const syncFineToFeeAccount = async (tenantId, loan) => {
  try {
    const student = await Student.findOne({ where: { tenant_id: tenantId, user_id: loan.user_id } });
    if (!student) return null;

    const existing = await StudentCharge.findOne({
      where: { tenant_id: tenantId, source_type: 'book_issue', source_id: loan.id },
    });

    const total = Number(loan.fine_amount || 0);

    // Nothing owed any more (returned on time, or written off) — retire the
    // charge so it stops counting against the student.
    if (total <= 0 || loan.fine_status === 'waived') {
      if (existing && existing.status === 'active') {
        await existing.update({ status: loan.fine_status === 'waived' ? 'waived' : 'cancelled' });
      }
      return existing;
    }

    const book = loan.book || await Book.findByPk(loan.book_id);
    const title = book?.title || 'Library book';
    const copy = loan.copy_number ? ` (Copy #${loan.copy_number})` : '';
    const fmtMoney = await moneyFormatterFor(tenantId);
    const overdue = Number(loan.overdue_fine || 0);
    const replacement = Number(loan.replacement_charge || 0);

    // Spelled out so the debt explains itself wherever it surfaces — on the
    // balance, in the payment form, and on the printed receipt.
    const parts = [];
    if (replacement > 0) parts.push(`replacement ${fmtMoney(replacement)}`);
    if (overdue > 0) parts.push(`overdue fine ${fmtMoney(overdue)}`);
    const reason = loan.status === 'lost' ? 'Lost book' : 'Late return';
    const description = `Library — ${reason}: ${title}${copy}${parts.length ? ` (${parts.join(' + ')})` : ''}`;

    const cls = student.class_id ? await Class.findByPk(student.class_id, { attributes: ['academic_year'] }) : null;

    if (existing) {
      await existing.update({
        description, amount: total, status: 'active',
        academic_year: cls?.academic_year || existing.academic_year,
      });
      return existing;
    }

    return StudentCharge.create({
      tenant_id: tenantId,
      student_id: student.id,
      description,
      category: 'library',
      amount: total,
      academic_year: cls?.academic_year || null,
      source_type: 'book_issue',
      source_id: loan.id,
      status: 'active',
    });
  } catch {
    // A fine failing to reach the fee ledger must not break the library
    // action that triggered it — the loan record is still correct.
    return null;
  }
};

/** Recomputes the settlement state of a loan after its charges change.
 * A fine that's already been waived stays waived. */
const settlementFor = (loan, total, paid) => {
  if (loan.fine_status === 'waived') return { fine_status: 'waived' };
  if (total <= 0) return { fine_status: 'none' };
  if (paid >= total - 0.005) return { fine_status: 'paid' };
  return { fine_status: paid > 0 ? 'partial' : 'pending' };
};

const ADMIN_TIER = ['super_admin', 'admin', 'principal'];

// A loan that only just became overdue is worth a notification; one that has been overdue for months (because nobody ever
// opened this page, or this feature is new to the school) is flipped quietly — otherwise the first sweep would flood
// the librarian, and every borrower, with notices about old loans.
const OVERDUE_NOTICE_WINDOW_DAYS = 7;

/** Tells the librarian — and, if the school chose to, the borrower or the student's parent — about loans that just went overdue. */
const announceOverdue = async (tenantId, loans) => {
  try {
    const books = await Book.findAll({ where: { id: [...new Set(loans.map((l) => l.book_id))] }, attributes: ['id', 'title'] });
    const titleOf = new Map(books.map((b) => [b.id, b.title]));
    const users = await User.findAll({ where: { id: [...new Set(loans.map((l) => l.user_id))] }, attributes: ['id', 'first_name', 'last_name', 'phone', 'email', 'role'] });
    const userById = new Map(users.map((u) => [u.id, u]));
    const pupils = await Student.findAll({ where: { tenant_id: tenantId, user_id: users.filter((u) => u.role === 'student').map((u) => u.id) }, attributes: ['id', 'user_id'] });
    const families = await familyContactsFor(tenantId, pupils);
    const familyOf = new Map(pupils.map((p) => [p.user_id, families.get(p.id)]));

    for (const loan of loans) {
      const borrower = userById.get(loan.user_id);
      const name = [borrower?.first_name, borrower?.last_name].filter(Boolean).join(' ').trim() || 'A borrower';
      const title = titleOf.get(loan.book_id) || 'a book';
      const family = familyOf.get(loan.user_id);
      await notifyEvent(tenantId, 'book_overdue', {
        parties: {
          librarian: { title: 'Library Book Overdue', message: `"${title}" borrowed by ${name} was due on ${loan.due_date} and is now overdue.` },
          borrower: family
            ? { recipientUserId: family.userId, smsPhone: family.phone, emailTo: family.email, title: 'Library Book Overdue', message: `${name} has not returned "${title}", which was due on ${loan.due_date}. Please return it to the library.` }
            : { recipientUserId: loan.user_id, smsPhone: borrower?.phone || null, emailTo: borrower?.email || null, title: 'Library Book Overdue', message: `Your library book "${title}" was due on ${loan.due_date}. Please return it to the library.` },
        },
      });
    }
  } catch (err) { console.error('[library] overdue notices failed:', err.message); }
};

/** Recomputes any 'issued' loan whose due date has passed into 'overdue',
 * and refreshes its running fine — called before any list/summary read so
 * numbers are always current, and by a daily sweep (jobs/libraryJobs.js) so
 * the notices go out even if nobody opens the library page. A loan flips
 * from 'issued' to 'overdue' only once, which is what makes each notice
 * go out exactly once. */
export const refreshOverdueStatus = async (tenantId) => {
  // Read once for the whole sweep rather than per loan.
  const settings = await getLibrarySettingsFor(tenantId);
  const overdue = await BookIssue.findAll({
    where: { tenant_id: tenantId, status: 'issued', due_date: { [Op.lt]: new Date().toISOString().slice(0, 10) } },
  });
  const recentCutoff = new Date(Date.now() - OVERDUE_NOTICE_WINDOW_DAYS * 86400000).toISOString().slice(0, 10);
  const toAnnounce = [];
  for (const loan of overdue) {
    const fine = overdueFineFor(loan.due_date, settings);
    const total = fine + Number(loan.replacement_charge || 0);
    await loan.update({
      status: 'overdue',
      overdue_fine: fine,
      fine_amount: total,
      ...settlementFor(loan, total, Number(loan.fine_paid || 0)),
    });
    await syncFineToFeeAccount(tenantId, loan);
    if (String(loan.due_date) >= recentCutoff) toAnnounce.push(loan);
  }
  if (toAnnounce.length > 0) await announceOverdue(tenantId, toAnnounce);
  return overdue.length;
};

/** Every school that has a loan past its due date — used by the daily sweep. */
export const tenantsWithOverdueLoans = async () => {
  const rows = await BookIssue.findAll({
    where: { status: 'issued', due_date: { [Op.lt]: new Date().toISOString().slice(0, 10) } },
    attributes: ['tenant_id'], group: ['tenant_id'], raw: true,
  });
  return rows.map((r) => r.tenant_id);
};

// ═══════════════════════════════════════════════════════════════════════════
// BOOKS
// ═══════════════════════════════════════════════════════════════════════════

export const getBooks = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, search = '', category = '', status = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (category) where.category = category;
    if (status) where.status = status;
    if (search) {
      where[Op.or] = [
        { title: { [Op.iLike]: `%${search}%` } },
        { author: { [Op.iLike]: `%${search}%` } },
        { isbn: { [Op.iLike]: `%${search}%` } },
      ];
    }

    const { count, rows } = await Book.findAndCountAll({
      where, limit: parseInt(limit), offset: parseInt(offset),
      order: [['title', 'ASC']],
    });

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

export const getBookById = async (req, res, next) => {
  try {
    const book = await Book.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!book) return res.status(404).json({ success: false, message: 'Book not found' });
    res.json({ success: true, data: book });
  } catch (error) { next(error); }
};

export const createBook = async (req, res, next) => {
  try {
    const { isbn, title, author, publisher, publication_year, category, total_copies, location, status, replacement_cost } = req.body;
    if (!title) return res.status(400).json({ success: false, message: 'title is required' });
    const copies = total_copies ? Number(total_copies) : 1;
    const book = await Book.create({
      tenant_id: req.tenantId, isbn: isbn || null, title, author: author || null, publisher: publisher || null,
      publication_year: publication_year || null, category: category || null,
      total_copies: copies, available_copies: copies, location: location || null, status: status || 'active',
      replacement_cost: replacement_cost === '' || replacement_cost === undefined ? null : Number(replacement_cost),
    });
    res.status(201).json({ success: true, message: 'Book added', data: book });
  } catch (error) { next(error); }
};

export const updateBook = async (req, res, next) => {
  try {
    const book = await Book.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!book) return res.status(404).json({ success: false, message: 'Book not found' });

    const { isbn, title, author, publisher, publication_year, category, total_copies, location, status, replacement_cost } = req.body;

    let availableDelta = 0;
    if (total_copies !== undefined && Number(total_copies) !== book.total_copies) {
      availableDelta = Number(total_copies) - book.total_copies;
    }

    await book.update({
      ...(isbn !== undefined && { isbn }),
      ...(title !== undefined && { title }),
      ...(author !== undefined && { author }),
      ...(publisher !== undefined && { publisher }),
      ...(publication_year !== undefined && { publication_year }),
      ...(category !== undefined && { category }),
      ...(total_copies !== undefined && { total_copies: Number(total_copies) }),
      ...(availableDelta !== 0 && { available_copies: Math.max(0, book.available_copies + availableDelta) }),
      ...(location !== undefined && { location }),
      ...(status !== undefined && { status }),
      ...(replacement_cost !== undefined && { replacement_cost: replacement_cost === '' ? null : Number(replacement_cost) }),
    });
    res.json({ success: true, message: 'Book updated', data: book });
  } catch (error) { next(error); }
};

export const deleteBook = async (req, res, next) => {
  try {
    const book = await Book.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!book) return res.status(404).json({ success: false, message: 'Book not found' });
    // Copies still in someone's hands — including ones written off as lost,
    // which the old check missed and which still have a fine attached.
    const outstanding = await BookIssue.count({ where: { book_id: book.id, status: ['issued', 'overdue', 'lost'] } });
    if (outstanding > 0) {
      return res.status(400).json({
        success: false,
        message: `${outstanding} cop${outstanding > 1 ? 'ies are' : 'y is'} still out on loan or unreturned. All copies must be returned before this book can be deleted.`,
      });
    }

    // Unsettled money owed against this title outlives the loan itself.
    const unsettled = await BookIssue.count({
      where: { book_id: book.id, fine_status: ['pending', 'partial'] },
    });
    if (unsettled > 0) {
      return res.status(400).json({
        success: false,
        message: `${unsettled} loan${unsettled > 1 ? 's have' : ' has'} an unpaid fine against this book. Settle or waive them first.`,
      });
    }

    // Past loans are the library's borrowing history — destroying the book
    // would take that record with it (and break the rows pointing at it).
    // Retire the title instead, which keeps it off active lists while the
    // history stays intact.
    const history = await BookIssue.count({ where: { book_id: book.id } });
    if (history > 0) {
      await book.update({ status: 'inactive' });
      return res.json({
        success: true,
        message: `This book has ${history} past loan${history > 1 ? 's' : ''} on record, so it was retired rather than deleted — the borrowing history is preserved.`,
        data: book,
      });
    }

    await book.destroy();
    res.json({ success: true, message: 'Book deleted' });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// ISSUE / RETURN
// ═══════════════════════════════════════════════════════════════════════════

const issueInclude = [
  { model: Book, as: 'book', attributes: ['id', 'title', 'author', 'isbn'] },
  { model: User, as: 'user', attributes: ['id', 'first_name', 'last_name', 'role'] },
];

export const getIssues = async (req, res, next) => {
  try {
    await refreshOverdueStatus(req.tenantId);
    const {
      page = 1, limit = 20, status = '', user_id = '', book_id = '', search = '', borrower = '',
      start_date = '', end_date = '',
    } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (status) where.status = status;
    if (user_id) where.user_id = user_id;
    if (book_id) where.book_id = book_id;

    // A loan belongs to the year it was ISSUED in. Without this the list
    // returned every loan ever made, so selecting a past year still showed
    // this year's borrowing.
    if (start_date || end_date) {
      where.issue_date = {};
      if (start_date) where.issue_date[Op.gte] = start_date;
      if (end_date) where.issue_date[Op.lte] = end_date;
    }

    const include = [...issueInclude];
    if (search) {
      include[0] = { ...include[0], where: { title: { [Op.iLike]: `%${search}%` } } };
    }
    if (borrower) {
      include[1] = {
        ...include[1],
        where: {
          [Op.or]: [
            { first_name: { [Op.iLike]: `%${borrower}%` } },
            { last_name: { [Op.iLike]: `%${borrower}%` } },
          ],
        },
      };
    }

    const { count, rows } = await BookIssue.findAndCountAll({
      where, include,
      limit: parseInt(limit), offset: parseInt(offset),
      order: [['issue_date', 'DESC']],
      distinct: true,
    });

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

/** GET /library/my-books — for the logged-in user (student/staff/parent-of-student): everything they currently have out. */
export const getMyBooks = async (req, res, next) => {
  try {
    await refreshOverdueStatus(req.tenantId);
    let userIds = [req.user.id];
    if (req.user.role === 'parent') {
      const children = await Student.findAll({ where: { tenant_id: req.tenantId, parent_id: req.user.id }, attributes: ['user_id'] });
      userIds = children.map((c) => c.user_id).filter(Boolean);
    }
    const issues = await BookIssue.findAll({
      where: { tenant_id: req.tenantId, user_id: userIds },
      include: issueInclude,
      order: [['issue_date', 'DESC']],
    });
    res.json({ success: true, data: issues });
  } catch (error) { next(error); }
};

/** POST /library/issue — checks out a copy to a user. */
export const issueBook = async (req, res, next) => {
  try {
    const { book_id, user_id, due_date, copy_number } = req.body;
    if (!book_id || !user_id) return res.status(400).json({ success: false, message: 'book_id and user_id are required' });

    const book = await Book.findOne({ where: { id: book_id, tenant_id: req.tenantId } });
    if (!book) return res.status(404).json({ success: false, message: 'Book not found' });
    if (book.available_copies <= 0) return res.status(400).json({ success: false, message: 'No copies available — every copy of this book is currently on loan.' });

    const alreadyHas = await BookIssue.findOne({ where: { tenant_id: req.tenantId, book_id, user_id, status: ['issued', 'overdue'] } });
    if (alreadyHas) return res.status(400).json({ success: false, message: 'This person already has a copy of this book on loan.' });

    let copyNum = copy_number ? Number(copy_number) : null;
    if (copyNum !== null) {
      if (copyNum < 1 || copyNum > book.total_copies) {
        return res.status(400).json({ success: false, message: `Copy number must be between 1 and ${book.total_copies}.` });
      }
      const copyTaken = await BookIssue.findOne({ where: { tenant_id: req.tenantId, book_id, copy_number: copyNum, status: ['issued', 'overdue'] } });
      if (copyTaken) return res.status(400).json({ success: false, message: `Copy #${copyNum} is already out on loan — pick a different copy.` });
    }

    const issueDate = new Date();
    const settings = await getLibrarySettingsFor(req.tenantId);
    const loanDays = Number(settings.default_loan_days) || FALLBACK_SETTINGS.default_loan_days;
    const dueDate = due_date ? new Date(due_date) : new Date(issueDate.getTime() + loanDays * 86400000);

    const issue = await BookIssue.create({
      tenant_id: req.tenantId, book_id, user_id, copy_number: copyNum,
      issue_date: issueDate.toISOString().slice(0, 10), due_date: dueDate.toISOString().slice(0, 10), status: 'issued',
    });
    await book.update({ available_copies: book.available_copies - 1 });

    const full = await BookIssue.findByPk(issue.id, { include: issueInclude });
    res.status(201).json({ success: true, message: 'Book issued', data: full });
  } catch (error) { next(error); }
};

/** GET /library/books/:id/available-copies — which copy numbers
 * (1..total_copies) are free to hand out right now, for the Issue Book
 * form's copy picker. */
export const getAvailableCopies = async (req, res, next) => {
  try {
    const book = await Book.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!book) return res.status(404).json({ success: false, message: 'Book not found' });
    const takenIssues = await BookIssue.findAll({ where: { tenant_id: req.tenantId, book_id: book.id, status: ['issued', 'overdue'], copy_number: { [Op.ne]: null } }, attributes: ['copy_number'] });
    const taken = new Set(takenIssues.map((i) => i.copy_number));
    const available = [];
    for (let n = 1; n <= book.total_copies; n++) if (!taken.has(n)) available.push(n);
    res.json({ success: true, data: { total_copies: book.total_copies, available_copy_numbers: available } });
  } catch (error) { next(error); }
};

/** PUT /library/issue/:id/return — marks a loan returned and frees the copy. */
export const returnBook = async (req, res, next) => {
  try {
    const issue = await BookIssue.findOne({ where: { id: req.params.id, tenant_id: req.tenantId }, include: [{ model: Book, as: 'book' }] });
    if (!issue) return res.status(404).json({ success: false, message: 'Loan record not found' });
    if (issue.status === 'returned') return res.status(400).json({ success: false, message: 'This copy was already returned.' });

    const { remarks } = req.body;
    const returnDate = new Date();
    const daysLate = daysOverdue(issue.due_date, returnDate);
    const settings = await getLibrarySettingsFor(req.tenantId);
    const fine = overdueFineFor(issue.due_date, settings, returnDate);
    const paid = Number(issue.fine_paid || 0);

    await issue.update({
      status: 'returned', return_date: returnDate.toISOString().slice(0, 10),
      overdue_fine: fine,
      replacement_charge: 0, // the copy came back — nothing to replace
      fine_amount: fine,
      remarks: remarks || issue.remarks,
      ...settlementFor(issue, fine, paid),
    });
    if (issue.book) await issue.book.update({ available_copies: issue.book.available_copies + 1 });
    await syncFineToFeeAccount(req.tenantId, issue);

    res.json({
      success: true,
      message: daysLate > 0
        ? `Returned — ${daysLate} day(s) late, fine: ${(await moneyFormatterFor(req.tenantId))(fine)}`
        : 'Returned on time',
      data: issue,
    });
  } catch (error) { next(error); }
};

/** PUT /library/issue/:id/lost — writes a copy off as lost.
 *
 * The borrower is charged BOTH the lateness accrued up to this point AND
 * the book's replacement cost. Charging only the daily fine, as this used
 * to, meant a lost book effectively cost the borrower nothing while the
 * school silently lost a copy off its shelves.
 *
 * `replacement_cost` can be overridden per case (a damaged-beyond-repair
 * copy might be settled for less), and is snapshotted onto the loan so
 * later re-pricing of the book doesn't rewrite what the borrower was told.
 */
export const markLost = async (req, res, next) => {
  try {
    const issue = await BookIssue.findOne({ where: { id: req.params.id, tenant_id: req.tenantId }, include: [{ model: Book, as: 'book' }] });
    if (!issue) return res.status(404).json({ success: false, message: 'Loan record not found' });
    if (issue.status === 'lost') return res.status(400).json({ success: false, message: 'This copy is already written off as lost.' });
    if (issue.status === 'returned') return res.status(400).json({ success: false, message: 'This copy was returned — it can no longer be marked lost.' });

    const { remarks, replacement_cost } = req.body;

    const override = replacement_cost !== undefined && replacement_cost !== null && replacement_cost !== '';
    if (override && Number(replacement_cost) < 0) {
      return res.status(400).json({ success: false, message: 'Replacement cost cannot be negative' });
    }

    const settings = await getLibrarySettingsFor(req.tenantId);
    const replacementCharge = override
      ? Number(replacement_cost)
      : Number(issue.book?.replacement_cost ?? settings.default_replacement_cost ?? 0);

    const fine = overdueFineFor(issue.due_date, settings);
    const total = fine + replacementCharge;
    const paid = Number(issue.fine_paid || 0);

    await issue.update({
      status: 'lost',
      overdue_fine: fine,
      replacement_charge: replacementCharge,
      fine_amount: total,
      remarks: remarks || issue.remarks,
      ...settlementFor(issue, total, paid),
    });

    // The copy is gone from the shelf, so the title's total stock drops.
    // available_copies was already decremented when it was issued.
    if (issue.book) await issue.book.update({ total_copies: Math.max(0, issue.book.total_copies - 1) });

    // Put the debt on the student's fee account, described in plain words,
    // so the bursar can actually collect it.
    await syncFineToFeeAccount(req.tenantId, issue);

    const fmtMoney = await moneyFormatterFor(req.tenantId);
    const note = replacementCharge === 0
      ? ' No replacement cost is set for this book, so only the overdue fine was charged.'
      : '';

    res.json({
      success: true,
      message: `Written off as lost — ${fmtMoney(total)} charged (${fmtMoney(fine)} overdue + ${fmtMoney(replacementCharge)} replacement).${note}`,
      data: issue,
    });
  } catch (error) { next(error); }
};

/** PUT /library/issue/:id/fine — waives a fine.
 *
 * Collection deliberately does NOT happen here. A library fine is raised as
 * a charge on the student's fee account, so it is paid through Fees like
 * everything else they owe — one receipt, one balance, one place money is
 * taken, and one set of books to reconcile. A second collection point here
 * would double-count every shilling and leave the librarian holding cash
 * that the accountant has no record of.
 *
 * Body: { reason }
 */
export const settleFine = async (req, res, next) => {
  try {
    const issue = await BookIssue.findOne({ where: { id: req.params.id, tenant_id: req.tenantId }, include: [{ model: Book, as: 'book' }] });
    if (!issue) return res.status(404).json({ success: false, message: 'Loan record not found' });

    if (Number(issue.fine_amount || 0) <= 0) {
      return res.status(400).json({ success: false, message: 'There is no fine on this loan.' });
    }
    if (issue.fine_status === 'waived') {
      return res.status(400).json({ success: false, message: 'This fine has already been waived.' });
    }

    await issue.update({
      fine_status: 'waived',
      fine_waived_by: req.user.id,
      fine_waiver_reason: req.body.reason || null,
    });

    // Drop it off the student's fee account too, or they would still be
    // chased for a debt the library has written off.
    await syncFineToFeeAccount(req.tenantId, issue);

    res.json({ success: true, message: "Fine waived and removed from the student's fee balance", data: issue });
  } catch (error) { next(error); }
};

/** GET /library/settings — the school's lending rules. */
export const getSettings = async (req, res, next) => {
  try {
    const settings = await getLibrarySettingsFor(req.tenantId);
    res.json({ success: true, data: settings });
  } catch (error) { next(error); }
};

/** PUT /library/settings — change them.
 *
 * Changing the rate does NOT recalculate fines already raised: a parent
 * who was told they owe 3,000 shouldn't find it has become 6,000 because
 * the school later raised its rate. New charges use the new rate; existing
 * ones keep the figure the borrower was actually quoted.
 */
export const updateSettings = async (req, res, next) => {
  try {

    const settings = await getLibrarySettingsFor(req.tenantId);
    const { default_loan_days, fine_per_day, max_fine_days, default_replacement_cost, max_books_per_borrower } = req.body;

    const updates = {};
    if (default_loan_days !== undefined) {
      if (!(Number(default_loan_days) > 0)) return res.status(400).json({ success: false, message: 'The loan period must be at least 1 day.' });
      updates.default_loan_days = Number(default_loan_days);
    }
    if (fine_per_day !== undefined) {
      // Zero is valid and meaningful — a library that doesn't fine.
      if (Number(fine_per_day) < 0) return res.status(400).json({ success: false, message: 'The daily fine cannot be negative.' });
      updates.fine_per_day = Number(fine_per_day);
    }
    if (max_fine_days !== undefined) {
      if (!(Number(max_fine_days) > 0)) return res.status(400).json({ success: false, message: 'The fine cap must be at least 1 day.' });
      updates.max_fine_days = Number(max_fine_days);
    }
    if (default_replacement_cost !== undefined) {
      if (Number(default_replacement_cost) < 0) return res.status(400).json({ success: false, message: 'The replacement cost cannot be negative.' });
      updates.default_replacement_cost = Number(default_replacement_cost);
    }
    if (max_books_per_borrower !== undefined) {
      updates.max_books_per_borrower = max_books_per_borrower === '' || max_books_per_borrower === null
        ? null
        : Number(max_books_per_borrower);
    }

    await settings.update(updates);
    res.json({
      success: true,
      message: 'Lending rules updated. Fines already raised keep the amounts borrowers were quoted.',
      data: settings,
    });
  } catch (error) { next(error); }
};