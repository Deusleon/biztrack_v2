import fs from 'fs';
import path from 'path';
import { Student, User, StudentDocument } from '../models/index.js';
import { publicUrlFor } from '../middleware/upload.js';

const MANAGE_ROLES = ['super_admin', 'admin', 'principal'];

const uploadRoot = process.env.UPLOAD_PATH || './uploads';

/** POST /documents/students/:id/photo — sets the photo used on a
 * student's ID card (stored on their User.avatar, so it's the same
 * photo shown anywhere else in the app that displays a profile
 * picture, not a document-specific copy). */
export const uploadStudentPhoto = async (req, res, next) => {
  try {
    const student = await Student.findOne({ where: { id: req.params.id, tenant_id: req.tenantId }, include: [{ model: User, as: 'user' }] });
    if (!student || !student.user) return res.status(404).json({ success: false, message: 'Student not found' });
    if (!req.file) return res.status(400).json({ success: false, message: 'No photo uploaded' });

    const url = publicUrlFor(req, 'students', req.file.filename);
    await student.user.update({ avatar: url });
    res.json({ success: true, message: 'Photo uploaded', data: { avatar: url } });
  } catch (error) { next(error); }
};

/** GET /documents/students/:id/documents — list documents attached to a student. */
export const listStudentDocuments = async (req, res, next) => {
  try {
    const student = await Student.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!student) return res.status(404).json({ success: false, message: 'Student not found' });

    const documents = await StudentDocument.findAll({
      where: { student_id: student.id, tenant_id: req.tenantId },
      include: [{ model: User, as: 'uploader', attributes: ['id', 'first_name', 'last_name'] }],
      order: [['created_at', 'DESC']],
    });
    res.json({ success: true, data: documents });
  } catch (error) { next(error); }
};

/** POST /documents/students/:id/documents — attach a document (medical
 * form, birth certificate, report card, etc) to a student's record. */
export const uploadStudentDocument = async (req, res, next) => {
  try {
    const student = await Student.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!student) return res.status(404).json({ success: false, message: 'Student not found' });
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });

    const { category = 'other', title } = req.body;
    const url = publicUrlFor(req, 'student-documents', req.file.filename);
    const document = await StudentDocument.create({
      tenant_id: req.tenantId,
      student_id: student.id,
      category,
      title: title || null,
      file_name: req.file.originalname,
      file_url: url,
      file_size: req.file.size,
      uploaded_by: req.user.id,
    });
    res.status(201).json({ success: true, message: 'Document uploaded', data: document });
  } catch (error) { next(error); }
};

/** DELETE /documents/students/:id/documents/:docId — remove an attached document. */
export const deleteStudentDocument = async (req, res, next) => {
  try {
    const { id, docId } = req.params;
    const document = await StudentDocument.findOne({ where: { id: docId, student_id: id, tenant_id: req.tenantId } });
    if (!document) return res.status(404).json({ success: false, message: 'Document not found' });

    const filename = document.file_url.split('/').pop();
    const filePath = path.join(uploadRoot, 'student-documents', filename);
    fs.unlink(filePath, () => {}); // best-effort; row deletion below is what matters

    await document.destroy();
    res.json({ success: true, message: 'Document deleted' });
  } catch (error) { next(error); }
};
