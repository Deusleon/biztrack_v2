// backend/src/controllers/leaveController.js
import { Op } from 'sequelize';
import { notifyEvent } from '../services/notificationService.js';
import {
  LeaveType, LeaveBalance, LeaveRequest,
  User, Staff, Student, Class,
} from '../models/index.js';

const ADMIN_ROLES = ['super_admin', 'admin', 'principal'];

// ═══════════════════════════════════════════════════════════════════════════
// Approver resolution
// ═══════════════════════════════════════════════════════════════════════════

const resolvePrincipal = async (tenantId) => {
  const principal = await User.findOne({ where: { tenant_id: tenantId, role: 'principal', status: 'active' } });
  if (principal) return principal.id;
  const admin = await User.findOne({ where: { tenant_id: tenantId, role: 'admin', status: 'active' } });
  if (admin) return admin.id;
  const superAdmin = await User.findOne({ where: { tenant_id: tenantId, role: 'super_admin', status: 'active' } });
  return superAdmin?.id || null;
};

const resolveStep1Approver = async (tenantId, requesterUserId, requesterRole) => {
  if (requesterRole === 'staff') {
    const staff = await Staff.findOne({ where: { tenant_id: tenantId, user_id: requesterUserId } });
    if (staff?.reports_to_id) return staff.reports_to_id;
    return resolvePrincipal(tenantId);
  }
  const student = await Student.findOne({ where: { tenant_id: tenantId, user_id: requesterUserId } });
  if (student?.class_id) {
    const cls = await Class.findByPk(student.class_id);
    if (cls?.class_teacher_id) return cls.class_teacher_id; // already a User id
  }
  return resolvePrincipal(tenantId);
};

// ═══════════════════════════════════════════════════════════════════════════
// LEAVE TYPES
// ═══════════════════════════════════════════════════════════════════════════

export const getLeaveTypes = async (req, res, next) => {
  try {
    const { applies_to = '', status = '' } = req.query;
    const where = { tenant_id: req.tenantId };
    if (applies_to) where.applies_to = { [Op.in]: [applies_to, 'both'] };
    if (status) where.status = status;
    const types = await LeaveType.findAll({ where, order: [['name', 'ASC']] });
    res.json({ success: true, data: types });
  } catch (error) { next(error); }
};

export const createLeaveType = async (req, res, next) => {
  try {
    const { name, applies_to, has_balance, default_days_per_year, status } = req.body;
    if (!name) return res.status(400).json({ success: false, message: 'name is required' });
    const type = await LeaveType.create({
      tenant_id: req.tenantId, name, applies_to: applies_to || 'staff',
      has_balance: has_balance !== undefined ? has_balance : true,
      default_days_per_year: default_days_per_year || null, status: status || 'active',
    });
    res.status(201).json({ success: true, message: 'Leave type created', data: type });
  } catch (error) { next(error); }
};

export const updateLeaveType = async (req, res, next) => {
  try {
    const type = await LeaveType.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!type) return res.status(404).json({ success: false, message: 'Leave type not found' });
    const { name, applies_to, has_balance, default_days_per_year, status } = req.body;
    await type.update({
      ...(name !== undefined && { name }),
      ...(applies_to !== undefined && { applies_to }),
      ...(has_balance !== undefined && { has_balance }),
      ...(default_days_per_year !== undefined && { default_days_per_year }),
      ...(status !== undefined && { status }),
    });
    res.json({ success: true, message: 'Leave type updated', data: type });
  } catch (error) { next(error); }
};

export const deleteLeaveType = async (req, res, next) => {
  try {
    const type = await LeaveType.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!type) return res.status(404).json({ success: false, message: 'Leave type not found' });
    const used = await LeaveRequest.count({ where: { leave_type_id: type.id } });
    if (used > 0) {
      return res.status(400).json({ success: false, message: `${used} request(s) already use this type — deactivate it instead of deleting.` });
    }
    await type.destroy();
    res.json({ success: true, message: 'Leave type deleted' });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// LEAVE BALANCE (staff only)
// ═══════════════════════════════════════════════════════════════════════════

export const getMyBalances = async (req, res, next) => {
  try {
    const year = parseInt(req.query.year) || new Date().getFullYear();
    const types = await LeaveType.findAll({ where: { tenant_id: req.tenantId, applies_to: { [Op.in]: ['staff', 'both'] }, has_balance: true, status: 'active' } });
    const balances = [];
    for (const type of types) {
      const [balance] = await LeaveBalance.findOrCreate({
        where: { user_id: req.user.id, leave_type_id: type.id, year },
        defaults: { tenant_id: req.tenantId, user_id: req.user.id, leave_type_id: type.id, year, allocated_days: type.default_days_per_year || 0 },
      });
      balances.push({ leave_type: { id: type.id, name: type.name }, year, allocated_days: Number(balance.allocated_days), used_days: Number(balance.used_days), remaining_days: Number(balance.allocated_days) - Number(balance.used_days) });
    }
    res.json({ success: true, data: balances });
  } catch (error) { next(error); }
};

export const getUserBalances = async (req, res, next) => {
  try {
    const year = parseInt(req.query.year) || new Date().getFullYear();
    const types = await LeaveType.findAll({ where: { tenant_id: req.tenantId, applies_to: { [Op.in]: ['staff', 'both'] }, has_balance: true, status: 'active' } });
    const balances = [];
    for (const type of types) {
      const [balance] = await LeaveBalance.findOrCreate({
        where: { user_id: req.params.userId, leave_type_id: type.id, year },
        defaults: { tenant_id: req.tenantId, user_id: req.params.userId, leave_type_id: type.id, year, allocated_days: type.default_days_per_year || 0 },
      });
      balances.push({ id: balance.id, leave_type: { id: type.id, name: type.name }, year, allocated_days: Number(balance.allocated_days), used_days: Number(balance.used_days), remaining_days: Number(balance.allocated_days) - Number(balance.used_days) });
    }
    res.json({ success: true, data: balances });
  } catch (error) { next(error); }
};

export const adjustBalance = async (req, res, next) => {
  try {
    const balance = await LeaveBalance.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!balance) return res.status(404).json({ success: false, message: 'Balance record not found' });
    const { allocated_days } = req.body;
    if (allocated_days === undefined) return res.status(400).json({ success: false, message: 'allocated_days is required' });
    await balance.update({ allocated_days });
    res.json({ success: true, message: 'Balance updated', data: balance });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// LEAVE REQUESTS
// ═══════════════════════════════════════════════════════════════════════════

const requestInclude = [
  { model: User, as: 'user', attributes: ['id', 'first_name', 'last_name', 'role'] },
  { model: LeaveType, as: 'leaveType', attributes: ['id', 'name', 'has_balance'] },
  { model: User, as: 'step1Approver', attributes: ['id', 'first_name', 'last_name'] },
  { model: User, as: 'step2Approver', attributes: ['id', 'first_name', 'last_name'] },
];

const countDays = (start, end) => {
  const ms = new Date(end).getTime() - new Date(start).getTime();
  return Math.floor(ms / 86400000) + 1;
};

export const createRequest = async (req, res, next) => {
  try {
    const { leave_type_id, start_date, end_date, reason } = req.body;
    if (!leave_type_id || !start_date || !end_date) {
      return res.status(400).json({ success: false, message: 'leave_type_id, start_date and end_date are required' });
    }
    if (new Date(end_date) < new Date(start_date)) {
      return res.status(400).json({ success: false, message: 'End date cannot be before start date' });
    }

    const requesterRole = req.user.role === 'student' ? 'student' : 'staff';
    const leaveType = await LeaveType.findOne({ where: { id: leave_type_id, tenant_id: req.tenantId, status: 'active' } });
    if (!leaveType) return res.status(404).json({ success: false, message: 'Leave type not found' });
    if (leaveType.applies_to !== 'both' && leaveType.applies_to !== requesterRole) {
      return res.status(400).json({ success: false, message: `This leave type is not available to ${requesterRole}s.` });
    }

    const daysCount = countDays(start_date, end_date);

    if (requesterRole === 'staff' && leaveType.has_balance) {
      const year = new Date(start_date).getFullYear();
      const [balance] = await LeaveBalance.findOrCreate({
        where: { user_id: req.user.id, leave_type_id, year },
        defaults: { tenant_id: req.tenantId, user_id: req.user.id, leave_type_id, year, allocated_days: leaveType.default_days_per_year || 0 },
      });
      const remaining = Number(balance.allocated_days) - Number(balance.used_days);
      if (daysCount > remaining) {
        return res.status(400).json({ success: false, message: `Not enough leave balance — ${remaining} day(s) remaining for ${leaveType.name} this year, but this request needs ${daysCount}.` });
      }
    }

    const step1ApproverId = await resolveStep1Approver(req.tenantId, req.user.id, requesterRole);
    if (!step1ApproverId) {
      return res.status(400).json({ success: false, message: 'No approver could be found for this request — contact an administrator.' });
    }

    const request = await LeaveRequest.create({
      tenant_id: req.tenantId, user_id: req.user.id, requester_role: requesterRole, leave_type_id,
      start_date, end_date, days_count: daysCount, reason: reason || null,
      current_step: 1, status: 'pending', step1_approver_id: step1ApproverId,
    });

    const full = await LeaveRequest.findByPk(request.id, { include: requestInclude });
    // Whoever has to act on this needs to know it exists — previously a
    // request sat waiting with nothing to announce it.
    const requesterName = `${full.user?.first_name || ''} ${full.user?.last_name || ''}`.trim();
    await notifyEvent(req.tenantId, 'leave_request_submitted', {
      parties: {
        approvers: {
          title: 'Leave Request Awaiting Approval',
          message: `${full.user?.first_name || ''} ${full.user?.last_name || ''}`.trim()
        + ` requested ${full.days_count} day(s) of ${full.leaveType?.name || 'leave'}.`,
        },
        requester: {
          recipientUserId: full.user_id,
          title: 'Leave Request Received',
          message: `Your request for ${full.days_count} day(s) of ${full.leaveType?.name || 'leave'} was received and is waiting for approval.`,
        },
      },
    });

    res.status(201).json({ success: true, message: 'Leave request submitted', data: full });
  } catch (error) { next(error); }
};

/**
 * Restricts a leave query to one calendar year, by start date.
 *
 * A request is filed against the year the leave STARTS in: that is when
 * it's taken, and it's the year whose balance it draws from (see
 * createRequest, which derives the balance year the same way). A request
 * spanning New Year therefore belongs to the year it began.
 *
 * No year given means no restriction, so existing callers are unaffected.
 */
const applyLeaveYear = (where, year) => {
  const base = parseInt(year, 10);
  if (!base) return where;
  where.start_date = { [Op.between]: [`${base}-01-01`, `${base}-12-31`] };
  return where;
};

export const getMyRequests = async (req, res, next) => {
  try {
    const { status = '', year = '' } = req.query;
    const where = { tenant_id: req.tenantId, user_id: req.user.id };
    if (status) where.status = status;
    applyLeaveYear(where, year);
    const requests = await LeaveRequest.findAll({ where, include: requestInclude, order: [['createdAt', 'DESC']] });
    res.json({ success: true, data: requests });
  } catch (error) { next(error); }
};

export const getPendingApprovals = async (req, res, next) => {
  try {
    const requests = await LeaveRequest.findAll({
      where: {
        tenant_id: req.tenantId, status: 'pending',
        [Op.or]: [
          { current_step: 1, step1_approver_id: req.user.id },
          { current_step: 2, step2_approver_id: req.user.id },
        ],
      },
      include: requestInclude,
      order: [['createdAt', 'ASC']],
    });
    res.json({ success: true, data: requests });
  } catch (error) { next(error); }
};

export const getAllRequests = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, status = '', requester_role = '', user_id = '', year = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (status) where.status = status;
    if (requester_role) where.requester_role = requester_role;
    // A request belongs to the year the leave STARTS in — that is the year
    // it is taken and the year its balance is drawn from.
    applyLeaveYear(where, year);
    // Lets a staff or student profile page show that person's own leave
    // history without pulling the whole school's requests down first.
    if (user_id) where.user_id = user_id;

    const { count, rows } = await LeaveRequest.findAndCountAll({
      where, include: requestInclude,
      limit: parseInt(limit), offset: parseInt(offset),
      order: [['createdAt', 'DESC']],
    });
    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

export const decideRequest = async (req, res, next) => {
  try {
    const request = await LeaveRequest.findOne({ where: { id: req.params.id, tenant_id: req.tenantId }, include: [{ model: LeaveType, as: 'leaveType' }] });
    if (!request) return res.status(404).json({ success: false, message: 'Leave request not found' });
    if (request.status !== 'pending') return res.status(400).json({ success: false, message: 'This request has already been decided.' });

    const { decision, comment } = req.body;
    if (!['approved', 'rejected'].includes(decision)) return res.status(400).json({ success: false, message: "decision must be 'approved' or 'rejected'" });

    const isStep1 = request.current_step === 1 && request.step1_approver_id === req.user.id;
    const isStep2 = request.current_step === 2 && request.step2_approver_id === req.user.id;
    if (!isStep1 && !isStep2) {
      return res.status(403).json({ success: false, message: 'This request is not awaiting your decision.' });
    }

    if (isStep1) {
      await request.update({ step1_decision: decision, step1_comment: comment || null, step1_at: new Date() });
      if (decision === 'rejected') {
        await request.update({ status: 'rejected' });
      } else {
        const step2ApproverId = await resolvePrincipal(req.tenantId);
        if (!step2ApproverId || step2ApproverId === request.step1_approver_id) {
          await finalizeApproval(request);
        } else {
          await request.update({ current_step: 2, step2_approver_id: step2ApproverId });
        }
      }
    } else {
      await request.update({ step2_decision: decision, step2_comment: comment || null, step2_at: new Date() });
      if (decision === 'rejected') {
        await request.update({ status: 'rejected' });
      } else {
        await finalizeApproval(request);
      }
    }

    const full = await LeaveRequest.findByPk(request.id, { include: requestInclude });

    // Only tell the requester once the outcome is final — a request still
    // moving between approval steps hasn't been decided yet.
    if (full.status === 'approved' || full.status === 'rejected') {
      const decided = full.status === 'approved' ? 'Approved' : 'Rejected';
      const decidedName = `${full.user?.first_name || ''} ${full.user?.last_name || ''}`.trim();
      await notifyEvent(req.tenantId, 'leave_request_decided', {
        type: full.status === 'approved' ? 'success' : 'warning',
        parties: {
          requester: {
            recipientUserId: full.user_id,
            title: `Leave Request ${decided}`,
            message: `Your ${full.days_count} day(s) of ${full.leaveType?.name || 'leave'} was ${full.status}.`
          + (full.step2_comment || full.step1_comment ? ` Note: ${full.step2_comment || full.step1_comment}` : ''),
          },
          admins: {
            title: `Leave Request ${decided}`,
            message: `${decidedName || 'A staff member'}'s ${full.days_count} day(s) of ${full.leaveType?.name || 'leave'} was ${full.status}.`,
          },
        },
      });
    }

    res.json({ success: true, message: `Request ${full.status}`, data: full });
  } catch (error) { next(error); }
};

async function finalizeApproval(request) {
  await request.update({ status: 'approved' });
  if (request.requester_role === 'staff' && request.leaveType?.has_balance) {
    const year = new Date(request.start_date).getFullYear();
    const [balance] = await LeaveBalance.findOrCreate({
      where: { user_id: request.user_id, leave_type_id: request.leave_type_id, year },
      defaults: { tenant_id: request.tenant_id, user_id: request.user_id, leave_type_id: request.leave_type_id, year, allocated_days: 0 },
    });
    await balance.update({ used_days: Number(balance.used_days) + Number(request.days_count) });
  }
}

export const cancelRequest = async (req, res, next) => {
  try {
    const request = await LeaveRequest.findOne({ where: { id: req.params.id, tenant_id: req.tenantId, user_id: req.user.id } });
    if (!request) return res.status(404).json({ success: false, message: 'Leave request not found' });
    if (request.status !== 'pending') return res.status(400).json({ success: false, message: 'Only pending requests can be cancelled.' });
    await request.update({ status: 'cancelled' });
    res.json({ success: true, message: 'Request cancelled' });
  } catch (error) { next(error); }
};