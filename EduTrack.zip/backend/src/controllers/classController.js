// FILE PATH: backend/src/controllers/classController.js
import { Class, Section, Campus, User, Student, Tenant } from '../models/index.js';
import { Op } from 'sequelize';
import { applyAcademicYearFilter, resolveAcademicYearForLevel, currentBaseYear } from '../utils/academicYear.js';

export const classController = {
  async getAll(req, res, next) {
    try {
      const {
        page = 1, limit = 10, search = '', status = '',
        campus_id = '', academic_year = '', grade = '', education_level = '',
        sortBy = 'name', sortOrder = 'ASC',
      } = req.query;

      const offset = (page - 1) * limit;
      const where = { tenant_id: req.tenantId };

      if (status) where.status = status;
      if (campus_id) where.campus_id = campus_id;
      // Base-year match, not exact-string: the global year selector is
      // always one format ("2026-2027") while Primary/O-Level classes
      // store the other ("2026") — see utils/academicYear.js.
      applyAcademicYearFilter(where, academic_year);
      if (education_level) where.education_level = education_level;
      if (grade) where.grade = { [Op.iLike]: `%${grade}%` };
      if (search) {
        where[Op.or] = [
          { name: { [Op.iLike]: `%${search}%` } },
          { grade: { [Op.iLike]: `%${search}%` } },
        ];
      }

      const { count, rows: classes } = await Class.findAndCountAll({
        where,
        include: [
          { model: Campus, as: 'campus', attributes: ['id', 'name', 'code'] },
          { model: Section, as: 'sections', attributes: ['id', 'name', 'capacity', 'status'] },
        ],
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [[sortBy, sortOrder]],
        distinct: true,
      });

      res.json({
        success: true,
        data: classes,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(count / limit),
          totalItems: count,
          itemsPerPage: parseInt(limit),
        },
      });
    } catch (error) {
      next(error);
    }
  },

  async getById(req, res, next) {
    try {
      const { id } = req.params;
      const cls = await Class.findOne({
        where: { id, tenant_id: req.tenantId },
        include: [
          { model: Campus, as: 'campus' },
          {
            model: Section, as: 'sections',
            include: [
              { model: User, as: 'classTeacher', attributes: ['id', 'first_name', 'last_name', 'email'] },
              { model: Student, as: 'students', attributes: ['id'] },
            ],
          },
        ],
      });

      if (!cls) {
        return res.status(404).json({ success: false, message: 'Class not found' });
      }

      res.json({ success: true, data: cls });
    } catch (error) {
      next(error);
    }
  },

  async create(req, res, next) {
    try {
      const {
        campus_id, name, grade, education_level, academic_year,
        capacity, description, status = 'active',
      } = req.body;

      const campus = await Campus.findOne({ where: { id: campus_id, tenant_id: req.tenantId } });
      if (!campus) {
        return res.status(400).json({ success: false, message: 'Invalid campus ID' });
      }

      // Check uniqueness: same name + grade + campus + academic_year
      const existing = await Class.findOne({
        where: { name, grade, campus_id, academic_year, tenant_id: req.tenantId },
      });
      if (existing) {
        return res.status(400).json({ success: false, message: 'A class with the same name and grade already exists for this campus and academic year' });
      }

      const cls = await Class.create({
        tenant_id: req.tenantId, campus_id, name, grade,
        education_level: education_level || 'o_level', academic_year,
        capacity: capacity || null, description: description || null, status,
      });

      const created = await Class.findByPk(cls.id, {
        include: [{ model: Campus, as: 'campus' }, { model: Section, as: 'sections' }],
      });

      res.status(201).json({ success: true, message: 'Class created successfully', data: created });
    } catch (error) {
      next(error);
    }
  },

  async update(req, res, next) {
    try {
      const { id } = req.params;
      const cls = await Class.findOne({ where: { id, tenant_id: req.tenantId } });

      if (!cls) {
        return res.status(404).json({ success: false, message: 'Class not found' });
      }

      const { campus_id, name, grade, education_level, academic_year, capacity, description, status } = req.body;

      // Uniqueness check if key fields changed
      if (name || grade || campus_id || academic_year) {
        const dup = await Class.findOne({
          where: {
            name: name || cls.name,
            grade: grade || cls.grade,
            campus_id: campus_id || cls.campus_id,
            academic_year: academic_year || cls.academic_year,
            tenant_id: req.tenantId,
            id: { [Op.ne]: id },
          },
        });
        if (dup) {
          return res.status(400).json({ success: false, message: 'A class with the same name and grade already exists' });
        }
      }

      const u = {};
      if (campus_id) u.campus_id = campus_id;
      if (name) u.name = name;
      if (grade) u.grade = grade;
      if (education_level) u.education_level = education_level;
      if (academic_year) u.academic_year = academic_year;
      if (capacity !== undefined) u.capacity = capacity || null;
      if (description !== undefined) u.description = description || null;
      if (status) u.status = status;

      await cls.update(u);

      const updated = await Class.findByPk(id, {
        include: [{ model: Campus, as: 'campus' }, { model: Section, as: 'sections' }],
      });

      res.json({ success: true, message: 'Class updated successfully', data: updated });
    } catch (error) {
      next(error);
    }
  },

  async delete(req, res, next) {
    try {
      const { id } = req.params;
      const cls = await Class.findOne({ where: { id, tenant_id: req.tenantId } });
      if (!cls) {
        return res.status(404).json({ success: false, message: 'Class not found' });
      }
      await cls.update({ status: 'inactive' });
      res.json({ success: true, message: 'Class deactivated successfully' });
    } catch (error) {
      next(error);
    }
  },

  async permanentDelete(req, res, next) {
    try {
      const { id } = req.params;
      const cls = await Class.findOne({ where: { id, tenant_id: req.tenantId } });
      if (!cls) {
        return res.status(404).json({ success: false, message: 'Class not found' });
      }
      await cls.destroy();
      res.json({ success: true, message: 'Class permanently deleted' });
    } catch (error) {
      next(error);
    }
  },

  async reactivate(req, res, next) {
    try {
      const { id } = req.params;
      const cls = await Class.findOne({ where: { id, tenant_id: req.tenantId } });
      if (!cls) {
        return res.status(404).json({ success: false, message: 'Class not found' });
      }
      await cls.update({ status: 'active' });
      res.json({ success: true, message: 'Class reactivated successfully', data: cls });
    } catch (error) {
      next(error);
    }
  },

  async bulkUpdateStatus(req, res, next) {
    try {
      const { ids, status } = req.body;
      if (!ids || !Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ success: false, message: 'Please provide class IDs' });
      }
      if (!['active', 'inactive'].includes(status)) {
        return res.status(400).json({ success: false, message: 'Invalid status value' });
      }
      await Class.update({ status }, { where: { id: { [Op.in]: ids }, tenant_id: req.tenantId } });
      res.json({ success: true, message: `${ids.length} class(es) updated successfully` });
    } catch (error) {
      next(error);
    }
  },

  async getStats(req, res, next) {
    try {
      const { id } = req.params;
      const cls = await Class.findOne({
        where: { id, tenant_id: req.tenantId },
        include: [{ model: Section, as: 'sections' }],
      });
      if (!cls) {
        return res.status(404).json({ success: false, message: 'Class not found' });
      }

      const totalStudents = await Student.count({ where: { class_id: id, tenant_id: req.tenantId } });
      const activeStudents = await Student.count({ where: { class_id: id, tenant_id: req.tenantId, status: 'active' } });

      const stats = {
        total_sections: cls.sections?.length || 0,
        active_sections: cls.sections?.filter(s => s.status === 'active').length || 0,
        total_students: totalStudents,
        active_students: activeStudents,
        capacity: cls.capacity || 0,
        occupancy_rate: cls.capacity ? Math.round((totalStudents / cls.capacity) * 100) : 0,
      };

      res.json({ success: true, data: stats });
    } catch (error) {
      next(error);
    }
  },

  // ─── Section sub-routes ──────────────────────────────────────────────────

  async addSection(req, res, next) {
    try {
      const { id: class_id } = req.params;
      const cls = await Class.findOne({ where: { id: class_id, tenant_id: req.tenantId } });
      if (!cls) {
        return res.status(404).json({ success: false, message: 'Class not found' });
      }

      const { name, class_teacher_id, capacity } = req.body;
      if (!name) {
        return res.status(400).json({ success: false, message: 'Section name is required' });
      }

      const existing = await Section.findOne({ where: { name, class_id, tenant_id: req.tenantId } });
      if (existing) {
        return res.status(400).json({ success: false, message: 'Section with this name already exists in this class' });
      }

      const section = await Section.create({
        tenant_id: req.tenantId, class_id, name,
        class_teacher_id: class_teacher_id || null,
        capacity: capacity || null,
        status: 'active',
      });

      const created = await Section.findByPk(section.id, {
        include: [{ model: User, as: 'classTeacher', attributes: ['id', 'first_name', 'last_name', 'email'] }],
      });

      res.status(201).json({ success: true, message: 'Section created successfully', data: created });
    } catch (error) {
      next(error);
    }
  },

  async updateSection(req, res, next) {
    try {
      const { id: class_id, sectionId } = req.params;
      const section = await Section.findOne({ where: { id: sectionId, class_id, tenant_id: req.tenantId } });
      if (!section) {
        return res.status(404).json({ success: false, message: 'Section not found' });
      }

      const { name, class_teacher_id, capacity, status } = req.body;
      const u = {};
      if (name) u.name = name;
      if (class_teacher_id !== undefined) u.class_teacher_id = class_teacher_id || null;
      if (capacity !== undefined) u.capacity = capacity || null;
      if (status) u.status = status;

      await section.update(u);

      const updated = await Section.findByPk(sectionId, {
        include: [{ model: User, as: 'classTeacher', attributes: ['id', 'first_name', 'last_name', 'email'] }],
      });

      res.json({ success: true, message: 'Section updated successfully', data: updated });
    } catch (error) {
      next(error);
    }
  },

  async deleteSection(req, res, next) {
    try {
      const { id: class_id, sectionId } = req.params;
      const section = await Section.findOne({ where: { id: sectionId, class_id, tenant_id: req.tenantId } });
      if (!section) {
        return res.status(404).json({ success: false, message: 'Section not found' });
      }
      await section.destroy();
      res.json({ success: true, message: 'Section deleted successfully' });
    } catch (error) {
      next(error);
    }
  },

  /**
   * POST /classes/clone-year
   * Body: { from_academic_year, to_academic_year, campus_id? }
   *
   * A school's grade structure ("Form I" through "Form IV", "Standard 1"
   * through "Standard 7", ...) doesn't change year to year — only the
   * academic year tag does. Without this, every single class had to be
   * re-created by hand each year before Promotion could even run, which
   * is exactly the busywork a "move to the next year" feature should be
   * removing, not creating.
   *
   * This clones every active class found in `from_academic_year` into
   * `to_academic_year`, keeping name/grade/education_level/capacity/
   * description identical and only changing the academic year — resolved
   * PER CLASS to that class's own education level's format, exactly like
   * every other academic-year-aware write in the app (see
   * resolveAcademicYearForLevel in utils/academicYear.js), so a Primary
   * class ends up tagged "2027" even though the request said "2027-2028".
   * Sections are cloned too (same name/capacity/class_teacher), since a
   * class with zero streams isn't usable yet.
   *
   * Safe to click more than once: a class that already exists for the
   * target year (by name + grade + campus + resolved academic year) is
   * left alone rather than duplicated, so re-running after fixing one
   * missing class doesn't recreate the ones already handled.
   */
  async cloneClassesForNewYear(req, res, next) {
    try {
      const { from_academic_year: fromYear, to_academic_year: toYear, campus_id: campusId = '' } = req.body;
      if (!fromYear || !toYear) {
        return res.status(400).json({ success: false, message: 'Both the year being closed and the year being opened are required.' });
      }

      const sourceWhere = { tenant_id: req.tenantId, status: 'active' };
      applyAcademicYearFilter(sourceWhere, fromYear);
      if (campusId) sourceWhere.campus_id = campusId;

      const sourceClasses = await Class.findAll({
        where: sourceWhere,
        include: [{ model: Section, as: 'sections' }],
        order: [['grade', 'ASC'], ['name', 'ASC']],
      });

      if (sourceClasses.length === 0) {
        return res.json({ success: true, message: `No classes found for ${fromYear} to clone.`, data: { created: [], skipped: [] } });
      }

      const created = [];
      const skipped = [];

      for (const source of sourceClasses) {
        const targetYear = resolveAcademicYearForLevel(toYear, source.education_level);

        const existing = await Class.findOne({
          where: {
            tenant_id: req.tenantId, campus_id: source.campus_id,
            name: source.name, grade: source.grade, academic_year: targetYear,
          },
        });
        if (existing) {
          skipped.push({ name: source.name, grade: source.grade, academic_year: targetYear, reason: 'already exists' });
          continue;
        }

        const clone = await Class.create({
          tenant_id: req.tenantId,
          campus_id: source.campus_id,
          name: source.name,
          grade: source.grade,
          education_level: source.education_level,
          academic_year: targetYear,
          capacity: source.capacity,
          description: source.description,
          status: 'active',
        });

        for (const section of source.sections || []) {
          await Section.create({
            tenant_id: req.tenantId,
            class_id: clone.id,
            name: section.name,
            class_teacher_id: section.class_teacher_id,
            capacity: section.capacity,
            status: 'active',
          });
        }

        created.push({ name: clone.name, grade: clone.grade, academic_year: clone.academic_year });
      }

      res.status(201).json({
        success: true,
        message: created.length > 0
          ? `Created ${created.length} class(es) for ${toYear}${skipped.length ? `, ${skipped.length} already existed` : ''}.`
          : `Every class for ${toYear} already existed — nothing to create.`,
        data: { created, skipped },
      });
    } catch (error) {
      next(error);
    }
  },
};

/**
 * Public — no login required, called from the tenant's website (see
 * routes/publicRoutes.js). Just enough for a "Program" picker on an
 * admission form: id, name, grade, education_level for active classes
 * in the current academic year. Nothing about capacity, enrolment, or
 * anything else internal.
 */
export const getPublicClasses = async (req, res, next) => {
  try {
    const tenant = await Tenant.findOne({ where: { slug: req.params.tenantSlug } });
    if (!tenant) {
      return res.status(404).json({ success: false, message: 'Class list is not available.' });
    }

    const academicYear = req.query.academic_year || String(currentBaseYear());
    const classes = await Class.findAll({
      where: applyAcademicYearFilter({ tenant_id: tenant.id, status: 'active' }, academicYear, 'Class.academic_year'),
      attributes: ['id', 'name', 'grade', 'education_level'],
      order: [['name', 'ASC']],
    });

    res.json({ success: true, academic_year: academicYear, data: classes });
  } catch (error) { next(error); }
};