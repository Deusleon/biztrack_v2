import { randomUUID } from 'crypto';
import { Op } from 'sequelize';
import sequelize from '../config/database.js';
import {
  Student, User, Class, Section, StudentPromotion,
} from '../models/index.js';
import { ensureBackupBeforeRiskyAction } from '../services/backup/backupService.js';
import { applyAcademicYearFilter } from '../utils/academicYear.js';
import { gradeNumber, isFinalGrade as isFinalGradeOf } from '../utils/gradeLevels.js';

const MANAGE_ROLES = ['super_admin', 'admin', 'principal'];

/** Thin wrapper kept for readability at call sites below — the shared
 * helper takes (education_level, grade) separately so it can be reused
 * without a Class instance; this restores the "pass the class" shape
 * this file used before the logic moved to utils/gradeLevels.js. */
const isFinalGrade = (cls) => isFinalGradeOf(cls.education_level, cls.grade);


/**
 * Finds the class a student should move INTO.
 *
 * Matched on campus, education level and grade number rather than name,
 * because "Form II" and "Form 2" are the same class written two ways and a
 * name match would silently find neither.
 */
const findTargetClass = (classes, { fromClass, targetGrade }) =>
  classes.find((c) =>
    c.campus_id === fromClass.campus_id
    && c.education_level === fromClass.education_level
    && gradeNumber(c.grade) === targetGrade) || null;

/**
 * GET /promotions/preview?from_academic_year=&to_academic_year=&class_id=
 *
 * Shows what WOULD happen before anything is changed. A promotion run
 * touches every student in the school at once, so it must be inspectable
 * first — this is the step that catches a missing target class before it
 * strands a whole form.
 */
export const getPromotionPreview = async (req, res, next) => {
  try {

    const { from_academic_year: fromYear, to_academic_year: toYear, class_id: classId = '', campus_id: campusId = '' } = req.query;
    if (!fromYear || !toYear) {
      return res.status(400).json({ success: false, message: 'Both the year being closed and the year being opened are required.' });
    }
    if (fromYear === toYear) {
      return res.status(400).json({ success: false, message: 'The two academic years must be different.' });
    }

    // Base-year match, not exact-string: fromYear/toYear come from the
    // single global selector (always the span format, "2026-2027"), while
    // Primary/O-Level classes store a single year ("2026"). An exact match
    // would silently find zero source/target classes for those levels —
    // see utils/academicYear.js.
    const sourceWhere = { tenant_id: req.tenantId };
    applyAcademicYearFilter(sourceWhere, fromYear);
    if (classId) sourceWhere.id = classId;
    if (campusId) sourceWhere.campus_id = campusId;

    const targetWhere = { tenant_id: req.tenantId };
    applyAcademicYearFilter(targetWhere, toYear);

    const [sourceClasses, targetClasses] = await Promise.all([
      Class.findAll({ where: sourceWhere }),
      Class.findAll({ where: targetWhere }),
    ]);

    if (sourceClasses.length === 0) {
      return res.json({
        success: true,
        data: { groups: [], summary: { total: 0, promoted: 0, graduating: 0, blocked: 0 }, warnings: [`No classes found for ${fromYear}.`] },
      });
    }

    const students = await Student.findAll({
      where: {
        tenant_id: req.tenantId,
        class_id: sourceClasses.map((c) => c.id),
        status: 'active',
      },
      include: [
        { model: User, as: 'user', attributes: ['first_name', 'last_name'] },
        { model: Section, as: 'section', attributes: ['id', 'name'] },
      ],
    });

    // Highest grade FIRST. Promotion fills next year's classes, so the top
    // form must be cleared out (graduated, or moved up) before the form
    // below it arrives — otherwise Form 5 is promoted into a Form 6 that
    // still holds last year's Form 6, and capacity looks doubled. Working
    // downwards means every class is empty by the time its intake arrives.
    sourceClasses.sort((a, b) => {
      const diff = (gradeNumber(b.grade) ?? -1) - (gradeNumber(a.grade) ?? -1);
      return diff !== 0 ? diff : String(a.name).localeCompare(String(b.name));
    });

    const warnings = [];
    const groups = [];
    let promoted = 0; let graduating = 0; let blocked = 0;

    for (const fromClass of sourceClasses) {
      const classStudents = students.filter((s) => s.class_id === fromClass.id);
      const finalYear = isFinalGrade(fromClass);
      const currentGrade = gradeNumber(fromClass.grade);

      let toClass = null;
      let issue = null;

      if (finalYear) {
        // Nothing to promote into — these students are finishing.
        graduating += classStudents.length;
      } else if (currentGrade === null) {
        issue = `Could not work out a grade number from "${fromClass.grade}", so the next class can't be determined.`;
        blocked += classStudents.length;
      } else {
        toClass = findTargetClass(targetClasses, { fromClass, targetGrade: currentGrade + 1 });
        if (!toClass) {
          issue = `No matching class exists in ${toYear} for grade ${currentGrade + 1} at this campus. Create it first.`;
          blocked += classStudents.length;
          if (classStudents.length > 0) warnings.push(issue);
        } else {
          promoted += classStudents.length;
        }
      }

      // Repeating a year is NOT staying in the same row: the source class
      // belongs to the year being closed. A repeater needs the SAME grade
      // in the NEW year, which is a different class altogether.
      const retainClass = currentGrade !== null
        ? findTargetClass(targetClasses, { fromClass, targetGrade: currentGrade })
        : null;

      groups.push({
        from_class: { id: fromClass.id, name: fromClass.name, grade: fromClass.grade, education_level: fromClass.education_level },
        to_class: toClass ? { id: toClass.id, name: toClass.name, grade: toClass.grade } : null,
        retain_class: retainClass ? { id: retainClass.id, name: retainClass.name, grade: retainClass.grade } : null,
        is_final_year: finalYear,
        issue,
        students: classStudents.map((s) => ({
          id: s.id,
          name: `${s.user?.first_name || ''} ${s.user?.last_name || ''}`.trim(),
          admission_number: s.admission_number,
          section: s.section?.name || null,
          section_id: s.section_id,
          // The default the UI pre-selects; every student can be overridden.
          suggested_action: finalYear ? 'graduated' : toClass ? 'promoted' : 'retained',
        })),
      });
    }

    res.json({
      success: true,
      data: {
        from_academic_year: fromYear,
        to_academic_year: toYear,
        groups,
        summary: { total: students.length, promoted, graduating, blocked },
        warnings,
      },
    });
  } catch (error) { next(error); }
};

/**
 * POST /promotions/run
 *
 * Applies the decisions. Everything happens inside a transaction: a run
 * that fails halfway would otherwise leave half the school in next year's
 * classes and half in last year's, with no way to tell which is which.
 *
 * Body: {
 *   from_academic_year, to_academic_year,
 *   decisions: [{ student_id, action, to_class_id?, to_section_id?, notes? }]
 * }
 */
export const runPromotion = async (req, res, next) => {
  // Safety net: a fresh, tested full-database backup is made first (skipped if one was made minutes ago).
  try { await ensureBackupBeforeRiskyAction({ reason: 'running a student promotion', userId: req.user?.id }); } catch (backupError) { return next(backupError); }
  const transaction = await sequelize.transaction();
  try {

    const { from_academic_year: fromYear, to_academic_year: toYear, decisions = [] } = req.body;
    if (!fromYear || !toYear || decisions.length === 0) {
      await transaction.rollback();
      return res.status(400).json({ success: false, message: 'Both academic years and at least one student decision are required.' });
    }

    const studentIds = decisions.map((d) => d.student_id);
    const students = await Student.findAll({
      where: { id: studentIds, tenant_id: req.tenantId },
      transaction,
    });
    const byId = Object.fromEntries(students.map((s) => [s.id, s]));

    const missing = studentIds.filter((id) => !byId[id]);
    if (missing.length > 0) {
      await transaction.rollback();
      return res.status(404).json({ success: false, message: `${missing.length} student(s) in this run no longer exist.` });
    }

    // Validate every target class up front, so a bad id can't be applied to
    // some students before being noticed on a later one.
    const targetIds = [...new Set(decisions.map((d) => d.to_class_id).filter(Boolean))];
    const targetClassWhere = { id: targetIds, tenant_id: req.tenantId };
    applyAcademicYearFilter(targetClassWhere, toYear);
    const targetClasses = targetIds.length
      ? await Class.findAll({ where: targetClassWhere, transaction })
      : [];
    if (targetClasses.length !== targetIds.length) {
      await transaction.rollback();
      return res.status(400).json({ success: false, message: `One or more target classes don't exist in ${toYear}.` });
    }

    const batchId = randomUUID();
    const rows = [];
    let promotedCount = 0; let graduatedCount = 0; let retainedCount = 0; let transferredCount = 0;

    for (const decision of decisions) {
      const student = byId[decision.student_id];
      const action = decision.action;

      const record = {
        tenant_id: req.tenantId,
        student_id: student.id,
        batch_id: batchId,
        action,
        from_class_id: student.class_id,
        from_section_id: student.section_id,
        from_academic_year: fromYear,
        to_academic_year: toYear,
        previous_status: student.status,
        notes: decision.notes || null,
        performed_by: req.user.id,
        to_class_id: null,
        to_section_id: null,
      };

      if (action === 'promoted' || action === 'retained') {
        if (!decision.to_class_id) {
          await transaction.rollback();
          return res.status(400).json({
            success: false,
            message: `${student.admission_number}: a target class is required to ${action === 'promoted' ? 'promote' : 'retain'} a student.`,
          });
        }
        record.to_class_id = decision.to_class_id;
        record.to_section_id = decision.to_section_id || null;

        await student.update(
          { class_id: decision.to_class_id, section_id: decision.to_section_id || null },
          { transaction },
        );
        if (action === 'promoted') promotedCount++; else retainedCount++;
      } else if (action === 'graduated') {
        // Class membership is left as it was: their record should still
        // show the form they finished in.
        await student.update({ status: 'graduated' }, { transaction });
        graduatedCount++;
      } else if (action === 'transferred') {
        await student.update({ status: 'transferred' }, { transaction });
        transferredCount++;
      } else {
        await transaction.rollback();
        return res.status(400).json({ success: false, message: `Unknown action "${action}".` });
      }

      rows.push(record);
    }

    await StudentPromotion.bulkCreate(rows, { transaction });
    await transaction.commit();

    res.status(201).json({
      success: true,
      message: `Promotion complete — ${promotedCount} promoted, ${retainedCount} retained, ${graduatedCount} graduated, ${transferredCount} transferred.`,
      data: {
        batch_id: batchId,
        promoted: promotedCount,
        retained: retainedCount,
        graduated: graduatedCount,
        transferred: transferredCount,
      },
    });
  } catch (error) {
    await transaction.rollback();
    next(error);
  }
};

/**
 * POST /promotions/individual
 *
 * Moves ONE student straight into a higher class, right now, mid-year —
 * for the student who's clearly outgrown their current class before the
 * academic year that would normally move them ends. Deliberately kept
 * separate from runPromotion above: that endpoint moves an entire
 * cohort BETWEEN two academic years (from_academic_year != to_academic_year,
 * every student in a class at once); this one moves a single student
 * WITHIN the same academic year, so both classes must share it — a
 * request naming classes from two different years is asking for the
 * year-end batch process instead, and is rejected here rather than
 * silently doing something it wasn't designed for.
 *
 * Still recorded as a real StudentPromotion row (own batch_id, one row),
 * so this shows up in the same promotion history as any other move and
 * survives being reverted the same way.
 */
export const promoteIndividualStudent = async (req, res, next) => {
  // Safety net: a fresh, tested full-database backup is made first (skipped if one was made minutes ago).
  try { await ensureBackupBeforeRiskyAction({ reason: 'promoting a student', userId: req.user?.id }); } catch (backupError) { return next(backupError); }
  const transaction = await sequelize.transaction();
  try {

    const { student_id, to_class_id, to_section_id, notes } = req.body;
    if (!student_id || !to_class_id) {
      await transaction.rollback();
      return res.status(400).json({ success: false, message: 'A student and a target class are required.' });
    }

    const student = await Student.findOne({ where: { id: student_id, tenant_id: req.tenantId }, transaction });
    if (!student) {
      await transaction.rollback();
      return res.status(404).json({ success: false, message: 'Student not found.' });
    }
    if (student.status !== 'active') {
      await transaction.rollback();
      return res.status(400).json({ success: false, message: 'Only an active student can be promoted.' });
    }
    if (!student.class_id) {
      await transaction.rollback();
      return res.status(400).json({ success: false, message: 'This student has no current class on record to promote them from.' });
    }

    const fromClass = await Class.findOne({ where: { id: student.class_id, tenant_id: req.tenantId }, transaction });
    const toClass = await Class.findOne({ where: { id: to_class_id, tenant_id: req.tenantId }, transaction });
    if (!fromClass || !toClass) {
      await transaction.rollback();
      return res.status(404).json({ success: false, message: 'Current or target class no longer exists.' });
    }
    if (toClass.academic_year !== fromClass.academic_year) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: `The target class is in ${toClass.academic_year}, but this student's current class is in ${fromClass.academic_year}. Moving a student between academic years is done from the year-end Promotion run, not here.`,
      });
    }

    const fromGradeNum = gradeNumber(fromClass.grade);
    const toGradeNum = gradeNumber(toClass.grade);
    if (fromGradeNum === null || toGradeNum === null || toGradeNum <= fromGradeNum) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'The target class must be a HIGHER grade than the student\'s current class — this is for jumping a student ahead, not a lateral class/section change.',
      });
    }

    if (to_section_id) {
      const section = await Section.findOne({ where: { id: to_section_id, class_id: to_class_id, tenant_id: req.tenantId }, transaction });
      if (!section) {
        await transaction.rollback();
        return res.status(400).json({ success: false, message: 'That section does not belong to the target class.' });
      }
    }

    const record = await StudentPromotion.create({
      tenant_id: req.tenantId,
      student_id: student.id,
      batch_id: randomUUID(),
      action: 'promoted',
      from_class_id: fromClass.id,
      from_section_id: student.section_id,
      from_academic_year: fromClass.academic_year,
      to_class_id: toClass.id,
      to_section_id: to_section_id || null,
      to_academic_year: toClass.academic_year,
      previous_status: student.status,
      notes: notes || 'Mid-year promotion — student performed well ahead of the year-end promotion run.',
      performed_by: req.user.id,
    }, { transaction });

    await student.update({ class_id: to_class_id, section_id: to_section_id || null }, { transaction });

    await transaction.commit();

    res.status(201).json({
      success: true,
      message: `${student.admission_number} moved from ${fromClass.name} to ${toClass.name}.`,
      data: { promotion: record, student_id: student.id, from_class: fromClass.name, to_class: toClass.name },
    });
  } catch (error) {
    await transaction.rollback();
    next(error);
  }
};

/**
 * POST /promotions/:batchId/revert
 *
 * Puts every student in a batch back where they were. A promotion run is
 * the single most destructive thing an admin can do in this system —
 * without a way back, one wrong click at the end of the year would mean
 * re-assigning hundreds of students by hand.
 */
export const revertPromotion = async (req, res, next) => {
  // Safety net: a fresh, tested full-database backup is made first (skipped if one was made minutes ago).
  try { await ensureBackupBeforeRiskyAction({ reason: 'reverting a promotion', userId: req.user?.id }); } catch (backupError) { return next(backupError); }
  const transaction = await sequelize.transaction();
  try {

    const records = await StudentPromotion.findAll({
      where: { batch_id: req.params.batchId, tenant_id: req.tenantId, reverted_at: null },
      transaction,
    });

    if (records.length === 0) {
      await transaction.rollback();
      return res.status(404).json({ success: false, message: 'No promotion found for that batch, or it has already been reverted.' });
    }

    for (const record of records) {
      const student = await Student.findByPk(record.student_id, { transaction });
      if (!student) continue;

      await student.update({
        class_id: record.from_class_id,
        section_id: record.from_section_id,
        // Restore the exact status held before, not a guess at 'active'.
        status: record.previous_status || student.status,
      }, { transaction });
    }

    await StudentPromotion.update(
      { reverted_at: new Date(), reverted_by: req.user.id },
      { where: { batch_id: req.params.batchId, tenant_id: req.tenantId }, transaction },
    );

    await transaction.commit();
    res.json({ success: true, message: `Reverted — ${records.length} student(s) restored to their previous class.` });
  } catch (error) {
    await transaction.rollback();
    next(error);
  }
};

/** GET /promotions — past runs, newest first. */
export const getPromotionHistory = async (req, res, next) => {
  try {
    const records = await StudentPromotion.findAll({
      where: { tenant_id: req.tenantId },
      include: [{ model: User, as: 'performedBy', attributes: ['first_name', 'last_name'] }],
      order: [['created_at', 'DESC']],
      limit: 500,
    });

    // Grouped into runs, because a batch of 400 rows is one event to a
    // person, not 400.
    const batches = new Map();
    records.forEach((r) => {
      if (!batches.has(r.batch_id)) {
        batches.set(r.batch_id, {
          batch_id: r.batch_id,
          from_academic_year: r.from_academic_year,
          to_academic_year: r.to_academic_year,
          performed_by: r.performedBy ? `${r.performedBy.first_name} ${r.performedBy.last_name}` : null,
          created_at: r.created_at,
          reverted_at: r.reverted_at,
          counts: { promoted: 0, retained: 0, graduated: 0, transferred: 0 },
          total: 0,
        });
      }
      const batch = batches.get(r.batch_id);
      batch.counts[r.action] = (batch.counts[r.action] || 0) + 1;
      batch.total++;
    });

    res.json({ success: true, data: [...batches.values()] });
  } catch (error) { next(error); }
};

/** GET /promotions/sections?class_id= — sections available in a target
 * class, so students can be placed into a specific stream. */
export const getClassSections = async (req, res, next) => {
  try {
    const sections = await Section.findAll({
      where: { tenant_id: req.tenantId, class_id: req.query.class_id },
      attributes: ['id', 'name'],
      order: [['name', 'ASC']],
    });
    res.json({ success: true, data: sections });
  } catch (error) { next(error); }
};
