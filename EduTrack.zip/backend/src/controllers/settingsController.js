// backend/src/controllers/settingsController.js
import { can } from '../utils/permissionEngine.js';
import { Op } from 'sequelize';
import {
  Tenant, User, AuditLog, Student, Staff, FeeStructure, Payment,
} from '../models/index.js';
import * as db from '../models/index.js';
import { systemStartBaseYear } from '../utils/academicYear.js';
import { describeRequest, cleanObject, recordName } from '../utils/auditDescribe.js';
import { DEFAULT_SESSION_POLICY, SESSION_POLICY_LIMITS, resolveSessionPolicy } from '../utils/sessionPolicy.js';
import { MONEY_DECIMALS, DATE_FORMATS, RECEIPT_SIZES, resolveDisplay, invalidateTenantDisplay } from '../utils/tenantDisplay.js';

import { sanitizeWebsiteContent, resolveWebsiteContent } from '../utils/websiteContent.js';

const MANAGE_ROLES = ['super_admin', 'admin'];

const clamp = (value, { min, max }, fallback) => {
  const n = parseInt(value, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
};

// ─────────────────────────────────────────────────────────────────────────
// Academic Year & Term settings + Session/Login policy + Backup preference
// — all stored as plain keys on tenants.settings (JSONB), same pattern
// academic_records_start_year already used before this file existed.
// ─────────────────────────────────────────────────────────────────────────
export const getSettingsOverview = async (req, res, next) => {
  try {
    const tenant = await Tenant.findByPk(req.tenantId);
    if (!tenant) return res.status(404).json({ success: false, message: 'Tenant not found' });

    const settings = tenant.settings || {};
    res.status(200).json({
      success: true,
      data: {
        academic_records_start_year: settings.academic_records_start_year ?? systemStartBaseYear(tenant),
        terms: settings.terms || [],
        session_policy: resolveSessionPolicy(tenant),
        // How this school shows dates, money and receipts — one setting for everyone.
        display: resolveDisplay(tenant),
        // Everyone needs the academic-year start and the session policy (idle
        // sign-out); the backup schedule is for the people who set it.
        ...((await can(req.user, req.tenantId, 'settings.backup'))
          ? { backup_schedule: settings.backup_schedule || { enabled: false, frequency: 'weekly' } }
          : {}),
      },
    });
  } catch (error) { next(error); }
};

/** PUT /settings/display — { money_decimals?, date_format?, receipt_size? }. */
export const updateDisplaySettings = async (req, res, next) => {
  try {
    const { money_decimals, date_format, receipt_size } = req.body || {};
    const next_ = {};
    if (money_decimals !== undefined) {
      if (!MONEY_DECIMALS.includes(Number(money_decimals))) {
        return res.status(400).json({ success: false, message: `Money decimals must be one of: ${MONEY_DECIMALS.join(', ')}.` });
      }
      next_.money_decimals = Number(money_decimals);
    }
    if (date_format !== undefined) {
      if (!DATE_FORMATS.includes(date_format)) return res.status(400).json({ success: false, message: 'That date format is not available.' });
      next_.date_format = date_format;
    }
    if (receipt_size !== undefined) {
      if (!RECEIPT_SIZES.includes(receipt_size)) return res.status(400).json({ success: false, message: 'That receipt size is not available.' });
      next_.receipt_size = receipt_size;
    }
    if (Object.keys(next_).length === 0) {
      return res.status(400).json({ success: false, message: 'Nothing to change.' });
    }

    const tenant = await Tenant.findByPk(req.tenantId);
    if (!tenant) return res.status(404).json({ success: false, message: 'Tenant not found' });
    const settings = { ...(tenant.settings || {}) };
    settings.display = { ...resolveDisplay(tenant), ...next_ };
    await tenant.update({ settings });
    invalidateTenantDisplay(req.tenantId);

    res.json({ success: true, message: 'Display settings saved for the whole school', data: { display: resolveDisplay(tenant) } });
  } catch (error) { next(error); }
};

export const updateAcademicYearSettings = async (req, res, next) => {
  try {

    const tenant = await Tenant.findByPk(req.tenantId);
    if (!tenant) return res.status(404).json({ success: false, message: 'Tenant not found' });

    const { academic_records_start_year, terms } = req.body;
    const nextSettings = { ...tenant.settings };

    if (academic_records_start_year !== undefined) {
      const year = parseInt(academic_records_start_year, 10);
      if (!Number.isFinite(year) || year < 2000 || year > 2100) {
        return res.status(400).json({ success: false, message: 'Enter a valid 4-digit year' });
      }
      nextSettings.academic_records_start_year = year;
    }

    if (terms !== undefined) {
      if (!Array.isArray(terms)) {
        return res.status(400).json({ success: false, message: 'Terms must be a list' });
      }
      const cleanTerms = terms
        .map((t) => ({
          name: String(t?.name || '').trim(),
          start_date: t?.start_date || null,
          end_date: t?.end_date || null,
        }))
        .filter((t) => t.name);

      for (const t of cleanTerms) {
        if (t.start_date && t.end_date && new Date(t.start_date) > new Date(t.end_date)) {
          return res.status(400).json({ success: false, message: `"${t.name}": end date is before its start date` });
        }
      }
      nextSettings.terms = cleanTerms;
    }

    await tenant.update({ settings: nextSettings });
    res.status(200).json({
      success: true,
      message: 'Academic year settings updated',
      data: {
        academic_records_start_year: nextSettings.academic_records_start_year ?? systemStartBaseYear(tenant),
        terms: nextSettings.terms || [],
      },
    });
  } catch (error) { next(error); }
};

export const updateSessionPolicy = async (req, res, next) => {
  try {

    const tenant = await Tenant.findByPk(req.tenantId);
    if (!tenant) return res.status(404).json({ success: false, message: 'Tenant not found' });

    const current = resolveSessionPolicy(tenant);
    const { idle_timeout_minutes, max_login_attempts, lockout_minutes } = req.body;

    const nextPolicy = {
      idle_timeout_minutes: idle_timeout_minutes !== undefined
        ? clamp(idle_timeout_minutes, SESSION_POLICY_LIMITS.idle_timeout_minutes, current.idle_timeout_minutes)
        : current.idle_timeout_minutes,
      max_login_attempts: max_login_attempts !== undefined
        ? clamp(max_login_attempts, SESSION_POLICY_LIMITS.max_login_attempts, current.max_login_attempts)
        : current.max_login_attempts,
      lockout_minutes: lockout_minutes !== undefined
        ? clamp(lockout_minutes, SESSION_POLICY_LIMITS.lockout_minutes, current.lockout_minutes)
        : current.lockout_minutes,
    };

    await tenant.update({ settings: { ...tenant.settings, session_policy: nextPolicy } });
    res.status(200).json({ success: true, message: 'Session & login policy updated', data: nextPolicy });
  } catch (error) { next(error); }
};

export const updateBackupSchedule = async (req, res, next) => {
  try {

    const tenant = await Tenant.findByPk(req.tenantId);
    if (!tenant) return res.status(404).json({ success: false, message: 'Tenant not found' });

    const { enabled, frequency } = req.body;
    const allowedFrequencies = ['daily', 'weekly', 'monthly'];
    const schedule = {
      enabled: !!enabled,
      frequency: allowedFrequencies.includes(frequency) ? frequency : (tenant.settings?.backup_schedule?.frequency || 'weekly'),
    };

    await tenant.update({ settings: { ...tenant.settings, backup_schedule: schedule } });
    res.status(200).json({ success: true, message: 'Backup preference saved', data: schedule });
  } catch (error) { next(error); }
};

// ─────────────────────────────────────────────────────────────────────────
// Data export — returns raw JSON for the requested slice of this tenant's
// data; the frontend bundles it into a downloadable Excel workbook with
// SheetJS (same client-side pattern as Reports/Exams exports) rather than
// this endpoint generating a file itself.
// ─────────────────────────────────────────────────────────────────────────
const EXPORTERS = {
  students: (tenant_id) => Student.findAll({ where: { tenant_id }, raw: true }),
  staff: (tenant_id) => Staff.findAll({ where: { tenant_id }, raw: true }),
  fees: (tenant_id) => FeeStructure.findAll({ where: { tenant_id }, raw: true }),
  payments: (tenant_id) => Payment.findAll({ where: { tenant_id }, raw: true }),
};

export const exportData = async (req, res, next) => {
  try {

    const type = req.query.type || 'all';
    if (type !== 'all' && !EXPORTERS[type]) {
      return res.status(400).json({ success: false, message: `Unknown export type "${type}"` });
    }

    const keys = type === 'all' ? Object.keys(EXPORTERS) : [type];
    const data = {};
    for (const key of keys) {
      data[key] = await EXPORTERS[key](req.tenantId);
    }

    res.status(200).json({ success: true, data, exported_at: new Date().toISOString() });
  } catch (error) { next(error); }
};

// ─────────────────────────────────────────────────────────────────────────
// Audit log / activity history — reads the audit_logs table that
// middleware/auditLog.js writes on every successful create / update / delete.
//
// New entries carry a readable title and the exact before → after values.
// Entries written before that only have the route, so they are described
// from it (utils/auditDescribe.js) and their stored request body is scrubbed
// of passwords/secrets on the way out.
// ─────────────────────────────────────────────────────────────────────────

/** One audit row, shaped for the screen. `full` adds the complete details. */
const presentAuditLog = (row, { full = false } = {}) => {
  const log = row.toJSON();
  const d = log.details || {};
  const current = d.version === 2;

  const described = current
    ? { title: d.title || log.action, kind: d.kind, record: d.record || null, changed_fields: d.changed_fields || [] }
    : { ...describeRequest({ method: d.method, resource: log.resource_type, path: d.path, body: d.body }), record: null, changed_fields: [] };

  const overflowTotal = current ? (d.overflow || []).reduce((n, o) => n + o.count, 0) : 0;

  const out = {
    id: log.id,
    action: described.title,
    kind: described.kind,
    outcome: current ? (d.outcome || null) : null, // 'failed' for refused sign-ins
    record: described.record,
    changed_fields: described.changed_fields,
    change_count: current ? (d.changes || []).length + overflowTotal : 0,
    legacy: !current,
    resource_type: log.resource_type,
    resource_id: log.resource_id,
    user: log.user || null,
    ip_address: log.ip_address,
    createdAt: log.createdAt,
  };

  if (full) {
    out.user_agent = log.user_agent;
    out.details = current
      ? d
      : { legacy: true, request: { method: d.method, path: d.path, query: cleanObject(d.query || {}), body: cleanObject(d.body || {}) } };
  }
  return out;
};

// Which model a "…_id" field points at, so the detail view can show
// "Form 1" instead of a UUID.
const REFERENCE_MODELS = {
  class_id: 'Class', campus_id: 'Campus', student_id: 'Student', subject_id: 'Subject', section_id: 'Section',
  user_id: 'User', parent_id: 'User', teacher_id: 'User', class_teacher_id: 'User', principal_id: 'User',
  staff_id: 'Staff', route_id: 'Route', vehicle_id: 'Vehicle', book_id: 'Book', hostel_id: 'Hostel',
  room_id: 'HostelRoom', fee_structure_id: 'FeeStructure', exam_id: 'Exam', category_id: 'ExpenseCategory',
  expense_category_id: 'ExpenseCategory', leave_type_id: 'LeaveType', template_id: 'MessageTemplate',
  plan_id: 'SubscriptionPlan', item_id: 'InventoryItem', contact_id: 'Contact', group_id: 'ContactGroup',
  payroll_period_id: 'PayrollPeriod',
};
const referenceModelFor = (field) => REFERENCE_MODELS[field] || (/_by$/.test(field) ? 'User' : null);
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const NAME_COLUMNS = ['name', 'title', 'first_name', 'last_name', 'admission_number', 'employee_number', 'code'];

/** { <uuid>: 'Form 1', … } for every record id mentioned in this entry's changes. */
const resolveAuditReferences = async (tenantId, details) => {
  const wanted = {}; // model name → Set(ids)
  const want = (field, value) => {
    const modelName = referenceModelFor(field);
    if (modelName && typeof value === 'string' && UUID_RE.test(value)) (wanted[modelName] ||= new Set()).add(value);
  };
  for (const change of details?.changes || []) {
    (change.fields || []).forEach((f) => { want(f.field, f.before); want(f.field, f.after); });
    Object.entries(change.data || {}).forEach(([field, value]) => want(field, value));
  }

  const lookups = {};
  await Promise.all(Object.entries(wanted).map(async ([modelName, ids]) => {
    const Model = db[modelName];
    if (!Model) return;
    const columns = Object.keys(Model.rawAttributes || {});
    const attributes = ['id', ...NAME_COLUMNS.filter((c) => columns.includes(c))];
    const where = { id: [...ids] };
    if (columns.includes('tenant_id')) where.tenant_id = tenantId; // never name another school's record
    try {
      const rows = await Model.findAll({ where, attributes, raw: true });
      rows.forEach((r) => { const label = recordName(r); if (label) lookups[r.id] = label; });
    } catch { /* a name that can't be looked up just stays an id */ }
  }));
  return lookups;
};

const KIND_FILTERS = {
  // Entries written before readable titles existed only have "POST /…" — they
  // are told apart by that prefix.
  create: ['POST /%'],
  update: ['PUT /%', 'PATCH /%'],
  delete: ['DELETE /%'],
  action: [],
  auth: [],
};

export const getAuditLogs = async (req, res, next) => {
  try {

    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 20));
    const { user_id, resource_type, action, kind, from, to } = req.query;

    const where = { tenant_id: req.tenantId };
    if (user_id) where.user_id = user_id;
    if (resource_type) where.resource_type = resource_type;
    if (action) where.action = { [Op.iLike]: `%${action}%` };
    if (kind && Object.prototype.hasOwnProperty.call(KIND_FILTERS, kind)) {
      where[Op.and] = [{
        [Op.or]: [
          { details: { kind } },
          ...KIND_FILTERS[kind].map((prefix) => ({ action: { [Op.like]: prefix } })),
        ],
      }];
    }
    if (from || to) {
      where.createdAt = {};
      if (from) where.createdAt[Op.gte] = new Date(from);
      if (to) where.createdAt[Op.lte] = new Date(`${to}T23:59:59.999Z`);
    }

    const { rows, count } = await AuditLog.findAndCountAll({
      where,
      include: [{ model: User, as: 'user', attributes: ['id', 'first_name', 'last_name', 'email', 'role'] }],
      order: [['createdAt', 'DESC']],
      limit,
      offset: (page - 1) * limit,
    });

    res.status(200).json({
      success: true,
      data: rows.map((r) => presentAuditLog(r)),
      pagination: { currentPage: page, itemsPerPage: limit, totalItems: count, totalPages: Math.ceil(count / limit) || 1 },
    });
  } catch (error) { next(error); }
};

/** GET /settings/audit-logs/:id — everything about one entry: the full
 * before → after values, plus the names behind any ids in them. */
export const getAuditLogById = async (req, res, next) => {
  try {

    const row = await AuditLog.findOne({
      where: { id: req.params.id, tenant_id: req.tenantId },
      include: [{ model: User, as: 'user', attributes: ['id', 'first_name', 'last_name', 'email', 'role'] }],
    });
    if (!row) return res.status(404).json({ success: false, message: 'Audit entry not found' });

    const data = presentAuditLog(row, { full: true });
    data.lookups = await resolveAuditReferences(req.tenantId, data.details);
    res.status(200).json({ success: true, data });
  } catch (error) { next(error); }
};

/** Distinct resource types seen in the log, for the filter dropdown —
 * cheap enough to compute on demand rather than caching, since audit
 * volume per tenant is modest. */
export const getAuditLogResourceTypes = async (req, res, next) => {
  try {
    const rows = await AuditLog.findAll({
      where: { tenant_id: req.tenantId, resource_type: { [Op.ne]: null } },
      attributes: [[AuditLog.sequelize.fn('DISTINCT', AuditLog.sequelize.col('resource_type')), 'resource_type']],
      order: [['resource_type', 'ASC']],
      raw: true,
    });
    res.status(200).json({ success: true, data: rows.map((r) => r.resource_type).filter(Boolean) });
  } catch (error) { next(error); }
};

// ─────────────────────────────────────────────────────────────────────────
// Website content — the wording the school's PUBLIC website shows (hero, contact details, stats, testimonials, news).
// Kept on tenants.settings.website_content; the public website reads it from /public/:slug/website-content.
// ─────────────────────────────────────────────────────────────────────────
export const getWebsiteContent = async (req, res, next) => {
  try {
    const tenant = await Tenant.findByPk(req.tenantId, { attributes: ['id', 'settings'] });
    if (!tenant) return res.status(404).json({ success: false, message: 'Tenant not found' });
    res.json({ success: true, data: resolveWebsiteContent(tenant) });
  } catch (error) { next(error); }
};

export const updateWebsiteContent = async (req, res, next) => {
  try {
    const tenant = await Tenant.findByPk(req.tenantId);
    if (!tenant) return res.status(404).json({ success: false, message: 'Tenant not found' });
    const clean = sanitizeWebsiteContent(req.body);
    await tenant.update({ settings: { ...(tenant.settings || {}), website_content: clean } });
    res.json({ success: true, message: 'Website content saved — the website shows it right away', data: resolveWebsiteContent(tenant) });
  } catch (error) { next(error); }
};

/** Public (no login): the same content, for the school's website. Read-only. */
export const getPublicWebsiteContent = async (req, res, next) => {
  try {
    const tenant = await Tenant.findOne({ where: { slug: req.params.tenantSlug }, attributes: ['id', 'settings'] });
    if (!tenant) return res.status(404).json({ success: false, message: 'Website content is not available.' });
    res.set('Cache-Control', 'public, max-age=60');
    res.json({ success: true, data: resolveWebsiteContent(tenant) });
  } catch (error) { next(error); }
};
