import { Subject, Campus, TimetableEntry, ClassSubject, Student, Grade } from '../models/index.js';
import { Op } from 'sequelize';
import { computeGrade } from './examController.js';

export const subjectController = {
  async getAll(req, res, next) {
    try {
      const {
        page = 1, limit = 10, search = '', status = '',
        campus_id = '', is_elective = '',
        sortBy = 'name', sortOrder = 'ASC',
      } = req.query;

      const offset = (page - 1) * limit;
      const where = { tenant_id: req.tenantId };

      if (status) where.status = status;
      if (campus_id) where.campus_id = campus_id;
      if (is_elective !== '') where.is_elective = is_elective === 'true';
      if (search) {
        where[Op.or] = [
          { name: { [Op.iLike]: `%${search}%` } },
          { code: { [Op.iLike]: `%${search}%` } },
        ];
      }

      const { count, rows: subjects } = await Subject.findAndCountAll({
        where,
        include: [
          { model: Campus, as: 'campus', attributes: ['id', 'name', 'code'] },
        ],
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [[sortBy, sortOrder]],
        distinct: true,
      });

      res.json({
        success: true,
        data: subjects,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(count / limit),
          totalItems: count,
          itemsPerPage: parseInt(limit),
        },
      });
    } catch (error) {
      next(error);
    }
  },

  async getById(req, res, next) {
    try {
      const { id } = req.params;
      const subject = await Subject.findOne({
        where: { id, tenant_id: req.tenantId },
        include: [{ model: Campus, as: 'campus' }],
      });

      if (!subject) {
        return res.status(404).json({ success: false, message: 'Subject not found' });
      }

      res.json({ success: true, data: subject });
    } catch (error) {
      next(error);
    }
  },

  async create(req, res, next) {
    try {
      const {
        name, code, description, campus_id,
        credits, is_elective = false, status = 'active',
      } = req.body;

      // Check code uniqueness within tenant (optionally scoped to campus)
      const existing = await Subject.findOne({
        where: { code, tenant_id: req.tenantId },
      });
      if (existing) {
        return res.status(400).json({ success: false, message: 'A subject with this code already exists' });
      }

      if (campus_id) {
        const campus = await Campus.findOne({ where: { id: campus_id, tenant_id: req.tenantId } });
        if (!campus) {
          return res.status(400).json({ success: false, message: 'Invalid campus ID' });
        }
      }

      const subject = await Subject.create({
        tenant_id: req.tenantId, name, code,
        description: description || null,
        campus_id: campus_id || null,
        credits: credits || null,
        is_elective: Boolean(is_elective),
        status,
      });

      const created = await Subject.findByPk(subject.id, {
        include: [{ model: Campus, as: 'campus' }],
      });

      res.status(201).json({ success: true, message: 'Subject created successfully', data: created });
    } catch (error) {
      next(error);
    }
  },

  async update(req, res, next) {
    try {
      const { id } = req.params;
      const subject = await Subject.findOne({ where: { id, tenant_id: req.tenantId } });

      if (!subject) {
        return res.status(404).json({ success: false, message: 'Subject not found' });
      }

      const { name, code, description, campus_id, credits, is_elective, status } = req.body;

      // Check code uniqueness if changed
      if (code && code !== subject.code) {
        const dup = await Subject.findOne({
          where: { code, tenant_id: req.tenantId, id: { [Op.ne]: id } },
        });
        if (dup) {
          return res.status(400).json({ success: false, message: 'A subject with this code already exists' });
        }
      }

      const u = {};
      if (name) u.name = name;
      if (code) u.code = code;
      if (description !== undefined) u.description = description || null;
      if (campus_id !== undefined) u.campus_id = campus_id || null;
      if (credits !== undefined) u.credits = credits || null;
      if (is_elective !== undefined) u.is_elective = Boolean(is_elective);
      if (status) u.status = status;

      await subject.update(u);

      const updated = await Subject.findByPk(id, {
        include: [{ model: Campus, as: 'campus' }],
      });

      res.json({ success: true, message: 'Subject updated successfully', data: updated });
    } catch (error) {
      next(error);
    }
  },

  async delete(req, res, next) {
    try {
      const { id } = req.params;
      const subject = await Subject.findOne({ where: { id, tenant_id: req.tenantId } });
      if (!subject) {
        return res.status(404).json({ success: false, message: 'Subject not found' });
      }
      await subject.update({ status: 'inactive' });
      res.json({ success: true, message: 'Subject deactivated successfully' });
    } catch (error) {
      next(error);
    }
  },

  async permanentDelete(req, res, next) {
    try {
      const { id } = req.params;
      const subject = await Subject.findOne({ where: { id, tenant_id: req.tenantId } });
      if (!subject) {
        return res.status(404).json({ success: false, message: 'Subject not found' });
      }
      await subject.destroy();
      res.json({ success: true, message: 'Subject permanently deleted' });
    } catch (error) {
      next(error);
    }
  },

  async reactivate(req, res, next) {
    try {
      const { id } = req.params;
      const subject = await Subject.findOne({ where: { id, tenant_id: req.tenantId } });
      if (!subject) {
        return res.status(404).json({ success: false, message: 'Subject not found' });
      }
      await subject.update({ status: 'active' });
      res.json({ success: true, message: 'Subject reactivated successfully', data: subject });
    } catch (error) {
      next(error);
    }
  },

  async bulkUpdateStatus(req, res, next) {
    try {
      const { ids, status } = req.body;
      if (!ids || !Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ success: false, message: 'Please provide subject IDs' });
      }
      if (!['active', 'inactive'].includes(status)) {
        return res.status(400).json({ success: false, message: 'Invalid status value' });
      }
      await Subject.update({ status }, { where: { id: { [Op.in]: ids }, tenant_id: req.tenantId } });
      res.json({ success: true, message: `${ids.length} subject(s) updated successfully` });
    } catch (error) {
      next(error);
    }
  },

  async getStats(req, res, next) {
    try {
      const { id } = req.params;
      const subject = await Subject.findOne({ where: { id, tenant_id: req.tenantId } });
      if (!subject) {
        return res.status(404).json({ success: false, message: 'Subject not found' });
      }

      // Which classes actually teach this subject (via the ClassSubject
      // assignment table), and how many timetable slots it occupies.
      const classSubjects = await ClassSubject.findAll({
        where: { subject_id: id, tenant_id: req.tenantId },
        attributes: ['class_id'],
      });
      const classIds = [...new Set(classSubjects.map((cs) => cs.class_id))];
      const classesTaking = classIds.length;

      const timetableSlots = await TimetableEntry.count({ where: { subject_id: id, tenant_id: req.tenantId } });

      // Students currently in one of those classes — i.e. actually taking
      // the subject, not just enrolled somewhere in the school.
      const studentsTaking = classIds.length > 0
        ? await Student.count({ where: { tenant_id: req.tenantId, status: 'active', class_id: { [Op.in]: classIds } } })
        : 0;

      // Grades recorded for this subject, and the average score as a
      // percentage (marks_obtained / max_marks) across all of them.
      const gradesRecorded = await Grade.count({
        where: { tenant_id: req.tenantId, subject_id: id, marks_obtained: { [Op.ne]: null } },
      });

      let averagePerformance = 0;
      if (gradesRecorded > 0) {
        // Compute the average percentage in JS rather than a fragile raw
        // SQL expression — clearer, and avoids dialect-specific quirks.
        const rows = await Grade.findAll({
          where: { tenant_id: req.tenantId, subject_id: id, marks_obtained: { [Op.ne]: null } },
          attributes: ['marks_obtained', 'max_marks'],
          raw: true,
        });
        const percentages = rows
          .filter((r) => Number(r.max_marks) > 0)
          .map((r) => (Number(r.marks_obtained) / Number(r.max_marks)) * 100);
        averagePerformance = percentages.length > 0
          ? Math.round((percentages.reduce((a, b) => a + b, 0) / percentages.length) * 10) / 10
          : 0;
      }

      const stats = {
        classes_taking: classesTaking,
        students_taking: studentsTaking,
        timetable_slots: timetableSlots,
        grades_recorded: gradesRecorded,
        average_performance: averagePerformance,
        average_grade: computeGrade(gradesRecorded > 0 ? averagePerformance : null),
      };

      res.json({ success: true, data: stats });
    } catch (error) {
      next(error);
    }
  },
};
