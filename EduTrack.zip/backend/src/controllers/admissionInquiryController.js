// FILE PATH: backend/src/controllers/admissionInquiryController.js
import crypto from 'crypto';
import { Op } from 'sequelize';
import { Tenant, AdmissionInquiry, EmailGatewaySettings } from '../models/index.js';
import { sendEmail } from '../services/emailService.js';


const generateReference = (tenantSlug) => {
  const code = crypto.randomBytes(3).toString('hex').toUpperCase();
  const prefix = (tenantSlug || 'APP').slice(0, 3).toUpperCase();
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${code}`;
};

// ─────────────────────────────────────────────────────────────────────────
// Public — no login required. Called from the tenant's public website
// (see website/frontend/src/services/api.js). Scoped by :tenantSlug in
// the URL rather than a JWT, and rate-limited (publicFormLimiter, wired
// in routes/publicRoutes.js) since anyone on the internet can reach it.
// ─────────────────────────────────────────────────────────────────────────
export const submitPublicInquiry = async (req, res, next) => {
  try {
    const tenant = await Tenant.findOne({ where: { slug: req.params.tenantSlug } });
    if (!tenant) {
      return res.status(404).json({ success: false, message: 'This admissions form is not available.' });
    }

    const {
      firstName, middleName, lastName, dateOfBirth, gender, program,
      parentName, email, phone, address, message,
    } = req.body;

    if (!firstName?.trim() || !lastName?.trim() || !parentName?.trim() || !phone?.trim()) {
      return res.status(400).json({
        success: false,
        message: 'Student first name, last name, parent/guardian name, and phone are all required.',
      });
    }
    if (email?.trim() && !/^\S+@\S+\.\S+$/.test(email.trim())) {
      return res.status(400).json({ success: false, message: 'Enter a valid email address.' });
    }

    const existing = await AdmissionInquiry.findOne({
      where: {
        tenant_id: tenant.id,
        phone: phone.trim(),
        first_name: { [Op.iLike]: firstName.trim() },
        last_name: { [Op.iLike]: lastName.trim() },
        status: { [Op.in]: ['new', 'contacted'] },
      },
    });
    if (existing) {
      return res.status(409).json({
        success: false,
        alreadySubmitted: true,
        message: 'This application has already been received. Our office will contact you once it has been reviewed.',
        reference: existing.reference,
      });
    }

    const inquiry = await AdmissionInquiry.create({
      tenant_id: tenant.id,
      reference: generateReference(tenant.slug),
      first_name: firstName.trim(),
      middle_name: middleName?.trim() || null,
      last_name: lastName.trim(),
      date_of_birth: dateOfBirth || null,
      gender: ['male', 'female', 'other'].includes(gender) ? gender : null,
      desired_class: program || null,
      parent_name: parentName.trim(),
      email: email?.trim() || null,
      phone: phone.trim(),
      address: address?.trim() || null,
      message: message?.trim() || null,
      source: 'website',
    });

    notifyOfficeOfNewInquiry(tenant, inquiry).catch(() => { /* logged inside the helper */ });

    res.status(201).json({
      success: true,
      message: 'Application submitted successfully!',
      reference: inquiry.reference,
    });
  } catch (error) { next(error); }
};

const fullInquiryName = (inquiry) => [inquiry.first_name, inquiry.middle_name, inquiry.last_name].filter(Boolean).join(' ');

async function notifyOfficeOfNewInquiry(tenant, inquiry) {
  try {
    const gatewaySettings = await EmailGatewaySettings.findOne({ where: { tenant_id: tenant.id } });
    await sendEmail({
      to: tenant.email,
      subject: `New admission inquiry: ${fullInquiryName(inquiry)} (${inquiry.reference})`,
      text: [
        `A new admission inquiry was submitted through the website.`,
        ``,
        `Reference: ${inquiry.reference}`,
        `Student: ${fullInquiryName(inquiry)}${inquiry.desired_class ? ` — ${inquiry.desired_class}` : ''}`,
        `Parent/Guardian: ${inquiry.parent_name}`,
        inquiry.email ? `Email: ${inquiry.email}` : null,
        `Phone: ${inquiry.phone}`,
        inquiry.message ? `Message: ${inquiry.message}` : null,
        ``,
        `View it in EduTrack under Students → Online Applications.`,
      ].filter(Boolean).join('\n'),
    }, gatewaySettings);
  } catch (error) {
    // Notification failing shouldn't surface to the applicant or the
    // caller — the inquiry itself is already saved and visible in
    // EduTrack regardless of whether this email goes out.
    console.error('Failed to send admission inquiry notification email:', error.message);
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Staff-facing — authenticated, tenant-scoped (mounted behind
// authenticate + checkTenant in routes/admissionInquiryRoutes.js).
// ─────────────────────────────────────────────────────────────────────────
export const listInquiries = async (req, res, next) => {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 20));
    const { status, search } = req.query;

    const where = { tenant_id: req.tenantId };
    if (status) where.status = status;
    if (search) {
      where[Op.or] = [
        { first_name: { [Op.iLike]: `%${search}%` } },
        { last_name: { [Op.iLike]: `%${search}%` } },
        { parent_name: { [Op.iLike]: `%${search}%` } },
        { email: { [Op.iLike]: `%${search}%` } },
        { phone: { [Op.iLike]: `%${search}%` } },
        { reference: { [Op.iLike]: `%${search}%` } },
      ];
    }

    const { rows, count } = await AdmissionInquiry.findAndCountAll({
      where,
      order: [['createdAt', 'DESC']],
      limit,
      offset: (page - 1) * limit,
    });

    res.json({
      success: true,
      data: rows,
      pagination: { currentPage: page, itemsPerPage: limit, totalItems: count, totalPages: Math.ceil(count / limit) || 1 },
    });
  } catch (error) { next(error); }
};

export const getInquiryCounts = async (req, res, next) => {
  try {
    const rows = await AdmissionInquiry.findAll({
      where: { tenant_id: req.tenantId },
      attributes: ['status'],
      raw: true,
    });
    const counts = { new: 0, contacted: 0, enrolled: 0, declined: 0 };
    for (const r of rows) counts[r.status] = (counts[r.status] || 0) + 1;
    res.json({ success: true, data: counts });
  } catch (error) { next(error); }
};

export const updateInquiryStatus = async (req, res, next) => {
  try {
    const { status, staff_notes } = req.body;
    if (status && !['new', 'contacted', 'enrolled', 'declined'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status' });
    }

    const inquiry = await AdmissionInquiry.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!inquiry) return res.status(404).json({ success: false, message: 'Inquiry not found' });

    await inquiry.update({
      ...(status !== undefined ? { status } : {}),
      ...(staff_notes !== undefined ? { staff_notes } : {}),
    });

    res.json({ success: true, message: 'Inquiry updated', data: inquiry });
  } catch (error) { next(error); }
};