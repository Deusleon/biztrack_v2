import { familyContactsFor } from '../utils/familyContacts.js';
import { can } from '../utils/permissionEngine.js';
import { Op } from 'sequelize';
import { Exam, Grade, Student, Class, Section, Subject, User, Campus } from '../models/index.js';
import { notifyEvent } from '../services/notificationService.js';
import { applyAcademicYearFilter, extractBaseYear } from '../utils/academicYear.js';
import { findStudentsEnrolledInClass, resolveStudentClassForYear } from '../utils/classRoster.js';
import { splitTermExams, subjectRowsFor, overallOf } from '../utils/reportCardCalc.js';

// ─── Grading scale (simple, fixed — not user-configurable, on purpose) ────────
// Percentage → letter grade. Adjust here if a school needs a different scale;
// kept as one small function rather than an admin-configurable UI to avoid
// the kind of complexity that made the Timetable module hard to use.
export const computeGrade = (percentage) => {
  if (percentage === null || percentage === undefined || Number.isNaN(percentage)) return null;
  if (percentage >= 75) return 'A';
  if (percentage >= 65) return 'B';
  if (percentage >= 45) return 'C';
  if (percentage >= 30) return 'D';
  return 'F';
};

const toNum = (v) => (v === null || v === undefined || v === '' ? null : Number(v));

// ═══════════════════════════════════════════════════════════════════════════
// EXAMS (CRUD)
// ═══════════════════════════════════════════════════════════════════════════

export const getExams = async (req, res, next) => {
  try {
    const {
      page = 1, limit = 20, search = '', status = '', academic_year = '',
      campus_id = '', sortBy = 'start_date', sortOrder = 'DESC',
    } = req.query;

    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (status) where.status = status;
    applyAcademicYearFilter(where, academic_year);
    if (campus_id) where.campus_id = campus_id;
    if (search) where.name = { [Op.iLike]: `%${search}%` };

    const { count, rows } = await Exam.findAndCountAll({
      where,
      include: [{ model: Campus, as: 'campus', attributes: ['id', 'name'] }],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [[sortBy, sortOrder]],
      distinct: true,
    });

    res.json({
      success: true,
      data: rows,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(count / limit),
        totalItems: count,
        itemsPerPage: parseInt(limit),
      },
    });
  } catch (error) {
    next(error);
  }
};

export const getExamById = async (req, res, next) => {
  try {
    const exam = await Exam.findOne({
      where: { id: req.params.id, tenant_id: req.tenantId },
      include: [{ model: Campus, as: 'campus', attributes: ['id', 'name'] }],
    });
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' });
    res.json({ success: true, data: exam });
  } catch (error) {
    next(error);
  }
};

export const createExam = async (req, res, next) => {
  try {
    const { name, exam_type, academic_year, term, start_date, end_date, status, campus_id, class_ids } = req.body;
    if (!name || !academic_year || !campus_id) {
      return res.status(400).json({ success: false, message: 'name, academic_year and campus_id are required' });
    }
    const exam = await Exam.create({
      tenant_id: req.tenantId, campus_id, name, exam_type, academic_year, term,
      start_date: start_date || null, end_date: end_date || null,
      status: status || 'draft', class_ids: Array.isArray(class_ids) ? class_ids : [],
    });
    res.status(201).json({ success: true, message: 'Exam created', data: exam });
  } catch (error) {
    next(error);
  }
};

export const updateExam = async (req, res, next) => {
  try {
    const exam = await Exam.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' });
    const { name, exam_type, academic_year, term, start_date, end_date, status, campus_id, class_ids } = req.body;
    await exam.update({
      ...(name !== undefined && { name }),
      ...(exam_type !== undefined && { exam_type }),
      ...(academic_year !== undefined && { academic_year }),
      ...(term !== undefined && { term }),
      ...(start_date !== undefined && { start_date: start_date || null }),
      ...(end_date !== undefined && { end_date: end_date || null }),
      ...(status !== undefined && { status }),
      ...(campus_id !== undefined && { campus_id }),
      ...(class_ids !== undefined && { class_ids: Array.isArray(class_ids) ? class_ids : [] }),
    });
    res.json({ success: true, message: 'Exam updated', data: exam });
  } catch (error) {
    next(error);
  }
};

export const deleteExam = async (req, res, next) => {
  try {
    const exam = await Exam.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' });
    const gradeCount = await Grade.count({ where: { exam_id: exam.id } });
    if (gradeCount > 0) {
      return res.status(400).json({ success: false, message: `Cannot delete — ${gradeCount} marks have already been entered for this exam.` });
    }
    await exam.destroy();
    res.json({ success: true, message: 'Exam deleted' });
  } catch (error) {
    next(error);
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// MARKS ENTRY
// ═══════════════════════════════════════════════════════════════════════════

/** GET /exams/:id/marks-sheet?class_id=&section_id=&subject_id=
 * Returns every active student in the class/section, each with their
 * existing mark for this exam+subject if one was already saved. */
export const getMarksSheet = async (req, res, next) => {
  try {
    const exam = await Exam.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' });

    const { class_id, section_id, subject_id } = req.query;
    if (!class_id || !subject_id) {
      return res.status(400).json({ success: false, message: 'class_id and subject_id are required' });
    }

    // Roster resolved for THIS class's own year (see
    // utils/classRoster.js) — a past exam's class must still show the
    // students who actually sat it, even if they've since been promoted
    // to a different class entirely.
    const { targetClass, students: unsorted } = await findStudentsEnrolledInClass({
      tenantId: req.tenantId, classId: class_id, sectionId: section_id || null,
    });
    if (!targetClass) return res.status(404).json({ success: false, message: 'Class not found' });
    const students = unsorted.sort((a, b) => (a.admission_number || '').localeCompare(b.admission_number || ''));

    const grades = await Grade.findAll({
      where: { tenant_id: req.tenantId, exam_id: exam.id, subject_id, student_id: students.map((s) => s.id) },
    });
    const gradeByStudent = Object.fromEntries(grades.map((g) => [g.student_id, g]));

    const rows = students.map((s) => {
      const g = gradeByStudent[s.id];
      return {
        student_id: s.id,
        admission_number: s.admission_number,
        name: `${s.user?.first_name || ''} ${s.user?.last_name || ''}`.trim(),
        marks_obtained: g ? Number(g.marks_obtained) : null,
        max_marks: g ? Number(g.max_marks) : null,
        grade: g?.grade || null,
        remarks: g?.remarks || null,
      };
    });

    res.json({ success: true, data: rows });
  } catch (error) {
    next(error);
  }
};

/** POST /exams/:id/marks
 * body: { class_id, section_id, subject_id, max_marks, records: [{ student_id, marks_obtained, remarks }] }
 * Upserts one Grade row per student and computes the letter grade. */
export const saveMarks = async (req, res, next) => {
  try {
    const exam = await Exam.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' });

    const { subject_id, max_marks, records } = req.body;
    if (!subject_id || !max_marks || !Array.isArray(records) || records.length === 0) {
      return res.status(400).json({ success: false, message: 'subject_id, max_marks and records[] are required' });
    }
    const maxMarksNum = Number(max_marks);
    if (!(maxMarksNum > 0)) {
      return res.status(400).json({ success: false, message: 'max_marks must be greater than 0' });
    }

    const results = [];
    for (const record of records) {
      const marksNum = toNum(record.marks_obtained);
      if (marksNum !== null && (marksNum < 0 || marksNum > maxMarksNum)) {
        return res.status(400).json({ success: false, message: `Marks for one student are out of range (0–${maxMarksNum})` });
      }
      const percentage = marksNum === null ? null : (marksNum / maxMarksNum) * 100;
      const grade = computeGrade(percentage);

      const [row] = await Grade.findOrCreate({
        where: { tenant_id: req.tenantId, exam_id: exam.id, student_id: record.student_id, subject_id },
        defaults: { max_marks: maxMarksNum, marks_obtained: marksNum, grade, remarks: record.remarks || null },
      });
      if (row.marks_obtained !== marksNum || Number(row.max_marks) !== maxMarksNum) {
        await row.update({ max_marks: maxMarksNum, marks_obtained: marksNum, grade, remarks: record.remarks ?? row.remarks });
      } else if (record.remarks !== undefined && record.remarks !== row.remarks) {
        await row.update({ remarks: record.remarks });
      }
      results.push(row);
    }

    // Notify students/parents whose marks were actually entered (skip
    // blanks) — best-effort, respects the "Exam Results Published"
    // notification setting.
    const notifiedStudentIds = records.filter((r) => r.marks_obtained !== null && r.marks_obtained !== '' && r.marks_obtained !== undefined).map((r) => r.student_id);
    if (notifiedStudentIds.length > 0) {
      const notifiedStudents = await Student.findAll({
        where: { id: notifiedStudentIds, tenant_id: req.tenantId },
        include: [{ model: User, as: 'user', attributes: ['first_name', 'last_name', 'phone'] }],
      });
      const subject = await Subject.findByPk(subject_id);
      const families = await familyContactsFor(req.tenantId, notifiedStudents);
      for (const student of notifiedStudents) {
        const family = families.get(student.id);
        await notifyEvent(req.tenantId, 'exam_results_published', {
          parties: {
            family: {
              recipientUserId: family?.userId || student.parent_id || student.user_id,
              smsPhone: family?.phone || null, emailTo: family?.email || null,
              title: 'Exam Results Published',
              message: `${subject?.name || 'A subject'} marks for ${exam.name} have been entered for ${student.user?.first_name || 'your child'} ${student.user?.last_name || ''}.`.trim(),
            },
          },
        });
      }
    }

    res.json({ success: true, message: `Saved marks for ${results.length} student(s)`, data: results });
  } catch (error) {
    next(error);
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// RESULTS
// ═══════════════════════════════════════════════════════════════════════════

/** GET /exams/:id/class-results?class_id=&section_id=
 * A full mark-sheet: every student in the class/section × every subject
 * that has at least one grade recorded for this exam, plus a computed
 * total/average/overall grade per student. */
export const getClassResults = async (req, res, next) => {
  try {
    const exam = await Exam.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' });

    const { class_id, section_id } = req.query;
    if (!class_id) return res.status(400).json({ success: false, message: 'class_id is required' });

    // Roster resolved for THIS class's own year (see utils/classRoster.js).
    const { targetClass, students: unsorted } = await findStudentsEnrolledInClass({
      tenantId: req.tenantId, classId: class_id, sectionId: section_id || null,
    });
    if (!targetClass) return res.status(404).json({ success: false, message: 'Class not found' });
    const students = unsorted.sort((a, b) => (a.admission_number || '').localeCompare(b.admission_number || ''));
    const studentIds = students.map((s) => s.id);

    const grades = await Grade.findAll({
      where: { tenant_id: req.tenantId, exam_id: exam.id, student_id: studentIds },
      include: [{ model: Subject, as: 'subject', attributes: ['id', 'name', 'code'] }],
    });

    // Distinct subjects that actually have marks for this exam/class
    const subjectMap = new Map();
    grades.forEach((g) => { if (g.subject) subjectMap.set(g.subject.id, g.subject); });
    const subjects = Array.from(subjectMap.values());

    const gradesByStudent = {};
    grades.forEach((g) => {
      if (!gradesByStudent[g.student_id]) gradesByStudent[g.student_id] = {};
      gradesByStudent[g.student_id][g.subject_id] = g;
    });

    const rows = students.map((s) => {
      const studentGrades = gradesByStudent[s.id] || {};
      const entered = Object.values(studentGrades).filter((g) => g.marks_obtained !== null);
      const totalObtained = entered.reduce((sum, g) => sum + Number(g.marks_obtained), 0);
      const totalMax = entered.reduce((sum, g) => sum + Number(g.max_marks), 0);
      const average = totalMax > 0 ? (totalObtained / totalMax) * 100 : null;
      return {
        student_id: s.id,
        admission_number: s.admission_number,
        name: `${s.user?.first_name || ''} ${s.user?.last_name || ''}`.trim(),
        subjects: subjects.map((subj) => {
          const g = studentGrades[subj.id];
          return {
            subject_id: subj.id,
            marks_obtained: g?.marks_obtained !== undefined && g?.marks_obtained !== null ? Number(g.marks_obtained) : null,
            max_marks: g ? Number(g.max_marks) : null,
            grade: g?.grade || null,
          };
        }),
        total_obtained: entered.length > 0 ? totalObtained : null,
        total_max: entered.length > 0 ? totalMax : null,
        average: average !== null ? Math.round(average * 100) / 100 : null,
        overall_grade: computeGrade(average),
      };
    });

    // Simple class rank by average (ties share a rank), only among students with at least one mark
    const ranked = rows.filter((r) => r.average !== null).sort((a, b) => b.average - a.average);
    let rank = 0, lastAvg = null;
    ranked.forEach((r, i) => {
      if (r.average !== lastAvg) { rank = i + 1; lastAvg = r.average; }
      r.position = rank;
    });

    res.json({ success: true, data: { exam, subjects, students: rows } });
  } catch (error) {
    next(error);
  }
};

/** GET /exams/:id/report-card/:studentId — single-student version of the above.
 * Access control: staff (admin/principal/teacher) can view any student's
 * report card. A student can only view their own. A parent can only view
 * their own linked child/children's. Everyone else is forbidden. */
export const getReportCard = async (req, res, next) => {
  try {
    const exam = await Exam.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' });

    const student = await Student.findOne({
      where: { id: req.params.studentId, tenant_id: req.tenantId },
      include: [
        { model: User, as: 'user', attributes: ['id', 'first_name', 'last_name'] },
        { model: Class, as: 'class', attributes: ['id', 'name', 'grade'] },
        { model: Section, as: 'section', attributes: ['id', 'name'] },
      ],
    });
    if (!student) return res.status(404).json({ success: false, message: 'Student not found' });

    const isStaffViewer = await can(req.user, req.tenantId, 'exams.marks');
    const isOwnRecord = student.user_id === req.user.id;
    const isParentOfStudent = student.parent_id === req.user.id;
    if (!isStaffViewer && !isOwnRecord && !isParentOfStudent) {
      return res.status(403).json({ success: false, message: 'You are not allowed to view this report card' });
    }

    // `student.class` is the class they are in NOW. A report card is a
    // record of one exam, sat in one year — printing today's class on a
    // 2026 report card states that the student sat that exam in a form
    // they had not reached yet. Resolve the class they were actually in
    // for the exam's own academic year.
    const examBaseYear = extractBaseYear(exam.academic_year);
    const examClass = await resolveStudentClassForYear({
      tenantId: req.tenantId, student, targetBaseYear: examBaseYear,
    });

    // ── The report card is for the whole TERM ────────────────────────────
    // Test    = average of the term's tests (every exam that is not a Final)
    // Exam    = the term's Final exam
    // Average = average of those two, per subject (see utils/reportCardCalc.js)
    const rosterClassId = examClass?.id || student.class_id;
    const termWhere = { tenant_id: req.tenantId, term: exam.term ?? null };
    applyAcademicYearFilter(termWhere, exam.academic_year);
    const allTermExams = await Exam.findAll({ where: termWhere, order: [['start_date', 'ASC']] });
    let termExams = allTermExams.filter(
      (e) => !e.class_ids || e.class_ids.length === 0 || e.class_ids.includes(rosterClassId),
    );
    // The exam the card was opened from always counts, whatever its class list says.
    if (!termExams.some((e) => e.id === exam.id)) termExams = [...termExams, exam];
    const { tests, finalExam } = splitTermExams(termExams);
    const testIds = new Set(tests.map((t) => t.id));
    const calcOpts = { testIds, finalId: finalExam?.id || null, gradeFn: computeGrade };

    const grades = await Grade.findAll({
      where: { tenant_id: req.tenantId, exam_id: termExams.map((e) => e.id), student_id: student.id },
      include: [{ model: Subject, as: 'subject', attributes: ['id', 'name', 'code'] }],
    });
    const subjectRows = subjectRowsFor(grades, calcOpts);
    const overall = overallOf(subjectRows);
    const average = overall.average;

    // Class position: rank this student's term average against every other
    // student in the same class/section, worked out the same way, so this
    // page and the class results always agree. The roster helper returns who
    // was really in the class during the exam's own year (not today's class).
    let position = null, classSize = null;
    if (average !== null) {
      const { students: classmates } = await findStudentsEnrolledInClass({
        tenantId: req.tenantId,
        classId: rosterClassId,
        sectionId: examClass?.id === student.class_id ? student.section_id : null,
      });
      classSize = classmates.length;
      const classmateGrades = await Grade.findAll({
        where: { tenant_id: req.tenantId, exam_id: termExams.map((e) => e.id), student_id: classmates.map((c) => c.id) },
      });
      const byStudent = new Map();
      classmateGrades.forEach((g) => {
        if (!byStudent.has(g.student_id)) byStudent.set(g.student_id, []);
        byStudent.get(g.student_id).push(g);
      });
      const averages = [...byStudent.values()]
        .map((rows) => overallOf(subjectRowsFor(rows, calcOpts)).average)
        .filter((v) => v !== null)
        .sort((a, b) => b - a);
      let rank = 0, lastAvg = null;
      for (let i = 0; i < averages.length; i++) {
        const rounded = Math.round(averages[i] * 100) / 100;
        if (rounded !== lastAvg) { rank = i + 1; lastAvg = rounded; }
        if (Math.abs(averages[i] - average) < 1e-6) { position = rank; break; }
      }
    }

    res.json({
      success: true,
      data: {
        exam,
        student: {
          id: student.id,
          admission_number: student.admission_number,
          name: `${student.user?.first_name || ''} ${student.user?.last_name || ''}`.trim(),
          class: examClass?.name || student.class?.name,
          section: examClass?.id === student.class_id ? student.section?.name : null,
          gender: student.gender,
        },
        // One row per subject: test_average, exam_score / exam_max / exam_percentage,
        // average, grade. Percentages are 0-100.
        subjects: subjectRows.map(({ _avg, ...row }) => row),
        // Which exams the Test and Exam columns were built from, so the card can say so.
        basis: {
          term: exam.term || null,
          tests: tests.map((t) => ({ id: t.id, name: t.name, exam_type: t.exam_type })),
          final: finalExam ? { id: finalExam.id, name: finalExam.name } : null,
        },
        total_obtained: overall.total,
        total_max: overall.total_max,
        average: average !== null ? Math.round(average * 100) / 100 : null,
        overall_grade: computeGrade(average),
        position,
        class_size: classSize,
        // So the card can state the year it belongs to rather than leaving
        // the reader to infer it from the exam name.
        academic_year: exam.academic_year,
      },
    });
  } catch (error) {
    next(error);
  }
};

/** GET /exams/my-results — for a logged-in student: list of exams they have at least one grade for. */
export const getMyExams = async (req, res, next) => {
  try {
    const student = await Student.findOne({ where: { tenant_id: req.tenantId, user_id: req.user.id } });
    if (!student) return res.status(404).json({ success: false, message: 'No student record linked to this account' });

    const examIds = await Grade.findAll({
      where: { tenant_id: req.tenantId, student_id: student.id },
      attributes: ['exam_id'],
      group: ['exam_id'],
      raw: true,
    });
    const exams = await Exam.findAll({
      where: { tenant_id: req.tenantId, id: examIds.map((e) => e.exam_id) },
      order: [['start_date', 'DESC']],
    });
    res.json({ success: true, data: { student_id: student.id, exams } });
  } catch (error) {
    next(error);
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// TERM SUMMARY (combines every exam in a term into one consolidated report)
// ═══════════════════════════════════════════════════════════════════════════

/** GET /exams/term-summary?academic_year=&term=&class_id=&section_id=
 * Merges marks from every exam that matches the academic year + term
 * (and applies to the given class, per Exam.class_ids) into one combined
 * mark-sheet per subject — e.g. Midterm + Final combined into a term
 * total — the same way a school's end-of-term report card works. Each
 * exam counts equally; a subject's combined mark is the sum of
 * marks_obtained across those exams out of the sum of max_marks. */
export const getTermSummary = async (req, res, next) => {
  try {
    const { academic_year, term, class_id, section_id } = req.query;
    if (!academic_year || !class_id) {
      return res.status(400).json({ success: false, message: 'academic_year and class_id are required' });
    }

    const examWhere = { tenant_id: req.tenantId };
    applyAcademicYearFilter(examWhere, academic_year);
    if (term) examWhere.term = term;
    const allExams = await Exam.findAll({ where: examWhere, order: [['start_date', 'ASC']] });
    // Only exams with no class restriction, or that explicitly include this class
    const exams = allExams.filter((e) => !e.class_ids || e.class_ids.length === 0 || e.class_ids.includes(class_id));

    if (exams.length === 0) {
      return res.json({ success: true, data: { exams: [], subjects: [], students: [] } });
    }

    const studentWhere = { tenant_id: req.tenantId, class_id, status: 'active' };
    if (section_id) studentWhere.section_id = section_id;
    const students = await Student.findAll({
      where: studentWhere,
      include: [{ model: User, as: 'user', attributes: ['id', 'first_name', 'last_name'] }],
      order: [['admission_number', 'ASC']],
    });
    const studentIds = students.map((s) => s.id);

    const grades = await Grade.findAll({
      where: { tenant_id: req.tenantId, exam_id: exams.map((e) => e.id), student_id: studentIds },
      include: [{ model: Subject, as: 'subject', attributes: ['id', 'name', 'code'] }],
    });

    const subjectMap = new Map();
    grades.forEach((g) => { if (g.subject) subjectMap.set(g.subject.id, g.subject); });
    const subjects = Array.from(subjectMap.values());

    // studentId -> subjectId -> { obtained, max }
    const combined = {};
    grades.forEach((g) => {
      if (g.marks_obtained === null) return;
      if (!combined[g.student_id]) combined[g.student_id] = {};
      if (!combined[g.student_id][g.subject_id]) combined[g.student_id][g.subject_id] = { obtained: 0, max: 0 };
      combined[g.student_id][g.subject_id].obtained += Number(g.marks_obtained);
      combined[g.student_id][g.subject_id].max += Number(g.max_marks);
    });

    const rows = students.map((s) => {
      const subjectTotals = combined[s.id] || {};
      let totalObtained = 0, totalMax = 0, anyMark = false;
      const subjectResults = subjects.map((subj) => {
        const t = subjectTotals[subj.id];
        if (!t || t.max === 0) return { subject_id: subj.id, marks_obtained: null, max_marks: null, percentage: null, grade: null };
        anyMark = true;
        totalObtained += t.obtained;
        totalMax += t.max;
        const percentage = Math.round((t.obtained / t.max) * 10000) / 100;
        return { subject_id: subj.id, marks_obtained: Math.round(t.obtained * 100) / 100, max_marks: t.max, percentage, grade: computeGrade(percentage) };
      });
      const average = anyMark && totalMax > 0 ? (totalObtained / totalMax) * 100 : null;
      return {
        student_id: s.id,
        admission_number: s.admission_number,
        name: `${s.user?.first_name || ''} ${s.user?.last_name || ''}`.trim(),
        subjects: subjectResults,
        total_obtained: anyMark ? Math.round(totalObtained * 100) / 100 : null,
        total_max: anyMark ? totalMax : null,
        average: average !== null ? Math.round(average * 100) / 100 : null,
        overall_grade: computeGrade(average),
      };
    });

    const ranked = rows.filter((r) => r.average !== null).sort((a, b) => b.average - a.average);
    let rank = 0, lastAvg = null;
    ranked.forEach((r, i) => {
      if (r.average !== lastAvg) { rank = i + 1; lastAvg = r.average; }
      r.position = rank;
    });

    res.json({
      success: true,
      data: {
        exams: exams.map((e) => ({ id: e.id, name: e.name, exam_type: e.exam_type })),
        subjects,
        students: rows,
      },
    });
  } catch (error) {
    next(error);
  }
};
