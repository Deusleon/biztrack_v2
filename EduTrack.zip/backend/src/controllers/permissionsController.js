import { Staff, User, RolePermission } from '../models/index.js';
import { AVAILABLE_PERMISSIONS, DEFAULT_ROLE_PERMISSIONS } from '../utils/permissionCatalog.js';
import { can, roleEffectivePermissions, SAVED_MARKER } from '../utils/permissionEngine.js';


const ASSIGNABLE_ROLES = [
  'admin', 'principal', 'teacher', 'student', 'parent',
  'accountant', 'librarian', 'hr', 'transport_manager', 'hostel_warden',
];

export { AVAILABLE_PERMISSIONS };

export const getAvailablePermissions = async (req, res, next) => {
  try {
    res.json({ success: true, data: AVAILABLE_PERMISSIONS });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// ROLE PERMISSIONS (primary mechanism)
// ═══════════════════════════════════════════════════════════════════════════

export const getRolePermissions = async (req, res, next) => {
  try {
    if (!(await can(req.user, req.tenantId, 'permissions.manage'))) return res.status(403).json({ success: false, message: 'Only Admin can manage role permissions.' });
    const rows = await RolePermission.findAll({ where: { tenant_id: req.tenantId } });
    const byRole = Object.fromEntries(rows.map((r) => [r.role, r]));
    // What each role can ACTUALLY do now (the saved set, or the defaults) — so the
    // screen's ticks are the truth, and unticking one really removes it.
    const data = ASSIGNABLE_ROLES.map((role) => ({
      role,
      permissions: [...roleEffectivePermissions(role, byRole[role])].sort(),
      customised: Boolean(byRole[role]?.permissions?.includes(SAVED_MARKER)),
      defaults: [...(DEFAULT_ROLE_PERMISSIONS[role] || [])].sort(),
      always_allowed: ['admin'].includes(role),
    }));
    res.json({ success: true, data });
  } catch (error) { next(error); }
};

export const updateRolePermissions = async (req, res, next) => {
  try {
    if (!(await can(req.user, req.tenantId, 'permissions.manage'))) return res.status(403).json({ success: false, message: 'Only Admin can manage role permissions.' });
    const { role } = req.params;
    if (!ASSIGNABLE_ROLES.includes(role)) return res.status(400).json({ success: false, message: 'Not an assignable role.' });
    if (role === 'admin') return res.status(400).json({ success: false, message: 'Administrators can always do everything — that is what stops a school locking itself out.' });
    const { permissions, reset } = req.body;

    // "Back to the standard permissions for this role."
    if (reset === true) {
      await RolePermission.destroy({ where: { tenant_id: req.tenantId, role } });
      return res.json({ success: true, message: 'Role permissions reset to the standard set', data: { role, permissions: [...(DEFAULT_ROLE_PERMISSIONS[role] || [])].sort(), customised: false } });
    }
    if (!Array.isArray(permissions)) return res.status(400).json({ success: false, message: 'permissions must be an array' });

    const validKeys = new Set(AVAILABLE_PERMISSIONS.map((p) => p.key));
    const cleaned = permissions.filter((p) => validKeys.has(p));

    // Stored with a marker meaning "this is the complete set" — so a permission
    // left unticked is genuinely taken away, defaults included.
    const stored = [...cleaned, SAVED_MARKER];
    const [row] = await RolePermission.findOrCreate({
      where: { tenant_id: req.tenantId, role },
      defaults: { tenant_id: req.tenantId, role, permissions: stored },
    });
    await row.update({ permissions: stored });
    res.json({ success: true, message: 'Role permissions updated', data: { role, permissions: cleaned.sort(), customised: true } });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// INDIVIDUAL OVERRIDES (secondary mechanism — additive on top of the role)
// ═══════════════════════════════════════════════════════════════════════════

export const getStaffPermissions = async (req, res, next) => {
  try {
    if (!(await can(req.user, req.tenantId, 'permissions.manage'))) return res.status(403).json({ success: false, message: 'Only Admin can manage staff permissions.' });
    const staffList = await Staff.findAll({
      where: { tenant_id: req.tenantId, status: 'active' },
      include: [{ model: User, as: 'user', attributes: ['id', 'first_name', 'last_name', 'role', 'permissions'] }],
      order: [[{ model: User, as: 'user' }, 'first_name', 'ASC']],
    });
    const data = staffList.filter((s) => s.user).map((s) => ({
      staff_id: s.id, user_id: s.user.id,
      name: `${s.user.first_name} ${s.user.last_name}`,
      role: s.user.role, department: s.department,
      permissions: s.user.permissions || [],
    }));
    res.json({ success: true, data });
  } catch (error) { next(error); }
};

export const updateUserPermissions = async (req, res, next) => {
  try {
    if (!(await can(req.user, req.tenantId, 'permissions.manage'))) return res.status(403).json({ success: false, message: 'Only Admin can manage staff permissions.' });
    const { permissions } = req.body;
    if (!Array.isArray(permissions)) return res.status(400).json({ success: false, message: 'permissions must be an array' });

    const validKeys = new Set(AVAILABLE_PERMISSIONS.map((p) => p.key));
    const cleaned = permissions.filter((p) => validKeys.has(p));

    const targetUser = await User.findOne({ where: { id: req.params.userId, tenant_id: req.tenantId } });
    if (!targetUser) return res.status(404).json({ success: false, message: 'User not found' });

    await targetUser.update({ permissions: cleaned });
    res.json({ success: true, message: 'Permissions updated', data: { user_id: targetUser.id, permissions: cleaned } });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// EFFECTIVE PERMISSION CHECK — used by other controllers
// ═══════════════════════════════════════════════════════════════════════════

export const hasPermission = (user, permissionKey, tenantId) => can(user, tenantId, permissionKey);
