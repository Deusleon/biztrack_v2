import { Attendance, Student, Class, Section } from '../models/index.js';
import { Op } from 'sequelize';
import sequelize from '../config/database.js';

/**
 * Rejects a register dated outside the current school year.
 *
 * Tanzanian school years run January to December, so "this year" is simply
 * the current calendar year. Two things this prevents:
 *   - back-filling a closed year, whose results and fees are already final
 *   - dating a register into the future, which is almost always a typo in
 *     the year field rather than an intention
 *
 * Returns an error message, or null when the date is acceptable.
 */
const attendanceDateGuard = (date) => {
  const value = String(date || '').slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return 'A valid date is required.';

  const today = new Date().toISOString().slice(0, 10);
  const currentYear = new Date().getFullYear();
  const year = parseInt(value.slice(0, 4), 10);

  if (year < currentYear) {
    return `Attendance can't be taken for ${year} — that academic year is closed. Only ${currentYear} registers can be recorded.`;
  }
  if (year > currentYear) {
    return `Attendance can't be taken for ${year} — that academic year hasn't started yet.`;
  }
  if (value > today) {
    return "Attendance can't be taken for a future date.";
  }
  return null;
};

export const markAttendance = async (req, res, next) => {
  try {
    if (req.body?.date) {
      const guard = attendanceDateGuard(req.body.date);
      if (guard) return res.status(400).json({ success: false, message: guard });
    }

    const { student_id, class_id, section_id, date, status, remarks } = req.body;
    let normalizedSectionId =
      section_id && section_id !== 'undefined' && section_id !== 'null' ? section_id : null;

    // A class that has sections must be marked per-section, never as a
    // whole — otherwise the same student could end up with two attendance
    // records for the same day under two different granularities.
    const classSections = await Section.count({ where: { class_id, tenant_id: req.tenantId } });
    if (classSections > 0 && !normalizedSectionId) {
      return res.status(400).json({
        success: false,
        message: 'This class has sections — please take attendance per section instead of for the whole class.',
      });
    }
    if (classSections === 0) normalizedSectionId = null;

    // Check if attendance already exists for this student on this date
    const existingAttendance = await Attendance.findOne({
      where: {
        tenant_id: req.tenantId,
        student_id,
        date,
      },
    });

    if (existingAttendance) {
      // Update existing attendance
      await existingAttendance.update({
        status,
        remarks,
        marked_by: req.user.id,
        latest_marked_by: req.user.id,
      });

      return res.status(200).json({
        success: true,
        message: 'Attendance updated successfully',
        data: existingAttendance,
      });
    }

    // Create new attendance record
    const attendance = await Attendance.create({
      tenant_id: req.tenantId,
      student_id,
      class_id,
      section_id: normalizedSectionId,
      date,
      status,
      remarks,
      marked_by: req.user.id,
      initial_marked_by: req.user.id,
      latest_marked_by: req.user.id,
    });

    res.status(201).json({
      success: true,
      message: 'Attendance marked successfully',
      data: attendance,
    });
  } catch (error) {
    next(error);
  }
};

export const bulkMarkAttendance = async (req, res, next) => {
  try {
    const { class_id, section_id, date, attendance_records } = req.body;

    // Registers belong to the year they were taken in. Allowing a date in a
    // closed year would let a register appear in a year whose results,
    // reports and fees have already been finalised — and the class it was
    // filed against may not even exist any more, since promotion moves
    // students into a new year's class rows.
    const guard = attendanceDateGuard(date);
    if (guard) return res.status(400).json({ success: false, message: guard });

    let normalizedSectionId =
      section_id && section_id !== 'undefined' && section_id !== 'null' ? section_id : null;

    // A class that has sections must be marked per-section — taking
    // attendance for the whole class first and then again for a specific
    // section (or vice versa) would double up records for the same
    // students on the same day. Classes with no sections are marked as a
    // whole, since there's nothing to split by.
    const classSections = await Section.count({ where: { class_id, tenant_id: req.tenantId } });
    if (classSections > 0 && !normalizedSectionId) {
      return res.status(400).json({
        success: false,
        message: 'This class has sections — please select a specific section to take attendance for.',
      });
    }
    if (classSections === 0) normalizedSectionId = null;

    const existingSession = await Attendance.findOne({
      where: {
        tenant_id: req.tenantId,
        class_id,
        section_id: normalizedSectionId,
        date,
      },
    });

    if (existingSession) {
      return res.status(409).json({
        success: false,
        message: 'Attendance already exists for this date and class. Please edit the existing session instead.',
      });
    }

    const attendanceData = attendance_records.map(record => ({
      tenant_id: req.tenantId,
      student_id: record.student_id,
      class_id,
      section_id: normalizedSectionId,
      date,
      status: record.status,
      remarks: record.remarks || null,
      marked_by: req.user.id,
      initial_marked_by: req.user.id,
      latest_marked_by: req.user.id,
    }));

    // Create new attendance records
    const attendance = await Attendance.bulkCreate(attendanceData);

    res.status(201).json({
      success: true,
      message: 'Attendance marked successfully',
      data: attendance,
    });
  } catch (error) {
    next(error);
  }
};

export const getAttendance = async (req, res, next) => {
  try {
    const {
      class_id,
      section_id,
      student_id,
      date_from,
      date_to,
      status,
      page = 1,
      limit = 10,
    } = req.query;

    const where = { tenant_id: req.tenantId };

    if (class_id) where.class_id = class_id;
    if (section_id) where.section_id = section_id;
    if (student_id) where.student_id = student_id;
    if (status) where.status = status;

    if (date_from && date_to) {
      where.date = {
        [Op.between]: [date_from, date_to],
      };
    } else if (date_from) {
      where.date = {
        [Op.gte]: date_from,
      };
    } else if (date_to) {
      where.date = {
        [Op.lte]: date_to,
      };
    }

    const offset = (page - 1) * limit;

    const { count, rows } = await Attendance.findAndCountAll({
      where,
      include: [
        {
          association: 'student',
          include: [{ association: 'user', attributes: ['first_name', 'last_name', 'email'] }],
        },
        { association: 'class', attributes: ['id', 'name', 'grade'] },
        { association: 'section', attributes: ['id', 'name'] },
        { association: 'initialMarker', attributes: ['first_name', 'last_name'] },
        { association: 'latestMarker', attributes: ['first_name', 'last_name'] },
        { association: 'markedBy', attributes: ['first_name', 'last_name'] },
      ],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['date', 'DESC']],
    });

    res.status(200).json({
      success: true,
      count,
      totalPages: Math.ceil(count / limit),
      currentPage: parseInt(page),
      data: rows,
    });
  } catch (error) {
    next(error);
  }
};

export const getAttendanceReport = async (req, res, next) => {
  try {
    const { student_id, class_id, section_id, date_from, date_to } = req.query;

    const where = { tenant_id: req.tenantId };

    if (student_id) where.student_id = student_id;
    if (class_id) where.class_id = class_id;
    if (section_id) where.section_id = section_id;

    if (date_from && date_to) {
      where.date = {
        [Op.between]: [date_from, date_to],
      };
    }

    const attendance = await Attendance.findAll({
      where,
      attributes: [
        'student_id',
        [sequelize.fn('COUNT', sequelize.col('id')), 'total_days'],
        [
          sequelize.fn('SUM', sequelize.literal("CASE WHEN status = 'present' THEN 1 ELSE 0 END")),
          'present_days',
        ],
        [
          sequelize.fn('SUM', sequelize.literal("CASE WHEN status = 'absent' THEN 1 ELSE 0 END")),
          'absent_days',
        ],
        [
          sequelize.fn('SUM', sequelize.literal("CASE WHEN status = 'late' THEN 1 ELSE 0 END")),
          'late_days',
        ],
      ],
      group: ['student_id'],
      include: [
        {
          association: 'student',
          include: [{ association: 'user', attributes: ['first_name', 'last_name', 'email'] }],
        },
      ],
    });

    res.status(200).json({
      success: true,
      data: attendance,
    });
  } catch (error) {
    next(error);
  }
};

export const getAttendanceById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const record = await Attendance.findOne({
      where: { id, tenant_id: req.tenantId },
      include: [
        {
          association: 'student',
          include: [{ association: 'user', attributes: ['first_name', 'last_name', 'email', 'phone'] }],
        },
        { association: 'class', attributes: ['id', 'name', 'grade'] },
        { association: 'section', attributes: ['id', 'name'] },
        { association: 'initialMarker', attributes: ['first_name', 'last_name', 'email'] },
        { association: 'latestMarker', attributes: ['first_name', 'last_name', 'email'] },
        { association: 'markedBy', attributes: ['first_name', 'last_name', 'email'] },
      ],
    });

    if (!record) {
      return res.status(404).json({ success: false, message: 'Attendance record not found' });
    }

    res.status(200).json({ success: true, data: record });
  } catch (error) {
    next(error);
  }
};

export const updateAttendance = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, remarks } = req.body;
    const trimmedRemarks = typeof remarks === 'string' ? remarks.trim() : '';

    if (!trimmedRemarks) {
      return res.status(400).json({ success: false, message: 'Remarks are required when updating attendance' });
    }

    const record = await Attendance.findOne({ where: { id, tenant_id: req.tenantId } });
    if (!record) {
      return res.status(404).json({ success: false, message: 'Attendance record not found' });
    }

    await record.update({
      status,
      remarks: trimmedRemarks,
      marked_by: req.user.id,
      latest_marked_by: req.user.id,
    });

    res.status(200).json({ success: true, message: 'Attendance updated successfully', data: record });
  } catch (error) {
    next(error);
  }
};

export const getAttendanceSessions = async (req, res, next) => {
  try {
    const { class_id, section_id, date_from, date_to, page = 1, limit = 20 } = req.query;

    const conditions = ['a.tenant_id = :tenantId'];
    const filterReplacements = { tenantId: req.tenantId };

    if (class_id) {
      conditions.push('a.class_id = :class_id');
      filterReplacements.class_id = class_id;
    }
    if (section_id) {
      conditions.push('a.section_id = :section_id');
      filterReplacements.section_id = section_id;
    }
    if (date_from && date_to) {
      conditions.push('a.date BETWEEN :date_from AND :date_to');
      filterReplacements.date_from = date_from;
      filterReplacements.date_to = date_to;
    } else if (date_from) {
      conditions.push('a.date >= :date_from');
      filterReplacements.date_from = date_from;
    } else if (date_to) {
      conditions.push('a.date <= :date_to');
      filterReplacements.date_to = date_to;
    }

    const whereClause = conditions.join(' AND ');
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const offset = (pageNum - 1) * limitNum;

    const sessions = await sequelize.query(
      `SELECT
         a.date,
         a.class_id,
         a.section_id,
         c.name  AS class_name,
         c.grade AS class_grade,
         s.name  AS section_name,
         COUNT(a.id)::int                                                        AS total,
         SUM(CASE WHEN a.status = 'present'  THEN 1 ELSE 0 END)::int            AS present,
         SUM(CASE WHEN a.status = 'absent'   THEN 1 ELSE 0 END)::int            AS absent,
         SUM(CASE WHEN a.status = 'late'     THEN 1 ELSE 0 END)::int            AS late,
         SUM(CASE WHEN a.status = 'excused'  THEN 1 ELSE 0 END)::int            AS excused,
         SUM(CASE WHEN a.status = 'half_day' THEN 1 ELSE 0 END)::int            AS half_day
       FROM attendance a
       LEFT JOIN classes  c ON c.id = a.class_id
       LEFT JOIN sections s ON s.id = a.section_id
       WHERE ${whereClause}
       GROUP BY a.date, a.class_id, a.section_id, c.name, c.grade, s.name
       ORDER BY a.date DESC
       LIMIT :limit OFFSET :offset`,
      {
        replacements: { ...filterReplacements, limit: limitNum, offset },
        type: 'SELECT',
      }
    );

    const countRows = await sequelize.query(
      `SELECT COUNT(*) AS count
       FROM (
         SELECT 1 FROM attendance a
         WHERE ${whereClause}
         GROUP BY a.date, a.class_id, a.section_id
       ) sub`,
      { replacements: filterReplacements, type: 'SELECT' }
    );

    const total = parseInt(countRows[0]?.count || 0);

    res.status(200).json({
      success: true,
      count: total,
      totalPages: Math.ceil(total / limitNum),
      currentPage: pageNum,
      data: sessions,
    });
  } catch (error) {
    next(error);
  }
};
