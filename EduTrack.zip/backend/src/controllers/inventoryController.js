import { Op } from 'sequelize';
import { InventoryItem, InventoryTransaction, User } from '../models/index.js';
import { INVENTORY_CONDITIONS, INVENTORY_ITEM_TYPES } from '../models/Inventory.js';

// Authorization now happens at the route level via requirePermission()
// (see inventoryRoutes.js) — kept nothing hardcoded here to avoid the
// two checks disagreeing with each other.

const emptyBreakdown = () => ({ new: 0, good: 0, fair: 0, poor: 0 });
const sumBreakdown = (b) => INVENTORY_CONDITIONS.reduce((sum, c) => sum + (Number(b?.[c]) || 0), 0);

// ── Asset vs consumable ────────────────────────────────────────────────────
// Fixed assets are tracked per condition bucket (how many are new / good /
// fair / poor). Consumables are not: they just run down, so the whole
// quantity is one pool. Internally that pool still lives in
// condition_breakdown (so quantity_on_hand always equals its sum and the two
// never drift) — received stock goes into 'new', and using stock up draws
// the buckets down worst-first, which also keeps an item that was re-typed
// from an asset consistent.
const isConsumable = (item) => item.item_type === 'consumable';
const CONSUMABLE_DRAW_ORDER = ['poor', 'fair', 'good', 'new'];
const drawDown = (breakdown, qty) => {
  const next = { ...breakdown };
  let left = qty;
  for (const c of CONSUMABLE_DRAW_ORDER) {
    const take = Math.min(Number(next[c]) || 0, left);
    next[c] = (Number(next[c]) || 0) - take;
    left -= take;
  }
  return next;
};

// ═══════════════════════════════════════════════════════════════════════════
// ITEMS
// ═══════════════════════════════════════════════════════════════════════════

export const getItems = async (req, res, next) => {
  try {
    const { search = '', category = '', status = '', low_stock = '', item_type = '' } = req.query;
    const where = { tenant_id: req.tenantId };
    if (INVENTORY_ITEM_TYPES.includes(item_type)) where.item_type = item_type;
    if (category) where.category = category;
    if (status) where.status = status;
    if (search) {
      where[Op.or] = [
        { name: { [Op.iLike]: `%${search}%` } },
        { location: { [Op.iLike]: `%${search}%` } },
      ];
    }

    let items = await InventoryItem.findAll({ where, order: [['name', 'ASC']] });
    if (low_stock === 'true') {
      // Only consumables run low — a fixed asset has no reorder level.
      items = items.filter((i) => isConsumable(i) && i.reorder_level !== null && i.quantity_on_hand <= i.reorder_level);
    }

    res.json({ success: true, data: items });
  } catch (error) { next(error); }
};

export const getItemById = async (req, res, next) => {
  try {
    const item = await InventoryItem.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!item) return res.status(404).json({ success: false, message: 'Item not found' });
    res.json({ success: true, data: item });
  } catch (error) { next(error); }
};

/** POST /inventory/items — creates the item with zero stock. Any
 * starting quantity is added afterward through the same "received"
 * transaction path bulk-receive/record-movement use, so there's exactly
 * one place that ever adjusts condition_breakdown/quantity_on_hand. */
export const createItem = async (req, res, next) => {
  try {
    const { campus_id, name, item_type = 'consumable', category, unit, quantity_on_hand, condition, reorder_level, location, notes, status } = req.body;
    if (!name) return res.status(400).json({ success: false, message: 'name is required' });
    if (!INVENTORY_ITEM_TYPES.includes(item_type)) {
      return res.status(400).json({ success: false, message: `item_type must be one of: ${INVENTORY_ITEM_TYPES.join(', ')}` });
    }
    const consumable = item_type === 'consumable';

    const item = await InventoryItem.create({
      tenant_id: req.tenantId, campus_id: campus_id || null, name, item_type, category: category || null,
      unit: unit || 'pcs', quantity_on_hand: 0, condition_breakdown: emptyBreakdown(),
      // Only consumables run low, so only they have a reorder level.
      reorder_level: consumable ? (reorder_level || null) : null,
      location: location || null, notes: notes || null, status: status || 'active',
    });

    const initialQty = quantity_on_hand ? Number(quantity_on_hand) : 0;
    if (initialQty > 0) {
      const cond = consumable ? 'new' : (INVENTORY_CONDITIONS.includes(condition) ? condition : 'good');
      const breakdown = { ...item.condition_breakdown, [cond]: item.condition_breakdown[cond] + initialQty };
      await item.update({ quantity_on_hand: initialQty, condition_breakdown: breakdown });
      await InventoryTransaction.create({
        tenant_id: req.tenantId, item_id: item.id, type: 'received', quantity: initialQty, condition: consumable ? null : cond,
        transaction_date: new Date().toISOString().slice(0, 10), notes: 'Initial stock', recorded_by: req.user.id,
      });
    }

    res.status(201).json({ success: true, message: 'Item added', data: item });
  } catch (error) { next(error); }
};

export const updateItem = async (req, res, next) => {
  try {
    const item = await InventoryItem.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!item) return res.status(404).json({ success: false, message: 'Item not found' });
    const { name, item_type, category, unit, reorder_level, location, notes, status } = req.body;
    if (item_type !== undefined && !INVENTORY_ITEM_TYPES.includes(item_type)) {
      return res.status(400).json({ success: false, message: `item_type must be one of: ${INVENTORY_ITEM_TYPES.join(', ')}` });
    }
    const effectiveType = item_type ?? item.item_type;
    await item.update({
      ...(name !== undefined && { name }),
      ...(item_type !== undefined && { item_type }),
      ...(category !== undefined && { category }),
      ...(unit !== undefined && { unit }),
      // A fixed asset never has a reorder level, whatever was sent.
      ...(effectiveType === 'asset' ? { reorder_level: null } : (reorder_level !== undefined && { reorder_level })),
      ...(location !== undefined && { location }),
      ...(notes !== undefined && { notes }),
      ...(status !== undefined && { status }),
    });
    res.json({ success: true, message: 'Item updated', data: item });
  } catch (error) { next(error); }
};

export const deleteItem = async (req, res, next) => {
  try {
    const item = await InventoryItem.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!item) return res.status(404).json({ success: false, message: 'Item not found' });
    await InventoryTransaction.destroy({ where: { item_id: item.id } });
    await item.destroy();
    res.json({ success: true, message: 'Item deleted' });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// TRANSACTIONS
// ═══════════════════════════════════════════════════════════════════════════

const txInclude = [
  { model: InventoryItem, as: 'item', attributes: ['id', 'name', 'unit'] },
  { model: User, as: 'recordedBy', attributes: ['id', 'first_name', 'last_name'] },
];

export const getTransactions = async (req, res, next) => {
  try {
    const { item_id = '', type = '', page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (item_id) where.item_id = item_id;
    if (type) where.type = type;

    const { count, rows } = await InventoryTransaction.findAndCountAll({
      where, include: txInclude,
      limit: parseInt(limit), offset: parseInt(offset),
      order: [['transaction_date', 'DESC'], ['createdAt', 'DESC']],
    });

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

/** POST /inventory/transactions
 *
 * Fixed assets: every type requires `condition` (which bucket it affects),
 * and 'adjusted' corrects that one bucket to an exact number (e.g. after a
 * physical count found only 8 "good" left, not 10).
 *
 * Consumables: no condition — they are one pool. received adds to it,
 * issued/damaged/lost take from it (never below zero), and 'adjusted' sets
 * the whole quantity to the exact counted number. */
export const createTransaction = async (req, res, next) => {
  try {
    const { item_id, type, quantity, condition, issued_to, transaction_date, notes } = req.body;
    if (!item_id || !type || quantity === undefined) {
      return res.status(400).json({ success: false, message: 'item_id, type and quantity are required' });
    }
    const qty = Number(quantity);
    if (!Number.isFinite(qty) || qty < 0) return res.status(400).json({ success: false, message: 'quantity must be zero or positive' });

    const item = await InventoryItem.findOne({ where: { id: item_id, tenant_id: req.tenantId } });
    if (!item) return res.status(404).json({ success: false, message: 'Item not found' });

    const consumable = isConsumable(item);
    // Consumables are one pool; only assets are tracked per condition.
    if (!consumable && !INVENTORY_CONDITIONS.includes(condition)) {
      return res.status(400).json({ success: false, message: `condition must be one of: ${INVENTORY_CONDITIONS.join(', ')}` });
    }

    let breakdown = { ...item.condition_breakdown };

    if (consumable) {
      const total = sumBreakdown(breakdown);
      if (type === 'received') {
        breakdown.new = (breakdown.new || 0) + qty;
      } else if (['issued', 'damaged', 'lost'].includes(type)) {
        if (qty > total) {
          return res.status(400).json({ success: false, message: `Only ${total} ${item.unit} on hand — cannot ${type === 'issued' ? 'issue' : `record ${type}`} ${qty}.` });
        }
        breakdown = drawDown(breakdown, qty);
      } else if (type === 'adjusted') {
        breakdown = { ...emptyBreakdown(), new: qty }; // exact count after a stock-take
      } else {
        return res.status(400).json({ success: false, message: 'Invalid transaction type' });
      }
    } else {
      const currentInBucket = breakdown[condition] || 0;
      if (type === 'received') {
        breakdown[condition] = currentInBucket + qty;
      } else if (['issued', 'damaged', 'lost'].includes(type)) {
        if (qty > currentInBucket) {
          return res.status(400).json({ success: false, message: `Only ${currentInBucket} ${item.unit} in "${condition}" condition on hand — cannot ${type} ${qty}.` });
        }
        breakdown[condition] = currentInBucket - qty;
      } else if (type === 'adjusted') {
        breakdown[condition] = qty; // absolute correction for this one bucket, e.g. after a physical count
      } else {
        return res.status(400).json({ success: false, message: 'Invalid transaction type' });
      }
    }

    const newTotal = sumBreakdown(breakdown);
    const transaction = await InventoryTransaction.create({
      tenant_id: req.tenantId, item_id, type, quantity: qty, condition: consumable ? null : condition, issued_to: issued_to || null,
      transaction_date: transaction_date || new Date().toISOString().slice(0, 10), notes: notes || null, recorded_by: req.user.id,
    });
    await item.update({ quantity_on_hand: newTotal, condition_breakdown: breakdown });

    res.status(201).json({ success: true, message: `Stock ${type} recorded${consumable ? '' : ` (${condition})`} — now ${newTotal} ${item.unit} on hand`, data: { transaction, item } });
  } catch (error) { next(error); }
};

/** POST /inventory/receive — records incoming stock for several items in
 * one go (e.g. a single delivery that restocks 5 different supplies at
 * once), each with its own condition — since a delivery isn't always
 * uniform (a box of 50 chairs might arrive with 2 already scratched). */
export const bulkReceive = async (req, res, next) => {
  try {
    const { transaction_date, items } = req.body;
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, message: 'items must be a non-empty array of { item_id, quantity, condition, notes? }' });
    }
    const date = transaction_date || new Date().toISOString().slice(0, 10);

    const results = [];
    for (const line of items) {
      const qty = Number(line.quantity);
      if (!line.item_id || !qty || qty <= 0) continue;
      const item = await InventoryItem.findOne({ where: { id: line.item_id, tenant_id: req.tenantId } });
      if (!item) continue;
      // Consumables have no condition: received stock simply goes into the pool.
      const consumable = isConsumable(item);
      const condition = consumable ? 'new' : (INVENTORY_CONDITIONS.includes(line.condition) ? line.condition : 'good');

      const breakdown = { ...item.condition_breakdown, [condition]: (item.condition_breakdown[condition] || 0) + qty };
      const newTotal = sumBreakdown(breakdown);

      await InventoryTransaction.create({
        tenant_id: req.tenantId, item_id: item.id, type: 'received', quantity: qty, condition: consumable ? null : condition,
        transaction_date: date, notes: line.notes || null, recorded_by: req.user.id,
      });
      await item.update({ quantity_on_hand: newTotal, condition_breakdown: breakdown });
      results.push({ item_id: item.id, name: item.name, condition: consumable ? null : condition, new_quantity: newTotal });
    }

    if (results.length === 0) return res.status(400).json({ success: false, message: 'No valid items to receive — check quantities and item selections.' });
    res.status(201).json({ success: true, message: `Received stock for ${results.length} item(s)`, data: results });
  } catch (error) { next(error); }
};
