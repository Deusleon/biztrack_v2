import jwt from 'jsonwebtoken';
import { User, Tenant } from '../models/index.js';
import { isDeveloper } from '../utils/developerAccess.js';
import { publicUrlFor } from '../middleware/upload.js';
import { normalizePhone } from '../utils/phone.js';
import { systemStartBaseYear } from '../utils/academicYear.js';
import { resolveSessionPolicy } from '../utils/sessionPolicy.js';
import { isDefaultPassword, newPasswordError, passwordVersion } from '../utils/passwords.js';
import { requestReset, completeReset, resetModeForForm } from '../services/passwordResetService.js';
import { logAuthEvent } from '../middleware/auditLog.js';
import { permissionList } from '../utils/permissionEngine.js';

// `pwv` ties a token to the password it was issued under — see utils/passwords.js.
// `user` must be loaded WITH its password hash.
const generateToken = (user) => {
  return jwt.sign({ id: user.id, pwv: passwordVersion(user.password) }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '7d',
  });
};

/**
 * POST /auth/register — creates a login account directly.
 *
 * This used to be open to anyone, with the school (`tenant_id`) and the `role`
 * both taken from the request — so anybody who knew a school's id could create
 * themselves a super_admin there and receive a working token. It now needs a
 * signed-in caller:
 *
 *   - the platform developer may create an account in any school (this is how a
 *     new school's first administrator is onboarded — there is no sign-up page);
 *   - a school's own super admin / admin may add accounts to THEIR school only,
 *     and only a super admin may create another super admin.
 *
 * Staff and students normally get their accounts from the Staff and Admission
 * screens; this endpoint is for everything else. No token is returned: creating
 * an account must not hand its session to whoever created it.
 */
export const register = async (req, res, next) => {
  try {
    const caller = req.user;
    const developer = isDeveloper(caller);
    if (!developer && !['super_admin', 'admin'].includes(caller.role)) {
      return res.status(403).json({ success: false, message: 'Only an administrator can create accounts.' });
    }

    const { email, password, first_name, last_name, role, phone } = req.body;
    const tenant_id = developer ? req.body.tenant_id : caller.tenant_id;

    if (!User.rawAttributes.role.values.includes(role)) {
      return res.status(400).json({ success: false, message: `"${role}" is not a valid role.` });
    }
    if (role === 'super_admin' && !developer && caller.role !== 'super_admin') {
      return res.status(403).json({ success: false, message: 'Only a super admin can create another super admin.' });
    }

    const tenant = tenant_id ? await Tenant.findByPk(tenant_id) : null;
    if (!tenant) return res.status(400).json({ success: false, message: 'That school does not exist.' });

    const userExists = await User.findOne({ where: { email } });
    if (userExists) {
      return res.status(400).json({ success: false, message: 'User already exists' });
    }

    const user = await User.create({ email, password, first_name, last_name, role, tenant_id, phone });

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data: {
        id: user.id,
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        role: user.role,
        tenant_id: user.tenant_id,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    // Validate email & password
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and password',
      });
    }

    // Check for user
    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials',
      });
    }

    const tenant = user.tenant_id ? await Tenant.findByPk(user.tenant_id, { attributes: ['createdAt', 'settings'] }) : null;
    const policy = resolveSessionPolicy(tenant);

    // Locked out — refuse before even checking the password, so a locked
    // account can't be used to keep probing passwords.
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      const minutesLeft = Math.max(1, Math.ceil((new Date(user.locked_until) - new Date()) / 60000));
      logAuthEvent({ req, user, title: `Sign-in refused — account is locked (${minutesLeft} min left)`, reason: 'locked' });
      return res.status(423).json({
        success: false,
        message: `Too many failed attempts. Try again in ${minutesLeft} minute${minutesLeft === 1 ? '' : 's'}.`,
      });
    }

    // Check if password matches
    const isMatch = await user.comparePassword(password);

    if (!isMatch) {
      const attempts = (user.failed_login_attempts || 0) + 1;
      const willLock = attempts >= policy.max_login_attempts;
      await user.update({
        failed_login_attempts: willLock ? 0 : attempts,
        locked_until: willLock ? new Date(Date.now() + policy.lockout_minutes * 60000) : null,
      });

      logAuthEvent({
        req, user, reason: willLock ? 'locked_out' : 'wrong_password',
        title: willLock
          ? `Failed sign-in — account locked for ${policy.lockout_minutes} min after ${policy.max_login_attempts} wrong passwords`
          : `Failed sign-in — wrong password (attempt ${attempts} of ${policy.max_login_attempts})`,
      });

      if (willLock) {
        return res.status(423).json({
          success: false,
          message: `Too many failed attempts. Account locked for ${policy.lockout_minutes} minutes.`,
        });
      }

      const remaining = policy.max_login_attempts - attempts;
      return res.status(401).json({
        success: false,
        message: `Invalid credentials. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining before lockout.`,
      });
    }

    // Check if user is active
    if (user.status !== 'active') {
      logAuthEvent({ req, user, title: 'Sign-in refused — account is not active', reason: 'inactive' });
      return res.status(403).json({
        success: false,
        message: 'User account is not active',
      });
    }

    // Correct password — clear any accumulated failed attempts and update last login
    await user.update({ last_login: new Date(), failed_login_attempts: 0, locked_until: null });

    // Someone signing in with the shared starting password must choose their own
    // before doing anything else — whether or not the "must change" mark is still
    // on their account (it may never have been set, e.g. for accounts created
    // before the rule existed, or cleared by an older version).
    if (!user.must_change_password && isDefaultPassword(password)) {
      await user.update({ must_change_password: true });
    }

    const token = generateToken(user);

    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        id: user.id,
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        role: user.role,
        tenant_id: user.tenant_id,
        must_change_password: user.must_change_password,
        effective_permissions: await permissionList(user, user.tenant_id),
        is_developer: isDeveloper(user),
        academic_records_start_year: systemStartBaseYear(tenant),
        token,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const getMe = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ['password'] },
    });

    // The earliest academic year the year-picker should offer, and the
    // floor historical/projected student data won't go below — see
    // utils/academicYear.js. Sent here (rather than a separate endpoint)
    // because the frontend already fetches this on every load.
    const tenant = user.tenant_id ? await Tenant.findByPk(user.tenant_id, { attributes: ['createdAt', 'settings'] }) : null;

    res.status(200).json({
      success: true,
      data: { ...user.toJSON(), effective_permissions: await permissionList(user, user.tenant_id), is_developer: isDeveloper(user), academic_records_start_year: systemStartBaseYear(tenant) },
    });
  } catch (error) {
    next(error);
  }
};

export const updateProfile = async (req, res, next) => {
  try {
    const { first_name, middle_name, last_name, phone, avatar } = req.body;

    const user = await User.findByPk(req.user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    await user.update({
      first_name: first_name || user.first_name,
      middle_name: middle_name !== undefined ? (middle_name || null) : user.middle_name,
      last_name: last_name || user.last_name,
      phone: phone ? normalizePhone(phone) : user.phone,
      avatar: avatar || user.avatar,
    });

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      data: {
        id: user.id,
        email: user.email,
        first_name: user.first_name,
        middle_name: user.middle_name,
        last_name: user.last_name,
        role: user.role,
        phone: user.phone,
        avatar: user.avatar,
      },
    });
  } catch (error) {
    next(error);
  }
};

/** POST /auth/profile/avatar — lets any logged-in user set their own
 * profile photo (separate from updateProfile since it's multipart). */
export const uploadAvatar = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });
    const user = await User.findByPk(req.user.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    const url = publicUrlFor(req, 'avatars', req.file.filename);
    await user.update({ avatar: url });
    res.status(200).json({ success: true, message: 'Avatar updated', data: { avatar: url } });
  } catch (error) {
    next(error);
  }
};

export const changePassword = async (req, res, next) => {
  try {
    const { current_password, new_password } = req.body;

    if (!current_password || !new_password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide current and new password',
      });
    }

    const user = await User.findByPk(req.user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    const isMatch = await user.comparePassword(current_password);

    if (!isMatch) {
      logAuthEvent({ req, user, title: 'Failed password change — wrong current password', reason: 'wrong_current_password' });
      // 400, not 401: the person IS signed in. A 401 makes the app sign them out,
      // so one typo here used to throw them out of their session.
      return res.status(400).json({
        success: false,
        message: 'Current password is incorrect',
      });
    }

    const problem = newPasswordError(new_password, current_password);
    if (problem) return res.status(400).json({ success: false, message: problem });

    await user.update({ password: new_password, must_change_password: false });
    // The password just changed, so every earlier session is now void — including
    // the one making this request. The new token keeps THIS browser signed in.
    await user.reload();

    res.status(200).json({
      success: true,
      message: 'Password changed successfully',
      data: { token: generateToken(user) },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /auth/forgot-password  { identifier }   — email or phone number
 *
 * Always answers the same way, whether or not the account exists or could be
 * reached, so it can't be used to find out who has an account. The code is sent
 * after the answer, so a slow SMS gateway doesn't make "found" look different
 * from "not found".
 */
export const forgotPassword = async (req, res) => {
  const { identifier } = req.body;
  res.status(200).json({
    success: true,
    message: 'If an account matches, a 6-digit code has been sent by SMS and/or email. It is valid for 15 minutes.',
  });
  requestReset(identifier).catch((err) => console.error('[password-reset] request failed:', err.message));
};

/** POST /auth/reset-password  { identifier, code, new_password } */
export const resetPassword = async (req, res, next) => {
  try {
    const { identifier, code, new_password } = req.body;
    const result = await completeReset({ identifier, code, newPassword: new_password });
    if (!result.ok) return res.status(result.status).json({ success: false, message: result.message });
    res.status(200).json({ success: true, message: 'Your password has been reset. You can now sign in with it.' });
  } catch (error) { next(error); }
};

/** GET /auth/forgot-password/options — what the form should ask for: 'email', 'sms' or 'either'. */
export const forgotPasswordOptions = async (req, res, next) => {
  try {
    res.json({ success: true, data: { mode: await resetModeForForm() } });
  } catch (error) { next(error); }
};
