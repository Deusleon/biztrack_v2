import { isOwnStudentRecord } from '../middleware/access.js';
import { can } from '../utils/permissionEngine.js';
import { Student, User, Campus, Class, Section, Attendance, Tenant, Grade, Payment, StudentPromotion, Exam } from '../models/index.js';
import { notifyEvent } from '../services/notificationService.js';
import { ensureBackupBeforeRiskyAction } from '../services/backup/backupService.js';
import { Op, literal, col, fn, where as sequelizeWhere } from 'sequelize';
import { generateStudentEmail, DEFAULT_STUDENT_PASSWORD } from '../utils/studentCredentials.js';
import { upsertParentContact } from './contactController.js';
import { normalizePhone } from '../utils/phone.js';
import { isRealDate, ageOn } from '../utils/importChecks.js';
import { computeGrade } from './examController.js';
import { expectedForStudent } from './feeController.js';
import { extractBaseYear, systemStartBaseYear, applyAcademicYearFilter, academicYearDateRange } from '../utils/academicYear.js';
import { resolveHistoricalEnrollment } from '../utils/studentHistory.js';
import { resolveStudentClassForYear } from '../utils/classRoster.js';

/** Bulk upload and the manual admission form both send Transport/Hostel
 * "Required" as Yes/No text (a spreadsheet cell, or a form select) — not
 * as a real boolean — so this normalizes whatever comes in to an actual
 * boolean before it hits the DB column. Case-insensitive and trims
 * stray spaces on purpose: a spreadsheet cell might read "Yes", "YES",
 * "yes ", or even just "Y" depending on how someone typed it, and only
 * matching an exact lowercase "yes" silently treated every one of those
 * as "No" instead — the admin's own "Yes" in the file was quietly
 * discarded rather than saved. */
const toBool = (v) => {
  if (v === true) return true;
  if (v === false || v === null || v === undefined) return false;
  const normalized = String(v).trim().toLowerCase();
  return normalized === 'yes' || normalized === 'true' || normalized === 'y' || normalized === '1';
};

const CLASS_ATTRS = ['id', 'name', 'grade', 'education_level', 'academic_year', 'campus_id'];

/**
 * Where a student actually sat in a given academic year.
 *
 * Promotion moves a student between class rows, and a class row belongs to
 * one academic year — so `student.class_id` answers "where are they now?",
 * never "where were they in 2025?". The promotion history holds that:
 *
 *   - a run closing year Y records the student's class in Y as `from_class_id`
 *   - a run opening year Y records their class in Y as `to_class_id`
 *
 * Falls back to the current class when no promotion touches that year,
 * which is the right answer for the current year and for any school that
 * has not run a promotion yet.
 *
 * `enrolled` is false when the student demonstrably wasn't at the school
 * that year — showing their current class in that case would be a lie.
 */
const resolvePlacementForYear = async (tenantId, student, requestedYear) => {
  const currentYear = student.class?.academic_year || null;

  const base = {
    academicYear: requestedYear || currentYear,
    isHistorical: false,
    enrolled: true,
    class: student.class || null,
    section: student.section || null,
  };

  if (!requestedYear || requestedYear === currentYear) return base;

  const promotions = await StudentPromotion.findAll({
    where: {
      tenant_id: tenantId,
      student_id: student.id,
      reverted_at: null,
      [Op.or]: [{ from_academic_year: requestedYear }, { to_academic_year: requestedYear }],
    },
    include: [
      { model: Class, as: 'fromClass' },
      { model: Class, as: 'toClass' },
    ],
    order: [['created_at', 'DESC']],
  });

  // A run that CLOSED the requested year is the most direct evidence:
  // it recorded the class the student was leaving.
  const closing = promotions.find((p) => p.from_academic_year === requestedYear);
  if (closing?.fromClass) {
    const section = closing.from_section_id
      ? await Section.findByPk(closing.from_section_id)
      : null;
    return { academicYear: requestedYear, isHistorical: true, enrolled: true, class: closing.fromClass, section };
  }

  // Otherwise a run that OPENED it tells us where they were placed.
  const opening = promotions.find((p) => p.to_academic_year === requestedYear);
  if (opening?.toClass) {
    const section = opening.to_section_id
      ? await Section.findByPk(opening.to_section_id)
      : null;
    return { academicYear: requestedYear, isHistorical: true, enrolled: true, class: opening.toClass, section };
  }

  // No promotion links this student to that year. If they have promotion
  // history at all, the year predates their enrolment (or follows their
  // leaving) — say so instead of showing an unrelated class.
  const anyHistory = await StudentPromotion.count({
    where: { tenant_id: tenantId, student_id: student.id, reverted_at: null },
  });

  if (anyHistory > 0) {
    return { academicYear: requestedYear, isHistorical: true, enrolled: false, class: null, section: null };
  }

  // No history at all — nothing has moved, so the current class is right.
  return { ...base, academicYear: requestedYear, isHistorical: requestedYear !== currentYear };
};

// ─────────────────────────────────────────────────────────────────────────────
// Excel import (students): ONE validator used by both the preview and the real import,
// so what the preview promises is exactly what the import does.
// ─────────────────────────────────────────────────────────────────────────────
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * Returns an async function that checks one spreadsheet row against the school's records.
 * It resolves names to records (campus, class, section) with a per-call cache, and reports
 *   errors    — the row cannot be imported
 *   warnings  — it can, but look twice (e.g. an unusual age)
 *   fields    — the cleaned values the import will use
 */
export const buildStudentRowValidator = ({ tenantId, academicYear }) => {
  const campusCache = new Map();
  const classCache = new Map();
  const findCampus = async (name) => {
    const key = String(name || '').trim().toLowerCase();
    if (!key) return null;
    if (campusCache.has(key)) return campusCache.get(key);
    const found = await Campus.findOne({ where: { tenant_id: tenantId, name: { [Op.iLike]: name.trim() } } });
    campusCache.set(key, found);
    return found;
  };
  const findClass = async (campusId, name) => {
    const key = `${campusId}::${String(name || '').trim().toLowerCase()}`;
    if (!key.split('::')[1]) return null;
    if (classCache.has(key)) return classCache.get(key);
    const where = { tenant_id: tenantId, campus_id: campusId, name: { [Op.iLike]: name.trim() } };
    // Base-year match, not an exact string match (see utils/academicYear.js): Primary/O-Level classes store a
    // single year ("2026") while the global selector is a span ("2026-2027").
    applyAcademicYearFilter(where, academicYear);
    const found = await Class.findOne({ where, include: [{ model: Section, as: 'sections' }] });
    classCache.set(key, found);
    return found;
  };

  return async (row = {}) => {
    const errors = [];
    const warnings = [];
    const fields = {
      first_name: String(row.first_name || '').trim(),
      last_name: String(row.last_name || '').trim(),
      middle_name: String(row.middle_name || '').trim(),
      admission_number: String(row.admission_number || '').trim(),
      date_of_birth: row.date_of_birth ? String(row.date_of_birth).trim() : '',
      admission_date: row.admission_date ? String(row.admission_date).trim() : '',
      parent_name: String(row.parent_name || '').trim(),
      parent_phone: String(row.parent_phone || '').trim(),
      parent_email: String(row.parent_email || '').trim(),
    };
    const genderRaw = String(row.gender || '').trim().toLowerCase();
    fields.gender = ['male', 'female', 'other'].includes(genderRaw) ? genderRaw : null;

    if (!fields.first_name) errors.push('First name is required');
    if (!fields.last_name) errors.push('Last name is required');
    if (!fields.gender) errors.push('Gender must be Male, Female or Other');
    if (!fields.date_of_birth || !isRealDate(fields.date_of_birth)) {
      errors.push('Date of birth is missing or not a real date (write it as YYYY-MM-DD)');
    } else {
      const age = ageOn(fields.date_of_birth);
      if (age < 0) errors.push('Date of birth is in the future');
      else if (age < 2 || age > 25) warnings.push(`Age ${age} looks unusual for a student — check the date of birth`);
    }
    if (!fields.admission_number) errors.push('Admission number is required');
    if (!fields.admission_date || !isRealDate(fields.admission_date)) errors.push('Admission date is missing or not a real date (write it as YYYY-MM-DD)');
    if (fields.parent_email && !EMAIL_RE.test(fields.parent_email)) errors.push('Parent email is not a valid email address');
    if (fields.parent_phone && !/^\+?[\d\s-]{9,15}$/.test(fields.parent_phone)) warnings.push('Parent phone does not look like a phone number');
    if ((fields.parent_phone || fields.parent_email) && !fields.parent_name) warnings.push('A parent contact is given without a parent name, so no contact will be saved');

    let campus = null;
    if (!row.campus_name || !String(row.campus_name).trim()) {
      errors.push('Campus is required');
    } else {
      campus = await findCampus(row.campus_name);
      if (!campus) errors.push(`Campus "${row.campus_name}" was not found`);
    }

    let matchedClass = null;
    let matchedSection = null;
    if (campus && row.class_name && String(row.class_name).trim()) {
      matchedClass = await findClass(campus.id, row.class_name);
      if (!matchedClass) errors.push(`Class "${row.class_name}" was not found on campus "${row.campus_name}"`);
      else if (row.section_name && String(row.section_name).trim()) {
        matchedSection = (matchedClass.sections || []).find((sec) => sec.name.trim().toLowerCase() === String(row.section_name).trim().toLowerCase());
        if (!matchedSection) errors.push(`Section "${row.section_name}" was not found in class "${row.class_name}"`);
      }
    } else if (!row.class_name || !String(row.class_name).trim()) {
      warnings.push('No class given — the student will be admitted without a class');
    }

    let existingAdmission = false;
    if (fields.admission_number) {
      const existing = await Student.findOne({ where: { admission_number: fields.admission_number, tenant_id: tenantId } });
      if (existing) { existingAdmission = true; errors.push(`Admission number "${fields.admission_number}" already exists`); }
    }

    return { errors, warnings, fields, campus, matchedClass, matchedSection, existingAdmission };
  };
};

/** How many more students the school's plan allows (Infinity when unlimited, or for a super admin). */
const studentSlotsLeft = async (req) => {
  if (req.user.role === 'super_admin') return { remaining: Infinity, limit: null };
  const { SubscriptionPlan, Subscription: SubscriptionModel } = await import('../models/index.js');
  const subscription = await SubscriptionModel.findOne({ where: { tenant_id: req.tenantId } });
  const plan = subscription?.plan_id ? await SubscriptionPlan.findByPk(subscription.plan_id) : null;
  if (plan && plan.student_limit !== null) {
    const currentCount = await Student.count({ where: { tenant_id: req.tenantId, status: 'active' } });
    return { remaining: Math.max(0, plan.student_limit - currentCount), limit: plan.student_limit };
  }
  return { remaining: Infinity, limit: null };
};


/** Whole-school head-counts for the Students stat cards. They ignore the page, search and status filter on
 * purpose: "Active" must mean every active student, not the ones that happen to be on the current page.
 * Still scoped to what the caller may see (campus, and a parent's / student's own record). */
const studentHeadcounts = async (where) => {
  const scope = {};
  ['tenant_id', 'campus_id', 'parent_id', 'user_id'].forEach((k) => { if (where[k]) scope[k] = where[k]; });
  const rows = await Student.findAll({ where: scope, attributes: ['status', [fn('COUNT', col('id')), 'n']], group: ['status'], raw: true });
  const by = Object.fromEntries(rows.map((r) => [r.status, Number(r.n)]));
  const total = rows.reduce((sum, r) => sum + Number(r.n), 0);
  return { total, active: by.active || 0, inactive: by.inactive || 0 };
};

const IMPORT_MAX_ROWS = 500;

export const studentController = {
  async getAll(req, res, next) {
    try {
      const { page = 1, limit = 10, search = '', status = '', campus_id = '', class_id = '', section_id = '', gender = '', parent_id = '', hostel_required = '', transport_required = '', academic_year = '', sortBy = 'name', sortOrder = 'ASC' } = req.query;
      const offset = (page - 1) * limit;
      const where = { tenant_id: req.tenantId };
      if (status) where.status = status;
      if (campus_id) where.campus_id = campus_id;
      if (gender) where.gender = gender;
      if (parent_id) where.parent_id = parent_id;
      // A parent sees only their own children and a student only themself —
      // whatever the query string says (a parent could otherwise pass someone
      // else's `parent_id`). The parent portal loads its children with
      // `?parent_id=<me>`, which this leaves working.
      if (!(await can(req.user, req.tenantId, 'students.view'))) {
        if (req.user.role === 'parent') where.parent_id = req.user.id;
        else if (req.user.role === 'student') where.user_id = req.user.id;
        else return res.status(403).json({ success: false, message: "You don't have permission to view students (students.view)." });
      }
      // Opt-in service flags, set at admission. Allocation screens filter on
      // these so a student whose parent declined hostel or transport never
      // appears in the list of people to allocate — offering them at all is
      // what leads to charging a family for a service they never asked for.
      if (hostel_required !== '') where.hostel_required = hostel_required === 'true';
      if (transport_required !== '') where.transport_required = transport_required === 'true';
      const userInclude = { model: User, as: 'user', attributes: { exclude: ['password'] }, required: false };
      if (search) {
        // A student can be found by EITHER their own admission_number OR
        // their linked User's name/email — two different tables, so this
        // has to be one genuine OR spanning both, not two separate `where`
        // clauses (one on Student, one on the User include). Splitting it
        // that way silently broke both directions: with the User include
        // left as a plain LEFT JOIN, a name-only search filtered on the
        // Student side found nothing (admission_number obviously never
        // contains a name); and searching by admission_number "worked" but
        // returned the student with a blank name, because Sequelize moves
        // an include's `where` into the JOIN's ON clause when that include
        // isn't `required` — a name that doesn't match the search term
        // failed the ON clause, so the LEFT JOIN still returned the
        // Student row but with every User column NULLed out.
        const term = `%${search}%`;
        where[Op.or] = [
          { admission_number: { [Op.iLike]: term } },
          sequelizeWhere(col('user.first_name'), { [Op.iLike]: term }),
          sequelizeWhere(col('user.middle_name'), { [Op.iLike]: term }),
          sequelizeWhere(col('user.last_name'), { [Op.iLike]: term }),
          sequelizeWhere(col('user.email'), { [Op.iLike]: term }),
        ];
      }
      const headcounts = await studentHeadcounts(where);
      // "name" sorts alphabetically by the linked user's first/last name
      // (the default — most lists read naturally A→Z by person). Any other
      // column name (e.g. "admission_number", "created_at") sorts directly.
      // Default list order: Female students first, then Male, then any
      // other gender value — each group sorted alphabetically by name.
      const order = sortBy === 'name'
        ? [
            [literal(`CASE "gender" WHEN 'female' THEN 0 WHEN 'male' THEN 1 ELSE 2 END`), 'ASC'],
            [{ model: User, as: 'user' }, 'first_name', sortOrder],
            [{ model: User, as: 'user' }, 'last_name', sortOrder],
          ]
        : [[sortBy, sortOrder]];

      // No academic-year selector applied — behave exactly as before:
      // whatever class/section a student is CURRENTLY in, filtered and
      // paginated entirely in SQL.
      if (!academic_year) {
        if (class_id) where.class_id = class_id;
        if (section_id) where.section_id = section_id;
        const { count, rows: students } = await Student.findAndCountAll({
          where,
          include: [userInclude, { model: Campus, as: 'campus', attributes: ['id', 'name', 'code'] }, { model: Class, as: 'class', attributes: CLASS_ATTRS }, { model: Section, as: 'section', attributes: ['id', 'name'] }],
          limit: parseInt(limit), offset: parseInt(offset), order, distinct: true,
        });
        return res.json({ success: true, data: students, pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) }, stats: headcounts });
      }

      // An academic year WAS selected — this is the historical/projected
      // view (see utils/studentHistory.js). Visibility depends on a
      // per-student calculation that can't be expressed as one SQL WHERE,
      // so filtering/pagination happen in application code below instead.
      const targetBaseYear = extractBaseYear(academic_year);
      const tenant = await Tenant.findByPk(req.tenantId, { attributes: ['createdAt', 'settings'] });
      const startBaseYear = systemStartBaseYear(tenant);

      const candidates = await Student.findAll({
        where,
        include: [userInclude, { model: Campus, as: 'campus', attributes: ['id', 'name', 'code'] }, { model: Class, as: 'class', attributes: CLASS_ATTRS }, { model: Section, as: 'section', attributes: ['id', 'name'] }],
        order,
      });

      const studentIds = candidates.map((s) => s.id);
      const promotions = studentIds.length
        ? await StudentPromotion.findAll({
            where: { tenant_id: req.tenantId, student_id: studentIds, reverted_at: null },
            include: [
              { model: Class, as: 'fromClass', attributes: ['grade', 'education_level'] },
              { model: Class, as: 'toClass', attributes: ['grade', 'education_level'] },
            ],
          })
        : [];
      const eventsByStudent = new Map();
      for (const p of promotions) {
        if (!eventsByStudent.has(p.student_id)) eventsByStudent.set(p.student_id, []);
        eventsByStudent.get(p.student_id).push({
          action: p.action,
          from_base_year: p.from_academic_year ? extractBaseYear(p.from_academic_year) : null,
          from_grade: p.fromClass?.grade ?? null,
          from_education_level: p.fromClass?.education_level ?? null,
          to_base_year: p.to_academic_year ? extractBaseYear(p.to_academic_year) : null,
          to_grade: p.toClass?.grade ?? null,
          to_education_level: p.toClass?.education_level ?? null,
        });
      }

      // Optional class_id filter, applied AFTER historical resolution: it
      // only makes sense here as "students who were in this SPECIFIC
      // class row during the requested year" — matched by comparing the
      // resolved grade/education_level/campus against that class, since
      // the class_id itself belongs to whatever year it was created for.
      let targetClassFilter = null;
      if (class_id) {
        const cls = await Class.findOne({ where: { id: class_id, tenant_id: req.tenantId }, attributes: CLASS_ATTRS });
        if (cls) targetClassFilter = { grade: cls.grade, education_level: cls.education_level, campus_id: cls.campus_id };
      }

      const resolved = candidates
        .map((student) => {
          const admissionBaseYear = student.admission_date ? new Date(student.admission_date).getFullYear() : null;
          // A student admitted WITHOUT a class has no grade to resolve a year from (resolveHistoricalEnrollment needs one), and used to
          // vanish from this list. They are still a student of the school: show them, with no class, from their admission
          // year on, until they are given a class.
          if (!student.class) {
            const notYetAdmitted = admissionBaseYear !== null && targetBaseYear < admissionBaseYear;
            const beforeSystem = startBaseYear !== null && targetBaseYear < startBaseYear;
            return { student, enrollment: { visible: !notYetAdmitted && !beforeSystem, grade: null, education_level: null, source: 'unassigned' } };
          }
          const enrollment = resolveHistoricalEnrollment({
            current: student.class ? {
              grade: student.class.grade, education_level: student.class.education_level, academic_year: student.class.academic_year,
            } : null,
            admissionBaseYear,
            promotionEvents: eventsByStudent.get(student.id) || [],
            targetBaseYear,
            systemStartBaseYear: startBaseYear,
          });
          return { student, enrollment };
        })
        .filter(({ enrollment }) => enrollment.visible)
        .filter(({ student, enrollment }) => {
          if (!targetClassFilter) return true;
          return enrollment.grade === targetClassFilter.grade
            && enrollment.education_level === targetClassFilter.education_level
            && student.campus_id === targetClassFilter.campus_id;
        })
        .map(({ student, enrollment }) => {
          const plain = student.toJSON();
          // Overwrite the displayed class with what's ACTUALLY correct
          // for the requested year, rather than the student's current
          // one — this is the whole point of the feature. `section` is
          // cleared for any year other than the current one: sections
          // are a CURRENT-year construct (see Class/Section), so which
          // stream a student was in during a past year isn't tracked
          // and showing this year's section against a past grade would
          // be misleading rather than merely incomplete.
          plain.historical_view = {
            requested_academic_year: academic_year,
            source: enrollment.source,
          };
          if (enrollment.source === 'unassigned') { plain.class = null; plain.section = null; return plain; }
          plain.class = {
            ...(plain.class || {}),
            grade: enrollment.grade,
            education_level: enrollment.education_level,
            name: enrollment.source === 'current' ? plain.class?.name : null,
          };
          if (enrollment.source !== 'current') plain.section = null;
          return plain;
        });

      const count = resolved.length;
      const paged = resolved.slice(offset, offset + parseInt(limit));

      res.json({ success: true, data: paged, pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) }, stats: headcounts });
    } catch (error) { next(error); }
  },

  async getById(req, res, next) {
    try {
      const { id, academic_year } = req.params;
      const student = await Student.findOne({
        where: { id, tenant_id: req.tenantId},
        include: [{ model: User, as: 'user', attributes: { exclude: ['password'] } }, { model: Campus, as: 'campus' }, { model: Class, as: 'class' }, { model: Section, as: 'section' }, { model: User, as: 'parent', attributes: { exclude: ['password'] } }],
      });
      if (!student) return res.status(404).json({ success: false, message: 'Student not found' });
      if (!(await can(req.user, req.tenantId, 'students.view')) && !isOwnStudentRecord(req.user, student)) {
        return res.status(403).json({ success: false, message: 'You can only view your own record' });
      }

      // `student.class_id` is only ever the CURRENT class. Once a student
      // has been promoted it points at the new year's class, so viewing an
      // earlier year would show the class they are in now — which is not
      // where they were then. The promotion history is the only record of
      // where they actually sat in a given year.
      const requestedYear = req.query.academic_year || null;
      const placement = await resolvePlacementForYear(req.tenantId, student, requestedYear);

      res.json({
        success: true,
        data: {
          ...student.toJSON(),
          // Present regardless, so the UI can always say which year it is
          // showing rather than leaving the reader to assume.
          viewing_academic_year: placement.academicYear,
          is_historical_view: placement.isHistorical,
          historical_class: placement.class,
          historical_section: placement.section,
          enrolled_in_year: placement.enrolled,
        },
      });
    } catch (error) { next(error); }
  },

  async create(req, res, next) {
    try {
      const { first_name, middle_name, last_name, admission_number, roll_number, campus_id, date_of_birth, gender, address, city, state, country, postal_code, admission_date, class_id, section_id, parent_id, parent_name, parent_phone, parent_email, parent_address, emergency_contact, other_notes, transport_required, hostel_required, status = 'active' } = req.body;
      const existing = await Student.findOne({ where: { admission_number, tenant_id: req.tenantId } });
      if (existing) return res.status(400).json({ success: false, message: 'Admission number already exists' });
      const campus = await Campus.findOne({ where: { id: campus_id, tenant_id: req.tenantId } });
      if (!campus) return res.status(400).json({ success: false, message: 'Invalid campus ID' });

      // Students don't supply their own email/password at admission — we
      // generate a login identity for them from their name + admission
      // number, and a shared default password they're expected to change
      // after their first login (see /auth/change-password).
      const tenant = await Tenant.findByPk(req.tenantId);
      const email = generateStudentEmail({ admissionNumber: admission_number, tenantSlug: tenant?.slug });
      const password = DEFAULT_STUDENT_PASSWORD;

      const user = await User.create({ tenant_id: req.tenantId, email, password, first_name, middle_name: middle_name || null, last_name, role: 'student', status: 'active', must_change_password: true });
      const student = await Student.create({
        tenant_id: req.tenantId, user_id: user.id, campus_id, admission_number,
        roll_number: roll_number || null, date_of_birth: date_of_birth || null, gender: gender || null,
        address: address || null, city: city || null, state: state || null,
        country: country || null, postal_code: postal_code || null, admission_date: admission_date || null,
        class_id: class_id || null, section_id: section_id || null, parent_id: parent_id || null,
        parent_name: parent_name || null, parent_phone: normalizePhone(parent_phone) || null,
        parent_email: parent_email || null, parent_address: parent_address || null,
        emergency_contact: emergency_contact || null, other_notes: other_notes || null,
        transport_required: toBool(transport_required), hostel_required: toBool(hostel_required), status,
      });

      // Keep the Messages contact book in sync with whatever guardian info
      // was entered here — no need to re-register the same phone/email
      // separately in the Messages feature.
      if (parent_name && (parent_phone || parent_email)) {
        await upsertParentContact({
          tenantId: req.tenantId, campusId: campus_id, name: parent_name,
          phone: normalizePhone(parent_phone), email: parent_email, userId: req.user.id, linkedUserId: parent_id || null,
        });
      }
      const created = await Student.findByPk(student.id, {
        include: [{ model: User, as: 'user', attributes: { exclude: ['password'] } }, { model: Campus, as: 'campus' }, { model: Class, as: 'class' }, { model: Section, as: 'section' }],
      });
      // One event, two parties (Settings → Notifications decides who is told and how): the school leadership, and — only if the
      // admission form has a phone or email for them — the parent, in Swahili, with the admission number and class.
      const className = created?.class?.name || null;
      const parties = {
        admins: { title: 'New Student Admitted', message: `${first_name} ${last_name} has been admitted (${admission_number}).`.replace(/\s+/g, ' ').trim() },
      };
      if (parent_phone || parent_email) {
        parties.family = {
          recipientUserId: parent_id || null,
          title: 'Admission Imekamilika',
          message: `Habari ${parent_name || 'Mzazi'}, admission ya ${first_name} ${last_name} imekamilika. Namba ya admission: ${admission_number}${className ? `, Darasa: ${className}` : ''}.`.replace(/\s+/g, ' ').trim(),
          smsPhone: parent_phone ? normalizePhone(parent_phone) : null,
          emailTo: parent_email || null,
          emailSubject: `Admission Imekamilika - ${first_name} ${last_name} (${admission_number})`,
        };
      }
      const notice = await notifyEvent(req.tenantId, 'student_admitted', { parties });
      const partyNotice = (key) => (notice.parties[key] ? { enabled: notice.enabled && !notice.parties[key].skipped, ...notice.parties[key] } : null);
      const adminNotice = partyNotice('admins') || { enabled: notice.enabled, in_app: 'skipped', sms: 'skipped', email: 'skipped', errors: [] };
      const parentNotice = partyNotice('family');

      res.status(201).json({
        success: true,
        message: 'Student created successfully',
        data: created,
        // Surfaced once so the front-end can show/print the generated
        // credentials — they aren't retrievable again after this (the
        // password is hashed at rest), so the admin must record them now.
        credentials: { email, password },
        // What actually happened with the notifications, so the admission
        // screen can say so instead of leaving the admin to guess whether the
        // parent was told. `parent` is null when there was no phone or email
        // to send to.
        notifications: { admin: adminNotice, parent: parentNotice },
      });
    } catch (error) { next(error); }
  },

  async update(req, res, next) {
    try {
      const { id } = req.params;
      const student = await Student.findOne({ where: { id, tenant_id: req.tenantId }, include: [{ model: User, as: 'user' }] });
      if (!student) return res.status(404).json({ success: false, message: 'Student not found' });
      const { first_name, middle_name, last_name, admission_number, roll_number, campus_id, date_of_birth, gender, address, city, state, country, postal_code, admission_date, class_id, section_id, parent_id, parent_name, parent_phone, parent_email, parent_address, emergency_contact, other_notes, transport_required, hostel_required, status } = req.body;
      if (admission_number && admission_number !== student.admission_number) {
        const dup = await Student.findOne({ where: { admission_number, tenant_id: req.tenantId, id: { [Op.ne]: id } } });
        if (dup) return res.status(400).json({ success: false, message: 'Admission number already exists' });
      }
      if (student.user) {
        const u = {};
        if (first_name) u.first_name = first_name;
        if (middle_name !== undefined) u.middle_name = middle_name || null;
        if (last_name) u.last_name = last_name;
        if (Object.keys(u).length > 0) await student.user.update(u);
      }
      const s = {};
      if (admission_number) s.admission_number = admission_number;
      if (roll_number !== undefined) s.roll_number = roll_number || null;
      if (campus_id) s.campus_id = campus_id;
      if (date_of_birth !== undefined) s.date_of_birth = date_of_birth || null;
      if (gender !== undefined) s.gender = gender || null;
      if (address !== undefined) s.address = address || null;
      if (city !== undefined) s.city = city || null;
      if (state !== undefined) s.state = state || null;
      if (country !== undefined) s.country = country || null;
      if (postal_code !== undefined) s.postal_code = postal_code || null;
      if (admission_date !== undefined) s.admission_date = admission_date || null;
      if (class_id !== undefined) s.class_id = class_id || null;
      if (section_id !== undefined) s.section_id = section_id || null;
      if (parent_id !== undefined) s.parent_id = parent_id || null;
      if (parent_name !== undefined) s.parent_name = parent_name || null;
      if (parent_phone !== undefined) s.parent_phone = normalizePhone(parent_phone) || null;
      if (parent_email !== undefined) s.parent_email = parent_email || null;
      if (parent_address !== undefined) s.parent_address = parent_address || null;
      if (emergency_contact !== undefined) s.emergency_contact = emergency_contact || null;
      if (other_notes !== undefined) s.other_notes = other_notes || null;
      if (transport_required !== undefined) s.transport_required = toBool(transport_required);
      if (hostel_required !== undefined) s.hostel_required = toBool(hostel_required);
      if (status) s.status = status;
      await student.update(s);

      // Keep the Messages contact in sync if guardian info changed too.
      const effectiveParentName = parent_name !== undefined ? parent_name : student.parent_name;
      const effectiveParentPhone = parent_phone !== undefined ? parent_phone : student.parent_phone;
      const effectiveParentEmail = parent_email !== undefined ? parent_email : student.parent_email;
      if (effectiveParentName && (effectiveParentPhone || effectiveParentEmail)) {
        await upsertParentContact({
          tenantId: req.tenantId, campusId: student.campus_id, name: effectiveParentName,
          phone: normalizePhone(effectiveParentPhone), email: effectiveParentEmail, userId: req.user.id,
          linkedUserId: parent_id !== undefined ? parent_id : student.parent_id,
        });
      }
      const updated = await Student.findByPk(id, {
        include: [{ model: User, as: 'user', attributes: { exclude: ['password'] } }, { model: Campus, as: 'campus' }, { model: Class, as: 'class' }, { model: Section, as: 'section' }],
      });
      res.json({ success: true, message: 'Student updated successfully', data: updated });
    } catch (error) { next(error); }
  },

  async delete(req, res, next) {
    try {
      const { id } = req.params;
      const student = await Student.findOne({ where: { id, tenant_id: req.tenantId } });
      if (!student) return res.status(404).json({ success: false, message: 'Student not found' });
      await student.update({ status: 'inactive' });
      res.json({ success: true, message: 'Student deactivated successfully' });
    } catch (error) { next(error); }
  },

  async permanentDelete(req, res, next) {
    try {
      const { id } = req.params;
      const student = await Student.findOne({ where: { id, tenant_id: req.tenantId } });
      if (!student) return res.status(404).json({ success: false, message: 'Student not found' });
      const userId = student.user_id;
      await student.destroy();
      const user = await User.findByPk(userId);
      if (user) await user.destroy();
      res.json({ success: true, message: 'Student permanently deleted' });
    } catch (error) { next(error); }
  },

  async reactivate(req, res, next) {
    try {
      const { id } = req.params;
      const student = await Student.findOne({ where: { id, tenant_id: req.tenantId } });
      if (!student) return res.status(404).json({ success: false, message: 'Student not found' });
      await student.update({ status: 'active' });
      res.json({ success: true, message: 'Student reactivated successfully', data: student });
    } catch (error) { next(error); }
  },

  async bulkUpdateStatus(req, res, next) {
    try {
      const { ids, status } = req.body;
      if (!ids || !Array.isArray(ids) || ids.length === 0) return res.status(400).json({ success: false, message: 'Please provide student IDs' });
      if (!['active', 'inactive'].includes(status)) return res.status(400).json({ success: false, message: 'Invalid status value' });
      await Student.update({ status }, { where: { id: { [Op.in]: ids }, tenant_id: req.tenantId } });
      res.json({ success: true, message: `${ids.length} student(s) updated successfully` });
    } catch (error) { next(error); }
  },

  /**
   * Bulk admission from the downloadable Excel template (frontend parses
   * the workbook and posts the rows as plain JSON — see
   * utils/studentBulkTemplate.js on the frontend). Each row is created
   * independently (one row failing — a duplicate admission number, an
   * unrecognised class name, etc — never blocks the rows around it), and
   * every row goes through exactly the same rules a single admission
   * would: same required fields, same generated login credentials, same
   * parent-contact upsert, same notifications. This is the only thing
   * that's allowed to differ from a single admission: names (Campus,
   * Class, Section) are resolved to IDs here from the tenant's own
   * records instead of coming in already as IDs, since that's what a
   * human can actually type into a spreadsheet.
   */
  async bulkCreate(req, res, next) {
    try {
      const { students, academic_year } = req.body;
      if (!Array.isArray(students) || students.length === 0) {
        return res.status(400).json({ success: false, message: 'No student rows were provided' });
      }
      const MAX_ROWS = IMPORT_MAX_ROWS;
      if (students.length > MAX_ROWS) {
        return res.status(400).json({ success: false, message: `A single upload is limited to ${MAX_ROWS} students. Please split the file into smaller batches.` });
      }

      const tenant = await Tenant.findByPk(req.tenantId);

      // Safety net: a fresh, tested backup of the whole database before rows are written
      // (the page sends the file in chunks; a backup made minutes ago is reused for the rest).
      try { await ensureBackupBeforeRiskyAction({ reason: 'importing students from Excel', userId: req.user?.id }); } catch (backupError) { return next(backupError); }

      // Same plan-limit check checkStudentLimit does for a single admission, but evaluated once for the whole
      // batch so a school on a limited plan gets a clear, row-by-row picture of exactly which admissions fit.
      const { remaining: remainingSlots } = await studentSlotsLeft(req);

      // The same checks the preview ran (see buildStudentRowValidator above).
      const validateRow = buildStudentRowValidator({ tenantId: req.tenantId, academicYear: academic_year });

      const results = [];
      const parentNotices = [];
      let created = 0;

      for (let i = 0; i < students.length; i += 1) {
        const row = students[i] || {};
        const rowNum = Number(row.__row) || i + 2; // the real Excel row when the page sent it (row 1 is the header)
        const rowLabel = `${row.first_name || ''} ${row.last_name || ''}`.trim() || `Row ${rowNum}`;
        try {
          const checked = await validateRow(row);
          const { errors, campus, matchedClass, matchedSection } = checked;
          const { first_name, last_name, middle_name, admission_number, gender, date_of_birth, admission_date, parent_name, parent_phone, parent_email } = checked.fields;

          if (errors.length > 0) {
            results.push({ row: rowNum, name: rowLabel, admission_number: admission_number || null, status: 'failed', message: errors.join('; ') });
            continue;
          }

          if (created >= remainingSlots) {
            results.push({ row: rowNum, name: rowLabel, admission_number, status: 'failed', message: 'Skipped — your subscription plan\'s student limit has been reached' });
            continue;
          }

          const email = generateStudentEmail({ admissionNumber: admission_number, tenantSlug: tenant?.slug });
          const password = DEFAULT_STUDENT_PASSWORD;
          const user = await User.create({ tenant_id: req.tenantId, email, password, first_name, middle_name: middle_name || null, last_name, role: 'student', status: 'active', must_change_password: true });
          await Student.create({
            tenant_id: req.tenantId, user_id: user.id, campus_id: campus.id, admission_number,
            roll_number: row.roll_number ? String(row.roll_number).trim() : null,
            date_of_birth, gender,
            address: row.address || null, city: row.city || null, state: row.state || null,
            country: row.country || null, postal_code: row.postal_code || null, admission_date,
            class_id: matchedClass?.id || null, section_id: matchedSection?.id || null, parent_id: null,
            parent_name: parent_name || null, parent_phone: parent_phone ? normalizePhone(parent_phone) : null,
            parent_email: parent_email || null, parent_address: row.parent_address || null,
            emergency_contact: row.emergency_contact || null, other_notes: row.other_notes || null,
            transport_required: toBool(row.transport_required), hostel_required: toBool(row.hostel_required),
            status: 'active',
          });

          if (parent_name && (parent_phone || parent_email)) {
            await upsertParentContact({
              tenantId: req.tenantId, campusId: campus.id, name: parent_name,
              phone: parent_phone ? normalizePhone(parent_phone) : null, email: parent_email || null, userId: req.user.id,
            });
          }

          await notifyEvent(req.tenantId, 'student_admitted', {
            parties: { admins: { title: 'New Student Admitted', message: `${first_name} ${last_name} has been admitted (${admission_number}) via bulk upload.` } },
          });

          created += 1;
          const resultRow = { row: rowNum, name: `${first_name} ${last_name}`, admission_number, status: 'created', message: 'Admitted successfully', parent_notification: 'skipped' };
          results.push(resultRow);

          // The parent messages are sent AFTER every row is saved (below),
          // a few at a time. Sending each one here would make the whole
          // upload wait on the SMS gateway row after row.
          if (parent_phone || parent_email) {
            parentNotices.push({
              resultRow,
              payload: {
                title: 'Admission Imekamilika',
                message: `Habari ${parent_name || 'Mzazi'}, admission ya ${first_name} ${last_name} imekamilika. Namba ya admission: ${admission_number}${matchedClass ? `, Darasa: ${matchedClass.name}` : ''}.`,
                smsPhone: parent_phone ? normalizePhone(parent_phone) : null,
                emailTo: parent_email || null,
                emailSubject: `Admission Imekamilika - ${first_name} ${last_name} (${admission_number})`,
              },
            });
          }
        } catch (rowError) {
          const message = rowError.name === 'SequelizeUniqueConstraintError'
            ? 'A login for this admission number already exists (an older record may still be using it) — use a different admission number'
            : (rowError.message || 'Unexpected error creating this student');
          results.push({ row: rowNum, name: rowLabel, admission_number: row.admission_number || null, status: 'failed', message });
        }
      }

      // Parent notices, 5 at a time. Each row ends up tagged with what
      // happened to its notice: 'sent', 'simulated' (no real SMS gateway is
      // active, so it was only logged), 'failed', or 'skipped' (no phone or
      // email, or the event is switched off in Settings → Notifications).
      const NOTICE_BATCH = 5;
      for (let i = 0; i < parentNotices.length; i += NOTICE_BATCH) {
        await Promise.all(parentNotices.slice(i, i + NOTICE_BATCH).map(async ({ resultRow, payload }) => {
          const outcome = await notifyEvent(req.tenantId, 'student_admitted', { parties: { family: payload } });
          const party = outcome.parties.family || {};
          const channels = [party.sms, party.email, party.in_app];
          resultRow.parent_notification = (!outcome.enabled || party.skipped) ? 'skipped'
            : channels.includes('failed') ? 'failed'
            : channels.includes('sent') ? 'sent'
            : channels.includes('simulated') ? 'simulated'
            : 'skipped';
        }));
      }
      const noticeCounts = results
        .filter((r) => r.status === 'created')
        .reduce((acc, r) => { acc[r.parent_notification] = (acc[r.parent_notification] || 0) + 1; return acc; }, {});

      res.status(created > 0 ? 201 : 200).json({
        success: true,
        message: `${created} of ${students.length} student(s) admitted successfully`,
        data: {
          summary: { total: students.length, created, failed: students.length - created, parent_notifications: noticeCounts },
          results,
        },
      });
    } catch (error) { next(error); }
  },

  /**
   * Import PREVIEW — checks every row of the spreadsheet without saving anything, using exactly the same rules
   * as bulkCreate (buildStudentRowValidator), and reports:
   *   ready                the row will be admitted
   *   error                the row cannot be admitted (reasons listed) — includes duplicate admission numbers,
   *                        whether already in the school or repeated inside the file
   *   possible_duplicate   nothing is wrong, but the same name and date of birth already exist (or repeat in
   *                        the file) — the page leaves these unticked for a person to decide
   * Also tells how many students the subscription plan still has room for.
   */
  async bulkPreview(req, res, next) {
    try {
      const { students, academic_year } = req.body;
      if (!Array.isArray(students) || students.length === 0) {
        return res.status(400).json({ success: false, message: 'No student rows were provided' });
      }
      if (students.length > IMPORT_MAX_ROWS) {
        return res.status(400).json({ success: false, message: `A single upload is limited to ${IMPORT_MAX_ROWS} students. Please split the file into smaller batches.` });
      }

      const validateRow = buildStudentRowValidator({ tenantId: req.tenantId, academicYear: academic_year });
      const { remaining, limit } = await studentSlotsLeft(req);

      // Everyone already in the school who shares a date of birth with a row in this file (one query, not one per row).
      const dobs = [...new Set(students.map((r) => String(r?.date_of_birth || '').trim()).filter(isRealDate))];
      const peers = dobs.length === 0 ? [] : await Student.findAll({
        where: { tenant_id: req.tenantId, date_of_birth: { [Op.in]: dobs.map((d) => d.slice(0, 10)) } },
        attributes: ['id', 'admission_number', 'date_of_birth'],
        include: [{ model: User, as: 'user', attributes: ['first_name', 'last_name'] }],
      });
      const personKey = (first, last, dob) => `${String(first).trim().toLowerCase()}|${String(last).trim().toLowerCase()}|${String(dob).slice(0, 10)}`;
      const inSchool = new Map(peers.filter((p) => p.user).map((p) => [personKey(p.user.first_name, p.user.last_name, p.date_of_birth), p.admission_number]));

      const firstAdmission = new Map(); // admission number → first row that uses it
      const firstPerson = new Map();    // name + date of birth → first row
      const rows = [];
      let readyCount = 0;

      for (let i = 0; i < students.length; i += 1) {
        const row = students[i] || {};
        const rowNum = Number(row.__row) || i + 2;
        const v = await validateRow(row);
        const errors = [...v.errors];
        const warnings = [...v.warnings];
        let duplicate = null;
        let possible = false;

        if (v.existingAdmission) duplicate = { kind: 'existing', detail: `Already in the school as ${v.fields.admission_number}` };
        const admKey = v.fields.admission_number.toLowerCase();
        if (admKey) {
          if (firstAdmission.has(admKey)) {
            errors.push(`Admission number "${v.fields.admission_number}" is repeated in this file — first used on row ${firstAdmission.get(admKey)}`);
            duplicate = duplicate || { kind: 'in_file', detail: `Same admission number as row ${firstAdmission.get(admKey)}`, of_row: firstAdmission.get(admKey) };
          } else firstAdmission.set(admKey, rowNum);
        }

        if (v.fields.first_name && v.fields.last_name && isRealDate(v.fields.date_of_birth)) {
          const key = personKey(v.fields.first_name, v.fields.last_name, v.fields.date_of_birth);
          if (inSchool.has(key)) {
            possible = true;
            warnings.push(`Possible duplicate: a student with this name and date of birth is already in the school (${inSchool.get(key)})`);
            duplicate = duplicate || { kind: 'possible_existing', detail: `Same name and date of birth as ${inSchool.get(key)}` };
          } else if (firstPerson.has(key)) {
            possible = true;
            warnings.push(`Possible duplicate: same name and date of birth as row ${firstPerson.get(key)} in this file`);
            duplicate = duplicate || { kind: 'possible_in_file', detail: `Same name and date of birth as row ${firstPerson.get(key)}`, of_row: firstPerson.get(key) };
          } else firstPerson.set(key, rowNum);
        }

        let status = errors.length > 0 ? 'error' : possible ? 'possible_duplicate' : 'ready';
        let overLimit = false;
        if (status === 'ready') {
          readyCount += 1;
          if (readyCount > remaining) { status = 'error'; overLimit = true; errors.push("Beyond your subscription plan's student limit — upgrade the plan or import fewer students"); }
        }

        rows.push({
          row: rowNum,
          name: `${v.fields.first_name} ${v.fields.last_name}`.trim() || `Row ${rowNum}`,
          admission_number: v.fields.admission_number || null,
          campus_name: v.campus?.name || (row.campus_name ? String(row.campus_name).trim() : null),
          class_name: v.matchedClass?.name || null,
          status, errors, warnings, duplicate, over_limit: overLimit,
        });
      }

      const count = (fn) => rows.filter(fn).length;
      res.json({
        success: true,
        data: {
          summary: {
            total: rows.length,
            ready: count((r) => r.status === 'ready'),
            errors: count((r) => r.status === 'error'),
            possible_duplicates: count((r) => r.status === 'possible_duplicate'),
            blocked_duplicates: count((r) => r.status === 'error' && r.duplicate && ['existing', 'in_file'].includes(r.duplicate.kind)),
            over_limit: count((r) => r.over_limit),
            with_warnings: count((r) => r.status !== 'error' && r.warnings.length > 0),
            plan_limit: limit,
            slots_left: Number.isFinite(remaining) ? remaining : null,
          },
          rows,
        },
      });
    } catch (error) { next(error); }
  },

  async getStats(req, res, next) {
    try {
      const { id } = req.params;
      const student = await Student.findOne({
        where: { id, tenant_id: req.tenantId },
        include: [{ model: Class, as: 'class', attributes: ['academic_year'] }],
      });
      if (!student) return res.status(404).json({ success: false, message: 'Student not found' });
      if (!(await can(req.user, req.tenantId, 'students.view')) && !isOwnStudentRecord(req.user, student)) {
        return res.status(403).json({ success: false, message: 'You can only view your own record' });
      }

      // Everything below is scoped to ONE academic year — whichever the
      // caller asked for (the globally selected year), falling back to
      // the student's own current class's year. Attendance and payments
      // don't carry an academic_year column of their own, so they're
      // scoped by real calendar date instead (see academicYearDateRange);
      // exams ARE scoped through the Exam they belong to, using the same
      // base-year matching as everywhere else in the app.
      const academicYear = req.query.academic_year || student.class?.academic_year || null;
      const dateRange = academicYear ? academicYearDateRange(academicYear) : null;

      const attendanceWhere = { student_id: id, tenant_id: req.tenantId };
      if (dateRange) attendanceWhere.date = { [Op.between]: [dateRange.start, dateRange.end] };
      const attendanceRecords = await Attendance.findAll({
        where: attendanceWhere,
        attributes: ['status'],
      });

      const total = attendanceRecords.length;
      const present = attendanceRecords.filter(r => r.status === 'present').length;
      const absent = attendanceRecords.filter(r => r.status === 'absent').length;
      const late = attendanceRecords.filter(r => r.status === 'late').length;
      const excused = attendanceRecords.filter(r => r.status === 'excused').length;
      const half_day = attendanceRecords.filter(r => r.status === 'half_day').length;
      const percentage = total > 0 ? Math.round((present / total) * 100) : 0;

      // Exams: one grade per exam per subject, so group by exam_id to
      // compute a per-exam average/pass-fail, the same way the report
      // card does — "passed" means that exam's overall grade isn't an F.
      // Joined through Exam and filtered to the requested year, so this
      // reflects that year's results only — e.g. a student now in Form
      // III but viewed for last year shows last year's Form II results,
      // not their whole academic history mixed together.
      const gradeWhere = { tenant_id: req.tenantId, student_id: id, marks_obtained: { [Op.ne]: null } };
      const examInclude = { model: Exam, as: 'exam', attributes: [] };
      // Scoped to the exam's OWN table (this is a nested include, not the
      // top-level where), so the plain column name is correct here — no
      // "Model.column" qualification needed, unlike a join at the main
      // query level (see utils/academicYear.js).
      if (academicYear) examInclude.where = applyAcademicYearFilter({}, academicYear);
      const grades = await Grade.findAll({
        where: gradeWhere,
        include: [examInclude],
        attributes: ['exam_id', 'marks_obtained', 'max_marks'],
      });
      const byExam = {};
      grades.forEach((g) => {
        if (!byExam[g.exam_id]) byExam[g.exam_id] = { obtained: 0, max: 0 };
        byExam[g.exam_id].obtained += Number(g.marks_obtained);
        byExam[g.exam_id].max += Number(g.max_marks);
      });
      const examAverages = Object.values(byExam)
        .filter((e) => e.max > 0)
        .map((e) => (e.obtained / e.max) * 100);
      const examsTotal = examAverages.length;
      const examsPassed = examAverages.filter((avg) => computeGrade(avg) !== 'F').length;
      const examsFailed = examsTotal - examsPassed;
      const examsAverage = examsTotal > 0
        ? Math.round((examAverages.reduce((a, b) => a + b, 0) / examsTotal) * 10) / 10
        : 0;

      // Fees: reuse the exact same billing_cycles/applies_to-aware
      // calculation used everywhere else in the Fees feature, so this
      // card always agrees with the Fee Status / Student Fee Summary
      // pages. Payments are scoped to the same real calendar window as
      // attendance above — a payment made in a different year (even for
      // an old balance) isn't counted against THIS year's expected fees.
      let feesExpected = 0, feesPaid = 0;
      if (academicYear) {
        // The student's class AS OF this specific year, not their
        // current one — otherwise a past year's expected fees would be
        // calculated against whatever class they're in TODAY (see
        // utils/classRoster.js resolveStudentClassForYear).
        const targetBaseYear = extractBaseYear(academicYear);
        const classForYear = await resolveStudentClassForYear({ tenantId: req.tenantId, student, targetBaseYear });
        const studentForFees = classForYear ? { ...student.toJSON(), class_id: classForYear.id } : student;
        const { total: expected } = await expectedForStudent(req.tenantId, studentForFees, academicYear);
        const paymentWhere = { tenant_id: req.tenantId, student_id: id, status: 'completed' };
        if (dateRange) paymentWhere.payment_date = { [Op.between]: [dateRange.start, dateRange.end] };
        const payments = await Payment.findAll({ where: paymentWhere });
        feesExpected = expected;
        feesPaid = payments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
      }
      const feesPending = Math.round((feesExpected - feesPaid) * 100) / 100;
      const feesPaidPct = feesExpected > 0 ? Math.round((feesPaid / feesExpected) * 100) : 0;

      res.json({
        success: true,
        data: {
          academic_year: academicYear,
          attendance: { total, present, absent, late, excused, half_day, percentage },
          exams: { total: examsTotal, passed: examsPassed, failed: examsFailed, average: examsAverage },
          fees: { total: feesExpected, paid: Math.round(feesPaid * 100) / 100, pending: feesPending, paid_percentage: feesPaidPct },
        },
      });
    } catch (error) { next(error); }
  },
};