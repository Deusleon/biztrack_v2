import { Staff, User, Campus } from '../models/index.js';
import sequelize from '../config/database.js';
import { buildStaffRowValidator, STAFF_IMPORT_MAX_ROWS } from '../utils/staffImport.js';
import { ensureBackupBeforeRiskyAction } from '../services/backup/backupService.js';
import { notifyEvent } from '../services/notificationService.js';
import { Op } from 'sequelize';
import { normalizePhone } from '../utils/phone.js';
import { DEFAULT_STAFF_PASSWORD } from '../utils/studentCredentials.js';
import { roleAssignmentError } from '../utils/staffRoles.js';
import { publicUrlFor } from '../middleware/upload.js';
import { can } from '../utils/permissionEngine.js';

// Staff records carry salaries, national ID, tax/pension numbers and bank
// details. Everyone who works at the school can look a colleague up (timetable,
// leave and library pick-lists need names and contacts), but these columns are
// only returned to people who manage staff, and to the person themself.
const SENSITIVE_STAFF_FIELDS = [
  'salary', 'national_id', 'tin_number', 'nssf_number', 'bank_name', 'bank_account_number',
  'emergency_contact', 'emergency_contact_name', 'emergency_contact_relation',
  'marital_status', 'blood_group', 'date_of_birth', 'address', 'city', 'country',
  'notes', 'contract_end_date', 'documents',
];
const DIRECTORY_USER_FIELDS = ['id', 'first_name', 'middle_name', 'last_name', 'email', 'phone', 'role', 'avatar', 'status'];

export const presentStaff = (staff, viewer, canSeeSensitive) => {
  const json = typeof staff.toJSON === 'function' ? staff.toJSON() : { ...staff };
  if (canSeeSensitive || json.user_id === viewer.id) return json;
  SENSITIVE_STAFF_FIELDS.forEach((field) => { delete json[field]; });
  if (json.user) {
    json.user = Object.fromEntries(DIRECTORY_USER_FIELDS.filter((f) => f in json.user).map((f) => [f, json.user[f]]));
  }
  return json;
};

export const staffController = {
  // Get all staff with filters and pagination
  async getAll(req, res, next) {
    try {
      const {
        page = 1,
        limit = 10,
        search = '',
        status = '',
        campus_id = '',
        department = '',
        contract_type = '',
        role = '',
        sortBy = 'name',
        sortOrder = 'ASC',
      } = req.query;

      const offset = (page - 1) * limit;
      const where = { tenant_id: req.tenantId };

      if (status) where.status = status;
      if (campus_id) where.campus_id = campus_id;
      if (department) where.department = { [Op.iLike]: `%${department}%` };
      if (contract_type) where.contract_type = contract_type;

      const userInclude = {
        model: User,
        as: 'user',
        attributes: { exclude: ['password'] },
        required: role ? true : false,
      };

      // Filter by user role (e.g. role=teacher for teacher-only dropdowns)
      if (role) {
        userInclude.where = { ...(userInclude.where || {}), role };
      }

      if (search) {
        where[Op.or] = [{ employee_number: { [Op.iLike]: `%${search}%` } }];
        userInclude.required = true;
        userInclude.where = {
          ...(userInclude.where || {}),
          [Op.or]: [
            { first_name: { [Op.iLike]: `%${search}%` } },
            { last_name: { [Op.iLike]: `%${search}%` } },
            { email: { [Op.iLike]: `%${search}%` } },
            { phone: { [Op.iLike]: `%${search}%` } },
          ],
        };
      }

      // "name" sorts alphabetically by the linked user's first/last name
      // (the default). Any other column name sorts directly.
      const order = sortBy === 'name'
        ? [[{ model: User, as: 'user' }, 'first_name', sortOrder], [{ model: User, as: 'user' }, 'last_name', sortOrder]]
        : [[sortBy, sortOrder]];

      const sensitive = await can(req.user, req.tenantId, 'staff.view_sensitive');
      const { count, rows: staff } = await Staff.findAndCountAll({
        where,
        include: [
          userInclude,
          { model: Campus, as: 'campus', attributes: ['id', 'name', 'code'] },
        ],
        limit: parseInt(limit),
        offset: parseInt(offset),
        order,
        distinct: true,
      });

      res.json({
        success: true,
        data: staff.map((s) => presentStaff(s, req.user, sensitive)),
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(count / limit),
          totalItems: count,
          itemsPerPage: parseInt(limit),
        },
      });
    } catch (error) {
      next(error);
    }
  },

  // Get single staff by ID
  async getById(req, res, next) {
    try {
      const { id } = req.params;

      const staff = await Staff.findOne({
        where: { id, tenant_id: req.tenantId },
        include: [
          { model: User, as: 'user', attributes: { exclude: ['password'] } },
          { model: Campus, as: 'campus' },
        ],
      });

      if (!staff) {
        return res.status(404).json({ success: false, message: 'Staff member not found' });
      }

      res.json({ success: true, data: presentStaff(staff, req.user, await can(req.user, req.tenantId, 'staff.view_sensitive')) });
    } catch (error) {
      next(error);
    }
  },

  // Create new staff member
  async create(req, res, next) {
    try {
      const {
        email, first_name, middle_name, last_name, phone,
        role, employee_number, campus_id,
        department, designation, joining_date, contract_type,
        salary, experience_years, qualifications, teaching_subjects,
        reports_to_id,
        emergency_contact, emergency_contact_name, emergency_contact_relation,
        address, city, country,
        date_of_birth, gender, marital_status, blood_group, national_id,
        tin_number, nssf_number, bank_name, bank_account_number,
        contract_end_date, notes,
        status = 'active',
      } = req.body;

      // The role decides what this person can do in the system, so it is
      // checked first — who may hand it out, and that it is a real staff role.
      const roleError = roleAssignmentError({ actor: req.user, newRole: role, canManageStaff: await can(req.user, req.tenantId, 'staff.update') });
      if (roleError) return res.status(roleError.status).json({ success: false, message: roleError.message });

      // Check employee number uniqueness
      const existing = await Staff.findOne({
        where: { employee_number, tenant_id: req.tenantId },
      });
      if (existing) {
        return res.status(400).json({ success: false, message: 'Employee number already exists' });
      }

      // Validate campus
      const campus = await Campus.findOne({ where: { id: campus_id, tenant_id: req.tenantId } });
      if (!campus) {
        return res.status(400).json({ success: false, message: 'Invalid campus ID' });
      }

      if (!email) {
        return res.status(400).json({ success: false, message: 'Email is required — it is the staff member\'s login.' });
      }
      const emailTaken = await User.findOne({ where: { email: email.toLowerCase().trim() } });
      if (emailTaken) {
        return res.status(400).json({ success: false, message: 'That email is already registered.' });
      }
      const phoneTaken = await User.findOne({ where: { phone: normalizePhone(phone) } });
      if (phoneTaken) {
        return res.status(400).json({ success: false, message: 'That phone number is already registered.' });
      }

      // Staff log in with the email entered here and a shared default
      // password, which they must change on first login. Nobody adding a
      // staff member gets to choose — and therefore know — their password.
      const user = await User.create({
        tenant_id: req.tenantId,
        email: email.toLowerCase().trim(),
        password: DEFAULT_STAFF_PASSWORD,
        first_name, middle_name: middle_name || null, last_name,
        phone: normalizePhone(phone) || null,
        role, status: 'active',
        must_change_password: true,
      });

      // Create staff profile
      const staff = await Staff.create({
        tenant_id: req.tenantId, user_id: user.id, campus_id, employee_number,
        department: department || null, designation: designation || null,
        joining_date: joining_date || null, contract_type,
        salary: salary || null, experience_years: experience_years || 0,
        qualifications: qualifications || [],
        teaching_subjects: teaching_subjects || [],
        reports_to_id: reports_to_id || null,
        emergency_contact: emergency_contact || null,
        emergency_contact_name: emergency_contact_name || null,
        emergency_contact_relation: emergency_contact_relation || null,
        address: address || null, city: city || null, country: country || null,
        date_of_birth: date_of_birth || null, gender: gender || null,
        marital_status: marital_status || null, blood_group: blood_group || null,
        national_id: national_id || null,
        tin_number: tin_number || null, nssf_number: nssf_number || null,
        bank_name: bank_name || null, bank_account_number: bank_account_number || null,
        contract_end_date: contract_end_date || null, notes: notes || null,
        documents: [],
        status,
      });

      const created = await Staff.findByPk(staff.id, {
        include: [
          { model: User, as: 'user', attributes: { exclude: ['password'] } },
          { model: Campus, as: 'campus' },
        ],
      });

      const staffNotice = { title: 'New Staff Member Added', message: `${first_name} ${last_name} has been added as ${designation || role}.` };
      await notifyEvent(req.tenantId, 'staff_added', { parties: { admins: staffNotice, hr: staffNotice } });

      res.status(201).json({
        success: true,
        message: `Staff member created. They can log in with ${user.email} and the default staff password, which they'll be asked to change.`,
        data: created,
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Import PREVIEW (staff) — checks every spreadsheet row without saving anything, with exactly the rules the
   * import itself uses (utils/staffImport.js). Rows are `ready`, `error` (reasons listed — duplicates of an
   * existing employee number / email / phone, or repeated inside the file, are errors), or
   * `possible_duplicate` (same national ID, or same name and date of birth, already exists or repeats in the file).
   */
  async bulkPreview(req, res, next) {
    try {
      const { staff } = req.body;
      if (!Array.isArray(staff) || staff.length === 0) return res.status(400).json({ success: false, message: 'No staff rows were provided' });
      if (staff.length > STAFF_IMPORT_MAX_ROWS) return res.status(400).json({ success: false, message: `A single upload is limited to ${STAFF_IMPORT_MAX_ROWS} staff. Please split the file into smaller batches.` });

      const validateRow = buildStaffRowValidator({ tenantId: req.tenantId, actor: req.user, canManageStaff: await can(req.user, req.tenantId, 'staff.update') });

      // People already on the staff list who could be the same person (one query).
      const existing = await Staff.findAll({
        where: { tenant_id: req.tenantId },
        attributes: ['employee_number', 'national_id', 'date_of_birth'],
        include: [{ model: User, as: 'user', attributes: ['first_name', 'last_name'] }],
      });
      const nid = (v) => String(v || '').replace(/[\s-]/g, '').toLowerCase();
      const pk = (a, b, d) => `${String(a).trim().toLowerCase()}|${String(b).trim().toLowerCase()}|${String(d).slice(0, 10)}`;
      const byNationalId = new Map(existing.filter((e) => nid(e.national_id)).map((e) => [nid(e.national_id), e.employee_number]));
      const byPerson = new Map(existing.filter((e) => e.user && e.date_of_birth).map((e) => [pk(e.user.first_name, e.user.last_name, e.date_of_birth), e.employee_number]));

      const seen = { employee_number: new Map(), email: new Map(), phone: new Map(), person: new Map(), national_id: new Map() };
      const rows = [];
      for (let i = 0; i < staff.length; i += 1) {
        const row = staff[i] || {};
        const rowNum = Number(row.__row) || i + 2;
        const v = await validateRow(row);
        const errors = [...v.errors];
        const warnings = [...v.warnings];
        let duplicate = null;
        let possible = false;
        const f = v.fields;

        if (v.dup.employee_number) duplicate = { kind: 'existing', detail: `Employee number ${f.employee_number} already exists` };
        else if (v.dup.email) duplicate = { kind: 'existing', detail: `Email ${f.email} is already registered` };
        else if (v.dup.phone) duplicate = { kind: 'existing', detail: `Phone ${f.phone} is already registered` };

        const repeat = (map, key, label, shown) => {
          if (!key) return;
          if (map.has(key)) {
            errors.push(`${label} "${shown}" is repeated in this file — first used on row ${map.get(key)}`);
            duplicate = duplicate || { kind: 'in_file', detail: `Same ${label.toLowerCase()} as row ${map.get(key)}`, of_row: map.get(key) };
          } else map.set(key, rowNum);
        };
        repeat(seen.employee_number, f.employee_number.toLowerCase(), 'Employee number', f.employee_number);
        repeat(seen.email, f.email, 'Email', f.email);
        repeat(seen.phone, f.phone_normalized, 'Phone', f.phone);

        const nKey = nid(f.national_id);
        if (nKey) {
          if (byNationalId.has(nKey)) { possible = true; warnings.push(`Possible duplicate: this national ID is already on the staff list (${byNationalId.get(nKey)})`); duplicate = duplicate || { kind: 'possible_existing', detail: `Same national ID as ${byNationalId.get(nKey)}` }; }
          else if (seen.national_id.has(nKey)) { possible = true; warnings.push(`Possible duplicate: same national ID as row ${seen.national_id.get(nKey)} in this file`); duplicate = duplicate || { kind: 'possible_in_file', detail: `Same national ID as row ${seen.national_id.get(nKey)}`, of_row: seen.national_id.get(nKey) }; }
          else seen.national_id.set(nKey, rowNum);
        }
        if (f.first_name && f.last_name && f.date_of_birth) {
          const key = pk(f.first_name, f.last_name, f.date_of_birth);
          if (byPerson.has(key)) { possible = true; warnings.push(`Possible duplicate: same name and date of birth as ${byPerson.get(key)}`); duplicate = duplicate || { kind: 'possible_existing', detail: `Same name and date of birth as ${byPerson.get(key)}` }; }
          else if (seen.person.has(key)) { possible = true; warnings.push(`Possible duplicate: same name and date of birth as row ${seen.person.get(key)} in this file`); duplicate = duplicate || { kind: 'possible_in_file', detail: `Same name and date of birth as row ${seen.person.get(key)}`, of_row: seen.person.get(key) }; }
          else seen.person.set(key, rowNum);
        }

        rows.push({
          row: rowNum,
          name: `${f.first_name} ${f.last_name}`.trim() || `Row ${rowNum}`,
          employee_number: f.employee_number || null,
          email: f.email || null,
          role: f.role || null,
          campus_name: v.campus?.name || (row.campus_name ? String(row.campus_name).trim() : null),
          status: errors.length > 0 ? 'error' : possible ? 'possible_duplicate' : 'ready',
          errors, warnings, duplicate,
        });
      }

      const count = (fn) => rows.filter(fn).length;
      res.json({
        success: true,
        data: {
          summary: {
            total: rows.length,
            ready: count((r) => r.status === 'ready'),
            errors: count((r) => r.status === 'error'),
            possible_duplicates: count((r) => r.status === 'possible_duplicate'),
            blocked_duplicates: count((r) => r.status === 'error' && r.duplicate && ['existing', 'in_file'].includes(r.duplicate.kind)),
            with_warnings: count((r) => r.status !== 'error' && r.warnings.length > 0),
          },
          rows,
        },
      });
    } catch (error) { next(error); }
  },

  /**
   * Staff import. Every row goes through the same checks as the preview and is saved on its own, inside its
   * own transaction (so a row can never leave a login without a staff record). A row with a mistake is reported
   * and the rest still go through. New people sign in with their email and the shared default staff password,
   * and must choose their own at first sign-in — exactly as when added one by one.
   */
  async bulkCreate(req, res, next) {
    try {
      const { staff } = req.body;
      if (!Array.isArray(staff) || staff.length === 0) return res.status(400).json({ success: false, message: 'No staff rows were provided' });
      if (staff.length > STAFF_IMPORT_MAX_ROWS) return res.status(400).json({ success: false, message: `A single upload is limited to ${STAFF_IMPORT_MAX_ROWS} staff. Please split the file into smaller batches.` });

      try { await ensureBackupBeforeRiskyAction({ reason: 'importing staff from Excel', userId: req.user?.id }); } catch (backupError) { return next(backupError); }

      const validateRow = buildStaffRowValidator({ tenantId: req.tenantId, actor: req.user, canManageStaff: await can(req.user, req.tenantId, 'staff.update') });
      const results = [];
      let created = 0;

      for (let i = 0; i < staff.length; i += 1) {
        const row = staff[i] || {};
        const rowNum = Number(row.__row) || i + 2;
        const label = `${row.first_name || ''} ${row.last_name || ''}`.trim() || `Row ${rowNum}`;
        try {
          const v = await validateRow(row);
          if (v.errors.length > 0) {
            results.push({ row: rowNum, name: label, employee_number: v.fields.employee_number || null, email: v.fields.email || null, status: 'failed', message: v.errors.join('; ') });
            continue;
          }
          const f = v.fields;
          await sequelize.transaction(async (transaction) => {
            const user = await User.create({
              tenant_id: req.tenantId, email: f.email, password: DEFAULT_STAFF_PASSWORD,
              first_name: f.first_name, middle_name: f.middle_name || null, last_name: f.last_name,
              phone: f.phone_normalized || null, role: f.role, status: 'active', must_change_password: true,
            }, { transaction });
            await Staff.create({
              tenant_id: req.tenantId, user_id: user.id, campus_id: v.campus.id, employee_number: f.employee_number,
              department: f.department || null, designation: f.designation || null,
              joining_date: f.joining_date || null, contract_type: f.contract_type, salary: f.salary,
              experience_years: f.experience_years, qualifications: [], teaching_subjects: [], reports_to_id: null,
              emergency_contact: f.emergency_contact || null, emergency_contact_name: f.emergency_contact_name || null,
              emergency_contact_relation: f.emergency_contact_relation || null,
              address: f.address || null, city: f.city || null, country: f.country || null,
              date_of_birth: f.date_of_birth || null, gender: f.gender, marital_status: f.marital_status,
              national_id: f.national_id || null, tin_number: f.tin_number || null, nssf_number: f.nssf_number || null,
              bank_name: f.bank_name || null, bank_account_number: f.bank_account_number || null,
              contract_end_date: f.contract_end_date || null, notes: f.notes || null, documents: [], status: 'active',
            }, { transaction });
          });
          created += 1;
          results.push({ row: rowNum, name: `${f.first_name} ${f.last_name}`, employee_number: f.employee_number, email: f.email, status: 'created', message: 'Added successfully' });
        } catch (rowError) {
          results.push({ row: rowNum, name: label, employee_number: row.employee_number || null, email: row.email || null, status: 'failed', message: rowError.message || 'Unexpected error adding this person' });
        }
      }

      if (created > 0) {
        const importNotice = { title: 'Staff Added', message: `${created} staff member(s) were added from an Excel upload.` };
        await notifyEvent(req.tenantId, 'staff_added', { parties: { admins: importNotice, hr: importNotice } });
      }
      res.status(created > 0 ? 201 : 200).json({
        success: true,
        message: `${created} of ${staff.length} staff member(s) added successfully`,
        data: { summary: { total: staff.length, created, failed: staff.length - created }, results },
      });
    } catch (error) { next(error); }
  },

  // Update staff member
  async update(req, res, next) {
    try {
      const { id } = req.params;

      const staff = await Staff.findOne({
        where: { id, tenant_id: req.tenantId },
        include: [{ model: User, as: 'user' }],
      });

      if (!staff) {
        return res.status(404).json({ success: false, message: 'Staff member not found' });
      }

      const {
        first_name, middle_name, last_name, phone, email, role, employee_number, campus_id,
        department, designation, joining_date, contract_type,
        salary, experience_years, qualifications, teaching_subjects, reports_to_id,
        emergency_contact, emergency_contact_name, emergency_contact_relation,
        address, city, country,
        date_of_birth, gender, marital_status, blood_group, national_id,
        tin_number, nssf_number, bank_name, bank_account_number,
        contract_end_date, notes, status,
      } = req.body;

      // The form always sends the role, and until now this handler ignored it —
      // so changing someone's role appeared to save but never did. It is applied
      // only when it really differs, and only if the person making the change is
      // allowed to (checked before anything is written).
      const roleChanging = role !== undefined && staff.user && role !== staff.user.role;
      if (roleChanging) {
        const roleError = roleAssignmentError({ actor: req.user, currentRole: staff.user.role, newRole: role, targetUserId: staff.user.id, canManageStaff: await can(req.user, req.tenantId, 'staff.update') });
        if (roleError) return res.status(roleError.status).json({ success: false, message: roleError.message });
      }

      // Check employee number uniqueness if changed
      if (employee_number && employee_number !== staff.employee_number) {
        const dup = await Staff.findOne({
          where: { employee_number, tenant_id: req.tenantId, id: { [Op.ne]: id } },
        });
        if (dup) {
          return res.status(400).json({ success: false, message: 'Employee number already exists' });
        }
      }

      // Update user account
      if (staff.user) {
        const u = {};
        if (first_name) u.first_name = first_name;
        if (middle_name !== undefined) u.middle_name = middle_name || null;
        if (last_name) u.last_name = last_name;
        if (phone !== undefined) u.phone = normalizePhone(phone);
        if (roleChanging) u.role = role;
        // Email is the login, so a change has to stay unique across the
        // whole system, not just this tenant.
        if (email && email.toLowerCase().trim() !== staff.user.email) {
          const taken = await User.findOne({ where: { email: email.toLowerCase().trim(), id: { [Op.ne]: staff.user.id } } });
          if (taken) return res.status(400).json({ success: false, message: 'That email is already registered.' });
          u.email = email.toLowerCase().trim();
        }
        if (phone && normalizePhone(phone) !== staff.user.phone) {
          const taken = await User.findOne({ where: { phone: normalizePhone(phone), id: { [Op.ne]: staff.user.id } } });
          if (taken) return res.status(400).json({ success: false, message: 'That phone number is already registered.' });
          u.phone = normalizePhone(phone);
        }
        if (Object.keys(u).length > 0) await staff.user.update(u);
      }

      // Update staff profile
      const s = {};
      if (employee_number) s.employee_number = employee_number;
      if (campus_id) s.campus_id = campus_id;
      if (department !== undefined) s.department = department || null;
      if (designation !== undefined) s.designation = designation || null;
      if (joining_date !== undefined) s.joining_date = joining_date || null;
      if (contract_type) s.contract_type = contract_type;
      if (salary !== undefined) s.salary = salary || null;
      if (experience_years !== undefined) s.experience_years = experience_years || 0;
      if (qualifications !== undefined) s.qualifications = qualifications;
      if (teaching_subjects !== undefined) s.teaching_subjects = teaching_subjects;
      if (reports_to_id !== undefined) s.reports_to_id = reports_to_id || null;
      if (emergency_contact !== undefined) s.emergency_contact = emergency_contact || null;
      if (emergency_contact_name !== undefined) s.emergency_contact_name = emergency_contact_name || null;
      if (emergency_contact_relation !== undefined) s.emergency_contact_relation = emergency_contact_relation || null;
      if (address !== undefined) s.address = address || null;
      if (city !== undefined) s.city = city || null;
      if (country !== undefined) s.country = country || null;
      if (date_of_birth !== undefined) s.date_of_birth = date_of_birth || null;
      if (gender !== undefined) s.gender = gender || null;
      if (marital_status !== undefined) s.marital_status = marital_status || null;
      if (blood_group !== undefined) s.blood_group = blood_group || null;
      if (national_id !== undefined) s.national_id = national_id || null;
      if (tin_number !== undefined) s.tin_number = tin_number || null;
      if (nssf_number !== undefined) s.nssf_number = nssf_number || null;
      if (bank_name !== undefined) s.bank_name = bank_name || null;
      if (bank_account_number !== undefined) s.bank_account_number = bank_account_number || null;
      if (contract_end_date !== undefined) s.contract_end_date = contract_end_date || null;
      if (notes !== undefined) s.notes = notes || null;
      if (status) s.status = status;

      await staff.update(s);

      const updated = await Staff.findByPk(id, {
        include: [
          { model: User, as: 'user', attributes: { exclude: ['password'] } },
          { model: Campus, as: 'campus' },
        ],
      });

      res.json({ success: true, message: 'Staff member updated successfully', data: updated });
    } catch (error) {
      next(error);
    }
  },

  // Soft delete (deactivate)
  async delete(req, res, next) {
    try {
      const { id } = req.params;
      const staff = await Staff.findOne({ where: { id, tenant_id: req.tenantId } });

      if (!staff) {
        return res.status(404).json({ success: false, message: 'Staff member not found' });
      }

      await staff.update({ status: 'inactive' });
      res.json({ success: true, message: 'Staff member deactivated successfully' });
    } catch (error) {
      next(error);
    }
  },

  // Permanent delete
  async permanentDelete(req, res, next) {
    try {
      const { id } = req.params;
      const staff = await Staff.findOne({ where: { id, tenant_id: req.tenantId } });

      if (!staff) {
        return res.status(404).json({ success: false, message: 'Staff member not found' });
      }

      const userId = staff.user_id;
      await staff.destroy();
      const user = await User.findByPk(userId);
      if (user) await user.destroy();

      res.json({ success: true, message: 'Staff member permanently deleted' });
    } catch (error) {
      next(error);
    }
  },

  // Reactivate staff
  async reactivate(req, res, next) {
    try {
      const { id } = req.params;
      const staff = await Staff.findOne({ where: { id, tenant_id: req.tenantId } });

      if (!staff) {
        return res.status(404).json({ success: false, message: 'Staff member not found' });
      }

      await staff.update({ status: 'active' });
      res.json({ success: true, message: 'Staff member reactivated successfully', data: staff });
    } catch (error) {
      next(error);
    }
  },

  // Bulk update status
  async bulkUpdateStatus(req, res, next) {
    try {
      const { ids, status } = req.body;

      if (!ids || !Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ success: false, message: 'Please provide staff IDs' });
      }

      if (!['active', 'inactive'].includes(status)) {
        return res.status(400).json({ success: false, message: 'Invalid status value' });
      }

      await Staff.update(
        { status },
        { where: { id: { [Op.in]: ids }, tenant_id: req.tenantId } }
      );

      res.json({ success: true, message: `${ids.length} staff member(s) updated successfully` });
    } catch (error) {
      next(error);
    }
  },

  // Get staff statistics
  async getStats(req, res, next) {
    try {
      const { id } = req.params;
      const staff = await Staff.findOne({ where: { id, tenant_id: req.tenantId } });

      if (!staff) {
        return res.status(404).json({ success: false, message: 'Staff member not found' });
      }

      const stats = {
        classes_assigned: 0,
        subjects_assigned: 0,
        attendance_rate: 0,
        years_of_service: staff.joining_date
          ? Math.floor((new Date() - new Date(staff.joining_date)) / (1000 * 60 * 60 * 24 * 365))
          : 0,
      };

      res.json({ success: true, data: stats });
    } catch (error) {
      next(error);
    }
  },

  // POST /staff/:id/documents — multipart upload, field name "document".
  async uploadPhoto(req, res, next) {
    try {
      const staff = await Staff.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
      if (!staff) return res.status(404).json({ success: false, message: 'Staff member not found' });
      if (!req.file) return res.status(400).json({ success: false, message: 'No photo uploaded' });

      const user = await User.findByPk(staff.user_id);
      if (!user) return res.status(404).json({ success: false, message: 'Linked user account not found' });

      const url = publicUrlFor(req, 'avatars', req.file.filename);
      await user.update({ avatar: url });

      res.status(200).json({ success: true, message: 'Photo updated', data: { avatar: url } });
    } catch (error) {
      next(error);
    }
  },

  async uploadDocument(req, res, next) {
    try {
      const staff = await Staff.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
      if (!staff) return res.status(404).json({ success: false, message: 'Staff member not found' });
      if (!req.file) return res.status(400).json({ success: false, message: 'No document uploaded' });

      const { name, type } = req.body;
      const doc = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        // Falls back to the original filename so a document is never left
        // unlabelled in the list.
        name: name || req.file.originalname,
        type: type || 'other',
        url: publicUrlFor(req, 'staff-documents', req.file.filename),
        size: req.file.size,
        uploaded_at: new Date().toISOString(),
        uploaded_by: req.user.id,
      };

      const documents = Array.isArray(staff.documents) ? staff.documents : [];
      await staff.update({ documents: [...documents, doc] });

      res.status(201).json({ success: true, message: 'Document uploaded', data: doc });
    } catch (error) {
      next(error);
    }
  },

  /** DELETE /staff/:id/documents/:documentId */
  async deleteDocument(req, res, next) {
    try {
      const staff = await Staff.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
      if (!staff) return res.status(404).json({ success: false, message: 'Staff member not found' });

      const documents = Array.isArray(staff.documents) ? staff.documents : [];
      const remaining = documents.filter((d) => d.id !== req.params.documentId);
      if (remaining.length === documents.length) {
        return res.status(404).json({ success: false, message: 'Document not found' });
      }

      await staff.update({ documents: remaining });
      res.json({ success: true, message: 'Document removed' });
    } catch (error) {
      next(error);
    }
  },
};
