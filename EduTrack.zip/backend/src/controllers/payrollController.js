import { can } from '../utils/permissionEngine.js';
import { Op } from 'sequelize';
import {
  PayrollPeriod, PayrollItem, Staff, User, ExpenseCategory, Expense, Campus,
} from '../models/index.js';
import { moneyFormatterFor } from '../utils/tenantDisplay.js';

const MANAGE_ROLES = ['super_admin', 'admin', 'accountant', 'hr'];

const MONTH_NAMES = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const sumLineItems = (items = []) => (items || []).reduce((sum, i) => sum + Number(i.amount || 0), 0);

const recomputeItem = (item) => {
  const allowancesTotal = sumLineItems(item.allowances);
  const deductionsTotal = sumLineItems(item.deductions);
  const gross = Number(item.basic_salary) + allowancesTotal;
  return { gross_pay: gross, total_deductions: deductionsTotal, net_pay: gross - deductionsTotal };
};

// ═══════════════════════════════════════════════════════════════════════════
// PERIODS
// ═══════════════════════════════════════════════════════════════════════════

export const getPeriods = async (req, res, next) => {
  try {
    const { status = '', year = '', campus_id = '' } = req.query;
    const where = { tenant_id: req.tenantId };
    if (status) where.status = status;
    if (year) where.year = year;
    if (campus_id) where.campus_id = campus_id;

    // Campus is included so a multi-campus school can tell two runs for the
    // same month apart in the list.
    const periods = await PayrollPeriod.findAll({
      where,
      include: [{ model: Campus, as: 'campus', attributes: ['id', 'name'], required: false }],
      order: [['year', 'DESC'], ['month', 'DESC']],
    });

    const data = await Promise.all(periods.map(async (p) => {
      const items = await PayrollItem.findAll({ where: { payroll_period_id: p.id }, attributes: ['net_pay'] });
      const totalNet = items.reduce((sum, i) => sum + Number(i.net_pay), 0);
      return { ...p.toJSON(), month_name: MONTH_NAMES[p.month], staff_count: items.length, total_net_pay: totalNet };
    }));

    res.json({ success: true, data });
  } catch (error) { next(error); }
};

export const getPeriodById = async (req, res, next) => {
  try {
    const period = await PayrollPeriod.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!period) return res.status(404).json({ success: false, message: 'Payroll period not found' });
    const items = await PayrollItem.findAll({
      where: { payroll_period_id: period.id },
      include: [{ model: User, as: 'user', attributes: ['id', 'first_name', 'last_name'] }, { model: Staff, as: 'staff', attributes: ['id', 'employee_number', 'department', 'designation'] }],
      order: [[{ model: User, as: 'user' }, 'first_name', 'ASC']],
    });
    res.json({ success: true, data: { ...period.toJSON(), month_name: MONTH_NAMES[period.month], items } });
  } catch (error) { next(error); }
};

export const createPeriod = async (req, res, next) => {
  try {
    const { campus_id, month, year } = req.body;
    if (!month || !year) return res.status(400).json({ success: false, message: 'month and year are required' });
    const existing = await PayrollPeriod.findOne({ where: { tenant_id: req.tenantId, campus_id: campus_id || null, month, year } });
    if (existing) return res.status(400).json({ success: false, message: `A payroll period for ${MONTH_NAMES[month]} ${year} already exists.` });
    const period = await PayrollPeriod.create({ tenant_id: req.tenantId, campus_id: campus_id || null, month, year, status: 'draft' });
    res.status(201).json({ success: true, message: 'Payroll period created', data: period });
  } catch (error) { next(error); }
};

export const deletePeriod = async (req, res, next) => {
  try {
    const period = await PayrollPeriod.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!period) return res.status(404).json({ success: false, message: 'Payroll period not found' });
    if (period.status !== 'draft') return res.status(400).json({ success: false, message: 'Only draft periods can be deleted.' });
    await PayrollItem.destroy({ where: { payroll_period_id: period.id } });
    await period.destroy();
    res.json({ success: true, message: 'Payroll period deleted' });
  } catch (error) { next(error); }
};

export const generateItems = async (req, res, next) => {
  try {
    const period = await PayrollPeriod.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!period) return res.status(404).json({ success: false, message: 'Payroll period not found' });
    if (period.status !== 'draft') return res.status(400).json({ success: false, message: 'Only draft periods can be generated/edited.' });

    const staffWhere = { tenant_id: req.tenantId, status: 'active' };
    if (period.campus_id) staffWhere.campus_id = period.campus_id;
    const staffList = await Staff.findAll({ where: staffWhere });

    const existingItems = await PayrollItem.findAll({ where: { payroll_period_id: period.id }, attributes: ['staff_id'] });
    const existingStaffIds = new Set(existingItems.map((i) => i.staff_id));

    let created = 0;
    for (const staff of staffList) {
      if (existingStaffIds.has(staff.id)) continue;
      const basicSalary = Number(staff.salary || 0);
      await PayrollItem.create({
        tenant_id: req.tenantId, payroll_period_id: period.id, staff_id: staff.id, user_id: staff.user_id,
        basic_salary: basicSalary, allowances: [], deductions: [],
        gross_pay: basicSalary, total_deductions: 0, net_pay: basicSalary,
      });
      created++;
    }
    res.json({ success: true, message: `${created} payslip(s) generated (${existingStaffIds.size} already existed)`, data: { created } });
  } catch (error) { next(error); }
};

export const processPeriod = async (req, res, next) => {
  try {
    const period = await PayrollPeriod.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!period) return res.status(404).json({ success: false, message: 'Payroll period not found' });
    if (period.status !== 'draft') return res.status(400).json({ success: false, message: 'Only draft periods can be processed.' });
    const itemCount = await PayrollItem.count({ where: { payroll_period_id: period.id } });
    if (itemCount === 0) return res.status(400).json({ success: false, message: 'Generate payslips before processing.' });
    await period.update({ status: 'processed', processed_by: req.user.id, processed_at: new Date() });
    res.json({ success: true, message: 'Payroll processed — ready to pay', data: period });
  } catch (error) { next(error); }
};

export const markPaid = async (req, res, next) => {
  try {
    const period = await PayrollPeriod.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!period) return res.status(404).json({ success: false, message: 'Payroll period not found' });
    if (period.status !== 'processed') return res.status(400).json({ success: false, message: 'Process the period before marking it paid.' });

    const items = await PayrollItem.findAll({ where: { payroll_period_id: period.id } });
    const totalNet = items.reduce((sum, i) => sum + Number(i.net_pay), 0);

    const [category] = await ExpenseCategory.findOrCreate({
      where: { tenant_id: req.tenantId, name: 'Salaries & Wages' },
      defaults: { tenant_id: req.tenantId, name: 'Salaries & Wages', description: 'Staff salaries and wages', status: 'active' },
    });

    const expense = await Expense.create({
      tenant_id: req.tenantId, campus_id: period.campus_id || null, category_id: category.id,
      amount: totalNet, expense_date: new Date().toISOString().slice(0, 10),
      payee: 'Staff Payroll', description: `Payroll for ${MONTH_NAMES[period.month]} ${period.year} (${items.length} staff)`,
      payment_method: 'bank_transfer', reference_number: `PAY-${period.year}${String(period.month).padStart(2, '0')}`,
      recorded_by: req.user.id, status: 'recorded',
    });

    await period.update({ status: 'paid', paid_by: req.user.id, paid_at: new Date(), expense_id: expense.id });
    const fmtMoney = await moneyFormatterFor(req.tenantId);
    res.json({ success: true, message: `Payroll marked paid — ${fmtMoney(totalNet)} recorded in Expenses.`, data: period });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// ITEMS
// ═══════════════════════════════════════════════════════════════════════════

export const updateItem = async (req, res, next) => {
  try {
    const item = await PayrollItem.findOne({ where: { id: req.params.id, tenant_id: req.tenantId }, include: [{ model: PayrollPeriod, as: 'period' }] });
    if (!item) return res.status(404).json({ success: false, message: 'Payslip not found' });
    if (item.period.status !== 'draft') return res.status(400).json({ success: false, message: 'This payroll period is no longer editable.' });

    const { basic_salary, allowances, deductions, notes } = req.body;
    const updates = {
      ...(basic_salary !== undefined && { basic_salary }),
      ...(allowances !== undefined && { allowances }),
      ...(deductions !== undefined && { deductions }),
      ...(notes !== undefined && { notes }),
    };
    const merged = { ...item.toJSON(), ...updates };
    Object.assign(updates, recomputeItem(merged));

    await item.update(updates);
    res.json({ success: true, message: 'Payslip updated', data: item });
  } catch (error) { next(error); }
};

export const deleteItem = async (req, res, next) => {
  try {
    const item = await PayrollItem.findOne({ where: { id: req.params.id, tenant_id: req.tenantId }, include: [{ model: PayrollPeriod, as: 'period' }] });
    if (!item) return res.status(404).json({ success: false, message: 'Payslip not found' });
    if (item.period.status !== 'draft') return res.status(400).json({ success: false, message: 'This payroll period is no longer editable.' });
    await item.destroy();
    res.json({ success: true, message: 'Payslip removed from this period' });
  } catch (error) { next(error); }
};

export const getItemById = async (req, res, next) => {
  try {
    const item = await PayrollItem.findOne({
      where: { id: req.params.id, tenant_id: req.tenantId },
      include: [
        { model: User, as: 'user', attributes: ['id', 'first_name', 'last_name', 'email'] },
        { model: Staff, as: 'staff', attributes: ['id', 'employee_number', 'department', 'designation'] },
        { model: PayrollPeriod, as: 'period' },
      ],
    });
    if (!item) return res.status(404).json({ success: false, message: 'Payslip not found' });
    if (item.user_id !== req.user.id && !(await can(req.user, req.tenantId, 'payroll.view'))) {
      return res.status(403).json({ success: false, message: 'You can only view your own payslip.' });
    }
    res.json({ success: true, data: { ...item.toJSON(), month_name: MONTH_NAMES[item.period.month] } });
  } catch (error) { next(error); }
};

export const getMyPayslips = async (req, res, next) => {
  try {
    const staff = await Staff.findOne({ where: { tenant_id: req.tenantId, user_id: req.user.id } });
    if (!staff) return res.json({ success: true, data: [] });
    const items = await PayrollItem.findAll({
      where: { tenant_id: req.tenantId, staff_id: staff.id },
      include: [{ model: PayrollPeriod, as: 'period' }],
      order: [[{ model: PayrollPeriod, as: 'period' }, 'year', 'DESC'], [{ model: PayrollPeriod, as: 'period' }, 'month', 'DESC']],
    });
    res.json({ success: true, data: items.map((i) => ({ ...i.toJSON(), month_name: MONTH_NAMES[i.period.month] })) });
  } catch (error) { next(error); }
};
