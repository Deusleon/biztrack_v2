import { Op } from 'sequelize';
import crypto from 'crypto';
import { MessageRecipient, Message, SmsGatewaySettings, SmsTransaction } from '../models/index.js';
import { isValidWebhookSignature } from '../utils/webhookSignature.js';
import { nextSmsStatusGroup, swalaStatusGroup } from '../services/smsService.js';
import { readVault } from '../utils/smsCredentialVault.js';

/**
 * Delivery-report (DLR) webhooks. SMS is inherently asynchronous — a
 * gateway accepting a send request only means "queued", not "delivered
 * to the handset". Real delivery confirmation arrives later as a webhook
 * call from the provider to a URL you register with them, pointing at
 * one of the routes below. This is what finally moves a recipient's
 * status from 'pending' to 'delivered' or 'failed'.
 *
 * These parsers were written from each provider's published webhook
 * payload format, without a live account to trigger a real callback and
 * confirm the exact shape — treat the field names here as a best-effort
 * starting point and adjust if a provider's actual payload differs once
 * you can see one.
 *
 * Register these URLs with your provider as:
 *   https://your-domain.com/api/v1/webhooks/dlr/beem_africa
 *   https://your-domain.com/api/v1/webhooks/dlr/nextsms
 *   https://your-domain.com/api/v1/webhooks/dlr/meseji
 *   https://your-domain.com/api/v1/webhooks/dlr/swalasms/<tenantId>/<signature>   (shown in Settings → Messages)
 *
 * No authentication is applied to these routes on purpose — providers
 * call them directly, not through the app's normal login. If a provider
 * supports a shared secret / signature header, it's worth adding
 * verification here once you're wiring up a real account.
 */

const STATUS_MAP = {
  // Normalize each provider's own status vocabulary to ours.
  delivered: 'delivered', delivrd: 'delivered', success: 'delivered', successful: 'delivered',
  failed: 'failed', undeliverable: 'failed', rejected: 'failed', expired: 'failed',
  sent: 'sent', pending: 'pending', queued: 'pending', accepted: 'pending',
};

const normalizeStatus = (raw) => STATUS_MAP[String(raw || '').toLowerCase()] || 'pending';

const applyDeliveryUpdate = async (providerMessageId, rawStatus, errorMessage) => {
  if (!providerMessageId) return { matched: false };
  const recipient = await MessageRecipient.findOne({ where: { provider_message_id: String(providerMessageId) } });
  if (!recipient) return { matched: false };
  return applyRecipientUpdate(recipient, rawStatus, errorMessage);
};

/** Applies a delivery result to a recipient we already have in hand, and keeps
 * the parent message's counts in step. Also used by the on-demand delivery
 * check, so a failure found that way is counted exactly like one reported by
 * webhook. */
export const applyRecipientUpdate = async (recipient, rawStatus, errorMessage) => {
  const status = normalizeStatus(rawStatus);
  await recipient.update({
    status,
    error_message: status === 'failed' ? (errorMessage || recipient.error_message) : recipient.error_message,
    delivered_at: status === 'delivered' ? new Date() : recipient.delivered_at,
  });

  // Keep the parent Message's aggregate counts roughly in sync — a
  // recipient moving from pending → failed should be reflected there too.
  if (status === 'failed') {
    const message = await Message.findByPk(recipient.message_id);
    if (message) {
      await message.update({
        failed_count: message.failed_count + 1,
        sent_count: Math.max(0, message.sent_count - 1),
        status: message.failed_count + 1 >= message.total_recipients ? 'failed' : 'partially_sent',
      });
    }
  }

  return { matched: true, recipient };
};

/** POST /webhooks/dlr/beem_africa
 * Beem's delivery callback payload (typical shape):
 *   { "dest_addr": "255...", "request_id": "...", "status": "DELIVRD" }
 */
export const beemAfricaDlr = async (req, res) => {
  const body = req.body || {};
  await applyDeliveryUpdate(body.request_id || body.id, body.status, body.description);
  res.status(200).json({ success: true }); // providers typically just need a 200 OK
};

/**
 * NextSMS delivery reports.
 *
 * NextSMS reports each message as
 *   { messageId, to, status: { groupName: 'DELIVERED', name: 'DELIVERED_TO_HANDSET', description },
 *     error: { description }, doneAt, ... }
 * either alone or wrapped in `results` / `messages` when several arrive at
 * once — all of those shapes are accepted.
 *
 * Two URLs lead here:
 *
 *   POST /webhooks/dlr/nextsms/<tenantId>/<signature>   ← register THIS one.
 *       Shown in full in Settings → Messages. The signature is computed from
 *       the school's id and a server secret (utils/webhookSignature.js), so the
 *       URL already exists — nothing to create, migrate or put in .env — and
 *       it identifies the school: a report can only ever touch that school's
 *       messages, and nobody can post fake results without the signature.
 *
 *   POST /webhooks/dlr/nextsms            ← the original, token-less URL, kept
 *       so anything already registered keeps working. Optionally protected by
 *       NEXTSMS_WEBHOOK_TOKEN (`?token=`) in .env.
 */
const nextSmsReportList = (body) => (
  Array.isArray(body) ? body
    : Array.isArray(body?.results) ? body.results
      : Array.isArray(body?.messages) ? body.messages
        : [body || {}]
);

const processNextSmsReports = async (body, tenantId = null) => {
  for (const report of nextSmsReportList(body)) {
    try {
      const messageId = report.messageId ?? report.id;
      if (!messageId) continue;

      const status = nextSmsStatusGroup(report.status);
      const recipient = await MessageRecipient.findOne({ where: { provider_message_id: String(messageId) } });
      if (!recipient) continue;

      if (tenantId) {
        // Only this school's own messages may be touched through its URL.
        const owner = await Message.findOne({ where: { id: recipient.message_id, tenant_id: tenantId }, attributes: ['id'] });
        if (!owner) continue;
      }

      // Providers repeat callbacks. Applying the same result twice would
      // double-count a failure on the parent message, and a late "pending"
      // must never undo a final answer.
      if (recipient.status === status || (status === 'pending' && ['delivered', 'failed'].includes(recipient.status))) continue;

      await applyRecipientUpdate(recipient, status, report.error?.description || report.status?.description);

      // Keep the message's delivered figure current without waiting for
      // somebody to open it.
      const [delivered, providerFailed] = await Promise.all([
        MessageRecipient.count({ where: { message_id: recipient.message_id, status: 'delivered' } }),
        MessageRecipient.count({ where: { message_id: recipient.message_id, status: 'failed', provider_message_id: { [Op.ne]: null } } }),
      ]);
      await Message.update({ delivered_count: delivered, provider_failed_count: providerFailed }, { where: { id: recipient.message_id } });
    } catch (err) {
      console.error('[webhook:nextsms] could not apply a delivery report:', err.message);
    }
  }
};

export const nextSmsDlrForSchool = async (req, res) => {
  const { tenantId, signature } = req.params;
  if (!isValidWebhookSignature(tenantId, signature)) {
    return res.status(404).json({ success: false, message: 'Unknown webhook URL' });
  }
  await processNextSmsReports(req.body, tenantId);
  res.status(200).json({ success: true });
};

export const nextSmsDlr = async (req, res) => {
  const expected = process.env.NEXTSMS_WEBHOOK_TOKEN;
  if (expected && req.query?.token !== expected) {
    return res.status(401).json({ success: false, message: 'Invalid webhook token' });
  }
  await processNextSmsReports(req.body);
  res.status(200).json({ success: true });
};

/**
 * SwalaSMS webhooks (https://docs.swalasms.com → Webhooks).
 *
 *   POST /webhooks/dlr/swalasms/<tenantId>/<signature>   ← register THIS URL, shown in Settings → Messages.
 *
 * Two independent checks, because anyone can reach a public URL:
 *   1. the signature in the URL (same scheme as NextSMS) says the URL really is this school's own;
 *   2. SwalaSMS signs the EXACT JSON body with HMAC-SHA256 and sends the digest in `X-SwalaSMS-Signature`.
 *      If a webhook signing secret has been saved (Settings → Messages → API Secret), a body that does not match it is
 *      refused with 401. Without a saved secret, only check 1 applies — so save the secret SwalaSMS shows you.
 *
 * Events: sms.delivered / sms.failed move a recipient from pending to its final state; wallet.topup.completed is
 * recorded in the SMS history; wallet.topup.failed is only logged. Anything else is acknowledged and ignored, so
 * SwalaSMS never keeps retrying an event we do not use.
 */
export const swalaSignatureMatches = (rawBody, header, secret) => {
  try {
    if (!rawBody || !header || !secret) return false;
    const given = String(header).trim().replace(/^sha256=/i, '').toLowerCase();
    const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
    return given.length === expected.length && crypto.timingSafeEqual(Buffer.from(given), Buffer.from(expected));
  } catch { return false; }
};

const refreshDeliveredCounts = async (messageId) => {
  const [delivered, providerFailed] = await Promise.all([
    MessageRecipient.count({ where: { message_id: messageId, status: 'delivered' } }),
    MessageRecipient.count({ where: { message_id: messageId, status: 'failed', provider_message_id: { [Op.ne]: null } } }),
  ]);
  await Message.update({ delivered_count: delivered, provider_failed_count: providerFailed }, { where: { id: messageId } });
};

export const swalaSmsDlrForSchool = async (req, res) => {
  const { tenantId, signature } = req.params;
  if (!isValidWebhookSignature(tenantId, signature, 'swalasms-dlr')) {
    return res.status(404).json({ success: false, message: 'Unknown webhook URL' });
  }

  const settings = await SmsGatewaySettings.findOne({ where: { tenant_id: tenantId } });
  const secret = (settings && (readVault(settings).swalasms?.api_secret || (settings.provider === 'swalasms' ? settings.api_secret : null))) || null;
  if (secret && !swalaSignatureMatches(req.rawBody, req.headers['x-swalasms-signature'], secret)) {
    return res.status(401).json({ success: false, message: 'Invalid webhook signature' });
  }

  const event = req.body || {};
  try {
    if (event.event === 'sms.delivered' || event.event === 'sms.failed') {
      const status = event.event === 'sms.delivered' ? 'delivered' : 'failed';
      const recipient = event.message_id ? await MessageRecipient.findOne({ where: { provider_message_id: String(event.message_id) } }) : null;
      const owner = recipient ? await Message.findOne({ where: { id: recipient.message_id, tenant_id: tenantId }, attributes: ['id'] }) : null;
      // Only this school's own messages; providers repeat callbacks, and a late "pending" never undoes a final answer.
      if (recipient && owner && recipient.status !== status && !(swalaStatusGroup(event.status) === 'pending' && ['delivered', 'failed'].includes(recipient.status))) {
        await applyRecipientUpdate(recipient, status, event.error || undefined);
        if (status === 'delivered' && event.delivered_at) await recipient.update({ delivered_at: new Date(event.delivered_at) });
        await refreshDeliveredCounts(recipient.message_id);
      }
    } else if (event.event === 'wallet.topup.completed' && event.order_uid) {
      const reference = `swalasms:${event.order_uid}`;
      const exists = await SmsTransaction.findOne({ where: { tenant_id: tenantId, reference } });
      if (!exists) {
        await SmsTransaction.create({
          tenant_id: tenantId, type: 'purchase', amount: Number(event.units) || 0, balance_after: Number(event.balance_after) || 0,
          reference, description: `SwalaSMS top-up ${event.reference || ''} (${Number(event.units) || 0} credits)`.replace(/\s+/g, ' ').trim(),
        });
      }
    } else if (event.event === 'wallet.topup.failed') {
      console.warn('[webhook:swalasms] a top-up payment failed:', event.order_uid || '(no order id)');
    }
  } catch (err) {
    console.error('[webhook:swalasms] could not apply an event:', err.message);
  }
  res.status(200).json({ success: true });
};

/** POST /webhooks/dlr/meseji
 * Meseji delivery callback — exact shape unconfirmed (see module docstring);
 * this accepts the most common field-name variants. */
export const mesejiDlr = async (req, res) => {
  const body = req.body || {};
  await applyDeliveryUpdate(body.message_id || body.id || body.messageId, body.status || body.delivery_status, body.error);
  res.status(200).json({ success: true });
};
