// FILE PATH: backend/src/controllers/feeController.js
import { familyContactsFor } from '../utils/familyContacts.js';
import { can } from '../utils/permissionEngine.js';
import { Op, cast, col, where as sequelizeWhere } from 'sequelize';
import sequelize from '../config/database.js';
import { FeeStructure, Payment, StudentCharge, Student, Class, Section, User, Campus, TransportAllocation, HostelAllocation, Tenant, FeeStructureStudent } from '../models/index.js';
import { notifyEvent } from '../services/notificationService.js';
import { generateVerificationCode, isValidVerificationCode } from '../utils/receiptSecurity.js';
import { applyAcademicYearFilter, academicYearBaseMatch, currentBaseYear, extractBaseYear, academicYearDateRange } from '../utils/academicYear.js';
import { findStudentsEnrolledInClass, resolveStudentClassForYear } from '../utils/classRoster.js';
import { moneyFormatterFor } from '../utils/tenantDisplay.js';

const toNum = (v) => (v === null || v === undefined || v === '' ? 0 : Number(v));

// A fee structure's `amount` is the amount charged EACH time, per its
// frequency — e.g. a "monthly" fee of 50,000 is normally charged 12 times
// across the academic year. `billing_cycles`, when set, overrides that
// default count — e.g. a transport fee only charged for the 9 months
// school is actually in session, not the 3 holiday months.
const FREQUENCY_MULTIPLIER = { one_time: 1, monthly: 12, quarterly: 4, annually: 1 };
const billingCycles = (structure) => {
  if (structure.frequency === 'one_time' || structure.frequency === 'annually') return 1;
  return structure.billing_cycles || FREQUENCY_MULTIPLIER[structure.frequency] || 1;
};
const annualizedAmount = (structure) => toNum(structure.amount) * billingCycles(structure);

// Identity of a fee NAME (case/whitespace-insensitive) and of one priced
// VARIANT of it — see getFeeStructures.
const feeNameKey = (name) => String(name || '').trim().toLowerCase();
const feeVariantKey = (structure) =>
  `${feeNameKey(structure.name)}|${toNum(structure.amount)}|${structure.frequency}|${billingCycles(structure)}`;

/** Every active fee structure for a class + academic year — not yet
 * filtered by who actually owes each one (see applicableStructures). */
const feeStructuresForClass = async (tenantId, classId, academicYear) => {
  if (!classId || !academicYear) return [];
  // Ordered so that spreading an un-earmarked "general" payment across a
  // student's fee items is deterministic — without a stable order the same
  // payment could land on different items between two requests, making a
  // student's per-item balances flicker.
  const where = { tenant_id: tenantId, class_id: classId, status: 'active' };
  applyAcademicYearFilter(where, academicYear);
  return FeeStructure.findAll({
    where,
    order: [['created_at', 'ASC'], ['name', 'ASC']],
  });
};

/** Whether a student "uses" transport/hostel for fee purposes — true if
 * EITHER they have a real, active TransportAllocation/HostelAllocation
 * (assigned to a specific vehicle/route or room via those modules), OR
 * they were simply marked "Transport/Hostel Required" at admission. Fee
 * charging shouldn't depend on the school having also gone through a
 * separate room/vehicle assignment workflow — a student flagged at
 * admission is already meant to be billed for it. */
const usesOptionalService = (student, hasActiveAllocation, requiredFlag) =>
  hasActiveAllocation || student?.[requiredFlag] === true;

/** Real transport/hostel costs are rarely one flat number for the whole
 * class — a route across town costs more to run than one round the
 * corner, a private room costs more than a shared one. Rather than
 * needing a separate FeeStructure per route/room (which would also mean
 * a separate name — "Transport", "Transport (Route B)", "Transport
 * (Route C)" — cluttering every fee list with what is really one fee),
 * the student's own TransportAllocation/HostelAllocation can carry a
 * `fee` that OVERRIDES the class-wide structure's amount for that one
 * student, while everything else about the structure (its name, which
 * students it applies to, how often it's billed) stays exactly the
 * same. A student with no override on file — or none set on their
 * allocation — simply gets the standard class-wide amount, unchanged
 * from before this existed. The structure's own frequency/billing_cycles
 * still applies on top of the override amount, so a personalized route
 * fee is still billed termly/monthly/etc exactly like the standard one
 * would be — only the PER-CYCLE amount itself differs. */
const withServiceFeeOverride = (structure, overrideFee) => {
  if (overrideFee === null || overrideFee === undefined) return structure;
  const amount = Number(overrideFee);
  if (!Number.isFinite(amount)) return structure;
  // Sequelize instances keep their real field values behind prototype
  // getters backed by `dataValues` — Object.keys()/spread on the RAW
  // instance sees none of them, only bookkeeping properties like
  // `dataValues` itself. Converting to a plain object first is what
  // makes `name`, `applies_to`, `frequency` etc. actually survive the
  // spread below, instead of silently coming out undefined.
  const plain = typeof structure.toJSON === 'function' ? structure.toJSON() : structure;
  return { ...plain, amount, is_override: true };
};

/** Which of a class's fee structures actually apply to ONE student, with
 * transport/hostel structures re-priced to that student's own allocation
 * fee when they have one on file (see withServiceFeeOverride above). A
 * structure with applies_to='all' (the common case — Tuition, Uniform,
 * Exam, Lunch, ...) always applies, unchanged. 'transport'/'hostel' only
 * apply if the student actually uses that service — otherwise a student
 * who's never used the bus would carry a permanent, unpayable "balance"
 * for a fee they were never really charged in real life. 'selected_students'
 * only applies if the student was specifically hand-picked for THAT
 * structure (selectedStructureIds — see fee_structure_students) — this is
 * how a school prices an ad-hoc group (an extra class, a trip, a
 * distance-based rate band) without inventing a rule-based category for
 * every possible reason a fee might not be universal. */
const applicableStructures = (structures, { usesTransport, usesHostel, transportFee, hostelFee, selectedStructureIds }) =>
  structures
    .filter((s) => {
      if (s.applies_to === 'all') return true;
      if (s.applies_to === 'transport') return usesTransport;
      if (s.applies_to === 'hostel') return usesHostel;
      if (s.applies_to === 'selected_students') return selectedStructureIds?.has(s.id) === true;
      return false;
    })
    .map((s) => {
      if (s.applies_to === 'transport') return withServiceFeeOverride(s, transportFee);
      if (s.applies_to === 'hostel') return withServiceFeeOverride(s, hostelFee);
      return s;
    });

/** How much has been paid against each individual fee structure, across a
 * student's whole payment history.
 *
 * Three payment shapes feed in:
 *   - multi-item  → its `allocations` breakdown
 *   - single-item → `fee_structure_id` + `amount`
 *   - general     → not earmarked for anything, so it's SPREAD across the
 *                   student's items, each filled up to what it still owes
 *                   before the next gets anything
 *
 * Spreading matters because a parent who hands over a lump sum has, in
 * real terms, paid down specific fees — leaving that money unattributed
 * would make every item still look fully unpaid on the next receipt.
 *
 * `structures` must be in a stable order (see feeStructuresForClass).
 * Returns a plain object keyed by fee_structure_id. */
export const paidPerStructure = (payments, structures = []) => {
  const { earmarked, generalPool } = splitEarmarkedFromGeneral(payments);
  const { allocations } = spreadAcrossStructures(generalPool, structures, earmarked);

  const totals = { ...earmarked };
  allocations.forEach((a) => { totals[a.fee_structure_id] = (totals[a.fee_structure_id] || 0) + a.amount; });
  return totals;
};

/** A payment line can point at a class fee structure OR a one-off student
 * charge. Only the former can use Payment.fee_structure_id, since that
 * column has a foreign key into fee_structures — charges are carried in
 * the `allocations` JSONB instead, which has no such constraint. This
 * returns whichever id a line refers to, so the billing maths treats both
 * the same way. */
const allocationKey = (a) => a?.fee_structure_id || a?.charge_id || null;

/** Separates payments into what was explicitly attributed to a fee item and
 * what arrived as an un-earmarked lump sum still waiting to be spread. */
const splitEarmarkedFromGeneral = (payments) => {
  const earmarked = {};
  let generalPool = 0;

  payments.forEach((p) => {
    const allocations = Array.isArray(p.allocations) ? p.allocations : null;
    if (allocations && allocations.length > 0) {
      allocations.forEach((a) => {
        const key = allocationKey(a);
        if (!key) return;
        earmarked[key] = (earmarked[key] || 0) + toNum(a.amount);
      });
    } else if (p.fee_structure_id) {
      earmarked[p.fee_structure_id] = (earmarked[p.fee_structure_id] || 0) + toNum(p.amount);
    } else {
      generalPool += toNum(p.amount);
    }
  });

  return { earmarked, generalPool };
};

/** Spreads an un-earmarked amount across a student's fee items, filling
 * each up to what it still owes before the next gets anything.
 *
 * This is the single source of truth for how a general payment is applied:
 * the same function drives both the running per-item balances and the
 * breakdown printed on the receipt, so what the parent sees on paper can't
 * drift from what the system actually recorded.
 *
 * `alreadyPaid` is a map of fee_structure_id → amount settled before this
 * money is applied. Returns the per-item allocations plus whatever is left
 * once every item is fully settled (an advance the school is holding).
 *
 * `structures` must be in a stable order (see feeStructuresForClass). */
const spreadAcrossStructures = (amount, structures = [], alreadyPaid = {}) => {
  const round = (n) => Math.round(n * 100) / 100;
  let remaining = round(toNum(amount));
  const allocations = [];

  structures.forEach((s) => {
    if (remaining <= 0) return;
    const owed = round(annualizedAmount(s) - (alreadyPaid[s.id] || 0));
    if (owed <= 0) return;
    const share = round(Math.min(owed, remaining));
    allocations.push({ fee_structure_id: s.id, name: s.name, amount: share });
    remaining = round(remaining - share);
  });

  return { allocations, unallocated: round(Math.max(0, remaining)) };
};

/** Splits a student's total paid into what actually settles their bill
 * versus what they've paid ON TOP of it.
 *
 * An overpayment is credit the school is holding, not a negative balance —
 * so `balance` floors at zero and the surplus is reported separately as
 * `extra`. Outstanding figures can then sum balances without an overpaying
 * student silently cancelling out a defaulting one. */
export const splitPaidAgainstExpected = (expected, paid) => {
  const round = (n) => Math.round(n * 100) / 100;
  return {
    balance: round(Math.max(0, expected - paid)),
    extra: round(Math.max(0, paid - expected)),
  };
};

/** Builds the receipt for ONE payment, exactly as it stood at that moment.
 *
 * `payments` must be every completed payment for the student, oldest
 * first. Everything before `payment` in that list counts as already
 * settled; everything after it is ignored, so reprinting an old receipt
 * shows the balance that was owed THEN, not the balance owed today.
 *
 * Each checklist row carries a status alongside the amount:
 *   - 'paid'    → fully settled as at this receipt, whether by this
 *                 payment or an earlier one. Printing a dash here reads as
 *                 "never paid", which is exactly the wrong impression.
 *   - 'partial' → something has gone against it, but it still owes
 *   - 'unpaid'  → nothing has ever been paid towards it
 */
export const buildReceiptSnapshot = ({ structures, payments, payment }) => {
  const round = (n) => Math.round(n * 100) / 100;

  const index = payments.findIndex((p) => p.id === payment.id);
  const priorPayments = index > 0 ? payments.slice(0, index) : [];
  const throughThis = index >= 0 ? payments.slice(0, index + 1) : [...priorPayments, payment];

  // Where every earlier payment had landed, per fee item.
  const priorTotals = paidPerStructure(priorPayments, structures);

  // What THIS payment settled, per fee item.
  const paidNow = {};
  const extraRows = [];
  const allocations = Array.isArray(payment.allocations) ? payment.allocations : [];

  if (allocations.length > 0) {
    // The breakdown was recorded at payment time.
    allocations.forEach((a) => {
      const key = allocationKey(a);
      if (key) paidNow[key] = toNum(a.amount);
    });
  } else if (payment.fee_structure_id) {
    // Single item.
    paidNow[payment.fee_structure_id] = toNum(payment.amount);
  } else {
    // General payment: not earmarked, but it still paid real fees down.
    // Replay the same spreading the running balances use, so the receipt
    // itemizes where the money actually went.
    const spread = spreadAcrossStructures(toNum(payment.amount), structures, priorTotals);
    spread.allocations.forEach((a) => { paidNow[a.fee_structure_id] = a.amount; });

    // Money left once every item is settled is an advance. It has to
    // appear, or the rows wouldn't add up to the receipt's own total.
    if (spread.unallocated > 0) {
      extraRows.push({ name: 'Advance Payment (Credit)', amount: spread.unallocated, status: 'credit' });
    }
  }

  const feeChecklist = structures.map((s) => {
    const charged = annualizedAmount(s);
    const paidToDate = round((priorTotals[s.id] || 0) + (paidNow[s.id] || 0));
    return {
      name: s.name,
      amount: paidNow[s.id] !== undefined ? paidNow[s.id] : null,
      charged,
      paid_to_date: paidToDate,
      status: paidToDate >= charged - 0.005 ? 'paid' : paidToDate > 0 ? 'partial' : 'unpaid',
      // Marks a one-off personal charge (e.g. a lost library book) so the
      // receipt can say what the debt is for rather than listing it as if
      // it were an ordinary class fee.
      is_charge: s.is_charge === true,
      charge_category: s.charge_category || null,
    };
  });

  // Items on this receipt whose fee structure is no longer active for the
  // class (renamed, deactivated, moved) would otherwise vanish from their
  // own receipt — fall back to the name snapshotted at payment time.
  const listedIds = new Set(structures.map((s) => s.id));
  allocations
    .filter((a) => !listedIds.has(allocationKey(a)))
    .forEach((a) => feeChecklist.push({
      name: a.name || 'Fee Payment', amount: toNum(a.amount), charged: null,
      paid_to_date: toNum(a.amount), status: 'paid', is_charge: Boolean(a.charge_id),
    }));

  feeChecklist.push(...extraRows);

  // A payment against a class with no fee structures at all has nothing to
  // itemize — keep one honest line rather than an empty table.
  if (feeChecklist.length === 0) {
    feeChecklist.push({ name: 'General Fee Payment', amount: toNum(payment.amount), charged: null, paid_to_date: toNum(payment.amount), status: 'paid' });
  }

  const expected = structures.reduce((sum, s) => sum + annualizedAmount(s), 0);
  const paidToDate = throughThis.reduce((sum, p) => sum + toNum(p.amount), 0);
  const { balance, extra } = splitPaidAgainstExpected(expected, paidToDate);

  return {
    expected: round(expected),
    paid_to_date: round(paidToDate),
    balance,
    extra,
    fee_checklist: feeChecklist,
    // Stamped so a snapshot can be told apart from a freshly-computed one
    // if the format ever needs migrating.
    generated_at: new Date().toISOString(),
  };
};

/** Outstanding one-off charges raised against a specific student.
 *
 * Charges without an academic year belong to whatever year is being looked
 * at — a fine raised mid-year shouldn't drop off the bill because nobody
 * stamped a year on it. Waived and cancelled ones stop counting. */
const chargesForStudent = async (tenantId, studentId, academicYear) => {
  const where = { tenant_id: tenantId, student_id: studentId, status: 'active' };
  const yearMatch = academicYear ? academicYearBaseMatch(academicYear) : null;
  if (yearMatch) where[Op.and] = [{ [Op.or]: [yearMatch, { academic_year: null }] }];
  return StudentCharge.findAll({ where, order: [['created_at', 'ASC']] });
};

/** Presents a charge in the same shape as a fee structure, so the billing
 * maths, receipt builder and payment allocation need no second code path.
 * `is_charge` marks it for anything that must tell them apart. */
const chargeAsBillable = (charge) => ({
  id: charge.id,
  name: charge.description,
  amount: Number(charge.amount),
  frequency: 'one_time',
  billing_cycles: 1,
  applies_to: 'all',
  is_charge: true,
  charge_category: charge.category,
});

/** Expected fee total for ONE specific student — not a class-wide
 * figure applied uniformly to everyone in it. Exported so other
 * controllers (e.g. Student statistics) can reuse the exact same
 * billing_cycles/applies_to-aware calculation instead of duplicating it. */
export const expectedForStudent = async (tenantId, student, academicYear) => {
  const [classStructures, transportAlloc, hostelAlloc, charges, myAssignments] = await Promise.all([
    feeStructuresForClass(tenantId, student.class_id, academicYear),
    TransportAllocation.findOne({ where: { tenant_id: tenantId, student_id: student.id, status: 'active' }, attributes: ['fee'] }),
    HostelAllocation.findOne({ where: { tenant_id: tenantId, student_id: student.id, status: 'active' }, attributes: ['fee'] }),
    chargesForStudent(tenantId, student.id, academicYear),
    FeeStructureStudent.findAll({ where: { tenant_id: tenantId, student_id: student.id }, attributes: ['fee_structure_id'] }),
  ]);

  const usesTransport = usesOptionalService(student, !!transportAlloc, 'transport_required');
  const usesHostel = usesOptionalService(student, !!hostelAlloc, 'hostel_required');
  const selectedStructureIds = new Set(myAssignments.map((a) => a.fee_structure_id));
  const applicable = applicableStructures(classStructures, {
    usesTransport, usesHostel,
    transportFee: transportAlloc?.fee ?? null,
    hostelFee: hostelAlloc?.fee ?? null,
    selectedStructureIds,
  });

  // One-off charges raised against this student personally (a lost library
  // book, say) sit alongside the class fees. Everything downstream — the
  // balance, the payment form, the receipt breakdown — works off this
  // combined list, so a charge behaves exactly like any other fee item
  // instead of being a debt hidden inside another module.
  const structures = [...applicable, ...charges.map(chargeAsBillable)];

  return {
    structures,
    charges,
    total: structures.reduce((sum, s) => sum + annualizedAmount(s), 0),
  };
};

/** How much a student still owes from EACH earlier academic year they
 * were enrolled in — arrears, in the plain sense parents and accountants
 * mean it: expected minus paid, per year, only for years where that's
 * still positive. Deliberately computed fresh every time rather than
 * stored anywhere: fees, fee structures and payments can all change
 * after the fact (a structure edited, a late payment recorded against
 * an old year), and a stored "carried forward" balance would silently
 * go stale the moment any of that happened. Computing it live off the
 * same `expectedForStudent`/`paidPerStructure` logic used for the
 * current year means it can never drift from what Fee Status shows for
 * that year if you actually opened it.
 *
 * This is also why a promoted student's old-class debt "automatically"
 * carries into what they owe going forward: it was never tied to a
 * specific payment record that moves with them — it's simply still
 * there, unpaid, every time this function looks back at that year,
 * until enough payment history against that year closes it out.
 */
export const arrearsForStudent = async (tenantId, student, uptoAcademicYear) => {
  const uptoBaseYear = extractBaseYear(uptoAcademicYear);
  // A fixed lookback window rather than admission_date: real promotion
  // history is the actual authority on which years a student was
  // enrolled (resolveStudentClassForYear returns null for any year it
  // can't support), and admission_date can't be trusted as a floor —
  // e.g. a student migrated into EduTrack after already having years of
  // real history elsewhere would have an admission_date newer than
  // years they demonstrably attended. 10 years comfortably covers any
  // school's full programme length.
  const firstYear = uptoBaseYear - 10;

  const years = [];
  for (let y = firstYear; y < uptoBaseYear; y += 1) years.push(y);

  const studentPlain = typeof student.toJSON === 'function' ? student.toJSON() : student;
  // Every earlier year is independent of the others, so they are worked out side by side instead of one query
  // after another (up to ~10 years × several queries each used to run in a row — the slow part of the summary).
  const perYear = await Promise.all(years.map(async (baseYear) => {
    const classForYear = await resolveStudentClassForYear({ tenantId, student, targetBaseYear: baseYear });
    if (!classForYear) return null; // not enrolled that year — nothing owed

    const academicYearLabel = classForYear.academic_year;
    const studentForYear = { ...studentPlain, class_id: classForYear.id };
    const { structures, total: expected } = await expectedForStudent(tenantId, studentForYear, academicYearLabel);
    if (expected <= 0) return null;

    const dateRange = academicYearDateRange(baseYear);
    const payments = await Payment.findAll({
      where: {
        tenant_id: tenantId, student_id: student.id, status: 'completed',
        payment_date: { [Op.between]: [dateRange.start, dateRange.end] },
      },
      include: [{ model: FeeStructure, as: 'feeStructure', attributes: ['id', 'name'] }],
    });
    const paid = payments.reduce((sum, p) => sum + toNum(p.amount), 0);
    const balance = Math.max(0, Math.round((expected - paid) * 100) / 100);
    if (balance <= 0) return null; // that year is fully settled — no arrears carried from it

    const paidByStructure = paidPerStructure(payments, structures);
    const items = structures
      .map((s) => {
        const annual = annualizedAmount(s);
        const paidForItem = paidByStructure[s.id] || 0;
        const outstanding = Math.max(0, Math.round((annual - paidForItem) * 100) / 100);
        return {
          name: s.name, annual_amount: annual, paid: paidForItem, outstanding,
          is_charge: s.is_charge === true, charge_category: s.charge_category || null,
        };
      })
      .filter((item) => item.outstanding > 0);

    return {
      academic_year: academicYearLabel,
      class_name: classForYear.name,
      expected: Math.round(expected * 100) / 100,
      paid: Math.round(paid * 100) / 100,
      balance,
      items,
    };
  }));
  const byYear = perYear.filter(Boolean); // still oldest year first
  const total = byYear.reduce((sum, y) => sum + y.balance, 0);

  return { total: Math.round(total * 100) / 100, years: byYear };
};

// ═══════════════════════════════════════════════════════════════════════════
// FEE STRUCTURES (CRUD)
// ═══════════════════════════════════════════════════════════════════════════

export const getFeeStructures = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, search = '', class_id = '', academic_year = '', status = '', campus_id = '', applies_to = '', fee_variants = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (class_id) where.class_id = class_id;
    // Qualified as "FeeStructure.academic_year" — this query also joins
    // Class (aliased 'class'), which has its OWN academic_year column, so
    // an unqualified reference would be ambiguous to Postgres.
    applyAcademicYearFilter(where, academic_year, 'FeeStructure.academic_year');
    if (status) where.status = status;
    if (campus_id) where.campus_id = campus_id;
    // `applies_to` here is a SCENARIO, not an exact match — "general" means
    // just the standard fees everyone pays, while "transport"/"hostel" mean
    // standard fees PLUS that optional service's fee, matching how a real
    // student's bill is actually built up (see applicableStructures below).
    if (applies_to === 'general') where.applies_to = 'all';
    else if (applies_to === 'transport' || applies_to === 'hostel') {
      // Besides the service's own fees, a school often prices a service per
      // route/room-type with several hand-picked ('selected_students') fees
      // that share the service's NAME — e.g. "Transport Fee" for one route
      // and another "Transport Fee" for a different route. Those belong in
      // this scenario too, otherwise their variants could never be seen.
      where[Op.and] = [
        ...(where[Op.and] || []),
        { [Op.or]: [
          { applies_to: { [Op.in]: ['all', applies_to] } },
          { applies_to: 'selected_students', name: { [Op.iLike]: `%${applies_to}%` } },
        ] },
      ];
    }
    if (search) where.name = { [Op.iLike]: `%${search}%` };

    // ── Fee variants ────────────────────────────────────────────────────
    // One fee NAME can legitimately carry several different prices — e.g.
    // "Transport Fee" priced per route. A "variant" is one distinct
    // name + amount + frequency + billing-cycles combination.
    //
    // Variants belong to a chosen Fee Scenario: once the caller has picked
    // one (Standard / Transport / Hostel), we look at the fees in that
    // scenario and report every fee NAME — whatever it is — that carries
    // more than one price. With no scenario chosen there is nothing to
    // report. Picking variants then narrows those names (and so the
    // total) to what was picked; fees with a single price are untouched.
    let selectedVariantKeys = [];
    if (fee_variants) {
      try {
        const parsed = JSON.parse(fee_variants);
        if (Array.isArray(parsed)) selectedVariantKeys = parsed.filter((k) => typeof k === 'string');
      } catch { /* malformed value — ignore it rather than failing the whole list */ }
    }

    const baseRows = applies_to
      ? await FeeStructure.findAll({ where, attributes: ['id', 'name', 'amount', 'frequency', 'billing_cycles'] })
      : [];
    const variantsByName = new Map();
    baseRows.forEach((s) => {
      const nameKey = feeNameKey(s.name);
      const key = feeVariantKey(s);
      // One display name per group (the first spelling seen), so "Transport
      // Fee" and "transport fee" don't show up as two differently-named
      // options.
      if (!variantsByName.has(nameKey)) variantsByName.set(nameKey, { displayName: s.name.trim(), variants: new Map() });
      const { displayName, variants: group } = variantsByName.get(nameKey);
      if (!group.has(key)) {
        group.set(key, {
          key, name: displayName, amount: toNum(s.amount), frequency: s.frequency,
          billing_cycles: billingCycles(s), annual_amount: annualizedAmount(s), count: 0,
        });
      }
      group.get(key).count += 1;
    });

    const variants = [];
    variantsByName.forEach(({ variants: group }) => {
      if (group.size > 1) variants.push(...[...group.values()].sort((a, b) => a.annual_amount - b.annual_amount));
    });
    variants.sort((a, b) => feeNameKey(a.name).localeCompare(feeNameKey(b.name)) || a.annual_amount - b.annual_amount);

    if (selectedVariantKeys.length > 0) {
      const picked = new Set(selectedVariantKeys);
      // Names that actually have a pick made on them — a stale key that
      // matches nothing (e.g. left over from another class) must not
      // hide every fee of that name.
      const namesWithPick = new Set(variants.filter((v) => picked.has(v.key)).map((v) => feeNameKey(v.name)));
      const excludedIds = baseRows
        .filter((s) => namesWithPick.has(feeNameKey(s.name)) && !picked.has(feeVariantKey(s)))
        .map((s) => s.id);
      if (excludedIds.length > 0) where.id = { [Op.notIn]: excludedIds };
    }

    const { count, rows } = await FeeStructure.findAndCountAll({
      where,
      include: [
        { model: Class, as: 'class', attributes: ['id', 'name', 'grade'] },
        { model: Campus, as: 'campus', attributes: ['id', 'name'] },
      ],
      limit: parseInt(limit), offset: parseInt(offset),
      order: [['name', 'ASC']],
      distinct: true,
    });

    const allMatching = await FeeStructure.findAll({ where, attributes: ['name', 'amount', 'frequency', 'billing_cycles', 'status'] });
    const maxAnnualByName = new Map();
    allMatching.forEach((s) => {
      const key = s.name.trim().toLowerCase();
      const annual = annualizedAmount(s);
      if (!maxAnnualByName.has(key) || annual > maxAnnualByName.get(key)) maxAnnualByName.set(key, annual);
    });
    const totalAmount = [...maxAnnualByName.values()].reduce((sum, v) => sum + v, 0);
    const activeCount = allMatching.filter((s) => s.status === 'active').length;

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
      summary: { total_amount: totalAmount, active_count: activeCount, total_count: allMatching.length },
      variants,
    });
  } catch (error) { next(error); }
};

export const createFeeStructure = async (req, res, next) => {
  try {
    const { campus_id, class_id, name, amount, frequency, billing_cycles, applies_to, academic_year, status } = req.body;
    if (!campus_id || !class_id || !name || !amount || !academic_year) {
      return res.status(400).json({ success: false, message: 'campus_id, class_id, name, amount and academic_year are required' });
    }
    if (Number(amount) <= 0) return res.status(400).json({ success: false, message: 'amount must be greater than 0' });
    if (billing_cycles !== undefined && billing_cycles !== null && billing_cycles !== '' && Number(billing_cycles) <= 0) {
      return res.status(400).json({ success: false, message: 'billing_cycles must be greater than 0' });
    }
    const structure = await FeeStructure.create({
      tenant_id: req.tenantId, campus_id, class_id, name, amount,
      frequency: frequency || 'one_time', billing_cycles: billing_cycles || null,
      applies_to: applies_to || 'all', academic_year, status: status || 'active',
    });
    res.status(201).json({ success: true, message: 'Fee structure created', data: structure });
  } catch (error) { next(error); }
};

export const updateFeeStructure = async (req, res, next) => {
  try {
    const structure = await FeeStructure.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!structure) return res.status(404).json({ success: false, message: 'Fee structure not found' });
    const { campus_id, class_id, name, amount, frequency, billing_cycles, applies_to, academic_year, status } = req.body;
    if (amount !== undefined && Number(amount) <= 0) return res.status(400).json({ success: false, message: 'amount must be greater than 0' });
    if (billing_cycles !== undefined && billing_cycles !== null && billing_cycles !== '' && Number(billing_cycles) <= 0) {
      return res.status(400).json({ success: false, message: 'billing_cycles must be greater than 0' });
    }
    await structure.update({
      ...(campus_id !== undefined && { campus_id }),
      ...(class_id !== undefined && { class_id }),
      ...(name !== undefined && { name }),
      ...(amount !== undefined && { amount }),
      ...(frequency !== undefined && { frequency }),
      ...(billing_cycles !== undefined && { billing_cycles: billing_cycles || null }),
      ...(applies_to !== undefined && { applies_to: applies_to || 'all' }),
      ...(academic_year !== undefined && { academic_year }),
      ...(status !== undefined && { status }),
    });
    res.json({ success: true, message: 'Fee structure updated', data: structure });
  } catch (error) { next(error); }
};

export const deleteFeeStructure = async (req, res, next) => {
  try {
    const structure = await FeeStructure.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!structure) return res.status(404).json({ success: false, message: 'Fee structure not found' });
    const paymentCount = await Payment.count({ where: { fee_structure_id: structure.id } });
    if (paymentCount > 0) {
      return res.status(400).json({ success: false, message: `Cannot delete — ${paymentCount} payment(s) are already recorded against this fee. Deactivate it instead.` });
    }
    await structure.destroy();
    res.json({ success: true, message: 'Fee structure deleted' });
  } catch (error) { next(error); }
};

/** GET /fee-structures/:id/students
 *
 * For a 'selected_students' fee structure: every student currently
 * enrolled in that structure's class, each flagged with whether they're
 * one of the ones hand-picked for this particular fee — everything the
 * "Assign Students" checklist needs in one call, rather than the
 * frontend fetching the roster and the assignments separately and
 * reconciling them itself. */
export const getFeeStructureStudents = async (req, res, next) => {
  try {
    const structure = await FeeStructure.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!structure) return res.status(404).json({ success: false, message: 'Fee structure not found' });

    // The roster for the structure's own class — resolved the same way
    // Fee Status resolves a class roster for any year, so a structure
    // written against a past year's class still lists the right
    // students even after some have since moved on. See
    // utils/classRoster.js.
    const { students: roster } = await findStudentsEnrolledInClass({
      tenantId: req.tenantId, classId: structure.class_id,
    });

    const assignments = await FeeStructureStudent.findAll({
      where: { tenant_id: req.tenantId, fee_structure_id: structure.id },
      attributes: ['student_id'],
    });
    const selectedIds = new Set(assignments.map((a) => a.student_id));

    const students = roster
      .map((s) => ({
        id: s.id,
        admission_number: s.admission_number,
        name: `${s.user?.first_name || ''} ${s.user?.last_name || ''}`.trim(),
        section: s.section?.name || null,
        selected: selectedIds.has(s.id),
      }))
      .sort((a, b) => (a.admission_number || '').localeCompare(b.admission_number || ''));

    res.json({
      success: true,
      data: { fee_structure: { id: structure.id, name: structure.name, amount: structure.amount, applies_to: structure.applies_to }, students },
    });
  } catch (error) { next(error); }
};

/** PUT /fee-structures/:id/students — body: { student_ids: [...] }
 *
 * Replaces the WHOLE selected set for this structure with exactly the
 * ids given — the checklist UI always submits its full current state
 * (every box, checked or not), so a full replace is simpler and safer
 * than trying to diff "what changed" client-side and risking a stale
 * partial update. Anyone dropped from the list stops being charged for
 * this fee from that point on; anyone newly added starts owing it —
 * same as ticking/unticking their box would suggest happens. */
export const setFeeStructureStudents = async (req, res, next) => {
  const transaction = await sequelize.transaction();
  try {
    const structure = await FeeStructure.findOne({ where: { id: req.params.id, tenant_id: req.tenantId }, transaction });
    if (!structure) {
      await transaction.rollback();
      return res.status(404).json({ success: false, message: 'Fee structure not found' });
    }
    if (structure.applies_to !== 'selected_students') {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'This fee structure\'s "Applies To" is not set to "Selected Students" — change that first, then assign students.',
      });
    }

    const studentIds = Array.isArray(req.body.student_ids) ? [...new Set(req.body.student_ids)] : [];
    if (studentIds.length > 0) {
      const validCount = await Student.count({ where: { id: studentIds, tenant_id: req.tenantId }, transaction });
      if (validCount !== studentIds.length) {
        await transaction.rollback();
        return res.status(400).json({ success: false, message: 'One or more selected students could not be found.' });
      }
    }

    await FeeStructureStudent.destroy({ where: { tenant_id: req.tenantId, fee_structure_id: structure.id }, transaction });
    if (studentIds.length > 0) {
      await FeeStructureStudent.bulkCreate(
        studentIds.map((student_id) => ({ tenant_id: req.tenantId, fee_structure_id: structure.id, student_id, assigned_by: req.user.id })),
        { transaction },
      );
    }

    await transaction.commit();
    res.json({ success: true, message: `${structure.name} now applies to ${studentIds.length} student(s)`, data: { count: studentIds.length } });
  } catch (error) {
    await transaction.rollback();
    next(error);
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// PAYMENTS
// ═══════════════════════════════════════════════════════════════════════════

export const getPayments = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, student_id = '', status = '', date_from = '', date_to = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (student_id) where.student_id = student_id;
    if (status) where.status = status;
    if (date_from || date_to) {
      where.payment_date = {};
      if (date_from) where.payment_date[Op.gte] = date_from;
      if (date_to) where.payment_date[Op.lte] = date_to;
    }

    const { count, rows } = await Payment.findAndCountAll({
      where,
      include: [
        { model: Student, as: 'student', attributes: ['id', 'admission_number', 'class_id', 'section_id'], include: [{ model: User, as: 'user', attributes: ['first_name', 'last_name'] }] },
        { model: FeeStructure, as: 'feeStructure', attributes: ['id', 'name'] },
        { model: User, as: 'receivedBy', attributes: ['id', 'first_name', 'last_name'] },
      ],
      limit: parseInt(limit), offset: parseInt(offset),
      order: [['payment_date', 'DESC'], ['created_at', 'DESC']],
      distinct: true,
    });

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

/** Computes and persists a payment's receipt snapshot.
 *
 * Shared by createPayment (at issue) and getPaymentById (lazily, for
 * payments recorded before snapshots existed) so both paths produce an
 * identical receipt. Returns the snapshot, or null when the student has no
 * class/academic year to bill against.
 *
 * Never throws: a receipt failing to freeze must not fail the payment
 * itself — the money has already changed hands.
 */
const snapshotReceipt = async (tenantId, payment) => {
  try {
    const student = await Student.findByPk(payment.student_id, { attributes: ['id', 'class_id', 'transport_required', 'hostel_required'] });
    const cls = student?.class_id ? await Class.findByPk(student.class_id, { attributes: ['academic_year'] }) : null;
    if (!student || !cls?.academic_year) return null;

    const { structures } = await expectedForStudent(tenantId, student, cls.academic_year);
    const payments = await Payment.findAll({
      where: { tenant_id: tenantId, student_id: student.id, status: 'completed' },
      order: [['payment_date', 'ASC'], ['created_at', 'ASC']],
    });

    const snapshot = buildReceiptSnapshot({ structures, payments, payment });
    await payment.update({ receipt_snapshot: snapshot });
    return snapshot;
  } catch {
    return null;
  }
};

/** POST /fees/payments
 *
 * Accepts EITHER shape:
 *   - single item / general:  { fee_structure_id?, amount }
 *   - several items at once:  { items: [{ fee_structure_id, amount }, ...] }
 *
 * The `items` form settles multiple fee items in one go so the parent
 * gets ONE receipt listing everything they just paid for, rather than a
 * separate receipt per item. The single-item form is untouched, so
 * existing callers keep working exactly as before.
 */
export const createPayment = async (req, res, next) => {
  try {
    const { student_id, fee_structure_id, amount, items, payment_method, payment_date, transaction_id, remarks, status } = req.body;
    if (!student_id || !payment_method || !payment_date) {
      return res.status(400).json({ success: false, message: 'student_id, payment_method and payment_date are required' });
    }

    const student = await Student.findOne({ where: { id: student_id, tenant_id: req.tenantId } });
    if (!student) return res.status(404).json({ success: false, message: 'Student not found' });

    // ── Normalize both request shapes into a single `lineItems` list ──
    // A line can target a class fee structure OR a one-off student charge
    // (a lost library book, say) — both are things the student owes.
    const hasItems = Array.isArray(items) && items.length > 0;
    const lineItems = hasItems
      ? items.filter((i) => i && (i.fee_structure_id || i.charge_id))
      : (fee_structure_id ? [{ fee_structure_id, amount }] : []);

    if (hasItems && lineItems.length === 0) {
      return res.status(400).json({ success: false, message: 'Each item needs a fee_structure_id or charge_id' });
    }
    if (hasItems && lineItems.some((i) => !(Number(i.amount) > 0))) {
      return res.status(400).json({ success: false, message: 'Every fee item must have an amount greater than 0' });
    }
    // Paying the same item twice in one payment is almost certainly a UI
    // slip; silently merging them would make the receipt disagree with what
    // the user actually entered, so reject it outright.
    const uniqueIds = new Set(lineItems.map(allocationKey));
    if (uniqueIds.size !== lineItems.length) {
      return res.status(400).json({ success: false, message: 'The same fee item was included more than once' });
    }

    // Everything referenced must exist and belong to this tenant.
    const structureIds = lineItems.filter((i) => i.fee_structure_id).map((i) => i.fee_structure_id);
    const chargeIds = lineItems.filter((i) => !i.fee_structure_id && i.charge_id).map((i) => i.charge_id);

    const [structures, charges] = await Promise.all([
      structureIds.length ? FeeStructure.findAll({ where: { id: structureIds, tenant_id: req.tenantId } }) : [],
      chargeIds.length ? StudentCharge.findAll({ where: { id: chargeIds, tenant_id: req.tenantId, student_id } }) : [],
    ]);
    if (structures.length !== new Set(structureIds).size) {
      return res.status(404).json({ success: false, message: 'Fee structure not found' });
    }
    // Scoped to this student on purpose — a charge belongs to one student,
    // so paying another student's charge is never valid.
    if (charges.length !== new Set(chargeIds).size) {
      return res.status(404).json({ success: false, message: 'Charge not found for this student' });
    }

    const lineName = (i) => (i.fee_structure_id
      ? structures.find((x) => x.id === i.fee_structure_id)?.name
      : charges.find((c) => c.id === i.charge_id)?.description) || null;

    // The stored `amount` is always the sum of the line items, so the
    // receipt total can never drift from its own breakdown. A general
    // payment (no items at all) falls back to the posted amount.
    const total = hasItems
      ? lineItems.reduce((sum, i) => sum + toNum(i.amount), 0)
      : toNum(amount);
    if (!(total > 0)) return res.status(400).json({ success: false, message: 'amount must be greater than 0' });

    // `fee_structure_id` has a foreign key into fee_structures, so it can
    // only ever hold a real structure. Anything else — several items at
    // once, or a single student charge — is carried in `allocations`.
    const singleStructure = lineItems.length === 1 && lineItems[0].fee_structure_id;
    const needsAllocations = lineItems.length > 1 || (lineItems.length === 1 && !singleStructure);

    const allocations = needsAllocations
      ? lineItems.map((i) => ({
          fee_structure_id: i.fee_structure_id || null,
          charge_id: i.fee_structure_id ? null : (i.charge_id || null),
          name: lineName(i),
          amount: toNum(i.amount),
        }))
      : null;

    const payment = await Payment.create({
      tenant_id: req.tenantId, student_id,
      fee_structure_id: singleStructure ? lineItems[0].fee_structure_id : null,
      allocations,
      amount: total, payment_method, payment_date, transaction_id: transaction_id || null,
      remarks: remarks || null, status: status || 'completed', received_by: req.user.id,
    });

    // Freeze the receipt as it stands right now. Doing this at payment time
    // (rather than recomputing on every print) is what makes a reprint show
    // the balance that was owed THEN — and stops a later edit to a fee
    // structure rewriting the history of a receipt already handed out.
    await snapshotReceipt(req.tenantId, payment);

    const full = await Payment.findOne({
      where: { id: payment.id },
      include: [
        { model: Student, as: 'student', attributes: ['id', 'admission_number'], include: [{ model: User, as: 'user', attributes: ['first_name', 'last_name', 'phone'] }] },
        { model: FeeStructure, as: 'feeStructure', attributes: ['id', 'name'] },
        { model: User, as: 'receivedBy', attributes: ['id', 'first_name', 'last_name'] },
      ],
    });

    // The parent gets their copy; the finance office gets theirs. Only the
    // parent was ever notified, so an accountant's bell stayed empty even
    // as money came in all day.
    const fmtMoney = await moneyFormatterFor(req.tenantId);
    // One event, two parties (Settings → Notifications decides who is told and how). The family is reached on the PARENT's phone
    // and email (falling back to what the admission form recorded), not the student's.
    const family = (await familyContactsFor(req.tenantId, [student.id])).get(student.id);
    await notifyEvent(req.tenantId, 'payment_recorded', {
      parties: {
        staff: { title: 'Payment Received', message: `${fmtMoney(total)} received from ${full.student?.user?.first_name || ''} ${full.student?.user?.last_name || ''}`.trim() + ` (${full.student?.admission_number || 'student'}).` },
        family: {
          recipientUserId: family?.userId || student.parent_id || student.user_id,
          smsPhone: family?.phone || null, emailTo: family?.email || null,
          title: 'Payment Received',
          message: `A payment of ${fmtMoney(total)} was recorded for ${full.student?.user?.first_name || 'your child'} ${full.student?.user?.last_name || ''}.`.trim(),
        },
      },
    });

    res.status(201).json({ success: true, message: 'Payment recorded', data: full });
  } catch (error) { next(error); }
};

export const getPaymentById = async (req, res, next) => {
  try {
    const payment = await Payment.findOne({
      where: { id: req.params.id, tenant_id: req.tenantId },
      include: [
        {
          model: Student, as: 'student',
          attributes: ['id', 'admission_number', 'class_id', 'section_id'],
          include: [
            { model: User, as: 'user', attributes: ['first_name', 'last_name'] },
            { model: Class, as: 'class', attributes: ['id', 'name', 'grade'] },
            { model: Section, as: 'section', attributes: ['id', 'name'] },
          ],
        },
        { model: FeeStructure, as: 'feeStructure', attributes: ['id', 'name', 'amount'] },
        { model: User, as: 'receivedBy', attributes: ['id', 'first_name', 'last_name'] },
      ],
    });
    if (!payment) return res.status(404).json({ success: false, message: 'Payment not found' });

    // Same access rule as exam report cards: staff, the student themself, or their parent.
    const isStaffViewer = await can(req.user, req.tenantId, 'fees.view');
    const isOwnRecord = payment.student?.user_id === req.user.id;
    if (!isStaffViewer && !isOwnRecord && payment.student) {
      const studentRow = await Student.findByPk(payment.student.id);
      if (studentRow?.parent_id !== req.user.id) {
        return res.status(403).json({ success: false, message: 'You are not allowed to view this receipt' });
      }
    }

    // A receipt is a financial record, so it's read from the snapshot frozen
    // when the payment was taken — NOT recomputed against today's figures.
    // Recomputing is what made yesterday's receipt and last term's both
    // print the current balance.
    //
    // Payments recorded before snapshots existed have none, so one is
    // reconstructed from the payment history up to that point and saved,
    // which freezes those older receipts from this moment on too.
    const snapshot = payment.receipt_snapshot || await snapshotReceipt(req.tenantId, payment);

    res.json({
      success: true,
      data: {
        ...payment.toJSON(),
        balance: snapshot?.balance ?? null,
        extra: snapshot?.extra ?? 0,
        fee_checklist: snapshot?.fee_checklist || [],
        receipt_snapshot: snapshot,
        verification_code: generateVerificationCode(payment),
      },
    });
  } catch (error) { next(error); }
};

export const deletePayment = async (req, res, next) => {
  try {
    const payment = await Payment.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!payment) return res.status(404).json({ success: false, message: 'Payment not found' });
    await payment.destroy();
    res.json({ success: true, message: 'Payment deleted' });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// FEE STATUS (per-student and per-class balance)
// ═══════════════════════════════════════════════════════════════════════════

/** GET /fees/student/:studentId/summary?academic_year=
 * Expected (sum of active fee structures for the student's class), total
 * paid, balance, and their full payment history. */
export const getStudentFeeSummary = async (req, res, next) => {
  try {
    const student = await Student.findOne({
      where: { id: req.params.studentId, tenant_id: req.tenantId },
      include: [
        { model: User, as: 'user', attributes: ['id', 'first_name', 'last_name'] },
        { model: Class, as: 'class', attributes: ['id', 'name', 'grade', 'academic_year'] },
        { model: Section, as: 'section', attributes: ['id', 'name'] },
      ],
    });
    if (!student) return res.status(404).json({ success: false, message: 'Student not found' });

    const isStaffViewer = await can(req.user, req.tenantId, 'fees.view');
    const isOwnRecord = student.user_id === req.user.id;
    const isParentOfStudent = student.parent_id === req.user.id;
    if (!isStaffViewer && !isOwnRecord && !isParentOfStudent) {
      return res.status(403).json({ success: false, message: 'You are not allowed to view this fee summary' });
    }

    const academicYear = req.query.academic_year || student.class?.academic_year;
    const { structures, total: expected } = await expectedForStudent(req.tenantId, student, academicYear);

    const payments = await Payment.findAll({
      where: { tenant_id: req.tenantId, student_id: student.id, status: 'completed' },
      include: [{ model: FeeStructure, as: 'feeStructure', attributes: ['id', 'name'] }],
      order: [['payment_date', 'DESC']],
    });
    const paid = payments.reduce((sum, p) => sum + toNum(p.amount), 0);
    const { balance, extra } = splitPaidAgainstExpected(expected, paid);

    // How much has already gone against each individual fee item, so the
    // Record Payment screen can pre-fill what's still outstanding per item
    // instead of always re-proposing the full annual charge.
    const paidByStructure = paidPerStructure(payments, structures);

    // Unpaid balances from EARLIER academic years — surfaced separately
    // (never folded into `balance` above) so the amount owed for THIS
    // year and old carried-forward debt are never confused with each
    // other, while still adding up to the true total the student owes.
    const arrears = await arrearsForStudent(req.tenantId, student, academicYear);

    res.json({
      success: true,
      data: {
        student: {
          id: student.id, admission_number: student.admission_number,
          name: `${student.user?.first_name || ''} ${student.user?.last_name || ''}`.trim(),
          class: student.class?.name, section: student.section?.name,
        },
        academic_year: academicYear,
        fee_items: structures.map((s) => {
          const annual = annualizedAmount(s);
          const paidForItem = paidByStructure[s.id] || 0;
          return {
            id: s.id, name: s.name, amount: Number(s.amount), frequency: s.frequency,
            billing_cycles: billingCycles(s), annual_amount: annual,
            paid: paidForItem,
            // Never negative — an overpayment on one item shouldn't show
            // as a credit that the payment form would then try to bill.
            outstanding: Math.max(0, Math.round((annual - paidForItem) * 100) / 100),
            // Lets the payment form label a personal charge for what it is
            // rather than showing it as an ordinary class fee.
            is_charge: s.is_charge === true,
            charge_category: s.charge_category || null,
            // True when this amount came from the student's OWN transport/
            // hostel allocation (a personalized route/room fee) rather
            // than the flat class-wide rate — lets the UI show a "Custom"
            // note so it's never mistaken for a pricing error.
            is_override: s.is_override === true,
          };
        }),
        expected, paid, balance, extra,
        previous_years_arrears: arrears,
        // What this student truly owes right now, across every year —
        // the number a receptionist or parent actually needs when asked
        // "how much do we still owe in total".
        total_owed: Math.round((balance + arrears.total) * 100) / 100,
        payments,
      },
    });
  } catch (error) { next(error); }
};

/** GET /fees/class-status?class_id=&section_id=&academic_year=
 * One row per student: expected, paid, balance, status — the fee
 * equivalent of the exam Class Results matrix. */
export const getClassFeeStatus = async (req, res, next) => {
  try {
    const { class_id, section_id, academic_year, service_filter } = req.query;
    if (!class_id || !academic_year) {
      return res.status(400).json({ success: false, message: 'class_id and academic_year are required' });
    }

    const structures = await feeStructuresForClass(req.tenantId, class_id, academic_year);

    // Roster resolved for THIS class's own year — not a plain "who is
    // currently in class_id" — so a class from a past year still shows
    // the right students even after they've since been promoted on.
    // See utils/classRoster.js.
    const { targetClass, students: rosterStudents } = await findStudentsEnrolledInClass({
      tenantId: req.tenantId, classId: class_id, sectionId: section_id || null,
    });
    if (!targetClass) {
      return res.status(404).json({ success: false, message: 'Class not found' });
    }
    const students = rosterStudents.sort((a, b) => (a.admission_number || '').localeCompare(b.admission_number || ''));
    const studentIds = students.map((s) => s.id);

    // Batch-fetch who's actually opted into transport/hostel — and their
    // own personalized fee if their allocation has one — plus who was
    // hand-picked for any 'selected_students' structure in this class,
    // rather than one query per student, so a class of 40 doesn't mean
    // 80+ extra round-trips just to price these correctly.
    const selectedStudentStructureIds = structures.filter((s) => s.applies_to === 'selected_students').map((s) => s.id);
    const [transportAllocs, hostelAllocs, payments, structureAssignments] = await Promise.all([
      TransportAllocation.findAll({ where: { tenant_id: req.tenantId, student_id: studentIds, status: 'active' }, attributes: ['student_id', 'fee'] }),
      HostelAllocation.findAll({ where: { tenant_id: req.tenantId, student_id: studentIds, status: 'active' }, attributes: ['student_id', 'fee'] }),
      Payment.findAll({ where: { tenant_id: req.tenantId, student_id: studentIds, status: 'completed' } }),
      selectedStudentStructureIds.length > 0
        ? FeeStructureStudent.findAll({ where: { tenant_id: req.tenantId, fee_structure_id: selectedStudentStructureIds, student_id: studentIds }, attributes: ['student_id', 'fee_structure_id'] })
        : Promise.resolve([]),
    ]);
    const transportFeeByStudent = new Map(transportAllocs.map((a) => [a.student_id, a.fee]));
    const hostelFeeByStudent = new Map(hostelAllocs.map((a) => [a.student_id, a.fee]));
    const transportStudentIds = new Set(transportAllocs.map((a) => a.student_id));
    const hostelStudentIds = new Set(hostelAllocs.map((a) => a.student_id));
    const selectedStructureIdsByStudent = new Map();
    structureAssignments.forEach((a) => {
      if (!selectedStructureIdsByStudent.has(a.student_id)) selectedStructureIdsByStudent.set(a.student_id, new Set());
      selectedStructureIdsByStudent.get(a.student_id).add(a.fee_structure_id);
    });
    const paidByStudent = {};
    payments.forEach((p) => { paidByStudent[p.student_id] = (paidByStudent[p.student_id] || 0) + toNum(p.amount); });

    // Optional narrowing by which services a student actually uses — e.g.
    // "how much do students who use neither transport nor hostel owe in
    // total?" vs. students using one or both.
    const matchesServiceFilter = (student) => {
      if (!service_filter) return true;
      const usesTransport = usesOptionalService(student, transportStudentIds.has(student.id), 'transport_required');
      const usesHostel = usesOptionalService(student, hostelStudentIds.has(student.id), 'hostel_required');
      switch (service_filter) {
        case 'none': return !usesTransport && !usesHostel;
        case 'transport_only': return usesTransport && !usesHostel;
        case 'hostel_only': return usesHostel && !usesTransport;
        case 'both': return usesTransport && usesHostel;
        default: return true;
      }
    };

    const rows = students.filter((s) => matchesServiceFilter(s)).map((s) => {
      const usesTransport = usesOptionalService(s, transportStudentIds.has(s.id), 'transport_required');
      const usesHostel = usesOptionalService(s, hostelStudentIds.has(s.id), 'hostel_required');
      const applicable = applicableStructures(structures, {
        usesTransport, usesHostel,
        transportFee: transportFeeByStudent.get(s.id) ?? null,
        hostelFee: hostelFeeByStudent.get(s.id) ?? null,
        selectedStructureIds: selectedStructureIdsByStudent.get(s.id),
      });
      const expected = applicable.reduce((sum, st) => sum + annualizedAmount(st), 0);
      const paid = paidByStudent[s.id] || 0;
      const { balance, extra } = splitPaidAgainstExpected(expected, paid);
      return {
        student_id: s.id,
        admission_number: s.admission_number,
        name: `${s.user?.first_name || ''} ${s.user?.last_name || ''}`.trim(),
        expected, paid: Math.round(paid * 100) / 100, balance, extra,
        payment_status: expected === 0 ? 'n/a' : balance <= 0.5 ? 'paid' : paid > 0 ? 'partial' : 'unpaid',
      };
    });

    // Outstanding sums only real shortfalls — an overpaying student must
    // never mask a defaulting one, which is exactly what happens if their
    // negative balance is allowed into the total. Collected, by contrast,
    // counts every shilling actually received, overpayment included.
    const totals = rows.reduce((acc, r) => ({
      expected: acc.expected + r.expected,
      paid: acc.paid + r.paid,
      balance: acc.balance + r.balance,
      extra: acc.extra + r.extra,
    }), { expected: 0, paid: 0, balance: 0, extra: 0 });

    res.json({ success: true, data: { students: rows, totals } });
  } catch (error) { next(error); }
};

/** GET /fees/my-children — for a logged-in parent: fee summary for each linked child. */
export const getMyChildrenFees = async (req, res, next) => {
  try {
    const children = await Student.findAll({
      where: { tenant_id: req.tenantId, parent_id: req.user.id, status: 'active' },
      include: [
        { model: User, as: 'user', attributes: ['id', 'first_name', 'last_name'] },
        { model: Class, as: 'class', attributes: ['id', 'name', 'grade', 'academic_year'] },
        { model: Section, as: 'section', attributes: ['id', 'name'] },
      ],
    });

    const data = [];
    for (const child of children) {
      const { total: expected } = await expectedForStudent(req.tenantId, child, child.class?.academic_year);
      const payments = await Payment.findAll({ where: { tenant_id: req.tenantId, student_id: child.id, status: 'completed' } });
      const paid = payments.reduce((sum, p) => sum + toNum(p.amount), 0);
      const { balance } = splitPaidAgainstExpected(expected, paid);
      const arrears = await arrearsForStudent(req.tenantId, child, child.class?.academic_year);
      data.push({
        student_id: child.id, admission_number: child.admission_number,
        name: `${child.user?.first_name || ''} ${child.user?.last_name || ''}`.trim(),
        class: child.class?.name, section: child.section?.name,
        expected, paid: Math.round(paid * 100) / 100,
        ...splitPaidAgainstExpected(expected, paid),
        // A parent's dashboard row needs the "there is old debt too" flag
        // without the full per-item breakdown — that detail is one click
        // away on this child's own Fee Summary page.
        arrears_total: arrears.total,
        total_owed: Math.round((balance + arrears.total) * 100) / 100,
      });
    }

    res.json({ success: true, data });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// RECEIPT VERIFICATION (public — no login required)
// ═══════════════════════════════════════════════════════════════════════════

const PAYMENT_INCLUDE_FOR_VERIFY = [
  {
    model: Student, as: 'student', attributes: ['admission_number'],
    include: [
      { model: User, as: 'user', attributes: ['first_name', 'last_name'] },
      { model: Class, as: 'class', attributes: ['name'] },
    ],
  },
  { model: Tenant, as: 'tenant', attributes: ['name'] },
];

/** Shape returned for a successfully-verified receipt — deliberately
 * limited to what's needed to confirm authenticity (school, student,
 * amount, date), not the student's full record. */
const verifiedSummary = (payment) => ({
  valid: true,
  receipt_no: `RCT-${payment.id.slice(0, 8).toUpperCase()}`,
  school: payment.tenant?.name || null,
  student_name: `${payment.student?.user?.first_name || ''} ${payment.student?.user?.last_name || ''}`.trim(),
  admission_number: payment.student?.admission_number || null,
  class_name: payment.student?.class?.name || null,
  amount: Number(payment.amount),
  payment_date: payment.payment_date,
  payment_method: payment.payment_method,
  status: payment.status,
});

/** GET /fees/verify/:paymentId/:code — the QR-code flow: the receipt's QR
 * encodes the exact payment id + its verification code, so this is a
 * direct, unambiguous lookup. */
export const verifyReceiptById = async (req, res, next) => {
  try {
    const { paymentId, code } = req.params;
    const payment = await Payment.findByPk(paymentId, { include: PAYMENT_INCLUDE_FOR_VERIFY });
    if (!payment || !isValidVerificationCode(payment, code)) {
      return res.json({ success: true, data: { valid: false } });
    }
    res.json({ success: true, data: verifiedSummary(payment) });
  } catch (error) { next(error); }
};

/** GET /fees/verify?receipt_no=RCT-XXXXXXXX&code=YYYYYYYYYY — the manual
 * flow, for someone typing in what's printed on a physical/scanned copy
 * instead of scanning the QR. `receipt_no` is only the first 8 hex
 * characters of the payment's id (that's all that's printed), so this
 * matches by prefix — a collision on the prefix alone is astronomically
 * unlikely, and even then the HMAC code additionally has to match that
 * exact row's own details, so a wrong match still can't pass. */
export const verifyReceiptByCode = async (req, res, next) => {
  try {
    const { receipt_no = '', code = '' } = req.query;
    const prefix = String(receipt_no).replace(/^RCT-/i, '').trim().toLowerCase();
    if (!/^[0-9a-f]{6,8}$/.test(prefix) || !code) {
      return res.json({ success: true, data: { valid: false } });
    }
    const payment = await Payment.findOne({
      where: sequelizeWhere(cast(col('Payment.id'), 'text'), { [Op.iLike]: `${prefix}%` }),
      include: PAYMENT_INCLUDE_FOR_VERIFY,
    });
    if (!payment || !isValidVerificationCode(payment, code)) {
      return res.json({ success: true, data: { valid: false } });
    }
    res.json({ success: true, data: verifiedSummary(payment) });
  } catch (error) { next(error); }
};

/**
 * Public — no login required, called from the tenant's website (see
 * routes/publicRoutes.js). Read-only: exposes only what a prospective
 * family needs to see (class, fee names, amounts, frequency) — nothing
 * about who's actually paid what. Grouped by class with an annualized
 * total per class so the site can show something like the old
 * "Registration / Tuition per Term / Tuition per Year" table, but built
 * from whatever fee items the school has actually configured rather
 * than a fixed set of hardcoded columns.
 */
export const getPublicFeeStructure = async (req, res, next) => {
  try {
    const tenant = await Tenant.findOne({ where: { slug: req.params.tenantSlug } });
    if (!tenant) {
      return res.status(404).json({ success: false, message: 'Fee structure is not available.' });
    }

    let academicYear = req.query.academic_year || String(currentBaseYear());
    const loadStructures = (year) => FeeStructure.findAll({
      // Class also has an academic_year column, so the filter column
      // must be qualified — otherwise Postgres can't tell which table's
      // academic_year the LEFT(...) comparison means once the join below
      // is in the query ("column reference academic_year is ambiguous").
      where: applyAcademicYearFilter({ tenant_id: tenant.id, status: 'active', applies_to: 'all' }, year, 'FeeStructure.academic_year'),
      include: [{ model: Class, as: 'class', attributes: ['id', 'name', 'grade'] }],
      order: [['name', 'ASC']],
    });
    let structures = await loadStructures(academicYear);

    // The website asks for "now" without naming a year. Before the new year's fees are entered that is an empty
    // page, so show the most recent year that does have published fees (the response says which year it is).
    if (structures.length === 0 && !req.query.academic_year) {
      const latest = await FeeStructure.findOne({
        where: { tenant_id: tenant.id, status: 'active', applies_to: 'all' },
        attributes: ['academic_year'], order: [['academic_year', 'DESC']],
      });
      if (latest && latest.academic_year && latest.academic_year !== academicYear) {
        academicYear = latest.academic_year;
        structures = await loadStructures(academicYear);
      }
    }

    const byClass = new Map();
    for (const s of structures) {
      const classId = s.class?.id || 'unassigned';
      if (!byClass.has(classId)) {
        byClass.set(classId, { class_name: s.class?.name || 'General', grade: s.class?.grade || null, items: [], annual_total: 0 });
      }
      const bucket = byClass.get(classId);
      const annual = annualizedAmount(s);
      bucket.items.push({ name: s.name, amount: toNum(s.amount), frequency: s.frequency, annual_amount: annual });
      bucket.annual_total += annual;
    }

    // Sort classes into a sensible teaching order — grade first (numbers
    // sort naturally even as strings for the common "1".."7" case), then
    // name as a tiebreaker for classes sharing a grade label.
    const data = [...byClass.values()].sort((a, b) => {
      const gradeCompare = (a.grade || '').localeCompare(b.grade || '', undefined, { numeric: true });
      return gradeCompare !== 0 ? gradeCompare : a.class_name.localeCompare(b.class_name);
    });

    res.json({ success: true, academic_year: academicYear, data });
  } catch (error) { next(error); }
};