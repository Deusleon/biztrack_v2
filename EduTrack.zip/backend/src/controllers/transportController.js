// backend/src/controllers/transportController.js
import { Op, fn, col } from 'sequelize';
import { extractBaseYear } from '../utils/academicYear.js';
import { resolveStudentClassForYear } from '../utils/classRoster.js';
import { Route, TransportAllocation, Student, User, Class, Section, Vehicle } from '../models/index.js';
import { normalizePhone } from '../utils/phone.js';
import { isOwnStudentRecord, SELF_SERVICE_ROLES } from '../middleware/access.js';

// ═══════════════════════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════════════════════

export const getRoutes = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, search = '', status = '', campus_id = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (status) where.status = status;
    if (campus_id) where.campus_id = campus_id;
    if (search) {
      where[Op.or] = [
        { name: { [Op.iLike]: `%${search}%` } },
        { route_number: { [Op.iLike]: `%${search}%` } },
        { driver_name: { [Op.iLike]: `%${search}%` } },
        { vehicle_number: { [Op.iLike]: `%${search}%` } },
      ];
    }

    const { count, rows } = await Route.findAndCountAll({
      where,
      include: [{ model: Vehicle, as: 'vehicle', attributes: ['id', 'registration_number', 'photo_url'] }],
      limit: parseInt(limit), offset: parseInt(offset),
      order: [['name', 'ASC']],
    });

    // Occupancy per route — how many active allocations vs capacity.
    const routeIds = rows.map((r) => r.id);
    const counts = routeIds.length > 0
      ? await TransportAllocation.findAll({
          where: { tenant_id: req.tenantId, route_id: routeIds, status: 'active' },
          attributes: ['route_id', [fn('COUNT', col('id')), 'count']],
          group: ['route_id'],
          raw: true,
        })
      : [];
    const occupancyByRoute = Object.fromEntries(counts.map((c) => [c.route_id, parseInt(c.count, 10)]));

    const data = rows.map((r) => ({ ...r.toJSON(), occupancy: occupancyByRoute[r.id] || 0 }));

    res.json({
      success: true, data,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

export const getRouteById = async (req, res, next) => {
  try {
    const route = await Route.findOne({
      where: { id: req.params.id, tenant_id: req.tenantId },
      include: [{ model: Vehicle, as: 'vehicle' }],
    });
    if (!route) return res.status(404).json({ success: false, message: 'Route not found' });
    res.json({ success: true, data: route });
  } catch (error) { next(error); }
};

export const createRoute = async (req, res, next) => {
  try {
    const { campus_id, name, route_number, vehicle_id, driver_name, driver_phone, vehicle_number, capacity, stops, status } = req.body;
    if (!campus_id || !name) return res.status(400).json({ success: false, message: 'campus_id and name are required' });
    const route = await Route.create({
      tenant_id: req.tenantId, campus_id, name, route_number: route_number || null, vehicle_id: vehicle_id || null,
      driver_name: driver_name || null, driver_phone: normalizePhone(driver_phone) || null, vehicle_number: vehicle_number || null,
      capacity: capacity || null, stops: Array.isArray(stops) ? stops : [], status: status || 'active',
    });
    res.status(201).json({ success: true, message: 'Route created', data: route });
  } catch (error) { next(error); }
};

export const updateRoute = async (req, res, next) => {
  try {
    const route = await Route.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!route) return res.status(404).json({ success: false, message: 'Route not found' });
    const { campus_id, name, route_number, vehicle_id, driver_name, driver_phone, vehicle_number, capacity, stops, status } = req.body;
    await route.update({
      ...(campus_id !== undefined && { campus_id }),
      ...(name !== undefined && { name }),
      ...(route_number !== undefined && { route_number }),
      ...(vehicle_id !== undefined && { vehicle_id: vehicle_id || null }),
      ...(driver_name !== undefined && { driver_name }),
      ...(driver_phone !== undefined && { driver_phone: normalizePhone(driver_phone) }),
      ...(vehicle_number !== undefined && { vehicle_number }),
      ...(capacity !== undefined && { capacity }),
      ...(stops !== undefined && { stops }),
      ...(status !== undefined && { status }),
    });
    res.json({ success: true, message: 'Route updated', data: route });
  } catch (error) { next(error); }
};

export const deleteRoute = async (req, res, next) => {
  try {
    const route = await Route.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!route) return res.status(404).json({ success: false, message: 'Route not found' });
    const activeCount = await TransportAllocation.count({ where: { route_id: route.id, status: 'active' } });
    if (activeCount > 0) {
      return res.status(400).json({ success: false, message: `Cannot delete — ${activeCount} student(s) are still assigned to this route. Reassign or remove them first.` });
    }
    await route.destroy();
    res.json({ success: true, message: 'Route deleted' });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// STUDENT ALLOCATIONS
// ═══════════════════════════════════════════════════════════════════════════

const studentInclude = {
  model: Student, as: 'student',
  attributes: ['id', 'admission_number', 'class_id', 'section_id'],
  include: [
    { model: User, as: 'user', attributes: ['id', 'first_name', 'last_name', 'phone'] },
    { model: Class, as: 'class', attributes: ['id', 'name', 'grade'] },
    { model: Section, as: 'section', attributes: ['id', 'name'] },
  ],
};

/** GET /transport/routes/:id/students — everyone currently assigned to this route */
export const getRouteStudents = async (req, res, next) => {
  try {
    const route = await Route.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!route) return res.status(404).json({ success: false, message: 'Route not found' });
    const allocations = await TransportAllocation.findAll({
      where: { tenant_id: req.tenantId, route_id: route.id, status: 'active' },
      include: [studentInclude],
      order: [['created_at', 'ASC']],
    });

    // `student.class` is whichever class the student is in NOW. Once a
    // promotion has run, a route list viewed for a past year showed every
    // child against their current form — so the same list read differently
    // depending on when you opened it. Resolve each student's class for
    // the requested year instead.
    const targetBaseYear = extractBaseYear(req.query.academic_year);
    const data = await Promise.all(allocations.map(async (allocation) => {
      const json = allocation.toJSON();
      if (!targetBaseYear || !allocation.student) return json;

      const classForYear = await resolveStudentClassForYear({
        tenantId: req.tenantId, student: allocation.student, targetBaseYear,
      });

      return {
        ...json,
        student: {
          ...json.student,
          class: classForYear
            ? { id: classForYear.id, name: classForYear.name, grade: classForYear.grade }
            : null,
          // Stream membership for a past year isn't tracked, so showing
          // the current one would be inventing it.
          section: classForYear?.id === allocation.student.class_id ? json.student.section : null,
        },
      };
    }));

    res.json({ success: true, data });
  } catch (error) { next(error); }
};

/** GET /transport/student/:studentId — a student's current transport assignment (if any) */
export const getStudentAllocation = async (req, res, next) => {
  try {
    // Staff may look up anyone; a student sees only their own allocation and a
    // parent only their children's.
    if (SELF_SERVICE_ROLES.includes(req.user.role)) {
      const student = await Student.findOne({ where: { id: req.params.studentId, tenant_id: req.tenantId }, attributes: ['id', 'user_id', 'parent_id'] });
      if (!isOwnStudentRecord(req.user, student)) {
        return res.status(403).json({ success: false, message: 'You can only view your own allocation' });
      }
    }
    const allocation = await TransportAllocation.findOne({
      where: { tenant_id: req.tenantId, student_id: req.params.studentId, status: 'active' },
      include: [{ model: Route, as: 'route' }],
    });
    res.json({ success: true, data: allocation });
  } catch (error) { next(error); }
};

/** POST /transport/allocations — assign a student to a route. Replaces
 * any existing active assignment for that student (a student can only
 * ride one route at a time). */
export const assignStudent = async (req, res, next) => {
  try {
    const { student_id, route_id, pickup_point, drop_point, fee } = req.body;
    if (!student_id || !route_id) return res.status(400).json({ success: false, message: 'student_id and route_id are required' });

    const route = await Route.findOne({ where: { id: route_id, tenant_id: req.tenantId } });
    if (!route) return res.status(404).json({ success: false, message: 'Route not found' });

    // Same rule as hostel: a student who opted out of transport at
    // admission must not be put on a route, or the fee engine will start
    // billing them for it.
    const student = await Student.findOne({ where: { id: student_id, tenant_id: req.tenantId }, include: [{ model: User, as: 'user', attributes: ['first_name', 'last_name'] }] });
    if (!student) return res.status(404).json({ success: false, message: 'Student not found' });
    if (student.transport_required === false) {
      const name = `${student.user?.first_name || ''} ${student.user?.last_name || ''}`.trim() || 'This student';
      return res.status(400).json({
        success: false,
        message: `${name} is not registered for school transport. Update their admission record to require transport before assigning a route.`,
      });
    }

    if (route.capacity) {
      const occupied = await TransportAllocation.count({ where: { tenant_id: req.tenantId, route_id, status: 'active' } });
      const existing = await TransportAllocation.findOne({ where: { tenant_id: req.tenantId, student_id, route_id, status: 'active' } });
      if (!existing && occupied >= route.capacity) {
        return res.status(400).json({ success: false, message: `This route is full (${occupied}/${route.capacity}). Increase capacity or pick another route.` });
      }
    }

    // A student rides one route at a time — deactivate any other active assignment first.
    await TransportAllocation.update(
      { status: 'inactive' },
      { where: { tenant_id: req.tenantId, student_id, status: 'active', route_id: { [Op.ne]: route_id } } },
    );

    const [allocation] = await TransportAllocation.findOrCreate({
      where: { tenant_id: req.tenantId, student_id, route_id },
      defaults: { tenant_id: req.tenantId, student_id, route_id, pickup_point, drop_point, fee: fee || null, status: 'active' },
    });
    await allocation.update({
      status: 'active',
      ...(pickup_point !== undefined && { pickup_point }),
      ...(drop_point !== undefined && { drop_point }),
      ...(fee !== undefined && { fee: fee || null }),
    });

    const full = await TransportAllocation.findByPk(allocation.id, { include: [studentInclude, { model: Route, as: 'route' }] });
    res.status(201).json({ success: true, message: 'Student assigned to route', data: full });
  } catch (error) { next(error); }
};

export const updateAllocation = async (req, res, next) => {
  try {
    const allocation = await TransportAllocation.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!allocation) return res.status(404).json({ success: false, message: 'Assignment not found' });
    const { pickup_point, drop_point, fee } = req.body;
    await allocation.update({
      ...(pickup_point !== undefined && { pickup_point }),
      ...(drop_point !== undefined && { drop_point }),
      ...(fee !== undefined && { fee: fee || null }),
    });
    res.json({ success: true, message: 'Assignment updated', data: allocation });
  } catch (error) { next(error); }
};

/** DELETE /transport/allocations/:id — remove a student from a route (soft: marks inactive) */
export const removeAllocation = async (req, res, next) => {
  try {
    const allocation = await TransportAllocation.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!allocation) return res.status(404).json({ success: false, message: 'Assignment not found' });
    await allocation.update({ status: 'inactive' });
    res.json({ success: true, message: 'Student removed from route' });
  } catch (error) { next(error); }
};