import { Op } from 'sequelize';
import {
  Contact, ContactGroup, ContactGroupMember, User, Student, Staff, Class, Section,
} from '../models/index.js';
import { normalizePhone as normalizeContactPhone } from '../utils/phone.js';

/** Contacts are stored as country-code + number, no leading '+' (e.g.
 * "255712345678") — this is what the SMS gateways expect, and keeping
 * storage in that exact shape avoids a re-normalize step at send time.
 * Accepts a '+', a local '0'-prefixed Tanzanian number, spaces/dashes,
 * or an already-correct string; leaves non-Tanzanian-looking numbers
 * alone beyond stripping '+' and whitespace, so this doesn't mangle a
 * legitimately different country code. */
export { normalizeContactPhone };

/** Used by studentController when a guardian's name + phone/email are
 * entered on the Admission form, so that info also becomes reachable from
 * the Messages feature without anyone re-typing it there. Matches an
 * existing Contact by phone (preferred) or email within the tenant —
 * important for siblings who share the same guardian — and keeps it
 * updated instead of creating a duplicate every time the student record
 * is saved. Silently does nothing if there isn't enough info to satisfy
 * Contact's own requirements (name + at least one of phone/email). */
export const upsertParentContact = async ({ tenantId, campusId, name, phone, email, userId, linkedUserId = null }) => {
  if (!name || (!phone && !email)) return null;
  const normalizedPhone = normalizeContactPhone(phone) || null;

  let contact = null;
  if (normalizedPhone) {
    contact = await Contact.findOne({ where: { tenant_id: tenantId, phone: normalizedPhone } });
  }
  if (!contact && email) {
    contact = await Contact.findOne({ where: { tenant_id: tenantId, email } });
  }

  if (contact) {
    await contact.update({
      name,
      ...(normalizedPhone && { phone: normalizedPhone }),
      ...(email && { email }),
      // Tie the contact to the parent's login, so features that start from the parent's account (fee reminders…) find it.
      ...(linkedUserId && { linked_user_id: linkedUserId }),
      type: contact.type === 'other' ? 'parent' : contact.type,
    });
    return contact;
  }

  return Contact.create({
    tenant_id: tenantId, campus_id: campusId || null, name,
    phone: normalizedPhone, email: email || null, type: 'parent', created_by: userId || null, linked_user_id: linkedUserId || null,
  });
};

// ═══════════════════════════════════════════════════════════════════════════
// CONTACTS
// ═══════════════════════════════════════════════════════════════════════════

export const getContacts = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, search = '', type = '', status = '', group_id = '' } = req.query;
    const offset = (page - 1) * limit;
    const where = { tenant_id: req.tenantId };
    if (type) where.type = type;
    if (status) where.status = status;
    if (search) {
      where[Op.or] = [
        { name: { [Op.iLike]: `%${search}%` } },
        { phone: { [Op.iLike]: `%${search}%` } },
        { email: { [Op.iLike]: `%${search}%` } },
      ];
    }

    const include = [{ model: ContactGroup, as: 'groups', attributes: ['id', 'name'], through: { attributes: [] } }];
    if (group_id) {
      include[0].where = { id: group_id };
      include[0].required = true;
    }

    const { count, rows } = await Contact.findAndCountAll({
      where, include,
      limit: parseInt(limit), offset: parseInt(offset),
      order: [['name', 'ASC']],
      distinct: true,
    });

    res.json({
      success: true, data: rows,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(count / limit), totalItems: count, itemsPerPage: parseInt(limit) },
    });
  } catch (error) { next(error); }
};

export const createContact = async (req, res, next) => {
  try {
    const { campus_id, name, phone, email, type, linked_user_id, notes, group_ids } = req.body;
    if (!name || (!phone && !email)) {
      return res.status(400).json({ success: false, message: 'name and at least one of phone/email are required' });
    }
    const contact = await Contact.create({
      tenant_id: req.tenantId, campus_id: campus_id || null, name, phone: normalizeContactPhone(phone) || null, email: email || null,
      type: type || 'other', linked_user_id: linked_user_id || null, notes: notes || null, created_by: req.user.id,
    });
    if (Array.isArray(group_ids) && group_ids.length > 0) {
      await ContactGroupMember.bulkCreate(group_ids.map((group_id) => ({ group_id, contact_id: contact.id })), { ignoreDuplicates: true });
    }
    res.status(201).json({ success: true, message: 'Contact created', data: contact });
  } catch (error) { next(error); }
};

export const updateContact = async (req, res, next) => {
  try {
    const contact = await Contact.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!contact) return res.status(404).json({ success: false, message: 'Contact not found' });
    const { name, phone, email, type, notes, status, group_ids } = req.body;
    await contact.update({
      ...(name !== undefined && { name }),
      ...(phone !== undefined && { phone: normalizeContactPhone(phone) }),
      ...(email !== undefined && { email }),
      ...(type !== undefined && { type }),
      ...(notes !== undefined && { notes }),
      ...(status !== undefined && { status }),
    });
    if (Array.isArray(group_ids)) {
      await ContactGroupMember.destroy({ where: { contact_id: contact.id } });
      if (group_ids.length > 0) {
        await ContactGroupMember.bulkCreate(group_ids.map((group_id) => ({ group_id, contact_id: contact.id })), { ignoreDuplicates: true });
      }
    }
    res.json({ success: true, message: 'Contact updated', data: contact });
  } catch (error) { next(error); }
};

export const deleteContact = async (req, res, next) => {
  try {
    const contact = await Contact.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!contact) return res.status(404).json({ success: false, message: 'Contact not found' });
    await ContactGroupMember.destroy({ where: { contact_id: contact.id } });
    await contact.destroy();
    res.json({ success: true, message: 'Contact deleted' });
  } catch (error) { next(error); }
};

/** POST /contacts/sync — pulls every parent (from Students) and every
 * Staff member into Contacts automatically, skipping ones already linked.
 * The quickest way to populate a contact book from data that already
 * exists in the system, instead of re-typing every phone number by hand. */
export const syncContactsFromSystem = async (req, res, next) => {
  try {
    let created = 0;

    // Parents — one contact per unique parent linked on a Student record
    const students = await Student.findAll({
      where: { tenant_id: req.tenantId, parent_id: { [Op.ne]: null } },
      include: [{ model: User, as: 'parent', attributes: ['id', 'first_name', 'last_name', 'email', 'phone'] }],
    });
    const seenParents = new Set();
    for (const s of students) {
      if (!s.parent || seenParents.has(s.parent.id)) continue;
      seenParents.add(s.parent.id);
      const existing = await Contact.findOne({ where: { tenant_id: req.tenantId, linked_user_id: s.parent.id } });
      if (existing) continue;
      await Contact.create({
        tenant_id: req.tenantId, campus_id: s.campus_id,
        name: `${s.parent.first_name} ${s.parent.last_name}`.trim(),
        phone: normalizeContactPhone(s.parent.phone) || null, email: s.parent.email || null,
        type: 'parent', linked_user_id: s.parent.id, created_by: req.user.id,
      });
      created++;
    }

    // Staff
    const staffRows = await Staff.findAll({
      where: { tenant_id: req.tenantId },
      include: [{ model: User, as: 'user', attributes: ['id', 'first_name', 'last_name', 'email', 'phone'] }],
    });
    for (const s of staffRows) {
      if (!s.user) continue;
      const existing = await Contact.findOne({ where: { tenant_id: req.tenantId, linked_user_id: s.user.id } });
      if (existing) continue;
      await Contact.create({
        tenant_id: req.tenantId, campus_id: s.campus_id,
        name: `${s.user.first_name} ${s.user.last_name}`.trim(),
        phone: normalizeContactPhone(s.user.phone) || null, email: s.user.email || null,
        type: 'staff', linked_user_id: s.user.id, created_by: req.user.id,
      });
      created++;
    }

    res.json({ success: true, message: `${created} contact(s) imported from existing parents & staff`, data: { created } });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// CONTACT GROUPS (and subgroups)
// ═══════════════════════════════════════════════════════════════════════════

export const getGroups = async (req, res, next) => {
  try {
    const groups = await ContactGroup.findAll({
      where: { tenant_id: req.tenantId },
      order: [['name', 'ASC']],
    });
    // Attach a member count to each — dynamic groups are resolved on the
    // fly, static groups count their stored members.
    const withCounts = await Promise.all(groups.map(async (g) => ({
      ...g.toJSON(),
      member_count: g.is_dynamic
        ? (await resolveDynamicGroupContactIds(req.tenantId, g.dynamic_filter)).length
        : await ContactGroupMember.count({ where: { group_id: g.id } }),
    })));
    res.json({ success: true, data: withCounts });
  } catch (error) { next(error); }
};

export const createGroup = async (req, res, next) => {
  try {
    const { name, description, parent_group_id, is_dynamic, dynamic_filter, campus_id } = req.body;
    if (!name) return res.status(400).json({ success: false, message: 'name is required' });
    const group = await ContactGroup.create({
      tenant_id: req.tenantId, campus_id: campus_id || null, name, description: description || null,
      parent_group_id: parent_group_id || null, is_dynamic: !!is_dynamic,
      dynamic_filter: is_dynamic ? (dynamic_filter || {}) : null, created_by: req.user.id,
    });
    res.status(201).json({ success: true, message: 'Group created', data: group });
  } catch (error) { next(error); }
};

export const updateGroup = async (req, res, next) => {
  try {
    const group = await ContactGroup.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!group) return res.status(404).json({ success: false, message: 'Group not found' });
    const { name, description, parent_group_id, is_dynamic, dynamic_filter } = req.body;
    await group.update({
      ...(name !== undefined && { name }),
      ...(description !== undefined && { description }),
      ...(parent_group_id !== undefined && { parent_group_id: parent_group_id || null }),
      ...(is_dynamic !== undefined && { is_dynamic }),
      ...(dynamic_filter !== undefined && { dynamic_filter }),
    });
    res.json({ success: true, message: 'Group updated', data: group });
  } catch (error) { next(error); }
};

export const deleteGroup = async (req, res, next) => {
  try {
    const group = await ContactGroup.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!group) return res.status(404).json({ success: false, message: 'Group not found' });
    const subgroupCount = await ContactGroup.count({ where: { parent_group_id: group.id } });
    if (subgroupCount > 0) {
      return res.status(400).json({ success: false, message: `This group has ${subgroupCount} subgroup(s). Remove or reassign them first.` });
    }
    await ContactGroupMember.destroy({ where: { group_id: group.id } });
    await group.destroy();
    res.json({ success: true, message: 'Group deleted' });
  } catch (error) { next(error); }
};

/** Static group member management */
export const setGroupMembers = async (req, res, next) => {
  try {
    const group = await ContactGroup.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!group) return res.status(404).json({ success: false, message: 'Group not found' });
    if (group.is_dynamic) return res.status(400).json({ success: false, message: 'This is a dynamic group — its members are computed automatically from the filter, not set manually.' });

    const { contact_ids } = req.body;
    if (!Array.isArray(contact_ids)) return res.status(400).json({ success: false, message: 'contact_ids must be an array' });

    await ContactGroupMember.destroy({ where: { group_id: group.id } });
    if (contact_ids.length > 0) {
      await ContactGroupMember.bulkCreate(contact_ids.map((contact_id) => ({ group_id: group.id, contact_id })), { ignoreDuplicates: true });
    }
    res.json({ success: true, message: `${contact_ids.length} member(s) set` });
  } catch (error) { next(error); }
};

export const getGroupMembers = async (req, res, next) => {
  try {
    const group = await ContactGroup.findOne({ where: { id: req.params.id, tenant_id: req.tenantId } });
    if (!group) return res.status(404).json({ success: false, message: 'Group not found' });
    const contacts = await resolveGroupContacts(req.tenantId, group);
    res.json({ success: true, data: contacts });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// Shared resolution helpers (also used by messageController when sending)
// ═══════════════════════════════════════════════════════════════════════════

/** Resolves a dynamic group's filter into a list of Contact IDs.
 * Supported filter keys (all optional, combined with AND):
 *   - role: 'parent' | 'staff' | 'student' | 'supplier' | 'other'
 *   - class_id: only parents/students of this class (requires role parent|student)
 *   - campus_id: only contacts at this campus
 */
export async function resolveDynamicGroupContactIds(tenantId, filter = {}) {
  const { role, class_id, campus_id } = filter || {};

  if (role === 'parent' && class_id) {
    const students = await Student.findAll({ where: { tenant_id: tenantId, class_id, status: 'active' }, attributes: ['parent_id'] });
    const parentUserIds = [...new Set(students.map((s) => s.parent_id).filter(Boolean))];
    if (parentUserIds.length === 0) return [];
    const contacts = await Contact.findAll({ where: { tenant_id: tenantId, linked_user_id: parentUserIds }, attributes: ['id'] });
    return contacts.map((c) => c.id);
  }

  const where = { tenant_id: tenantId, status: 'active' };
  if (role) where.type = role;
  if (campus_id) where.campus_id = campus_id;
  const contacts = await Contact.findAll({ where, attributes: ['id'] });
  return contacts.map((c) => c.id);
}

/** Resolves a group (static, dynamic, or with subgroups) into full Contact rows. */
export async function resolveGroupContacts(tenantId, group) {
  let contactIds = [];
  if (group.is_dynamic) {
    contactIds = await resolveDynamicGroupContactIds(tenantId, group.dynamic_filter);
  } else {
    const memberships = await ContactGroupMember.findAll({ where: { group_id: group.id }, attributes: ['contact_id'] });
    contactIds = memberships.map((m) => m.contact_id);
  }
  // Include any subgroup members too, so messaging a parent group also
  // reaches its subgroups (e.g. "All Parents" → "Form I Parents" subgroup).
  const subgroups = await ContactGroup.findAll({ where: { parent_group_id: group.id } });
  for (const sub of subgroups) {
    const subContacts = await resolveGroupContacts(tenantId, sub);
    contactIds.push(...subContacts.map((c) => c.id));
  }
  contactIds = [...new Set(contactIds)];
  if (contactIds.length === 0) return [];
  return Contact.findAll({ where: { id: contactIds, tenant_id: tenantId, status: 'active' } });
}
