import { Op } from 'sequelize';
import {
  TimetableSettings, ClassSubject, TimetableEntry,
  Class, Section, Subject, User, Campus,
} from '../models/index.js';
import { notifyEvent } from '../services/notificationService.js';
import { applyAcademicYearFilter } from '../utils/academicYear.js';

const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
const EDUCATION_LEVELS = ['primary', 'o_level', 'a_level'];

// ═══════════════════════════════════════════════════════════════════════════
// Shared grid computation — turns a settings row into an ordered list of
// periods and breaks for one day. Pure function, no DB access, so the same
// logic is mirrored on the frontend for instant local rendering.
// ═══════════════════════════════════════════════════════════════════════════
const parseTime = (hhmm) => {
  const [h, m] = String(hhmm || '07:30').split(':').map(Number);
  return h * 60 + m;
};
const formatTime = (mins) => {
  const wrapped = ((mins % 1440) + 1440) % 1440; // guard against a misconfigured day rolling past midnight
  const h = Math.floor(wrapped / 60);
  const m = wrapped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
};

export const computeDayGrid = (settings, day) => {
  const periodsCount = day === 'friday' ? settings.friday_periods : settings.periods_per_day;
  const slots = [];
  let cursor = parseTime(settings.start_time);
  for (let p = 1; p <= periodsCount; p++) {
    const start = cursor;
    cursor += settings.period_duration;
    slots.push({ type: 'period', period_number: p, start_time: formatTime(start), end_time: formatTime(cursor) });
    if (settings.break_after_period === p && settings.break_duration) {
      const bStart = cursor;
      cursor += settings.break_duration;
      slots.push({ type: 'break', label: 'Break', start_time: formatTime(bStart), end_time: formatTime(cursor) });
    }
    if (settings.lunch_after_period === p && settings.lunch_duration) {
      const lStart = cursor;
      cursor += settings.lunch_duration;
      slots.push({ type: 'lunch', label: 'Lunch', start_time: formatTime(lStart), end_time: formatTime(cursor) });
    }
  }
  return slots;
};

/** Resolves a Class row scoped to this tenant, or null. Shared by every
 * handler below that needs to know a class's campus/education level. */
const findTenantClass = (tenantId, classId) => Class.findOne({ where: { id: classId, tenant_id: tenantId } });

// ═══════════════════════════════════════════════════════════════════════════
// SETTINGS — the school week, per campus per education level
// ═══════════════════════════════════════════════════════════════════════════

export const getSettings = async (req, res, next) => {
  try {
    const { campus_id, education_level } = req.query;
    if (!campus_id) return res.status(400).json({ success: false, message: 'campus_id is required' });
    const level = EDUCATION_LEVELS.includes(education_level) ? education_level : 'o_level';

    const campus = await Campus.findOne({ where: { id: campus_id, tenant_id: req.tenantId } });
    if (!campus) return res.status(404).json({ success: false, message: 'Campus not found' });

    const [settings] = await TimetableSettings.findOrCreate({
      where: { campus_id, education_level: level },
      defaults: { tenant_id: req.tenantId, campus_id, education_level: level },
    });

    res.json({
      success: true,
      data: {
        ...settings.toJSON(),
        grid: {
          regular: computeDayGrid(settings, 'monday'),
          friday: computeDayGrid(settings, 'friday'),
        },
      },
    });
  } catch (error) { next(error); }
};

export const updateSettings = async (req, res, next) => {
  try {
    const {
      campus_id, education_level, start_time, period_duration, periods_per_day,
      friday_periods, break_after_period, break_duration, lunch_after_period,
      lunch_duration, daily_activities,
    } = req.body;
    if (!campus_id) return res.status(400).json({ success: false, message: 'campus_id is required' });
    const level = EDUCATION_LEVELS.includes(education_level) ? education_level : 'o_level';

    const campus = await Campus.findOne({ where: { id: campus_id, tenant_id: req.tenantId } });
    if (!campus) return res.status(404).json({ success: false, message: 'Campus not found' });

    if (break_after_period && periods_per_day && break_after_period > periods_per_day) {
      return res.status(400).json({ success: false, message: 'Tea break cannot fall after the last period of the day' });
    }
    if (lunch_after_period && periods_per_day && lunch_after_period > periods_per_day) {
      return res.status(400).json({ success: false, message: 'Lunch break cannot fall after the last period of the day' });
    }

    const [settings] = await TimetableSettings.findOrCreate({
      where: { campus_id, education_level: level },
      defaults: { tenant_id: req.tenantId, campus_id, education_level: level },
    });

    try {
      await settings.update({
        ...(start_time !== undefined && { start_time }),
        ...(period_duration !== undefined && { period_duration }),
        ...(periods_per_day !== undefined && { periods_per_day }),
        ...(friday_periods !== undefined && { friday_periods }),
        ...(break_after_period !== undefined && { break_after_period: break_after_period || null }),
        ...(break_duration !== undefined && { break_duration }),
        ...(lunch_after_period !== undefined && { lunch_after_period: lunch_after_period || null }),
        ...(lunch_duration !== undefined && { lunch_duration }),
        ...(daily_activities !== undefined && { daily_activities }),
      });
    } catch (validationError) {
      if (validationError.name === 'SequelizeValidationError') {
        return res.status(400).json({ success: false, message: validationError.errors?.[0]?.message || 'Invalid schedule values' });
      }
      throw validationError;
    }

    // Entries whose period_number no longer exists in the new grid (e.g.
    // periods_per_day was reduced) would be orphaned/invisible — remove
    // them so the grid and stored entries never disagree. Scoped to this
    // education level's classes only; the other level's settings and
    // entries are untouched.
    const levelClasses = await Class.findAll({ where: { tenant_id: req.tenantId, campus_id, education_level: level }, attributes: ['id'] });
    const maxRegular = settings.periods_per_day;
    const maxFriday = settings.friday_periods;
    const removed = await TimetableEntry.destroy({
      where: {
        tenant_id: req.tenantId,
        class_id: levelClasses.map((c) => c.id),
        [Op.or]: [
          { day: { [Op.ne]: 'friday' }, period_number: { [Op.gt]: maxRegular } },
          { day: 'friday', period_number: { [Op.gt]: maxFriday } },
        ],
      },
    });

    res.json({
      success: true,
      message: removed > 0 ? `Schedule updated — ${removed} period(s) beyond the new grid were removed.` : 'Schedule updated',
      data: settings,
    });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// CLASS SUBJECTS — what each class studies, how often, taught by whom
// ═══════════════════════════════════════════════════════════════════════════

export const getClassSubjects = async (req, res, next) => {
  try {
    const { class_id, academic_year } = req.query;
    if (!class_id || !academic_year) return res.status(400).json({ success: false, message: 'class_id and academic_year are required' });

    const rows = await ClassSubject.findAll({
      where: applyAcademicYearFilter({ tenant_id: req.tenantId, class_id }, academic_year),
      include: [
        { model: Subject, as: 'subject', attributes: ['id', 'name', 'code'] },
        { model: User, as: 'teacher', attributes: ['id', 'first_name', 'last_name'] },
      ],
      order: [[{ model: Subject, as: 'subject' }, 'name', 'ASC']],
    });
    res.json({ success: true, data: rows });
  } catch (error) { next(error); }
};

export const saveClassSubjects = async (req, res, next) => {
  try {
    const { class_id, academic_year, subjects } = req.body;
    if (!class_id || !academic_year || !Array.isArray(subjects)) {
      return res.status(400).json({ success: false, message: 'class_id, academic_year, and subjects[] are required' });
    }

    const klass = await findTenantClass(req.tenantId, class_id);
    if (!klass) return res.status(404).json({ success: false, message: 'Class not found' });

    const cleaned = subjects.filter((s) => s.subject_id && Number(s.periods_per_week) > 0);

    const subjectIds = [...new Set(cleaned.map((s) => s.subject_id))];
    if (subjectIds.length > 0) {
      const foundSubjects = await Subject.count({ where: { id: subjectIds, tenant_id: req.tenantId } });
      if (foundSubjects !== subjectIds.length) {
        return res.status(400).json({ success: false, message: 'One or more subjects are invalid' });
      }
    }
    const teacherIds = [...new Set(cleaned.map((s) => s.teacher_id).filter(Boolean))];
    if (teacherIds.length > 0) {
      const foundTeachers = await User.count({ where: { id: teacherIds, tenant_id: req.tenantId, role: ['teacher', 'principal', 'admin', 'super_admin'] } });
      if (foundTeachers !== teacherIds.length) {
        return res.status(400).json({ success: false, message: 'One or more teachers are invalid' });
      }
    }

    await ClassSubject.destroy({ where: applyAcademicYearFilter({ tenant_id: req.tenantId, class_id }, academic_year) });
    const rows = cleaned.map((s) => ({
      tenant_id: req.tenantId, class_id, academic_year,
      subject_id: s.subject_id, teacher_id: s.teacher_id || null,
      periods_per_week: s.periods_per_week,
    }));
    if (rows.length > 0) await ClassSubject.bulkCreate(rows);

    res.json({ success: true, message: `Saved ${rows.length} subject(s) for this class` });
  } catch (error) { next(error); }
};

// ═══════════════════════════════════════════════════════════════════════════
// TIMETABLE GRID — view + manual edit (the reliable, core interaction)
// ═══════════════════════════════════════════════════════════════════════════

const entryInclude = [
  { model: Subject, as: 'subject', attributes: ['id', 'name', 'code'] },
  { model: User, as: 'teacher', attributes: ['id', 'first_name', 'last_name'] },
  { model: Class, as: 'class', attributes: ['id', 'name', 'grade'] },
  { model: Section, as: 'section', attributes: ['id', 'name'] },
];

/** GET /timetable/class?class_id=&section_id=&academic_year= — one section's grid */
export const getClassTimetable = async (req, res, next) => {
  try {
    const { class_id, section_id, academic_year } = req.query;
    if (!class_id || !section_id || !academic_year) {
      return res.status(400).json({ success: false, message: 'class_id, section_id and academic_year are required' });
    }
    const entries = await TimetableEntry.findAll({
      where: applyAcademicYearFilter({ tenant_id: req.tenantId, class_id, section_id }, academic_year, 'TimetableEntry.academic_year'),
      include: entryInclude,
      order: [['period_number', 'ASC']],
    });
    res.json({ success: true, data: entries });
  } catch (error) { next(error); }
};

/** GET /timetable/teacher?teacher_id=&academic_year= — one teacher's personal timetable, across every class */
export const getTeacherTimetable = async (req, res, next) => {
  try {
    const { teacher_id, academic_year } = req.query;
    if (!teacher_id || !academic_year) return res.status(400).json({ success: false, message: 'teacher_id and academic_year are required' });
    const entries = await TimetableEntry.findAll({
      where: applyAcademicYearFilter({ tenant_id: req.tenantId, teacher_id }, academic_year, 'TimetableEntry.academic_year'),
      include: entryInclude,
      order: [['period_number', 'ASC']],
    });
    res.json({ success: true, data: entries });
  } catch (error) { next(error); }
};

/** GET /timetable/master?campus_id=&academic_year= — whole-school grid, every class */
export const getMasterTimetable = async (req, res, next) => {
  try {
    const { campus_id, academic_year, education_level } = req.query;
    if (!campus_id || !academic_year) return res.status(400).json({ success: false, message: 'campus_id and academic_year are required' });
    const classWhere = { tenant_id: req.tenantId, campus_id, status: 'active' };
    if (education_level) classWhere.education_level = education_level;
    const classes = await Class.findAll({ where: classWhere, attributes: ['id'] });
    if (classes.length === 0) return res.json({ success: true, data: [] });
    const entries = await TimetableEntry.findAll({
      // Qualified — entryInclude joins Class, which has its own
      // academic_year column, so an unqualified reference is ambiguous.
      where: applyAcademicYearFilter({ tenant_id: req.tenantId, class_id: classes.map((c) => c.id) }, academic_year, 'TimetableEntry.academic_year'),
      include: entryInclude,
      order: [['period_number', 'ASC']],
    });
    res.json({ success: true, data: entries });
  } catch (error) { next(error); }
};

/** PUT /timetable/entry — set or clear one cell. This is the core,
 * always-reliable way to build a timetable: no algorithm to fail, just
 * "put this subject in this box." Rejects a save only for a genuine
 * double-booking (the same teacher already placed elsewhere at the exact
 * same day+period). */
export const upsertEntry = async (req, res, next) => {
  try {
    const { class_id, section_id, academic_year, day, period_number, subject_id, teacher_id } = req.body;
    if (!class_id || !section_id || !academic_year || !day || !period_number) {
      return res.status(400).json({ success: false, message: 'class_id, section_id, academic_year, day and period_number are required' });
    }
    if (!DAYS.includes(day)) return res.status(400).json({ success: false, message: 'Invalid day' });

    const klass = await findTenantClass(req.tenantId, class_id);
    if (!klass) return res.status(404).json({ success: false, message: 'Class not found' });
    const section = await Section.findOne({ where: { id: section_id, tenant_id: req.tenantId, class_id } });
    if (!section) return res.status(404).json({ success: false, message: 'Section not found for this class' });

    const settings = await TimetableSettings.findOne({ where: { campus_id: klass.campus_id, education_level: klass.education_level || 'o_level' } });
    const maxPeriod = day === 'friday' ? (settings?.friday_periods ?? 15) : (settings?.periods_per_day ?? 15);
    if (period_number < 1 || period_number > maxPeriod) {
      return res.status(400).json({ success: false, message: `Period ${period_number} is outside this day's schedule (max ${maxPeriod}).` });
    }

    if (subject_id) {
      const subject = await Subject.findOne({ where: { id: subject_id, tenant_id: req.tenantId } });
      if (!subject) return res.status(400).json({ success: false, message: 'Subject not found' });
    }

    if (teacher_id) {
      const teacher = await User.findOne({ where: { id: teacher_id, tenant_id: req.tenantId } });
      if (!teacher) return res.status(400).json({ success: false, message: 'Teacher not found' });

      const conflict = await TimetableEntry.findOne({
        // Qualified — this query joins Class (has its own academic_year).
        where: applyAcademicYearFilter(
          { tenant_id: req.tenantId, teacher_id, day, period_number, section_id: { [Op.ne]: section_id } },
          academic_year,
          'TimetableEntry.academic_year',
        ),
        include: [
          { model: Class, as: 'class', attributes: ['name'] },
          { model: Section, as: 'section', attributes: ['name'] },
        ],
      });
      if (conflict) {
        return res.status(409).json({
          success: false,
          message: `This teacher is already teaching ${conflict.class?.name} ${conflict.section?.name} at this same time.`,
        });
      }
    }

    const [entry] = await TimetableEntry.findOrCreate({
      where: { tenant_id: req.tenantId, section_id, academic_year, day, period_number },
      defaults: { tenant_id: req.tenantId, class_id, section_id, academic_year, day, period_number },
    });

    if (!subject_id) {
      // Clearing the cell — remove it outright rather than storing an
      // empty row, so "empty" always just means "no row exists".
      await entry.destroy();
      return res.json({ success: true, message: 'Period cleared', data: null });
    }

    await entry.update({ subject_id, teacher_id: teacher_id || null });
    const full = await TimetableEntry.findByPk(entry.id, { include: entryInclude });
    res.json({ success: true, message: 'Period saved', data: full });
  } catch (error) { next(error); }
};

/** POST /timetable/auto-fill — best-effort greedy fill of EMPTY cells
 * only, for one class/section, from its ClassSubject list. Never touches
 * cells that already have something in them — Auto-Fill is a starting
 * point, manual edits always win. Simple by design: no backtracking, no
 * scoring — just "next subject that still needs periods, next empty slot
 * that doesn't clash," spread across the week as evenly as possible, and
 * placed as double periods where a subject still needs 2+ periods so a
 * real timetable's common back-to-back pattern comes out of the box. */
/** POST /timetable/auto-fill — best-effort fill of a class/section's
 * timetable from its ClassSubject list. By default only touches EMPTY
 * cells (Auto-Fill is a starting point; manual edits always win). Pass
 * `regenerate: true` to clear this section's existing entries first and
 * build a fresh arrangement from scratch — for when the current layout
 * just isn't working and the user wants the system to try again.
 *
 * Runs several randomised attempts and keeps whichever placed the most
 * periods (a simple, effective way to get a greedy scheduler much closer
 * to a full solution — and, for `regenerate`, it means asking again
 * after a bad-looking result can genuinely produce a different, better
 * arrangement rather than the exact same one every time). */
export const autoFill = async (req, res, next) => {
  try {
    const { class_id, section_id, academic_year, regenerate } = req.body;
    if (!class_id || !section_id || !academic_year) {
      return res.status(400).json({ success: false, message: 'class_id, section_id and academic_year are required' });
    }

    const campusClass = await findTenantClass(req.tenantId, class_id);
    if (!campusClass) return res.status(404).json({ success: false, message: 'Class not found' });
    const section = await Section.findOne({ where: { id: section_id, tenant_id: req.tenantId, class_id } });
    if (!section) return res.status(404).json({ success: false, message: 'Section not found for this class' });

    const settings = await TimetableSettings.findOne({ where: { campus_id: campusClass.campus_id, education_level: campusClass.education_level || 'o_level' } });
    if (!settings) return res.status(400).json({ success: false, message: 'Set up the school schedule first (Timetable → Setup).' });

    const classSubjects = await ClassSubject.findAll({ where: applyAcademicYearFilter({ tenant_id: req.tenantId, class_id }, academic_year) });
    if (classSubjects.length === 0) {
      return res.status(400).json({ success: false, message: 'This class has no subjects configured yet (Timetable → Setup → Subjects).' });
    }

    if (regenerate) {
      await TimetableEntry.destroy({ where: applyAcademicYearFilter({ tenant_id: req.tenantId, section_id }, academic_year) });
    }

    const existingEntries = await TimetableEntry.findAll({ where: applyAcademicYearFilter({ tenant_id: req.tenantId, section_id }, academic_year) });
    const filledCells = new Set(existingEntries.map((e) => `${e.day}-${e.period_number}`));
    const placedCountBySubject = {};
    existingEntries.forEach((e) => {
      if (e.subject_id) placedCountBySubject[e.subject_id] = (placedCountBySubject[e.subject_id] || 0) + 1;
    });

    // Teachers already busy at a given (day, period) in OTHER sections —
    // checked before placing a subject with an assigned teacher. Fetched
    // once, outside the attempts loop, since it doesn't change between
    // attempts (this section's OWN entries are cleared/rebuilt each
    // attempt in-memory, but other sections' entries are already in the
    // DB and fixed for this run).
    const teacherIds = classSubjects.filter((cs) => cs.teacher_id).map((cs) => cs.teacher_id);
    const otherSectionTeacherBusy = new Set();
    if (teacherIds.length > 0) {
      const otherEntries = await TimetableEntry.findAll({
        where: applyAcademicYearFilter({ tenant_id: req.tenantId, teacher_id: teacherIds, section_id: { [Op.ne]: section_id } }, academic_year),
      });
      otherEntries.forEach((e) => otherSectionTeacherBusy.add(`${e.teacher_id}-${e.day}-${e.period_number}`));
    }

    const queueBase = classSubjects
      .map((cs) => ({ cs, remaining: cs.periods_per_week - (placedCountBySubject[cs.subject_id] || 0) }))
      .filter((q) => q.remaining > 0);

    // Small seeded PRNG (mulberry32) — random restarts explore different
    // valid arrangements; seeded by the current time so a `regenerate`
    // call a moment later explores a genuinely different set than the
    // last one, while a single call's own attempts stay reproducible.
    const mulberry32 = (seed) => () => {
      seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
      let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    const shuffle = (arr, rand) => { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

    const runAttempt = (rand) => {
      const emptyCellsByDay = {};
      for (const day of DAYS) {
        const count = day === 'friday' ? settings.friday_periods : settings.periods_per_day;
        const cells = [];
        for (let p = 1; p <= count; p++) if (!filledCells.has(`${day}-${p}`)) cells.push(p);
        emptyCellsByDay[day] = cells;
      }
      const teacherBusy = new Set(otherSectionTeacherBusy);
      const queue = shuffle(queueBase, rand).sort((a, b) => b.remaining - a.remaining);
      const placed = [];
      const skipped = [];
      const dayCountThisRun = {};
      const rowsToCreate = [];

      const isFree = (day, period) => emptyCellsByDay[day]?.includes(period);
      const canPlace = (item, day, period) => {
        if (!isFree(day, period)) return false;
        const alreadyToday = (dayCountThisRun[item.cs.subject_id] || {})[day] || 0;
        if (alreadyToday >= 2) return false;
        if (item.cs.teacher_id && teacherBusy.has(`${item.cs.teacher_id}-${day}-${period}`)) return false;
        return true;
      };
      const markPlaced = (item, day, period) => {
        emptyCellsByDay[day] = emptyCellsByDay[day].filter((p) => p !== period);
        if (item.cs.teacher_id) teacherBusy.add(`${item.cs.teacher_id}-${day}-${period}`);
        const subjDayCounts = dayCountThisRun[item.cs.subject_id] || {};
        dayCountThisRun[item.cs.subject_id] = { ...subjDayCounts, [day]: (subjDayCounts[day] || 0) + 1 };
        rowsToCreate.push({
          tenant_id: req.tenantId, class_id, section_id, academic_year,
          day, period_number: period, subject_id: item.cs.subject_id, teacher_id: item.cs.teacher_id || null,
        });
        placed.push({ subject_id: item.cs.subject_id, day, period });
      };

      for (const item of queue) {
        let need = item.remaining;
        while (need > 0) {
          const dayOrder = shuffle(DAYS, rand).sort((a, b) => (emptyCellsByDay[b]?.length || 0) - (emptyCellsByDay[a]?.length || 0));
          let placedThisPass = false;
          for (const day of dayOrder) {
            if (need <= 0) break;
            const cells = [...(emptyCellsByDay[day] || [])].sort((a, b) => a - b);
            for (const period of cells) {
              if (need <= 0) break;
              if (!canPlace(item, day, period)) continue;
              markPlaced(item, day, period);
              need--;
              placedThisPass = true;
              // Prefer a double period: if this subject still needs more
              // and the very next period on the same day is free and legal,
              // take it immediately so the two periods land back-to-back —
              // the way real school timetables are almost always printed.
              if (need > 0 && canPlace(item, day, period + 1)) {
                markPlaced(item, day, period + 1);
                need--;
              }
            }
          }
          if (!placedThisPass) break; // no legal cell left anywhere this pass — stop rather than loop forever
        }
        if (need > 0) skipped.push({ subject_id: item.cs.subject_id, remaining: need });
      }
      return { placed, skipped, rowsToCreate };
    };

    let best = null;
    const attemptCount = regenerate ? 60 : 20; // a fresh regenerate is worth trying harder for, since the user is asking specifically because the last result wasn't good enough
    const seedBase = regenerate ? Date.now() : 1; // deterministic for a plain auto-fill call (repeatable), randomised per-call for regenerate
    for (let attempt = 0; attempt < attemptCount && (!best || best.skipped.length > 0); attempt++) {
      const result = runAttempt(mulberry32(seedBase + attempt));
      if (!best || result.placed.length > best.placed.length) best = result;
    }
    const { placed, skipped, rowsToCreate } = best;

    if (rowsToCreate.length > 0) await TimetableEntry.bulkCreate(rowsToCreate);

    const subjectNames = await Subject.findAll({ where: { id: [...new Set(skipped.map((s) => s.subject_id))] }, attributes: ['id', 'name'] });
    const nameById = Object.fromEntries(subjectNames.map((s) => [s.id, s.name]));

    if (placed.length > 0) {
      await notifyEvent(req.tenantId, 'timetable_published', {
        title: 'Timetable Updated',
        parties: {
          teachers: { message: `The timetable for ${campusClass.name} ${section.name || ''} has been updated.` },
          students: { message: `Your class timetable for ${campusClass.name} ${section.name || ''} has been updated.` },
        },
      });
    }

    res.json({
      success: true,
      message: skipped.length === 0
        ? `Filled ${placed.length} period(s) — every subject got its full weekly count.`
        : `Filled ${placed.length} period(s). Not enough free slots for: ${skipped.map((s) => `${nameById[s.subject_id] || 'a subject'} (${s.remaining} short)`).join(', ')}.`,
      data: { placed: placed.length, skipped },
    });
  } catch (error) { next(error); }
};

/** DELETE /timetable/class?class_id=&section_id=&academic_year= — clears every entry for one section, for starting over. */
export const clearClassTimetable = async (req, res, next) => {
  try {
    const { class_id, section_id, academic_year } = req.query;
    if (!class_id || !section_id || !academic_year) {
      return res.status(400).json({ success: false, message: 'class_id, section_id and academic_year are required' });
    }
    const count = await TimetableEntry.destroy({ where: applyAcademicYearFilter({ tenant_id: req.tenantId, class_id, section_id }, academic_year) });
    res.json({ success: true, message: `Cleared ${count} period(s)` });
  } catch (error) { next(error); }
};
