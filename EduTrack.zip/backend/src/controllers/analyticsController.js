// backend/src/controllers/analyticsController.js
import { Op, fn, col } from 'sequelize';
import {
  Student, Staff, Class,
  Attendance, Exam, Grade,
  FeeStructure, Payment,
  Expense, ExpenseCategory,
  PayrollPeriod,
  Route, TransportAllocation,
  Book, BookIssue,
  HostelRoom, HostelAllocation,
  InventoryItem,
  LeaveRequest,
  Message,
} from '../models/index.js';
import { applyAcademicYearFilter, extractBaseYear } from '../utils/academicYear.js';

export const getDashboard = async (req, res, next) => {
  try {
    const tenantId = req.tenantId;
    const now = new Date();

    // Every figure below used to be anchored to TODAY — "last 30 days",
    // "this year", "this month" — so selecting 2026 in the header still
    // showed 2027's numbers. School years run January to December, so the
    // selected academic year IS a calendar year window.
    const baseYear = extractBaseYear(req.query.academic_year) || now.getFullYear();
    const isCurrentYear = baseYear === now.getFullYear();

    const windowStart = `${baseYear}-01-01`;
    // A year still in progress ends today; a closed one ends on 31 Dec.
    // Running a "last 30 days" window past the end of a finished year would
    // simply return nothing.
    const windowEnd = isCurrentYear
      ? now.toISOString().slice(0, 10)
      : `${baseYear}-12-31`;

    const windowEndDate = new Date(`${windowEnd}T00:00:00Z`);
    const daysBack = (n) => new Date(windowEndDate.getTime() - n * 86400000).toISOString().slice(0, 10);

    const thirtyDaysAgo = daysBack(30);
    const fourteenDaysAgo = daysBack(14);
    // For a closed year this is December, not the calendar month we happen
    // to be in now.
    const startOfMonth = `${windowEnd.slice(0, 7)}-01`;
    const monthLabel = windowEndDate.toLocaleString('en', { month: 'long', year: 'numeric', timeZone: 'UTC' });

    const [
      totalStudents, totalStaff, totalClasses,
      attendanceRows, attendanceTrend,
      latestExam,
      feeStructures, paymentsThisYear,
      expensesThisMonth, expensesYTD, expenseByCategory,
      latestPaidPayroll,
      routes, transportAllocCount,
      books, issuedBooks, overdueBooks,
      hostelRooms, hostelAllocCount,
      inventoryItems,
      pendingLeaveCount,
      admissionsYTD,
    ] = await Promise.all([
      Student.count({ where: { tenant_id: tenantId, status: 'active' } }),
      Staff.count({ where: { tenant_id: tenantId, status: 'active' } }),
      // Classes belong to a specific academic year, so this is a real
      // per-year figure rather than a running total of every class ever.
      Class.count({ where: applyAcademicYearFilter({ tenant_id: tenantId, status: 'active' }, req.query.academic_year) }),

      Attendance.findAll({ where: { tenant_id: tenantId, date: { [Op.gte]: thirtyDaysAgo, [Op.lte]: windowEnd } }, attributes: ['status'], raw: true }),
      Attendance.findAll({
        where: { tenant_id: tenantId, date: { [Op.gte]: fourteenDaysAgo, [Op.lte]: windowEnd } },
        attributes: ['date', 'status', [fn('COUNT', col('id')), 'count']],
        group: ['date', 'status'], raw: true,
      }),

      Exam.findOne({ where: applyAcademicYearFilter({ tenant_id: tenantId, status: 'completed' }, req.query.academic_year), order: [['end_date', 'DESC']] }),

      FeeStructure.findAll({ where: applyAcademicYearFilter({ tenant_id: tenantId, status: 'active' }, req.query.academic_year), attributes: ['id', 'amount', 'frequency', 'billing_cycles'], raw: true }),
      Payment.findAll({ where: { tenant_id: tenantId, payment_date: { [Op.between]: [windowStart, windowEnd] } }, attributes: ['amount'], raw: true }),

      Expense.sum('amount', { where: { tenant_id: tenantId, status: { [Op.ne]: 'void' }, expense_date: { [Op.between]: [startOfMonth, windowEnd] } } }),
      Expense.sum('amount', { where: { tenant_id: tenantId, status: { [Op.ne]: 'void' }, expense_date: { [Op.between]: [windowStart, windowEnd] } } }),
      Expense.findAll({
        where: { tenant_id: tenantId, status: { [Op.ne]: 'void' }, expense_date: { [Op.between]: [windowStart, windowEnd] } },
        include: [{ model: ExpenseCategory, as: 'category', attributes: ['name'] }],
        attributes: ['category_id', [fn('SUM', col('amount')), 'total']],
        group: ['category_id', 'category.id', 'category.name'], raw: true, nest: true,
      }),

      PayrollPeriod.findOne({ where: { tenant_id: tenantId, status: 'paid', year: baseYear }, order: [['month', 'DESC']] }),

      Route.findAll({ where: { tenant_id: tenantId, status: 'active' }, attributes: ['id', 'capacity'], raw: true }),
      TransportAllocation.count({ where: { tenant_id: tenantId, status: 'active' } }),

      Book.count({ where: { tenant_id: tenantId, status: 'active' } }),
      BookIssue.count({ where: { tenant_id: tenantId, status: ['issued', 'overdue'], issue_date: { [Op.between]: [windowStart, windowEnd] } } }),
      BookIssue.count({ where: { tenant_id: tenantId, status: 'overdue', issue_date: { [Op.between]: [windowStart, windowEnd] } } }),

      HostelRoom.findAll({ where: { tenant_id: tenantId }, attributes: ['id', 'capacity', 'occupied'], raw: true }),
      HostelAllocation.count({ where: { tenant_id: tenantId, status: 'active' } }),

      InventoryItem.findAll({ where: { tenant_id: tenantId, status: 'active' }, attributes: ['id', 'item_type', 'quantity_on_hand', 'reorder_level'], raw: true }),

      LeaveRequest.count({ where: { tenant_id: tenantId, status: 'pending' } }),

      // Admissions within the selected academic year window — same
      // year-scoping as everything else on this endpoint, so switching
      // the academic year selector updates this figure too.
      Student.count({ where: { tenant_id: tenantId, admission_date: { [Op.between]: [windowStart, windowEnd] } } }),
    ]);

    const attendanceTotal = attendanceRows.length;
    const attendancePresent = attendanceRows.filter((a) => a.status === 'present' || a.status === 'late').length;
    const attendanceRate = attendanceTotal > 0 ? Math.round((attendancePresent / attendanceTotal) * 1000) / 10 : null;

    const trendByDate = {};
    for (const row of attendanceTrend) {
      if (!trendByDate[row.date]) trendByDate[row.date] = { date: row.date, present: 0, absent: 0, other: 0 };
      const count = parseInt(row.count, 10);
      if (row.status === 'present' || row.status === 'late') trendByDate[row.date].present += count;
      else if (row.status === 'absent') trendByDate[row.date].absent += count;
      else trendByDate[row.date].other += count;
    }
    const attendanceChartData = Object.values(trendByDate).sort((a, b) => a.date.localeCompare(b.date));

    let examAverage = null;
    if (latestExam) {
      const grades = await Grade.findAll({ where: { tenant_id: tenantId, exam_id: latestExam.id, marks_obtained: { [Op.ne]: null } }, attributes: ['marks_obtained', 'max_marks'], raw: true });
      if (grades.length > 0) {
        const totalPct = grades.reduce((sum, g) => sum + (Number(g.marks_obtained) / Number(g.max_marks)) * 100, 0);
        examAverage = Math.round((totalPct / grades.length) * 10) / 10;
      }
    }

    // Mirrors the same annualization formula used throughout the Fees
    // feature (feeController.js) — a fee's real yearly total depends on
    // its frequency AND billing_cycles (e.g. a transport fee charged for
    // only 10 of 12 months), not a flat "billing_cycles or 1" guess.
    const FREQUENCY_MULTIPLIER = { one_time: 1, monthly: 12, quarterly: 4, annually: 1 };
    const feesExpected = feeStructures.reduce((sum, f) => {
      const cycles = (f.frequency === 'one_time' || f.frequency === 'annually')
        ? 1
        : (f.billing_cycles || FREQUENCY_MULTIPLIER[f.frequency] || 1);
      return sum + Number(f.amount) * cycles;
    }, 0);
    const feesCollected = paymentsThisYear.reduce((sum, p) => sum + Number(p.amount), 0);
    const collectionRate = feesExpected > 0 ? Math.round((feesCollected / feesExpected) * 1000) / 10 : null;

    const transportCapacity = routes.reduce((sum, r) => sum + (r.capacity || 0), 0);
    const transportOccupancyRate = transportCapacity > 0 ? Math.round((transportAllocCount / transportCapacity) * 1000) / 10 : null;

    const hostelCapacity = hostelRooms.reduce((sum, r) => sum + r.capacity, 0);
    const hostelOccupancyRate = hostelCapacity > 0 ? Math.round((hostelAllocCount / hostelCapacity) * 1000) / 10 : null;

    // Only consumables run low; a fixed asset has no reorder level.
    const lowStockCount = inventoryItems.filter((i) => i.item_type === 'consumable' && i.reorder_level !== null && i.quantity_on_hand <= i.reorder_level).length;

    res.json({
      success: true,
      data: {
        // So the dashboard can say which year and month it is reporting on,
        // rather than labelling a 2026 figure "This Month".
        period: {
          academic_year: req.query.academic_year || String(baseYear),
          base_year: baseYear,
          is_current_year: isCurrentYear,
          window_start: windowStart,
          window_end: windowEnd,
          month_label: monthLabel,
        },
        overview: { total_students: totalStudents, total_staff: totalStaff, total_classes: totalClasses, pending_leave_requests: pendingLeaveCount, admissions_ytd: admissionsYTD },
        academic: {
          attendance_rate_30d: attendanceRate,
          attendance_trend: attendanceChartData,
          latest_exam: latestExam ? { id: latestExam.id, name: latestExam.name, term: latestExam.term, average_percent: examAverage } : null,
        },
        financial: {
          fees_collected_ytd: feesCollected,
          fees_expected_ytd: feesExpected,
          fees_outstanding_ytd: Math.max(0, feesExpected - feesCollected),
          fee_collection_rate: collectionRate,
          expenses_this_month: Number(expensesThisMonth) || 0,
          expenses_ytd: Number(expensesYTD) || 0,
          expense_by_category: expenseByCategory.map((e) => ({ category: e.category?.name || 'Uncategorized', total: Number(e.total) })),
          latest_payroll: latestPaidPayroll ? { month: latestPaidPayroll.month, year: latestPaidPayroll.year } : null,
        },
        operations: {
          transport: { routes: routes.length, occupied: transportAllocCount, capacity: transportCapacity, occupancy_rate: transportOccupancyRate },
          library: { total_books: books, currently_issued: issuedBooks, overdue: overdueBooks },
          hostel: { rooms: hostelRooms.length, occupied: hostelAllocCount, capacity: hostelCapacity, occupancy_rate: hostelOccupancyRate },
          inventory: {
            total_items: inventoryItems.length,
            assets: inventoryItems.filter((i) => i.item_type === 'asset').length,
            consumables: inventoryItems.filter((i) => i.item_type === 'consumable').length,
            low_stock: lowStockCount,
          },
        },
      },
    });
  } catch (error) { next(error); }
};

/**
 * Dashboard "Today's Highlights" — what actually happened, in the
 * language a principal would use ("TZS 240,000 collected today", "12
 * students absent"), not a technical activity log ("POST /api/v1/...").
 * Every figure is a real query; nothing here is inferred or guessed.
 */
export const getHighlights = async (req, res, next) => {
  try {
    const tenantId = req.tenantId;
    const today = new Date().toISOString().slice(0, 10);
    const threeDaysAgo = new Date(Date.now() - 3 * 86400000);
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

    const [
      feesToday, attendanceToday, admissionsToday, staffOnLeaveToday,
      recentExams, recentNotices,
    ] = await Promise.all([
      Payment.findAll({ where: { tenant_id: tenantId, payment_date: today }, attributes: ['amount'], raw: true }),
      Attendance.findAll({ where: { tenant_id: tenantId, date: today }, attributes: ['status'], raw: true }),
      Student.count({ where: { tenant_id: tenantId, admission_date: today } }),
      LeaveRequest.count({ where: { tenant_id: tenantId, status: 'approved', start_date: { [Op.lte]: today }, end_date: { [Op.gte]: today } } }),
      Exam.findAll({
        where: { tenant_id: tenantId, status: 'scheduled', createdAt: { [Op.gte]: threeDaysAgo } },
        attributes: ['id', 'name', 'term', 'start_date'], order: [['createdAt', 'DESC']], limit: 3, raw: true,
      }),
      Message.findAll({
        where: { tenant_id: tenantId, is_automated: false, status: ['sent', 'partially_sent'], sent_at: { [Op.gte]: oneDayAgo } },
        attributes: ['id', 'subject', 'recipient_summary', 'sent_at'], order: [['sent_at', 'DESC']], limit: 3, raw: true,
      }),
    ]);

    const feesTodayTotal = feesToday.reduce((sum, p) => sum + Number(p.amount), 0);
    const attendanceMarkedToday = attendanceToday.length;
    const absentToday = attendanceToday.filter((a) => a.status === 'absent').length;
    // Came to school today: present, late or half a day (excused/absent do not count).
    const presentToday = attendanceToday.filter((a) => ['present', 'late', 'half_day'].includes(a.status)).length;

    res.json({
      success: true,
      data: {
        fees_today: { amount: feesTodayTotal, count: feesToday.length },
        attendance_today: { absent: absentToday, present: presentToday, marked: attendanceMarkedToday },
        admissions_today: admissionsToday,
        staff_on_leave_today: staffOnLeaveToday,
        recent_exams: recentExams,
        recent_notices: recentNotices,
      },
    });
  } catch (error) { next(error); }
};