// FILE PATH: backend/src/controllers/emailGatewayController.js
import { EmailGatewaySettings } from '../models/index.js';
import { isDeveloper } from '../utils/developerAccess.js';
import { verifyEmailGateway, sendGatewayTestEmail, describeSmtpError } from '../services/emailService.js';

/** Same restriction as SMS Gateway settings — email credentials are just
 * as sensitive, and no tenant admin (not even super_admin) should be able
 * to view or change them except the platform developer. See
 * utils/developerAccess.js. */

const MASK = '••••••••';
const DEV_ONLY = { success: false, message: 'Email gateway configuration is restricted to the platform developer.' };
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** The settings row as the browser may see it — the saved password never travels back. */
const publicView = (settings) => {
  const data = settings.toJSON();
  if (data.smtp_password) data.smtp_password = MASK;
  return data;
};

export const getEmailGatewaySettings = async (req, res, next) => {
  try {
    if (!isDeveloper(req.user)) return res.status(403).json(DEV_ONLY);
    const [settings] = await EmailGatewaySettings.findOrCreate({
      where: { tenant_id: req.tenantId },
      defaults: { tenant_id: req.tenantId, is_active: false },
    });
    res.json({ success: true, data: publicView(settings) });
  } catch (error) { next(error); }
};

export const updateEmailGatewaySettings = async (req, res, next) => {
  try {
    if (!isDeveloper(req.user)) return res.status(403).json(DEV_ONLY);
    const { smtp_host, smtp_port, smtp_secure, smtp_username, smtp_password, from_email, from_name, system_from_email, system_from_name, is_active } = req.body;
    const [settings] = await EmailGatewaySettings.findOrCreate({
      where: { tenant_id: req.tenantId },
      defaults: { tenant_id: req.tenantId },
    });

    // What is already saved counts: switching "Active" on for a host that was
    // saved earlier must not be refused just because the host wasn't re-sent.
    const effectiveHost = smtp_host !== undefined ? smtp_host : settings.smtp_host;
    if (is_active && !effectiveHost) {
      return res.status(400).json({ success: false, message: 'SMTP Host is required before activating.' });
    }

    await settings.update({
      ...(smtp_host !== undefined && { smtp_host }),
      ...(smtp_port !== undefined && { smtp_port }),
      ...(smtp_secure !== undefined && { smtp_secure }),
      ...(smtp_username !== undefined && { smtp_username }),
      ...(smtp_password !== undefined && smtp_password !== MASK && { smtp_password }),
      ...(from_email !== undefined && { from_email }),
      ...(from_name !== undefined && { from_name }),
      ...(system_from_email !== undefined && { system_from_email }),
      ...(system_from_name !== undefined && { system_from_name }),
      ...(is_active !== undefined && { is_active }),
    });
    // Masked like the GET above. This used to return the row as-is, so every
    // save sent the SMTP password back to the browser in the clear.
    res.json({ success: true, message: 'Email gateway settings updated', data: publicView(settings) });
  } catch (error) { next(error); }
};

/** POST /messaging/email/gateway/test — checks the SMTP settings before the
 * school starts relying on them, the way the SMS gateway's Test Connection does.
 *
 *   { }                       → connect + log in only; nothing is sent
 *   { send_to: "a@b.com" }    → also sends one real test message there
 *
 * Any of the form fields may be included (smtp_host, smtp_port, smtp_secure,
 * smtp_username, smtp_password, from_email, from_name). They are laid over the
 * saved settings, so the form can be tested BEFORE it is saved, and before
 * "Active" is switched on. The masked password means "use the saved one".
 *
 * A failed test is a valid answer, not a server fault — it is reported as a
 * 400 with a reason the admin can act on rather than a 500.
 */
export const testEmailGateway = async (req, res, next) => {
  try {
    if (!isDeveloper(req.user)) return res.status(403).json(DEV_ONLY);

    const saved = await EmailGatewaySettings.findOne({ where: { tenant_id: req.tenantId } });
    const body = req.body || {};

    const gateway = {
      smtp_host: saved?.smtp_host, smtp_port: saved?.smtp_port, smtp_secure: saved?.smtp_secure,
      smtp_username: saved?.smtp_username, smtp_password: saved?.smtp_password,
      from_email: saved?.from_email, from_name: saved?.from_name,
      system_from_email: saved?.system_from_email, system_from_name: saved?.system_from_name,
    };
    for (const key of ['smtp_host', 'smtp_port', 'smtp_secure', 'smtp_username', 'from_email', 'from_name', 'system_from_email', 'system_from_name']) {
      if (body[key] !== undefined) gateway[key] = body[key];
    }
    if (body.smtp_password !== undefined && body.smtp_password !== MASK) gateway.smtp_password = body.smtp_password;

    gateway.smtp_host = String(gateway.smtp_host || '').trim();
    gateway.smtp_username = String(gateway.smtp_username || '').trim();
    if (!gateway.smtp_host) {
      return res.status(400).json({ success: false, message: 'Enter the SMTP Host first — there is nothing to test yet.' });
    }
    if (gateway.smtp_username && !gateway.smtp_password) {
      return res.status(400).json({ success: false, message: 'A username is set but there is no password. Enter the password, then test again.' });
    }

    const sendTo = String(body.send_to || '').trim();
    if (sendTo && !EMAIL_RE.test(sendTo)) {
      return res.status(400).json({ success: false, message: `"${sendTo}" is not a valid email address.` });
    }

    try {
      const where = `${gateway.smtp_host}:${gateway.smtp_port || 587}`;

      if (sendTo) {
        // "Send as": the school's own sender (default) or the system sender, so each can be checked.
        const sent = await sendGatewayTestEmail(gateway, sendTo, body.send_as === 'system' ? 'system' : 'user');
        return res.json({
          success: true,
          message: `Test email sent to ${sendTo} through ${where} as ${sent.from}. Check that inbox (and its spam folder) to confirm it arrived.`,
          data: { mode: 'send', ...sent },
        });
      }

      const result = await verifyEmailGateway(gateway);
      return res.json({
        success: true,
        message: `Connected to ${where} successfully — ${result.authenticated ? 'username and password accepted' : 'connected without a login (no username set)'}. Nothing was sent; use "Send Test Email" to confirm a message actually arrives.`,
        data: { mode: 'verify', ...result },
      });
    } catch (err) {
      console.error('[email:test]', err);
      return res.status(400).json({ success: false, message: describeSmtpError(err, gateway) });
    }
  } catch (error) { next(error); }
};