import { Op } from 'sequelize';
import { Notification, NotificationSetting, SmsGatewaySettings, EmailGatewaySettings, User } from '../models/index.js';
import { getEvent, getEventDefaults, resolveAudience } from '../utils/notificationEvents.js';
import { isDeliverableEmail } from '../utils/familyContacts.js';
import { sendSmsViaGateway } from './smsService.js';
import { sendEmail } from './emailService.js';

// A provider that stops answering must not hang whatever triggered the
// notification (an admission, a payment...). Each outgoing channel gets this
// long, then it is recorded as failed and the request carries on.
const CHANNEL_TIMEOUT_MS = 10000;
const withTimeout = (promise, label) => {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label} timed out after ${CHANNEL_TIMEOUT_MS / 1000}s`)), CHANNEL_TIMEOUT_MS);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
};

const MAX_PEOPLE_PER_PARTY = 100; // a role with more people than this is cut off, not allowed to hang a request
const CONCURRENCY = 5;
const LEGACY = '__legacy';

const escapeHtml = (t) => String(t ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const digits = (p) => String(p || '').replace(/\D/g, '');

/** sent beats simulated beats failed beats skipped — one word for "what happened on this channel overall". */
const combine = (statuses) => {
  if (statuses.includes('sent')) return 'sent';
  if (statuses.includes('simulated')) return 'simulated';
  if (statuses.includes('failed')) return 'failed';
  return 'skipped';
};

const runLimited = async (items, fn) => {
  for (let i = 0; i < items.length; i += CONCURRENCY) await Promise.all(items.slice(i, i + CONCURRENCY).map(fn));
};

/**
 * notifyEvent — the single entry point every other controller (Fees, Exams, Leave, ...) calls to notify people about
 * something that just happened. Looks up whether the event is switched on for the school, WHO should be told (its parties)
 * and on which channels (Settings → Notifications), then fans out. Never throws — a notification failure must never break
 * the action that triggered it (recording a payment must succeed even if the SMS gateway is down).
 *
 * @param {string} tenantId
 * @param {string} eventKey       one of NOTIFICATION_EVENTS' keys
 * @param {object} payload
 * @param {string} payload.title / payload.message / payload.type    the default text for every party
 * @param {object} payload.parties  { [partyKey]: spec } — one entry for each party this event concerns right now. A party the
 *                                  school has switched off for this event is skipped. spec may carry:
 *     recipientUserId   one person to notify in-app (and whose phone / email are used when none is given)
 *     smsPhone / emailTo / emailSubject / emailHtml   explicit contact details (win over the user's own)
 *     title / message / type   this party's own wording
 *   Staff parties (accountants, admins…) need nothing but their key: the roles come from the event's definition and
 *   everyone active with that role is notified, on each channel chosen for the party.
 *
 * (Older callers that pass recipientUserId / recipientRoles / smsPhone / emailTo directly, without `parties`, still work as one
 * party using the event's channels.)
 *
 * Returns what actually happened, so callers that care (the admission screens) can tell the user:
 *   { event, enabled, audience, in_app, sms, email, errors, parties: { [partyKey]: { in_app, sms, email, errors, … } } }
 * each channel being one of
 *   'sent'       delivered / handed to the gateway
 *   'simulated'  SMS only: no real gateway is active, so it was only logged on the server and nobody received it
 *   'skipped'    channel off for this party, or nobody to send it to (no phone / email / account)
 *   'failed'     tried and failed — the reason is in `errors`
 */
export const notifyEvent = async (tenantId, eventKey, payload = {}) => {
  const outcome = { event: eventKey, enabled: false, audience: [], in_app: 'skipped', sms: 'skipped', email: 'skipped', errors: [], parties: {} };

  try {
    const evt = getEvent(eventKey);
    const setting = await NotificationSetting.findOne({ where: { tenant_id: tenantId, event_key: eventKey } });
    const defaults = getEventDefaults(eventKey);
    const enabled = setting ? setting.enabled : defaults.default_enabled;
    outcome.enabled = !!enabled;
    if (!enabled) return outcome;

    const audience = resolveAudience(evt, setting?.audience);
    outcome.audience = Object.keys(audience);

    const gateways = {}; // looked up once, only if a channel needs them
    const ctx = {
      tenantId, eventKey,
      smsGateway: async () => (gateways.sms ??= await SmsGatewaySettings.findOne({ where: { tenant_id: tenantId } })),
      emailGateway: async () => (gateways.email ??= await EmailGatewaySettings.findOne({ where: { tenant_id: tenantId } })),
    };

    // Older call style: one anonymous party, using the event's own channels and no audience filter.
    const legacy = !payload.parties;
    const partyMap = legacy
      ? { [LEGACY]: { ...payload, roles: payload.recipientRoles || (payload.recipientRole ? [payload.recipientRole] : []) } }
      : payload.parties;

    for (const [partyKey, spec = {}] of Object.entries(partyMap)) {
      let channels; let roles;
      if (legacy) {
        channels = setting?.channels || defaults.default_channels; roles = spec.roles;
      } else {
        const party = evt?.parties?.find((p) => p.key === partyKey);
        if (!party) { console.warn(`[notify:${eventKey}] unknown party "${partyKey}" — skipped`); continue; }
        if (!audience[partyKey] || audience[partyKey].length === 0) { outcome.parties[partyKey] = { skipped: 'switched off for this party', in_app: 'skipped', sms: 'skipped', email: 'skipped', errors: [] }; continue; }
        channels = audience[partyKey]; roles = [...(party.roles || []), ...(spec.extraRoles || [])];
      }
      outcome.parties[partyKey] = await deliverToParty(ctx, channels, { ...payload, ...spec, parties: undefined }, roles || []);
    }

    for (const ch of ['in_app', 'sms', 'email']) outcome[ch] = combine(Object.values(outcome.parties).map((p) => p[ch]));
    Object.values(outcome.parties).forEach((p) => outcome.errors.push(...(p.errors || [])));
  } catch (err) {
    // Never throws — see docstring. But it is logged, where it would otherwise vanish without a trace.
    outcome.errors.push(err?.message || String(err));
    console.error(`[notify:${eventKey}] failed:`, err?.message || err);
  }
  return outcome;
};

/** One party, on its chosen channels. Each channel is attempted on its own: a failing SMS gateway must not stop the email or the in-app notice. */
async function deliverToParty(ctx, channels, spec, roles) {
  const { tenantId, eventKey } = ctx;
  const result = { in_app: 'skipped', sms: 'skipped', email: 'skipped', errors: [], counts: { in_app: 0, sms: 0, email: 0 } };
  const fail = (channel, who, err) => {
    result.errors.push(`${channel}${who ? ` (${who})` : ''}: ${err?.message || err}`);
    console.error(`[notify:${eventKey}] ${channel} failed${who ? ` for ${who}` : ''}:`, err?.message || err);
  };
  const message = spec.message;
  const title = spec.title;
  // A caller can rule out a channel it has already used itself (a fee reminder was just texted: no second SMS).
  channels = channels.filter((c) => !(spec.skipChannels || []).includes(c));

  // ── in-app ──
  if (channels.includes('in_app') && (spec.recipientUserId || roles.length > 0)) {
    try {
      const base = { tenant_id: tenantId, title, message, type: spec.type || 'info', channel: 'in_app', sent_at: new Date(), status: 'sent' };
      const rows = [];
      if (spec.recipientUserId) rows.push({ ...base, recipient_id: spec.recipientUserId, recipient_role: null });
      roles.forEach((role) => rows.push({ ...base, recipient_id: null, recipient_role: role }));
      await Notification.bulkCreate(rows);
      result.in_app = 'sent'; result.counts.in_app = rows.length;
    } catch (err) { result.in_app = 'failed'; fail('in_app', null, err); }
  }

  // ── who the SMS / email go to ──
  const wantSms = channels.includes('sms');
  const wantEmail = channels.includes('email');
  let users = [];
  if ((wantSms && !spec.smsPhone) || (wantEmail && !spec.emailTo)) {
    const who = [];
    if (spec.recipientUserId) who.push({ id: spec.recipientUserId });
    if (roles.length) who.push({ role: { [Op.in]: roles } });
    if (who.length) {
      try { users = await User.findAll({ where: { tenant_id: tenantId, status: 'active', [Op.or]: who }, attributes: ['id', 'email', 'phone'], limit: MAX_PEOPLE_PER_PARTY }); }
      catch (err) { fail('lookup', null, err); }
    }
  }

  // ── SMS ──
  if (wantSms) {
    const seen = new Set();
    const phones = (spec.smsPhone ? [spec.smsPhone] : users.map((u) => u.phone)).filter((p) => { const d = digits(p); if (d.length < 9 || seen.has(d)) return false; seen.add(d); return true; });
    if (phones.length > 0) {
      const statuses = [];
      try {
        const gateway = await ctx.smsGateway();
        await runLimited(phones, async (to) => {
          try {
            const r = await withTimeout(sendSmsViaGateway(gateway, { to, message }), 'SMS gateway');
            if (r && r.success === false) throw new Error(r.error || 'SMS gateway reported a failure');
            statuses.push(r?.simulated ? 'simulated' : 'sent');
          } catch (err) { statuses.push('failed'); fail('sms', to, err); }
        });
      } catch (err) { statuses.push('failed'); fail('sms', null, err); }
      result.sms = combine(statuses); result.counts.sms = statuses.filter((s) => s !== 'failed').length;
    }
  }

  // ── email ──
  if (wantEmail) {
    const seen = new Set();
    const emails = (spec.emailTo ? [spec.emailTo] : users.map((u) => u.email).filter(isDeliverableEmail)).filter((e) => { const k = String(e).toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; });
    if (emails.length > 0) {
      const statuses = [];
      try {
        const gateway = await ctx.emailGateway();
        await runLimited(emails, async (to) => {
          try {
            const r = await withTimeout(sendEmail({ to, subject: spec.emailSubject || title, text: message, html: spec.emailHtml || `<p>${escapeHtml(message)}</p>` }, gateway), 'Email gateway');
            // sendEmail reports failure as { success: false } rather than throwing.
            if (r && r.success === false) throw new Error(r.error || 'Email gateway reported a failure');
            statuses.push('sent');
          } catch (err) { statuses.push('failed'); fail('email', to, err); }
        });
      } catch (err) { statuses.push('failed'); fail('email', null, err); }
      result.email = combine(statuses); result.counts.email = statuses.filter((s) => s === 'sent').length;
    }
  }
  return result;
}
