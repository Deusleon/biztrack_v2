// FILE PATH: backend/src/services/emailService.js
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

// Default transporter — built once from .env vars, used whenever a tenant
// hasn't configured (or hasn't activated) their own SMTP settings via
// Settings → Messages → Email Gateway. This keeps system emails (welcome,
// password reset, etc.) working out of the box with no per-tenant setup.
const defaultTransporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD,
  },
});

/**
 * The pieces of "send through this school's SMTP settings", shared by the real
 * sender below and by the Test buttons in Settings → Messages → Email Gateway.
 * Both go through the same two helpers on purpose: a test that built its own
 * transporter could pass while real sends fail (or the other way round).
 */
const TEST_TIMEOUT_MS = 10000;

export const buildGatewayTransporter = (gateway, { forTest = false } = {}) => nodemailer.createTransport({
  host: gateway.smtp_host,
  port: gateway.smtp_port || 587,
  secure: !!gateway.smtp_secure,
  auth: gateway.smtp_username ? { user: gateway.smtp_username, pass: gateway.smtp_password } : undefined,
  // A test must answer in seconds rather than leave the page spinning on a
  // blocked port; real sends keep nodemailer's own (longer) defaults.
  ...(forTest && { connectionTimeout: TEST_TIMEOUT_MS, greetingTimeout: TEST_TIMEOUT_MS, socketTimeout: TEST_TIMEOUT_MS }),
});

/**
 * The From address for a message sent through a school's gateway.
 *   purpose "user"    (default) from_email / from_name — what people at the school send
 *   purpose "system"  system_from_email / system_from_name — password-reset and subscription
 *                     emails. Each part falls back to the ordinary one, so a school that has set
 *                     nothing for the system sender sends exactly as before.
 */
export const gatewayFromAddress = (gateway, fallback = null, purpose = 'user') => {
  const system = purpose === 'system';
  const email = (system && gateway.system_from_email) || gateway.from_email || gateway.smtp_username;
  const name = (system && gateway.system_from_name) || gateway.from_name;
  if (!email) return fallback;
  return name ? `"${name}" <${email}>` : email;
};

/**
 * sendEmail — accepts an optional `gatewaySettings` (an EmailGatewaySettings
 * row) as a 2nd argument. When provided and active, builds a one-off
 * transporter from those tenant-specific SMTP credentials instead of the
 * .env default; otherwise falls back to `defaultTransporter`.
 */
export const sendEmail = async ({ to, subject, text, html, attachments, purpose = 'user' }, gatewaySettings = null) => {
  try {
    let transporter = defaultTransporter;
    // Without a school gateway, system mail may come from its own platform address.
    let fromAddress = (purpose === 'system' && process.env.EMAIL_FROM_SYSTEM) || process.env.EMAIL_FROM || 'noreply@edutrack.com';

    if (gatewaySettings?.is_active && gatewaySettings.smtp_host) {
      transporter = buildGatewayTransporter(gatewaySettings);
      fromAddress = gatewayFromAddress(gatewaySettings, fromAddress, purpose);
    }

    const info = await transporter.sendMail({
      from: fromAddress,
      to,
      subject,
      text,
      html,
      ...(attachments?.length ? { attachments } : {}),
    });

    console.log('Email sent:', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('Error sending email:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Turns a failed SMTP connection / login / send into something a school
 * administrator can act on. nodemailer reports most transport problems as a
 * bare "Connection timeout" or "Greeting never received"; the likely cause
 * (almost always the port / TLS pairing or a blocked port) is worked out here.
 */
export const describeSmtpError = (err, gateway = {}) => {
  const host = gateway.smtp_host || 'the mail server';
  const port = Number(gateway.smtp_port) || 587;
  const secure = !!gateway.smtp_secure;
  const code = err?.code;
  const msg = String(err?.message || '');
  const response = Number(err?.responseCode) || 0;

  const tlsHint = () => {
    if (port === 465 && !secure) return ' Port 465 expects "Use TLS on connect" to be ticked.';
    if (secure && port !== 465) return ` "Use TLS on connect" is ticked but port ${port} normally uses STARTTLS — untick it, or use port 465.`;
    return '';
  };

  if (code === 'EAUTH' || response === 535 || response === 534 || /invalid login|authentication (failed|unsuccessful)|auth(entication)? .*(rejected|failed)/i.test(msg)) {
    return `${host} rejected the username or password. Check both, and that the username is the full mailbox address if your provider requires it. Gmail and Google Workspace need an App Password (2-Step Verification on), not the normal account password.`;
  }
  if (code === 'EDNS' || code === 'ENOTFOUND' || code === 'EAI_AGAIN' || /getaddrinfo (ENOTFOUND|EAI_AGAIN)/i.test(msg)) {
    return `The SMTP host "${host}" could not be found. Check the spelling (for example smtp.gmail.com or mail.yourschool.ac.tz) and this server's internet access.`;
  }
  if (/ECONNREFUSED/.test(msg) || code === 'ECONNREFUSED') {
    return `${host} refused the connection on port ${port}. Nothing is accepting mail there — check the port (587 or 465 for most providers).${tlsHint()}`;
  }
  if (/wrong version number|ssl3_get_record|SSL routines|packet length too long/i.test(msg) || code === 'ETLS') {
    return `The TLS handshake with ${host}:${port} failed — the port and the "Use TLS on connect" setting do not match.${tlsHint() || ' Use port 465 with the box ticked, or port 587 with it unticked.'}`;
  }
  if (/self[- ]signed|certificate|hostname\/IP does not match|CERT_/i.test(msg)) {
    return `The TLS certificate of ${host} could not be verified (${msg}). Use the exact host name printed on the mail server's certificate (often the provider's own server name, not your domain).`;
  }
  if (code === 'ETIMEDOUT' || code === 'ESOCKET' || code === 'ECONNECTION' || /timeout|timed out|greeting never received|ECONNRESET/i.test(msg)) {
    return `No answer from ${host}:${port} in time. Either the port is blocked (some hosting providers block outgoing mail ports — ask them, or try the other one of 587 / 465) or the port and TLS setting don't match.${tlsHint()}`;
  }
  if (code === 'EENVELOPE' || response === 550 || response === 553 || response === 554 || /sender|from address|not allowed|relay/i.test(msg)) {
    return `The mail server accepted the login but refused the message: ${msg}. The From Email usually must be the mailbox you log in with, or an address the provider has verified for you.`;
  }
  return msg || 'Unknown error talking to the mail server.';
};

/**
 * Checks the SMTP settings WITHOUT sending anything: resolves the host,
 * opens the connection, negotiates TLS and logs in. Throws on any failure
 * (pass the error to describeSmtpError). Works whether or not the gateway is
 * switched on — that is the point: test before you activate.
 */
export const verifyEmailGateway = async (gateway) => {
  const transporter = buildGatewayTransporter(gateway, { forTest: true });
  try {
    await transporter.verify();
    return {
      host: gateway.smtp_host,
      port: gateway.smtp_port || 587,
      secure: !!gateway.smtp_secure,
      authenticated: Boolean(gateway.smtp_username),
    };
  } finally {
    transporter.close();
  }
};

/**
 * Sends ONE real message through the given settings, to prove the whole path:
 * login, the From address being accepted, and delivery to a real inbox.
 */
export const sendGatewayTestEmail = async (gateway, to, purpose = 'user') => {
  const transporter = buildGatewayTransporter(gateway, { forTest: true });
  try {
    const from = gatewayFromAddress(gateway, null, purpose);
    const info = await transporter.sendMail({
      from,
      to,
      subject: 'EduTrack email gateway test',
      text: 'This is a test message from EduTrack. If you are reading it, the email gateway settings work. No action is needed.',
      html: '<div style="font-family: Arial, sans-serif; max-width: 600px;"><h3>EduTrack email gateway test</h3><p>If you are reading this, the email gateway settings work. No action is needed.</p></div>',
    });
    if (info.rejected?.length) {
      const err = new Error(`The mail server rejected the recipient ${info.rejected.join(', ')}.`);
      err.code = 'EENVELOPE';
      throw err;
    }
    return { messageId: info.messageId, accepted: info.accepted || [], from };
  } finally {
    transporter.close();
  }
};

export const sendWelcomeEmail = async (user) => {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Welcome to EduTrack!</h2>
      <p>Hello ${user.first_name} ${user.last_name},</p>
      <p>Your account has been created successfully.</p>
      <p><strong>Email:</strong> ${user.email}</p>
      <p><strong>Role:</strong> ${user.role}</p>
      <p>Please login to your account to get started.</p>
      <br>
      <p>Best regards,</p>
      <p>EduTrack Team</p>
    </div>
  `;

  return await sendEmail({
    to: user.email,
    subject: 'Welcome to EduTrack',
    html,
  });
};

export const sendPasswordResetEmail = async (user, resetToken) => {
  const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}`;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Password Reset Request</h2>
      <p>Hello ${user.first_name},</p>
      <p>You requested to reset your password. Click the link below to reset it:</p>
      <a href="${resetUrl}" style="background-color: #4CAF50; color: white; padding: 14px 20px; text-decoration: none; display: inline-block; margin: 10px 0;">Reset Password</a>
      <p>If you didn't request this, please ignore this email.</p>
      <p>This link will expire in 1 hour.</p>
      <br>
      <p>Best regards,</p>
      <p>EduTrack Team</p>
    </div>
  `;

  return await sendEmail({
    to: user.email,
    subject: 'Password Reset Request',
    html,
  });
};

export const sendAttendanceNotification = async (parent, student, attendance) => {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Attendance Notification</h2>
      <p>Dear Parent,</p>
      <p>This is to notify you about your child's attendance:</p>
      <p><strong>Student:</strong> ${student.first_name} ${student.last_name}</p>
      <p><strong>Date:</strong> ${attendance.date}</p>
      <p><strong>Status:</strong> ${attendance.status}</p>
      ${attendance.remarks ? `<p><strong>Remarks:</strong> ${attendance.remarks}</p>` : ''}
      <br>
      <p>Best regards,</p>
      <p>EduTrack Team</p>
    </div>
  `;

  return await sendEmail({
    to: parent.email,
    subject: 'Student Attendance Notification',
    html,
  });
};