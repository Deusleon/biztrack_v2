import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

// Mock SMS service - Replace with actual SMS provider (Twilio, AWS SNS, etc.)
export const sendSMS = async ({ to, message }) => {
  try {
    console.log(`SMS to ${to}: ${message}`);
    
    // Example with Twilio (uncomment and configure when needed)
    /*
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const client = require('twilio')(accountSid, authToken);

    const result = await client.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: to
    });

    return { success: true, messageId: result.sid };
    */

    // Mock success response
    return { success: true, messageId: 'mock_' + Date.now() };
  } catch (error) {
    console.error('Error sending SMS:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Gateway-aware sender used by the Messages module. Looks at the tenant's
 * SmsGatewaySettings row: if no real provider is configured and active
 * (the default for every new school), it falls back to the same mock
 * behaviour as `sendSMS` above — logged, marked as sent, but not actually
 * dispatched anywhere. Flip `is_active` + fill in credentials from
 * Settings → Messages → SMS Gateway once a real provider is available.
 *
 * Four real providers are wired in below: Beem Africa, NextSMS, Meseji.co.tz
 * and SwalaSMS. IMPORTANT: these were implemented from each
 * provider's published API documentation, since this environment has no
 * internet access or live credentials to test against — before relying
 * on any of them in production, send a real test message with a sandbox/
 * trial account and confirm the endpoint, field names, and response shape
 * still match (providers do change these). Beem Africa's format is the
 * most stable/widely documented of the three; NextSMS and Meseji are
 * lower-confidence — check their current docs if a send fails.
 */
/**
 * Turns a failed `fetch` into something a school administrator can act on.
 *
 * Node's fetch throws a bare `TypeError: fetch failed` for EVERY transport
 * problem — the actual reason (bad hostname, refused connection, TLS
 * failure, timeout) is buried in `err.cause`. Surfacing only `err.message`
 * meant the Messages page showed "fetch failed" and nothing else, which
 * says nothing about what to fix.
 */
export const describeGatewayError = (err, provider) => {
  const cause = err?.cause;
  const code = cause?.code || err?.code;

  switch (code) {
    case 'ENOTFOUND':
    case 'EAI_AGAIN':
      return `Could not reach the ${provider} SMS gateway — the address "${cause?.hostname || 'the API host'}" does not resolve. The endpoint URL in smsService.js is likely wrong; check it against ${provider}'s current API documentation.`;
    case 'ECONNREFUSED':
      return `The ${provider} SMS gateway refused the connection. The host resolved but nothing is listening on that port — check the endpoint URL and whether the server requires https.`;
    case 'ETIMEDOUT':
    case 'UND_ERR_CONNECT_TIMEOUT':
      return `Timed out connecting to the ${provider} SMS gateway. Check this server's internet access and any outbound firewall rules.`;
    case 'CERT_HAS_EXPIRED':
    case 'UNABLE_TO_VERIFY_LEAF_SIGNATURE':
    case 'DEPTH_ZERO_SELF_SIGNED_CERT':
      return `The ${provider} SMS gateway's TLS certificate could not be verified (${code}).`;
    default:
      break;
  }

  if (err?.message === 'fetch failed') {
    return `Could not reach the ${provider} SMS gateway${code ? ` (${code})` : ''}. The request never got a response — check the endpoint URL and this server's internet access.`;
  }
  return err?.message || `Unknown error talking to the ${provider} SMS gateway.`;
};

/**
 * Which sender a message goes out under.
 *
 *   purpose "user"    (the default) the school's sender_id — messages people send, and every
 *                     automatic notice that is not a system message: admissions, payments, results…
 *   purpose "system"  the platform's system_sender_id — password-reset codes and subscription
 *                     messages. If none is set it falls back to sender_id, so nothing changes
 *                     for a school until a system sender is configured.
 *
 * Returns a plain copy of the settings with `sender_id` already set to the right one, so every
 * provider sender (which reads gatewaySettings.sender_id) works unchanged.
 */
export const settingsForPurpose = (gatewaySettings, purpose = 'user') => {
  if (!gatewaySettings) return gatewaySettings;
  const plain = typeof gatewaySettings.get === 'function' ? gatewaySettings.get({ plain: true }) : { ...gatewaySettings };
  if (purpose === 'system' && plain.system_sender_id) return { ...plain, sender_id: plain.system_sender_id };
  return plain;
};

export const sendSmsViaGateway = async (gatewaySettingsInput, { to, message, purpose = 'user' }) => {
  const gatewaySettings = settingsForPurpose(gatewaySettingsInput, purpose);
  const provider = gatewaySettings?.provider || 'simulated';

  if (provider === 'simulated' || !gatewaySettings?.is_active) {
    const mock = await sendSMS({ to, message });
    return { ...mock, simulated: true, provider: 'simulated' };
  }

  try {
    switch (provider) {
      case 'beem_africa':
        return await sendViaBeemAfrica(gatewaySettings, { to, message });
      case 'nextsms':
        return await sendViaNextSms(gatewaySettings, { to, message });
      case 'meseji':
        return await sendViaMeseji(gatewaySettings, { to, message });
      case 'swalasms':
        return await sendViaSwalaSms(gatewaySettings, { to, message });
      default:
        throw new Error(`SMS provider "${provider}" is enabled in settings but isn't implemented yet. Switch back to "Simulated" or contact support to add this provider.`);
    }
  } catch (err) {
    // Log the full error server-side — `cause` never reaches the browser,
    // and it is the only place the real reason is recorded.
    console.error(`[sms:${provider}] send to ${to} failed:`, err?.cause || err);
    const described = describeGatewayError(err, provider);
    // Re-thrown so the per-recipient handler still records it as a failure
    // (and so the send isn't charged against the balance).
    throw new Error(described);
  }
};

/** Normalizes a phone number to the "255XXXXXXXXX" format most Tanzanian
 * SMS gateways expect (no leading +, no leading 0). */
export const normalizeTzPhone = (phone) => {
  let p = String(phone || '').replace(/[\s-]/g, '');
  if (p.startsWith('+')) p = p.slice(1);
  if (p.startsWith('0')) p = '255' + p.slice(1);
  if (!p.startsWith('255')) p = '255' + p; // last resort, assume local number missing prefix
  return p;
};

// ─── Beem Africa (https://beem.africa) ─────────────────────────────────────
// Docs (as of last knowledge update): POST https://apisms.beem.africa/v1/send
// Auth: HTTP Basic, username = API key, password = Secret key.
async function sendViaBeemAfrica(gatewaySettings, { to, message }) {
  const { api_key: apiKey, api_secret: secretKey, sender_id: senderId } = gatewaySettings;
  if (!apiKey || !secretKey) throw new Error('Beem Africa API Key and Secret Key are required in Settings → Messages.');

  const auth = Buffer.from(`${apiKey}:${secretKey}`).toString('base64');
  const response = await fetch('https://apisms.beem.africa/v1/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Basic ${auth}` },
    body: JSON.stringify({
      source_addr: senderId || 'INFO',
      encoding: 0,
      message,
      recipients: [{ recipient_id: 1, dest_addr: normalizeTzPhone(to) }],
    }),
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.successful === false) {
    throw new Error(data.message || `Beem Africa request failed (HTTP ${response.status})`);
  }
  return { success: true, messageId: data.request_id || null, provider: 'beem_africa', raw: data };
}

// ─── NextSMS (https://nextsms.co.tz) ────────────────────────────────────────
//
//   Base URL : https://messaging-service.co.tz
//   Auth     : HTTP Basic — the NextSMS account username + password
//              (entered in Settings as API Key / API Secret)
//   Send     : POST /api/sms/v1/text/single   { from, to, text }
//              `to` is ONE number or an ARRAY of numbers, so a broadcast goes
//              out in a few calls instead of one call per parent.
//   Response : { messages: [ { to, messageId, smsCount,
//                              status: { groupName, name, description } } ] }
//              — one entry PER RECIPIENT, each with its own messageId, which
//              is what delivery reports are later matched on.
//   Balance  : GET /api/sms/v1/balance                     → { sms_balance }
//   Delivery : GET /api/sms/v1/reports?messageId=...       (or the DLR webhook)
//
// Written from NextSMS's published API reference. Everything that depends on
// the exact shape of a response (balance field, status names) is parsed
// leniently and logs the raw body when it can't make sense of it, so a small
// difference shows up in the server log instead of silently breaking sends.
export const NEXTSMS_BASE_URL = 'https://messaging-service.co.tz';
const NEXTSMS_TIMEOUT_MS = 20000;
const NEXTSMS_BATCH_SIZE = 100; // recipients per /text/single call

const nextSmsHeaders = (gatewaySettings) => {
  const username = gatewaySettings?.api_key;
  const password = gatewaySettings?.api_secret;
  if (!username || !password) {
    throw new Error('NextSMS username and password are required in Settings → Messages (enter the username as API Key and the password as API Secret).');
  }
  return {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    Authorization: `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`,
  };
};

/** One authenticated call to NextSMS, with the error cases the API actually
 * returns mapped to messages a school administrator can act on. */
const nextSmsRequest = async (gatewaySettings, path, { method = 'GET', body } = {}) => {
  let response;
  try {
    response = await fetch(`${NEXTSMS_BASE_URL}${path}`, {
      method,
      headers: nextSmsHeaders(gatewaySettings),
      ...(body ? { body: JSON.stringify(body) } : {}),
      // Without this a provider that stops answering hangs the whole send.
      signal: AbortSignal.timeout?.(NEXTSMS_TIMEOUT_MS),
    });
  } catch (err) {
    if (err?.name === 'TimeoutError' || err?.name === 'AbortError') {
      throw new Error(`NextSMS did not respond within ${NEXTSMS_TIMEOUT_MS / 1000}s. Try again shortly.`);
    }
    throw err; // network failures are explained by describeGatewayError
  }

  const raw = await response.text();
  let data = {};
  try { data = raw ? JSON.parse(raw) : {}; } catch { data = { message: raw.slice(0, 300) }; }

  const reason = data.message || data.error || data.description || data.messages?.[0]?.status?.description || '';

  if (response.status === 401) {
    throw new Error('NextSMS rejected the username or password. Check them in Settings → Messages — they are the same ones you log in to NextSMS with.');
  }
  if (response.status === 403) {
    throw new Error(`NextSMS refused access (HTTP 403). ${reason} Check that API access is enabled for your NextSMS account.`.trim());
  }
  if (response.status === 429) {
    throw new Error('NextSMS rate-limited this request. Wait a moment and try again.');
  }
  if (!response.ok) {
    if (/balance|insufficient|credit/i.test(`${reason}`)) {
      throw new Error(`NextSMS reports insufficient SMS balance. ${reason} Top up at nextsms.co.tz.`.trim());
    }
    throw new Error(reason || `NextSMS request failed (HTTP ${response.status}): ${raw.slice(0, 300)}`);
  }
  return data;
};

/**
 * Collapses NextSMS's status vocabulary into ours: 'delivered', 'failed' or
 * 'pending'. NextSMS reports a status as an object — { groupName: 'DELIVERED',
 * name: 'DELIVERED_TO_HANDSET', description } — and the same words arrive in
 * the delivery webhook. A bare string is accepted too.
 */
export const nextSmsStatusGroup = (status) => {
  const label = typeof status === 'string'
    ? status
    : (status?.groupName || status?.name || '');
  const s = String(label).toUpperCase();
  if (s.startsWith('DELIVERED')) return 'delivered';
  if (/UNDELIVERABLE|EXPIRED|REJECTED|FAILED|ERROR/.test(s)) return 'failed';
  return 'pending'; // PENDING_*, or unknown — not final yet
};

/**
 * Sends ONE message to MANY recipients (up to NEXTSMS_BATCH_SIZE per call).
 *
 * Returns one result per recipient, in the order given (duplicates collapsed):
 *   { to, status: 'pending' | 'failed', messageId, smsCount, error }
 * A recipient NextSMS refuses (bad number, blocked...) comes back as 'failed'
 * with the provider's reason, while the rest of the batch still goes out.
 * Only a problem with the request as a whole (bad credentials, no balance)
 * fails every recipient in that call.
 */
export const sendManyViaNextSms = async (gatewaySettings, { recipients, message }) => {
  const numbers = [...new Set((recipients || []).map(normalizeTzPhone).filter(Boolean))];
  if (numbers.length === 0) throw new Error('No valid phone numbers to send to.');

  const from = gatewaySettings.sender_id || 'NEXTSMS';
  const byNumber = new Map();

  for (let i = 0; i < numbers.length; i += NEXTSMS_BATCH_SIZE) {
    const chunk = numbers.slice(i, i + NEXTSMS_BATCH_SIZE);
    let data;
    try {
      data = await nextSmsRequest(gatewaySettings, '/api/sms/v1/text/single', {
        method: 'POST',
        body: { from, to: chunk.length === 1 ? chunk[0] : chunk, text: message },
      });
    } catch (err) {
      chunk.forEach((to) => byNumber.set(to, { to, status: 'failed', messageId: null, smsCount: 0, error: err.message }));
      continue;
    }

    const entries = Array.isArray(data?.messages) ? data.messages : (data?.to ? [data] : []);
    entries.forEach((entry) => {
      const to = normalizeTzPhone(entry.to);
      if (!to) return;
      const group = nextSmsStatusGroup(entry.status);
      const accepted = group !== 'failed';
      if (accepted && (entry.messageId === undefined || entry.messageId === null)) {
        // Without an id the delivery of this message can never be looked up.
        console.warn('[sms:nextsms] accepted but no messageId in the response entry:', JSON.stringify(entry));
      }
      byNumber.set(to, {
        to,
        status: accepted ? 'pending' : 'failed',
        messageId: entry.messageId !== undefined && entry.messageId !== null ? String(entry.messageId) : null,
        smsCount: Number(entry.smsCount) || 1,
        error: accepted ? null : (entry.status?.description || entry.status?.name || 'NextSMS rejected this number'),
        raw: entry,
      });
    });

    // A number missing from the response was not confirmed accepted.
    chunk.forEach((to) => {
      if (!byNumber.has(to)) {
        console.warn('[sms:nextsms] no result returned for', to, 'response:', JSON.stringify(data));
        byNumber.set(to, { to, status: 'failed', messageId: null, smsCount: 0, error: 'NextSMS returned no result for this number' });
      }
    });
  }

  return { provider: 'nextsms', results: numbers.map((to) => byNumber.get(to)) };
};

/** Single-recipient send, so the generic gateway interface (used for e.g. the
 * parent's admission SMS) works for NextSMS too. */
async function sendViaNextSms(gatewaySettings, { to, message }) {
  const { results } = await sendManyViaNextSms(gatewaySettings, { recipients: [to], message });
  const result = results[0];
  if (!result || result.status === 'failed') {
    throw new Error(result?.error || 'NextSMS did not accept the message');
  }
  return { success: true, messageId: result.messageId, provider: 'nextsms', raw: result.raw };
}

/**
 * Live SMS balance held at NextSMS, or null if the response has no balance
 * field we recognise (logged once so the real shape is visible). Throws if
 * the request itself fails — callers decide whether that blocks anything.
 */
export const getNextSmsBalance = async (gatewaySettings) => {
  const data = await nextSmsRequest(gatewaySettings, '/api/sms/v1/balance');
  const value = data?.sms_balance ?? data?.balance ?? data?.credits ?? data?.data?.sms_balance ?? data?.data?.balance;
  const balance = Number(value);
  if (value === undefined || value === null || value === '' || !Number.isFinite(balance)) {
    console.warn('[sms:nextsms] no balance field found in /balance. Full body:', JSON.stringify(data));
    return null;
  }
  return balance;
};

/**
 * Pings NextSMS using the balance endpoint.
 *
 * Read-only, so it proves the host resolves, TLS works and the username and
 * password are accepted — without sending an SMS or spending a credit. It
 * returns the account balance too, the number that decides whether a send
 * will succeed.
 */
export const testNextSmsConnection = async (gatewaySettings) => {
  const balance = await getNextSmsBalance(gatewaySettings);
  return { success: true, provider: 'nextsms', balance, sender_id: gatewaySettings.sender_id || null };
};

/**
 * Delivery outcome for ONE message id returned by a previous send.
 *
 * Returns { messageId, status: 'delivered'|'failed'|'pending', detail, error,
 * doneAt, via } or null when NextSMS has no record of it yet.
 *
 * Two NextSMS endpoints can answer this, and they differ in a way that
 * matters: /reports is the delivery-report feed, /logs is the permanent
 * sent-message log. They are tried in that order — if /reports is empty or
 * refuses the request, /logs gets a chance — and `via` says which one
 * answered, so the server log shows what actually worked. If BOTH fail the
 * error from each is reported, instead of one hiding the other.
 */
const NEXTSMS_REPORT_PATHS = ['/api/sms/v1/reports', '/api/sms/v1/logs'];

const readNextSmsReport = (data, messageId, via) => {
  const list = Array.isArray(data) ? data : (data?.results || data?.reports || data?.logs || data?.messages || []);
  const entry = list.find((e) => String(e.messageId ?? e.id) === String(messageId));
  if (!entry) return null;
  return {
    messageId: String(entry.messageId ?? entry.id ?? messageId),
    status: nextSmsStatusGroup(entry.status),
    detail: entry.status?.name || entry.status?.groupName || (typeof entry.status === 'string' ? entry.status : null),
    error: entry.error?.description || entry.status?.description || null,
    doneAt: entry.doneAt || null,
    via,
  };
};

export const getNextSmsDeliveryReport = async (gatewaySettings, messageId) => {
  const failures = [];
  for (const path of NEXTSMS_REPORT_PATHS) {
    try {
      const data = await nextSmsRequest(gatewaySettings, `${path}?messageId=${encodeURIComponent(messageId)}`);
      const report = readNextSmsReport(data, messageId, path);
      if (report) return report;
    } catch (err) {
      failures.push(`${path}: ${err.message}`);
    }
  }
  // Every endpoint failed — that is an error to surface, not "no report yet".
  if (failures.length === NEXTSMS_REPORT_PATHS.length) throw new Error(failures.join(' | '));
  return null;
};

// ─── Meseji.co.tz ────────────────────────────────────────────────────────────
// Implemented from Meseji's full API Reference (https://meseji.co.tz/docs).
//
//   Base URL : https://meseji.co.tz/api/v1
//   Auth     : x-api-key: <your_api_key>        (keys start with "zs_")
//   Send     : POST /sms/send      { sender_id, message, contacts }
//              `contacts` is a COMMA-SEPARATED STRING, and one call can
//              carry many recipients — see sendManyViaMeseji below.
//   Response : { batch_id, total_recipients, estimated_cost, status }
//   Stats    : GET /sms/user-stats            → includes live account balance
//   Batch    : GET /sms/stats/:batch_id       → delivery success for a batch
//   Senders  : GET /sms/sender-ids            → approval status per sender ID
//
// NOTE: the Bearer token from /auth/login is for the web dashboard only
// (it's what you use to generate an API key). Every SMS endpoint uses the
// x-api-key header instead.
export const MESEJI_BASE_URL = 'https://meseji.co.tz/api/v1';

const mesejiHeaders = (gatewaySettings) => {
  const apiKey = gatewaySettings?.api_key;
  if (!apiKey) throw new Error('Meseji API Key is required in Settings → Messages. Generate one in the Meseji dashboard under Developer Settings — it starts with "zs_".');
  return {
    'x-api-key': apiKey,
    'Content-Type': 'application/json',
    Accept: 'application/json',
  };
};

/** One authenticated call to Meseji, with the error cases the API actually
 * returns mapped to messages a school administrator can act on. */
const mesejiRequest = async (gatewaySettings, path, { method = 'GET', body } = {}) => {
  const response = await fetch(`${MESEJI_BASE_URL}${path}`, {
    method,
    headers: mesejiHeaders(gatewaySettings),
    ...(body ? { body: JSON.stringify(body) } : {}),
  });

  const data = await response.json().catch(() => ({}));

  if (response.status === 401 || response.status === 403) {
    throw new Error('Meseji rejected the API key. Check it in Settings → Messages — it must be a key generated in the Meseji dashboard (Developer Settings), and it starts with "zs_".');
  }
  if (response.status === 402) {
    throw new Error(`Meseji reports insufficient balance on your account. ${data.message || ''} Top up at meseji.co.tz.`.trim());
  }
  if (response.status === 429) {
    throw new Error('Meseji rate-limited this request. Wait a moment and try again.');
  }
  if (response.status === 422) {
    const fields = data.errors && typeof data.errors === 'object' ? Object.keys(data.errors) : [];
    throw new Error(`Meseji rejected the request (HTTP 422).${fields.length ? ` Fields: ${fields.join(', ')}.` : ''} ${JSON.stringify(data.errors || data)}`);
  }
  if (!response.ok) {
    throw new Error(data.message || data.error || `Meseji request failed (HTTP ${response.status}): ${JSON.stringify(data)}`);
  }

  return data;
};

/**
 * Sends ONE message to MANY recipients in a single API call.
 *
 * Meseji's /sms/send takes `contacts` as a comma-separated list and bills
 * the whole thing as one batch, so pushing 200 parents through 200 separate
 * HTTP requests would be slower, more likely to hit the rate limiter, and
 * would produce 200 unrelated batch ids instead of one trackable batch.
 *
 * Returns the batch envelope; the caller maps it back onto its recipients.
 */
export const sendManyViaMeseji = async (gatewaySettings, { recipients, message }) => {
  const numbers = (recipients || []).map(normalizeTzPhone).filter(Boolean);
  if (numbers.length === 0) throw new Error('No valid phone numbers to send to.');

  const data = await mesejiRequest(gatewaySettings, '/sms/send', {
    method: 'POST',
    body: {
      sender_id: gatewaySettings.sender_id || undefined,
      message,
      contacts: numbers.join(','),
    },
  });

  return {
    success: true,
    provider: 'meseji',
    batchId: data.batch_id || null,
    totalRecipients: data.total_recipients ?? numbers.length,
    estimatedCost: data.estimated_cost ?? null,
    status: data.status || 'queued',
    raw: data,
  };
};

/** Single-recipient send, kept so the generic gateway interface still works
 * for callers that send one message at a time. */
async function sendViaMeseji(gatewaySettings, { to, message }) {
  const result = await sendManyViaMeseji(gatewaySettings, { recipients: [to], message });
  return { success: true, messageId: result.batchId, provider: 'meseji', raw: result.raw };
}

/**
 * Pings Meseji using the account stats endpoint.
 *
 * Read-only and protected, so it proves the host resolves, TLS works and
 * the API key is accepted — without sending an SMS or spending a credit.
 * It also returns the account's real balance, which is the number that
 * actually governs whether a send will succeed.
 */
export const testMesejiConnection = async (gatewaySettings) => {
  const data = await mesejiRequest(gatewaySettings, '/sms/user-stats');
  return {
    success: true,
    provider: 'meseji',
    balance: data.summary?.balance ?? data.balance,
    totalSent: data.summary?.total_sent ?? data.total_sent ?? null,
    totalFailed: data.summary?.total_failed ?? data.total_failed ?? null,
    totalDelivered: data.summary?.total_delivered ?? data.total_delivered ?? null,
    successRate: data.summary?.success_rate ?? data.success_rate ?? null,
    raw: data,
  };
};

/** Live credit balance held at Meseji, or null if it can't be determined. */
export const getMesejiBalance = async (gatewaySettings) => {
  const data = await mesejiRequest(gatewaySettings, '/sms/user-stats');
  const balance = data;

  if (balance === null) {
    // Logged so the real shape is visible once, instead of silently
    // degrading to "unknown" forever.
    console.warn('[sms:meseji] no balance field found in /sms/user-stats. Full body:', JSON.stringify(data));
  }
  return balance;
};

/**
 * Starts a USSD mobile-money top-up for the Meseji account.
 *
 * Meseji pushes the USSD prompt to the phone number given; the credits
 * land on the account once the subscriber approves it on their handset.
 * There is nothing to deduct locally — the balance that matters lives at
 * Meseji, and this is what actually moves it.
 */
export const buyMesejiCredits = async (gatewaySettings, { amountTzs, phone }) => {
  const data = await mesejiRequest(gatewaySettings, '/payments/buy', {
    method: 'POST',
    body: { amount_tzs: Number(amountTzs), phone: normalizeTzPhone(phone) },
  });

  return {
    transactionId: data.transaction_id || null,
    amount: data.amount ?? Number(amountTzs),
    status: data.status || 'pending',
    paymentUrl: data.payment_url || null,
    raw: data,
  };
};

/**
 * Creates a ZenoPay order (Lipa Namba / QR) as an alternative to USSD.
 * Returns a gateway URL and TAN the payer can use.
 */
export const createMesejiZenoPayOrder = async (gatewaySettings, { amount, buyerName, buyerPhone }) => {
  const data = await mesejiRequest(gatewaySettings, '/payments/zenopay/create', {
    method: 'POST',
    body: { amount: Number(amount), buyer_name: buyerName, buyer_phone: normalizeTzPhone(buyerPhone) },
  });

  return {
    orderId: data.order_id || null,
    paymentUrl: data.payment_gateway_url || null,
    tanNumber: data.tan_number || null,
    amount: data.amount ?? Number(amount),
    smsCount: data.sms_count ?? null,
    raw: data,
  };
};

/** Polls a ZenoPay order. On COMPLETED, Meseji credits the account itself. */
export const checkMesejiZenoPayStatus = async (gatewaySettings, orderId) =>
  mesejiRequest(gatewaySettings, `/payments/zenopay/status?order_id=${encodeURIComponent(orderId)}`);

/** Delivery outcome for a batch returned by a previous send. */
export const getMesejiBatchStats = async (gatewaySettings, batchId) =>
  mesejiRequest(gatewaySettings, `/sms/stats/${encodeURIComponent(batchId)}`);

/** Sender IDs on the account and whether they're approved yet — a pending
 * or rejected sender ID is a common reason sends are refused. */
export const getMesejiSenderIds = async (gatewaySettings) =>
  mesejiRequest(gatewaySettings, '/sms/sender-ids');

// ─── SwalaSMS (https://swalasms.com) ─────────────────────────────────────────
// Implemented from SwalaSMS's published OpenAPI definition (docs.swalasms.com).
//
//   Base URL : https://api.swalasms.com        (override with SWALASMS_BASE_URL)
//   Auth     : Authorization: Bearer <key>      live keys "swl_live_…", sandbox keys "swl_test_…"
//   Send     : POST /v1/sms/messages  { recipient, sender_id, body }        one SMS → 202 { data: { uid, status … } }
//              POST /v2/sms/send-bulk { recipients[≤1000], message, sender_id } → 202 { data: { messages: [{ to, message_uid, status, units }], failures: [] } }
//   Status   : GET  /v1/sms/messages/{uid}     queued → processing → sent → delivered | failed (+ failure_reason)
//   Balance  : GET  /v1/balance                { data: { balance, countries: [...] } }
//   Senders  : GET/POST /v1/sender-ids, GET /v1/sender-ids/requirements
//   Wallet   : GET /v1/wallet/packages | payment-methods | topups, POST /v1/wallet/quote | topups
//   Webhooks : sms.delivered / sms.failed / wallet.topup.* signed with HMAC-SHA256 (X-SwalaSMS-Signature)
//
// Every send carries an Idempotency-Key, so a retry after a dropped connection can never send twice.
// A "swl_test_" key is a SANDBOX: SwalaSMS answers as if it sent, but nothing reaches a phone and no credit is spent.
// The wallet endpoints were implemented from their descriptions (the published examples are empty), so their
// responses are read tolerantly — check them against a real account the first time you top up.
export const SWALASMS_BASE_URL = (process.env.SWALASMS_BASE_URL || 'https://api.swalasms.com').replace(/\/+$/, '');
export const SWALASMS_BULK_LIMIT = 1000;

/** 'live' | 'sandbox' | null, from the shape of the key. */
export const swalaKeyMode = (key) => {
  const k = String(key || '').trim();
  if (/^swl_live_\S+/.test(k)) return 'live';
  if (/^swl_test_\S+/.test(k)) return 'sandbox';
  return null;
};

/** Carries what SwalaSMS said, so callers can tell "refused" from "outcome unknown". */
export class SwalaError extends Error {
  constructor(message, { status = null, code = null, acceptanceState = null, requestUid = null } = {}) {
    super(message);
    this.name = 'SwalaError';
    this.status = status; this.code = code; this.acceptanceState = acceptanceState; this.requestUid = requestUid;
  }
}

const swalaPhone = (phone) => `+${normalizeTzPhone(phone)}`;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const newKey = () => crypto.randomUUID();

const swalaHeaders = (gatewaySettings, { idempotencyKey, hasBody } = {}) => {
  const key = String(gatewaySettings?.api_key || '').trim();
  if (!key) throw new Error('SwalaSMS API Key is required in Settings → Messages. Create one in the SwalaSMS dashboard under SMS → API Keys — it starts with "swl_live_" (real) or "swl_test_" (sandbox).');
  return {
    Authorization: `Bearer ${key}`,
    Accept: 'application/json',
    ...(hasBody ? { 'Content-Type': 'application/json' } : {}),
    ...(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}),
  };
};

/** One authenticated call, with SwalaSMS's documented error cases turned into messages an administrator can act on. */
const swalaRequest = async (gatewaySettings, path, { method = 'GET', body, query, idempotencyKey } = {}) => {
  const url = new URL(`${SWALASMS_BASE_URL}${path}`);
  Object.entries(query || {}).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v)); });
  const response = await fetch(url, {
    method,
    headers: swalaHeaders(gatewaySettings, { idempotencyKey, hasBody: Boolean(body) }),
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const data = await response.json().catch(() => ({}));
  if (response.ok) return data;

  const meta = { status: response.status, code: data.error_code || data.error || null, acceptanceState: data.acceptance_state || null, requestUid: data.request_uid || null };
  const ref = meta.requestUid ? ` (reference ${meta.requestUid} — quote it if you contact SwalaSMS support)` : '';
  const fields = data.errors && typeof data.errors === 'object'
    ? ` ${Object.values(data.errors).flat().filter(Boolean).join(' ')}` : '';
  const said = String(data.message || '').trim();

  if (response.status === 401) {
    throw new SwalaError(`SwalaSMS rejected the API key. Check it in Settings → Messages: it must be a live ("swl_live_") or sandbox ("swl_test_") key from the SwalaSMS dashboard, still active, allowed to call from this server, and carrying the permission this action needs (sms:send, sms:read, sender-ids:read, wallet:read or wallet:topup).${ref}`, meta);
  }
  if (response.status === 409) {
    throw new SwalaError(`SwalaSMS saw this send before with different content (${said || 'idempotency key reused'}). Nothing was sent twice — try again.${ref}`, meta);
  }
  if (response.status === 422) {
    const prefix = meta.code === 'INSUFFICIENT_BALANCE' ? 'Not enough SMS credit at SwalaSMS. ' : 'SwalaSMS refused the request. ';
    throw new SwalaError(`${prefix}${said}${fields}${ref}`.replace(/\s+/g, ' ').trim(), meta);
  }
  if (response.status === 429) {
    throw new SwalaError('SwalaSMS is rate-limiting this key (too many requests in a minute). Wait a moment and try again.', meta);
  }
  if (response.status === 503 && meta.acceptanceState === 'UNKNOWN') {
    throw new SwalaError(`SwalaSMS could not confirm whether the message was queued — it may already be on its way. It is safe to try again: the same send is never delivered twice.${ref}`, meta);
  }
  throw new SwalaError(`${said || `SwalaSMS request failed (HTTP ${response.status})`}${fields}${ref}`.replace(/\s+/g, ' ').trim(), meta);
};

/** A failure that is worth ONE more try with the same Idempotency-Key (so it can never double-send). */
const isTransientSwala = (err) => err?.status === 503 || err?.status === 429
  || ['ECONNRESET', 'ETIMEDOUT', 'UND_ERR_CONNECT_TIMEOUT', 'EAI_AGAIN'].includes(err?.cause?.code)
  || err?.message === 'fetch failed';

const swalaSendRequest = async (gatewaySettings, path, body) => {
  const idempotencyKey = newKey();
  try {
    return await swalaRequest(gatewaySettings, path, { method: 'POST', body, idempotencyKey });
  } catch (err) {
    if (!isTransientSwala(err)) throw err;
    await sleep(Number(process.env.SWALASMS_RETRY_DELAY_MS ?? 1000));
    return swalaRequest(gatewaySettings, path, { method: 'POST', body, idempotencyKey }); // the SAME key
  }
};

/** queued / processing / scheduled / sent → still on its way; delivered; failed. */
export const swalaStatusGroup = (status) => {
  const s = String(status || '').toLowerCase();
  if (s === 'delivered') return 'delivered';
  if (s === 'failed' || s === 'rejected' || s === 'undelivered' || s === 'expired') return 'failed';
  return 'pending';
};

/**
 * Sends ONE message text to MANY recipients (SWALASMS_BULK_LIMIT per request).
 *
 * Returns one result per recipient, in the order given (duplicates collapsed):
 *   { to, status: 'pending' | 'failed', messageId, smsCount, error }
 * `messageId` is SwalaSMS's message_uid — the id that status checks and delivery webhooks use. A number SwalaSMS
 * refuses comes back 'failed' with its reason while the rest still go; only a problem with the whole request
 * (bad key, not enough credit, unapproved sender ID) fails every recipient in that request.
 */
export const sendManyViaSwalaSms = async (gatewaySettings, { recipients, message, campaignName }) => {
  const numbers = [...new Set((recipients || []).map(normalizeTzPhone).filter(Boolean))];
  if (numbers.length === 0) throw new Error('No valid phone numbers to send to.');
  const senderId = gatewaySettings.sender_id;
  if (!senderId) throw new Error('SwalaSMS needs a Sender ID (Settings → Messages). Use SWALATECH, SwalaSMS\'s test sender, until your own is approved.');

  const byNumber = new Map();
  for (let i = 0; i < numbers.length; i += SWALASMS_BULK_LIMIT) {
    const chunk = numbers.slice(i, i + SWALASMS_BULK_LIMIT);
    let res;
    try {
      res = await swalaSendRequest(gatewaySettings, '/v2/sms/send-bulk', {
        recipients: chunk.map(swalaPhone), message, sender_id: senderId, campaign_name: campaignName || 'EduTrack',
      });
    } catch (err) {
      chunk.forEach((to) => byNumber.set(to, { to, status: 'failed', messageId: null, smsCount: 0, error: err.message }));
      continue;
    }
    const data = res?.data || {};
    (data.messages || []).forEach((m) => {
      const to = normalizeTzPhone(m.to); if (!to) return;
      const accepted = swalaStatusGroup(m.status) !== 'failed';
      if (accepted && !m.message_uid) console.warn('[sms:swalasms] accepted but no message_uid in the response entry:', JSON.stringify(m));
      byNumber.set(to, { to, status: accepted ? 'pending' : 'failed', messageId: m.message_uid ? String(m.message_uid) : null, smsCount: Number(m.units) || 1, error: accepted ? null : (m.failure_reason || 'SwalaSMS rejected this number'), raw: m });
    });
    (data.failures || []).forEach((f) => {
      const to = normalizeTzPhone(f?.to || f?.recipient || f?.number); if (!to || byNumber.has(to)) return;
      byNumber.set(to, { to, status: 'failed', messageId: null, smsCount: 0, error: f?.reason || f?.error || f?.message || 'SwalaSMS refused this number', raw: f });
    });
    chunk.forEach((to) => { // not confirmed accepted = not accepted
      if (!byNumber.has(to)) {
        console.warn('[sms:swalasms] no result returned for', to, 'response:', JSON.stringify(res));
        byNumber.set(to, { to, status: 'failed', messageId: null, smsCount: 0, error: 'SwalaSMS returned no result for this number' });
      }
    });
    if (data.queueing) console.warn('[sms:swalasms] campaign is still being queued by SwalaSMS:', data.uid);
  }
  return { provider: 'swalasms', results: numbers.map((to) => byNumber.get(to)) };
};

/** One message, so the generic gateway interface (admission SMS, password-reset codes…) works for SwalaSMS too. */
async function sendViaSwalaSms(gatewaySettings, { to, message }) {
  if (!gatewaySettings.sender_id) throw new Error('SwalaSMS needs a Sender ID (Settings → Messages). Use SWALATECH until your own is approved.');
  const res = await swalaSendRequest(gatewaySettings, '/v1/sms/messages', { recipient: swalaPhone(to), sender_id: gatewaySettings.sender_id, body: message });
  const uid = res?.data?.uid;
  if (!uid) console.warn('[sms:swalasms] accepted but no uid in the response:', JSON.stringify(res));
  return { success: true, messageId: uid ? String(uid) : null, provider: 'swalasms', raw: res };
}

/** The account's balance (total + per country wallet) and which mode the key is in. */
export const getSwalaAccount = async (gatewaySettings) => {
  const res = await swalaRequest(gatewaySettings, '/v1/balance');
  const raw = res?.data?.balance;
  const balance = Number(raw);
  if (raw === undefined || raw === null || raw === '' || !Number.isFinite(balance)) {
    console.warn('[sms:swalasms] no balance field found in /v1/balance. Full body:', JSON.stringify(res));
  }
  return {
    balance: Number.isFinite(balance) ? balance : null,
    countries: Array.isArray(res?.data?.countries) ? res.data.countries.map((c) => ({ country: c.country, calling_code: c.calling_code, balance: Number(c.balance), wallet_uid: c.wallet_uid })) : [],
    mode: res?.mode || swalaKeyMode(gatewaySettings.api_key),
  };
};

/** Credits held at SwalaSMS, or null if the response had no recognisable balance. Throws if the request fails. */
export const getSwalaBalance = async (gatewaySettings) => (await getSwalaAccount(gatewaySettings)).balance;

/**
 * Pings SwalaSMS using the balance endpoint: read-only, so it proves the host resolves, TLS works and the key is
 * accepted — without sending an SMS or spending a credit — and returns the real balance and the key's mode.
 */
export const testSwalaConnection = async (gatewaySettings) => {
  const account = await getSwalaAccount(gatewaySettings);
  const keyMode = swalaKeyMode(gatewaySettings.api_key);
  return { success: true, provider: 'swalasms', balance: account.balance, countries: account.countries, mode: account.mode || keyMode, key_mode: keyMode, sender_id: gatewaySettings.sender_id || null };
};

/** Delivery outcome for ONE message_uid: { messageId, status: 'delivered'|'failed'|'pending', detail, error, doneAt } or null if unknown to SwalaSMS. */
export const getSwalaDeliveryReport = async (gatewaySettings, messageId) => {
  try {
    const res = await swalaRequest(gatewaySettings, `/v1/sms/messages/${encodeURIComponent(messageId)}`);
    const m = res?.data;
    if (!m) return null;
    return { messageId: String(m.uid || messageId), status: swalaStatusGroup(m.status), detail: m.status || null, error: m.failure_reason || null, doneAt: m.delivered_at || null, units: Number(m.units) || null, via: '/v1/sms/messages' };
  } catch (err) {
    if (err?.status === 404) return null; // SwalaSMS has no record of it (yet)
    throw err;
  }
};

/** Sender IDs on the account, shaped for the settings screen. `is_usable` is what decides whether sends can use one. */
export const getSwalaSenderIds = async (gatewaySettings) => {
  const res = await swalaRequest(gatewaySettings, '/v1/sender-ids');
  return (res?.data || []).map((s) => ({
    id: s.uid, sender_id: s.sender_id, status: s.status, is_usable: Boolean(s.is_usable), is_trial: Boolean(s.is_trial), is_default: Boolean(s.is_default),
    purpose: s.purpose || null, rejection_reason: s.rejection_reason || null, country: s.country_name || null,
    description: s.is_trial ? 'Test sender ID: delivers only to your registered test numbers'
      : s.rejection_reason ? `Rejected: ${s.rejection_reason}`
        : [s.country_name, s.purpose].filter(Boolean).join(' · ') || null,
  }));
};

/** What a sender-ID request must contain (eligibility, rules, accepted purposes). Call before requesting one. */
export const getSwalaSenderRequirements = async (gatewaySettings) => (await swalaRequest(gatewaySettings, '/v1/sender-ids/requirements'))?.data || {};

/** Submits a sender ID for SwalaSMS's manual review. */
export const requestSwalaSenderId = async (gatewaySettings, { senderId, purpose, sampleMessage, countryUid, documentsBase64, protectionRequested, protectionDocumentsBase64 }) => {
  const res = await swalaRequest(gatewaySettings, '/v1/sender-ids', {
    method: 'POST',
    body: {
      sender_id: senderId, purpose, sample_message: sampleMessage,
      ...(countryUid ? { country_uid: countryUid } : {}),
      ...(documentsBase64?.length ? { documents_base64: documentsBase64 } : {}),
      ...(protectionRequested ? { protection_requested: true, protection_documents_base64: protectionDocumentsBase64 || [] } : {}),
    },
  });
  return { message: res?.message || 'Sender ID request submitted for review.', data: res?.data || null };
};

// ── Wallet: buy SMS credits ───────────────────────────────────────────────────

/** Markets, fixed packages, per-SMS price tiers and the payment methods for a market. */
export const getSwalaWalletOptions = async (gatewaySettings, { countryUid } = {}) => {
  const packagesRes = await swalaRequest(gatewaySettings, '/v1/wallet/packages', { query: { country_uid: countryUid } });
  const d = packagesRes?.data ?? packagesRes ?? {};
  const countries = d.countries || [];
  const selected = d.selected_country || countries.find((c) => c.uid === countryUid) || countries[0] || null;
  const country = countryUid || selected?.uid || selected?.country_uid || null;
  let paymentMethods = [];
  try {
    const m = await swalaRequest(gatewaySettings, '/v1/wallet/payment-methods', { query: { country_uid: country } });
    const list = m?.data ?? m;
    paymentMethods = Array.isArray(list) ? list : (list?.payment_methods || list?.methods || []);
  } catch (err) { console.warn('[sms:swalasms] could not list payment methods:', err.message); }
  return { countries, selected_country: selected, country_uid: country, packages: d.packages || [], tiers: d.tiers || [], account_price: d.account_price ?? null, payment_methods: paymentMethods };
};

/** What `units` credits would cost, before ordering. */
export const quoteSwalaTopUp = async (gatewaySettings, { countryUid, units }) => {
  const res = await swalaRequest(gatewaySettings, '/v1/wallet/quote', { method: 'POST', body: { country_uid: countryUid, units: Number(units) } });
  return res?.data ?? res;
};

const readTopUp = (res) => {
  const d = res?.data ?? res ?? {};
  const order = d.order || d;
  const payment = d.payment || null;
  return {
    orderUid: order.uid || null, reference: order.reference || null, units: order.units ?? null, amount: order.amount ?? null, currency: order.currency || null,
    status: order.status || null, sandbox: Boolean(order.sandbox || res?.mode === 'sandbox'),
    payment: payment ? { mode: payment.mode || null, status: payment.status || null, redirectUrl: payment.redirect_url || null, reference: payment.reference || null } : null,
    existingOrder: Boolean(res?.existing_order), idempotentReplay: Boolean(res?.idempotent_replay), raw: res,
  };
};

/**
 * Buys credits. Mobile money (`payment_gateway` of a method with requires_phone) pushes a prompt to `billingPhone`; a card or
 * wallet method answers with a redirect URL. Needs the `wallet:topup` permission — it starts REAL charges (a sandbox key never does).
 */
export const createSwalaTopUp = async (gatewaySettings, { countryUid, units, packageUid, paymentGateway, billingPhone }) => {
  const res = await swalaRequest(gatewaySettings, '/v1/wallet/topups', {
    method: 'POST', idempotencyKey: newKey(),
    body: {
      ...(countryUid ? { country_uid: countryUid } : {}),
      ...(packageUid ? { package_uid: packageUid } : { units: Number(units) }),
      payment_gateway: paymentGateway,
      ...(billingPhone ? { billing_phone: swalaPhone(billingPhone) } : {}),
    },
  });
  return readTopUp(res);
};

/** Where a top-up has got to. While the payment is pending this also asks the payment provider, and credits the wallet once it clears. */
export const getSwalaTopUp = async (gatewaySettings, orderUid) =>
  readTopUp(await swalaRequest(gatewaySettings, `/v1/wallet/topups/${encodeURIComponent(orderUid)}`));

export const sendAttendanceSMS = async (phone, studentName, status, date) => {
  const message = `EduTrack: ${studentName} was marked ${status} on ${date}.`;
  return await sendSMS({ to: phone, message });
};

export const sendFeeReminderSMS = async (phone, studentName, amount, dueDate) => {
  const message = `EduTrack: Fee reminder for ${studentName}. Amount: $${amount}. Due date: ${dueDate}.`;
  return await sendSMS({ to: phone, message });
};

export const sendExamNotificationSMS = async (phone, studentName, examName, date) => {
  const message = `EduTrack: ${examName} scheduled for ${studentName} on ${date}.`;
  return await sendSMS({ to: phone, message });
};

