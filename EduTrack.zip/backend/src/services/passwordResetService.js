// FILE PATH: backend/src/services/passwordResetService.js
/**
 * "Forgot password" — a person resets their own password with a 6-digit code
 * sent to their email address and/or phone, with no administrator involved.
 *
 * WHERE the code goes is the school's choice (Settings → Notifications → Password
 * Reset Code): EMAIL only — the default, because it costs nothing — SMS only, or
 * either/both. The form asks only for what the school allows: an email address in
 * email mode, a phone number in SMS mode, either in the third.
 *
 *   requestReset()  → makes a code, remembers a keyed hash of it, sends it.
 *   completeReset() → checks the code and sets the new password.
 *
 * Safety rules, because this is a way to take over an account:
 *   - the code is never stored, only an HMAC of it; it lasts 15 minutes, works
 *     once, and dies after 5 wrong guesses;
 *   - what the caller is told never depends on whether the account exists, so the
 *     form can't be used to find out who has an account;
 *   - a new request replaces the old code, and requests are throttled per account
 *     (1 a minute, 5 an hour) on top of the per-IP limit on the route;
 *   - resetting voids every existing session (the session fingerprint is derived
 *     from the password hash — see utils/passwords.js) and clears a lockout.
 */
import crypto from 'crypto';
import { Op } from 'sequelize';
import { User, Student, PasswordReset, EmailGatewaySettings, SmsGatewaySettings, NotificationSetting, Tenant } from '../models/index.js';
import { sendSmsViaGateway } from './smsService.js';
import { sendEmail } from './emailService.js';
import { normalizePhone } from '../utils/phone.js';
import { newPasswordError } from '../utils/passwords.js';

export const CODE_TTL_MS = 15 * 60 * 1000;
export const MAX_ATTEMPTS = 5;
const RESEND_COOLDOWN_MS = 60 * 1000;
const MAX_REQUESTS_PER_HOUR = 5;
const DELIVERY_TIMEOUT_MS = 10000;

const secret = () => {
  const value = process.env.WEBHOOK_SECRET || process.env.JWT_SECRET;
  if (!value) throw new Error('JWT_SECRET must be set.');
  return value;
};

const hashCode = (userId, code) => crypto.createHmac('sha256', secret()).update(`${userId}:${code}`).digest('hex');
const sameHash = (a, b) => { const x = Buffer.from(a); const y = Buffer.from(b); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const makeCode = () => String(crypto.randomInt(0, 1000000)).padStart(6, '0');

export const RESET_EVENT_KEY = 'password_reset';

/** 'email' | 'sms' | 'either' from the channels a school ticked. Email alone is the default. */
export const modeFromChannels = (channels) => {
  const c = Array.isArray(channels) ? channels : ['email'];
  const email = c.includes('email'); const sms = c.includes('sms');
  if (email && sms) return 'either';
  return sms ? 'sms' : 'email';
};

export const resetModeForTenant = async (tenantId) => {
  const row = await NotificationSetting.findOne({ where: { tenant_id: tenantId, event_key: RESET_EVENT_KEY } });
  return modeFromChannels(row?.channels);
};

/**
 * What the forgot-password form should ask for. The form is shown before anyone
 * is identified, so there is no school to look at yet: if every school on this
 * server uses the same choice (always true for a school that hosts its own),
 * that is the answer; if they differ, the form accepts either, and each school's
 * own choice is then applied once the account is found.
 */
export const resetModeForForm = async () => {
  const [tenants, rows] = await Promise.all([
    Tenant.findAll({ attributes: ['id'] }),
    NotificationSetting.findAll({ where: { event_key: RESET_EVENT_KEY } }),
  ]);
  const byTenant = new Map(rows.map((r) => [r.tenant_id, modeFromChannels(r.channels)]));
  const modes = new Set(tenants.map((t) => byTenant.get(t.id) || 'email'));
  return modes.size === 1 ? [...modes][0] : 'either';
};

/** Does the thing typed in match what this school allows (email vs phone)? */
const identifierFits = (mode, identifier) => {
  const isEmail = String(identifier || '').includes('@');
  return mode === 'either' || (mode === 'email' ? isEmail : !isEmail);
};

/** The person a login identifier ("name@school.tz" or "255712345678") points at. */
export const findAccount = async (identifier) => {
  const value = String(identifier || '').trim();
  if (!value) return null;
  // A phone is stored in whichever form it was entered — 255712345678, 0712345678
  // or +255712345678 — so every form of the same number has to be looked for.
  const phoneForms = (raw) => {
    const n = normalizePhone(raw);
    return n && /^255\d{9}$/.test(n) ? [n, `0${n.slice(3)}`, `+${n}`] : [n];
  };
  const where = value.includes('@') ? { email: value.toLowerCase() } : { phone: { [Op.in]: phoneForms(value) } };
  // A phone number shared by several accounts can't safely identify one — don't guess.
  const matches = await User.findAll({ where: { ...where, status: 'active' }, limit: 2 });
  return matches.length === 1 ? matches[0] : null;
};

/** Students are given made-up addresses ("…@school.local") that nobody can read mail at. */
const hasRealEmail = (user) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(user.email || '') && !/\.local$/i.test(user.email);

const realEmail = (e) => (e && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) && !/\.local$/i.test(e) ? e : null);

/**
 * Where a code can go, for the school's chosen mode. A student has only a made-up
 * email and often no phone, so theirs goes to their PARENT's — the parent account's,
 * or the one recorded on the student. If there is nowhere real to send it, nothing
 * is sent and the person must ask their school.
 */
export const destinationsFor = async (user, mode = 'email') => {
  let email = realEmail(user.email);
  let phone = user.phone ? normalizePhone(user.phone) : null;
  if (user.role === 'student' && ((mode !== 'sms' && !email) || (mode !== 'email' && !phone))) {
    const student = await Student.findOne({ where: { user_id: user.id }, attributes: ['parent_id', 'parent_email', 'parent_phone'] });
    const parent = student?.parent_id ? await User.findByPk(student.parent_id, { attributes: ['email', 'phone'] }) : null;
    if (!email) email = realEmail(parent?.email) || realEmail(student?.parent_email);
    if (!phone) phone = normalizePhone(parent?.phone || student?.parent_phone) || null;
  }
  return { email: mode === 'sms' ? null : email, phone: mode === 'email' ? null : phone };
};

const withTimeout = (promise, label) => {
  let timer;
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`${label} timed out`)), DELIVERY_TIMEOUT_MS); });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
};

/** Sends the code by whatever the school chose. Returns the channels used. */
const defaultDelivery = async ({ user, destinations, code }) => {
  const sent = [];
  if (destinations.email) {
    try {
      const gateway = await EmailGatewaySettings.findOne({ where: { tenant_id: user.tenant_id } });
      const result = await withTimeout(sendEmail({
        purpose: 'system',
        to: destinations.email,
        subject: 'Your EduTrack password reset code',
        text: `Your password reset code is ${code}. It is valid for 15 minutes. If you did not ask for it, you can ignore this message — your password has not changed.`,
        html: `<p>Your password reset code is <strong style="font-size:1.4em;letter-spacing:2px">${code}</strong>.</p><p>It is valid for 15 minutes. If you did not ask for it, ignore this message — your password has not changed.</p>`,
      }, gateway), 'Email gateway');
      if (result && result.success === false) throw new Error(result.error || 'email not sent');
      sent.push('email');
    } catch (err) { console.error('[password-reset] email failed:', err.message); }
  }
  if (destinations.phone) {
    try {
      const gateway = await SmsGatewaySettings.findOne({ where: { tenant_id: user.tenant_id } });
      await withTimeout(sendSmsViaGateway(gateway, {
        purpose: 'system',
        to: destinations.phone,
        message: `EduTrack: Namba ya kubadilisha nenosiri / password reset code: ${code}. Valid 15 min. Do not share.`,
      }), 'SMS gateway');
      sent.push('sms');
    } catch (err) { console.error('[password-reset] SMS failed:', err.message); }
  }

  // While developing there may be no mail server or SMS gateway; this is the only way to see the code.
  if (process.env.NODE_ENV === 'development') console.log(`[password-reset] (development only) code for ${user.email}: ${code}`);
  return sent;
};

let deliver = defaultDelivery;
/** Lets tests capture the code instead of sending it. Pass nothing to restore. */
export const setDeliveryForTests = (fn) => { deliver = fn || defaultDelivery; };

/**
 * Starts a reset. Resolves with nothing useful by design: the caller must not be
 * able to tell whether anything was sent (see the file header).
 */
export const requestReset = async (identifier) => {
  const user = await findAccount(identifier);
  if (!user) return;
  // Only what this school accepts: an email address in email mode, a phone number in SMS mode.
  const mode = await resetModeForTenant(user.tenant_id);
  if (!identifierFits(mode, identifier)) return;

  const now = Date.now();
  const recent = await PasswordReset.findAll({
    where: { user_id: user.id, createdAt: { [Op.gt]: new Date(now - 60 * 60 * 1000) } },
    order: [['createdAt', 'DESC']],
  });
  if (recent.length >= MAX_REQUESTS_PER_HOUR) return;
  if (recent[0] && now - new Date(recent[0].createdAt).getTime() < RESEND_COOLDOWN_MS) return;

  const destinations = await destinationsFor(user, mode);
  if (!destinations.email && !destinations.phone) {
    console.warn(`[password-reset] no way to reach ${user.id} — they need their school to reset it`);
    return;
  }

  // A new code replaces any earlier one.
  await PasswordReset.update({ used_at: new Date() }, { where: { user_id: user.id, used_at: null } });
  const code = makeCode();
  const row = await PasswordReset.create({
    user_id: user.id, code_hash: hashCode(user.id, code), expires_at: new Date(now + CODE_TTL_MS),
  });

  const channels = await deliver({ user, destinations, code });
  await row.update({ channels: Array.isArray(channels) ? channels : [] });
};

/**
 * Finishes a reset. Returns { ok: true } or { ok: false, status, message }.
 * "Wrong code", "expired", "no such account" and "too many tries" all look the
 * same to the caller.
 */
export const completeReset = async ({ identifier, code, newPassword }) => {
  const problem = newPasswordError(newPassword);
  if (problem) return { ok: false, status: 400, message: problem };

  const refused = { ok: false, status: 400, message: 'That code is incorrect or has expired. Check it, or ask for a new one.' };
  const user = await findAccount(identifier);
  if (!user || !/^\d{6}$/.test(String(code || '').trim())) return refused;
  if (!identifierFits(await resetModeForTenant(user.tenant_id), identifier)) return refused;

  const row = await PasswordReset.findOne({
    where: { user_id: user.id, used_at: null, expires_at: { [Op.gt]: new Date() } },
    order: [['createdAt', 'DESC']],
  });
  if (!row || row.attempts >= MAX_ATTEMPTS) return refused;

  if (!sameHash(hashCode(user.id, String(code).trim()), row.code_hash)) {
    const attempts = row.attempts + 1;
    await row.update({ attempts, ...(attempts >= MAX_ATTEMPTS ? { used_at: new Date() } : {}) });
    return refused;
  }

  await user.update({ password: newPassword, must_change_password: false, failed_login_attempts: 0, locked_until: null });
  await PasswordReset.update({ used_at: new Date() }, { where: { user_id: user.id, used_at: null } });
  return { ok: true };
};
