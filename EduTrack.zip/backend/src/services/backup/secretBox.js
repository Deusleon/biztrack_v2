// FILE PATH: backend/src/services/backup/secretBox.js
/**
 * Encrypts the Google credentials stored for backups (AES-256-GCM), so reading the database does not reveal them.
 * The key comes from BACKUP_SECRET, or JWT_SECRET if that is not set (same idea as RECEIPT_SECRET).
 * If that secret is ever changed, the saved Google link simply cannot be read and must be connected again.
 */
import crypto from 'crypto';

const key = () => {
  const secret = process.env.BACKUP_SECRET || process.env.JWT_SECRET;
  if (!secret) throw new Error('Set BACKUP_SECRET (or JWT_SECRET) on the server before saving Google credentials.');
  return crypto.createHash('sha256').update(`edutrack-backup:${secret}`).digest();
};

export const seal = (plain) => {
  if (plain === null || plain === undefined || plain === '') return null;
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key(), iv);
  const enc = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), enc].map((b) => b.toString('base64')).join('.');
};

export const open = (sealed) => {
  if (!sealed) return null;
  try {
    const [iv, tag, enc] = sealed.split('.').map((s) => Buffer.from(s, 'base64'));
    const d = crypto.createDecipheriv('aes-256-gcm', key(), iv);
    d.setAuthTag(tag);
    return Buffer.concat([d.update(enc), d.final()]).toString('utf8');
  } catch {
    return null; // wrong key or damaged — treated as "not connected"
  }
};

/** A short-lived, tamper-proof token for the Google redirect (so the callback can trust who started it). */
export const signState = (payload, ttlMs = 15 * 60 * 1000) => {
  const body = Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + ttlMs })).toString('base64url');
  const sig = crypto.createHmac('sha256', key()).update(body).digest('base64url');
  return `${body}.${sig}`;
};

export const readState = (token) => {
  try {
    const [body, sig] = String(token).split('.');
    const want = crypto.createHmac('sha256', key()).update(body).digest('base64url');
    if (!sig || sig.length !== want.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(want))) return null;
    const data = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    return data.exp > Date.now() ? data : null;
  } catch { return null; }
};
