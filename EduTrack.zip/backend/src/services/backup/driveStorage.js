// FILE PATH: backend/src/services/backup/driveStorage.js
/**
 * Google Drive storage for backups, using Google's OAuth 2.0 web flow and plain HTTPS (no SDK).
 *
 * Scope is "drive.file": EduTrack can only see files and folders IT created — never the rest of the owner's Drive.
 * Backups go into one folder, "EduTrack Backups", created on first upload.
 *
 * One-time setup by the platform owner (shown step by step in Settings → Database Backup):
 *   1. Google Cloud Console → create a project → enable the Google Drive API.
 *   2. OAuth consent screen → External → set the publishing status to "In production"
 *      (in "Testing" Google expires the link after 7 days and uploads would quietly stop).
 *   3. Credentials → Create OAuth client ID → Web application → add the redirect address shown in Settings.
 *   4. Paste the Client ID and Client Secret into Settings and click "Connect Google Drive".
 */
import fs from 'fs';
import { DatabaseBackupSettings } from '../../models/index.js';
import { seal, open, signState, readState } from './secretBox.js';

const AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const API = 'https://www.googleapis.com/drive/v3';
const UPLOAD = 'https://www.googleapis.com/upload/drive/v3/files';
const SCOPES = 'https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/userinfo.email';
export const FOLDER_NAME = 'EduTrack Backups';

export class DriveError extends Error {
  constructor(message, { reconnect = false } = {}) { super(message); this.reconnect = reconnect; }
}

export const getSettings = async () => {
  const [row] = await DatabaseBackupSettings.findOrCreate({ where: { id: 1 }, defaults: { id: 1 } });
  return row;
};

/** Client id/secret: saved in Settings, or (fallback) the GOOGLE_DRIVE_CLIENT_ID / _SECRET server variables. */
export const credentialsOf = (settings) => ({
  clientId: settings.drive_client_id || process.env.GOOGLE_DRIVE_CLIENT_ID || '',
  clientSecret: open(settings.drive_client_secret_enc) || process.env.GOOGLE_DRIVE_CLIENT_SECRET || '',
});

export const redirectUriFor = (req) => {
  const base = (process.env.BACKEND_PUBLIC_URL || (req ? `${req.protocol}://${req.get('host')}` : '')).replace(/\/+$/, '');
  return `${base}/api/v1/webhooks/google-drive/callback`;
};

export const saveCredentials = async ({ clientId, clientSecret }) => {
  const s = await getSettings();
  const changed = (clientId && clientId !== s.drive_client_id) || Boolean(clientSecret);
  await s.update({
    ...(clientId ? { drive_client_id: String(clientId).trim() } : {}),
    ...(clientSecret ? { drive_client_secret_enc: seal(String(clientSecret).trim()) } : {}),
    // new credentials mean the old authorisation no longer applies
    ...(changed ? { drive_refresh_token_enc: null, drive_account_email: null, drive_folder_id: null, drive_connected_at: null, drive_enabled: false, drive_last_error: null } : {}),
  });
};

export const buildAuthUrl = async ({ req, userId }) => {
  const s = await getSettings();
  const { clientId, clientSecret } = credentialsOf(s);
  if (!clientId || !clientSecret) throw new DriveError('Save the Google Client ID and Client Secret first.');
  const redirect = redirectUriFor(req);
  const state = signState({ uid: userId, redirect });
  const p = new URLSearchParams({
    client_id: clientId, redirect_uri: redirect, response_type: 'code', scope: SCOPES,
    access_type: 'offline', prompt: 'consent', include_granted_scopes: 'true', state,
  });
  return `${AUTH_URL}?${p}`;
};

const tokenRequest = async (body) => {
  const res = await fetch(TOKEN_URL, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(body) });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const reconnect = data.error === 'invalid_grant';
    throw new DriveError(reconnect
      ? 'Google no longer accepts the saved link (it was revoked or expired). Connect Google Drive again.'
      : `Google refused the request: ${data.error_description || data.error || res.status}`, { reconnect });
  }
  return data;
};

/** Called by the Google redirect. Validates the signed state, swaps the code for a long-lived refresh token and stores it. */
export const completeAuthorisation = async ({ code, state }) => {
  const st = readState(state);
  if (!st) throw new DriveError('This connection attempt expired or is not valid. Start again from Settings.');
  const s = await getSettings();
  const { clientId, clientSecret } = credentialsOf(s);
  const t = await tokenRequest({ code, client_id: clientId, client_secret: clientSecret, redirect_uri: st.redirect, grant_type: 'authorization_code' });
  if (!t.refresh_token) throw new DriveError('Google did not give a long-lived access. Remove EduTrack from your Google account permissions and connect again.');
  let email = null;
  try {
    const r = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { Authorization: `Bearer ${t.access_token}` } });
    email = (await r.json()).email || null;
  } catch { /* the email is only for display */ }
  await s.update({ drive_refresh_token_enc: seal(t.refresh_token), drive_account_email: email, drive_connected_at: new Date(), drive_enabled: true, drive_last_error: null, drive_folder_id: null });
  return { email };
};

const accessToken = async () => {
  const s = await getSettings();
  const refresh = open(s.drive_refresh_token_enc);
  if (!refresh) throw new DriveError('Google Drive is not connected.', { reconnect: true });
  const { clientId, clientSecret } = credentialsOf(s);
  try {
    return (await tokenRequest({ client_id: clientId, client_secret: clientSecret, refresh_token: refresh, grant_type: 'refresh_token' })).access_token;
  } catch (e) {
    if (e.reconnect) await s.update({ drive_last_error: e.message, drive_enabled: false });
    throw e;
  }
};

const api = async (token, path, init = {}) => {
  const res = await fetch(path.startsWith('http') ? path : `${API}${path}`, { ...init, headers: { Authorization: `Bearer ${token}`, ...(init.headers || {}) } });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data.error?.message || `Google Drive error ${res.status}`;
    throw new DriveError(res.status === 401 ? `${msg} — connect Google Drive again.` : msg, { reconnect: res.status === 401 });
  }
  return data;
};

const ensureFolder = async (token) => {
  const s = await getSettings();
  if (s.drive_folder_id) {
    try { const f = await api(token, `/files/${s.drive_folder_id}?fields=id,trashed`); if (!f.trashed) return s.drive_folder_id; } catch { /* recreate below */ }
  }
  const q = encodeURIComponent(`name='${FOLDER_NAME}' and mimeType='application/vnd.google-apps.folder' and trashed=false`);
  const found = await api(token, `/files?q=${q}&fields=files(id)&spaces=drive`);
  let id = found.files?.[0]?.id;
  if (!id) id = (await api(token, '/files?fields=id', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: FOLDER_NAME, mimeType: 'application/vnd.google-apps.folder' }) })).id;
  await s.update({ drive_folder_id: id });
  return id;
};

/** Uploads one backup file (resumable, streamed). Returns the Drive file id. */
export const uploadFile = async (filePath, fileName) => {
  const token = await accessToken();
  const folder = await ensureFolder(token);
  const size = fs.statSync(filePath).size;
  const init = await fetch(`${UPLOAD}?uploadType=resumable&fields=id`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json; charset=UTF-8', 'X-Upload-Content-Type': 'application/gzip', 'X-Upload-Content-Length': String(size) },
    body: JSON.stringify({ name: fileName, parents: [folder], mimeType: 'application/gzip' }),
  });
  if (!init.ok) throw new DriveError(`Google Drive refused the upload: ${(await init.json().catch(() => ({}))).error?.message || init.status}`);
  const session = init.headers.get('location');
  const put = await fetch(session, { method: 'PUT', headers: { 'Content-Length': String(size), 'Content-Type': 'application/gzip' }, body: fs.createReadStream(filePath), duplex: 'half' });
  const data = await put.json().catch(() => ({}));
  if (!put.ok) throw new DriveError(`Upload to Google Drive failed: ${data.error?.message || put.status}`);
  return data.id;
};

export const deleteFile = async (fileId) => {
  const token = await accessToken();
  try { await api(token, `/files/${fileId}`, { method: 'DELETE' }); } catch (e) { if (!/not found/i.test(e.message)) throw e; }
};

/** Proves the link works by checking the folder (creating it if needed). Returns { email, folderId }. */
export const testConnection = async () => {
  const token = await accessToken();
  const folderId = await ensureFolder(token);
  const s = await getSettings();
  await s.update({ drive_last_error: null });
  return { email: s.drive_account_email, folderId };
};

export const disconnect = async () => {
  const s = await getSettings();
  const refresh = open(s.drive_refresh_token_enc);
  if (refresh) { try { await fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(refresh)}`, { method: 'POST' }); } catch { /* best effort */ } }
  await s.update({ drive_refresh_token_enc: null, drive_account_email: null, drive_folder_id: null, drive_connected_at: null, drive_enabled: false, drive_last_error: null });
};

export const isConnected = (s) => Boolean(open(s.drive_refresh_token_enc));
