// FILE PATH: backend/src/services/backup/backupService.js
/**
 * Runs and manages full-database backups:
 *
 *   runBackup()                      dump → restore test → upload to Google Drive (if linked) → tidy old ones
 *   ensureBackupBeforeRiskyAction()  called before promotion, bulk import, migrations… — makes a fresh backup first
 *   runDueBackup()                   the daily schedule, with catch-up if the server was asleep at the set hour
 *
 * A backup is only called "good" once the restore test has passed. A failure never goes unnoticed: the history
 * shows it in red and the platform owner (DEVELOPER_EMAILS) is emailed.
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Op } from 'sequelize';
import { DatabaseBackup } from '../../models/index.js';
import { createDump, verifyBackupFile, databaseHasData, newClient } from './dumpEngine.js';
import * as drive from './driveStorage.js';
import { sendEmail } from '../emailService.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const LOCK_KEY = 7263541;
const DAY = 86400000;
const MIN_KEEP = 3;               // never delete the newest few good backups, whatever the retention says
const REUSE_WITHIN_MS = 5 * 60 * 1000; // a good backup this fresh counts for a "before risky action" backup too
const TZ = () => process.env.SCHOOL_TIME_ZONE || 'Africa/Dar_es_Salaam';

export const backupDir = () => {
  const dir = path.resolve(process.env.BACKUP_DIR || path.join(__dirname, '..', '..', '..', 'backups'));
  fs.mkdirSync(dir, { recursive: true });
  return dir;
};

/** True while the automated test suite is running (Node's test runner sets NODE_TEST_CONTEXT), so tests never
 * trigger real backups unless a test asks for it with BACKUP_FORCE_IN_TESTS=1. */
export const runningUnderTests = () => (process.env.NODE_ENV === 'test' || Boolean(process.env.NODE_TEST_CONTEXT)) && process.env.BACKUP_FORCE_IN_TESTS !== '1';

export class BackupRequiredError extends Error {
  constructor(message) { super(message); this.status = 503; this.statusCode = 503; this.code = 'BACKUP_REQUIRED'; }
}

const stamp = (d = new Date()) => d.toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');

/** { date: 'YYYY-MM-DD', hour } of an instant in the school's time zone. */
export const localParts = (when = new Date()) => {
  const f = new Intl.DateTimeFormat('en-CA', { timeZone: TZ(), year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hourCycle: 'h23' });
  const p = Object.fromEntries(f.formatToParts(when).map((x) => [x.type, x.value]));
  return { date: `${p.year}-${p.month}-${p.day}`, hour: Number(p.hour) };
};

const withLock = async (fn) => {
  const client = await newClient();
  try {
    const { rows } = await client.query('SELECT pg_try_advisory_lock($1) AS got', [LOCK_KEY]);
    if (!rows[0].got) return { busy: true };
    try { return { value: await fn() }; } finally { await client.query('SELECT pg_advisory_unlock($1)', [LOCK_KEY]); }
  } finally { await client.end().catch(() => {}); }
};

const alertOwner = async (subject, text) => {
  const to = (process.env.DEVELOPER_EMAILS || '').split(',').map((e) => e.trim()).filter(Boolean);
  if (to.length === 0) return;
  try { await sendEmail({ to: to.join(','), subject: `[EduTrack] ${subject}`, text, purpose: 'system' }); } catch (e) { console.error('Backup alert email failed:', e.message); }
};

export const driveUsable = async () => {
  const s = await drive.getSettings();
  return s.drive_enabled && drive.isConnected(s);
};

/** Pushes one finished, tested backup to Google Drive and records the result. */
export const uploadToDrive = async (row) => {
  const file = path.join(backupDir(), row.file_name);
  if (!fs.existsSync(file)) { await row.update({ drive_status: 'failed', drive_error: 'The backup file is no longer on the server.' }); return row; }
  await row.update({ drive_status: 'pending', drive_error: null });
  try {
    const id = await drive.uploadFile(file, row.file_name);
    await row.update({ drive_status: 'uploaded', drive_file_id: id, drive_error: null });
  } catch (e) {
    await row.update({ drive_status: 'failed', drive_error: e.message });
    await alertOwner('Backup could not be copied to Google Drive', `Backup ${row.file_name} was made and tested on the server, but the copy to Google Drive failed:\n\n${e.message}\n\nOpen Settings → Database Backup to fix the Google Drive connection.`);
  }
  return row;
};

export const pruneOld = async () => {
  const s = await drive.getSettings();
  const cutoff = new Date(Date.now() - s.retention_days * DAY);
  const good = await DatabaseBackup.findAll({ where: { status: 'success', verify_status: 'passed' }, order: [['createdAt', 'DESC']], limit: MIN_KEEP, attributes: ['id'] });
  const protectedIds = good.map((g) => g.id);
  const old = await DatabaseBackup.findAll({ where: { createdAt: { [Op.lt]: cutoff }, file_deleted: false, id: { [Op.notIn]: protectedIds.length ? protectedIds : ['00000000-0000-0000-0000-000000000000'] } } });
  let removed = 0;
  for (const b of old) {
    try { if (b.file_name) fs.rmSync(path.join(backupDir(), b.file_name), { force: true }); } catch { /* ignore */ }
    if (b.drive_file_id && (await driveUsable())) { try { await drive.deleteFile(b.drive_file_id); } catch { /* keep going */ } }
    await b.update({ file_deleted: true, ...(b.drive_file_id ? { drive_file_id: null } : {}) });
    removed += 1;
  }
  await DatabaseBackup.destroy({ where: { createdAt: { [Op.lt]: new Date(Date.now() - 365 * DAY) } } }); // history older than a year
  return removed;
};

/** Backups left "running" by a crash or restart are marked failed. */
export const markStale = async () => DatabaseBackup.update(
  { status: 'failed', error: 'Interrupted — the server stopped while this backup was running.' },
  { where: { status: 'running', createdAt: { [Op.lt]: new Date(Date.now() - 2 * 3600000) } } },
);

/**
 * Makes one full backup, tests that it restores, and (if linked) copies it to Google Drive.
 * Returns the history row. Throws nothing for an ordinary failure: the row says what went wrong.
 */
export const runBackup = async ({ trigger = 'manual', reason = null, userId = null, existingRow = null } = {}) => {
  let row = existingRow || await DatabaseBackup.create({ trigger, reason, triggered_by: userId, status: 'running' });
  const t0 = Date.now();
  const locked = await withLock(async () => {
    try {
      const fileName = `edutrack-backup-${stamp()}-${row.id.slice(0, 6)}.sql.gz`;
      const file = path.join(backupDir(), fileName); // creating the folder can fail too — that is a failed backup, not a crash
      const d = await createDump(file, { label: `${trigger}${reason ? `: ${reason}` : ''}` });
      await row.update({ file_name: fileName, size_bytes: d.bytes, sha256: d.sha256, table_count: d.manifest.table_count, row_count: d.manifest.total_rows, warnings: d.manifest.warnings?.length ? d.manifest.warnings : null });

      const v = await verifyBackupFile(file, { expectedSha256: d.sha256 });
      await row.update({
        verify_status: v.ok ? 'passed' : 'failed', verified_at: new Date(),
        verify_detail: { ok: v.ok, seconds: v.seconds, tables: v.tables, rows: v.rows, problems: v.problems.slice(0, 20), warnings: v.warnings || null },
      });
      if (!v.ok) throw new Error(`The restore test failed, so this backup cannot be trusted: ${v.problems[0] || 'unknown problem'}`);

      await row.update({ status: 'success', duration_ms: Date.now() - t0, error: null });
      if (await driveUsable()) await uploadToDrive(row); else await row.update({ drive_status: 'skipped' });
      await pruneOld();
    } catch (err) {
      await row.update({ status: 'failed', error: err.message, duration_ms: Date.now() - t0 });
      await alertOwner('Database backup FAILED', `A ${trigger.replace('_', ' ')} backup of the EduTrack database failed:\n\n${err.message}\n\nOpen Settings → Database Backup to see the details and try again.`);
    }
  });
  if (locked.busy) await row.update({ status: 'failed', error: 'Another backup was already running.', duration_ms: Date.now() - t0 });
  return row.reload();
};

/** Starts a backup and returns at once (the web page then watches the row). */
export const startBackupInBackground = async (opts) => {
  const row = await DatabaseBackup.create({ trigger: opts.trigger || 'manual', reason: opts.reason || null, triggered_by: opts.userId || null, status: 'running' });
  runBackup({ ...opts, existingRow: row }).catch((e) => console.error('Backup crashed:', e));
  return row;
};

export const verifyExisting = async (id) => {
  const row = await DatabaseBackup.findByPk(id);
  if (!row || !row.file_name || row.file_deleted) throw new Error('That backup file is no longer on the server.');
  const v = await verifyBackupFile(path.join(backupDir(), row.file_name), { expectedSha256: row.sha256 });
  await row.update({
    verify_status: v.ok ? 'passed' : 'failed', verified_at: new Date(),
    verify_detail: { ok: v.ok, seconds: v.seconds, tables: v.tables, rows: v.rows, problems: v.problems.slice(0, 20), warnings: v.warnings || null },
  });
  return row;
};

export const deleteBackup = async (id) => {
  const row = await DatabaseBackup.findByPk(id);
  if (!row) return false;
  if (row.file_name) fs.rmSync(path.join(backupDir(), row.file_name), { force: true });
  if (row.drive_file_id && (await driveUsable())) { try { await drive.deleteFile(row.drive_file_id); } catch { /* ignore */ } }
  await row.update({ file_deleted: true, drive_file_id: null });
  return true;
};

/**
 * Call this before something that is hard to undo (student promotion, a bulk import, a migration).
 * It makes a fresh, tested backup first — or reuses one made in the last few minutes. If the backup cannot be made
 * and "protect risky actions" is on (the default), it throws and the action does not run.
 */
export const ensureBackupBeforeRiskyAction = async ({ reason, userId = null }) => {
  if (runningUnderTests() || process.env.BACKUP_BEFORE_ACTIONS === 'off') return null;
  const s = await drive.getSettings();
  if (!s.protect_risky_actions) return null;
  if (!(await databaseHasData())) return null;

  const recent = await DatabaseBackup.findOne({ where: { status: 'success', verify_status: 'passed', createdAt: { [Op.gt]: new Date(Date.now() - REUSE_WITHIN_MS) } }, order: [['createdAt', 'DESC']] });
  if (recent) return recent;

  const row = await runBackup({ trigger: 'before_action', reason, userId });
  if (row.status !== 'success') {
    throw new BackupRequiredError(`For safety, EduTrack takes a backup before ${reason}, and the backup could not be made (${row.error || 'unknown reason'}). Nothing was changed. Ask the system owner to check Settings → Database Backup.`);
  }
  return row;
};

/** The daily schedule. Runs when the school-time hour has been reached and today's scheduled backup is missing. */
export const runDueBackup = async () => {
  await markStale();
  const s = await drive.getSettings();
  if (!s.enabled) return null;
  const now = localParts();
  if (now.hour < s.run_at_hour) return null;

  const todays = await DatabaseBackup.findAll({ where: { trigger: 'scheduled', createdAt: { [Op.gt]: new Date(Date.now() - 36 * 3600000) } }, order: [['createdAt', 'DESC']] });
  const doneToday = todays.some((b) => b.status === 'success' && localParts(b.createdAt).date === now.date);
  if (doneToday) return null;
  const last = todays[0];
  if (last && (last.status === 'running' || Date.now() - new Date(last.createdAt).getTime() < 30 * 60000)) return null; // running, or failed a moment ago
  const failuresToday = todays.filter((b) => b.status === 'failed' && localParts(b.createdAt).date === now.date).length;
  if (failuresToday >= 4) return null; // stop retrying; the owner has been emailed
  if (!(await databaseHasData())) return null;
  return runBackup({ trigger: 'scheduled', reason: 'daily backup' });
};

export const nextRunText = (s) => {
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(s.run_at_hour)}:00 (${TZ()})`;
};

export const sizeFor = (row) => {
  try { return row.file_name && !row.file_deleted ? fs.statSync(path.join(backupDir(), row.file_name)).size : null; } catch { return null; }
};
export const filePathFor = (row) => (row.file_name && !row.file_deleted ? path.join(backupDir(), row.file_name) : null);

/**
 * A tested backup file made WITHOUT touching the history table — for command-line tools (migrations, database
 * reset) that may run before that table exists. Returns the file path, or null when there is nothing to back up.
 * Throws if the backup cannot be made or fails its restore test.
 */
export const quickBackupToFile = async (label) => {
  if (process.env.SKIP_BACKUP === '1' || process.env.BACKUP_BEFORE_ACTIONS === 'off' || runningUnderTests()) return null;
  if (!(await databaseHasData())) return null;
  const file = path.join(backupDir(), `edutrack-backup-${stamp()}-${label.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.sql.gz`);
  const d = await createDump(file, { label });
  const v = await verifyBackupFile(file, { expectedSha256: d.sha256 });
  if (!v.ok) throw new Error(`The safety backup failed its restore test (${v.problems[0] || 'unknown'}). Nothing was changed.`);
  return { file, tables: d.manifest.table_count, rows: d.manifest.total_rows, bytes: d.bytes };
};
