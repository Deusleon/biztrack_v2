// FILE PATH: backend/src/services/subscriptionDocuments.js
/**
 * Subscription invoices and receipts as data and as PDF.
 *
 * `loadInvoiceDocumentData` is the one place that gathers everything a document needs
 * (the invoice, the plan, the school it is billed to, the receipt number and the QR codes).
 * The invoice screen reads it through the API; the emails read it directly — so a school
 * never sees one thing in the app and another in its inbox.
 *
 * The PDF is drawn by documents/subscriptionDocumentCore.js, the very same file the browser
 * uses (a test makes sure the two copies stay identical).
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import QRCode from 'qrcode';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { SubscriptionInvoice, SubscriptionPlan, Tenant, Campus } from '../models/index.js';
import { generateSubscriptionReceiptCode, generateSubscriptionPayCode } from '../utils/receiptSecurity.js';
import { getTenantDisplay } from '../utils/tenantDisplay.js';
import { formatDate } from '../utils/dateFormat.js';
import { formatNumber } from '../utils/money.js';
import { buildDoc, drawSubscriptionDocument, documentFileName } from '../documents/subscriptionDocumentCore.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const EMBLEM_PATH = path.join(here, '..', 'assets', 'edutrack-emblem.png');

/** Where the web app lives — the base of every QR link. FRONTEND_URL may list several origins. */
export const frontendOrigin = () => String(process.env.FRONTEND_URL || '').split(',')[0].trim().replace(/\/+$/, '');

/** Who the money goes to, printed at the top of every invoice and receipt. */
export const platformSeller = () => ({
  name: process.env.PLATFORM_NAME || 'EduTrack',
  lines: [
    process.env.PLATFORM_ADDRESS,
    process.env.PLATFORM_PHONE && `Tel: ${process.env.PLATFORM_PHONE}`,
    process.env.PLATFORM_EMAIL,
    process.env.PLATFORM_WEBSITE,
    process.env.PLATFORM_TIN && `TIN: ${process.env.PLATFORM_TIN}`,
  ].filter(Boolean),
});

export const platformContact = () => [process.env.PLATFORM_EMAIL, process.env.PLATFORM_PHONE].filter(Boolean).join('   |   ');

/** Everything needed to show or print one invoice or its receipt. `invoice` must include its plan. */
export const loadInvoiceDocumentData = async (invoice) => {
  const [tenant, campus] = await Promise.all([
    Tenant.findByPk(invoice.tenant_id, { attributes: ['id', 'name'] }),
    Campus.findOne({ where: { tenant_id: invoice.tenant_id }, order: [['created_at', 'ASC']] }),
  ]);
  const paid = invoice.status === 'paid';
  const unpaid = invoice.status === 'pending' || invoice.status === 'failed';
  return {
    invoice,
    school: {
      name: tenant?.name || campus?.name || 'School',
      address: [campus?.address, campus?.city, campus?.country].filter(Boolean).join(', '),
      phone: campus?.phone || '',
      email: campus?.email || '',
      logo_url: campus?.logo_url || null,
    },
    // Same digits as the invoice, so the two documents are obviously a pair.
    receipt_number: paid ? invoice.invoice_number.replace(/^INV-/, 'RCT-') : null,
    verification_code: paid ? generateSubscriptionReceiptCode(invoice) : null,
    pay_code: unpaid ? generateSubscriptionPayCode(invoice) : null,
  };
};

export const withPlan = (invoice) => (invoice.plan !== undefined ? invoice
  : SubscriptionInvoice.findByPk(invoice.id, { include: [{ model: SubscriptionPlan, as: 'plan', attributes: ['id', 'name', 'code', 'description', 'student_limit'] }] }));

/** The PDF for an invoice (kind "invoice") or its receipt (kind "receipt"), as a Buffer. */
export const renderDocumentPdf = async (kind, invoiceInput) => {
  const invoice = await withPlan(invoiceInput);
  const data = await loadInvoiceDocumentData(invoice);
  const display = await getTenantDisplay(invoice.tenant_id);
  const origin = frontendOrigin();

  const doc = buildDoc(kind, data, {
    formatDate: (d) => formatDate(d, display.date_format),
    formatNumber: (n) => formatNumber(n, display.money_decimals),
    seller: platformSeller(),
    origin,
  });

  const qr = doc.qr
    ? await QRCode.toDataURL(doc.qr.url, { errorCorrectionLevel: 'M', margin: 0, width: 360, color: { dark: '#111827', light: '#ffffff' } })
    : null;
  const emblem = `data:image/png;base64,${fs.readFileSync(EMBLEM_PATH).toString('base64')}`;

  const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4', compress: true });
  drawSubscriptionDocument(pdf, autoTable, doc, { emblem, qr, contact: platformContact() });

  return { buffer: Buffer.from(pdf.output('arraybuffer')), filename: documentFileName(doc), doc, data };
};
