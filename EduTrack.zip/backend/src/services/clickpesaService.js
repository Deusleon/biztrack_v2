/**
 * ClickPesa payment gateway.
 *
 * Flow:
 *   1. POST /third-parties/generate-token   → short-lived bearer token
 *   2. POST .../preview-ussd-push-request   → which methods can pay this
 *   3. POST .../initiate-ussd-push-request  → pushes a prompt to the phone
 *   4. Webhook, or GET .../payments/:ref    → outcome
 *
 * ⚠ VERIFY BEFORE GOING LIVE
 * Endpoint paths and field names below follow ClickPesa's published
 * third-party integration flow, but they have NOT been exercised against a
 * live account from here. Treat `testConnection()` as the first thing to
 * run: it exchanges credentials for a token and will fail loudly if any of
 * this is wrong, rather than failing silently mid-payment.
 *
 * Credentials come from the environment, not the database, because they
 * belong to the EduTrack platform (who receives the money) rather than to
 * any one school:
 *   CLICKPESA_CLIENT_ID
 *   CLICKPESA_API_KEY
 *   CLICKPESA_BASE_URL      (optional override)
 *   CLICKPESA_WEBHOOK_SECRET
 */

const BASE_URL = process.env.CLICKPESA_BASE_URL || 'https://api.clickpesa.com';

/** Tokens are short-lived; cached briefly so a checkout doesn't fetch one
 * per call, but not so long that an expired token is reused. */
let tokenCache = null;
const TOKEN_TTL_MS = 25 * 60 * 1000;

export const isClickPesaConfigured = () =>
  Boolean(process.env.CLICKPESA_CLIENT_ID && process.env.CLICKPESA_API_KEY);

const describeError = (err) => {
  const code = err?.cause?.code || err?.code;
  if (code === 'ENOTFOUND' || code === 'EAI_AGAIN') {
    return 'Could not reach ClickPesa — the API address did not resolve. Check CLICKPESA_BASE_URL and this server\'s internet access.';
  }
  if (code === 'ETIMEDOUT' || code === 'UND_ERR_CONNECT_TIMEOUT') {
    return 'Timed out connecting to ClickPesa. Check outbound network access from this server.';
  }
  if (err?.message === 'fetch failed') {
    return `Could not reach ClickPesa${code ? ` (${code})` : ''}. The request never got a response.`;
  }
  return err?.message || 'Unknown error talking to ClickPesa.';
};

const getToken = async ({ forceRefresh = false } = {}) => {
  if (!isClickPesaConfigured()) {
    throw new Error('ClickPesa is not configured. Set CLICKPESA_CLIENT_ID and CLICKPESA_API_KEY on the server.');
  }
  if (!forceRefresh && tokenCache && Date.now() - tokenCache.at < TOKEN_TTL_MS) {
    return tokenCache.token;
  }

  const response = await fetch(`${BASE_URL}/third-parties/generate-token`, {
    method: 'POST',
    headers: {
      'client-id': process.env.CLICKPESA_CLIENT_ID,
      'api-key': process.env.CLICKPESA_API_KEY,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(`ClickPesa rejected the credentials (HTTP ${response.status}). ${data.message || ''}`.trim());
  }

  // ClickPesa returns the token prefixed with "Bearer " in some responses.
  const raw = data.token || data.access_token || data.data?.token;
  if (!raw) throw new Error(`ClickPesa returned no token: ${JSON.stringify(data)}`);
  const token = String(raw).replace(/^Bearer\s+/i, '');

  tokenCache = { token, at: Date.now() };
  return token;
};

const request = async (path, { method = 'GET', body, retryOn401 = true } = {}) => {
  const token = await getToken();

  const call = async (t) => fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${t}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });

  let response = await call(token);

  // A cached token that has expired is the ordinary case, not an error.
  if (response.status === 401 && retryOn401) {
    response = await call(await getToken({ forceRefresh: true }));
  }

  const data = await response.json().catch(() => ({}));

  if (response.status === 401 || response.status === 403) {
    throw new Error('ClickPesa rejected the request credentials. Check CLICKPESA_CLIENT_ID and CLICKPESA_API_KEY.');
  }
  if (!response.ok) {
    throw new Error(data.message || data.error || `ClickPesa request failed (HTTP ${response.status}): ${JSON.stringify(data)}`);
  }

  return data;
};

/** Exchanges credentials for a token — proves the whole chain works
 * without moving any money. */
export const testClickPesaConnection = async () => {
  try {
    await getToken({ forceRefresh: true });
    return { success: true, message: 'ClickPesa credentials accepted.' };
  } catch (err) {
    throw new Error(describeError(err));
  }
};

/**
 * Asks ClickPesa which methods can settle this amount before charging.
 *
 * Worth doing first: it catches an unsupported amount or an inactive
 * collection account up front, instead of after the school has been told
 * to expect a prompt that never arrives.
 */
export const previewPayment = async ({ amount, currency = 'TZS', orderReference }) => {
  try {
    return await request('/third-parties/payments/preview-ussd-push-request', {
      method: 'POST',
      body: { amount: String(amount), currency, orderReference },
    });
  } catch (err) {
    throw new Error(describeError(err));
  }
};

/**
 * Pushes a USSD payment prompt to the payer's handset.
 *
 * `orderReference` is our invoice's reference and comes back on the
 * webhook, which is how a payment notification is matched to an invoice.
 * ClickPesa requires it to be alphanumeric.
 */
export const initiatePayment = async ({ amount, currency = 'TZS', orderReference, phoneNumber }) => {
  try {
    const data = await request('/third-parties/payments/initiate-ussd-push-request', {
      method: 'POST',
      body: { amount: String(amount), currency, orderReference, phoneNumber },
    });

    return {
      paymentId: data.id || data.paymentId || null,
      status: data.status || 'PROCESSING',
      orderReference: data.orderReference || orderReference,
      raw: data,
    };
  } catch (err) {
    throw new Error(describeError(err));
  }
};

/** Current outcome for a reference. Used to reconcile when a webhook is
 * missed — never rely on the webhook alone. */
export const getPaymentStatus = async (orderReference) => {
  try {
    const data = await request(`/third-parties/payments/${encodeURIComponent(orderReference)}`);
    const record = Array.isArray(data) ? data[0] : (data.data || data);
    return {
      status: record?.status || null,
      paymentId: record?.id || null,
      raw: data,
    };
  } catch (err) {
    throw new Error(describeError(err));
  }
};

/**
 * Maps ClickPesa's status vocabulary onto our invoice statuses.
 *
 * Anything unrecognised is treated as still processing rather than as a
 * failure — marking a payment failed that later settles would leave a
 * school locked out of a system they have paid for.
 */
export const mapPaymentStatus = (clickPesaStatus) => {
  const status = String(clickPesaStatus || '').toUpperCase();
  if (['SUCCESS', 'SETTLED', 'COMPLETED', 'PAID'].includes(status)) return 'paid';
  if (['FAILED', 'REJECTED', 'CANCELLED', 'REVERSED'].includes(status)) return 'failed';
  return 'processing';
};
