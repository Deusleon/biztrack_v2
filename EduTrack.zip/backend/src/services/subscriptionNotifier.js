// FILE PATH: backend/src/services/subscriptionNotifier.js
/**
 * Emails about a school's EduTrack subscription:
 *   - the INVOICE (with its PDF) when one is created,
 *   - the RECEIPT (with its PDF) when a payment is confirmed,
 *   - REMINDERS before the subscription ends, and when it has locked.
 *
 * They go to the school's administrators (and the school's own contact email, if it has
 * one) under the SYSTEM sender (system_from_email / system_from_name on the school's email
 * gateway). If the school's gateway cannot send, the platform's own mail server is used, so a
 * misconfigured school SMTP never stops an invoice or a lock notice from arriving.
 *
 * Nothing here may break a payment or a request: every function catches its own errors,
 * records what happened in the audit log, and returns a plain result.
 */
import { User, Tenant, EmailGatewaySettings } from '../models/index.js';
import { sendEmail } from './emailService.js';
import { renderDocumentPdf, frontendOrigin, loadInvoiceDocumentData, withPlan } from './subscriptionDocuments.js';
import { getTenantDisplay } from '../utils/tenantDisplay.js';
import { formatNumber } from '../utils/money.js';
import { formatDate } from '../utils/dateFormat.js';
import { logSystemEvent } from '../middleware/auditLog.js';

const NAVY = '#0A3C8C';
const GREEN = '#3E9B2C';
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/** Who should hear about this school's subscription. */
export const billingRecipients = async (tenantId) => {
  const [admins, tenant] = await Promise.all([
    User.findAll({ where: { tenant_id: tenantId, role: 'admin', status: 'active' }, attributes: ['email'] }),
    Tenant.findByPk(tenantId, { attributes: ['name', 'email'] }),
  ]);
  const emails = new Set();
  admins.forEach((a) => { if (a.email && /^\S+@\S+\.\S+$/.test(a.email)) emails.add(a.email.toLowerCase()); });
  if (tenant?.email && /^\S+@\S+\.\S+$/.test(tenant.email)) emails.add(tenant.email.toLowerCase());
  return { emails: [...emails], schoolName: tenant?.name || 'your school' };
};

const button = (href, label, color = NAVY) => `<a href="${esc(href)}" style="display:inline-block;background:${color};color:#ffffff;text-decoration:none;font-weight:700;font-size:14px;padding:12px 26px;border-radius:4px">${esc(label)}</a>`;

const rows = (pairs) => `<table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;margin:16px 0">${pairs.map(([k, v]) => `<tr><td style="padding:8px 0;border-bottom:1px solid #e5e7eb;color:#6b7280;font-size:13px;width:38%">${esc(k)}</td><td style="padding:8px 0;border-bottom:1px solid #e5e7eb;color:#111827;font-size:13px;font-weight:700">${esc(v)}</td></tr>`).join('')}</table>`;

/** One branded frame for every subscription email. */
const layout = ({ heading, intro, details = '', actions = '', note = '' }) => `<!doctype html><html><body style="margin:0;background:#f3f4f6;font-family:Arial,Helvetica,sans-serif">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px 12px">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:6px;overflow:hidden">
<tr><td style="background:${NAVY};padding:20px 28px"><span style="color:#ffffff;font-size:20px;font-weight:800">EduTrack</span><span style="color:#bfd3f2;font-size:12px"> &nbsp;School Management System</span></td></tr>
<tr><td style="padding:28px;color:#1f2937;font-size:14px;line-height:1.6">
<h1 style="margin:0 0 12px;font-size:20px;color:${NAVY}">${esc(heading)}</h1>
<p style="margin:0 0 4px">${intro}</p>
${details}
<p style="margin:22px 0">${actions}</p>
${note ? `<p style="margin:0;color:#6b7280;font-size:12px">${note}</p>` : ''}
</td></tr>
<tr><td style="background:#f9fafb;padding:14px 28px;color:#9ca3af;font-size:11px">This message was sent automatically by EduTrack about your school's subscription. Please do not reply to it.</td></tr>
</table></td></tr></table></body></html>`;

const toText = (html) => html
  .replace(/<a [^>]*href="([^"]+)"[^>]*>([^<]*)<\/a>/g, '$2: $1')
  .replace(/<\/(p|tr|h1|div)>/g, '\n').replace(/<br\s*\/?>/g, '\n').replace(/<[^>]+>/g, '')
  .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
  .replace(/\n{3,}/g, '\n\n').trim();

/** Sends one email to a school's billing contacts and writes down the outcome. */
const deliver = async ({ tenantId, subject, html, attachments, event, resourceId }) => {
  try {
    const { emails } = await billingRecipients(tenantId);
    if (emails.length === 0) {
      await logSystemEvent({ tenantId, title: `${event}: not emailed, the school has no administrator email`, resourceId, reason: 'no_recipient' });
      return { sent: false, reason: 'no_recipient' };
    }
    const message = { to: emails.join(', '), subject, html, text: toText(html), attachments, purpose: 'system' };
    const gateway = await EmailGatewaySettings.findOne({ where: { tenant_id: tenantId } });
    let result = await sendEmail(message, gateway);
    if (!result.success && gateway?.is_active) result = await sendEmail(message, null); // the platform's own mail server
    await logSystemEvent({
      tenantId,
      title: result.success ? `${event}: emailed to ${emails.length} address${emails.length === 1 ? '' : 'es'}` : `${event}: email could not be sent`,
      resourceId,
      reason: result.success ? null : result.error,
    });
    return { sent: !!result.success, recipients: emails, error: result.error };
  } catch (error) {
    console.error('Subscription email error:', error);
    await logSystemEvent({ tenantId, title: `${event}: email could not be sent`, resourceId, reason: error.message });
    return { sent: false, error: error.message };
  }
};

const formatters = async (tenantId) => {
  const d = await getTenantDisplay(tenantId);
  return { money: (n, c = 'TZS') => `${c} ${formatNumber(n, d.money_decimals)}`, date: (x) => formatDate(x, d.date_format) };
};

/** The invoice, with its PDF, the moment it is created. */
export const emailInvoiceCreated = async (invoiceInput) => {
  try {
    const invoice = await withPlan(invoiceInput);
    const { money, date } = await formatters(invoice.tenant_id);
    const origin = frontendOrigin();
    const data = await loadInvoiceDocumentData(invoice);
    const pdf = await renderDocumentPdf('invoice', invoice);
    const payLink = data.pay_code ? `${origin}/pay/${invoice.invoice_number}/${data.pay_code}` : `${origin}/subscription`;
    const html = layout({
      heading: `Invoice ${invoice.invoice_number}`,
      intro: `An invoice was created for <strong>${esc(data.school.name)}</strong>. The PDF is attached.`,
      details: rows([
        ['Plan', `${invoice.plan?.name || 'Subscription'} (${invoice.billing_cycle})`],
        ['Service period', `${date(invoice.period_start)} to ${date(invoice.period_end)}`],
        ['Amount due', money(invoice.total, invoice.currency)],
      ]),
      actions: `${button(payLink, 'Pay now', GREEN)} &nbsp; ${button(`${origin}/subscription/invoices/${invoice.invoice_number}`, 'View invoice')}`,
      note: 'The subscription starts as soon as the payment is confirmed. "Pay now" opens a page where anyone at the school can pay with mobile money; no sign-in is needed.',
    });
    return await deliver({
      tenantId: invoice.tenant_id, subject: `Invoice ${invoice.invoice_number}: ${money(invoice.total, invoice.currency)} (${invoice.plan?.name || 'subscription'})`,
      html, attachments: [{ filename: pdf.filename, content: pdf.buffer, contentType: 'application/pdf' }],
      event: `Invoice ${invoice.invoice_number}`, resourceId: invoice.id,
    });
  } catch (error) {
    console.error('Invoice email error:', error);
    return { sent: false, error: error.message };
  }
};

/** The receipt, with its PDF, when a payment is confirmed. */
export const emailReceipt = async (invoiceInput) => {
  try {
    const invoice = await withPlan(invoiceInput);
    const { money, date } = await formatters(invoice.tenant_id);
    const origin = frontendOrigin();
    const data = await loadInvoiceDocumentData(invoice);
    const pdf = await renderDocumentPdf('receipt', invoice);
    const html = layout({
      heading: 'Payment received. Thank you!',
      intro: `We received your payment for <strong>${esc(data.school.name)}</strong>. Your receipt is attached.`,
      details: rows([
        ['Receipt No.', data.receipt_number],
        ['Plan', `${invoice.plan?.name || 'Subscription'} (${invoice.billing_cycle})`],
        ['Amount received', money(invoice.total, invoice.currency)],
        ['Subscription active until', date(invoice.period_end)],
      ]),
      actions: button(`${origin}/verify-subscription-receipt/${invoice.invoice_number}/${data.verification_code}`, 'Verify this receipt'),
      note: `Anyone can confirm the receipt is genuine with the QR code on it, or with receipt number ${esc(data.receipt_number)} and verification code ${esc(data.verification_code)}.`,
    });
    return await deliver({
      tenantId: invoice.tenant_id, subject: `Payment received: receipt ${data.receipt_number} (${money(invoice.total, invoice.currency)})`,
      html, attachments: [{ filename: pdf.filename, content: pdf.buffer, contentType: 'application/pdf' }],
      event: `Receipt ${data.receipt_number}`, resourceId: invoice.id,
    });
  } catch (error) {
    console.error('Receipt email error:', error);
    return { sent: false, error: error.message };
  }
};

export const REMINDERS = {
  d7: { heading: 'Your EduTrack subscription ends in 7 days', lead: 'ends in 7 days', color: NAVY },
  d3: { heading: 'Your EduTrack subscription ends in 3 days', lead: 'ends in 3 days', color: '#C96F08' },
  d0: { heading: 'Your EduTrack subscription has ended', lead: 'has ended', color: '#C96F08' },
  locked: { heading: 'EduTrack is now locked', lead: 'ended and the grace period has passed', color: '#B91C1C' },
};

/** kind: d7 | d3 | d0 | locked. `subscription` needs its plan name for the message. */
export const emailSubscriptionReminder = async (tenantId, subscription, kind, planName) => {
  try {
    const r = REMINDERS[kind];
    if (!r) return { sent: false, reason: 'unknown_reminder' };
    const { date } = await formatters(tenantId);
    const { schoolName } = await billingRecipients(tenantId);
    const origin = frontendOrigin();
    const locked = kind === 'locked';
    const html = layout({
      heading: r.heading,
      intro: `The EduTrack subscription for <strong>${esc(schoolName)}</strong> ${r.lead}.`,
      details: rows([
        ['Plan', planName || '—'],
        [kind === 'd7' || kind === 'd3' ? 'Ends on' : 'Ended on', date(subscription.ends_at)],
        ...(locked ? [] : [['Grace period after that', `${subscription.grace_days} day${Number(subscription.grace_days) === 1 ? '' : 's'}`]]),
      ]),
      actions: button(`${origin}/subscription`, locked ? 'Pay to unlock EduTrack' : 'Renew now', r.color),
      note: locked
        ? 'Everything except the Subscription page is closed until a payment is confirmed. All your data is kept safe and is available again straight away once you pay.'
        : 'Renew before it ends so nobody at the school is interrupted. If the subscription lapses, EduTrack locks after the grace period until a payment is confirmed.',
    });
    return await deliver({ tenantId, subject: r.heading, html, event: `Reminder "${r.heading}"`, resourceId: subscription.id });
  } catch (error) {
    console.error('Reminder email error:', error);
    return { sent: false, error: error.message };
  }
};
