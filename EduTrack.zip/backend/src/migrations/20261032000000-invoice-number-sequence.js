// FILE PATH: backend/src/migrations/20261032000000-invoice-number-sequence.js
/**
 * 20261032000000-invoice-number-sequence.js
 *
 * Invoice numbers now come from a sequence, so they are never reused when invoices are deleted
 * (see utils/invoiceNumber.js). The sequence starts after the highest number already issued.
 * Safe to run twice; `down` drops the sequence.
 */
const SQL = `
CREATE SEQUENCE IF NOT EXISTS subscription_invoice_number_seq;
DO $$
DECLARE m bigint;
BEGIN
  SELECT COALESCE(MAX(CAST(substring(invoice_number from '^INV-[0-9]{4}-([0-9]+)$') AS bigint)), 0)
    INTO m FROM subscription_invoices;
  IF m > 0 AND m >= (SELECT CASE WHEN is_called THEN last_value + 1 ELSE last_value END FROM subscription_invoice_number_seq) THEN
    PERFORM setval('subscription_invoice_number_seq', m, true);
  END IF;
END $$;`;

export async function up(queryInterface, Sequelize, transaction) {
  await queryInterface.sequelize.query(SQL, { transaction });
}

export async function down(queryInterface, Sequelize, transaction) {
  await queryInterface.sequelize.query('DROP SEQUENCE IF EXISTS subscription_invoice_number_seq', { transaction });
}
