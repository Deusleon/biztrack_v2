// FILE PATH: backend/src/migrations/20261035000000-notification-audience.js
/**
 * 20261035000000-notification-audience.js
 *
 * Settings → Notifications now lets a school choose, for each notification, WHO is notified (the parent, the finance
 * office, both…) and on which channels. This adds `notification_settings.audience` ({ party: [channels] }) and carries every
 * school's existing choices across so nobody's notifications change by themselves:
 *
 *   - "Payment Received (Staff Copy)" is folded into "Payment Recorded" as its accountants-and-admins party;
 *   - "Admission Completed (Parent Notice)" is folded into "New Student Admitted" as its parent party;
 *   - every other saved event keeps its on/off and its channels, now stored per party.
 *
 * The party tables below are a frozen copy of what notificationEvents.js said when this was written, so this migration
 * keeps meaning the same thing even after the catalogue changes later.
 */
import crypto from 'crypto';

const EVENTS = {
  payment_recorded: [['family', true, ['in_app']], ['staff', true, ['in_app']]],
  exam_results_published: [['family', true, ['in_app']]],
  timetable_published: [['teachers', true, ['in_app']], ['students', true, ['in_app']]],
  fee_balance_reminder: [['family', true, ['in_app']]],
  student_admitted: [['family', true, ['sms']], ['admins', true, ['in_app']]],
  staff_added: [['admins', true, ['in_app']], ['hr', true, ['in_app']]],
  leave_request_submitted: [['approvers', true, ['in_app']], ['requester', false, ['in_app']]],
  leave_request_decided: [['requester', true, ['in_app']], ['admins', false, ['in_app']]],
  expense_recorded: [['accountants', true, ['in_app']], ['admins', true, ['in_app']]],
  book_overdue: [['librarian', true, ['in_app']], ['borrower', false, ['in_app']]],
};
// old event → [new event, the party it becomes, the new event's party it was merged beside]
const FOLDED = { payment_received_staff: ['payment_recorded', 'staff'], admission_completed: ['student_admitted', 'family'] };
const DEFAULT_ENABLED = true;
const DEFAULT_CHANNELS = { payment_received_staff: ['in_app'], admission_completed: ['sms'], payment_recorded: ['in_app'], student_admitted: ['in_app'] };

export async function up(queryInterface, Sequelize, transaction) {
  const { sequelize } = queryInterface;
  const columns = await queryInterface.describeTable('notification_settings');
  if (!columns.audience) await queryInterface.addColumn('notification_settings', 'audience', { type: Sequelize.JSONB, allowNull: true }, { transaction });

  // Safe to run twice: rows that already have an audience were converted before and are left alone.
  const [rows] = await sequelize.query('SELECT tenant_id, event_key, enabled, channels, audience FROM notification_settings', { transaction });
  const byTenant = new Map();
  rows.forEach((r) => { if (!byTenant.has(r.tenant_id)) byTenant.set(r.tenant_id, new Map()); byTenant.get(r.tenant_id).set(r.event_key, r); });

  const write = async (tenantId, key, enabled, audience, channels) => {
    const union = [...new Set(Object.values(audience).flat())];
    await sequelize.query(
      `INSERT INTO notification_settings (id, tenant_id, event_key, enabled, channels, audience, created_at, updated_at)
       VALUES (:id, :tenantId, :key, :enabled, CAST(:channels AS jsonb), CAST(:audience AS jsonb), NOW(), NOW())
       ON CONFLICT (tenant_id, event_key) DO UPDATE SET enabled = :enabled, channels = CAST(:channels AS jsonb), audience = CAST(:audience AS jsonb), updated_at = NOW()`,
      { replacements: { id: crypto.randomUUID(), tenantId, key, enabled, channels: JSON.stringify(channels || union), audience: JSON.stringify(audience) }, transaction },
    );
  };

  for (const [tenantId, events] of byTenant) {
    for (const [key, parties] of Object.entries(EVENTS)) {
      const own = events.get(key);
      const foldedFrom = Object.entries(FOLDED).find(([, [into]]) => into === key)?.[0];
      const folded = foldedFrom ? events.get(foldedFrom) : null;
      if (!own && !folded) continue; // nothing was ever saved: defaults still apply
      if (own?.audience) continue;   // already converted

      const ownEnabled = own ? own.enabled : DEFAULT_ENABLED;
      const ownChannels = own?.channels?.length ? own.channels : DEFAULT_CHANNELS[key];
      const audience = {};
      parties.forEach(([party, on, defaults]) => {
        const isFoldedParty = foldedFrom && FOLDED[foldedFrom][1] === party;
        if (isFoldedParty) {
          const en = folded ? folded.enabled : DEFAULT_ENABLED;
          const ch = folded?.channels?.length ? folded.channels : DEFAULT_CHANNELS[foldedFrom];
          if (en) audience[party] = ch;
        } else if (on && ownEnabled) {
          audience[party] = ownChannels?.length ? ownChannels : defaults;
        }
      });
      const anyOn = Object.keys(audience).length > 0;
      // Everything was off: keep the event off but remember the defaults, so switching it back on restores sensible choices.
      const finalAudience = anyOn ? audience : Object.fromEntries(parties.filter(([, on]) => on).map(([p, , d]) => [p, d]));
      await write(tenantId, key, anyOn, finalAudience, null);
    }
    for (const old of Object.keys(FOLDED)) await sequelize.query('DELETE FROM notification_settings WHERE tenant_id = :tenantId AND event_key = :old', { replacements: { tenantId, old }, transaction });
  }
}

export async function down(queryInterface, Sequelize, transaction) {
  await queryInterface.removeColumn('notification_settings', 'audience', { transaction });
}
