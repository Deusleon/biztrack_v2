// FILE PATH: backend/src/migrations/20261022000000-messages-selected-contacts.js
/**
 * 20261022000000-messages-selected-contacts.js
 *
 * Adds a seventh `recipient_type` to messages: 'selected_contacts'.
 *
 * Compose → Custom Numbers can now be filled by ticking contacts from the
 * saved contact list instead of typing numbers one by one. Those sends are
 * recorded as 'selected_contacts' (the ids of the ticked contacts are what
 * gets resolved), so message history can tell them apart from typed numbers.
 *
 * Safe to run twice (IF NOT EXISTS). Postgres cannot remove an enum value,
 * so `down` is a no-op — a leftover unused value is harmless.
 */
export async function up(queryInterface, Sequelize, transaction) {
  await queryInterface.sequelize.query(
    "ALTER TYPE enum_messages_recipient_type ADD VALUE IF NOT EXISTS 'selected_contacts'",
    { transaction },
  );
}

export async function down() {
  // Intentionally empty — see header.
}
