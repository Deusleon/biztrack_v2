// FILE PATH: backend/src/migrations/20261030000000-subscription-reminders.js
/**
 * 20261030000000-subscription-reminders.js
 *
 * Adds `subscriptions.reminders_sent` (JSONB, default {}): which expiry reminders have
 * already been sent for the CURRENT paid window, so the daily job never sends the same
 * reminder twice and starts again after the school renews.
 *
 *   { "window": "2026-11-27T00:00:00.000Z",   // the ends_at the reminders belong to
 *     "d7": "2026-11-20T06:00:00.000Z",        // when each was sent
 *     "d3": "...", "d0": "...", "locked": "..." }
 *
 * Safe to run twice; `down` removes the column.
 */
export async function up(queryInterface, Sequelize, transaction) {
  await queryInterface.sequelize.query(
    "ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS reminders_sent JSONB NOT NULL DEFAULT '{}'::jsonb",
    { transaction },
  );
}

export async function down(queryInterface, Sequelize, transaction) {
  await queryInterface.sequelize.query('ALTER TABLE subscriptions DROP COLUMN IF EXISTS reminders_sent', { transaction });
}
