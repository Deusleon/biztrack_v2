// FILE PATH: backend/src/migrations/20261033000000-database-backups.js
/**
 * 20261033000000-database-backups.js
 *
 * Two small tables for the automatic full-database backup (services/backup):
 *   database_backup_settings  one row: schedule, retention, "back up before risky actions", Google Drive link
 *   database_backups          one row per backup attempt: when, why, size, restore-test result, Drive upload
 * Safe to run twice; `down` drops both.
 */
export async function up(queryInterface, Sequelize, transaction) {
  const { DataTypes } = Sequelize;
  const tables = (await queryInterface.showAllTables()).map((t) => (typeof t === 'string' ? t : t.tableName));

  if (!tables.includes('database_backup_settings')) {
    await queryInterface.createTable('database_backup_settings', {
      id: { type: DataTypes.INTEGER, primaryKey: true, defaultValue: 1 },
      enabled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
      run_at_hour: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 2 },
      retention_days: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 14 },
      protect_risky_actions: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
      drive_enabled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
      drive_client_id: { type: DataTypes.TEXT, allowNull: true },
      drive_client_secret_enc: { type: DataTypes.TEXT, allowNull: true },
      drive_refresh_token_enc: { type: DataTypes.TEXT, allowNull: true },
      drive_account_email: { type: DataTypes.STRING, allowNull: true },
      drive_folder_id: { type: DataTypes.STRING, allowNull: true },
      drive_connected_at: { type: DataTypes.DATE, allowNull: true },
      drive_last_error: { type: DataTypes.TEXT, allowNull: true },
      created_at: { type: DataTypes.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') },
      updated_at: { type: DataTypes.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') },
    }, { transaction });
  }

  if (!tables.includes('database_backups')) {
    await queryInterface.createTable('database_backups', {
      id: { type: DataTypes.UUID, primaryKey: true },
      trigger: { type: DataTypes.STRING(20), allowNull: false, defaultValue: 'manual' },
      reason: { type: DataTypes.TEXT, allowNull: true },
      status: { type: DataTypes.STRING(20), allowNull: false, defaultValue: 'running' },
      file_name: { type: DataTypes.STRING, allowNull: true },
      size_bytes: { type: DataTypes.BIGINT, allowNull: true },
      sha256: { type: DataTypes.STRING(64), allowNull: true },
      table_count: { type: DataTypes.INTEGER, allowNull: true },
      row_count: { type: DataTypes.BIGINT, allowNull: true },
      duration_ms: { type: DataTypes.INTEGER, allowNull: true },
      verify_status: { type: DataTypes.STRING(20), allowNull: false, defaultValue: 'pending' },
      verify_detail: { type: DataTypes.JSONB, allowNull: true },
      verified_at: { type: DataTypes.DATE, allowNull: true },
      drive_status: { type: DataTypes.STRING(20), allowNull: false, defaultValue: 'skipped' },
      drive_file_id: { type: DataTypes.STRING, allowNull: true },
      drive_error: { type: DataTypes.TEXT, allowNull: true },
      error: { type: DataTypes.TEXT, allowNull: true },
      warnings: { type: DataTypes.JSONB, allowNull: true },
      file_deleted: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
      triggered_by: { type: DataTypes.UUID, allowNull: true },
      created_at: { type: DataTypes.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') },
      updated_at: { type: DataTypes.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') },
    }, { transaction });
    await queryInterface.addIndex('database_backups', ['created_at'], { transaction });
  }
}

export async function down(queryInterface, Sequelize, transaction) {
  await queryInterface.dropTable('database_backups', { transaction });
  await queryInterface.dropTable('database_backup_settings', { transaction });
}
