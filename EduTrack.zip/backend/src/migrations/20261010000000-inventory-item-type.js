// FILE PATH: backend/src/migrations/20261010000000-inventory-item-type.js
/**
 * 20261010000000-inventory-item-type.js
 *
 * Splits inventory into two kinds of stock:
 *   asset       — fixed assets (desks, projectors...): condition matters
 *   consumable  — things that run down (chalk, books...): quantity and
 *                 reorder level matter
 *
 * Adds inventory_items.item_type and sets it for the rows that already
 * exist. Existing items were never labelled, so they are sorted by the one
 * signal the data has: an item with a reorder level was being watched for
 * running low, so it becomes a consumable; an item without one becomes an
 * asset. That is a best guess — items can be re-typed from the Edit dialog
 * — but it keeps every item that already raised low-stock alerts doing so.
 *
 * Safe to run twice (every step checks first).
 */
export async function up(queryInterface, Sequelize, transaction) {
  const sequelize = queryInterface.sequelize;
  const run = (sql) => sequelize.query(sql, { transaction });

  await run(`DO $$ BEGIN
    CREATE TYPE "enum_inventory_items_item_type" AS ENUM ('asset', 'consumable');
  EXCEPTION WHEN duplicate_object THEN NULL; END $$;`);

  const [cols] = await run(`SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'inventory_items' AND column_name = 'item_type'`);
  if (cols.length === 0) {
    await run(`ALTER TABLE "inventory_items"
      ADD COLUMN "item_type" "enum_inventory_items_item_type" NOT NULL DEFAULT 'consumable'`);
    await run(`UPDATE "inventory_items" SET "item_type" = 'asset' WHERE "reorder_level" IS NULL`);
    // An asset has no reorder level — it would only ever show a meaningless alert.
    await run(`UPDATE "inventory_items" SET "reorder_level" = NULL WHERE "item_type" = 'asset'`);
  }

  await run(`CREATE INDEX IF NOT EXISTS "inventory_items_item_type" ON "inventory_items" ("item_type")`);
}

export async function down(queryInterface, Sequelize, transaction) {
  const run = (sql) => queryInterface.sequelize.query(sql, { transaction });
  await run(`DROP INDEX IF EXISTS "inventory_items_item_type"`);
  await run(`ALTER TABLE "inventory_items" DROP COLUMN IF EXISTS "item_type"`);
  await run(`DROP TYPE IF EXISTS "enum_inventory_items_item_type"`);
}
