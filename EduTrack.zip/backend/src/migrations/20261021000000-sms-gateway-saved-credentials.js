// FILE PATH: backend/src/migrations/20261021000000-sms-gateway-saved-credentials.js
/**
 * 20261021000000-sms-gateway-saved-credentials.js
 *
 * Adds `saved_credentials` to sms_gateway_settings: one remembered set of
 * credentials per SMS provider, so switching gateway no longer means typing the
 * previous provider's key in again (see utils/smsCredentialVault.js).
 *
 * The credentials already stored on each row are copied under the provider they
 * belong to, so nothing configured today is lost or has to be re-entered.
 *
 * Safe to run twice.
 */
export async function up(queryInterface, Sequelize, transaction) {
  const run = (sql) => queryInterface.sequelize.query(sql, { transaction });

  await run(`ALTER TABLE "sms_gateway_settings"
    ADD COLUMN IF NOT EXISTS "saved_credentials" JSONB NOT NULL DEFAULT '{}'::jsonb`);

  await run(`UPDATE "sms_gateway_settings"
    SET "saved_credentials" = jsonb_build_object(
      "provider"::text,
      jsonb_build_object('api_key', "api_key", 'api_secret', "api_secret", 'sender_id', "sender_id")
    )
    WHERE "provider" <> 'simulated'
      AND ("api_key" IS NOT NULL OR "api_secret" IS NOT NULL OR "sender_id" IS NOT NULL)
      AND "saved_credentials" = '{}'::jsonb`);
}

export async function down(queryInterface, Sequelize, transaction) {
  await queryInterface.sequelize.query(
    `ALTER TABLE "sms_gateway_settings" DROP COLUMN IF EXISTS "saved_credentials"`,
    { transaction },
  );
}