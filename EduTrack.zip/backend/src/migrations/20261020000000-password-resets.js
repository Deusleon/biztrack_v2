// FILE PATH: backend/src/migrations/20261020000000-password-resets.js
/**
 * 20261020000000-password-resets.js
 *
 * The table behind "Forgot password": one row per reset request, holding a keyed
 * hash of the 6-digit code (never the code), when it expires, how many wrong
 * guesses it has had, and when it was used. Only the forgot/reset endpoints read
 * it, so nothing else depends on this migration having run.
 *
 * Safe to run twice.
 */
export async function up(queryInterface, Sequelize, transaction) {
  const run = (sql) => queryInterface.sequelize.query(sql, { transaction });
  await run(`CREATE TABLE IF NOT EXISTS "password_resets" (
    "id" UUID PRIMARY KEY,
    "user_id" UUID NOT NULL REFERENCES "users" ("id") ON DELETE CASCADE,
    "code_hash" VARCHAR(255) NOT NULL,
    "expires_at" TIMESTAMP WITH TIME ZONE NOT NULL,
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "used_at" TIMESTAMP WITH TIME ZONE,
    "channels" JSONB NOT NULL DEFAULT '[]'::jsonb,
    "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  )`);
  await run(`CREATE INDEX IF NOT EXISTS "password_resets_user_id" ON "password_resets" ("user_id")`);
}

export async function down(queryInterface, Sequelize, transaction) {
  await queryInterface.sequelize.query(`DROP TABLE IF EXISTS "password_resets"`, { transaction });
}
