// FILE PATH: backend/src/migrations/20261034000000-swalasms-provider.js
/**
 * 20261034000000-swalasms-provider.js
 *
 * Adds SwalaSMS (https://swalasms.com) to the list of SMS gateways a school can choose:
 * `sms_gateway_settings.provider` gains the value 'swalasms'.
 *
 * Safe to run twice (IF NOT EXISTS). Postgres cannot remove an enum value, so `down` is a no-op —
 * a leftover unused value is harmless.
 */
export async function up(queryInterface, Sequelize, transaction) {
  await queryInterface.sequelize.query(
    "ALTER TYPE enum_sms_gateway_settings_provider ADD VALUE IF NOT EXISTS 'swalasms'",
    { transaction },
  );
}

export async function down() {
  // Intentionally empty — see header.
}
