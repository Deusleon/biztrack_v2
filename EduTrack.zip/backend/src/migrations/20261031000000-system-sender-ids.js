// FILE PATH: backend/src/migrations/20261031000000-system-sender-ids.js
/**
 * 20261031000000-system-sender-ids.js
 *
 * Two senders per gateway, for SMS and for email:
 *
 *   sender_id / from_*           the school's ordinary sender — messages people send, and
 *                                notices like admissions and payment alerts
 *   system_sender_id /           the PLATFORM's sender — password-reset codes and
 *   system_from_email,_name      subscription messages
 *
 * Both new columns are optional. Until one is set, system messages use the ordinary sender,
 * exactly as before. Safe to run twice; `down` removes the columns.
 */
export async function up(queryInterface, Sequelize, transaction) {
  await queryInterface.sequelize.query('ALTER TABLE sms_gateway_settings ADD COLUMN IF NOT EXISTS system_sender_id VARCHAR(255)', { transaction });
  await queryInterface.sequelize.query('ALTER TABLE email_gateway_settings ADD COLUMN IF NOT EXISTS system_from_email VARCHAR(255)', { transaction });
  await queryInterface.sequelize.query('ALTER TABLE email_gateway_settings ADD COLUMN IF NOT EXISTS system_from_name VARCHAR(255)', { transaction });
}

export async function down(queryInterface, Sequelize, transaction) {
  await queryInterface.sequelize.query('ALTER TABLE sms_gateway_settings DROP COLUMN IF EXISTS system_sender_id', { transaction });
  await queryInterface.sequelize.query('ALTER TABLE email_gateway_settings DROP COLUMN IF EXISTS system_from_email', { transaction });
  await queryInterface.sequelize.query('ALTER TABLE email_gateway_settings DROP COLUMN IF EXISTS system_from_name', { transaction });
}
