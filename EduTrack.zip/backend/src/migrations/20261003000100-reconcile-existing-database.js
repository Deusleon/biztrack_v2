// FILE PATH: backend/src/migrations/20261003000100-reconcile-existing-database.js
/**
 * 20261003000100-reconcile-existing-database.js
 *
 * Tidies a database that was built the OLD way (sequelize.sync + the first
 * hand-written migrations) so that it matches 20261003000000-initial-schema.js.
 * On a database created by the initial schema it finds nothing to do and
 * changes nothing, so it is safe in both cases and safe to run twice.
 *
 * It does three things, and only these:
 *
 * 1) Drops DUPLICATE unique constraints.
 *    Every time the server started with NODE_ENV=development, server.js ran
 *    sequelize.sync({ alter: true }), and on PostgreSQL that adds one more
 *    copy of every `unique: true` constraint each time. A live database had
 *    users(email) x66, tenants(slug) x69, students(admission_number) x63 and
 *    four more columns at x29 — about 310 identical indexes that PostgreSQL
 *    must update on every INSERT/UPDATE of those tables, for no benefit.
 *    One copy of each is kept, so uniqueness is still enforced. A constraint
 *    that a foreign key depends on is never dropped.
 *
 * 2) Creates two indexes the models declare but older databases lack
 *    (class_subjects.teacher_id, timetable_entries.subject_id), if missing.
 *
 * 3) Makes book_issues.fine_waived_by and fee_structure_students.assigned_by
 *    ON DELETE SET NULL. They record WHO did something; deleting that user
 *    used to be refused by the database. The foreign key is found by its
 *    column, not by name, because sync() and the migrations named it
 *    differently.
 *
 * Not reversible on purpose: restoring duplicate constraints would only
 * recreate the problem. down() does nothing.
 */

const EXTRA_INDEXES = [
  ['class_subjects_teacher_id', 'class_subjects', 'teacher_id'],
  ['timetable_entries_subject_id', 'timetable_entries', 'subject_id'],
];

const SET_NULL_FKS = [
  ['book_issues', 'fine_waived_by', 'users', 'id'],
  ['fee_structure_students', 'assigned_by', 'users', 'id'],
];

export async function up(queryInterface, Sequelize, transaction) {
  const sequelize = queryInterface.sequelize;
  const run = (sql, replacements) => sequelize.query(sql, { transaction, replacements });
  const rows = async (sql, replacements) => (await run(sql, replacements))[0];

  // ── 1) duplicate unique constraints ──────────────────────────────────────
  const uniques = await rows(`
    SELECT cl.relname AS tbl, c.conname AS name, c.conkey::text AS cols,
           EXISTS (SELECT 1 FROM pg_constraint f
                   WHERE f.contype = 'f' AND f.conindid = c.conindid) AS used_by_fk
    FROM pg_constraint c
    JOIN pg_class cl ON cl.oid = c.conrelid
    JOIN pg_namespace n ON n.oid = cl.relnamespace
    WHERE c.contype = 'u' AND n.nspname = 'public'
    ORDER BY cl.relname, c.conkey::text, length(c.conname), c.conname
  `);

  const groups = new Map();
  for (const u of uniques) {
    const key = `${u.tbl}|${u.cols}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(u);
  }

  let dropped = 0;
  for (const list of groups.values()) {
    if (list.length < 2) continue;
    // Keep one: a copy a foreign key relies on if there is one, otherwise the
    // original (shortest name, e.g. users_email_key rather than users_email_key57).
    const keep = list.find((u) => u.used_by_fk) || list[0];
    for (const u of list) {
      if (u === keep || u.used_by_fk) continue;
      await run(`ALTER TABLE "${u.tbl}" DROP CONSTRAINT "${u.name}"`);
      dropped += 1;
    }
  }
  if (dropped) console.log(`  · dropped ${dropped} duplicate unique constraint(s)`);

  // ── 2) indexes older databases are missing ───────────────────────────────
  for (const [name, table, column] of EXTRA_INDEXES) {
    await run(`CREATE INDEX IF NOT EXISTS "${name}" ON "${table}" ("${column}")`);
  }

  // ── 3) "who did it" foreign keys -> ON DELETE SET NULL ───────────────────
  for (const [table, column, refTable, refColumn] of SET_NULL_FKS) {
    const fks = await rows(`
      SELECT c.conname AS name, c.confdeltype::text AS del
      FROM pg_constraint c
      WHERE c.contype = 'f'
        AND c.conrelid = :table::regclass
        AND c.conkey = ARRAY[(SELECT attnum FROM pg_attribute
                              WHERE attrelid = :table::regclass AND attname = :column)]::int2[]
    `, { table, column });

    if (fks.length === 1 && fks[0].del === 'n') continue; // already right
    for (const fk of fks) {
      await run(`ALTER TABLE "${table}" DROP CONSTRAINT "${fk.name}"`);
    }
    await run(
      `ALTER TABLE "${table}" ADD CONSTRAINT "fk_${table}_${column}"
       FOREIGN KEY ("${column}") REFERENCES "${refTable}" ("${refColumn}")
       ON DELETE SET NULL ON UPDATE CASCADE`,
    );
    console.log(`  · ${table}.${column} is now ON DELETE SET NULL`);
  }
}

export async function down() {
  // Intentionally empty — see the header.
}
