// FILE PATH: backend/src/server.js
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import path from 'path';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { testConnection } from './config/database.js';
import { errorHandler, notFound } from './middleware/error.js';
import { auditLog } from './middleware/auditLog.js';
import { apiLimiter } from './middleware/rateLimiter.js';

// Import routes
import authRoutes from './routes/authRoutes.js';
import studentRoutes from './routes/studentRoutes.js';
import staffRoutes from './routes/staffRoutes.js';
import attendanceRoutes from './routes/attendanceRoutes.js';
import campusRoutes from './routes/campusRoutes.js';
import classRoutes from './routes/classRoutes.js';
import subjectRoutes from './routes/subjectRoutes.js';
import timetableRoutes from './routes/timetableRoutes.js';
import examRoutes from './routes/examRoutes.js';
import feeRoutes from './routes/feeRoutes.js';
import verifyRoutes from './routes/verifyRoutes.js';
import messagingRoutes from './routes/messagingRoutes.js';
import notificationRoutes from './routes/notificationRoutes.js';
import webhookRoutes from './routes/webhookRoutes.js';
import transportRoutes from './routes/transportRoutes.js';
import libraryRoutes from './routes/libraryRoutes.js';
import leaveRoutes from './routes/leaveRoutes.js';
import expenseRoutes from './routes/expenseRoutes.js';
import hostelRoutes from './routes/hostelRoutes.js';
import subscriptionRoutes from './routes/subscriptionRoutes.js';
import searchRoutes from './routes/searchRoutes.js';
import promotionRoutes from './routes/promotionRoutes.js';
import { seedSubscriptionPlans } from './utils/seedSubscriptionPlans.js';
import { startSubscriptionJobs } from './jobs/subscriptionJobs.js';
import { startBackupJobs } from './jobs/backupJobs.js';
import { startLibraryJobs } from './jobs/libraryJobs.js';
import { jsonReplacer, requireSignedFile } from './utils/signedFiles.js';
import payrollRoutes from './routes/payrollRoutes.js';
import inventoryRoutes from './routes/inventoryRoutes.js';
import analyticsRoutes from './routes/analyticsRoutes.js';
import reportsRoutes from './routes/reportsRoutes.js';
import permissionsRoutes from './routes/permissionsRoutes.js';
import documentsRoutes from './routes/documentsRoutes.js';
import settingsRoutes from './routes/settingsRoutes.js';
import backupRoutes from './routes/backupRoutes.js';
import publicRoutes from './routes/publicRoutes.js';
import admissionInquiryRoutes from './routes/admissionInquiryRoutes.js';
import contactInquiryRoutes from './routes/contactInquiryRoutes.js';

// Load environment variables
dotenv.config();

const app = express();

// Trust the first proxy hop (nginx, Render, Railway, etc.) so req.protocol
// reflects the original client scheme (https) instead of the proxy's
// internal connection (often plain http). Without this, any URL built
// from req.protocol — like uploaded file URLs — silently comes out wrong
// in most production deployments.
app.set('trust proxy', 1);

// Security middleware
// crossOriginResourcePolicy defaults to 'same-origin', which silently
// blocks <img>/<video> tags from loading files served here whenever the
// frontend runs on a different origin than the API (different port
// counts as a different origin — true for almost every local dev setup,
// e.g. :5173 vs :5000, and for most production deployments too). The
// POST that uploads the file still succeeds either way (that's a
// fetch/XHR call, governed by CORS, not this header) — only the actual
// <img src="..."> render silently fails, which is exactly the "upload
// says success but the photo never shows" symptom. 'cross-origin' here
// is what actually fixes it.
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));

// CORS configuration
// /api/v1/public/* is meant to be called from a tenant's own public
// website, which lives on a different domain than the EduTrack app and
// never sends cookies/JWTs — so it gets an open, non-credentialed origin
// instead of being locked to FRONTEND_URL. Everything else keeps the
// strict, credentialed lock. Set PUBLIC_ALLOWED_ORIGINS (comma-separated)
// to restrict the public routes to specific website domains instead of
// allowing any origin.
const publicAllowedOrigins = (process.env.PUBLIC_ALLOWED_ORIGINS || '')
  .split(',').map((s) => s.trim()).filter(Boolean);

app.use((req, res, next) => {
  const isPublicRoute = req.path.startsWith('/api/v1/public');
  const corsOptions = isPublicRoute
    ? { origin: publicAllowedOrigins.length ? publicAllowedOrigins : true, credentials: false }
    : { origin: process.env.FRONTEND_URL || 'http://localhost:5173', credentials: true };
  return cors(corsOptions)(req, res, next);
});

// Apply rate limiting to all API routes
app.use('/api/', apiLimiter);

// Body parser middleware
// The import previews receive a whole spreadsheet in one request (up to 500 rows), which is bigger than the
// default 100 KB limit — so they, and only they, get a larger one. (Everything else keeps the default.)
app.use(['/api/v1/students/bulk/preview', '/api/v1/staff/bulk/preview'], express.json({ limit: '5mb' }));
// SwalaSMS signs the exact raw JSON body, so that one webhook keeps the raw bytes for the signature check.
app.use('/api/v1/webhooks/dlr/swalasms', express.json({ verify: (req, res, buf) => { req.rawBody = buf; } }));
app.use(express.json());

// Serve uploaded files (photos, documents, receipts) — but ONLY with a valid signed link (utils/signedFiles.js):
// the API puts a short-lived signature on every file address it returns, and a bare address is refused with 403.
app.set('json replacer', jsonReplacer);
app.use('/uploads', requireSignedFile, express.static(path.resolve(process.env.UPLOAD_PATH || './uploads')));
app.use(express.urlencoded({ extended: true }));

// Logging middleware
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// Audit log middleware
app.use(auditLog);

// Health check route
app.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Server is running',
    timestamp: new Date().toISOString(),
  });
});

// API routes
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/students', studentRoutes);
app.use('/api/v1/staff', staffRoutes);
app.use('/api/v1/attendance', attendanceRoutes);
app.use('/api/v1/campus', campusRoutes);
app.use('/api/v1/classes', classRoutes);
app.use('/api/v1/subjects', subjectRoutes);
app.use('/api/v1/timetable', timetableRoutes);
app.use('/api/v1/exams', examRoutes);
app.use('/api/v1/fees', feeRoutes);
app.use('/api/v1/verify', verifyRoutes);
app.use('/api/v1/messaging', messagingRoutes);
app.use('/api/v1/notifications', notificationRoutes);
app.use('/api/v1/webhooks', webhookRoutes);
app.use('/api/v1/transport', transportRoutes);
app.use('/api/v1/library', libraryRoutes);
app.use('/api/v1/leave', leaveRoutes);
app.use('/api/v1/expenses', expenseRoutes);
app.use('/api/v1/hostel', hostelRoutes);
app.use('/api/v1/subscription', subscriptionRoutes);
app.use('/api/v1/search', searchRoutes);
app.use('/api/v1/promotions', promotionRoutes);
app.use('/api/v1/payroll', payrollRoutes);
app.use('/api/v1/inventory', inventoryRoutes);
app.use('/api/v1/analytics', analyticsRoutes);
app.use('/api/v1/reports', reportsRoutes);
app.use('/api/v1/permissions', permissionsRoutes);
app.use('/api/v1/documents', documentsRoutes);
app.use('/api/v1/settings', settingsRoutes);
app.use('/api/v1/backups', backupRoutes);
app.use('/api/v1/admission-inquiries', admissionInquiryRoutes);
app.use('/api/v1/contact-inquiries', contactInquiryRoutes);
app.use('/api/v1/public', publicRoutes);

// Welcome route
app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Welcome to EduTrack API',
    version: '1.0.0',
    documentation: '/api/v1/docs',
  });
});

// 404 handler
app.use(notFound);

// Error handler
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    // Test database connection
    const connected = await testConnection();

    if (!connected) {
      console.error('Failed to connect to database. Please check your database configuration.');
      process.exit(1);
    }

    // Plan ladder must exist before any school can subscribe. Idempotent
    // (findOrCreate on `code`, never overwrites edited prices), so it is safe
    // on every start. A failure here must not take the API down.
    try {
      await seedSubscriptionPlans();
    } catch (error) {
      console.error('Could not seed subscription plans (continuing):', error.message);
    }

    // Start server
    startSubscriptionJobs();
    startBackupJobs();
    startLibraryJobs();
    app.listen(PORT, () => {
      console.log(`🚀 Server is running on port ${PORT}`);
      console.log(`📝 Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`🔗 API URL: http://localhost:${PORT}`);
      console.log(`🏥 Health check: http://localhost:${PORT}/health`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

const underPassenger = Boolean(
  process.env.PASSENGER_APP_ENV
  || process.env.IN_PASSENGER
  || typeof PhusionPassenger === 'object',
);
const runDirectly = Boolean(
  process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1]),
);

if (underPassenger || runDirectly) {
  startServer();
}

export default app;