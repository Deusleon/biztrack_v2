/**
 * studentHistory.js — "what grade was this student in during year Y?"
 *
 * Student.class_id only ever points at ONE class row: whatever the
 * student is CURRENTLY enrolled in. There is no column that says "and in
 * 2024 they were in Form I" — so switching the academic-year selector on
 * the Students list, by itself, changed nothing: the query never looked
 * at the selected year at all, and even if it had, there was nowhere in
 * the schema to look up a past year's grade from.
 *
 * Two sources of truth, in priority order:
 *
 *   1. Real StudentPromotion history. Every completed promotion run
 *      records exactly which class a student held in the year being
 *      closed (`from_class_id`/`from_academic_year`) and the year being
 *      opened (`to_class_id`/`to_academic_year`). When a promotion event
 *      covers the requested year, its answer is authoritative — it's
 *      what actually happened, including grade repeats, transfers, and
 *      early graduation, none of which a simple formula could guess.
 *
 *   2. Arithmetic projection, ONLY when no promotion event covers the
 *      requested year (typically: a school that hasn't run a Promotion
 *      for that year yet, or ever). One grade per year is assumed:
 *      currently Form II in 2026 → Form I in 2025 → not yet enrolled in
 *      2024. This is what makes the feature work immediately for a
 *      brand-new school with no promotion history at all, at the cost of
 *      being an estimate rather than a fact (surfaced to the caller via
 *      `source: 'projected'`, so the UI can label it as such).
 */
import { gradeNumber, finalGradeNumber } from './gradeLevels.js';
import { extractBaseYear } from './academicYear.js';

/**
 * @param {object} params
 * @param {object} params.current - The student's CURRENT class:
 *   { grade, education_level, academic_year, class_id, class_name, campus_id }
 * @param {number|null} params.admissionBaseYear - Base year of admission_date, or null if unknown.
 * @param {Array} params.promotionEvents - This student's own StudentPromotion rows, each
 *   pre-resolved to plain values: { action, from_grade, from_education_level, from_base_year,
 *   to_grade, to_education_level, to_base_year }. from_grade/to_grade are null when the
 *   corresponding class_id was null (e.g. a 'graduated' event has no to_class_id).
 * @param {number} params.targetBaseYear - The academic year being asked about, as a base year.
 * @returns {{
 *   visible: boolean,
 *   grade: string|null,
 *   education_level: string|null,
 *   base_year: number|null,
 *   source: 'current'|'promotion'|'projected'|null,
 *   reason: string|null,
 * }}
 */
export const resolveHistoricalEnrollment = ({
  current, admissionBaseYear = null, promotionEvents = [], targetBaseYear, systemStartBaseYear = null,
}) => {
  if (!current || !current.grade || !current.education_level || current.academic_year == null) {
    return { visible: false, grade: null, education_level: null, base_year: null, source: null, reason: 'no current class on record' };
  }

  const currentBaseYear = extractBaseYear(current.academic_year);
  const currentGradeNum = gradeNumber(current.grade);

  if (targetBaseYear === currentBaseYear) {
    return {
      visible: true, grade: current.grade, education_level: current.education_level,
      base_year: currentBaseYear, source: 'current', reason: null,
    };
  }

  // 1. Real history first — it's a fact, not a guess, and it's the only
  // thing that can correctly reflect a repeated grade, a mid-programme
  // transfer, or an early graduation.
  const events = [...promotionEvents].sort((a, b) => (a.from_base_year ?? 0) - (b.from_base_year ?? 0));

  const fromMatch = events.find((e) => e.from_base_year === targetBaseYear);
  if (fromMatch && fromMatch.from_grade) {
    return {
      visible: true, grade: fromMatch.from_grade, education_level: fromMatch.from_education_level,
      base_year: targetBaseYear, source: 'promotion', reason: null,
    };
  }
  const toMatch = events.find((e) => e.to_base_year === targetBaseYear);
  if (toMatch && toMatch.to_grade) {
    return {
      visible: true, grade: toMatch.to_grade, education_level: toMatch.to_education_level,
      base_year: targetBaseYear, source: 'promotion', reason: null,
    };
  }
  // A promotion event that graduated/transferred the student OUT as of
  // some from_base_year means every later year is a definite "not
  // enrolled", regardless of what arithmetic projection would say.
  const exitEvent = events.find((e) => (e.action === 'graduated' || e.action === 'transferred') && e.from_base_year != null);
  if (exitEvent && targetBaseYear > exitEvent.from_base_year) {
    return {
      visible: false, grade: null, education_level: null, base_year: null, source: null,
      reason: exitEvent.action === 'graduated' ? 'already graduated by this year' : 'left the school before this year',
    };
  }

  // 2. No record covers this year — project it, one grade per year, off
  // the current class.
  if (currentGradeNum === null) {
    return { visible: false, grade: null, education_level: null, base_year: null, source: null, reason: 'current grade is not a recognizable number' };
  }

  // Never project further back than the system itself could possibly
  // know about. Real promotion records above are exempt from this — if
  // one genuinely exists before this floor, that's real recorded data,
  // not a guess, and it already returned above. Only the FALLBACK
  // arithmetic guess is stopped here.
  if (systemStartBaseYear !== null && targetBaseYear < systemStartBaseYear) {
    return { visible: false, grade: null, education_level: null, base_year: null, source: null, reason: 'before this school started using the system' };
  }

  const projectedGradeNum = currentGradeNum + (targetBaseYear - currentBaseYear);

  if (admissionBaseYear !== null && targetBaseYear < admissionBaseYear) {
    return { visible: false, grade: null, education_level: null, base_year: null, source: null, reason: 'not yet admitted' };
  }
  if (projectedGradeNum < 1) {
    return { visible: false, grade: null, education_level: null, base_year: null, source: null, reason: 'not yet admitted' };
  }
  const ceiling = finalGradeNumber(current.education_level);
  if (ceiling !== null && projectedGradeNum > ceiling) {
    return { visible: false, grade: null, education_level: null, base_year: null, source: null, reason: 'already graduated by this year' };
  }

  return {
    visible: true,
    grade: String(projectedGradeNum),
    education_level: current.education_level,
    base_year: targetBaseYear,
    source: 'projected',
    reason: null,
  };
};
