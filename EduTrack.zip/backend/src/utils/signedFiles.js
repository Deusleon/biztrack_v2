// FILE PATH: backend/src/utils/signedFiles.js
/**
 * Uploaded files (photos, birth certificates, receipts) used to be served to
 * anybody who had the address. The addresses were unguessable, but a link that
 * leaks — in a screenshot, a forwarded message, browser history — worked forever
 * for anyone. Now a file is only served with a SIGNATURE:
 *
 *   /uploads/avatars/1700000-ab12.png?exp=1700021600000&sig=9f2c…
 *
 *   - The API puts the signature on every file address it returns, automatically
 *     (the `json replacer` below), so screens and PDFs keep working unchanged and
 *     only people who could read the record are ever handed a link.
 *   - The signature covers that one file's path and an expiry, so it can't be
 *     reused for another file or edited to last longer.
 *   - A link lasts 6–12 hours and is the same string for a given file throughout
 *     each 6-hour window, so the browser can still cache the picture.
 *   - Without a valid signature the server answers 403 — never the file.
 *
 * FILE_URL_SECRET may be set to use a secret other than JWT_SECRET.
 */
import crypto from 'crypto';

const WINDOW_MS = 6 * 60 * 60 * 1000;
const secret = () => {
  const value = process.env.FILE_URL_SECRET || process.env.JWT_SECRET;
  if (!value) throw new Error('JWT_SECRET (or FILE_URL_SECRET) must be set to sign file links.');
  return value;
};

const sign = (pathname, exp) => crypto.createHmac('sha256', secret()).update(`${pathname}|${exp}`).digest('hex').slice(0, 32);

/** Matches "/uploads/…" or "https://host/uploads/…" with no query string yet. */
const UPLOAD_URL = /^(https?:\/\/[^\s/?#]+)?(\/uploads\/[^\s?#]+)$/;

/** Adds ?exp=&sig= to an upload address; anything else is returned unchanged. */
export const signUploadUrl = (value, now = Date.now()) => {
  if (typeof value !== 'string') return value;
  const match = UPLOAD_URL.exec(value);
  if (!match || match[2].includes('..')) return value;
  const exp = (Math.floor(now / WINDOW_MS) + 2) * WINDOW_MS;
  return `${value}?exp=${exp}&sig=${sign(match[2], exp)}`;
};

// Only fields that hold a file address are signed — a stray piece of text that
// merely looks like one (something typed into a "notes" box) must not be turned
// into a working link.
const FILE_FIELD = /url$|avatar|logo|photo|image|picture|file|receipt|attachment/i;

/** For `app.set('json replacer', …)`: signs file addresses in every API response. */
export const jsonReplacer = (key, value) => (
  typeof value === 'string' && value.includes('/uploads/') && (FILE_FIELD.test(key) || /^\d+$/.test(key))
    ? signUploadUrl(value)
    : value
);

/** Is this request for a file carrying a valid, unexpired signature? */
export const hasValidFileSignature = (req) => {
  const pathname = String(req.originalUrl || '').split('?')[0];
  const { exp, sig } = req.query || {};
  if (!exp || !sig || pathname.includes('..')) return false;
  if (!/^\d+$/.test(String(exp)) || Number(exp) <= Date.now()) return false;
  try {
    const expected = Buffer.from(sign(pathname, String(exp)));
    const given = Buffer.from(String(sig));
    return expected.length === given.length && crypto.timingSafeEqual(expected, given);
  } catch { return false; }
};

/** Mount in front of express.static('/uploads'). */
export const requireSignedFile = (req, res, next) => {
  if (hasValidFileSignature(req)) return next();
  return res.status(403).json({ success: false, message: 'This file link is missing or has expired. Open the page it came from again to get a fresh one.' });
};
