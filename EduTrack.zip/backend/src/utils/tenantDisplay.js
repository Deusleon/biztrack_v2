// FILE PATH: backend/src/utils/tenantDisplay.js
/**
 * How this school wants dates, money and receipts shown. One setting per school,
 * stored on tenants.settings.display, so every user — and every message the server
 * writes — follows the same standard (it used to live in each person's browser).
 *
 *   money_decimals   0 | 2
 *   date_format      one of DATE_FORMATS
 *   receipt_size     one of RECEIPT_SIZES
 */
import { Tenant } from '../models/index.js';
import { formatNumber, formatMoney } from './money.js';

export const MONEY_DECIMALS = [0, 2];
export const DATE_FORMATS = ['DD/MM/YYYY', 'MM/DD/YYYY', 'YYYY-MM-DD', 'DD-MM-YYYY', 'D MMM YYYY', 'MMMM D, YYYY'];
export const RECEIPT_SIZES = ['a5', 'thermal80', 'thermal58'];
export const DISPLAY_DEFAULTS = { money_decimals: 0, date_format: 'DD/MM/YYYY', receipt_size: 'a5' };

/** Stored values merged over the defaults; anything invalid falls back to the default. */
export const resolveDisplay = (tenant) => {
  const stored = tenant?.settings?.display || {};
  return {
    money_decimals: MONEY_DECIMALS.includes(Number(stored.money_decimals)) ? Number(stored.money_decimals) : DISPLAY_DEFAULTS.money_decimals,
    date_format: DATE_FORMATS.includes(stored.date_format) ? stored.date_format : DISPLAY_DEFAULTS.date_format,
    receipt_size: RECEIPT_SIZES.includes(stored.receipt_size) ? stored.receipt_size : DISPLAY_DEFAULTS.receipt_size,
  };
};

// Read often (every notification, every email) and changed rarely, so keep it for a minute.
const cache = new Map();
const TTL_MS = 60 * 1000;

export const invalidateTenantDisplay = (tenantId) => cache.delete(tenantId);

export const getTenantDisplay = async (tenantId) => {
  const hit = cache.get(tenantId);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.value;
  const tenant = await Tenant.findByPk(tenantId, { attributes: ['id', 'settings'] });
  const value = resolveDisplay(tenant);
  cache.set(tenantId, { value, at: Date.now() });
  return value;
};

/** `const fmt = await moneyFormatterFor(tenantId); fmt(12000)` → "12,000" or "12,000.00". */
export const moneyFormatterFor = async (tenantId) => {
  const { money_decimals: decimals } = await getTenantDisplay(tenantId);
  const number = (n) => formatNumber(n, decimals);
  number.withCurrency = (n, currency = 'TZS') => formatMoney(n, decimals, currency);
  return number;
};
