import { SubscriptionPlan } from '../models/index.js';

/**
 * Creates the default plan ladder the first time the system starts.
 *
 * Uses findOrCreate keyed on `code`, so it never overwrites prices an
 * operator has since changed — running it on every boot is safe.
 *
 * Prices are placeholders. They are meant to be edited from the platform
 * admin screen (or directly), not hard-coded into a release.
 */
const DEFAULT_PLANS = [
  {
    code: 'basic',
    name: 'Basic',
    description: 'For small schools getting started. Core academic and fee management.',
    student_limit: 300,
    price_monthly: 50000,
    price_termly: 135000,
    price_yearly: 480000,
    included_modules: ['students', 'staff', 'classes', 'attendance', 'exams', 'fees'],
    tier: 1,
  },
  {
    code: 'standard',
    name: 'Standard',
    description: 'For growing schools. Adds messaging, library, transport and reporting.',
    student_limit: 1000,
    price_monthly: 120000,
    price_termly: 320000,
    price_yearly: 1150000,
    included_modules: ['students', 'staff', 'classes', 'attendance', 'exams', 'fees', 'messaging', 'library', 'transport', 'reports'],
    tier: 2,
  },
  {
    code: 'premium',
    name: 'Premium',
    description: 'Unlimited students and every module, including payroll, hostel and analytics.',
    student_limit: null, // unlimited
    price_monthly: 250000,
    price_termly: 670000,
    price_yearly: 2400000,
    included_modules: ['all'],
    tier: 3,
  },
];

export const seedSubscriptionPlans = async () => {
  let created = 0;
  for (const plan of DEFAULT_PLANS) {
    const [, wasCreated] = await SubscriptionPlan.findOrCreate({
      where: { code: plan.code },
      defaults: plan,
    });
    if (wasCreated) created++;
  }
  if (created > 0) console.log(`✓ Seeded ${created} subscription plan(s)`);
  return created;
};
