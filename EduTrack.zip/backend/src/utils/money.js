/**
 * Money and number formatting for text the SERVER writes (notifications, messages,
 * emails, PDFs). The frontend has its own copy in utils/money.js that follows the same
 * rule: the school's "Money Decimals" setting (Settings → General).
 */
const LOCALE = 'en-US';

export const formatNumber = (amount, decimals = 0) => {
  const n = Number(amount);
  return (Number.isFinite(n) ? n : 0).toLocaleString(LOCALE, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
};

export const formatMoney = (amount, decimals = 0, currency = 'TZS') => `${currency} ${formatNumber(amount, decimals)}`;
