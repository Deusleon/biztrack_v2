// FILE PATH: backend/src/utils/auditContext.js
import { AsyncLocalStorage } from 'node:async_hooks';

/**
 * Carries "what is this request changing?" from the audit middleware down to
 * the database hooks, without any controller having to pass it along.
 *
 * The middleware opens a store when a request starts; every create / update /
 * delete that happens while that request is being handled drops a note into
 * it (see registerAuditHooks in middleware/auditLog.js); when the response is
 * sent, the notes become the audit entry. Work done outside a request — seeds,
 * scripts, background jobs — has no store and is simply not recorded.
 */
export const auditStore = new AsyncLocalStorage();

export const newAuditStore = () => ({ changes: [], overflow: {} });
