/**
 * resetDatabase.js — Wipes and recreates every table with a completely
 * empty database, ready for real day-to-day use/testing (as opposed to
 * `seed.js`, which fills it with ~380 fake demo students/staff/etc).
 *
 * Only creates the bare minimum needed to log in and start using the
 * system yourself:
 *   • 1 Tenant (your school)
 *   • 1 Campus
 *   • 2 logins: a super_admin and a school admin
 *
 * Everything else (students, staff, classes, subjects, fees, attendance,
 * timetable, etc.) starts completely empty — you build it for real
 * through the UI from here.
 *
 * Run with:  npm run db:empty   (from the backend/ folder)
 *
 * You can override the defaults below via environment variables so you
 * don't have to edit this file:
 *   SCHOOL_NAME, SCHOOL_SLUG, SCHOOL_EMAIL, SCHOOL_PHONE,
 *   ADMIN_EMAIL, ADMIN_PASSWORD, SUPERADMIN_EMAIL, SUPERADMIN_PASSWORD
 */
import dotenv from 'dotenv';
import { Tenant, User, Campus } from '../models/index.js';
import { syncDatabase } from '../config/database.js';

dotenv.config();

// ── Never run this against a live system by accident ─────────────────────────
// It drops every table and refills them, which would erase a real school's data.
if (process.env.NODE_ENV === 'production' && process.env.I_UNDERSTAND_THIS_ERASES_ALL_DATA !== 'yes') {
  console.error('\n✗ Refusing to run: NODE_ENV is "production" and this script ERASES the whole database.');
  console.error('  For a real installation use  npm run seed:production  (adds only the essentials, deletes nothing).');
  console.error('  If you really mean to wipe this database, set I_UNDERSTAND_THIS_ERASES_ALL_DATA=yes and run it again.\n');
  process.exit(1);
}

const resetDatabase = async () => {
  try {
    console.log('🧹 Resetting database to a clean, empty state...\n');

    // Drops and recreates every table from the current models — this
    // wipes ALL existing data. Only ever run this intentionally.
    // Safety net: keep a tested backup of what is about to be erased (skip with SKIP_BACKUP=1).
    const { quickBackupToFile } = await import('../services/backup/backupService.js');
    const kept = await quickBackupToFile('before-reset');
    if (kept) console.log(`💾 Safety backup of the old data: ${kept.file}\n`);
    await syncDatabase({ force: true });
    console.log('✅ Tables recreated (empty)');

    const tenant = await Tenant.create({
      name: process.env.SCHOOL_NAME || 'Lucy Lameck Secondary School',
      slug: process.env.SCHOOL_SLUG || 'lucy-lameck-secondary',
      email: process.env.SCHOOL_EMAIL || 'info@lucylameck.ac.tz',
      phone: process.env.SCHOOL_PHONE || '255754000001',
      address: process.env.SCHOOL_ADDRESS || 'P.O. Box 100, Dar es Salaam, Tanzania',
      status: 'active',
      settings: {
        timezone: 'Africa/Dar_es_Salaam',
        currency: 'TZS',
      },
    });
    console.log('✅ Tenant created:', tenant.name);

    const campus = await Campus.create({
      tenant_id: tenant.id,
      name: 'Main Campus',
      code: 'MAIN01',
      address: tenant.address,
      city: 'Dar es Salaam',
      state: 'Dar es Salaam Region',
      country: 'Tanzania',
      postal_code: '',
      phone: tenant.phone,
      email: tenant.email,
      status: 'active',
    });
    console.log('✅ Campus created:', campus.name);

    const superAdminEmail = process.env.SUPERADMIN_EMAIL || 'superadmin@edutrack.com';
    const superAdminPassword = process.env.SUPERADMIN_PASSWORD || 'Admin@123';
    await User.create({
      tenant_id: tenant.id, email: superAdminEmail, password: superAdminPassword,
      first_name: 'Super', last_name: 'Admin', role: 'super_admin', status: 'active',
    });

    const adminEmail = process.env.ADMIN_EMAIL || 'admin@lucylameck.ac.tz';
    const adminPassword = process.env.ADMIN_PASSWORD || 'Admin@123';
    await User.create({
      tenant_id: tenant.id, email: adminEmail, password: adminPassword,
      first_name: 'School', last_name: 'Admin', role: 'admin', status: 'active',
    });
    console.log('✅ Logins created');

    console.log('\n🎉 Database is empty and ready.\n');
    console.log('Log in with either of these:');
    console.log(`  Super Admin → ${superAdminEmail} / ${superAdminPassword}`);
    console.log(`  School Admin → ${adminEmail} / ${adminPassword}`);
    console.log('\n(Change these passwords after your first login.)');

    process.exit(0);
  } catch (error) {
    console.error('❌ Database reset failed:', error);
    process.exit(1);
  }
};

resetDatabase();
