/**
 * gradeLevels.js — shared grade-numbering logic.
 *
 * Originally lived only inside promotionController.js. Pulled out here
 * because the Students list needs the exact same "what grade is this,
 * numerically" and "is this the final grade of its level" logic to
 * reconstruct a student's grade in a PAST or FUTURE academic year — using
 * two different rules for the same concept (one in Promotion, a subtly
 * different one in Students) would make the two features disagree with
 * each other about a student's history.
 */

/**
 * The final form of each programme. A student in one of these has finished
 * the programme rather than having somewhere to be promoted to.
 */
export const FINAL_GRADE = {
  primary: '7',
  o_level: '4',
  a_level: '6',
};

/** Grades are stored as strings ("1", "Form 1", "IV"), so the number is
 * pulled out rather than assumed. Returns null when there isn't one. */
export const gradeNumber = (grade) => {
  const roman = {
    I: 1, II: 2, III: 3, IV: 4, V: 5, VI: 6, VII: 7,
  };
  const raw = String(grade || '').trim().toUpperCase();

  const digits = raw.match(/\d+/);
  if (digits) return parseInt(digits[0], 10);

  const romanMatch = raw.match(/\b(VII|VI|IV|V|III|II|I)\b/);
  if (romanMatch) return roman[romanMatch[1]] ?? null;

  return null;
};

/** Given an education level and a grade, is this the last grade of that
 * programme? Accepts either a `{ education_level, grade }`-shaped object
 * (a Class instance works) or the two values separately. */
export const isFinalGrade = (educationLevel, grade) => {
  const finalNum = gradeNumber(FINAL_GRADE[educationLevel] || FINAL_GRADE.o_level);
  const current = gradeNumber(grade);
  return current !== null && finalNum !== null && current >= finalNum;
};

/** Final grade number (not the raw label) for a given education level —
 * the numeric ceiling a student's grade can never exceed while still in
 * that level. */
export const finalGradeNumber = (educationLevel) => gradeNumber(FINAL_GRADE[educationLevel] || FINAL_GRADE.o_level);
