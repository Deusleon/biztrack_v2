import crypto from 'crypto';

/**
 * Every printed receipt carries a short verification code derived from
 * an HMAC of the payment's own immutable details (its id, tenant,
 * student, amount, and date) signed with a server-side secret the
 * public never sees. Anyone can read the code off a paper receipt, but
 * nobody can compute a *valid* code for a fabricated or altered amount
 * without the secret — so a forged or doctored receipt (e.g. someone
 * changing "200,000" to "2,000,000" on a photocopy) simply won't match
 * when checked against this receipt's real code, or when the checker
 * asks the server for what this payment's amount actually was.
 */
const SECRET = process.env.RECEIPT_SECRET || process.env.JWT_SECRET || 'edutrack-receipt-secret-change-in-production';

const payloadFor = (payment) =>
  [payment.id, payment.tenant_id, payment.student_id, payment.amount, payment.payment_date].join('|');

/** 10-character, uppercase, easy-to-read-off-paper code. */
export const generateVerificationCode = (payment) =>
  crypto.createHmac('sha256', SECRET).update(payloadFor(payment)).digest('hex').slice(0, 10).toUpperCase();

export const isValidVerificationCode = (payment, code) =>
  typeof code === 'string' && generateVerificationCode(payment) === code.trim().toUpperCase();

/**
 * The same idea for a SUBSCRIPTION receipt (what a school pays EduTrack). The payload
 * starts with "SUB" so a code for a fee receipt can never validate a subscription
 * receipt or the other way round, and it includes the amount and the time of payment,
 * so changing either on a copy makes the code fail.
 */
const subscriptionPayloadFor = (invoice) => [
  'SUB', invoice.id, invoice.tenant_id, invoice.invoice_number,
  Number(invoice.total).toFixed(2),
  invoice.paid_at ? new Date(invoice.paid_at).toISOString() : '',
].join('|');

export const generateSubscriptionReceiptCode = (invoice) =>
  crypto.createHmac('sha256', SECRET).update(subscriptionPayloadFor(invoice)).digest('hex').slice(0, 10).toUpperCase();

export const isValidSubscriptionReceiptCode = (invoice, code) =>
  typeof code === 'string' && generateSubscriptionReceiptCode(invoice) === code.trim().toUpperCase();

/**
 * The code in an invoice's "Scan to pay" QR. It lets whoever holds the invoice open the
 * pay page and send a mobile-money prompt WITHOUT signing in — so it has to be something
 * nobody can guess or build for another invoice. It is tied to the invoice and its total,
 * so a link cannot be reused after the invoice is re-priced. (Paying is harmless: the worst
 * a stranger with the link can do is pay the school's bill.)
 */
const payPayloadFor = (invoice) => ['PAY', invoice.id, invoice.tenant_id, invoice.invoice_number, Number(invoice.total).toFixed(2)].join('|');

export const generateSubscriptionPayCode = (invoice) =>
  crypto.createHmac('sha256', SECRET).update(payPayloadFor(invoice)).digest('hex').slice(0, 16).toUpperCase();

export const isValidSubscriptionPayCode = (invoice, code) =>
  typeof code === 'string' && generateSubscriptionPayCode(invoice) === code.trim().toUpperCase();
