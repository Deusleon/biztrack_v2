// FILE PATH: backend/src/utils/webhookSignature.js
import crypto from 'crypto';

/**
 * Delivery-report webhook URLs are signed rather than stored.
 *
 * Each school's URL is  /webhooks/dlr/nextsms/<tenantId>/<signature>  where
 * the signature is an HMAC of the tenant id under a server secret. That means:
 *   - the URL exists from the first moment, for every school, with nothing to
 *     create, save or migrate — it is ready to register as soon as the app is
 *     deployed;
 *   - it can't be guessed or forged without the secret, so strangers can't post
 *     fake delivery results;
 *   - the tenant id in the URL says whose message a report belongs to.
 *
 * The secret is WEBHOOK_SECRET if set, otherwise JWT_SECRET (already required
 * by the app). Changing it changes every URL, so any URL registered with a
 * provider must be re-registered.
 */
const secret = () => {
  const value = process.env.WEBHOOK_SECRET || process.env.JWT_SECRET;
  if (!value) throw new Error('WEBHOOK_SECRET or JWT_SECRET must be set to build webhook URLs.');
  return value;
};

export const webhookSignature = (tenantId, purpose = 'nextsms-dlr') =>
  crypto.createHmac('sha256', secret()).update(`${purpose}:${tenantId}`).digest('hex').slice(0, 32);

export const isValidWebhookSignature = (tenantId, signature, purpose = 'nextsms-dlr') => {
  try {
    const expected = Buffer.from(webhookSignature(tenantId, purpose));
    const given = Buffer.from(String(signature || ''));
    return expected.length === given.length && crypto.timingSafeEqual(expected, given);
  } catch { return false; }
};
