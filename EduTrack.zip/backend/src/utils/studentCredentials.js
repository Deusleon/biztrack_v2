/**
 * Students are admitted in bulk and rarely have a usable personal email at
 * enrollment time, so EduTrack auto-generates a login identity for them:
 * an email built from their name + admission number (guaranteed unique
 * because the admission number is unique per school, and the school's slug
 * makes it unique across tenants too), plus a shared default password.
 * Students are expected to change the password after their first login
 * (see the existing `/auth/change-password` endpoint).
 */

// One shared default password for every newly admitted student. Can be
// overridden per-deployment via STUDENT_DEFAULT_PASSWORD in the environment.
export const DEFAULT_STUDENT_PASSWORD = process.env.STUDENT_DEFAULT_PASSWORD || 'Student@2026';

const slugify = (value) =>
  (value || '')
    .toString()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // strip accents
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '')
    .trim();

/**
 * Builds a stable, unique login email for a student, e.g.
 * "asha.mwakalinga.stu2026014@lucylameck.students.edutrack.local".
 */
export const generateStudentEmail = ({ admissionNumber, tenantSlug }) => {
  const admissionPart = slugify(admissionNumber) || Date.now().toString(36);
  const schoolPart = slugify(tenantSlug) || 'school';
  return `${admissionPart}@${schoolPart}.local`;
};

/**
 * Staff, unlike students, already have a working email address by the time
 * they're hired — so their login identity is simply the email entered on
 * the form. What they DON'T get is a password chosen for them by whoever
 * added them: that means an admin knowing every staff member's password.
 *
 * Instead they share one default password for the first login and are
 * forced to change it (`must_change_password`), exactly as students are.
 * Overridable per deployment via STAFF_DEFAULT_PASSWORD.
 */
export const DEFAULT_STAFF_PASSWORD = process.env.STAFF_DEFAULT_PASSWORD || 'Staff@2026';
