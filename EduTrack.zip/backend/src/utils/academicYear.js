/**
 * Academic year formatting — handles schools that use a single-year format
 * for Primary/O-Level ("2025") and a two-year span for A-Level ("2025-2026").
 *
 * The canonical value stored everywhere (Class.academic_year, Exam.academic_year,
 * FeeStructure.academic_year, ...) is always a plain string, exactly as the
 * user picked it — this file helps GENERATE and VALIDATE that string
 * consistently, AND provides the shared WHERE-clause helpers
 * (`academicYearBaseMatch` / `applyAcademicYearFilter`) that every
 * controller must use to FILTER by academic year. Filtering can never be a
 * plain `where.academic_year = value` exact-string comparison, because the
 * single global academic-year selector is always one format (a span, e.g.
 * "2025-2026") while Primary/O-Level rows are stored in the other (a single
 * year, e.g. "2025") — an exact match would silently return nothing for
 * those levels. Comparing by BASE YEAR instead (the leading 4 digits) is a
 * strict superset of exact matching — same-format values still match each
 * other exactly as before — so it's always safe to use in place of it.
 */
import { Op, where, fn, col } from 'sequelize';

/** 'primary' and 'o_level' use a single year; 'a_level' uses a span. */
export const usesYearSpan = (educationLevel) => educationLevel === 'a_level';

/** Format a base year (e.g. 2025) for the given education level. */
export const formatAcademicYear = (baseYear, educationLevel) => {
  const year = parseInt(baseYear, 10);
  if (Number.isNaN(year)) return '';
  return usesYearSpan(educationLevel) ? `${year}-${year + 1}` : `${year}`;
};

/** The base year Tanzanian-style school years default to right now — the
 * calendar year the school year STARTS in (school years run roughly
 * Jan-Dec for Primary/O-Level, and are still anchored to a start year for
 * A-Level's two-year span). */
export const currentBaseYear = () => new Date().getFullYear();

/** Pulls the leading 4-digit year out of any academic-year string, whether
 * it's already a single year ("2025") or a span ("2025-2026"). */
export const extractBaseYear = (academicYearString) => {
  const match = String(academicYearString || '').match(/^\d{4}/);
  return match ? parseInt(match[0], 10) : currentBaseYear();
};

/** Given the school-wide "current academic year" (as picked in the header —
 * always stored/displayed as a range, e.g. "2025-2026") and a specific
 * class's education level, returns the correctly-formatted academic year
 * for THAT class. This is how a single global year selector stays useful
 * for a school that mixes Primary/O-Level (single-year) and A-Level
 * (span) classes — each class-linked record (Fee Structure, etc.) is
 * still tagged with the format its own level actually uses. */
export const resolveAcademicYearForLevel = (globalAcademicYear, educationLevel) =>
  formatAcademicYear(extractBaseYear(globalAcademicYear), educationLevel);

/** Generate a handful of selectable academic years around the current one,
 * already formatted for the given education level. */
export const academicYearOptions = (educationLevel, span = 2) => {
  const base = currentBaseYear();
  const options = [];
  for (let y = base - span; y <= base + span; y++) {
    options.push(formatAcademicYear(y, educationLevel));
  }
  return options;
};

/**
 * A Sequelize WHERE fragment that matches any academic_year-style column
 * whose LEADING YEAR equals the incoming filter's leading year — e.g. a
 * filter of "2026-2027" (the format the global selector always uses)
 * matches a row stored as "2026" (Primary/O-Level) exactly as well as one
 * stored as "2026-2027" (A-Level), because both start with the same base
 * year. Returns null when there's no usable year to filter on, so callers
 * can skip adding it to a query.
 *
 * `columnName` accepts a plain column ('academic_year') or a Sequelize
 * association path ('$class.academic_year$') for use inside `include`d
 * queries.
 */
export const academicYearBaseMatch = (filterValue, columnName = 'academic_year') => {
  const base = extractBaseYear(filterValue);
  if (!base) return null;
  return where(fn('LEFT', col(columnName), 4), String(base));
};

/**
 * Merges a base-year academic-year filter into an existing Sequelize
 * `where` object, replacing the old pattern of
 * `if (academic_year) where.academic_year = academic_year;` everywhere.
 * A no-op when `filterValue` is falsy, so it's always safe to call.
 */
export const applyAcademicYearFilter = (whereObj, filterValue, columnName = 'academic_year') => {
  if (!filterValue) return whereObj;
  const clause = academicYearBaseMatch(filterValue, columnName);
  if (!clause) return whereObj;
  whereObj[Op.and] = whereObj[Op.and] ? [...whereObj[Op.and], clause] : [clause];
  return whereObj;
};

/**
 * The earliest academic year this school could possibly have REAL records
 * for in this system — either an explicit override the school set
 * (`tenant.settings.academic_records_start_year`, for a school that
 * migrated in existing history from another system), or simply the year
 * they started using EduTrack at all (`tenant.createdAt`).
 *
 * Used in two places: the academic-year picker shouldn't OFFER years
 * before this (there's nothing there to show), and historical/projected
 * student data (see utils/studentHistory.js) must never guess a grade
 * for a year before this — a projection for a year the system never
 * recorded anything in isn't an estimate, it's a fabrication.
 */
export const systemStartBaseYear = (tenant) => {
  const override = tenant?.settings?.academic_records_start_year;
  if (override) return Number(override);
  if (tenant?.createdAt) return new Date(tenant.createdAt).getFullYear();
  return null;
};

/**
 * The real calendar date range for an academic year.
 *
 * Tanzanian school years run JANUARY TO DECEMBER. This previously assumed
 * a September–August year, which is the Northern-hemisphere convention and
 * silently broke every date-scoped figure: for academic year 2026 the
 * window was Sep 2026 – Aug 2027, so attendance taken in March 2026 and
 * fees paid in February 2026 both fell outside it and reported as zero.
 *
 * A-Level's two-year span label ("2025-2026") still resolves to its BASE
 * year here on purpose: Form V sits in calendar 2025 and Form VI in 2026,
 * and each is stored under its own label, so one calendar year is the
 * correct window for both. Widening it to two years would double-count a
 * student's attendance across the whole programme.
 *
 * Used to scope date-stamped records (attendance, payments) to one
 * academic year when the record carries no academic_year column of its own.
 */
export const academicYearDateRange = (academicYearOrBaseYear) => {
  const base = typeof academicYearOrBaseYear === 'number' ? academicYearOrBaseYear : extractBaseYear(academicYearOrBaseYear);
  if (base === null) return null;
  return { start: `${base}-01-01`, end: `${base}-12-31` };
};
