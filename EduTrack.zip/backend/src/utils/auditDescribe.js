// FILE PATH: backend/src/utils/auditDescribe.js
/**
 * Pure helpers (no database) that turn what a request did into something a
 * person can read: a sentence for the list, and exact before/after values for
 * the detail view. Kept separate from the middleware so they can be tested
 * on their own.
 */

// Anything that looks like a credential is never stored or shown — the audit
// log must not become the place passwords end up.
const HIDDEN_FIELD = /pass(word)?|secret|token|api_?key|\bpin\b|otp|hash|salt|credential|authorization|card_?number|cvv/i;
const IGNORED_FIELDS = new Set(['id', 'tenant_id', 'created_at', 'updated_at', 'deleted_at', 'createdAt', 'updatedAt', 'deletedAt']);
const MAX_STRING = 300;
const MAX_JSON = 500;
export const HIDDEN_MARK = '[hidden]';

export const isHiddenField = (field) => HIDDEN_FIELD.test(String(field));

/** One value, made safe to store and show. */
export const cleanValue = (field, value) => {
  if (value === undefined || value === null) return null;
  if (isHiddenField(field)) return HIDDEN_MARK;
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value.toISOString();
  if (typeof Buffer !== 'undefined' && Buffer.isBuffer(value)) return '[binary data]';
  if (typeof value === 'string') {
    if (/^data:[^;]+;base64,/.test(value)) return '[file data]';
    return value.length > MAX_STRING ? `${value.slice(0, MAX_STRING)}…` : value;
  }
  if (typeof value === 'object') {
    let json;
    try { json = JSON.stringify(value); } catch { return '[unreadable value]'; }
    if (json === undefined) return null;
    return json.length > MAX_JSON ? `${json.slice(0, MAX_JSON)}…` : JSON.parse(json);
  }
  return value;
};

/** Recursively cleans a request body / query for display (legacy rows and the
 * "no database change was captured" fallback). */
export const cleanObject = (value, depth = 0, field = '') => {
  if (depth > 4) return '[nested data]';
  if (Array.isArray(value)) {
    const items = value.slice(0, 20).map((v) => cleanObject(v, depth + 1, field));
    return value.length > 20 ? [...items, `… and ${value.length - 20} more`] : items;
  }
  if (value && typeof value === 'object' && !(value instanceof Date) && !Buffer.isBuffer(value)) {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, cleanObject(v, depth + 1, k)]));
  }
  return cleanValue(field, value);
};

const sameValue = (a, b) => {
  if (a === b) return true;
  try { return JSON.stringify(a) === JSON.stringify(b); } catch { return false; }
};

const modelColumns = (instance) => Object.keys(instance.constructor.rawAttributes || {});

/** Every filled-in column of a record (what was created / what was deleted). */
export const snapshotInstance = (instance) => {
  const data = {};
  for (const key of modelColumns(instance)) {
    if (IGNORED_FIELDS.has(key)) continue;
    const value = cleanValue(key, instance.get(key));
    if (value !== null) data[key] = value;
  }
  return data;
};

/** The columns an update actually changed, with their previous and new values. */
export const diffInstance = (instance) => {
  const fields = [];
  for (const key of instance.changed() || []) {
    if (IGNORED_FIELDS.has(key)) continue;
    const before = cleanValue(key, instance.previous(key));
    const after = cleanValue(key, instance.get(key));
    if (sameValue(before, after) && !isHiddenField(key)) continue;
    fields.push({ field: key, before, after });
  }
  return fields;
};

// ── Wording ────────────────────────────────────────────────────────────────

/** 'FeeStructure' → 'fee structure' */
export const humanizeModel = (name) =>
  String(name || 'record').replace(/([a-z0-9])([A-Z])/g, '$1 $2').toLowerCase();

/** 'class_teacher_id' → 'Class teacher' */
export const humanizeField = (field) => {
  const text = String(field || '').replace(/_id$/, '').replace(/[_-]+/g, ' ').trim();
  return text ? text.charAt(0).toUpperCase() + text.slice(1) : String(field);
};

const str = (v) => (typeof v === 'string' && v.trim() ? v.trim() : null);

/** The most recognisable name for a record, from whatever columns it has. */
export const recordName = (data) => {
  if (!data) return null;
  const full = [str(data.first_name), str(data.last_name)].filter(Boolean).join(' ');
  return str(data.name) || str(data.title) || str(data.full_name) || (full || null)
    || str(data.admission_number) || str(data.receipt_number) || str(data.invoice_number)
    || str(data.employee_number) || str(data.reference) || str(data.code) || str(data.email)
    || str(data.phone) || (str(data.description) ? str(data.description).slice(0, 40) : null)
    || (str(data.subject) ? str(data.subject).slice(0, 40) : null);
};

const INACTIVE = new Set(['inactive', 'disabled', 'archived', 'cancelled', 'canceled', 'void', 'voided', 'suspended', 'deactivated']);
const ACTIVE = new Set(['active', 'enabled']);

const quote = (name) => (name ? ` "${name}"` : '');

/** One change → a short sentence ("Updated class "Form 1""). */
export const describeChange = (change) => {
  const label = change.label || humanizeModel(change.model);
  const named = quote(change.name);

  if (change.op === 'create') return `Created ${label}${named}`;
  if (change.op === 'delete') return `Deleted ${label}${named}`;
  if (change.op === 'bulk_update') {
    const set = Object.entries(change.set || {})
      .filter(([k]) => !['updated_at', 'updatedAt'].includes(k))
      .slice(0, 2).map(([k, v]) => `${humanizeField(k).toLowerCase()} → ${v}`).join(', ');
    return `Updated ${change.count || 'several'} ${label} record${change.count === 1 ? '' : 's'}${set ? ` (${set})` : ''}`;
  }
  if (change.op === 'bulk_delete') return `Deleted ${change.count || 'several'} ${label} record${change.count === 1 ? '' : 's'}`;
  if (change.op === 'update') {
    const onlyStatus = change.fields?.length === 1 && change.fields[0].field === 'status';
    if (onlyStatus) {
      const next = String(change.fields[0].after || '').toLowerCase();
      if (INACTIVE.has(next)) return `Deactivated ${label}${named}`;
      if (ACTIVE.has(next)) return `Reactivated ${label}${named}`;
    }
    return `Updated ${label}${named}`;
  }
  return `Changed ${label}${named}`;
};

const KIND_OF_OP = { create: 'create', update: 'update', delete: 'delete', bulk_update: 'update', bulk_delete: 'delete' };

/** Summarises everything a request changed: title, kind, and the main record. */
export const describeChanges = (changes, overflow = {}, resource = '') => {
  if (!changes.length) return null;

  // The record the user was actually working on — the one that matches the
  // module of the request when there is one (a payment request that also
  // updated a student's balance is "a payment", not "a student").
  const module = String(resource).replace(/[-_]/g, '').toLowerCase();
  const names = [module, module.replace(/es$/, ''), module.replace(/s$/, '')].filter(Boolean);
  const isModuleRecord = (c) => { const m = String(c.model).toLowerCase(); return names.some((n) => m.startsWith(n) || n.startsWith(m)); };
  const primary = changes.find(isModuleRecord) || changes[0];

  const extra = (changes.length - 1) + Object.values(overflow).reduce((a, b) => a + b, 0);
  const title = `${describeChange(primary)}${extra > 0 ? ` (+${extra} related change${extra === 1 ? '' : 's'})` : ''}`;

  return {
    title,
    kind: KIND_OF_OP[primary.op] || 'update',
    record: { model: primary.model, label: primary.label, id: primary.id || null, name: primary.name || null },
    changed_fields: primary.op === 'update' ? (primary.fields || []).map((f) => f.field) : [],
  };
};

// ── Request-level wording (no database change captured, and older entries) ─

const ACTION_WORDS = [
  'send', 'approve', 'reject', 'cancel', 'void', 'refund', 'promote', 'revert', 'retry', 'refresh', 'sync', 'import',
  'export', 'upload', 'reset', 'assign', 'unassign', 'issue', 'return', 'mark', 'publish', 'generate', 'clone', 'close',
  'open', 'activate', 'deactivate', 'reactivate', 'verify', 'pay', 'collect', 'record', 'allocate', 'transfer', 'enroll',
  'withdraw', 'restore', 'archive', 'top-up', 'purchase', 'test', 'bulk', 'preview', 'process', 'submit', 'review',
];
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const isIdSegment = (seg) => UUID.test(seg) || /^\d+$/.test(seg);
const capital = (t) => t.charAt(0).toUpperCase() + t.slice(1);
const words = (t) => String(t || '').replace(/[-_]+/g, ' ').trim();

/**
 * Best sentence for a request when no record change was captured — and for
 * entries written before this was recorded, which only have the route.
 */
export const describeRequest = ({ method = '', resource = '', path = '', body = null }) => {
  const m = String(method).toUpperCase();
  const clean = String(path).split('?')[0].replace(/\/+$/, '');
  const tail = clean.split('/').filter(Boolean);
  const last = tail[tail.length - 1] || '';

  if (/\/login$/.test(clean)) return { title: `Signed in${str(body?.email) ? ` (${body.email})` : ''}`, kind: 'auth' };
  if (/\/logout$/.test(clean)) return { title: 'Signed out', kind: 'auth' };
  if (/\/change-password$/.test(clean)) return { title: 'Changed own password', kind: 'auth' };
  if (/\/forgot-password$/.test(clean)) return { title: 'Asked for a password reset code', kind: 'auth' };
  if (/\/reset-password$/.test(clean)) return { title: 'Reset password using an emailed/SMS code', kind: 'auth' };
  if (/\/profile\/avatar$/.test(clean)) return { title: 'Changed own profile picture', kind: 'update' };
  if (/\/auth\/profile$|^\/profile$/.test(clean) && m !== 'GET') return { title: 'Updated own profile', kind: 'update' };
  if (/\/register$/.test(clean)) return { title: `Registered an account${str(body?.email) ? ` (${body.email})` : ''}`, kind: 'create' };

  const named = quote(recordName(body));
  const noun = words(resource) || 'record';

  // /messages/send, /fees/payments/:id/refund, …  → an action, not a plain CRUD verb
  const actionWord = ACTION_WORDS.find((w) => last === w || last.startsWith(`${w}-`) || last.endsWith(`-${w}`));
  if (actionWord && !isIdSegment(last)) {
    const subject = words(tail.filter((s) => !isIdSegment(s) && s !== last).pop() || noun);
    return { title: `${capital(words(last))} — ${subject}${named}`, kind: 'action' };
  }

  const subPath = tail.filter((s) => !isIdSegment(s)).map(words);
  const where = subPath.length ? subPath.join(' › ') : noun;
  if (m === 'POST') return { title: `Created ${where}${named}`, kind: 'create' };
  if (m === 'PUT' || m === 'PATCH') return { title: `Updated ${where}${named}`, kind: 'update' };
  if (m === 'DELETE') return { title: `Deleted ${where}${named}`, kind: 'delete' };
  return { title: `${m} ${where}`.trim(), kind: 'action' };
};
