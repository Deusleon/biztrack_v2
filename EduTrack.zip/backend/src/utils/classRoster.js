/**
 * classRoster.js — "who was actually in THIS class during its year?"
 *
 * `Student.class_id` only ever points at a student's CURRENT class. A
 * class row for a past year (e.g. "Form II" dated 2025) still exists,
 * still has real fee structures and exam grades tied to it — but once a
 * Promotion run has moved those students on to a newer class, a plain
 * `Student.findAll({ where: { class_id: oldId } })` silently returns
 * NOBODY, even though every one of them really was there. Fee Status,
 * the exam Marks Sheet, and Class Results all used to fetch their
 * roster exactly that way, so viewing any of them for a past year
 * quietly went empty (or wrong) the moment promotion had run since.
 *
 * This reuses the exact same resolution used for the Students list
 * itself (see studentHistory.js): real StudentPromotion records first,
 * arithmetic projection only as a fallback, and never projecting past
 * the school's own system-start floor.
 */
import { Student, User, Section, Class, StudentPromotion, Tenant } from '../models/index.js';
import { extractBaseYear, systemStartBaseYear, formatAcademicYear } from './academicYear.js';
import { resolveHistoricalEnrollment } from './studentHistory.js';

/**
 * @param {object} params
 * @param {string} params.tenantId
 * @param {string} params.classId - The SPECIFIC class row (a particular year's "Form II", say).
 * @param {string|null} params.sectionId - Optional stream filter. Only ever
 *   honoured for students CURRENTLY sitting in this exact class row — a
 *   past year's stream membership isn't tracked (see studentController.js),
 *   so a section filter simply excludes anyone resolved historically.
 * @returns {{ targetClass: object|null, students: Array }} `students` are
 *   full Sequelize Student instances (with `user`/`section` included),
 *   the same shape a plain `Student.findAll({ where: { class_id } })`
 *   used to return — so existing row-building code downstream doesn't
 *   need to change, only how the roster itself is gathered.
 */
export const findStudentsEnrolledInClass = async ({ tenantId, classId, sectionId = null }) => {
  const targetClass = await Class.findOne({ where: { id: classId, tenant_id: tenantId } });
  if (!targetClass) return { targetClass: null, students: [] };

  const targetBaseYear = extractBaseYear(targetClass.academic_year);

  // Every active student for the tenant — a full scan is unavoidable
  // here, the same trade-off the Students list itself makes for a
  // historical year: a student who has since moved to a DIFFERENT
  // current class might still have belonged to THIS one during its year.
  const allActive = await Student.findAll({
    where: { tenant_id: tenantId, status: 'active' },
    include: [
      { model: User, as: 'user', attributes: { exclude: ['password'] } },
      { model: Class, as: 'class', attributes: ['id', 'grade', 'education_level', 'academic_year', 'campus_id'] },
      { model: Section, as: 'section', attributes: ['id', 'name'] },
    ],
  });

  const studentIds = allActive.map((s) => s.id);
  const promotions = studentIds.length
    ? await StudentPromotion.findAll({
        where: { tenant_id: tenantId, student_id: studentIds, reverted_at: null },
        include: [
          { model: Class, as: 'fromClass', attributes: ['grade', 'education_level'] },
          { model: Class, as: 'toClass', attributes: ['grade', 'education_level'] },
        ],
      })
    : [];
  const eventsByStudent = new Map();
  for (const p of promotions) {
    if (!eventsByStudent.has(p.student_id)) eventsByStudent.set(p.student_id, []);
    eventsByStudent.get(p.student_id).push({
      action: p.action,
      from_base_year: p.from_academic_year ? extractBaseYear(p.from_academic_year) : null,
      from_grade: p.fromClass?.grade ?? null,
      from_education_level: p.fromClass?.education_level ?? null,
      to_base_year: p.to_academic_year ? extractBaseYear(p.to_academic_year) : null,
      to_grade: p.toClass?.grade ?? null,
      to_education_level: p.toClass?.education_level ?? null,
      from_class_id: p.from_class_id,
      to_class_id: p.to_class_id,
    });
  }

  const tenant = await Tenant.findByPk(tenantId, { attributes: ['createdAt', 'settings'] });
  const startBaseYear = systemStartBaseYear(tenant);

  const students = allActive.filter((student) => {
    const events = eventsByStudent.get(student.id) || [];

    // Fast path, and the only path that respects a section filter: the
    // student is CURRENTLY sitting in this exact class row.
    if (student.class_id === classId) {
      return !sectionId || student.section_id === sectionId;
    }
    // A real promotion record explicitly names this class row, even
    // though the student has since moved on — that's a fact, not a
    // guess, so it wins regardless of arithmetic projection.
    if (events.some((e) => e.from_class_id === classId || e.to_class_id === classId)) {
      return !sectionId;
    }
    if (sectionId) return false; // no historical section data to match against below

    const admissionBaseYear = student.admission_date ? new Date(student.admission_date).getFullYear() : null;
    const enrollment = resolveHistoricalEnrollment({
      current: student.class ? {
        grade: student.class.grade, education_level: student.class.education_level, academic_year: student.class.academic_year,
      } : null,
      admissionBaseYear,
      promotionEvents: events,
      targetBaseYear,
      systemStartBaseYear: startBaseYear,
    });
    return enrollment.visible
      && enrollment.grade === targetClass.grade
      && enrollment.education_level === targetClass.education_level
      && student.campus_id === targetClass.campus_id;
  });

  return { targetClass, students };
};

/**
 * The reverse direction of findStudentsEnrolledInClass: given ONE
 * student, which actual Class row were they in during a specific past
 * or future year? Used anywhere a calculation needs "the fee structure/
 * timetable/etc. for this student's class AS OF year Y" — most
 * importantly `expectedForStudent` in feeController, which otherwise
 * always used the student's CURRENT class_id no matter which year's
 * fees were actually being asked about.
 *
 * Real promotion history wins when it exists (exact class_id, no
 * guessing); otherwise falls back to resolveHistoricalEnrollment's
 * projection and looks up whichever real Class row matches that
 * projected grade/level/campus for the target year, if one exists.
 */
export const resolveStudentClassForYear = async ({ tenantId, student, targetBaseYear }) => {
  if (!student.class_id) return null;

  const currentClass = await Class.findByPk(student.class_id, {
    attributes: ['id', 'grade', 'education_level', 'academic_year', 'campus_id'],
  });
  if (!currentClass) return null;
  if (extractBaseYear(currentClass.academic_year) === targetBaseYear) return currentClass;

  const promotions = await StudentPromotion.findAll({
    where: { tenant_id: tenantId, student_id: student.id, reverted_at: null },
    include: [
      { model: Class, as: 'fromClass', attributes: ['grade', 'education_level'] },
      { model: Class, as: 'toClass', attributes: ['grade', 'education_level'] },
    ],
  });

  const fromMatch = promotions.find((p) => p.from_academic_year && extractBaseYear(p.from_academic_year) === targetBaseYear);
  if (fromMatch?.from_class_id) return Class.findByPk(fromMatch.from_class_id);
  const toMatch = promotions.find((p) => p.to_academic_year && extractBaseYear(p.to_academic_year) === targetBaseYear);
  if (toMatch?.to_class_id) return Class.findByPk(toMatch.to_class_id);

  const events = promotions.map((p) => ({
    action: p.action,
    from_base_year: p.from_academic_year ? extractBaseYear(p.from_academic_year) : null,
    from_grade: p.fromClass?.grade ?? null,
    from_education_level: p.fromClass?.education_level ?? null,
    to_base_year: p.to_academic_year ? extractBaseYear(p.to_academic_year) : null,
    to_grade: p.toClass?.grade ?? null,
    to_education_level: p.toClass?.education_level ?? null,
  }));

  const tenant = await Tenant.findByPk(tenantId, { attributes: ['createdAt', 'settings'] });
  const admissionBaseYear = student.admission_date ? new Date(student.admission_date).getFullYear() : null;
  const enrollment = resolveHistoricalEnrollment({
    current: { grade: currentClass.grade, education_level: currentClass.education_level, academic_year: currentClass.academic_year },
    admissionBaseYear,
    promotionEvents: events,
    targetBaseYear,
    systemStartBaseYear: systemStartBaseYear(tenant),
  });
  if (!enrollment.visible) return null;

  return Class.findOne({
    where: {
      tenant_id: tenantId, campus_id: student.campus_id,
      grade: enrollment.grade, education_level: enrollment.education_level,
      // The exact expected string for that level/year — e.g. "2025" for
      // O-Level, "2025-2026" for A-Level — rather than a loose base-year
      // match, since we already know precisely which format this row
      // must use.
      academic_year: formatAcademicYear(targetBaseYear, enrollment.education_level),
    },
  });
};
