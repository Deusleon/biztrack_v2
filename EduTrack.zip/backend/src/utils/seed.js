/**
 * seed.js — Comprehensive demo-data seeder for EduTrack.
 * ========================================================
 * Creates a realistic secondary-school dataset so every module (Students,
 * Staff, Classes, Subjects, Attendance, and — most importantly — the
 * Timetable module) has enough data to be tested end-to-end:
 *
 *   • 1 Tenant + 1 Campus
 *   • ~20 Users across every role (admin, principal, teachers, support staff)
 *   • 6 Classes (Form I – Form VI) with 16 Sections total
 *   • 16 Subjects (O-Level + A-Level)
 *   • ~14 Teacher/Staff profiles, each qualified to teach specific subjects
 *   • ~380 Students spread realistically across every section
 *   • Timetable module demo data: school-week settings (O-Level and
 *     A-Level separately), class-subject assignments for every class, and
 *     a fully AUTO-FILLED timetable for every section in the school — so
 *     the Timetable pages show real, working data the moment you log in.
 *
 * Run with:  npm run seed   (from the backend/ folder)
 */
import dotenv from 'dotenv';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import {
  Tenant, User, Campus, Class, Section, Subject, Student, Staff,
  TimetableSettings, ClassSubject, TimetableEntry,
  Exam, Grade, FeeStructure, Payment,
  Contact, ContactGroup, MessageTemplate, Message, MessageRecipient,
  SmsBalance, SmsTransaction, SmsGatewaySettings,
  Route, TransportAllocation,
  Book, BookIssue,
  Vehicle, VehicleMaintenanceRecord,
  LeaveType, LeaveBalance, LeaveRequest,
  ExpenseCategory, Expense,
  Hostel, HostelRoom, HostelAllocation,
  PayrollPeriod, PayrollItem,
  InventoryItem, InventoryTransaction,
  RolePermission,
} from '../models/index.js';
import { Op } from 'sequelize';
import { syncDatabase } from '../config/database.js';
import { computeGrade } from '../controllers/examController.js';
import { formatAcademicYear, extractBaseYear, currentBaseYear } from './academicYear.js';

dotenv.config();

// ── Never run this against a live system by accident ─────────────────────────
// It drops every table and refills them, which would erase a real school's data.
if (process.env.NODE_ENV === 'production' && process.env.I_UNDERSTAND_THIS_ERASES_ALL_DATA !== 'yes') {
  console.error('\n✗ Refusing to run: NODE_ENV is "production" and this script ERASES the whole database.');
  console.error('  For a real installation use  npm run seed:production  (adds only the essentials, deletes nothing).');
  console.error('  If you really mean to wipe this database, set I_UNDERSTAND_THIS_ERASES_ALL_DATA=yes and run it again.\n');
  process.exit(1);
}

const uuid = () => crypto.randomUUID();
// Anchored to THIS YEAR (whenever seed.js actually runs) rather than a
// hardcoded string — so the demo data always lands under the academic
// year the app shows by default (see AcademicYearContext.jsx, which
// defaults to the current calendar year and — critically — will not even
// OFFER a year earlier than the tenant's own createdAt year). A fixed
// past year here would silently fall outside that floor the very next
// time this seed is run, making all the demo data invisible until the
// person manually widens/changes the year picker.
const SEED_BASE_YEAR = currentBaseYear();
const ACADEMIC_YEAR = formatAcademicYear(SEED_BASE_YEAR, 'a_level'); // e.g. "2026-2027"
// How far every hardcoded demo date below (originally written relative to
// calendar year 2025) needs to move to land in the same relative spot
// this year — e.g. "the exam 2 months into the school year" stays 2
// months into whatever year is actually current, instead of literally
// being January 2025 forever. Applied via shiftYear() to every literal
// date string in this file (leave requests, payroll, vehicle expiries,
// exam windows, ...) so none of them silently drift into the past.
const YEAR_SHIFT = SEED_BASE_YEAR - 2025;
const shiftYear = (isoDate) => {
  const [y, ...rest] = isoDate.split('-');
  return [String(Number(y) + YEAR_SHIFT), ...rest].join('-');
};

// ─── Name pools (used to generate realistic, varied student names) ────────────
const MALE_FIRST_NAMES = [
  'Juma', 'Baraka', 'Emmanuel', 'Frank', 'Godfrey', 'Hassan', 'Ibrahim', 'Joseph',
  'Kelvin', 'Lucas', 'Michael', 'Nasra', 'Omary', 'Peter', 'Rashid', 'Samuel',
  'Thomas', 'Victor', 'William', 'Yusuf', 'Zephania', 'Daniel', 'Erick', 'Fadhili',
];
const FEMALE_FIRST_NAMES = [
  'Amina', 'Beatrice', 'Catherine', 'Dorcas', 'Esther', 'Fatuma', 'Grace', 'Halima',
  'Irene', 'Joyce', 'Khadija', 'Lightness', 'Mary', 'Neema', 'Olivia', 'Prisca',
  'Queen', 'Rehema', 'Sarah', 'Tatu', 'Upendo', 'Veronica', 'Winfrida', 'Zainab',
];
const LAST_NAMES = [
  'Mushi', 'Kileo', 'Mrema', 'Kessy', 'Mwakalinga', 'Shirima', 'Ndosi', 'Massawe',
  'Temba', 'Lyimo', 'Kimaro', 'Moshi', 'Nnko', 'Swai', 'Urio', 'Mallya',
  'Msaki', 'Ngowi', 'Sanga', 'Chuwa', 'Mosha', 'Laizer', 'Mbise',
  'Materu', 'Minja', 'Mmbaga', 'Kimario', 'Shayo',
];

const pick = (arr, i) => arr[((i % arr.length) + arr.length) % arr.length];

/** Pre-hash a password once so bulkCreate can insert it directly (skips
 * the model's beforeCreate hook, which would otherwise re-hash it once
 * per row — far too slow for hundreds of student accounts). */
const prehash = async (plain) => {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(plain, salt);
};

const seedDatabase = async () => {
  try {
    console.log('🌱 Starting database seeding...\n');

    // Sync database (create tables). WARNING: drops existing tables.
    await syncDatabase({ force: true });
    console.log('✅ Database tables created');

    // ── Tenant + Campus ───────────────────────────────────────────────────
    const tenant = await Tenant.create({
      name: 'RealFaith Secondary School',
      slug: 'realfaith-secondary',
      email: 'info@realfaith.ac.tz',
      phone: '255754000001',
      address: 'P.O. Box 100, Dar es Salaam, Tanzania',
      status: 'active',
      settings: {
        academic_year: ACADEMIC_YEAR,
        timezone: 'Africa/Dar_es_Salaam',
        currency: 'TZS',
        motto: 'Education Is Light For Future',
      },
    });
    console.log('✅ Tenant created:', tenant.name);

    const campus = await Campus.create({
      tenant_id: tenant.id,
      name: 'Main Campus',
      code: 'LLS01',
      address: 'Kinondoni Road',
      city: 'Dar es Salaam',
      state: 'Dar es Salaam Region',
      country: 'Tanzania',
      postal_code: '11101',
      phone: '255754000001',
      email: 'maincampus@realfaith.ac.tz',
      status: 'active',
    });
    console.log('✅ Campus created:', campus.name);

    // ── Core admin users ──────────────────────────────────────────────────
    const superAdmin = await User.create({
      tenant_id: tenant.id, email: 'superadmin@edutrack.com', password: 'Admin@123',
      first_name: 'Super', last_name: 'Admin', role: 'super_admin', status: 'active',
    });
    const admin = await User.create({
      tenant_id: tenant.id, email: 'admin@realfaith.ac.tz', password: 'Admin@123',
      first_name: 'School', last_name: 'Admin', role: 'admin', status: 'active',
    });
    const principal = await User.create({
      tenant_id: tenant.id, email: 'principal@realfaith.ac.tz', password: 'Principal@123',
      first_name: 'John', last_name: 'Materu', role: 'principal', status: 'active',
    });
    await campus.update({ principal_id: principal.id });
    console.log('✅ Admin, Principal, Super Admin created');

    // ── Subjects (matches the printed timetable abbreviations) ─────────────
    const subjectDefs = [
      { name: 'Kiswahili', code: 'KISW', credits: 4 },
      { name: 'English Language', code: 'ENGLG', credits: 4 },
      { name: 'Literature in English', code: 'LENG', credits: 2 },
      { name: 'Basic Mathematics', code: 'BMATHS', credits: 5 },
      { name: 'Physics', code: 'PHY', credits: 4 },
      { name: 'Chemistry', code: 'CHEM', credits: 4 },
      { name: 'Biology', code: 'BIO', credits: 4 },
      { name: 'Geography', code: 'GEO', credits: 3 },
      { name: 'History', code: 'HIST', credits: 3 },
      { name: 'Civics', code: 'CIV', credits: 2 },
      { name: 'Religion & Ethics', code: 'HMAAD', credits: 2 },
      { name: 'Business Studies', code: 'BSTUD', credits: 3 },
      { name: 'Book Keeping', code: 'BKEEP', credits: 2 },
      { name: 'Computer Studies', code: 'COMP', credits: 3, elective: true },
      { name: 'Physical Education', code: 'PE', credits: 2, elective: true },
      { name: 'General Studies', code: 'GS', credits: 2 },
    ];
    const subjects = [];
    for (const sd of subjectDefs) {
      const s = await Subject.create({
        tenant_id: tenant.id, campus_id: campus.id,
        name: sd.name, code: sd.code,
        description: `${sd.name} curriculum`,
        is_elective: !!sd.elective, credits: sd.credits, status: 'active',
      });
      subjects.push(s);
    }
    const subjByCode = Object.fromEntries(subjects.map((s) => [s.code, s]));
    console.log(`✅ ${subjects.length} subjects created`);

    // ── Teachers (Staff) ────────────────────────────────────────────────────
    // How many periods a subject needs EACH WEEK, ACROSS THE WHOLE SCHOOL,
    // is periods_per_week × how many sections take it. For a subject taught
    // in every O-Level form (12 sections) at 4 periods/week, that's 48 —
    // more than any single teacher can cover (max 36 periods/week — every
    // period of the school week). So heavily-loaded subjects are split
    // across 2-3 teachers by "scope": 'junior' (Form I-II), 'senior' (Form
    // III-IV), 'o_level' (all of Form I-IV), or 'a_level' (Form V-VI).
    // `scope: 'junior+a'` is a junior-form teacher who also picks up that
    // subject's (lighter) A-Level load. This is what makes Form I A's
    // Monday actually differ from Form III A's Monday — different classes
    // are simply taught by different people, exactly as in a real school.
    const teacherDefs = [
      { first: 'Ramadhani', last: 'Kileo', dept: 'Kiswahili', subs: ['KISW'], scope: 'junior' },
      { first: 'Halima', last: 'Mchome', dept: 'Kiswahili', subs: ['KISW'], scope: 'senior' },
      { first: 'Jane', last: 'Smith', dept: 'English', subs: ['ENGLG'], scope: 'junior+a' },
      { first: 'Peter', last: 'Mushi', dept: 'English', subs: ['ENGLG'], scope: 'senior' },
      { first: 'Emily', last: 'Davis', dept: 'Mathematics', subs: ['BMATHS'], scope: 'junior' },
      { first: 'Anna', last: 'Swai', dept: 'Mathematics', subs: ['BMATHS'], scope: 'senior' },
      { first: 'Baraka', last: 'Sanga', dept: 'Mathematics', subs: ['BMATHS'], scope: 'a_level' },
      { first: 'Michael', last: 'Brown', dept: 'Science', subs: ['PHY'], scope: 'junior' },
      { first: 'Nickson', last: 'Urio', dept: 'Science', subs: ['PHY'], scope: 'senior' },
      { first: 'Josephine', last: 'Kway', dept: 'Science', subs: ['PHY'], scope: 'a_level' },
      { first: 'Zawadi', last: 'Mrema', dept: 'Science', subs: ['CHEM'], scope: 'junior' },
      { first: 'Grace', last: 'Mnyamani', dept: 'Science', subs: ['CHEM'], scope: 'senior' },
      { first: 'Emmanuel', last: 'Rutta', dept: 'Science', subs: ['CHEM'], scope: 'a_level' },
      { first: 'Godwin', last: 'Ndosi', dept: 'Science', subs: ['BIO'], scope: 'junior' },
      { first: 'Lucas', last: 'Mtui', dept: 'Science', subs: ['BIO'], scope: 'senior' },
      { first: 'Neema', last: 'Kilewo', dept: 'Science', subs: ['BIO'], scope: 'a_level' },
      { first: 'Consolata', last: 'Massawe', dept: 'Humanities', subs: ['GEO'], scope: 'junior+a' },
      { first: 'Editha', last: 'Kway', dept: 'Humanities', subs: ['GEO'], scope: 'senior' },
      { first: 'Elias', last: 'Temba', dept: 'Humanities', subs: ['HIST'], scope: 'o_level' },
      { first: 'Yohana', last: 'Mwakyusa', dept: 'Humanities', subs: ['GS', 'HIST'], scope: 'a_level' },
      { first: 'Furaha', last: 'Lyimo', dept: 'Languages', subs: ['LENG'], scope: 'o_level' },
      { first: 'Salome', last: 'Mbwana', dept: 'Religious Studies', subs: ['HMAAD', 'CIV'], scope: 'o_level' },
      { first: 'Deogratius', last: 'Kimaro', dept: 'Commerce', subs: ['BSTUD', 'BKEEP'], scope: 'o_level' },
      { first: 'Happiness', last: 'Moshi', dept: 'ICT', subs: ['COMP'], scope: 'all' },
      { first: 'Salum', last: 'Nnko', dept: 'Sports', subs: ['PE'], scope: 'all' },
    ];
    // Does a teacher's scope cover a given class's group? 'o_level' means
    // any Form I-IV class (junior or senior); 'junior+a' means either the
    // junior forms OR A-Level; 'all' is used only by non-timetabled
    // subjects (COMP, PE) so it's never actually load-bearing here.
    const scopeCoversGroup = (scope, group) => {
      if (scope === 'all') return true;
      if (scope === 'o_level') return group === 'junior' || group === 'senior';
      if (scope === 'junior+a') return group === 'junior' || group === 'a_level';
      return scope === group;
    };
    /** Form I-II = 'junior', Form III-IV = 'senior', Form V-VI = 'a_level'
     * — the three groupings the roster above is split along. */
    const classGroupOf = (className) => {
      if (['Form I', 'Form II'].includes(className)) return 'junior';
      if (['Form III', 'Form IV'].includes(className)) return 'senior';
      return 'a_level';
    };

    const teacherUsers = [];
    const teacherStaff = [];
    let empCounter = 7; // 1-6 reserved for principal/admin/etc below
    for (const t of teacherDefs) {
      const email = `${t.first.toLowerCase()}.${t.last.toLowerCase()}@lucylameck.ac.tz`;
      const u = await User.create({
        tenant_id: tenant.id, email, password: 'Teacher@123',
        first_name: t.first, last_name: t.last, role: 'teacher', status: 'active',
      });
      const subjectIds = t.subs.map((code) => subjByCode[code]?.id).filter(Boolean);
      const staffRow = await Staff.create({
        tenant_id: tenant.id, user_id: u.id, campus_id: campus.id,
        employee_number: `EMP-${SEED_BASE_YEAR}-${String(empCounter++).padStart(3, '0')}`,
        department: t.dept, designation: 'Teacher',
        joining_date: '2021-01-10', contract_type: 'permanent',
        salary: 850000.0, experience_years: 4 + (empCounter % 10),
        teaching_subjects: subjectIds, status: 'active',
        city: 'Dar es Salaam', country: 'Tanzania',
      });
      teacherUsers.push(Object.assign(u, { scope: t.scope, subs: t.subs })); // scope/subs stashed on the instance (in-memory only) for the class-subject assignment step below; doesn't touch any DB column
      teacherStaff.push(staffRow);
    }
    console.log(`✅ ${teacherUsers.length} teachers created`);


    // ── Non-teaching staff ───────────────────────────────────────────────
    await Staff.create({
      tenant_id: tenant.id, user_id: principal.id, campus_id: campus.id,
      employee_number: `EMP-${SEED_BASE_YEAR}-001`, department: 'Administration', designation: 'Principal',
      joining_date: '2018-01-15', contract_type: 'permanent', salary: 1800000.0,
      experience_years: 15, status: 'active', city: 'Dar es Salaam', country: 'Tanzania',
    });

    const supportStaffDefs = [
      { email: 'librarian@lucylameck.ac.tz', first: 'Sarah', last: 'Wilson', role: 'librarian', dept: 'Library', designation: 'Chief Librarian', years: 5 },
      { email: 'accountant@lucylameck.ac.tz', first: 'Robert', last: 'Taylor', role: 'accountant', dept: 'Finance', designation: 'School Accountant', years: 3 },
      { email: 'registrar@lucylameck.ac.tz', first: 'Grace', last: 'Kessy', role: 'admin', dept: 'Administration', designation: 'Academic Registrar', years: 6 },
    ];
    for (const sdef of supportStaffDefs) {
      const u = await User.create({
        tenant_id: tenant.id, email: sdef.email, password: 'Staff@123',
        first_name: sdef.first, last_name: sdef.last, role: sdef.role, status: 'active',
      });
      await Staff.create({
        tenant_id: tenant.id, user_id: u.id, campus_id: campus.id,
        employee_number: `EMP-${SEED_BASE_YEAR}-${String(empCounter++).padStart(3, '0')}`,
        department: sdef.dept, designation: sdef.designation,
        joining_date: '2022-06-01', contract_type: 'permanent', salary: 750000.0,
        experience_years: sdef.years, status: 'active', city: 'Dar es Salaam', country: 'Tanzania',
      });
    }
    console.log('✅ Support staff (librarian, accountant, registrar) created');

    // ── Classes (Form I – Form VI) ────────────────────────────────────────
    const classDefs = [
      { name: 'Form I',   grade: 'Form 1', level: 'o-level', streams: ['A', 'B', 'C'], capacity: 45 },
      { name: 'Form II',  grade: 'Form 2', level: 'o-level', streams: ['A', 'B', 'C'], capacity: 45 },
      { name: 'Form III', grade: 'Form 3', level: 'o-level', streams: ['A', 'B', 'C'], capacity: 42 },
      { name: 'Form IV',  grade: 'Form 4', level: 'o-level', streams: ['A', 'B', 'C'], capacity: 42 },
      { name: 'Form V',   grade: 'Form 5', level: 'a-level', streams: ['Science', 'Arts'], capacity: 35 },
      { name: 'Form VI',  grade: 'Form 6', level: 'a-level', streams: ['Science', 'Arts'], capacity: 35 },
    ];

    const classes = [];
    const sectionsByClassId = {};
    let teacherRoundRobin = 0;
    const baseYear = extractBaseYear(ACADEMIC_YEAR);
    for (const cd of classDefs) {
      // O-Level uses a single-year academic year ("2025"); A-Level uses a
      // two-year span ("2025-2026") — see src/utils/academicYear.js.
      const educationLevel = cd.level === 'o-level' ? 'o_level' : 'a_level';
      const classAcademicYear = formatAcademicYear(baseYear, educationLevel);
      const cls = await Class.create({
        tenant_id: tenant.id, campus_id: campus.id,
        name: cd.name, grade: cd.grade, education_level: educationLevel, academic_year: classAcademicYear,
        capacity: cd.capacity, description: `${cd.name} (${cd.level === 'o-level' ? 'O-Level' : 'A-Level'})`,
        status: 'active',
      });
      classes.push({ ...cd, row: cls });
      sectionsByClassId[cls.id] = [];
      for (const streamName of cd.streams) {
        const teacher = teacherUsers[teacherRoundRobin % teacherUsers.length];
        teacherRoundRobin++;
        const sec = await Section.create({
          tenant_id: tenant.id, class_id: cls.id, name: streamName,
          class_teacher_id: teacher.id,
          capacity: cd.level === 'o-level' ? 40 : 30,
          status: 'active',
        });
        sectionsByClassId[cls.id].push(sec);
      }
    }
    console.log(`✅ ${classes.length} classes created`);
    // Used below by several unrelated demo sections (Messages, Hostel, ...)
    // as a representative "flagship" class to hang a few illustrative demo
    // rows off of — Form I, the school's largest/first class.
    const demoClass = classes[0];
    console.log(`✅ ${Object.values(sectionsByClassId).flat().length} sections created`);

    // ── Students ─────────────────────────────────────────────────────────
    // Bulk-insert for speed: generate raw rows with pre-computed UUIDs +
    // a single pre-hashed password, then bulkCreate Users then Students.
    const studentPassword = await prehash('Student@123');
    const studentUserRows = [];
    const studentRows = [];
    const parentUserRows = [];
    let admissionSeq = 1;

    const baseAgeByGrade = { 'Form 1': 13, 'Form 2': 14, 'Form 3': 15, 'Form 4': 16, 'Form 5': 17, 'Form 6': 18 };

    for (const cd of classes) {
      const sections = sectionsByClassId[cd.row.id];
      for (const sec of sections) {
        const studentsPerSection = 22 + (admissionSeq % 8); // 22-29 students per section
        for (let i = 0; i < studentsPerSection; i++) {
          const isMale = (admissionSeq + i) % 2 === 0;
          const firstName = isMale
            ? pick(MALE_FIRST_NAMES, admissionSeq + i)
            : pick(FEMALE_FIRST_NAMES, admissionSeq + i);
          const lastName = pick(LAST_NAMES, admissionSeq * 3 + i);
          const admissionNumber = `LLS-${SEED_BASE_YEAR}-${String(admissionSeq).padStart(4, '0')}`;
          const email = `${firstName.toLowerCase()}.${lastName.toLowerCase()}${admissionSeq}@student.lucylameck.ac.tz`;
          const userId = uuid();
          const age = baseAgeByGrade[cd.grade] || 15;
          const birthYear = SEED_BASE_YEAR - age;
          const dob = `${birthYear}-${String(1 + (admissionSeq % 12)).padStart(2, '0')}-${String(1 + (admissionSeq % 27)).padStart(2, '0')}`;

          const parentFirstName = pick(isMale ? FEMALE_FIRST_NAMES : MALE_FIRST_NAMES, admissionSeq + 5);
          const parentUserId = uuid();
          const parentEmail = `${parentFirstName.toLowerCase()}.${lastName.toLowerCase()}${admissionSeq}@parent.lucylameck.ac.tz`;
          const parentPhone = `2557${String(10000000 + admissionSeq).slice(0, 8)}`;

          parentUserRows.push({
            id: parentUserId, tenant_id: tenant.id, email: parentEmail, password: studentPassword,
            first_name: parentFirstName, last_name: lastName, role: 'parent', status: 'active',
            phone: parentPhone, created_at: new Date(), updated_at: new Date(),
          });

          studentUserRows.push({
            id: userId, tenant_id: tenant.id, email, password: studentPassword,
            first_name: firstName, last_name: lastName, role: 'student', status: 'active',
            created_at: new Date(), updated_at: new Date(),
          });

          studentRows.push({
            id: uuid(), tenant_id: tenant.id, user_id: userId, campus_id: campus.id,
            class_id: cd.row.id, section_id: sec.id,
            admission_number: admissionNumber,
            admission_date: shiftYear('2025-01-15'),
            date_of_birth: dob,
            gender: isMale ? 'male' : 'female',
            blood_group: pick(['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'], admissionSeq),
            parent_id: parentUserId,
            parent_name: `${parentFirstName} ${lastName}`,
            parent_phone: parentPhone,
            city: 'Dar es Salaam', country: 'Tanzania', status: 'active',
            created_at: new Date(), updated_at: new Date(),
          });

          admissionSeq++;
        }
      }
    }

    // Insert in manageable batches to keep memory/log output reasonable.
    // Parents first (students reference them via parent_id).
    const BATCH = 100;
    for (let i = 0; i < parentUserRows.length; i += BATCH) {
      await User.bulkCreate(parentUserRows.slice(i, i + BATCH), { validate: false });
    }
    for (let i = 0; i < studentUserRows.length; i += BATCH) {
      await User.bulkCreate(studentUserRows.slice(i, i + BATCH), { validate: false });
    }
    for (let i = 0; i < studentRows.length; i += BATCH) {
      await Student.bulkCreate(studentRows.slice(i, i + BATCH), { validate: false });
    }
    console.log(`✅ ${studentRows.length} students created across ${Object.values(sectionsByClassId).flat().length} sections`);
    console.log(`✅ ${parentUserRows.length} parent accounts created and linked (Student.parent_id) — the "parent" role can now actually be tested`);

    // ═══════════════════════════════════════════════════════════════════
    // TIMETABLE MODULE DEMO DATA (rebuilt — 3 simple models)
    // ═══════════════════════════════════════════════════════════════════

    // ── School week settings — Primary/O-Level and A-Level each keep
    // their own (they very commonly differ in real schools). Daily
    // Activities mirror a typical Tanzanian secondary-school pattern:
    // a fixed non-academic slot at the end of each day.
    const dailyActivities = {
      monday: ['Cleanliness'], tuesday: ['Subject Clubs'], wednesday: ['Religion', 'Cleanliness'],
      thursday: ['Clubs'], friday: ['Mosque', 'Debate', 'Sport & Games'],
    };
    const timetableSettings = await TimetableSettings.create({
      tenant_id: tenant.id, campus_id: campus.id, education_level: 'o_level',
      start_time: '07:30', period_duration: 40, periods_per_day: 8, friday_periods: 4,
      break_after_period: 2, break_duration: 20, lunch_after_period: 6, lunch_duration: 40,
      daily_activities: dailyActivities,
    });
    await TimetableSettings.create({
      tenant_id: tenant.id, campus_id: campus.id, education_level: 'a_level',
      start_time: '07:30', period_duration: 40, periods_per_day: 8, friday_periods: 4,
      break_after_period: 2, break_duration: 20, lunch_after_period: 6, lunch_duration: 40,
      daily_activities: dailyActivities,
    });
    console.log('✅ School week settings created for O-Level and A-Level separately (07:30 start, 8 periods Mon–Thu, 4 on Friday)');

    // ── Class Subjects — what each class studies, how often, by whom ───
    // Weekly capacity per section is 8 periods × 4 full days + 4 on the
    // (half-day) Friday = 36. The two allocations below deliberately sum
    // to a bit LESS than that (34, not 36) — a real class's timetable is
    // almost never packed to literally every last period with zero
    // flexibility, and that flexibility is also what lets Auto-Fill
    // actually succeed: several subjects share a single teacher across
    // multiple streams (see the roster above), and a fully 100%-packed
    // section leaves the scheduler no room at all to work around that.
    const oLevelAllocation = [
      { code: 'KISW', periods: 4 }, { code: 'ENGLG', periods: 4 }, { code: 'LENG', periods: 1 },
      { code: 'BMATHS', periods: 4 }, { code: 'PHY', periods: 4 }, { code: 'CHEM', periods: 4 },
      { code: 'BIO', periods: 4 }, { code: 'GEO', periods: 4 }, { code: 'HIST', periods: 1 },
      { code: 'CIV', periods: 1 }, { code: 'HMAAD', periods: 1 }, { code: 'BSTUD', periods: 1 }, { code: 'BKEEP', periods: 1 },
    ];
    const aLevelAllocation = [
      { code: 'BMATHS', periods: 6 }, { code: 'PHY', periods: 6 }, { code: 'CHEM', periods: 6 },
      { code: 'BIO', periods: 6 }, { code: 'GEO', periods: 2 }, { code: 'HIST', periods: 3 },
      { code: 'GS', periods: 3 }, { code: 'ENGLG', periods: 2 },
    ];
    console.assert(oLevelAllocation.reduce((s, a) => s + a.periods, 0) === 34, 'O-Level demo allocation should leave a little slack under the 36-period weekly capacity');
    console.assert(aLevelAllocation.reduce((s, a) => s + a.periods, 0) === 34, 'A-Level demo allocation should leave a little slack under the 36-period weekly capacity');

    const teacherBySubjectCode = {};
    for (const t of teacherStaff) {
      for (const subjId of t.teaching_subjects || []) {
        if (!teacherBySubjectCode[subjId]) teacherBySubjectCode[subjId] = t.user_id;
      }
    }

    /** Picks the ONE teacher (out of the roster's 1-3 per subject) whose
     * `scope` actually covers this class's group (junior/senior/a_level) —
     * see the roster comment above for why a subject taught school-wide
     * needs more than one teacher, and why that's exactly what makes each
     * class's timetable genuinely different rather than a copy of the rest. */
    const teacherForClassSubject = (code, group) => {
      const match = teacherUsers.find((t) => t.subs?.includes(code) && scopeCoversGroup(t.scope, group));
      return match?.id || teacherBySubjectCode[subjByCode[code]?.id] || null; // falls back to "any qualified teacher" only if the roster has a gap
    };

    let classSubjectCount = 0;
    for (const cd of classes) {
      const allocation = cd.level === 'o-level' ? oLevelAllocation : aLevelAllocation;
      const group = classGroupOf(cd.name);
      const rows = allocation
        .map((a) => subjByCode[a.code] && {
          tenant_id: tenant.id, class_id: cd.row.id, subject_id: subjByCode[a.code].id,
          teacher_id: teacherForClassSubject(a.code, group), periods_per_week: a.periods, academic_year: cd.row.academic_year,
        })
        .filter(Boolean);
      if (rows.length > 0) await ClassSubject.bulkCreate(rows);
      classSubjectCount += rows.length;
    }
    console.log(`✅ ${classSubjectCount} class-subject assignments created`);

    // ── Demo timetable — one GLOBAL scheduling pass across the whole
    // school, not 16 independent per-section runs. Subjects are placed
    // in DOUBLE PERIODS wherever possible (2 consecutive periods, same
    // subject) — mirroring how real Tanzanian secondary schools commonly
    // run their day. Uses each class's own level settings (O-Level vs
    // A-Level periods/day can differ).
    //
    // Why global, not per-section: several subjects are taught by ONE
    // teacher across several sections at once (see the roster above) — a
    // real, unavoidable constraint, since a teacher can only be in one
    // classroom per period. Scheduling section-by-section in isolation
    // lets an early, "easy" section grab slots a later section's SAME
    // teacher then has no room left for, even though a smarter global
    // ordering would have fit everyone. So instead: build one flat list
    // of "requirements" (one per section × subject), sort the TIGHTEST
    // teachers' requirements first (least spare capacity relative to
    // their total load — they have the least room for a bad placement),
    // and place all of them into one shared schedule in a single pass.
    const settingsByLevel = { o_level: timetableSettings, a_level: await TimetableSettings.findOne({ where: { tenant_id: tenant.id, campus_id: campus.id, education_level: 'a_level' } }) };

    const requirements = []; // { sectionId, classId, academicYear, subjectId, teacherId, periodsNeeded, settings }
    for (const cd of classes) {
      const level = cd.level === 'o-level' ? 'o_level' : 'a_level';
      const settings = settingsByLevel[level];
      if (!settings) continue;
      const classSubjectsForClass = await ClassSubject.findAll({ where: { tenant_id: tenant.id, class_id: cd.row.id, academic_year: cd.row.academic_year } });
      for (const sec of sectionsByClassId[cd.row.id]) {
        for (const cs of classSubjectsForClass) {
          requirements.push({
            sectionId: sec.id, classId: cd.row.id, academicYear: cd.row.academic_year,
            subjectId: cs.subject_id, teacherId: cs.teacher_id, periodsNeeded: cs.periods_per_week, settings,
            label: `${cd.name} ${sec.name}`,
          });
        }
      }
    }

    // Small seeded PRNG (mulberry32) so re-running `npm run seed` produces
    // the same demo data every time — important for reproducible testing —
    // while still giving each of the attempts below a genuinely different
    // ordering to try.
    const mulberry32 = (seed) => () => {
      seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
      let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    const shuffle = (arr, rand) => { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

    // Total weekly load committed to each teacher — requirements are
    // processed tightest-teacher-first, since those have the least room
    // for a bad placement decision to cost them a spot later.
    const loadByTeacher = {};
    for (const r of requirements) if (r.teacherId) loadByTeacher[r.teacherId] = (loadByTeacher[r.teacherId] || 0) + r.periodsNeeded;

    /** Runs one full greedy scheduling pass over every requirement and
     * returns however many periods it managed to place. Deterministic
     * greedy scheduling can leave a handful of periods stranded purely
     * because of the order things were tried in — not because no valid
     * arrangement exists — so this gets called several times below with
     * different (seeded) tie-break orderings, keeping whichever attempt
     * placed the most periods. This "random restarts" approach is a
     * standard, simple way to push a greedy bin-packing heuristic much
     * closer to a full solution without writing a real backtracking solver. */
    const runSchedulingPass = (rand, maxPerDay = 2, strategy = 'tight-first') => {
      let ordered = shuffle(requirements, rand);
      if (strategy === 'tight-first') ordered = ordered.sort((a, b) => (loadByTeacher[b.teacherId] || 0) - (loadByTeacher[a.teacherId] || 0));
      else if (strategy === 'loose-first') ordered = ordered.sort((a, b) => (loadByTeacher[a.teacherId] || 0) - (loadByTeacher[b.teacherId] || 0));
      // strategy === 'random': left as the plain shuffle, no load-based sort at all
      const sectionFree = {}; // sectionId -> { day: [periods] }
      const dayCountBySection = {}; // sectionId -> subjectId -> { day: count }
      const teacherBusy = new Set(); // "<teacherId>-<day>-<period>"
      const entryRows = [];
      const shortfalls = [];

      const freeCellsFor = (sectionId, settings) => {
        if (sectionFree[sectionId]) return sectionFree[sectionId];
        const byDay = {};
        for (const day of ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']) {
          const count = day === 'friday' ? settings.friday_periods : settings.periods_per_day;
          byDay[day] = Array.from({ length: count }, (_, i) => i + 1);
        }
        sectionFree[sectionId] = byDay;
        return byDay;
      };

      for (const req of ordered) {
        const free = freeCellsFor(req.sectionId, req.settings);
        const dayCount = dayCountBySection[req.sectionId] || (dayCountBySection[req.sectionId] = {});
        const subjDayCount = dayCount[req.subjectId] || (dayCount[req.subjectId] = {});

        const canPlace = (day, period) => {
          if (!free[day]?.includes(period)) return false;
          if ((subjDayCount[day] || 0) >= maxPerDay) return false;
          if (req.teacherId && teacherBusy.has(`${req.teacherId}-${day}-${period}`)) return false;
          return true;
        };
        const markPlaced = (day, period) => {
          free[day] = free[day].filter((p) => p !== period);
          if (req.teacherId) teacherBusy.add(`${req.teacherId}-${day}-${period}`);
          subjDayCount[day] = (subjDayCount[day] || 0) + 1;
          entryRows.push({
            tenant_id: tenant.id, class_id: req.classId, section_id: req.sectionId, academic_year: req.academicYear,
            day, period_number: period, subject_id: req.subjectId, teacher_id: req.teacherId,
          });
        };

        let need = req.periodsNeeded;
        while (need > 0) {
          // Slight randomised jitter alongside "most free room" keeps
          // different attempts from all converging on the same ordering
          // whenever several days are close to equally free.
          const dayOrder = shuffle(['monday', 'tuesday', 'wednesday', 'thursday', 'friday'], rand)
            .sort((a, b) => (free[b]?.length || 0) - (free[a]?.length || 0));
          let placedThisPass = false;
          for (const day of dayOrder) {
            if (need <= 0) break;
            for (const period of [...(free[day] || [])].sort((a, b) => a - b)) {
              if (need <= 0) break;
              if (!canPlace(day, period)) continue;
              markPlaced(day, period);
              need--;
              placedThisPass = true;
              if (need > 0 && canPlace(day, period + 1)) { markPlaced(day, period + 1); need--; }
            }
          }
          if (!placedThisPass) break; // no legal cell anywhere this pass — stop rather than loop forever
        }
        if (need > 0) shortfalls.push({ label: req.label, need });
      }
      return { entryRows, shortfalls };
    };

    let best = null;
    const strategies = ['tight-first', 'loose-first', 'random'];
    for (let attempt = 0; attempt < 300 && (!best || best.shortfalls.length > 0); attempt++) {
      const result = runSchedulingPass(mulberry32(attempt + 1), 2, strategies[attempt % strategies.length]);
      if (!best || result.entryRows.length > best.entryRows.length) best = result;
    }
    // Last resort for whatever a normal (max-2-per-day) schedule still
    // couldn't place: try again allowing up to 3 periods of the same
    // subject on one day. A real school would occasionally do this too
    // (e.g. a lab-heavy science day) rather than leave a class with an
    // actually-empty, unexplained gap in its timetable.
    if (best.shortfalls.length > 0) {
      for (let attempt = 0; attempt < 300 && best.shortfalls.length > 0; attempt++) {
        const result = runSchedulingPass(mulberry32(2000 + attempt), 3, strategies[attempt % strategies.length]);
        if (result.entryRows.length > best.entryRows.length) best = result;
      }
    }
    const { entryRows, shortfalls } = best;

    if (entryRows.length > 0) await TimetableEntry.bulkCreate(entryRows);
    const filledSectionCount = new Set(entryRows.map((e) => e.section_id)).size;
    console.log(`✅ Demo timetable auto-filled for ${filledSectionCount} sections across all ${classes.length} classes — ${entryRows.length} periods placed`);
    if (shortfalls.length > 0) console.log(`⚠️  Incomplete sections: ${shortfalls.map((s) => `${s.label}: ${s.need} period(s) short`).join('; ')}`);

    // ═══════════════════════════════════════════════════════════════════
    // EXAMS & GRADES DEMO DATA
    // ═══════════════════════════════════════════════════════════════════
    // Two exams (Midterm + Final), full marks across EVERY O-level subject,
    // for every section of Form I, II and III — enough real data to browse
    // Results/Report Cards/Class rankings across multiple classes and exams.
    const examDefs = [
      { name: 'Midterm Examination', exam_type: 'Midterm', term: 'Term 1', start_date: shiftYear('2025-10-20'), end_date: shiftYear('2025-10-24'), status: 'ongoing', seedOffset: 42, low: 35, high: 100 },
      { name: 'Final Examination', exam_type: 'Final', term: 'Term 1', start_date: shiftYear('2025-12-01'), end_date: shiftYear('2025-12-05'), status: 'completed', seedOffset: 917, low: 28, high: 98 },
    ];

    const gradedClasses = classes.slice(0, 3); // Form I, II, III
    const gradedSubjectCodes = oLevelAllocation.map((a) => a.code); // every O-level subject
    const oLevelAcademicYear = gradedClasses[0].row.academic_year; // all three share the same O-Level year format

    let totalGradeRows = 0;
    for (const examDef of examDefs) {
      const exam = await Exam.create({
        tenant_id: tenant.id, campus_id: campus.id,
        name: examDef.name, exam_type: examDef.exam_type, academic_year: oLevelAcademicYear, term: examDef.term,
        start_date: examDef.start_date, end_date: examDef.end_date, status: examDef.status,
        class_ids: gradedClasses.map((c) => c.row.id), // demonstrates the exam-to-class linkage feature
      });

      // Deterministic pseudo-random generator (repeatable demo marks, no external dependency)
      let seedRandom = examDef.seedOffset;
      const nextRandom = () => { seedRandom = (seedRandom * 1103515245 + 12345) % 2147483648; return seedRandom / 2147483648; };

      const gradeRows = [];
      for (const cd of gradedClasses) {
        for (const sec of sectionsByClassId[cd.row.id]) {
          const sectionStudents = await Student.findAll({
            where: { tenant_id: tenant.id, class_id: cd.row.id, section_id: sec.id, status: 'active' },
            order: [['admission_number', 'ASC']],
          });
          for (const code of gradedSubjectCodes) {
            const subject = subjByCode[code];
            if (!subject) continue;
            for (const student of sectionStudents) {
              const marks = Math.round(examDef.low + nextRandom() * (examDef.high - examDef.low));
              gradeRows.push({
                id: uuid(), tenant_id: tenant.id, exam_id: exam.id, student_id: student.id, subject_id: subject.id,
                marks_obtained: marks, max_marks: 100, grade: computeGrade(marks),
                created_at: new Date(), updated_at: new Date(),
              });
            }
          }
        }
      }

      const BATCH = 500;
      for (let i = 0; i < gradeRows.length; i += BATCH) {
        await Grade.bulkCreate(gradeRows.slice(i, i + BATCH), { validate: false });
      }
      totalGradeRows += gradeRows.length;
      console.log(`✅ Exam "${exam.name}" created with ${gradeRows.length} grades ` +
        `(${gradedClasses.map((c) => c.name).join(', ')} — all sections — ${gradedSubjectCodes.length} subjects)`);
    }
    console.log(`✅ ${examDefs.length} exams seeded, ${totalGradeRows} total grade records`);

    // ═══════════════════════════════════════════════════════════════════
    // FEES & PAYMENTS DEMO DATA
    // ═══════════════════════════════════════════════════════════════════
    // A typical fee structure for Form I, II and III, plus realistic
    // payment history (some students fully paid, some partial, some
    // unpaid) so Fee Status, Record Payment, and Receipts all have real
    // data to explore immediately.
    const feeItemDefs = [
      { name: 'Tuition Fee', amount: 500000, frequency: 'annually' },
      { name: 'Uniform Fee', amount: 60000, frequency: 'one_time' },
      { name: 'Examination Fee', amount: 20000, frequency: 'one_time' },
      { name: 'Lunch Fee', amount: 150000, frequency: 'annually' },
      // Only charged for the ~9 months school is actually in session — not
      // the 3 holiday months — demonstrating the billing_cycles override.
      { name: 'Transport Fee', amount: 25000, frequency: 'monthly', billing_cycles: 9, applies_to: 'transport' },
    ];

    let feeSeedRandom = 271;
    const feeRandom = () => { feeSeedRandom = (feeSeedRandom * 1103515245 + 12345) % 2147483648; return feeSeedRandom / 2147483648; };

    let structureCount = 0, paymentCount = 0;
    const PAYMENT_METHODS = ['cash', 'bank_transfer', 'online'];

    for (const cd of gradedClasses) { // Form I, II, III — same classes graded above
      const structures = [];
      for (const item of feeItemDefs) {
        const structure = await FeeStructure.create({
          tenant_id: tenant.id, campus_id: campus.id, class_id: cd.row.id,
          name: item.name, amount: item.amount, frequency: item.frequency, billing_cycles: item.billing_cycles || null,
          applies_to: item.applies_to || 'all', academic_year: cd.row.academic_year, status: 'active',
        });
        structures.push(structure);
        structureCount++;
      }
      const totalExpected = structures.reduce((sum, s) => sum + Number(s.amount), 0);

      for (const sec of sectionsByClassId[cd.row.id]) {
        const sectionStudents = await Student.findAll({
          where: { tenant_id: tenant.id, class_id: cd.row.id, section_id: sec.id, status: 'active' },
          order: [['admission_number', 'ASC']],
        });
        for (const student of sectionStudents) {
          const roll = feeRandom();
          // ~40% pay everything in full, ~40% pay partially (one or two
          // items), ~20% haven't paid anything yet.
          if (roll < 0.2) continue; // unpaid

          const itemsToPay = roll < 0.6 ? structures : structures.slice(0, 1 + Math.floor(feeRandom() * (structures.length - 1)));
          for (const item of itemsToPay) {
            const payFraction = roll < 0.6 ? 1 : 0.4 + feeRandom() * 0.5; // full payers pay 100%, partial payers 40-90%
            const amount = Math.round(Number(item.amount) * payFraction);
            if (amount <= 0) continue;
            await Payment.create({
              tenant_id: tenant.id, student_id: student.id, fee_structure_id: item.id,
              amount, payment_method: PAYMENT_METHODS[Math.floor(feeRandom() * PAYMENT_METHODS.length)],
              payment_date: shiftYear('2025-09-15'), status: 'completed', received_by: admin.id,
              remarks: payFraction < 1 ? 'Partial payment' : null,
            });
            paymentCount++;
          }
        }
      }
      console.log(`✅ Fee structures for ${cd.name}: ${structures.length} items totalling TZS ${totalExpected.toLocaleString()}/student`);
    }
    console.log(`✅ ${structureCount} fee structures and ${paymentCount} payments seeded across Form I, II, III`);

    // ═══════════════════════════════════════════════════════════════════
    // MESSAGING DEMO DATA
    // ═══════════════════════════════════════════════════════════════════
    // Contacts — every parent + every staff member, mirroring what
    // "Sync from System" does, so Contacts/Groups/Compose all have real
    // data immediately.
    const contactByUserId = {};
    const parentContacts = [];
    const allStudentsForContacts = await Student.findAll({
      where: { tenant_id: tenant.id, parent_id: { [Op.ne]: null } },
      include: [{ model: User, as: 'parent', attributes: ['id', 'first_name', 'last_name', 'email', 'phone'] }],
    });
    for (const s of allStudentsForContacts) {
      if (!s.parent || contactByUserId[s.parent.id]) continue;
      const contact = await Contact.create({
        tenant_id: tenant.id, campus_id: campus.id,
        name: `${s.parent.first_name} ${s.parent.last_name}`.trim(),
        phone: s.parent.phone || `25570${String(1000000 + Math.floor(Math.random() * 8999999))}`,
        email: s.parent.email || null, type: 'parent', linked_user_id: s.parent.id, created_by: admin.id,
      });
      contactByUserId[s.parent.id] = contact;
      parentContacts.push({ contact, student: s });
    }
    const staffContacts = [];
    for (const t of [...teacherUsers]) {
      if (contactByUserId[t.id]) continue;
      const contact = await Contact.create({
        tenant_id: tenant.id, campus_id: campus.id,
        name: `${t.first_name} ${t.last_name}`.trim(), phone: t.phone || null, email: t.email,
        type: 'staff', linked_user_id: t.id, created_by: admin.id,
      });
      contactByUserId[t.id] = contact;
      staffContacts.push(contact);
    }
    // A couple of external contacts (suppliers) with no linked user — the
    // kind "Sync from System" can never create, only manual entry can.
    await Contact.create({ tenant_id: tenant.id, campus_id: campus.id, name: 'Kilimanjaro Stationers', phone: '255754112233', type: 'supplier', notes: 'Exercise books & stationery supplier', created_by: admin.id });
    await Contact.create({ tenant_id: tenant.id, campus_id: campus.id, name: 'Safari Bus Services', phone: '255754445566', type: 'supplier', notes: 'School transport contractor', created_by: admin.id });
    console.log(`✅ ${parentContacts.length + staffContacts.length + 2} contacts seeded (parents, staff, suppliers)`);

    // Groups — one static example, one dynamic ("smart") example
    const staffGroup = await ContactGroup.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'All Staff', description: 'Every teacher and support staff member',
      is_dynamic: true, dynamic_filter: { role: 'staff' }, created_by: admin.id,
    });
    const allParentsGroup = await ContactGroup.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'All Parents', description: 'Every parent in the school',
      is_dynamic: true, dynamic_filter: { role: 'parent' }, created_by: admin.id,
    });
    await ContactGroup.create({
      tenant_id: tenant.id, campus_id: campus.id, name: `${demoClass.name} Parents`, description: `Parents of ${demoClass.name} students only`,
      parent_group_id: allParentsGroup.id, is_dynamic: true, dynamic_filter: { role: 'parent', class_id: demoClass.row.id }, created_by: admin.id,
    });
    console.log('✅ 3 contact groups seeded (All Staff, All Parents, Form I Parents subgroup)');

    // Templates
    await MessageTemplate.bulkCreate([
      { tenant_id: tenant.id, name: 'Fee Payment Reminder', category: 'fee_reminder', channel: 'sms', body: 'Dear {{name}}, this is a reminder that your child has an outstanding school fee balance. Kindly clear it at your earliest convenience. Thank you.', created_by: admin.id },
      { tenant_id: tenant.id, name: 'Exam Results Ready', category: 'exam_result', channel: 'sms', body: 'Dear {{name}}, your child\'s exam results are now available. Please check the parent portal or contact the school office for details.', created_by: admin.id },
      { tenant_id: tenant.id, name: 'General Announcement', category: 'general', channel: 'sms', body: 'Dear {{name}}, {{message}}. — Lucy Lameck Secondary School', created_by: admin.id },
      { tenant_id: tenant.id, name: 'School Closure Notice', category: 'event', channel: 'sms', body: 'Dear {{name}}, please be informed that the school will be closed on the announced date. Normal classes resume the following day.', created_by: admin.id },
    ]);
    console.log('✅ 4 message templates seeded');

    // SMS balance + a starter transaction, and gateway settings (simulated, inactive by default)
    const smsBalance = await SmsBalance.create({ tenant_id: tenant.id, balance: 1000, cost_per_sms: 1 });
    await SmsTransaction.create({
      tenant_id: tenant.id, type: 'purchase', amount: 1000, balance_after: 1000,
      description: 'Initial demo balance', created_by: admin.id,
    });
    await SmsGatewaySettings.create({ tenant_id: tenant.id, provider: 'simulated', is_active: false });
    console.log('✅ SMS balance seeded (1000 credits) and gateway set to Simulated');

    // One example sent message, so Message History isn't empty on first login
    const announcementTemplate = await MessageTemplate.findOne({ where: { tenant_id: tenant.id, name: 'General Announcement' } });
    const welcomeMessage = await Message.create({
      tenant_id: tenant.id, campus_id: campus.id, sender_id: admin.id, channel: 'sms',
      body: 'Dear Parent/Guardian, welcome to the new academic year! We look forward to a great term ahead. — Lucy Lameck Secondary School',
      recipient_type: 'group', recipient_summary: `All Parents (${parentContacts.length})`,
      status: 'sent', sent_at: new Date(), total_recipients: parentContacts.length, sent_count: parentContacts.length, cost: parentContacts.length,
    });
    const recipientRows = parentContacts.slice(0, 40).map(({ contact }) => ({
      message_id: welcomeMessage.id, contact_id: contact.id, name_snapshot: contact.name, phone_snapshot: contact.phone,
      status: 'sent', sent_at: new Date(),
    }));
    if (recipientRows.length > 0) await MessageRecipient.bulkCreate(recipientRows);
    if (parentContacts.length > 0) {
      await smsBalance.update({ balance: Number(smsBalance.balance) - parentContacts.length });
      await SmsTransaction.create({
        tenant_id: tenant.id, type: 'deduction', amount: -parentContacts.length, balance_after: Number(smsBalance.balance),
        reference: welcomeMessage.id, description: 'Message: "Dear Parent/Guardian, welcome to the new academic year!..."', created_by: admin.id,
      });
    }
    console.log(`✅ 1 example sent message seeded (welcome SMS to ${parentContacts.length} parents)`);

    // ═══════════════════════════════════════════════════════════════════
    // TRANSPORT DEMO DATA
    // ═══════════════════════════════════════════════════════════════════
    const vehicleDefs = [
      { registration_number: 'T123 ABC', make: 'Toyota', model: 'Coaster', year: 2019, capacity: 40, description: 'Main school bus for the Kariakoo route.', driver_name: 'Juma Mwakalinga', driver_phone: '255754112211', driver_license_number: 'DL-2201948', insurance_expiry: shiftYear('2026-06-30'), inspection_expiry: shiftYear('2026-03-15') },
      { registration_number: 'T456 DEF', make: 'Isuzu', model: 'NPR', year: 2020, capacity: 35, description: 'Serves the Mbezi/Tegeta area.', driver_name: 'Elias Chuwa', driver_phone: '255754223322', driver_license_number: 'DL-2301122', insurance_expiry: shiftYear('2026-05-20'), inspection_expiry: shiftYear('2026-02-10') },
      { registration_number: 'T789 GHI', make: 'Toyota', model: 'Hiace', year: 2018, capacity: 30, description: 'Smaller vehicle covering Tabata/Buguruni.', driver_name: 'Godfrey Mushi', driver_phone: '255754334433', driver_license_number: 'DL-2101873', insurance_expiry: shiftYear('2025-12-01'), inspection_expiry: shiftYear('2025-11-01') },
    ];
    const vehicles = [];
    for (const vd of vehicleDefs) {
      const vehicle = await Vehicle.create({ tenant_id: tenant.id, campus_id: campus.id, ...vd, status: 'active' });
      vehicles.push(vehicle);
    }
    // A couple of maintenance records so the history isn't empty on first look.
    await VehicleMaintenanceRecord.create({
      tenant_id: tenant.id, vehicle_id: vehicles[0].id, service_date: shiftYear('2025-09-10'), service_type: 'Full Service',
      cost: 450000, performed_by: 'Kariakoo Auto Garage', next_service_date: shiftYear('2026-03-10'), notes: 'Routine 10,000km service.', created_by: admin.id,
    });
    await VehicleMaintenanceRecord.create({
      tenant_id: tenant.id, vehicle_id: vehicles[1].id, service_date: shiftYear('2025-10-02'), service_type: 'Tire Replacement',
      cost: 280000, performed_by: 'Mbezi Tyre Center', notes: 'Replaced 2 rear tires.', created_by: admin.id,
    });
    console.log(`✅ ${vehicles.length} vehicles seeded with 2 maintenance records`);

    const routeDefs = [
      { name: 'Kariakoo Route', route_number: 'R1', vehicle: vehicles[0], stops: ['Kariakoo Market', 'Mnazi Mmoja', 'Posta', 'Lucy Lameck Secondary'] },
      { name: 'Mbezi Route', route_number: 'R2', vehicle: vehicles[1], stops: ['Mbezi Beach', 'Mbezi Louis', 'Tegeta', 'Lucy Lameck Secondary'] },
      { name: 'Tabata Route', route_number: 'R3', vehicle: vehicles[2], stops: ['Tabata Kimanga', 'Tabata Segerea', 'Buguruni', 'Lucy Lameck Secondary'] },
    ];
    const routes = [];
    for (const rd of routeDefs) {
      const route = await Route.create({
        tenant_id: tenant.id, campus_id: campus.id, name: rd.name, route_number: rd.route_number,
        vehicle_id: rd.vehicle.id, driver_name: rd.vehicle.driver_name, driver_phone: rd.vehicle.driver_phone,
        vehicle_number: rd.vehicle.registration_number, capacity: rd.vehicle.capacity, stops: rd.stops, status: 'active',
      });
      routes.push(route);
    }
    // Assign roughly a third of Form I A's students to each route, so
    // Transport has real occupancy to look at immediately.
    const formIAStudents = await Student.findAll({
      where: { tenant_id: tenant.id, class_id: demoClass.row.id, section_id: sectionsByClassId[demoClass.row.id][0].id, status: 'active' },
      order: [['admission_number', 'ASC']],
    });
    let transportAssignedCount = 0;
    for (let i = 0; i < formIAStudents.length; i++) {
      if (i % 3 !== 0) continue; // assign every 3rd student, spread across the 3 routes
      const student = formIAStudents[i];
      const route = routes[Math.floor(i / 3) % routes.length];
      const stop = route.stops[i % route.stops.length];
      await TransportAllocation.create({
        tenant_id: tenant.id, student_id: student.id, route_id: route.id,
        pickup_point: stop, drop_point: stop, status: 'active',
      });
      transportAssignedCount++;
    }
    console.log(`✅ ${routes.length} transport routes seeded with ${transportAssignedCount} students assigned (Form I A)`);

    // ═══════════════════════════════════════════════════════════════════
    // LIBRARY DEMO DATA
    // ═══════════════════════════════════════════════════════════════════
    const bookDefs = [
      { title: 'Chemistry for Secondary Schools', author: 'J. Mwakalinga', category: 'Science', total_copies: 5, location: 'Shelf A1', isbn: '978-9976-1-001-1' },
      { title: 'Basic Mathematics Form I-IV', author: 'A. Komba', category: 'Mathematics', total_copies: 6, location: 'Shelf A2', isbn: '978-9976-1-002-8' },
      { title: 'English Grammar in Use', author: 'R. Murphy', category: 'Language', total_copies: 4, location: 'Shelf B1', isbn: '978-0-521-1-003' },
      { title: 'A History of Tanzania', author: 'I. Kimambo', category: 'History', total_copies: 3, location: 'Shelf C1', isbn: '978-9976-1-004-2' },
      { title: 'Biology for East Africa', author: 'D. Materu', category: 'Science', total_copies: 5, location: 'Shelf A1', isbn: '978-9976-1-005-9' },
      { title: 'Things Fall Apart', author: 'Chinua Achebe', category: 'Fiction', total_copies: 3, location: 'Shelf D1', isbn: '978-0-435-9-006' },
      { title: 'Civics for Secondary Schools', author: 'F. Shayo', category: 'Civics', total_copies: 4, location: 'Shelf C2', isbn: '978-9976-1-007-6' },
      { title: 'Geography of Tanzania', author: 'P. Mbogoni', category: 'Geography', total_copies: 3, location: 'Shelf C1', isbn: '978-9976-1-008-3' },
    ];
    const seededBooks = [];
    for (const bd of bookDefs) {
      const book = await Book.create({ tenant_id: tenant.id, ...bd, available_copies: bd.total_copies, status: 'active' });
      seededBooks.push(book);
    }
    // Issue a handful of copies to Form I A students so Loans isn't empty —
    // a couple deliberately backdated past their due date to demo "overdue".
    let issuedCount = 0;
    for (let i = 0; i < Math.min(5, formIAStudents.length); i++) {
      const student = formIAStudents[i];
      const book = seededBooks[i % seededBooks.length];
      const issueDate = new Date();
      issueDate.setDate(issueDate.getDate() - (i === 0 ? 20 : 3)); // first one overdue, rest recent
      const dueDate = new Date(issueDate);
      dueDate.setDate(dueDate.getDate() + 14);
      await BookIssue.create({
        tenant_id: tenant.id, book_id: book.id, user_id: student.user_id,
        issue_date: issueDate.toISOString().slice(0, 10), due_date: dueDate.toISOString().slice(0, 10),
        status: dueDate < new Date() ? 'overdue' : 'issued',
        fine_amount: dueDate < new Date() ? Math.max(0, Math.floor((Date.now() - dueDate.getTime()) / 86400000)) * 500 : 0,
      });
      await book.update({ available_copies: book.available_copies - 1 });
      issuedCount++;
    }
    console.log(`✅ ${seededBooks.length} books seeded, ${issuedCount} copies issued (1 overdue) — open Library to view.`);

    // ═══════════════════════════════════════════════════════════════════
    // LEAVE DEMO DATA
    // ═══════════════════════════════════════════════════════════════════
    // A couple of teachers report directly to the Principal for leave
    // approval — the rest fall back to the Principal automatically since
    // reports_to_id is left unset, demonstrating both paths.
    if (teacherStaff[0]) await teacherStaff[0].update({ reports_to_id: principal.id });
    if (teacherStaff[1]) await teacherStaff[1].update({ reports_to_id: principal.id });

    const leaveTypeDefs = [
      { name: 'Annual Leave', applies_to: 'staff', has_balance: true, default_days_per_year: 21 },
      { name: 'Sick Leave', applies_to: 'staff', has_balance: true, default_days_per_year: 14 },
      { name: 'Maternity/Paternity Leave', applies_to: 'staff', has_balance: true, default_days_per_year: 90 },
      { name: 'Study Leave', applies_to: 'staff', has_balance: false, default_days_per_year: null },
      { name: 'Excuse / Absence', applies_to: 'student', has_balance: false, default_days_per_year: null },
    ];
    const seededLeaveTypes = [];
    for (const lt of leaveTypeDefs) {
      const type = await LeaveType.create({ tenant_id: tenant.id, ...lt, status: 'active' });
      seededLeaveTypes.push(type);
    }
    const annualType = seededLeaveTypes[0];
    const sickType = seededLeaveTypes[1];
    const excuseType = seededLeaveTypes[4];

    // One approved staff leave request (fully through both steps, balance deducted)
    const requester = teacherStaff[2]; // reports_to Principal by fallback (not explicitly set)
    const step1Date = new Date(); step1Date.setDate(step1Date.getDate() - 10);
    const step2Date = new Date(); step2Date.setDate(step2Date.getDate() - 9);
    const approvedLeave = await LeaveRequest.create({
      tenant_id: tenant.id, user_id: requester.user_id, requester_role: 'staff', leave_type_id: sickType.id,
      start_date: shiftYear('2026-01-05'), end_date: shiftYear('2026-01-07'), days_count: 3, reason: 'Flu — doctor recommended rest.',
      current_step: 2, status: 'approved',
      step1_approver_id: principal.id, step1_decision: 'approved', step1_comment: 'Get well soon.', step1_at: step1Date,
      step2_approver_id: principal.id, step2_decision: 'approved', step2_at: step2Date,
    });
    const sickYear = SEED_BASE_YEAR;
    const [sickBalance] = await LeaveBalance.findOrCreate({
      where: { user_id: requester.user_id, leave_type_id: sickType.id, year: sickYear },
      defaults: { tenant_id: tenant.id, user_id: requester.user_id, leave_type_id: sickType.id, year: sickYear, allocated_days: sickType.default_days_per_year },
    });
    await sickBalance.update({ used_days: Number(sickBalance.used_days) + 3 });

    // One pending staff request, awaiting Step 1
    await LeaveRequest.create({
      tenant_id: tenant.id, user_id: teacherStaff[3].user_id, requester_role: 'staff', leave_type_id: annualType.id,
      start_date: shiftYear('2026-04-14'), end_date: shiftYear('2026-04-18'), days_count: 5, reason: 'Family event upcountry.',
      current_step: 1, status: 'pending', step1_approver_id: teacherStaff[3].reports_to_id || principal.id,
    });

    // One pending student excuse request, awaiting their class teacher
    const excuseStudent = formIAStudents[5];
    const demoSectionClassTeacher = (await Class.findByPk(demoClass.row.id))?.class_teacher_id || principal.id;
    if (excuseStudent) {
      await LeaveRequest.create({
        tenant_id: tenant.id, user_id: excuseStudent.user_id, requester_role: 'student', leave_type_id: excuseType.id,
        start_date: shiftYear('2026-03-02'), end_date: shiftYear('2026-03-02'), days_count: 1, reason: 'Hospital appointment.',
        current_step: 1, status: 'pending', step1_approver_id: demoSectionClassTeacher,
      });
    }
    console.log(`✅ ${seededLeaveTypes.length} leave types, 1 approved + 2 pending leave requests seeded — open Leave to view.`);

    // ═══════════════════════════════════════════════════════════════════
    // EXPENSES DEMO DATA
    // ═══════════════════════════════════════════════════════════════════
    const expenseCategoryDefs = [
      { name: 'Utilities', description: 'Electricity, water, internet' },
      { name: 'Maintenance', description: 'Repairs and upkeep of buildings/equipment' },
      { name: 'Supplies', description: 'Stationery, teaching materials, cleaning supplies' },
      { name: 'Transport', description: 'Fuel, vehicle repairs, transport-related costs' },
      { name: 'Salaries & Wages', description: 'Staff salaries and casual labor' },
      { name: 'Food & Catering', description: 'Student meals and staff refreshments' },
    ];
    const seededExpenseCategories = [];
    for (const ec of expenseCategoryDefs) {
      const cat = await ExpenseCategory.create({ tenant_id: tenant.id, ...ec, status: 'active' });
      seededExpenseCategories.push(cat);
    }
    const [utilitiesCat, maintenanceCat, suppliesCat, transportCat, salariesCat, foodCat] = seededExpenseCategories;

    const expenseDefs = [
      { category: utilitiesCat, amount: 850000, expense_date: shiftYear('2026-01-05'), payee: 'TANESCO', description: 'January electricity bill', payment_method: 'bank_transfer', reference_number: 'TNS-2601-4471' },
      { category: utilitiesCat, amount: 320000, expense_date: shiftYear('2026-01-10'), payee: 'DAWASA', description: 'January water bill', payment_method: 'bank_transfer', reference_number: 'DWS-2601-1029' },
      { category: maintenanceCat, amount: 450000, expense_date: shiftYear('2026-01-08'), payee: 'Kariakoo Auto Garage', description: 'School vehicle full service', payment_method: 'cash' },
      { category: suppliesCat, amount: 620000, expense_date: shiftYear('2026-01-12'), payee: 'Kilimanjaro Stationers', description: 'Exercise books and chalk for Term 1', payment_method: 'mobile_money', reference_number: 'MP-778213' },
      { category: transportCat, amount: 280000, expense_date: shiftYear('2026-01-15'), payee: 'Total Energies', description: 'Diesel for school buses', payment_method: 'cash' },
      { category: salariesCat, amount: 12500000, expense_date: shiftYear('2026-01-31'), payee: 'Staff Payroll', description: 'January staff salaries', payment_method: 'bank_transfer', reference_number: 'PAY-JAN26' },
      { category: foodCat, amount: 1800000, expense_date: shiftYear('2026-01-20'), payee: 'Mama Nia Suppliers', description: 'Termly food supplies', payment_method: 'bank_transfer' },
      { category: maintenanceCat, amount: 150000, expense_date: shiftYear('2026-02-02'), payee: 'Local Plumber', description: 'Fixed leaking pipe in Form II block', payment_method: 'cash' },
    ];
    for (const ed of expenseDefs) {
      await Expense.create({
        tenant_id: tenant.id, campus_id: campus.id, category_id: ed.category.id, amount: ed.amount,
        expense_date: ed.expense_date, payee: ed.payee, description: ed.description,
        payment_method: ed.payment_method, reference_number: ed.reference_number || null,
        recorded_by: admin.id, status: 'recorded',
      });
    }
    console.log(`✅ ${seededExpenseCategories.length} expense categories, ${expenseDefs.length} expenses seeded — open Expenses to view.`);

    // ═══════════════════════════════════════════════════════════════════
    // HOSTEL DEMO DATA
    // ═══════════════════════════════════════════════════════════════════
    const hostel1 = await Hostel.create({ tenant_id: tenant.id, campus_id: campus.id, name: 'Amani Boys Hostel', type: 'boys', warden_id: teacherStaff[0]?.user_id || null, total_rooms: 6, address: 'North Wing', status: 'active' });
    const hostel2 = await Hostel.create({ tenant_id: tenant.id, campus_id: campus.id, name: 'Furaha Girls Hostel', type: 'girls', warden_id: teacherStaff[1]?.user_id || null, total_rooms: 6, address: 'South Wing', status: 'active' });

    const seededRooms = [];
    for (let i = 1; i <= 6; i++) {
      const room = await HostelRoom.create({ tenant_id: tenant.id, hostel_id: hostel1.id, room_number: `A${i}`, capacity: 4, occupied: 0, floor: i <= 3 ? '1' : '2', status: 'available' });
      seededRooms.push(room);
    }
    for (let i = 1; i <= 6; i++) {
      const room = await HostelRoom.create({ tenant_id: tenant.id, hostel_id: hostel2.id, room_number: `B${i}`, capacity: 4, occupied: 0, floor: i <= 3 ? '1' : '2', status: 'available' });
      seededRooms.push(room);
    }

    // Assign a handful of Form I A boys/girls into the first room of each hostel, alternating by gender.
    let hostelAssignedCount = 0;
    const boysRoom = seededRooms[0];
    const girlsRoom = seededRooms[6];
    for (const student of formIAStudents) {
      if (hostelAssignedCount >= 6) break;
      const isMale = student.gender === 'male';
      const targetRoom = isMale ? boysRoom : girlsRoom;
      if (targetRoom.occupied >= targetRoom.capacity) continue;
      await HostelAllocation.create({ tenant_id: tenant.id, student_id: student.id, room_id: targetRoom.id, allocation_date: shiftYear('2026-01-10'), status: 'active' });
      await targetRoom.update({ occupied: targetRoom.occupied + 1 });
      hostelAssignedCount++;
    }
    console.log(`✅ 2 hostels, ${seededRooms.length} rooms, ${hostelAssignedCount} students assigned — open Hostel to view.`);

    // ═══════════════════════════════════════════════════════════════════
    // PAYROLL DEMO DATA
    // ═══════════════════════════════════════════════════════════════════
    // January 2026: fully paid (shows the whole lifecycle end-to-end).
    const janPeriod = await PayrollPeriod.create({ tenant_id: tenant.id, campus_id: null, month: 1, year: SEED_BASE_YEAR, status: 'draft' });
    const allStaffForPayroll = await Staff.findAll({ where: { tenant_id: tenant.id, status: 'active' } });
    const janItems = [];
    for (const staff of allStaffForPayroll) {
      const basicSalary = Number(staff.salary || 0);
      const item = await PayrollItem.create({
        tenant_id: tenant.id, payroll_period_id: janPeriod.id, staff_id: staff.id, user_id: staff.user_id,
        basic_salary: basicSalary, allowances: [], deductions: [], gross_pay: basicSalary, total_deductions: 0, net_pay: basicSalary,
      });
      janItems.push(item);
    }
    // Give the Principal's payslip a couple of realistic line items.
    const principalItem = janItems.find((i) => i.user_id === principal.id);
    if (principalItem) {
      const allowances = [{ label: 'Housing Allowance', amount: 300000 }, { label: 'Transport Allowance', amount: 150000 }];
      const deductions = [{ label: 'NSSF (staff contribution)', amount: 90000 }, { label: 'PAYE Tax', amount: 210000 }];
      const gross = Number(principalItem.basic_salary) + 450000;
      await principalItem.update({ allowances, deductions, gross_pay: gross, total_deductions: 300000, net_pay: gross - 300000 });
    }
    const janTotalNet = (await PayrollItem.findAll({ where: { payroll_period_id: janPeriod.id } })).reduce((s, i) => s + Number(i.net_pay), 0);
    const janCategory = await ExpenseCategory.findOne({ where: { tenant_id: tenant.id, name: 'Salaries & Wages' } });
    const janExpense = await Expense.create({
      tenant_id: tenant.id, campus_id: campus.id, category_id: janCategory.id, amount: janTotalNet,
      expense_date: shiftYear('2026-01-31'), payee: 'Staff Payroll', description: `Payroll for January 2026 (${janItems.length} staff)`,
      payment_method: 'bank_transfer', reference_number: `PAY-${SEED_BASE_YEAR}01`, recorded_by: admin.id, status: 'recorded',
    });
    await janPeriod.update({ status: 'paid', processed_by: admin.id, processed_at: shiftYear('2026-01-30'), paid_by: admin.id, paid_at: shiftYear('2026-01-31'), expense_id: janExpense.id });

    // February 2026: left as a draft, ready to generate — shows the "next step" in the app.
    await PayrollPeriod.create({ tenant_id: tenant.id, campus_id: null, month: 2, year: SEED_BASE_YEAR, status: 'draft' });

    console.log(`✅ Payroll: January ${SEED_BASE_YEAR} fully paid (${janItems.length} staff, ${janTotalNet.toLocaleString()} total), February ${SEED_BASE_YEAR} left as a draft — open Payroll to view.`);

    // ═══════════════════════════════════════════════════════════════════
    // INVENTORY DEMO DATA
    // ═══════════════════════════════════════════════════════════════════
    const inventoryDefs = [
      { name: 'Student Desks', item_type: 'asset', category: 'Furniture', unit: 'pcs', quantity_on_hand: 240, location: 'Classrooms', condition: 'good' },
      { name: 'Whiteboard Markers', item_type: 'consumable', category: 'Stationery', unit: 'boxes', quantity_on_hand: 8, reorder_level: 10, location: 'Store Room A', condition: 'new' },
      { name: 'Exercise Books', item_type: 'consumable', category: 'Stationery', unit: 'reams', quantity_on_hand: 45, reorder_level: 15, location: 'Store Room A', condition: 'new' },
      { name: 'Microscopes', item_type: 'asset', category: 'Lab Equipment', unit: 'pcs', quantity_on_hand: 12, location: 'Science Lab', condition: 'good' },
      { name: 'Footballs', item_type: 'asset', category: 'Sports Equipment', unit: 'pcs', quantity_on_hand: 6, location: 'Sports Store', condition: 'fair' },
      { name: 'Projectors', item_type: 'asset', category: 'Electronics', unit: 'pcs', quantity_on_hand: 4, location: 'AV Room', condition: 'good' },
    ];
    const seededInventoryItems = [];
    for (const def of inventoryDefs) {
      const { quantity_on_hand, condition, ...itemFields } = def;
      const breakdown = { new: 0, good: 0, fair: 0, poor: 0, [condition]: quantity_on_hand };
      const item = await InventoryItem.create({
        tenant_id: tenant.id, campus_id: campus.id, ...itemFields,
        quantity_on_hand, condition_breakdown: breakdown, status: 'active',
      });
      await InventoryTransaction.create({
        tenant_id: tenant.id, item_id: item.id, type: 'received', quantity: quantity_on_hand, condition,
        transaction_date: shiftYear('2026-01-05'), notes: 'Initial stock', recorded_by: admin.id,
      });
      seededInventoryItems.push(item);
    }
    // A couple of follow-up movements so History isn't empty on first look.
    const desks = seededInventoryItems[0];
    await InventoryTransaction.create({ tenant_id: tenant.id, item_id: desks.id, type: 'issued', quantity: 40, condition: 'good', issued_to: 'Form I Classrooms', transaction_date: shiftYear('2026-01-15'), notes: null, recorded_by: admin.id });
    await desks.update({ quantity_on_hand: desks.quantity_on_hand - 40, condition_breakdown: { ...desks.condition_breakdown, good: desks.condition_breakdown.good - 40 } });
    const markers = seededInventoryItems[1];
    await InventoryTransaction.create({ tenant_id: tenant.id, item_id: markers.id, type: 'issued', quantity: 4, condition: 'new', issued_to: 'Staff Room', transaction_date: shiftYear('2026-01-20'), notes: null, recorded_by: admin.id });
    await markers.update({ quantity_on_hand: markers.quantity_on_hand - 4, condition_breakdown: { ...markers.condition_breakdown, new: markers.condition_breakdown.new - 4 } });
    // A demo of a mixed-condition delivery — 10 chairs arrived scratched
    // in the same batch as 40 good ones, showing why the breakdown
    // matters instead of one blended total.
    const desksAfterIssue = await InventoryItem.findByPk(desks.id);
    await InventoryTransaction.create({ tenant_id: tenant.id, item_id: desks.id, type: 'received', quantity: 10, condition: 'fair', issued_to: null, transaction_date: shiftYear('2026-01-25'), notes: 'New delivery — 10 arrived with minor scratches', recorded_by: admin.id });
    await desksAfterIssue.update({ quantity_on_hand: desksAfterIssue.quantity_on_hand + 10, condition_breakdown: { ...desksAfterIssue.condition_breakdown, fair: (desksAfterIssue.condition_breakdown.fair || 0) + 10 } });
    console.log(`✅ Inventory: ${seededInventoryItems.length} items seeded (2 below reorder level, 1 with a mixed-condition delivery) — open Inventory to view.`);

    // ═══════════════════════════════════════════════════════════════════
    // ROLE PERMISSIONS — sensible defaults
    // ═══════════════════════════════════════════════════════════════════
    // Preserves the access each role had before routes started checking
    // the new granular permission system (e.g. Accountants could always
    // manage Expenses via a hardcoded role check; now that Expenses
    // routes check the permission system instead, this seeds the
    // equivalent grant so nothing regresses on a fresh install). Admins
    // can adjust any of this from Settings → Permissions afterward.
    const defaultRolePermissions = [
      { role: 'accountant', permissions: ['expenses.view', 'expenses.create', 'expenses.update', 'expenses.delete', 'fees.view', 'fees.create', 'fees.update'] },
      { role: 'transport_manager', permissions: ['transport.view', 'transport.create', 'transport.update', 'transport.delete'] },
      { role: 'hostel_warden', permissions: ['hostel.view', 'hostel.create', 'hostel.update', 'hostel.delete'] },
      { role: 'librarian', permissions: ['library.view', 'library.create', 'library.update', 'library.delete'] },
      { role: 'hr', permissions: ['staff.view', 'staff.update', 'leave.view', 'leave.update', 'payroll.view', 'payroll.update'] },
      { role: 'teacher', permissions: ['attendance.view', 'attendance.create', 'attendance.update', 'exams.view', 'exams.create', 'exams.update'] },
    ];
    for (const rp of defaultRolePermissions) {
      await RolePermission.create({ tenant_id: tenant.id, role: rp.role, permissions: rp.permissions });
    }
    console.log(`✅ Default role permissions seeded for ${defaultRolePermissions.length} roles — open Settings → Permissions to view/adjust.`);

    // ═══════════════════════════════════════════════════════════════════
    console.log('\n🎉 Seeding complete!\n');
    console.log('Demo Login Credentials:');
    console.log('========================================');
    console.log('Super Admin:   superadmin@edutrack.com     / Admin@123');
    console.log('School Admin:  admin@lucylameck.ac.tz      / Admin@123');
    console.log('Principal:     principal@lucylameck.ac.tz  / Principal@123');
    console.log('Teacher:       jane.smith@lucylameck.ac.tz / Teacher@123');
    console.log('Librarian:     librarian@lucylameck.ac.tz  / Staff@123');
    console.log('Accountant:    accountant@lucylameck.ac.tz / Staff@123');
    console.log(`Any student:   ${studentUserRows[0]?.email || '(see students table)'} / Student@123  (Form I A — has results for both exams)`);
    console.log(`Any parent:    ${parentUserRows[0]?.email || '(see users table)'} / Student@123  (parent of the student above)`);
    console.log('========================================\n');
    console.log(`Classes: ${classes.length} | Sections: ${Object.values(sectionsByClassId).flat().length} | Subjects: ${subjects.length} | Teachers: ${teacherUsers.length} | Students: ${studentRows.length}`);
    console.log(`Timetable: school week configured for O-Level and A-Level, ${classSubjectCount} class-subject assignments, ${entryRows.length} periods auto-filled across ${filledSectionCount} sections — open Timetable in the app to view it.`);
    console.log(`Exams: ${examDefs.length} exams (${examDefs.map((e) => e.name).join(', ')}) with ${totalGradeRows} total grades across Form I, II, III (all sections, ${gradedSubjectCodes.length} subjects each) — open Exams > Results to view.`);
    console.log(`Fees: ${structureCount} fee structures and ${paymentCount} payments seeded across Form I, II, III — open Fees > Fee Status to view.`);
    console.log(`Messages: ${parentContacts.length + staffContacts.length + 2} contacts, 3 groups, 4 templates, 1000 SMS credits — open Messages to view.`);
    console.log(`Transport: ${vehicles.length} vehicles, ${routes.length} routes with ${transportAssignedCount} students assigned — open Transport to view.`);
    console.log(`Library: ${seededBooks.length} books, ${issuedCount} loans issued — open Library to view.`);
    console.log(`Leave: ${seededLeaveTypes.length} leave types, 3 sample requests (1 approved, 2 pending) — open Leave to view.`);
    console.log(`Expenses: ${seededExpenseCategories.length} categories, ${expenseDefs.length} expenses seeded — open Expenses to view.`);
    console.log(`Hostel: 2 hostels, ${seededRooms.length} rooms, ${hostelAssignedCount} students assigned — open Hostel to view.`);
    console.log(`Payroll: January ${SEED_BASE_YEAR} fully paid (${janItems.length} staff), February ${SEED_BASE_YEAR} draft ready — open Payroll to view.`);
    console.log(`Inventory: ${seededInventoryItems.length} items seeded — open Inventory to view.\n`);

    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
};

seedDatabase();
