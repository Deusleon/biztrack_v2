// FILE PATH: backend/src/utils/reportCardCalc.js
/**
 * The maths behind a term report card, kept apart from the controller so it
 * can be tested without a database.
 *
 * A report card is one TERM, not one exam. For each subject it shows:
 *   Test    = the average of the student's results (as percentages) across
 *             every TEST in the term — every exam in that term whose type is
 *             not "Final" (Midterm, Quiz, Mock, Continuous Assessment …)
 *   Exam    = the student's result in the term's FINAL exam
 *   Average = the average of the Test and Exam columns
 *   Grade   = the grade for that Average
 *
 * Percentages are used throughout because different tests are marked "out
 * of" different totals; averaging raw marks would let a quiz out of 10 count
 * the same as a test out of 100.
 *
 * If a subject has only tests (the final isn't marked yet), or only the final,
 * its Average is simply the one column that exists — it is never counted as 0.
 */

const round2 = (n) => Math.round(n * 100) / 100;
const mean = (list) => (list.length ? list.reduce((a, b) => a + b, 0) / list.length : null);

export const isFinalExam = (exam) => String(exam?.exam_type || '').trim().toLowerCase() === 'final';

/** Percentage for one Grade row, or null when no mark was entered / no maximum. */
export const percentOf = (g) => {
  if (g.marks_obtained === null || g.marks_obtained === undefined || g.marks_obtained === '') return null;
  const max = Number(g.max_marks);
  if (!max) return null;
  return (Number(g.marks_obtained) / max) * 100;
};

/** Splits a term's exams into the tests and the final exam (the latest one, if a school made several). */
export function splitTermExams(exams) {
  const finals = exams.filter(isFinalExam);
  const finalExam = finals.length
    ? finals.reduce((a, b) => (String(b.start_date || '') >= String(a.start_date || '') ? b : a))
    : null;
  return { tests: exams.filter((e) => !isFinalExam(e)), finalExam };
}

/**
 * One student's subject rows. `grades` are that student's Grade rows across
 * every exam in the term (with `subject` included for the name).
 */
export function subjectRowsFor(grades, { testIds, finalId, gradeFn }) {
  const bySubject = new Map();
  for (const g of grades) {
    const p = percentOf(g);
    if (p === null) continue;
    if (!bySubject.has(g.subject_id)) {
      bySubject.set(g.subject_id, { subject: g.subject?.name || '', tests: [], exam: null });
    }
    const row = bySubject.get(g.subject_id);
    if (finalId && g.exam_id === finalId) {
      row.exam = { pct: p, obtained: Number(g.marks_obtained), max: Number(g.max_marks) };
    } else if (testIds.has(g.exam_id)) {
      row.tests.push(p);
    }
  }
  return [...bySubject.values()]
    .map((r) => {
      const testAvg = mean(r.tests);
      const examPct = r.exam ? r.exam.pct : null;
      const avg = mean([testAvg, examPct].filter((v) => v !== null));
      return {
        subject: r.subject,
        test_average: testAvg !== null ? round2(testAvg) : null,
        test_count: r.tests.length,
        exam_score: r.exam ? round2(r.exam.obtained) : null,
        exam_max: r.exam ? r.exam.max : null,
        exam_percentage: examPct !== null ? round2(examPct) : null,
        average: avg !== null ? round2(avg) : null,
        grade: avg !== null ? gradeFn(avg) : null,
        _avg: avg, // unrounded, for ranking
      };
    })
    .filter((r) => r._avg !== null)
    .sort((a, b) => a.subject.localeCompare(b.subject));
}

/** Total of the subject averages, and their mean — the student's overall result for the term. */
export function overallOf(rows) {
  if (rows.length === 0) return { total: null, total_max: null, average: null };
  const total = rows.reduce((s, r) => s + r._avg, 0);
  return { total: round2(total), total_max: rows.length * 100, average: total / rows.length };
}
