// FILE PATH: backend/src/utils/smsCredentialVault.js
/**
 * smsCredentialVault.js — one saved set of credentials PER SMS provider.
 *
 * The problem this solves: `sms_gateway_settings` has a single api_key /
 * api_secret / sender_id per school. Switching from Meseji to NextSMS meant
 * typing the NextSMS login over the Meseji key, and switching back meant
 * typing the Meseji key in again — nothing was ever kept.
 *
 * How it works without touching the code that sends messages: the three
 * columns on the row stay exactly what every sender already reads — the
 * credentials of the ACTIVE provider ("live"). Beside them,
 * `saved_credentials` (JSONB) remembers every provider's set:
 *
 *   { "meseji":  { api_key, api_secret, sender_id },
 *     "nextsms": { api_key, api_secret, sender_id } }
 *
 * On every save the live set is parked under its own provider, then the
 * target provider's saved set is loaded back into the live columns. Switching
 * gateways therefore swaps credentials in and out; it never loses them.
 *
 * Secrets never leave the server: `publicGatewayView` replaces the raw vault
 * with a summary that only says whether a secret exists.
 */

export const SECRET_MASK = '••••••••';

const isReal = (provider) => Boolean(provider) && provider !== 'simulated';
const hasAny = (c) => Boolean(c && (c.api_key || c.api_secret || c.sender_id || c.system_sender_id));
const EMPTY = { api_key: null, api_secret: null, sender_id: null, system_sender_id: null };

/** A plain-object copy of the stored vault (tolerates null / bad JSON). */
export const readVault = (settings) => {
  const v = settings?.saved_credentials;
  return v && typeof v === 'object' && !Array.isArray(v) ? { ...v } : {};
};

/**
 * Works out what a PUT /sms/gateway should write.
 *
 * `body` is the request body. Only the fields that are present change; the
 * masked secret placeholder means "keep what is saved".
 * Returns { provider, live, vault }.
 */
export const planGatewayUpdate = (settings, body = {}) => {
  const { provider, api_key, api_secret, sender_id, system_sender_id } = body;
  const current = settings.provider;
  const target = provider !== undefined ? provider : current;
  const vault = readVault(settings);

  // 1. Park the live set under the provider it belongs to, so it is never
  //    lost — this also covers rows that pre-date the vault.
  if (isReal(current) && hasAny(settings)) {
    vault[current] = {
      api_key: settings.api_key ?? null,
      api_secret: settings.api_secret ?? null,
      sender_id: settings.sender_id ?? null,
      system_sender_id: settings.system_sender_id ?? null,
    };
  }

  // 2. Start from whatever is already saved for the provider being selected…
  const saved = (isReal(target) && vault[target]) || {};
  const next = {
    api_key: saved.api_key ?? null,
    api_secret: saved.api_secret ?? null,
    sender_id: saved.sender_id ?? null,
    system_sender_id: saved.system_sender_id ?? null,
  };

  // 3. …and lay anything the admin typed on top.
  if (api_key !== undefined) next.api_key = api_key;
  if (api_secret !== undefined && api_secret !== SECRET_MASK) next.api_secret = api_secret;
  if (sender_id !== undefined) next.sender_id = sender_id;
  if (system_sender_id !== undefined) next.system_sender_id = system_sender_id;

  if (isReal(target)) vault[target] = next;
  return { provider: target, live: isReal(target) ? next : { ...EMPTY }, vault };
};

/** Why a provider can't be switched on with these credentials, or null. */
export const missingCredentials = (provider, live) => {
  switch (provider) {
    case 'nextsms':
      return (!live.api_key || !live.api_secret)
        ? 'NextSMS needs both a username and a password before it can be activated. Enter them (as API Key and API Secret) and save again.'
        : null;
    case 'beem_africa':
      return (!live.api_key || !live.api_secret)
        ? 'Beem Africa needs both an API Key and a Secret Key before it can be activated. Enter them and save again.'
        : null;
    case 'meseji':
      return !live.api_key
        ? 'Meseji needs an API key before it can be activated. Paste it into API Key and save again.'
        : null;
    case 'swalasms':
      if (!live.api_key) return 'SwalaSMS needs an API key before it can be activated. Create one in the SwalaSMS dashboard (SMS → API Keys), paste it into API Key and save again.';
      if (!/^swl_(live|test)_\S+$/.test(String(live.api_key).trim())) return 'That does not look like a SwalaSMS API key. Live keys start with "swl_live_" and sandbox keys with "swl_test_".';
      if (!live.sender_id) return 'SwalaSMS needs a Sender ID. Use your approved sender ID — or SWALATECH, SwalaSMS\'s test sender, until yours is approved — and save again.';
      return null;
    default:
      return null;
  }
};

/** { provider: { api_key, sender_id, has_secret } } — everything but the secret. */
export const summarizeVault = (vault) => Object.fromEntries(
  Object.entries(vault)
    .filter(([, c]) => hasAny(c))
    .map(([provider, c]) => [provider, {
      api_key: c.api_key || '',
      sender_id: c.sender_id || '',
      system_sender_id: c.system_sender_id || '',
      has_secret: Boolean(c.api_secret),
    }]),
);

/** The settings row as the browser may see it: secret masked, vault summarised. */
export const publicGatewayView = (settings) => {
  const data = settings.toJSON();
  data.saved_credentials = summarizeVault(readVault(settings));
  if (data.api_secret) data.api_secret = SECRET_MASK;
  return data;
};