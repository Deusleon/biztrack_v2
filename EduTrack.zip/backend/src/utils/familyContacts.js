// FILE PATH: backend/src/utils/familyContacts.js
/**
 * Who to reach about a student, and how.
 *
 * A notice about a student (a payment, exam marks, a fee reminder, an overdue book) goes to the family, not to the student's
 * own phone: pupils rarely have one, and the in-app notice already went to the parent. This works out, for many students at
 * once, the person to notify and their contact details, using the best information the school has, in this order:
 *
 *   1. the parent's own login account (parent_id): their phone and email;
 *   2. what was typed on the admission form (the student's parent_phone / parent_email / parent_name);
 *   3. the student's own account, as a last resort.
 *
 * Returns Map(studentId → { userId, name, phone, email, studentName, source }) — `phone` / `email` may be empty. Nothing here
 * writes to the database.
 */
import { Op } from 'sequelize';
import { Student, User } from '../models/index.js';

/** A generated login address (…@school.local) cannot receive mail, so it is never used as an email contact. */
export const isDeliverableEmail = (email) => {
  const e = String(email || '').trim().toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) && !/\.(local|invalid|test|example|localhost)$/.test(e);
};

const cleanPhone = (p) => { const s = String(p || '').trim(); return s || null; };

export const familyContactsFor = async (tenantId, studentsOrIds) => {
  const list = (studentsOrIds || []).filter(Boolean);
  const ids = list.map((s) => (typeof s === 'object' ? s.id : s));
  if (ids.length === 0) return new Map();

  const students = await Student.findAll({
    where: { tenant_id: tenantId, id: { [Op.in]: ids } },
    attributes: ['id', 'user_id', 'parent_id', 'parent_name', 'parent_phone', 'parent_email'],
    include: [{ model: User, as: 'user', attributes: ['id', 'first_name', 'last_name', 'phone', 'email'], required: false }],
  });
  const parentIds = [...new Set(students.map((s) => s.parent_id).filter(Boolean))];
  const parents = parentIds.length
    ? await User.findAll({ where: { tenant_id: tenantId, id: { [Op.in]: parentIds } }, attributes: ['id', 'first_name', 'last_name', 'phone', 'email'] })
    : [];
  const parentById = new Map(parents.map((p) => [p.id, p]));

  const out = new Map();
  for (const s of students) {
    const parent = s.parent_id ? parentById.get(s.parent_id) : null;
    const studentName = [s.user?.first_name, s.user?.last_name].filter(Boolean).join(' ').trim() || 'your child';
    const phone = cleanPhone(parent?.phone) || cleanPhone(s.parent_phone) || cleanPhone(s.user?.phone);
    const emailCandidates = [parent?.email, s.parent_email, s.user?.email];
    const email = emailCandidates.find(isDeliverableEmail) || null;
    out.set(s.id, {
      userId: s.parent_id || s.user_id || null,
      name: (parent ? [parent.first_name, parent.last_name].filter(Boolean).join(' ').trim() : '') || s.parent_name || studentName,
      phone, email, studentName,
      source: parent?.phone ? 'parent account' : s.parent_phone ? 'admission form' : s.user?.phone ? 'student account' : 'none',
    });
  }
  return out;
};
