// FILE PATH: backend/src/utils/staffRoles.js

/**
 * Roles a staff member can hold. Must match users.role in the database —
 * "support_staff", which the form used to offer, is not one of them, and
 * choosing it failed on save.
 */
export const STAFF_ROLES = [
  'teacher', 'principal', 'admin', 'accountant', 'librarian', 'hr', 'transport_manager', 'hostel_warden',
];

/** Roles that carry school-wide authority — only an administrator can hand these out or take them away. */
const ELEVATED_ROLES = ['admin', 'principal'];
const ADMINISTRATORS = ['super_admin', 'admin'];

const label = (role) => String(role).replace(/_/g, ' ');

/**
 * Whether `actor` may give a staff member `newRole`. `canManageStaff` is whether they hold
 * the staff.update permission (the caller works that out — see utils/permissionEngine.js).
 *
 * Returns null when it is fine, otherwise { status, message }.
 *   currentRole   — the member's role now (null when creating them)
 *   targetUserId  — their user id (null when creating them)
 *
 * Saving a form without changing the role is always fine, so editing someone's
 * phone number does not need role-management rights.
 */
export const roleAssignmentError = ({ actor, currentRole = null, newRole, targetUserId = null, canManageStaff = false }) => {
  if (currentRole && newRole === currentRole) return null; // not a change

  if (!newRole) {
    return { status: 400, message: 'Role is required — choose what this person does at the school.' };
  }
  if (!STAFF_ROLES.includes(newRole)) {
    return { status: 400, message: `"${label(newRole)}" is not a staff role. Choose one of: ${STAFF_ROLES.map(label).join(', ')}.` };
  }
  if (currentRole === 'super_admin') {
    return { status: 403, message: "A super admin's role can't be changed here." };
  }
  if (targetUserId && actor?.id === targetUserId) {
    return { status: 403, message: "You can't change your own role — ask another administrator." };
  }
  if (!canManageStaff) {
    return { status: 403, message: "You don't have permission to assign roles (staff.update). Ask an administrator to grant it." };
  }
  const touchesElevated = ELEVATED_ROLES.includes(newRole) || ELEVATED_ROLES.includes(currentRole);
  if (touchesElevated && !ADMINISTRATORS.includes(actor.role)) {
    return { status: 403, message: 'Only an administrator can grant or change the Admin and Principal roles.' };
  }
  return null;
};
