/**
 * Normalizes any phone number to the shape our SMS gateway and the rest of
 * the system expect: country code + number, no leading '+' (e.g.
 * "255712345678"). Accepts a local "0"-prefixed Tanzanian number, a '+'
 * prefixed one, or one with spaces/dashes. Non-Tanzanian-looking numbers
 * are left alone beyond stripping '+' and whitespace, so this doesn't
 * mangle a legitimately different country code.
 */
export const normalizePhone = (phone) => {
  if (!phone) return phone;
  let p = String(phone).trim().replace(/[\s-]/g, '');
  if (p.startsWith('+')) p = p.slice(1);
  if (p.startsWith('0') && p.length === 10) p = '255' + p.slice(1);
  return p;
};
