#!/usr/bin/env node
/**
 * Subscription test data.
 *
 * Puts ONE school's subscription into a chosen state so every screen of
 * Settings → Subscription (and the top-of-page banner, and the lock-out) can
 * be tested without paying anything and without ClickPesa.
 *
 *   npm run seed:subscription -- list
 *   npm run seed:subscription -- <scenario> [--tenant=<slug | part of name | id>]
 *   npm run seed:subscription -- simulate-paid <order reference | invoice number>
 *
 * Scenarios
 *   trial      free trial, 14 days left              (blue "trial" banner)
 *   active     Standard, termly, 80 days left + paid history and a failed attempt
 *   expiring   Standard, monthly, 3 days left        (amber "expires in 3 days" banner)
 *   grace      Basic, ended yesterday, 2-day grace   (red "access remains for N hours" banner)
 *   expired    Basic, ended 10 days ago              (LOCKED — the school can only sign in and pay)
 *   cancelled  deliberately cancelled                (LOCKED)
 *   pending    leaves the subscription alone and adds an UNPAID Premium/yearly invoice;
 *              then `simulate-paid <reference>` completes it exactly as a ClickPesa
 *              confirmation would (extends the window, sets the plan, marks it paid).
 *
 * Without --tenant the first school in the database is used. Re-running a
 * scenario replaces the invoices this script made before (they carry the
 * gateway name "seed"); real invoices are never touched.
 *
 * ⚠ Development / staging only. `expired` and `cancelled` lock the school out
 * of everything except the subscription page — which is the point of testing
 * them. Put it back with `active` or `trial`.
 */
import 'dotenv/config';
import { Op } from 'sequelize';
import sequelize from '../config/database.js';
import { Tenant, Student, SubscriptionPlan, Subscription, SubscriptionInvoice } from '../models/index.js';
import { seedSubscriptionPlans } from './seedSubscriptionPlans.js';
import { applyPaidInvoice } from '../controllers/subscriptionController.js';

const DAY = 86400000;
const daysFromNow = (n) => new Date(Date.now() + n * DAY);
const CYCLE_DAYS = { monthly: 30, termly: 120, yearly: 365 };
const PRICE_FIELD = { monthly: 'price_monthly', termly: 'price_termly', yearly: 'price_yearly' };

const SCENARIOS = {
  trial:     'Free trial, 14 days left',
  active:    'Standard plan, termly, 80 days left, with payment history',
  expiring:  'Standard plan, monthly, 3 days left (expiry banner)',
  grace:     'Basic plan, ended yesterday, inside the 2-day grace period',
  expired:   'Basic plan, ended 10 days ago — school is LOCKED',
  cancelled: 'Cancelled — school is LOCKED',
  pending:   'Adds an unpaid Premium/yearly invoice for simulate-paid',
};

let seq = 0;
// Seed invoices get their own number range, so they can never collide with a real INV-YYYY-NNNNN.
const invoiceNumber = async () => `INV-SEED-${Date.now().toString(36).toUpperCase()}${++seq}`;
const orderRef = (tag) => `EDUSEED${tag}${Date.now().toString(36)}${seq}`.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();

async function pickTenant(arg) {
  if (arg) {
    const t = await Tenant.findOne({
      where: { [Op.or]: [{ slug: arg }, { name: { [Op.iLike]: `%${arg}%` } }, ...(/^[0-9a-f-]{36}$/i.test(arg) ? [{ id: arg }] : [])] },
    });
    if (!t) throw new Error(`No school matches "${arg}".`);
    return t;
  }
  const t = await Tenant.findOne({ order: [['createdAt', 'ASC']] });
  if (!t) throw new Error('There are no schools in the database yet. Run `npm run seed` first.');
  return t;
}

async function planByCode(code) {
  const p = await SubscriptionPlan.findOne({ where: { code } });
  if (!p) throw new Error(`Plan "${code}" is missing. Start the server once (it seeds the plans) or check subscription_plans.`);
  return p;
}

const lineItems = (plan, cycle) => [{ label: `${plan.name} plan — ${cycle}`, amount: Number(plan[PRICE_FIELD[cycle]]) }];

async function makeInvoice({ tenant, subscription, plan, cycle, status, kind = 'new', start, end, paidAt = null, failure = null, tag }) {
  const total = Number(plan[PRICE_FIELD[cycle]]);
  return SubscriptionInvoice.create({
    tenant_id: tenant.id,
    subscription_id: subscription.id,
    plan_id: plan.id,
    invoice_number: await invoiceNumber(),
    line_items: lineItems(plan, cycle),
    billing_cycle: cycle,
    subtotal: total,
    proration_credit: 0,
    total,
    currency: 'TZS',
    status,
    kind,
    order_reference: orderRef(tag),
    gateway: 'seed',
    gateway_status: status === 'paid' ? 'SUCCESS' : status === 'failed' ? 'FAILED' : 'PENDING',
    payer_phone: '255712345678',
    paid_at: paidAt,
    failure_reason: failure,
    period_start: start,
    period_end: end,
  });
}

async function applyScenario(name, tenant) {
  await seedSubscriptionPlans();
  const [subscription] = await Subscription.findOrCreate({
    where: { tenant_id: tenant.id },
    defaults: { tenant_id: tenant.id, status: 'trial', grace_days: 2 },
  });
  // forget the invoices an earlier run of this script made
  await SubscriptionInvoice.destroy({ where: { tenant_id: tenant.id, gateway: 'seed' } });

  const basic = await planByCode('basic');
  const standard = await planByCode('standard');
  const premium = await planByCode('premium');
  const students = await Student.count({ where: { tenant_id: tenant.id, status: 'active' } });
  const base = { grace_days: 2, auto_renew: false, cancelled_at: null, addons: [], student_count_at_purchase: students };

  switch (name) {
    case 'trial':
      await subscription.update({ ...base, plan_id: null, billing_cycle: 'monthly', status: 'trial', starts_at: daysFromNow(-16), ends_at: daysFromNow(14), amount_paid: 0 });
      break;

    case 'active': {
      await subscription.update({ ...base, plan_id: standard.id, billing_cycle: 'termly', status: 'active', starts_at: daysFromNow(-40), ends_at: daysFromNow(80), amount_paid: standard.price_termly });
      await makeInvoice({ tenant, subscription, plan: basic, cycle: 'monthly', status: 'paid', kind: 'new', start: daysFromNow(-190), end: daysFromNow(-160), paidAt: daysFromNow(-190), tag: 'A' });
      await makeInvoice({ tenant, subscription, plan: basic, cycle: 'monthly', status: 'failed', kind: 'renewal', start: daysFromNow(-160), end: daysFromNow(-130), failure: 'Payment was not approved on the handset', tag: 'B' });
      await makeInvoice({ tenant, subscription, plan: basic, cycle: 'monthly', status: 'paid', kind: 'renewal', start: daysFromNow(-160), end: daysFromNow(-130), paidAt: daysFromNow(-159), tag: 'C' });
      await makeInvoice({ tenant, subscription, plan: standard, cycle: 'termly', status: 'paid', kind: 'upgrade', start: daysFromNow(-40), end: daysFromNow(80), paidAt: daysFromNow(-40), tag: 'D' });
      break;
    }
    case 'expiring':
      await subscription.update({ ...base, plan_id: standard.id, billing_cycle: 'monthly', status: 'active', starts_at: daysFromNow(-27), ends_at: daysFromNow(3), amount_paid: standard.price_monthly });
      await makeInvoice({ tenant, subscription, plan: standard, cycle: 'monthly', status: 'paid', start: daysFromNow(-27), end: daysFromNow(3), paidAt: daysFromNow(-27), tag: 'E' });
      break;

    case 'grace':
      await subscription.update({ ...base, plan_id: basic.id, billing_cycle: 'monthly', status: 'grace', starts_at: daysFromNow(-31), ends_at: daysFromNow(-1), amount_paid: basic.price_monthly });
      await makeInvoice({ tenant, subscription, plan: basic, cycle: 'monthly', status: 'paid', start: daysFromNow(-31), end: daysFromNow(-1), paidAt: daysFromNow(-31), tag: 'F' });
      break;

    case 'expired':
      await subscription.update({ ...base, plan_id: basic.id, billing_cycle: 'monthly', status: 'expired', starts_at: daysFromNow(-40), ends_at: daysFromNow(-10), amount_paid: basic.price_monthly });
      await makeInvoice({ tenant, subscription, plan: basic, cycle: 'monthly', status: 'paid', start: daysFromNow(-40), end: daysFromNow(-10), paidAt: daysFromNow(-40), tag: 'G' });
      break;

    case 'cancelled':
      await subscription.update({ ...base, plan_id: standard.id, billing_cycle: 'monthly', status: 'cancelled', starts_at: daysFromNow(-20), ends_at: daysFromNow(10), amount_paid: standard.price_monthly, cancelled_at: new Date() });
      break;

    case 'pending': {
      const start = new Date();
      const inv = await makeInvoice({ tenant, subscription, plan: premium, cycle: 'yearly', status: 'pending', kind: 'upgrade', start, end: new Date(start.getTime() + CYCLE_DAYS.yearly * DAY), tag: 'P' });
      console.log(`\nUnpaid invoice ${inv.invoice_number}  (${Number(inv.total).toLocaleString()} TZS)`);
      console.log(`Complete it with:  npm run seed:subscription -- simulate-paid ${inv.order_reference}`);
      break;
    }
    default:
      throw new Error(`Unknown scenario "${name}". Try: ${Object.keys(SCENARIOS).join(', ')}`);
  }

  const fresh = await Subscription.findByPk(subscription.id);
  console.log(`\n✓ ${tenant.name}: scenario "${name}" applied`);
  console.log(`  status: ${fresh.status}   plan: ${fresh.plan_id ? (await SubscriptionPlan.findByPk(fresh.plan_id)).name : '—'}   cycle: ${fresh.billing_cycle}`);
  console.log(`  window: ${fresh.starts_at ? fresh.starts_at.toISOString().slice(0, 10) : '—'} → ${fresh.ends_at ? fresh.ends_at.toISOString().slice(0, 10) : '—'}   grace: ${fresh.grace_days} day(s)`);
  if (['expired', 'cancelled'].includes(name)) console.log('  ⚠ This school is now locked. Run the "active" or "trial" scenario to unlock it.');
}

async function simulatePaid(ref) {
  const invoice = await SubscriptionInvoice.findOne({ where: { [Op.or]: [{ order_reference: ref }, { invoice_number: ref }] } });
  if (!invoice) throw new Error(`No invoice found for "${ref}".`);
  if (invoice.status === 'paid') { console.log(`Invoice ${invoice.invoice_number} is already paid.`); return; }
  await invoice.update({ gateway_status: 'SUCCESS' });
  // Wait for the audit entry and the receipt email too, so the script does not exit before they happen.
  await applyPaidInvoice(invoice, { source: 'test (seed script)', awaitNotifications: true });
  const sub = await Subscription.findByPk(invoice.subscription_id);
  console.log(`✓ Invoice ${invoice.invoice_number} marked paid. Subscription is now "${sub.status}" until ${sub.ends_at.toISOString().slice(0, 10)}.`);
}

async function main() {
  const [cmd, arg] = process.argv.slice(2).filter((a) => !a.startsWith('--'));
  const tenantArg = (process.argv.find((a) => a.startsWith('--tenant=')) || '').slice('--tenant='.length) || null;

  if (!cmd || cmd === 'list' || cmd === 'help') {
    console.log('Scenarios:');
    for (const [k, v] of Object.entries(SCENARIOS)) console.log(`  ${k.padEnd(10)} ${v}`);
    console.log('\nnpm run seed:subscription -- <scenario> [--tenant=<slug|name|id>]');
    console.log('npm run seed:subscription -- simulate-paid <order reference | invoice number>');
    return;
  }
  await sequelize.authenticate();
  if (cmd === 'simulate-paid') {
    if (!arg) throw new Error('Give the order reference or invoice number.');
    await simulatePaid(arg);
  } else {
    await applyScenario(cmd, await pickTenant(tenantArg));
  }
}

main()
  .then(() => sequelize.close())
  .catch(async (err) => { console.error(`\n✗ ${err.message}`); await sequelize.close().catch(() => {}); process.exit(1); });
