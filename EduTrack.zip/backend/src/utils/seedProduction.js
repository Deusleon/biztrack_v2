#!/usr/bin/env node
/**
 * seedProduction.js — the starting data for a REAL installation. Nothing else.
 *
 *   1. the subscription plans and add-ons (without them nobody can subscribe);
 *   2. the first school, its main campus, and its administrator (without one nobody can sign in);
 *   3. optionally, the platform developer's login (a super_admin).
 *
 * It does NOT create students, staff, classes, fees, demo exams or any sample content: a school
 * builds those for real through the app. Things the app makes for itself the first time they are
 * needed (the subscription's trial, the "Salaries & Wages" expense category, notification
 * defaults) are left to the app.
 *
 * Safe to run again at any time: it only adds what is missing and never changes or deletes data.
 *
 *   # 1. create an empty database, then build its tables:
 *   npm run db:migrate
 *   # 2. seed it (the administrator's password is YOURS — there is no default):
 *   SEED_SCHOOL_NAME="Lucy Lameck Secondary School" SEED_SCHOOL_EMAIL=info@school.ac.tz \
 *   SEED_ADMIN_EMAIL=admin@school.ac.tz SEED_ADMIN_PASSWORD='a-long-password-1' \
 *   npm run seed:production
 *
 * Settings (environment variables):
 *   SEED_SCHOOL_NAME        required for the first school (skip it to seed plans only)
 *   SEED_SCHOOL_SLUG        optional, made from the name by default
 *   SEED_SCHOOL_EMAIL / SEED_SCHOOL_PHONE / SEED_SCHOOL_ADDRESS / SEED_SCHOOL_CITY   optional
 *   SEED_CAMPUS_NAME        optional, "Main Campus" by default
 *   SEED_ADMIN_EMAIL, SEED_ADMIN_PASSWORD   required with SEED_SCHOOL_NAME
 *   SEED_ADMIN_FIRST_NAME, SEED_ADMIN_LAST_NAME   optional
 *   SEED_DEVELOPER_EMAIL, SEED_DEVELOPER_PASSWORD   optional: also create the platform developer's login
 *
 * Passwords are never printed, and every login created here must change its password at first sign-in.
 */
import 'dotenv/config';
import sequelize from '../config/database.js';
import { Tenant, Campus, User, SubscriptionPlan, SubscriptionAddOn } from '../models/index.js';
import { seedSubscriptionPlans } from './seedSubscriptionPlans.js';
import { MIN_PASSWORD_LENGTH, isDefaultPassword } from './passwords.js';

const env = (name) => String(process.env[name] || '').trim();
const EMAIL_RE = /^\S+@\S+\.\S+$/;
const MIN_SEED_PASSWORD = 10; // stricter than the app's minimum: this is the first, most powerful login

/** Why this password is not good enough for the first login of a production system, or null. */
export const seedPasswordProblem = (password) => {
  if (!password) return 'is missing';
  if (password.length < Math.max(MIN_SEED_PASSWORD, MIN_PASSWORD_LENGTH)) return `must be at least ${MIN_SEED_PASSWORD} characters`;
  if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) return 'must contain both letters and numbers';
  if (isDefaultPassword(password) || /^(admin|password|123456|qwerty|edutrack)/i.test(password)) return 'is a well-known default; choose your own';
  return null;
};

export const slugify = (text) => String(text).toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
  .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);

/** A problem the person running this can fix (a missing setting, a weak password). */
export class SeedError extends Error {}
const fail = (message) => { throw new SeedError(message); };

async function ensureSchema() {
  const [rows] = await sequelize.query("SELECT to_regclass('public.tenants') AS t, to_regclass('public.subscription_plans') AS p");
  if (!rows[0]?.t || !rows[0]?.p) {
    fail('The database has no tables yet. Run `npm run db:migrate` first, then run this again.');
  }
}

async function ensureUser({ tenantId, email, password, firstName, lastName, role, label }) {
  const existing = await User.findOne({ where: { email: email.toLowerCase() } });
  if (existing) {
    console.log(`  • ${label}: ${email} already exists, left as it is`);
    return false;
  }
  await User.create({
    tenant_id: tenantId, email: email.toLowerCase(), password, first_name: firstName, last_name: lastName,
    role, status: 'active', must_change_password: true,
  });
  console.log(`  ✓ ${label}: ${email} created (must change the password at first sign-in)`);
  return true;
}

export async function seedProduction() {
  await sequelize.authenticate();
  await ensureSchema();
  console.log('Seeding production essentials…\n');

  // 1 ── plans and add-ons
  await seedSubscriptionPlans();
  const [plans, addOns] = await Promise.all([SubscriptionPlan.count(), SubscriptionAddOn.count()]);
  console.log(`  ✓ subscription plans: ${plans}, add-ons: ${addOns}`);

  // 2 ── the first school
  const schoolName = env('SEED_SCHOOL_NAME');
  if (!schoolName) {
    console.log('\n  (No SEED_SCHOOL_NAME given, so no school was created. Run again with the SEED_* settings when you are ready.)');
    return;
  }
  const adminEmail = env('SEED_ADMIN_EMAIL');
  const adminPassword = process.env.SEED_ADMIN_PASSWORD || '';
  if (!EMAIL_RE.test(adminEmail)) fail('SEED_ADMIN_EMAIL is missing or not a valid email address.');
  const adminProblem = seedPasswordProblem(adminPassword);
  const existingTenant = await Tenant.findOne({ where: { slug: env('SEED_SCHOOL_SLUG') || slugify(schoolName) } });
  // an administrator's password is only needed when the admin has to be created
  if (adminProblem && !(await User.findOne({ where: { email: adminEmail.toLowerCase() } }))) {
    fail(`SEED_ADMIN_PASSWORD ${adminProblem}.`);
  }

  const slug = env('SEED_SCHOOL_SLUG') || slugify(schoolName);
  let tenant = existingTenant;
  if (tenant) {
    console.log(`  • school "${tenant.name}" already exists, left as it is`);
  } else {
    tenant = await Tenant.create({
      name: schoolName, slug, status: 'active',
      email: env('SEED_SCHOOL_EMAIL') || adminEmail,
      phone: env('SEED_SCHOOL_PHONE') || null,
      address: env('SEED_SCHOOL_ADDRESS') || null,
      settings: { timezone: 'Africa/Dar_es_Salaam', currency: 'TZS' },
    });
    console.log(`  ✓ school: ${tenant.name}`);
  }

  const campusName = env('SEED_CAMPUS_NAME') || 'Main Campus';
  if (!(await Campus.findOne({ where: { tenant_id: tenant.id } }))) {
    await Campus.create({
      tenant_id: tenant.id, name: campusName, code: 'MAIN',
      address: env('SEED_SCHOOL_ADDRESS') || null, city: env('SEED_SCHOOL_CITY') || null, country: 'Tanzania',
      phone: env('SEED_SCHOOL_PHONE') || null, email: env('SEED_SCHOOL_EMAIL') || adminEmail, status: 'active',
    });
    console.log(`  ✓ campus: ${campusName}`);
  } else {
    console.log('  • the school already has a campus, left as it is');
  }

  await ensureUser({
    tenantId: tenant.id, email: adminEmail, password: adminPassword, role: 'admin', label: 'administrator',
    firstName: env('SEED_ADMIN_FIRST_NAME') || 'School', lastName: env('SEED_ADMIN_LAST_NAME') || 'Administrator',
  });

  // 3 ── the platform developer (optional)
  const devEmail = env('SEED_DEVELOPER_EMAIL');
  if (devEmail) {
    if (!EMAIL_RE.test(devEmail)) fail('SEED_DEVELOPER_EMAIL is not a valid email address.');
    const devPassword = process.env.SEED_DEVELOPER_PASSWORD || '';
    const problem = seedPasswordProblem(devPassword);
    if (problem && !(await User.findOne({ where: { email: devEmail.toLowerCase() } }))) fail(`SEED_DEVELOPER_PASSWORD ${problem}.`);
    await ensureUser({ tenantId: tenant.id, email: devEmail, password: devPassword, role: 'super_admin', label: 'platform developer', firstName: 'Platform', lastName: 'Developer' });
    console.log(`\n  ⚠ Add ${devEmail} to DEVELOPER_EMAILS in the backend environment so this login is never locked by a subscription`);
    console.log('    and can configure the SMS and email gateways.');
  }

  console.log('\nDone. Start the server and sign in.');
}

// Run directly (not when imported by a test).
if (import.meta.url === `file://${process.argv[1]}`) {
  seedProduction()
    .then(() => sequelize.close())
    .catch(async (err) => {
      if (err instanceof SeedError) console.error(`\n✗ ${err.message}\n`); else console.error(err);
      await sequelize.close().catch(() => {});
      process.exit(1);
    });
}
