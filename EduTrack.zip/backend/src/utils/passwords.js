// FILE PATH: backend/src/utils/passwords.js
import crypto from 'crypto';
import { DEFAULT_STUDENT_PASSWORD, DEFAULT_STAFF_PASSWORD } from './studentCredentials.js';

export const MIN_PASSWORD_LENGTH = 8;

/** The shared first-login passwords EduTrack hands out to new students and staff. */
export const isDefaultPassword = (plain) =>
  typeof plain === 'string' && plain.length > 0 && (plain === DEFAULT_STUDENT_PASSWORD || plain === DEFAULT_STAFF_PASSWORD);

/**
 * A short fingerprint of a password hash. It is put in every session token, so
 * changing (or resetting) a password makes every token issued before it stop
 * working — a stolen or forgotten session can't outlive the password it was
 * created with. Nothing is stored for this; it is derived from the hash the
 * database already holds (the same expression is computed in SQL by
 * middleware/auth.js).
 */
export const passwordVersion = (passwordHash) =>
  crypto.createHash('sha256').update(String(passwordHash || ''), 'utf8').digest('hex').slice(0, 12);

/**
 * Rules for a NEW password. Returns an error message, or null when it is fine.
 *   - at least 8 characters, with both letters and numbers;
 *   - not the same as the current one (otherwise "changing" it on first login
 *     could simply type the default again);
 *   - not one of the shared default passwords.
 */
export const PASSWORD_RULE_TEXT = `Use at least ${MIN_PASSWORD_LENGTH} characters, with both letters and numbers.`;

export const newPasswordError = (newPassword, currentPassword = null) => {
  if (typeof newPassword !== 'string' || newPassword.length < MIN_PASSWORD_LENGTH
    || !/[A-Za-z]/.test(newPassword) || !/\d/.test(newPassword)) {
    return `Your new password is too weak. ${PASSWORD_RULE_TEXT}`;
  }
  if (currentPassword !== null && newPassword === currentPassword) {
    return 'Your new password must be different from your current one.';
  }
  if (isDefaultPassword(newPassword)) {
    return 'That is the standard starting password — please choose one only you know.';
  }
  return null;
};
