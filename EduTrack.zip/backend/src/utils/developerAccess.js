/**
 * Platform-developer gate. Some settings (currently: SMS Gateway
 * credentials) shouldn't be configurable by ANY tenant admin, no matter
 * how privileged — only the platform developer/operator. This is
 * separate from the normal role system entirely: it's not a role, it's
 * an allowlist of specific email addresses set via the DEVELOPER_EMAILS
 * environment variable (comma-separated), checked directly against the
 * logged-in user's email.
 *
 * Example .env entry:
 *   DEVELOPER_EMAILS=you@yourcompany.com,teammate@yourcompany.com
 */
const getDeveloperEmails = () =>
  (process.env.DEVELOPER_EMAILS || '')
    .split(',')
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);

export const isDeveloperEmail = (email) => {
  if (!email) return false;
  return getDeveloperEmails().includes(String(email).toLowerCase());
};

export const isDeveloper = (user) => isDeveloperEmail(user?.email);

/**
 * Who is never locked out by an expired subscription: the platform developer —
 * a super_admin whose email is in DEVELOPER_EMAILS. A super_admin account that
 * belongs to a school is locked like everyone else.
 */
export const bypassesSubscription = (user) => user?.role === 'super_admin' && isDeveloper(user);
