// backend/src/utils/sessionPolicy.js
/**
 * Session & Login Policy — per-tenant, stored in tenants.settings.session_policy
 * (a plain JSONB object, same pattern as academic_records_start_year in
 * utils/academicYear.js). Every field is optional on the stored object;
 * resolveSessionPolicy() always returns the full set with defaults filled
 * in, so callers never need to null-check.
 */

export const DEFAULT_SESSION_POLICY = {
  /** Minutes of inactivity before the frontend auto-logs the user out. */
  idle_timeout_minutes: 30,
  /** Consecutive wrong-password attempts allowed before the account locks. */
  max_login_attempts: 5,
  /** How long a locked account stays locked. */
  lockout_minutes: 15,
};

/** Clamp ranges enforced by settingsController when saving — kept here too
 * so any other caller building a policy object stays consistent. */
export const SESSION_POLICY_LIMITS = {
  idle_timeout_minutes: { min: 5, max: 240 },
  max_login_attempts: { min: 3, max: 10 },
  lockout_minutes: { min: 5, max: 1440 },
};

export const resolveSessionPolicy = (tenant) => ({
  ...DEFAULT_SESSION_POLICY,
  ...(tenant?.settings?.session_policy || {}),
});
