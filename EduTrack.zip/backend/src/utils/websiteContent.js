// backend/src/utils/websiteContent.js
//
// What the school's PUBLIC website shows that the school can change itself (Settings → Website Content).
// Stored on tenants.settings.website_content — no table of its own. Every field is optional: an empty field means
// "keep the website's built-in wording", so saving a half-filled form can never blank out a page.
const text = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

const list = (v, max, mapper) => (Array.isArray(v) ? v.slice(0, max).map(mapper).filter(Boolean) : []);

// Links the website puts in <a href>/<Link to>: only same-site paths or http(s) addresses — never javascript: etc.
const link = (v) => {
  const s = text(v, 300);
  return /^(\/|https?:\/\/)/i.test(s) ? s : '';
};

export const EMPTY_WEBSITE_CONTENT = {
  site: { name: '', tagline: '', phone: '', phone2: '', email: '', admissions_email: '', address: '', hours: '', facebook: '', instagram: '', youtube: '', whatsapp: '' },
  hero: { badge: '', headline: '', headline_highlight: '', subheadline: '', primary_label: '', primary_link: '', secondary_label: '', secondary_link: '' },
  stats: [],
  about: { title: '', body: '' },
  testimonials: [],
  news: [],
  notice: { enabled: false, text: '', link: '' },
};

export const sanitizeWebsiteContent = (input = {}) => {
  const i = input && typeof input === 'object' ? input : {};
  const site = i.site || {}; const hero = i.hero || {}; const about = i.about || {}; const notice = i.notice || {};
  return {
    site: {
      name: text(site.name, 120), tagline: text(site.tagline, 200),
      phone: text(site.phone, 40), phone2: text(site.phone2, 40),
      email: text(site.email, 120), admissions_email: text(site.admissions_email, 120),
      address: text(site.address, 300), hours: text(site.hours, 200),
      facebook: link(site.facebook), instagram: link(site.instagram), youtube: link(site.youtube), whatsapp: text(site.whatsapp, 40),
    },
    hero: {
      badge: text(hero.badge, 120), headline: text(hero.headline, 160), headline_highlight: text(hero.headline_highlight, 80),
      subheadline: text(hero.subheadline, 500),
      primary_label: text(hero.primary_label, 40), primary_link: link(hero.primary_link),
      secondary_label: text(hero.secondary_label, 40), secondary_link: link(hero.secondary_link),
    },
    stats: list(i.stats, 6, (s) => {
      const value = text(s?.value, 20); const label = text(s?.label, 60);
      return value && label ? { value, label } : null;
    }),
    about: { title: text(about.title, 160), body: text(about.body, 4000) },
    testimonials: list(i.testimonials, 12, (t) => {
      const quote = text(t?.quote, 600); const author = text(t?.author, 80);
      return quote && author ? { quote, author, role: text(t?.role, 100) } : null;
    }),
    news: list(i.news, 20, (n) => {
      const title = text(n?.title, 160);
      return title ? { title, date: text(n?.date, 40), excerpt: text(n?.excerpt, 400), type: text(n?.type, 20) || 'News' } : null;
    }),
    notice: { enabled: notice.enabled === true, text: text(notice.text, 300), link: link(notice.link) },
  };
};

export const resolveWebsiteContent = (tenant) => ({ ...EMPTY_WEBSITE_CONTENT, ...sanitizeWebsiteContent(tenant?.settings?.website_content) });
