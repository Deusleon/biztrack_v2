// FILE PATH: backend/src/utils/permissionEngine.js
/**
 * Works out what a person may do. See utils/permissionCatalog.js for the model.
 *
 *   effective permissions of a user =
 *       everything                      if super_admin / admin
 *       otherwise  role's set  +  the person's own extras
 *
 *   role's set = what an administrator last SAVED for that role in Settings →
 *   Permissions (stored with a marker, and then it is the whole set — so ticking
 *   a box off really takes it away), or, if nothing has been saved, the defaults
 *   plus anything older versions stored (which were additions only).
 */
import { RolePermission } from '../models/index.js';
import { DEFAULT_ROLE_PERMISSIONS } from './permissionCatalog.js';

export const ALWAYS_ALLOWED_ROLES = ['super_admin', 'admin'];
/** Stored inside a role's list to say "this list is the complete set". */
export const SAVED_MARKER = '*saved';

export const roleEffectivePermissions = (role, row) => {
  const stored = row?.permissions || [];
  if (stored.includes(SAVED_MARKER)) return new Set(stored.filter((k) => k !== SAVED_MARKER));
  return new Set([...(DEFAULT_ROLE_PERMISSIONS[role] || []), ...stored]);
};

/** { all: true } for the always-allowed roles, else { all: false, set }. Cached on the user object for the request. */
export const effectivePermissions = async (user, tenantId) => {
  if (ALWAYS_ALLOWED_ROLES.includes(user.role)) return { all: true, set: new Set() };
  if (user.__effectivePermissions) return user.__effectivePermissions;
  const row = await RolePermission.findOne({ where: { tenant_id: tenantId || user.tenant_id, role: user.role } });
  const set = new Set([...roleEffectivePermissions(user.role, row), ...(user.permissions || [])]);
  const result = { all: false, set };
  try { Object.defineProperty(user, '__effectivePermissions', { value: result, enumerable: false }); } catch { /* frozen — just don't cache */ }
  return result;
};

export const can = async (user, tenantId, key) => {
  const p = await effectivePermissions(user, tenantId);
  return p.all || p.set.has(key);
};

/** What the browser is told, to decide which buttons to show. '*' means everything. */
export const permissionList = async (user, tenantId) => {
  const p = await effectivePermissions(user, tenantId);
  return p.all ? ['*'] : [...p.set].sort();
};
