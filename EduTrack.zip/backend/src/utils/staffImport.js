// FILE PATH: backend/src/utils/staffImport.js
/**
 * Excel import (staff): ONE validator used by both the preview and the real import, so what the
 * preview promises is exactly what the import does. It applies the same rules as adding one staff
 * member by hand (controllers/staffController.js → create): who may hand out a role, a unique
 * employee number, email and phone — and adds checks that matter for a spreadsheet: real dates,
 * sensible numbers, and duplicates inside the file.
 */
import { Op } from 'sequelize';
import { Staff, User, Campus } from '../models/index.js';
import { normalizePhone } from './phone.js';
import { roleAssignmentError, STAFF_ROLES } from './staffRoles.js';
import { isRealDate } from './importChecks.js';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const slug = (v) => String(v || '').trim().toLowerCase().replace(/[\s-]+/g, '_');

const ROLE_ALIASES = { hr_manager: 'hr', human_resources: 'hr', hr_officer: 'hr', head_teacher: 'principal', headmaster: 'principal', headmistress: 'principal', warden: 'hostel_warden', transport: 'transport_manager' };
const CONTRACTS = { permanent: 'permanent', contract: 'contract', part_time: 'part_time', parttime: 'part_time', fixed_term: 'contract' };
const GENDERS = ['male', 'female', 'other'];
const MARITAL = ['single', 'married', 'divorced', 'widowed'];

export const STAFF_IMPORT_MAX_ROWS = 300;
export const staffRoleFrom = (raw) => { const r = slug(raw); return ROLE_ALIASES[r] || r; };

export const buildStaffRowValidator = ({ tenantId, actor, canManageStaff }) => {
  const campusCache = new Map();
  const findCampus = async (name) => {
    const key = String(name || '').trim().toLowerCase();
    if (!key) return null;
    if (campusCache.has(key)) return campusCache.get(key);
    const found = await Campus.findOne({ where: { tenant_id: tenantId, name: { [Op.iLike]: String(name).trim() } } });
    campusCache.set(key, found);
    return found;
  };

  return async (row = {}) => {
    const errors = [];
    const warnings = [];
    const t = (k) => String(row[k] ?? '').trim();
    const f = {
      first_name: t('first_name'), middle_name: t('middle_name'), last_name: t('last_name'),
      email: t('email').toLowerCase(), phone: t('phone'),
      role: staffRoleFrom(row.role), employee_number: t('employee_number'),
      department: t('department'), designation: t('designation'),
      joining_date: t('joining_date'), contract_end_date: t('contract_end_date'), date_of_birth: t('date_of_birth'),
      national_id: t('national_id'), tin_number: t('tin_number'), nssf_number: t('nssf_number'),
      bank_name: t('bank_name'), bank_account_number: t('bank_account_number'),
      address: t('address'), city: t('city'), country: t('country'),
      emergency_contact_name: t('emergency_contact_name'), emergency_contact_relation: t('emergency_contact_relation'), emergency_contact: t('emergency_contact'),
      notes: t('notes'),
    };
    f.phone_normalized = f.phone ? normalizePhone(f.phone) : '';

    if (!f.first_name) errors.push('First name is required');
    if (!f.last_name) errors.push('Last name is required');
    if (!f.email || !EMAIL_RE.test(f.email)) errors.push('A valid email is required — it is the staff member\'s login');
    if (f.phone && !/^\+?[\d\s-]{9,15}$/.test(f.phone)) errors.push('Phone does not look like a phone number');
    if (!f.employee_number) errors.push('Employee number is required');

    if (!row.role || !String(row.role).trim()) errors.push(`Role is required (one of: ${STAFF_ROLES.join(', ')})`);
    else {
      const roleError = roleAssignmentError({ actor, newRole: f.role, canManageStaff });
      if (roleError) errors.push(roleError.message);
    }

    let campus = null;
    if (!t('campus_name')) errors.push('Campus is required');
    else {
      campus = await findCampus(t('campus_name'));
      if (!campus) errors.push(`Campus "${t('campus_name')}" was not found`);
    }

    const ct = t('contract_type');
    f.contract_type = 'permanent';
    if (ct) {
      const mapped = CONTRACTS[slug(ct)];
      if (!mapped) errors.push('Contract type must be Permanent, Contract or Part-Time'); else f.contract_type = mapped;
    }
    const gender = t('gender').toLowerCase();
    f.gender = null;
    if (gender) { if (!GENDERS.includes(gender)) errors.push('Gender must be Male, Female or Other'); else f.gender = gender; }
    const marital = t('marital_status').toLowerCase();
    f.marital_status = null;
    if (marital) { if (!MARITAL.includes(marital)) errors.push('Marital status must be Single, Married, Divorced or Widowed'); else f.marital_status = marital; }

    ['joining_date', 'contract_end_date', 'date_of_birth'].forEach((k) => {
      if (f[k] && !isRealDate(f[k])) errors.push(`${{ joining_date: 'Joining date', contract_end_date: 'Contract end date', date_of_birth: 'Date of birth' }[k]} is not a real date (write it as YYYY-MM-DD)`);
    });
    if (isRealDate(f.joining_date) && isRealDate(f.contract_end_date) && f.contract_end_date < f.joining_date) errors.push('Contract end date is before the joining date');
    if (isRealDate(f.date_of_birth)) {
      const years = (Date.now() - new Date(`${f.date_of_birth.slice(0, 10)}T00:00:00Z`).getTime()) / 31557600000;
      if (years < 0) errors.push('Date of birth is in the future');
      else if (years < 16 || years > 80) warnings.push(`Age ${Math.floor(years)} looks unusual for a staff member — check the date of birth`);
    }
    if (f.contract_type === 'contract' && !f.contract_end_date) warnings.push('A fixed-term contract has no end date');

    f.salary = null;
    if (t('salary')) {
      const n = Number(t('salary').replace(/[,\s]/g, ''));
      if (!Number.isFinite(n) || n < 0) errors.push('Salary must be a number (no letters)'); else f.salary = n;
    } else warnings.push('No salary given — payroll will show 0 until it is added');
    f.experience_years = 0;
    if (t('experience_years')) {
      const n = Number(t('experience_years'));
      if (!Number.isInteger(n) || n < 0 || n > 60) errors.push('Years of experience must be a whole number'); else f.experience_years = n;
    }

    const dup = { email: false, employee_number: false, phone: false };
    if (f.employee_number && await Staff.findOne({ where: { employee_number: f.employee_number, tenant_id: tenantId } })) {
      dup.employee_number = true; errors.push(`Employee number "${f.employee_number}" already exists`);
    }
    if (f.email && EMAIL_RE.test(f.email) && await User.findOne({ where: { email: f.email } })) {
      dup.email = true; errors.push(`Email "${f.email}" is already registered`);
    }
    if (f.phone_normalized && await User.findOne({ where: { phone: f.phone_normalized } })) {
      dup.phone = true; errors.push(`Phone "${f.phone}" is already registered`);
    }

    return { errors, warnings, fields: f, campus, dup };
  };
};
