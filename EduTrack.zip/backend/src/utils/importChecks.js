// FILE PATH: backend/src/utils/importChecks.js
// Small checks shared by the Excel imports (students and staff).

/** A real calendar date written YYYY-MM-DD (so 2012-02-31 is refused, not silently shifted into March). */
export const isRealDate = (value) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(value || '').trim());
  if (!m) return false;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const t = new Date(Date.UTC(y, mo - 1, d));
  return t.getUTCFullYear() === y && t.getUTCMonth() === mo - 1 && t.getUTCDate() === d;
};

/** Whole years between a YYYY-MM-DD date of birth and today. */
export const ageOn = (dob, now = new Date()) => {
  const b = new Date(`${String(dob).slice(0, 10)}T00:00:00Z`);
  let a = now.getUTCFullYear() - b.getUTCFullYear();
  if (now.getUTCMonth() < b.getUTCMonth() || (now.getUTCMonth() === b.getUTCMonth() && now.getUTCDate() < b.getUTCDate())) a -= 1;
  return a;
};
