// FILE PATH: backend/src/utils/backupCli.js
/**
 * Command-line tool for the full-database backup. Use it from a hosting cron job, or to recover the system.
 *
 *   npm run db:backup                     make a backup now (and test that it restores, and copy it to Google Drive if linked)
 *   npm run db:backup:due                 make today's backup only if it is due (safe to run every hour from cron)
 *   npm run db:backup:verify -- latest    run the restore test on a backup file (or "latest", or a file name/path)
 *   npm run db:backup:list                list the backups on this server
 *   npm run db:restore -- <file> [--wipe] RESTORE a backup into this database (see below)
 *
 * RESTORE is for disaster recovery. By default it only restores into an EMPTY database. With --wipe it replaces
 * everything in the database — all in one transaction, so if anything goes wrong the database is left exactly as it was.
 * It asks you to type the database name to confirm (add --yes to skip the question in a script).
 */
import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import readline from 'readline';
import sequelize from '../config/database.js';
import { restoreBackupFile, verifyBackupFile, hashFile } from '../services/backup/dumpEngine.js';
import { runBackup, runDueBackup, backupDir } from '../services/backup/backupService.js';

const [cmd, ...rest] = process.argv.slice(2);
const flags = new Set(rest.filter((a) => a.startsWith('--')));
const args = rest.filter((a) => !a.startsWith('--'));
const mb = (n) => `${(n / 1048576).toFixed(1)} MB`;

const listFiles = () => fs.readdirSync(backupDir()).filter((f) => f.endsWith('.sql.gz')).sort().reverse()
  .map((f) => ({ name: f, file: path.join(backupDir(), f), size: fs.statSync(path.join(backupDir(), f)).size }));

const resolveFile = (arg) => {
  if (!arg) throw new Error('Say which backup: a file path, a file name from the backups folder, or "latest".');
  if (arg === 'latest') { const l = listFiles()[0]; if (!l) throw new Error('There are no backups on this server yet.'); return l.file; }
  if (fs.existsSync(arg)) return path.resolve(arg);
  const inDir = path.join(backupDir(), arg);
  if (fs.existsSync(inDir)) return inDir;
  throw new Error(`Cannot find "${arg}".`);
};

const ask = (q) => new Promise((r) => { const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); rl.question(q, (a) => { rl.close(); r(a); }); });

const main = async () => {
  switch (cmd) {
    case 'run': {
      console.log('Making a full backup and testing that it restores…');
      const row = await runBackup({ trigger: 'command_line', reason: 'command line' });
      console.log(`${row.status === 'success' ? '✅' : '❌'} ${row.status}: ${row.file_name || ''}`);
      if (row.status === 'success') console.log(`   ${row.table_count} tables, ${row.row_count} rows, ${mb(Number(row.size_bytes))}; restore test ${row.verify_status}; Google Drive: ${row.drive_status}`);
      else { console.log(`   ${row.error}`); process.exitCode = 1; }
      break;
    }
    case 'due': {
      const row = await runDueBackup();
      console.log(row ? `Backup ${row.status}${row.error ? `: ${row.error}` : ''}` : 'No backup was due.');
      if (row && row.status !== 'success') process.exitCode = 1;
      break;
    }
    case 'verify': {
      const file = resolveFile(args[0]);
      console.log(`Restore test of ${path.basename(file)}…`);
      const v = await verifyBackupFile(file);
      console.log(v.ok ? `✅ Passed — ${v.tables} tables, ${v.rows} rows restored and matched (${v.seconds}s).` : `❌ FAILED:\n   ${v.problems.join('\n   ')}`);
      if (!v.ok) process.exitCode = 1;
      break;
    }
    case 'list': {
      const files = listFiles();
      if (files.length === 0) console.log('No backups on this server yet.');
      files.forEach((f) => console.log(`${f.name}   ${mb(f.size)}`));
      break;
    }
    case 'restore': {
      const file = resolveFile(args[0]);
      const wipe = flags.has('--wipe');
      const db = sequelize.config.database;
      console.log(`Backup:   ${path.basename(file)}  (sha256 ${(await hashFile(file)).slice(0, 12)}…)\nDatabase: ${db} on ${sequelize.config.host}\nMode:     ${wipe ? 'REPLACE EVERYTHING in this database' : 'restore into an empty database'}`);
      if (!flags.has('--yes')) {
        const typed = await ask(`Type the database name (${db}) to continue: `);
        if (typed.trim() !== db) { console.log('Cancelled — nothing was changed.'); return; }
      }
      const r = await restoreBackupFile(file, { wipe });
      console.log(`✅ Restored ${r.tables} tables and ${r.rows} rows, and checked every table against the backup.\nNow restart the app.`);
      break;
    }
    default:
      console.log('Usage: backupCli.js run | due | verify <file|latest> | list | restore <file> [--wipe] [--yes]');
      process.exitCode = cmd ? 1 : 0;
  }
};

main().catch((e) => { console.error(`❌ ${e.message}`); process.exitCode = 1; }).finally(() => sequelize.close());
