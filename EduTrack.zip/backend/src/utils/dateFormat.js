/**
 * Dates in text the server writes (emails, PDFs), in the school's chosen format
 * (tenants.settings.display.date_format). Same tokens as the frontend's utils/dateFormat.js.
 * Read in the school's own time zone so "27 Oct" is the day people in Tanzania saw, not
 * the UTC day, which late in the evening is already tomorrow.
 */
const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONTHS_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
export const SCHOOL_TIME_ZONE = process.env.SCHOOL_TIME_ZONE || 'Africa/Dar_es_Salaam';

export const formatDate = (input, format = 'DD/MM/YYYY', timeZone = SCHOOL_TIME_ZONE) => {
  if (!input) return '';
  const d = input instanceof Date ? input : new Date(input);
  if (Number.isNaN(d.getTime())) return '';
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat('en-GB', { timeZone, year: 'numeric', month: 'numeric', day: 'numeric' })
      .formatToParts(d).filter((p) => p.type !== 'literal').map((p) => [p.type, Number(p.value)]),
  );
  const yyyy = parts.year;
  const mm = String(parts.month).padStart(2, '0');
  const dd = String(parts.day).padStart(2, '0');
  const mon = MONTHS_SHORT[parts.month - 1];
  const month = MONTHS_FULL[parts.month - 1];
  const day = parts.day;
  switch (format) {
    case 'MM/DD/YYYY': return `${mm}/${dd}/${yyyy}`;
    case 'YYYY-MM-DD': return `${yyyy}-${mm}-${dd}`;
    case 'DD-MM-YYYY': return `${dd}-${mm}-${yyyy}`;
    case 'D MMM YYYY': return `${day} ${mon} ${yyyy}`;
    case 'MMMM D, YYYY': return `${month} ${day}, ${yyyy}`;
    case 'DD/MM/YYYY':
    default: return `${dd}/${mm}/${yyyy}`;
  }
};
