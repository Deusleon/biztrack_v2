// FILE PATH: backend/src/utils/invoiceNumber.js
/**
 * Subscription invoice numbers: INV-<year>-<running number>.
 *
 * The running number comes from a database SEQUENCE, so it only ever goes up. It used to be
 * "how many invoices exist, plus one", which repeats a number the moment any invoice is deleted
 * (and when two are created at once). A number is never reused: cancelling or cleaning up
 * invoices leaves gaps, which is normal for invoices.
 *
 * The migration creates the sequence; `ensureInvoiceSequence` makes the same thing true for a
 * database built another way (the demo seed builds tables straight from the models).
 */
import sequelize from '../config/database.js';

export const SEQUENCE = 'subscription_invoice_number_seq';

/** Creates the sequence if missing and moves it past every number already issued. Idempotent. */
export const INVOICE_SEQUENCE_SQL = `
CREATE SEQUENCE IF NOT EXISTS ${SEQUENCE};
DO $$
DECLARE m bigint;
BEGIN
  SELECT COALESCE(MAX(CAST(substring(invoice_number from '^INV-[0-9]{4}-([0-9]+)$') AS bigint)), 0)
    INTO m FROM subscription_invoices;
  IF m > 0 AND m >= (SELECT CASE WHEN is_called THEN last_value + 1 ELSE last_value END FROM ${SEQUENCE}) THEN
    PERFORM setval('${SEQUENCE}', m, true);
  END IF;
END $$;`;

let ready = false;
export const ensureInvoiceSequence = async () => {
  if (ready) return;
  await sequelize.query(INVOICE_SEQUENCE_SQL);
  ready = true;
};

export const nextInvoiceNumber = async () => {
  await ensureInvoiceSequence();
  const [[row]] = await sequelize.query(`SELECT nextval('${SEQUENCE}') AS n`);
  return `INV-${new Date().getFullYear()}-${String(row.n).padStart(5, '0')}`;
};
