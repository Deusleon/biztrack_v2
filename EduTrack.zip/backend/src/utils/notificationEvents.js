/**
 * The full list of events the system can notify people about automatically.
 *
 * Every event has one or more PARTIES — the groups of people it can reach (for a payment: the parent, and the finance
 * office). For each party a school chooses, in Settings → Notifications, whether they are notified at all and through
 * which channels (in-app, SMS, email) — so "Payment Recorded" can go to the parent only, to the accountants only, or both,
 * each on its own channel.
 *
 *   party.roles     staff roles that make up the party (everyone active in the school with that role); a party without
 *                   `roles` is a person named at the moment of the event (the student's parent, the borrower…)
 *   party.default   whether the party is notified until the school says otherwise
 *   party.default_channels
 *
 * Actual settings live in the NotificationSetting table.
 */
export const CHANNELS = ['in_app', 'sms', 'email'];

export const NOTIFICATION_EVENTS = [
  {
    key: 'payment_recorded',
    label: 'Payment Recorded',
    description: 'When a fee payment is recorded: tells the family it was received, and the finance office.',
    default_enabled: true,
    parties: [
      { key: 'family', label: 'Parent / student', description: 'The student\'s parent (or the student if no parent is linked).', default: true, default_channels: ['in_app'] },
      { key: 'staff', label: 'Accountants & admins', description: 'Everyone with the accountant or admin role.', roles: ['accountant', 'admin'], default: true, default_channels: ['in_app'] },
    ],
  },
  {
    key: 'exam_results_published',
    label: 'Exam Results Published',
    description: 'When marks for a subject are entered or updated: tells the student\'s parent.',
    default_enabled: true,
    parties: [
      { key: 'family', label: 'Parent / student', description: 'The student\'s parent (or the student if no parent is linked).', default: true, default_channels: ['in_app'] },
    ],
  },
  {
    key: 'timetable_published',
    label: 'Timetable Published',
    description: 'When a timetable is filled in or updated.',
    default_enabled: true,
    parties: [
      { key: 'teachers', label: 'Teachers', roles: ['teacher'], default: true, default_channels: ['in_app'] },
      { key: 'students', label: 'Students', roles: ['student'], default: true, default_channels: ['in_app'] },
    ],
  },
  {
    key: 'fee_balance_reminder',
    label: 'Outstanding Fee Reminder',
    description: 'When staff send a fee reminder from Fee Status. The reminder SMS itself is sent by that button; this adds an in-app (or email) copy for the parent.',
    default_enabled: true,
    parties: [
      { key: 'family', label: 'Parent', description: 'The parent of each student reminded.', default: true, default_channels: ['in_app'] },
    ],
  },
  {
    key: 'student_admitted',
    label: 'New Student Admitted',
    description: 'When a student is admitted: confirms the admission number and class to the parent, and tells the school leadership.',
    default_enabled: true,
    parties: [
      { key: 'family', label: 'Parent / guardian', description: 'Gets the admission number and class (needs a phone or email on the admission form).', default: true, default_channels: ['sms'] },
      { key: 'admins', label: 'Admins & principal', roles: ['admin', 'principal'], default: true, default_channels: ['in_app'] },
    ],
  },
  {
    key: 'staff_added',
    label: 'New Staff Member Added',
    description: 'When a staff member is added to the system.',
    default_enabled: true,
    parties: [
      { key: 'admins', label: 'Admins', roles: ['admin'], default: true, default_channels: ['in_app'] },
      { key: 'hr', label: 'HR managers', roles: ['hr'], default: true, default_channels: ['in_app'] },
    ],
  },
  {
    key: 'leave_request_submitted',
    label: 'Leave Request Submitted',
    description: 'When someone submits a leave request that is waiting for approval.',
    default_enabled: true,
    parties: [
      { key: 'approvers', label: 'HR, principal & admins', description: 'The people who can approve it.', roles: ['hr', 'principal', 'admin'], default: true, default_channels: ['in_app'] },
      { key: 'requester', label: 'The person who asked', description: 'A confirmation that their request was received.', default: false, default_channels: ['in_app'] },
    ],
  },
  {
    key: 'leave_request_decided',
    label: 'Leave Request Approved or Rejected',
    description: 'When a leave request is finally approved or rejected.',
    default_enabled: true,
    parties: [
      { key: 'requester', label: 'The person who asked', default: true, default_channels: ['in_app'] },
      { key: 'admins', label: 'HR & admins (a copy)', roles: ['hr', 'admin'], default: false, default_channels: ['in_app'] },
    ],
  },
  {
    key: 'expense_recorded',
    label: 'Expense Recorded',
    description: 'When an operational expense is recorded.',
    default_enabled: true,
    parties: [
      { key: 'accountants', label: 'Accountants', roles: ['accountant'], default: true, default_channels: ['in_app'] },
      { key: 'admins', label: 'Admins', roles: ['admin'], default: true, default_channels: ['in_app'] },
    ],
  },
  {
    key: 'book_overdue',
    label: 'Library Book Overdue',
    description: 'When a borrowed book passes its due date (checked automatically each day).',
    default_enabled: true,
    parties: [
      { key: 'librarian', label: 'Librarians', roles: ['librarian'], default: true, default_channels: ['in_app'] },
      { key: 'borrower', label: 'The borrower', description: 'The staff member, or a student\'s parent.', default: false, default_channels: ['in_app'] },
    ],
  },

  // Not sent by notifyEvent(): "Forgot password" works before anyone is signed in, so services/passwordResetService.js
  // reads this setting itself. It is in the list so the school chooses WHERE reset codes go next to every other
  // notification — email only (the default), SMS only, or either/both. It can't be switched off: a school that did
  // would leave people unable to recover their own account.
  {
    key: 'password_reset',
    label: 'Password Reset Code',
    description: 'Where the 6-digit code goes when someone forgets their password.',
    default_enabled: true,
    default_channels: ['email'],
    parties: [],
  },
];

export const getEvent = (eventKey) => NOTIFICATION_EVENTS.find((e) => e.key === eventKey) || null;

/** All channels any party of the event uses by default (kept for callers that only want "the event's channels"). */
export const getEventDefaults = (eventKey) => {
  const evt = getEvent(eventKey);
  if (!evt) return { default_enabled: true, default_channels: ['in_app'] };
  const channels = evt.default_channels || [...new Set(evt.parties.filter((p) => p.default).flatMap((p) => p.default_channels))];
  return { default_enabled: evt.default_enabled, default_channels: channels.length ? channels : ['in_app'] };
};

/** { partyKey: [channels] } for a school that has not chosen anything: every party that is on by default. */
export const defaultAudience = (evt) => Object.fromEntries((evt?.parties || []).filter((p) => p.default).map((p) => [p.key, [...p.default_channels]]));

/**
 * What a stored audience means for an event: only parties the event really has, only real channels, in the event's order.
 * Returns the default audience when nothing is stored.
 */
export const resolveAudience = (evt, stored) => {
  if (!evt || !stored || typeof stored !== 'object' || Array.isArray(stored)) return defaultAudience(evt);
  const out = {};
  evt.parties.forEach((p) => {
    if (Array.isArray(stored[p.key])) out[p.key] = stored[p.key].filter((c) => CHANNELS.includes(c));
  });
  return out;
};
