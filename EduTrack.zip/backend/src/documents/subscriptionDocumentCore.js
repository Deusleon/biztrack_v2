// FILE: subscriptionDocumentCore.js
//
// Invoice and receipt for a subscription payment — the model AND the PDF drawing.
//
// THIS FILE EXISTS TWICE, byte for byte:
//   frontend/src/utils/subscriptionDocumentCore.js     (downloads in the browser)
//   backend/src/documents/subscriptionDocumentCore.js  (the PDFs attached to emails)
// A backend test fails if the two differ, so an invoice means the same thing wherever it
// is produced. Edit one, copy it over the other.
//
// It touches nothing environment-specific: no DOM, no Node APIs, no assets. The caller
// supplies the jsPDF instance, the autoTable function, and any images.

const ONES = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"];
const TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];

const below1000 = (n) => {
  const parts = [];
  if (n >= 100) { parts.push(`${ONES[Math.floor(n / 100)]} hundred`); n %= 100; if (n) parts.push("and"); }
  if (n >= 20) { parts.push(TENS[Math.floor(n / 10)] + (n % 10 ? `-${ONES[n % 10]}` : "")); }
  else if (n > 0) parts.push(ONES[n]);
  return parts.join(" ");
};

/** 2400000 → "Two million four hundred thousand Tanzanian shillings only" (whole shillings). */
function amountInWords(amount, currency = "Tanzanian shillings") {
  let n = Math.round(Math.abs(Number(amount) || 0));
  if (n === 0) return `Zero ${currency} only`;
  const scales = [[1e9, "billion"], [1e6, "million"], [1e3, "thousand"]];
  const parts = [];
  for (const [size, name] of scales) {
    if (n >= size) { parts.push(`${below1000(Math.floor(n / size))} ${name}`); n %= size; }
  }
  if (n > 0) parts.push(below1000(n));
  const words = parts.join(" ").replace(/\s+/g, " ").trim();
  return `${words.charAt(0).toUpperCase()}${words.slice(1)} ${currency} only`;
}

export const NAVY = [10, 60, 140];
export const GREEN = [62, 155, 44];
const AMBER = [201, 111, 8];
const RED = [185, 28, 28];
const GREY = [107, 114, 128];

const STATUS = {
  pending:    { label: "UNPAID",     rgb: AMBER, hex: "#C96F08" },
  processing: { label: "PROCESSING", rgb: AMBER, hex: "#C96F08" },
  paid:       { label: "PAID",       rgb: GREEN, hex: "#3E9B2C" },
  failed:     { label: "FAILED",     rgb: RED,   hex: "#B91C1C" },
  cancelled:  { label: "CANCELLED",  rgb: GREY,  hex: "#6B7280" },
};
export const statusStyle = (s) => STATUS[s] || STATUS.pending;

const CYCLE = { monthly: "Monthly", termly: "Per term", yearly: "Yearly" };

const maskPhone = (p) => {
  const d = String(p || "").replace(/\s+/g, "");
  return d.length >= 8 ? `${d.slice(0, 5)}***${d.slice(-3)}` : d || "—";
};

const methodLabel = (gateway) => {
  if (gateway === "clickpesa") return "Mobile money (via ClickPesa)";
  if (gateway === "seed") return "Test payment";
  return gateway ? String(gateway) : "—";
};

/**
 * kind: "invoice" | "receipt"
 * data: the response of GET /subscription/invoices/:reference
 */
/**
 * env: {
 *   formatDate(d) -> string,        formatNumber(n) -> string  (the school's Money Decimals),
 *   seller: { name, lines: [..] },  origin: "https://app.example.com" (for the QR links)
 * }
 */
export function buildDoc(kind, data, env) {
  const { formatDate, formatNumber, seller, origin = '' } = env;
  const money = (n) => formatNumber(n);
  const signed = (n) => (Number(n) < 0 ? `-${money(Math.abs(n))}` : money(n));
  const inv = data.invoice;
  const fmt = (d) => (d ? formatDate(d) : "—");
  const lines = (inv.line_items || []).map((li) => ({ label: li.label, amount: Number(li.amount) }));
  const periodText = inv.period_start && inv.period_end ? `${fmt(inv.period_start)} to ${fmt(inv.period_end)}` : "—";
  const isReceipt = kind === "receipt";
  const code = data.verification_code || null;
  // Unpaid: scan to open this invoice in EduTrack and pay it. Paid (invoice or receipt): scan to
  // verify the payment against EduTrack's own records, without needing to sign in.
  let qr = null;
  if (inv.status === "paid" && code) {
    qr = { kind: "verify", url: `${origin}/verify-subscription-receipt/${inv.invoice_number}/${code}`, caption: "Scan to verify", hint: "Confirms this payment with EduTrack" };
  } else if (!isReceipt && data.pay_code && (inv.status === "pending" || inv.status === "failed")) {
    // Anyone can pay from their own phone: the code in the link is the proof, no EduTrack login.
    qr = { kind: "pay", url: `${origin}/pay/${inv.invoice_number}/${data.pay_code}`, caption: "Scan to pay", hint: "Pay with mobile money from your phone" };
  }
  return {
    qr, verificationCode: code, verifyPage: `${origin}/verify-subscription-receipt`,
    kind,
    isReceipt,
    title: isReceipt ? "PAYMENT RECEIPT" : "INVOICE",
    number: isReceipt ? data.receipt_number : inv.invoice_number,
    invoiceNumber: inv.invoice_number,
    receiptNumber: data.receipt_number,
    status: inv.status,
    issued: isReceipt ? fmt(inv.paid_at) : fmt(inv.createdAt),
    school: data.school,
    planName: inv.plan?.name || "Subscription",
    cycle: CYCLE[inv.billing_cycle] || inv.billing_cycle,
    periodText,
    lines,
    subtotal: Number(inv.subtotal),
    credit: Number(inv.proration_credit || 0),
    total: Number(inv.total),
    currency: inv.currency || "TZS",
    paid: inv.status === "paid",
    paidAt: fmt(inv.paid_at),
    method: methodLabel(inv.gateway),
    payerPhone: maskPhone(inv.payer_phone),
    transactionRef: inv.gateway_payment_id || "—",
    orderRef: inv.order_reference,
    failureReason: inv.failure_reason,
    words: amountInWords(inv.total),
    seller,
    money, signed,
  };
}

/**
 * Draws the document onto `pdf` (an A4 portrait jsPDF).
 *   assets = { emblem: dataUrl|null, qr: dataUrl|null, contact: "support@… | 255…" }
 */
export function drawSubscriptionDocument(pdf, autoTable, doc, assets = {}) {
  const { money, signed } = doc; // the model carries the school's number formatting
  const W = pdf.internal.pageSize.getWidth();
  const H = pdf.internal.pageSize.getHeight();
  const M = 16;
  const R = W - M;
  const accent = doc.isReceipt ? GREEN : NAVY;
  const st = statusStyle(doc.status);
  const emblem = assets.emblem || null;

  const qr = doc.qr ? assets.qr || null : null;
  // A QR with a thin frame, its caption underneath. Returns nothing; draws at (x, y), size s.
  const drawQr = (x, y, s) => {
    if (!qr) return;
    pdf.setDrawColor(209, 213, 219); pdf.setLineWidth(0.25); pdf.setFillColor(255, 255, 255);
    pdf.rect(x - 1.5, y - 1.5, s + 3, s + 3, "FD");
    pdf.addImage(qr, "PNG", x, y, s, s);
    pdf.setFont("helvetica", "bold"); pdf.setFontSize(7.5); pdf.setTextColor(...accent);
    pdf.text(doc.qr.caption, x + s / 2, y + s + 5.2, { align: "center" });
  };

  // ── Header: logo + name (left), title + status (right) ──────────────────
  if (emblem) pdf.addImage(emblem, "PNG", M, 14, 24, 14.7);
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(18);
  pdf.setTextColor(...NAVY);
  pdf.text("EduTrack", M + 27, 22.5);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(8);
  pdf.setTextColor(...GREY);
  pdf.text("School Management System", M + 27, 27);

  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(24);
  pdf.setTextColor(...accent);
  pdf.text(doc.title, R, 23, { align: "right" });

  const label = st.label;
  pdf.setFontSize(8.5);
  const pillW = pdf.getTextWidth(label) + 9;
  pdf.setFillColor(...st.rgb);
  pdf.roundedRect(R - pillW, 27, pillW, 6.5, 3.25, 3.25, "F");
  pdf.setTextColor(255, 255, 255);
  pdf.text(label, R - pillW / 2, 31.4, { align: "center" });

  pdf.setDrawColor(...accent);
  pdf.setLineWidth(0.7);
  pdf.line(M, 38, R, 38);

  // ── Seller (left) and document facts (right) ────────────────────────────
  let y = 46;
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(9.5);
  pdf.setTextColor(30);
  pdf.text(doc.seller.name, M, y);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(8.5);
  pdf.setTextColor(...GREY);
  doc.seller.lines.forEach((l, i) => pdf.text(String(l), M, y + 5 + i * 4.3));

  const facts = doc.isReceipt
    ? [["Receipt No.", doc.number], ["Date paid", doc.paidAt], ["Invoice No.", doc.invoiceNumber], ["Reference", doc.orderRef]]
    : [["Invoice No.", doc.number], ["Issue date", doc.issued], ["Service period", doc.periodText], ["Reference", doc.orderRef]];
  const labelX = 112;
  facts.forEach(([k, v], i) => {
    const yy = y + i * 6;
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(8.5);
    pdf.setTextColor(...GREY);
    pdf.text(k, labelX, yy);
    pdf.setFont("helvetica", "bold");
    pdf.setTextColor(30);
    const val = pdf.splitTextToSize(String(v), R - (labelX + 28));
    pdf.text(val[0], labelX + 28, yy);
  });

  // ── Bill to / received from ─────────────────────────────────────────────
  y = 80;
  pdf.setFillColor(244, 247, 252);
  pdf.rect(M, y - 5, R - M, 25, "F");
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(7.5);
  pdf.setTextColor(...accent);
  pdf.text(doc.isReceipt ? "RECEIVED FROM" : "BILL TO", M + 4, y);
  pdf.setFontSize(11);
  pdf.setTextColor(20);
  pdf.text(doc.school.name, M + 4, y + 6);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(8.5);
  pdf.setTextColor(...GREY);
  [doc.school.address, [doc.school.phone, doc.school.email].filter(Boolean).join("   |   ")].filter(Boolean)
    .forEach((l, i) => pdf.text(l, M + 4, y + 11 + i * 4.3));

  y += 30;

  if (!doc.isReceipt) {
    // ── Line items ────────────────────────────────────────────────────────
    autoTable(pdf, {
      startY: y,
      margin: { left: M, right: M },
      theme: "grid",
      head: [["#", "Description", "Service period", `Amount (${doc.currency})`]],
      body: doc.lines.map((l, i) => [i + 1, `${l.label}`, i === 0 ? `${doc.periodText}\n${doc.cycle}` : "", signed(l.amount)]),
      styles: { fontSize: 9, cellPadding: { top: 3, bottom: 3, left: 3, right: 3 }, lineColor: [209, 213, 219], lineWidth: 0.2, valign: "middle", textColor: 30 },
      headStyles: { fillColor: NAVY, textColor: 255, fontStyle: "bold", fontSize: 8.5, lineColor: NAVY },
      alternateRowStyles: { fillColor: [249, 250, 251] },
      columnStyles: { 0: { cellWidth: 9, halign: "center" }, 1: { cellWidth: "auto" }, 2: { cellWidth: 52, fontSize: 8, textColor: GREY }, 3: { cellWidth: 34, halign: "right", fontStyle: "bold" } },
      didParseCell: (d) => {
        if (d.section === "head" && d.column.index === 3) d.cell.styles.halign = "right";
        if (d.section === "head" && d.column.index === 0) d.cell.styles.halign = "center";
        if (d.section === "body" && d.column.index === 3 && doc.lines[d.row.index]?.amount < 0) d.cell.styles.textColor = GREEN;
      },
    });
    y = pdf.lastAutoTable.finalY + 6;

    // ── Totals ────────────────────────────────────────────────────────────
    const tx = 118;
    const row = (k, v, yy, color = 30) => {
      pdf.setFont("helvetica", "normal"); pdf.setFontSize(9); pdf.setTextColor(...GREY); pdf.text(k, tx, yy);
      pdf.setFont("helvetica", "bold"); pdf.setTextColor(...(Array.isArray(color) ? color : [color, color, color])); pdf.text(v, R, yy, { align: "right" });
    };
    row("Subtotal", `${doc.currency} ${money(doc.subtotal)}`, y);
    let yy = y;
    if (doc.credit) { yy += 6; row("Credit for unused time", `-${doc.currency} ${money(doc.credit)}`, yy, GREEN); }
    yy += 5;
    pdf.setFillColor(...(doc.paid ? GREEN : NAVY));
    pdf.rect(tx - 4, yy, R - tx + 4, 10, "F");
    pdf.setTextColor(255, 255, 255);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(9);
    pdf.text(doc.paid ? "TOTAL PAID" : "TOTAL DUE", tx, yy + 6.4);
    pdf.setFontSize(11);
    pdf.text(`${doc.currency} ${money(doc.total)}`, R - 2, yy + 6.6, { align: "right" });
    y = yy + 17;

    pdf.setFont("helvetica", "italic");
    pdf.setFontSize(8);
    pdf.setTextColor(...GREY);
    const words = pdf.splitTextToSize(`Amount in words: ${doc.words}`, R - M);
    pdf.text(words, M, y);
    y += words.length * 4 + 5;

    // ── How to pay / payment received ────────────────────────────────────
    const boxTop = y;
    if (doc.paid) {
      const bh = qr ? 36 : 20;
      pdf.setFillColor(234, 245, 230);
      pdf.rect(M, boxTop, R - M, bh, "F");
      pdf.setFillColor(...GREEN);
      pdf.rect(M, boxTop, 1.4, bh, "F");
      pdf.setFont("helvetica", "bold"); pdf.setFontSize(9); pdf.setTextColor(...GREEN);
      pdf.text("PAYMENT RECEIVED", M + 5, boxTop + 6);
      pdf.setFont("helvetica", "normal"); pdf.setFontSize(8.5); pdf.setTextColor(40);
      pdf.text(`Paid in full on ${doc.paidAt} by ${doc.method}.`, M + 5, boxTop + 11.5);
      pdf.text(`Transaction reference: ${doc.transactionRef}.   Receipt: ${doc.receiptNumber || "—"}.`, M + 5, boxTop + 16);
      if (qr) {
        pdf.setFontSize(8); pdf.setTextColor(...GREY);
        pdf.text(`Verification code: ${doc.verificationCode}`, M + 5, boxTop + 23);
        drawQr(R - 30, boxTop + 3.5, 24);
      }
      y = boxTop + bh + 6;
    } else {
      const bh = qr ? 38 : 27;
      pdf.setFillColor(253, 241, 225);
      pdf.rect(M, boxTop, R - M, bh, "F");
      pdf.setFillColor(...AMBER);
      pdf.rect(M, boxTop, 1.4, bh, "F");
      pdf.setFont("helvetica", "bold"); pdf.setFontSize(9); pdf.setTextColor(...AMBER);
      pdf.text(doc.status === "failed" ? "PAYMENT NOT COMPLETED" : "HOW TO PAY", M + 5, boxTop + 6);
      pdf.setFont("helvetica", "normal"); pdf.setFontSize(8.5); pdf.setTextColor(40);
      const how = doc.status === "failed" && doc.failureReason
        ? `The last attempt failed: ${doc.failureReason}. Open this invoice in EduTrack and choose Pay to try again.`
        : "Scan the QR code with your phone to pay with mobile money (Airtel Money, Mixx by Yas, HaloPesa), or open Subscription in EduTrack and choose Pay. Your subscription starts as soon as the payment is confirmed.";
      pdf.text(pdf.splitTextToSize(how, R - M - 10 - (qr ? 34 : 0)), M + 5, boxTop + 11.5);
      pdf.setFontSize(8); pdf.setTextColor(...GREY);
      pdf.text(`Quote ${doc.invoiceNumber} when you contact support.`, M + 5, boxTop + bh - 4);
      if (qr) {
        drawQr(R - 30, boxTop + 3.5, 24);
        pdf.setFont("helvetica", "normal"); pdf.setFontSize(6.5); pdf.setTextColor(...GREY);
        pdf.text(doc.qr.hint, R - 18, boxTop + bh - 1.6, { align: "center", maxWidth: 34 });
      }
      y = boxTop + bh + 6;
    }
  } else {
    // ── Receipt: amount box ───────────────────────────────────────────────
    pdf.setFillColor(234, 245, 230);
    pdf.rect(M, y, R - M, 30, "F");
    pdf.setFillColor(...GREEN);
    pdf.rect(M, y, 1.4, 30, "F");
    pdf.setFont("helvetica", "bold"); pdf.setFontSize(8); pdf.setTextColor(...GREEN);
    pdf.text("AMOUNT RECEIVED", M + 6, y + 7);
    pdf.setFontSize(24); pdf.setTextColor(20);
    pdf.text(`${doc.currency} ${money(doc.total)}`, M + 6, y + 18);
    pdf.setFont("helvetica", "italic"); pdf.setFontSize(8.5); pdf.setTextColor(...GREY);
    pdf.text(pdf.splitTextToSize(doc.words, R - M - 12), M + 6, y + 25);
    y += 38;

    autoTable(pdf, {
      startY: y,
      margin: { left: M, right: M },
      theme: "plain",
      body: [
        ["Payment for", `${doc.planName} plan, ${String(doc.cycle).toLowerCase()}`],
        ["Service period", doc.periodText],
        ["Invoice", doc.invoiceNumber],
        ["Payment method", doc.method],
        ["Paid from", doc.payerPhone],
        ["Transaction reference", doc.transactionRef],
        ["Order reference", doc.orderRef],
        ["Date paid", doc.paidAt],
      ],
      styles: { fontSize: 9.5, cellPadding: { top: 2.0, bottom: 2.0, left: 3, right: 3 }, textColor: 30 },
      columnStyles: { 0: { cellWidth: 48, textColor: GREY }, 1: { fontStyle: "bold" } },
      didParseCell: (d) => { d.cell.styles.lineColor = [229, 231, 235]; d.cell.styles.lineWidth = { bottom: 0.2 }; },
    });
    y = pdf.lastAutoTable.finalY + 6;

    // Verification: the QR, and the same information in words for a printed copy.
    const vh = qr ? 38 : 0;
    if (qr) {
      pdf.setFillColor(244, 247, 252);
      pdf.rect(M, y, R - M, vh, "F");
      pdf.setFillColor(...GREEN);
      pdf.rect(M, y, 1.4, vh, "F");
      pdf.setFont("helvetica", "bold"); pdf.setFontSize(9); pdf.setTextColor(...GREEN);
      pdf.text("VERIFY THIS RECEIPT", M + 5, y + 7);
      pdf.setFont("helvetica", "normal"); pdf.setFontSize(8.5); pdf.setTextColor(40);
      pdf.text(pdf.splitTextToSize(`Scan the QR code to confirm with EduTrack that this payment was really received. Or open ${doc.verifyPage} and enter the receipt number and verification code below.`, R - M - 46), M + 5, y + 13);
      pdf.setFont("helvetica", "bold"); pdf.setFontSize(9); pdf.setTextColor(20);
      pdf.text(`Receipt No.: ${doc.receiptNumber}`, M + 5, y + 30);
      pdf.text(`Verification code: ${doc.verificationCode}`, M + 5, y + 35.5);
      drawQr(R - 33, y + 4, 26);
    }
    y += vh + 6;
  }

  // ── Terms / closing ─────────────────────────────────────────────────────
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(8);
  pdf.setTextColor(...GREY);
  const closing = doc.isReceipt
    ? "Thank you for your payment. This receipt confirms that the amount above was received and applied to your EduTrack subscription."
    : doc.paid
      ? "Thank you. This invoice has been paid in full; a payment receipt is available in EduTrack under Subscription."
      : "This invoice is payable on receipt. Your subscription is not extended until the payment is confirmed. Amounts are in Tanzanian shillings and include all taxes unless stated.";
  pdf.text(pdf.splitTextToSize(closing, R - M), M, y);

  // ── Footer ──────────────────────────────────────────────────────────────
  pdf.setDrawColor(209, 213, 219);
  pdf.setLineWidth(0.2);
  pdf.line(M, H - 18, R, H - 18);
  pdf.setFontSize(7.5);
  pdf.setTextColor(...GREY);
  pdf.text("Generated electronically by EduTrack. No signature is required.", M, H - 13);
  pdf.text(assets.contact || "", R, H - 13, { align: "right" });
  pdf.text(`${doc.title.charAt(0)}${doc.title.slice(1).toLowerCase()} ${doc.number || ""}`, M, H - 9);

  // ── Watermark on paid documents ─────────────────────────────────────────
  // Drawn last, on top of everything: the cards above are opaque, so a watermark drawn first
  // would vanish behind them. At this opacity the text underneath stays fully readable.
  if (doc.paid) {
    pdf.saveGraphicsState();
    pdf.setGState(new pdf.GState({ opacity: 0.07 }));
    pdf.setTextColor(...GREEN);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(110);
    pdf.text("PAID", W / 2, H / 2 + 20, { align: "center", angle: 30 });
    pdf.restoreGraphicsState();
  }

}

/** The file name a downloaded or attached copy should have. */
export const documentFileName = (doc) => `${doc.isReceipt ? "Receipt" : "Invoice"}_${doc.number || ""}.pdf`;
