// FILE PATH: backend/src/models/AdmissionInquiry.js
import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const AdmissionInquiry = sequelize.define('AdmissionInquiry', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: { model: 'tenants', key: 'id' },
  },
  reference: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  // Split first/middle/last, not a single "student_name" — matches
  // pages/Student/AdmissionForm.jsx exactly, so a reviewed inquiry can be
  // handed straight to that form without staff re-typing or guessing how
  // to split a full name back apart.
  first_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  middle_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  last_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  date_of_birth: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  gender: {
    type: DataTypes.ENUM('male', 'female', 'other'),
    allowNull: true,
  },
  desired_class: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  parent_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    // Optional — only name and phone are required of a family applying.
    type: DataTypes.STRING,
    allowNull: true,
    validate: { isEmail: { msg: 'Enter a valid email address' } },
  },
  phone: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  address: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  message: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('new', 'contacted', 'enrolled', 'declined'),
    allowNull: false,
    defaultValue: 'new',
  },
  staff_notes: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  source: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'website',
  },
}, {
  tableName: 'admission_inquiries',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id', 'status'] },
    { fields: ['tenant_id', 'created_at'] },
  ],
});

export default AdmissionInquiry;