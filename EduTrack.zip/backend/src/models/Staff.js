import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Staff = sequelize.define('Staff', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  user_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id',
    },
  },
  campus_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'campuses',
      key: 'id',
    },
  },
  employee_number: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  department: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  /** Who approves this staff member's leave requests at Step 1 (e.g.
   * their Head of Department). Falls back to the Principal directly if
   * not set. References User (not Staff) so it lines up with how leave
   * approvers are resolved elsewhere. */
  reports_to_id: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  designation: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  joining_date: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  contract_type: {
    type: DataTypes.ENUM('permanent', 'contract', 'part_time'),
    defaultValue: 'permanent',
  },
  salary: {
    type: DataTypes.DECIMAL(12, 2),
    allowNull: true,
  },
  experience_years: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
  qualifications: {
    type: DataTypes.JSONB,
    defaultValue: [],
  },
  teaching_subjects: {
    type: DataTypes.JSONB,
    defaultValue: [],
    comment: 'Array of subject IDs this staff member is qualified to teach (for teachers)',
  },
  emergency_contact: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  address: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  city: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  country: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  // ── Personal ─────────────────────────────────────────────────────────
  date_of_birth: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  gender: {
    type: DataTypes.ENUM('male', 'female', 'other'),
    allowNull: true,
  },
  marital_status: {
    type: DataTypes.ENUM('single', 'married', 'divorced', 'widowed'),
    allowNull: true,
  },
  blood_group: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  /** Tanzanian NIDA number — needed on employment paperwork and for
   * verifying identity against the documents uploaded below. */
  national_id: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  // ── Emergency contact ────────────────────────────────────────────────
  // `emergency_contact` above holds the phone number. A number with no
  // name against it is nearly useless in an actual emergency, so the
  // person and their relationship are recorded too.
  emergency_contact_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  emergency_contact_relation: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  // ── Payroll / statutory ──────────────────────────────────────────────
  // Payroll already computes net pay, but the identifiers a Tanzanian
  // school must file against — TIN, NSSF, and where the money actually
  // goes — had nowhere to live.
  tin_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  nssf_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  bank_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  bank_account_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  // ── Employment ───────────────────────────────────────────────────────
  /** When a fixed-term contract ends. Only meaningful for contract and
   * part-time staff; null for permanent. */
  contract_end_date: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  /** Free-text HR notes — disciplinary summaries, commitments made at
   * hiring, anything that belongs on the file but has no field. */
  notes: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  /**
   * Uploaded employment documents: ID copy, appointment letter,
   * certificates, contract. Stored as
   * [{ id, name, type, url, uploaded_at }] so a staff file can hold any
   * number of them without a separate table.
   */
  documents: {
    type: DataTypes.JSONB,
    defaultValue: [],
  },

  status: {
    type: DataTypes.ENUM('active', 'inactive', 'on_leave', 'terminated'),
    defaultValue: 'active',
  },
}, {
  tableName: 'staff',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['user_id'] },
    { fields: ['campus_id'] },
    { fields: ['employee_number'] },
    { fields: ['status'] },
    { fields: ['department'] },
  ],
});

export default Staff;
