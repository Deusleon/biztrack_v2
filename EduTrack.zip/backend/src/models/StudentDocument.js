import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

/** A single document attached to a student's record (medical form, birth
 * certificate, report card, etc). Stored on disk via the shared upload
 * middleware — this row just tracks the category/label + file location. */
const StudentDocument = sequelize.define('StudentDocument', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  student_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'students',
      key: 'id',
    },
  },
  category: {
    type: DataTypes.ENUM(
      'medical_form',
      'birth_certificate',
      'report_card',
      'immunization_record',
      'national_id',
      'passport_photo',
      'transfer_letter',
      'other'
    ),
    allowNull: false,
    defaultValue: 'other',
  },
  title: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  file_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  file_url: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  file_size: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  uploaded_by: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id',
    },
  },
}, {
  tableName: 'student_documents',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['student_id'] },
    { fields: ['category'] },
  ],
});

export default StudentDocument;
