import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Exam = sequelize.define('Exam', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  campus_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'campuses',
      key: 'id',
    },
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  exam_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  academic_year: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  term: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  start_date: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  end_date: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('draft', 'scheduled', 'ongoing', 'completed', 'cancelled'),
    defaultValue: 'draft',
  },
  /**
   * Which classes this exam applies to. Empty/null = applies to every
   * class (matches the original behaviour before this field existed).
   * When set, Marks Entry and Results only offer these classes for this
   * exam, so a teacher can't accidentally enter O-Level marks under an
   * A-Level exam or vice-versa.
   */
  class_ids: {
    type: DataTypes.JSONB,
    allowNull: true,
    defaultValue: [],
  },
}, {
  tableName: 'exams',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['campus_id'] },
    { fields: ['status'] },
  ],
});

const Grade = sequelize.define('Grade', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  exam_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'exams',
      key: 'id',
    },
  },
  student_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'students',
      key: 'id',
    },
  },
  subject_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'subjects',
      key: 'id',
    },
  },
  marks_obtained: {
    type: DataTypes.DECIMAL(5, 2),
    allowNull: true,
  },
  max_marks: {
    type: DataTypes.DECIMAL(5, 2),
    allowNull: false,
  },
  grade: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  remarks: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
}, {
  tableName: 'grades',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['exam_id'] },
    { fields: ['student_id'] },
    { fields: ['subject_id'] },
  ],
});

export { Exam, Grade };
