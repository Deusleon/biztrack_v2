import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Vehicle = sequelize.define('Vehicle', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false, references: { model: 'tenants', key: 'id' } },
  campus_id: { type: DataTypes.UUID, allowNull: false, references: { model: 'campuses', key: 'id' } },
  registration_number: { type: DataTypes.STRING, allowNull: false }, // e.g. "T123 ABC"
  make: { type: DataTypes.STRING, allowNull: true }, // e.g. "Toyota"
  model: { type: DataTypes.STRING, allowNull: true }, // e.g. "Coaster"
  year: { type: DataTypes.INTEGER, allowNull: true },
  capacity: { type: DataTypes.INTEGER, allowNull: true }, // seats
  description: { type: DataTypes.TEXT, allowNull: true },
  photo_url: { type: DataTypes.STRING, allowNull: true },
  driver_name: { type: DataTypes.STRING, allowNull: true },
  driver_phone: { type: DataTypes.STRING, allowNull: true },
  driver_license_number: { type: DataTypes.STRING, allowNull: true },
  insurance_expiry: { type: DataTypes.DATEONLY, allowNull: true },
  inspection_expiry: { type: DataTypes.DATEONLY, allowNull: true },
  status: {
    type: DataTypes.ENUM('active', 'in_maintenance', 'inactive'),
    defaultValue: 'active',
  },
}, {
  tableName: 'vehicles',
  timestamps: true,
  indexes: [{ fields: ['tenant_id'] }, { fields: ['campus_id'] }],
});

/** Service/maintenance history — one row per service event (oil change,
 * tire replacement, full service, repair, ...). Kept as a simple log,
 * not a scheduling system — "next service due" is just a date note on
 * each record, surfaced on the vehicle's page. */
const VehicleMaintenanceRecord = sequelize.define('VehicleMaintenanceRecord', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  vehicle_id: { type: DataTypes.UUID, allowNull: false, references: { model: 'vehicles', key: 'id' } },
  service_date: { type: DataTypes.DATEONLY, allowNull: false },
  service_type: { type: DataTypes.STRING, allowNull: false }, // e.g. "Oil Change", "Full Service", "Repair"
  cost: { type: DataTypes.DECIMAL(10, 2), allowNull: true },
  performed_by: { type: DataTypes.STRING, allowNull: true }, // garage / mechanic name
  next_service_date: { type: DataTypes.DATEONLY, allowNull: true },
  notes: { type: DataTypes.TEXT, allowNull: true },
  created_by: { type: DataTypes.UUID, allowNull: true },
}, {
  tableName: 'vehicle_maintenance_records',
  timestamps: true,
  indexes: [{ fields: ['tenant_id'] }, { fields: ['vehicle_id'] }],
});

const Route = sequelize.define('Route', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  campus_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'campuses',
      key: 'id',
    },
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  route_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  /** Optional link to a managed Vehicle record — when set, the vehicle's
   * own driver/registration info is what's authoritative; the fields
   * below remain for routes that don't (yet) have a formal Vehicle
   * record, so nothing breaks for existing simple setups. */
  vehicle_id: { type: DataTypes.UUID, allowNull: true, references: { model: 'vehicles', key: 'id' } },
  driver_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  driver_phone: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  vehicle_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  capacity: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  stops: {
    type: DataTypes.JSONB,
    defaultValue: [],
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive'),
    defaultValue: 'active',
  },
}, {
  tableName: 'routes',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['campus_id'] },
  ],
});

const TransportAllocation = sequelize.define('TransportAllocation', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  student_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'students',
      key: 'id',
    },
  },
  route_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'routes',
      key: 'id',
    },
  },
  pickup_point: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  drop_point: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  fee: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive'),
    defaultValue: 'active',
  },
}, {
  tableName: 'transport_allocations',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['student_id'] },
    { fields: ['route_id'] },
  ],
});

export { Route, TransportAllocation, Vehicle, VehicleMaintenanceRecord };
