import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

/**
 * One "I forgot my password" request. The 6-digit code that was sent is NEVER
 * stored — only a keyed hash of it — so reading this table reveals no codes.
 * A code works once, for 15 minutes, and for at most 5 wrong guesses
 * (see services/passwordResetService.js).
 */
const PasswordReset = sequelize.define('PasswordReset', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  user_id: { type: DataTypes.UUID, allowNull: false },
  code_hash: { type: DataTypes.STRING, allowNull: false },
  expires_at: { type: DataTypes.DATE, allowNull: false },
  attempts: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
  used_at: { type: DataTypes.DATE, allowNull: true },
  // Where the code was sent, for support ("sms", "email") — never the address itself.
  channels: { type: DataTypes.JSONB, allowNull: false, defaultValue: [] },
}, {
  tableName: 'password_resets',
  timestamps: true,
  indexes: [{ fields: ['user_id'] }],
});

export default PasswordReset;
