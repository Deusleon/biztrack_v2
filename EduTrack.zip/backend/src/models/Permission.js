import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

/**
 * Role-level permissions — the primary mechanism: a role (e.g.
 * 'teacher', 'accountant') is granted a set of permission keys, and
 * every user with that role gets them automatically. One row per role
 * per tenant.
 *
 * User.permissions (see User model) is the secondary mechanism — extra
 * permissions granted to one specific person beyond what their role
 * normally allows. Effective permissions for a user are always
 * roleGrant UNION userGrant — never a replacement of the role's grant,
 * so giving one teacher an extra permission can never accidentally take
 * away what the "teacher" role already provides everyone else.
 */
const RolePermission = sequelize.define('RolePermission', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  role: { type: DataTypes.STRING, allowNull: false },
  permissions: { type: DataTypes.JSONB, defaultValue: [] },
}, {
  tableName: 'role_permissions',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { unique: true, fields: ['tenant_id', 'role'] },
  ],
});

export default RolePermission;
