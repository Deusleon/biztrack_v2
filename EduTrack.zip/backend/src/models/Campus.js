import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Campus = sequelize.define('Campus', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  code: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  address: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  city: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  state: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  country: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  postal_code: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  phone: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  website: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  /**
   * Public URL of the school's logo, uploaded via
   * POST /campus/:id/logo. Printed on payment receipts and report cards
   * so official documents carry the school's real letterhead instead of
   * a placeholder. Null until a logo is uploaded — every consumer must
   * fall back gracefully rather than rendering a broken image.
   */
  logo_url: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  principal_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id',
    },
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive'),
    defaultValue: 'active',
  },
  /**
   * Saved input from the simplified Timetable "Schedule Settings" form
   * (start time, period length, periods/day, Friday half-day, break
   * placement, etc.) — stored verbatim so the settings screen can be
   * pre-filled with exactly what the admin last chose, instead of having
   * to reverse-engineer it from the generated Time Slot rows.
   * Shape: { start_time, period_duration, periods_per_day, friday_periods,
   *          break_after_period, break_duration, lunch_after_period,
   *          lunch_duration, add_friday_prayer_slot, friday_prayer_duration }
   */
  timetable_settings: {
    type: DataTypes.JSONB,
    allowNull: true,
    defaultValue: {},
  },
}, {
  tableName: 'campuses',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['status'] },
  ],
});

export default Campus;
