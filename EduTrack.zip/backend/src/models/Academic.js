import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Class = sequelize.define('Class', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  campus_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'campuses',
      key: 'id',
    },
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  grade: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  /**
   * Which academic year FORMAT this class uses — see
   * backend/src/utils/academicYear.js for the shared logic. Tanzanian
   * (and similar) school systems commonly write Primary/O-Level years as
   * a single year ("2025") but A-Level years as a two-year span
   * ("2025-2026"), since Form 5/6 is treated as one continuous 2-year
   * program. Defaults to 'o_level' so existing data (and schools that
   * don't run A-Level) behave exactly as before this field existed.
   */
  education_level: {
    type: DataTypes.ENUM('primary', 'o_level', 'a_level'),
    allowNull: false,
    defaultValue: 'o_level',
  },
  academic_year: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  capacity: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive', 'archived'),
    defaultValue: 'active',
  },
}, {
  tableName: 'classes',
  timestamps: true,
  underscored: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['campus_id'] },
    { fields: ['status'] },
  ],
});

const Section = sequelize.define('Section', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  class_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'classes',
      key: 'id',
    },
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  class_teacher_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id',
    },
  },
  capacity: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive'),
    defaultValue: 'active',
  },
}, {
  tableName: 'sections',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['class_id'] },
    { fields: ['status'] },
  ],
});

export { Class, Section };
