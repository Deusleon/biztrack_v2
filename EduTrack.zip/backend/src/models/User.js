import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';
import bcrypt from 'bcryptjs';

const User = sequelize.define('User', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true,
    },
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  first_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  middle_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  last_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  role: {
    type: DataTypes.ENUM(
      'super_admin',
      'admin',
      'principal',
      'teacher',
      'student',
      'parent',
      'accountant',
      'librarian',
      'hr',
      'transport_manager',
      'hostel_warden'
    ),
    allowNull: false,
  },
  phone: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  avatar: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive', 'suspended'),
    defaultValue: 'active',
  },
  last_login: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  failed_login_attempts: {
    // Consecutive wrong-password attempts since the last successful login
    // or the last lockout. Reset to 0 on success; used by authController's
    // login lockout, whose thresholds live in Tenant.settings.session_policy
    // (see utils/sessionPolicy.js).
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0,
  },
  locked_until: {
    // Set when failed_login_attempts crosses the tenant's configured
    // threshold; login is refused until this timestamp passes.
    type: DataTypes.DATE,
    allowNull: true,
  },
  permissions: {
    type: DataTypes.JSONB,
    defaultValue: [],
  },
  must_change_password: {
    // Set true for auto-generated student accounts (see studentCredentials.js)
    // so the frontend/backend can prompt them to set their own password
    // after their first login. Cleared by the change-password endpoint.
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
}, {
  tableName: 'users',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['email'], unique: true },
    { fields: ['role'] },
    { fields: ['status'] },
  ],
  hooks: {
    beforeCreate: async (user) => {
      if (user.password) {
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(user.password, salt);
      }
    },
    beforeUpdate: async (user) => {
      if (user.changed('password')) {
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(user.password, salt);
      }
    },
  },
});

User.prototype.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

export default User;
