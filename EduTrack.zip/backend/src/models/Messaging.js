// FILE PATH: backend/src/models/Messaging.js
import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

// ═══════════════════════════════════════════════════════════════════════════
// CONTACTS — anyone reachable by message: parents, staff, suppliers, others.
// Can optionally link to an existing platform User (parent/staff already in
// the system), or stand alone (e.g. a supplier who never logs in).
// ═══════════════════════════════════════════════════════════════════════════
export const Contact = sequelize.define('Contact', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  campus_id: { type: DataTypes.UUID, allowNull: true },
  name: { type: DataTypes.STRING, allowNull: false },
  phone: { type: DataTypes.STRING, allowNull: true },
  email: { type: DataTypes.STRING, allowNull: true },
  type: {
    type: DataTypes.ENUM('parent', 'staff', 'student', 'supplier', 'other'),
    defaultValue: 'other',
  },
  /** If this contact is also a platform user (most parents/staff/students
   * are), link them here so messages can also show as in-app notifications
   * and so the contact record stays in sync with their profile. */
  linked_user_id: { type: DataTypes.UUID, allowNull: true },
  notes: { type: DataTypes.TEXT, allowNull: true },
  status: { type: DataTypes.ENUM('active', 'inactive'), defaultValue: 'active' },
  created_by: { type: DataTypes.UUID, allowNull: true },
}, {
  tableName: 'contacts',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] }, { fields: ['campus_id'] }, { fields: ['type'] },
    { fields: ['linked_user_id'] }, { fields: ['phone'] },
  ],
});

// ═══════════════════════════════════════════════════════════════════════════
// CONTACT GROUPS — manual groups (hand-picked members) or dynamic/smart
// groups (auto-computed from a filter, e.g. "every parent of Form I").
// Groups can nest one level as subgroups via parent_group_id.
// ═══════════════════════════════════════════════════════════════════════════
export const ContactGroup = sequelize.define('ContactGroup', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  campus_id: { type: DataTypes.UUID, allowNull: true },
  name: { type: DataTypes.STRING, allowNull: false },
  description: { type: DataTypes.TEXT, allowNull: true },
  parent_group_id: { type: DataTypes.UUID, allowNull: true }, // subgroup of another group
  /** Dynamic groups compute their membership on the fly from a simple
   * filter instead of a stored member list — e.g. { role: 'parent',
   * class_id: '...' } means "every parent of every student in this class".
   * Static groups (is_dynamic=false) use ContactGroupMember instead. */
  is_dynamic: { type: DataTypes.BOOLEAN, defaultValue: false },
  dynamic_filter: { type: DataTypes.JSONB, allowNull: true },
  created_by: { type: DataTypes.UUID, allowNull: true },
}, {
  tableName: 'contact_groups',
  timestamps: true,
  indexes: [{ fields: ['tenant_id'] }, { fields: ['parent_group_id'] }],
});

export const ContactGroupMember = sequelize.define('ContactGroupMember', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  group_id: { type: DataTypes.UUID, allowNull: false },
  contact_id: { type: DataTypes.UUID, allowNull: false },
}, {
  tableName: 'contact_group_members',
  timestamps: true,
  indexes: [
    { fields: ['group_id'] }, { fields: ['contact_id'] },
    { unique: true, fields: ['group_id', 'contact_id'] },
  ],
});

// ═══════════════════════════════════════════════════════════════════════════
// MESSAGE TEMPLATES — reusable bodies with {{placeholders}}
// ═══════════════════════════════════════════════════════════════════════════
export const MessageTemplate = sequelize.define('MessageTemplate', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  name: { type: DataTypes.STRING, allowNull: false },
  category: {
    type: DataTypes.ENUM('fee_reminder', 'exam_result', 'attendance', 'general', 'event', 'custom'),
    defaultValue: 'general',
  },
  channel: { type: DataTypes.ENUM('sms', 'email', 'in_app'), defaultValue: 'sms' },
  subject: { type: DataTypes.STRING, allowNull: true }, // used for email
  body: { type: DataTypes.TEXT, allowNull: false },
  status: { type: DataTypes.ENUM('active', 'inactive'), defaultValue: 'active' },
  created_by: { type: DataTypes.UUID, allowNull: true },
}, {
  tableName: 'message_templates',
  timestamps: true,
  indexes: [{ fields: ['tenant_id'] }, { fields: ['category'] }],
});

// ═══════════════════════════════════════════════════════════════════════════
// MESSAGES — one compose/send action, possibly fanning out to many
// recipients (individual / group / subgroup / role broadcast). Drafts are
// Messages with status='draft' and no MessageRecipient rows yet.
// ═══════════════════════════════════════════════════════════════════════════
export const Message = sequelize.define('Message', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  campus_id: { type: DataTypes.UUID, allowNull: true },
  sender_id: { type: DataTypes.UUID, allowNull: true }, // null for system-automated messages
  channel: { type: DataTypes.ENUM('sms', 'email', 'in_app'), defaultValue: 'sms' },
  subject: { type: DataTypes.STRING, allowNull: true },
  body: { type: DataTypes.TEXT, allowNull: false },
  template_id: { type: DataTypes.UUID, allowNull: true },
  recipient_type: {
    type: DataTypes.ENUM('individual', 'group', 'subgroup', 'role_broadcast', 'custom_numbers', 'selected_contacts', 'student_parents'),
    defaultValue: 'individual',
  },
  /** Human-readable summary of who this was sent to, e.g. "Form I A
   * Parents (24)" or "3 contacts" — avoids re-deriving it for display. */
  recipient_summary: { type: DataTypes.STRING, allowNull: true },
  status: {
    type: DataTypes.ENUM('draft', 'queued', 'sending', 'sent', 'partially_sent', 'failed'),
    defaultValue: 'draft',
  },
  is_automated: { type: DataTypes.BOOLEAN, defaultValue: false }, // sent by a system trigger, not a person
  scheduled_at: { type: DataTypes.DATE, allowNull: true },
  sent_at: { type: DataTypes.DATE, allowNull: true },
  total_recipients: { type: DataTypes.INTEGER, defaultValue: 0 },
  sent_count: { type: DataTypes.INTEGER, defaultValue: 0 },
  failed_count: { type: DataTypes.INTEGER, defaultValue: 0 },
  cost: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 }, // total SMS cost deducted from balance

  /**
   * Delivery figures pulled back FROM the provider, as opposed to
   * `sent_count`, which only records that the gateway accepted the send.
   * The two are routinely different — a message can be accepted and then
   * dropped by the network — and conflating them is what made the history
   * page claim messages were delivered when they weren't.
   *
   * Null until a delivery check has actually run.
   */
  delivered_count: { type: DataTypes.INTEGER, allowNull: true },
  provider_failed_count: { type: DataTypes.INTEGER, allowNull: true },
  delivery_checked_at: { type: DataTypes.DATE, allowNull: true },
}, {
  tableName: 'messages',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] }, { fields: ['sender_id'] }, { fields: ['status'] }, { fields: ['channel'] },
  ],
});

export const MessageRecipient = sequelize.define('MessageRecipient', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  message_id: { type: DataTypes.UUID, allowNull: false },
  contact_id: { type: DataTypes.UUID, allowNull: true }, // null when sent to a raw number not in Contacts
  name_snapshot: { type: DataTypes.STRING, allowNull: true },
  phone_snapshot: { type: DataTypes.STRING, allowNull: true },
  email_snapshot: { type: DataTypes.STRING, allowNull: true },
  status: { type: DataTypes.ENUM('pending', 'sent', 'delivered', 'failed'), defaultValue: 'pending' },
  /** The ID the SMS/email gateway assigned to this specific send, used to
   * match an incoming delivery-report webhook back to this row. Null for
   * simulated sends (there's no real gateway to report back). */
  provider_message_id: { type: DataTypes.STRING, allowNull: true },
  error_message: { type: DataTypes.STRING, allowNull: true },
  sent_at: { type: DataTypes.DATE, allowNull: true },
  delivered_at: { type: DataTypes.DATE, allowNull: true },
}, {
  tableName: 'message_recipients',
  timestamps: true,
  indexes: [{ fields: ['message_id'] }, { fields: ['contact_id'] }, { fields: ['status'] }, { fields: ['provider_message_id'] }],
});

// ═══════════════════════════════════════════════════════════════════════════
// SMS BALANCE & LEDGER — a simple internal wallet. Purchases recorded here
// are manual/simulated (see smsGatewayService.js) until a real payment +
// SMS provider is wired in.
// ═══════════════════════════════════════════════════════════════════════════
export const SmsBalance = sequelize.define('SmsBalance', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false, unique: true },
  balance: { type: DataTypes.DECIMAL(12, 2), defaultValue: 0 }, // in SMS credits/units
  cost_per_sms: { type: DataTypes.DECIMAL(10, 2), defaultValue: 1 },
}, {
  tableName: 'sms_balances',
  timestamps: true,
});

export const SmsTransaction = sequelize.define('SmsTransaction', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  type: { type: DataTypes.ENUM('purchase', 'deduction', 'refund', 'adjustment'), allowNull: false },
  amount: { type: DataTypes.DECIMAL(12, 2), allowNull: false }, // positive for purchase/refund, negative for deduction
  balance_after: { type: DataTypes.DECIMAL(12, 2), allowNull: false },
  reference: { type: DataTypes.STRING, allowNull: true }, // e.g. message_id or a payment reference
  description: { type: DataTypes.STRING, allowNull: true },
  created_by: { type: DataTypes.UUID, allowNull: true },
}, {
  tableName: 'sms_transactions',
  timestamps: true,
  indexes: [{ fields: ['tenant_id'] }, { fields: ['type'] }],
});

// ═══════════════════════════════════════════════════════════════════════════
// SMS GATEWAY SETTINGS — provider credentials, one row per tenant. Values
// are placeholders until a real provider (Beem Africa, NextSMS, Meseji, SwalaSMS) is
// configured; see smsService.js.
// ═══════════════════════════════════════════════════════════════════════════
export const SmsGatewaySettings = sequelize.define('SmsGatewaySettings', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false, unique: true },
  provider: {
    type: DataTypes.ENUM('simulated', 'beem_africa', 'nextsms', 'meseji', 'swalasms'),
    defaultValue: 'simulated',
  },
  api_key: { type: DataTypes.STRING, allowNull: true },
  api_secret: { type: DataTypes.STRING, allowNull: true },
  sender_id: { type: DataTypes.STRING, allowNull: true }, // the "from" name/number shown to recipients of the school's own messages
  // The platform's sender, for password-reset codes and subscription messages. Optional: until it is
  // set, system messages use sender_id (see services/smsService.js settingsForPurpose).
  system_sender_id: { type: DataTypes.STRING, allowNull: true },
  is_active: { type: DataTypes.BOOLEAN, defaultValue: false },
  // Every provider's credentials, remembered separately so switching gateway
  // never loses them. The three columns above stay the ACTIVE provider's set —
  // that is what every sender reads. See utils/smsCredentialVault.js.
  saved_credentials: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
}, {
  tableName: 'sms_gateway_settings',
  timestamps: true,
});

// ═══════════════════════════════════════════════════════════════════════════
// EMAIL GATEWAY SETTINGS — SMTP credentials, one row per tenant. Falls back
// to the .env-based transporter (see emailService.js) when not configured
// or not active, so email keeps working out of the box.
// ═══════════════════════════════════════════════════════════════════════════
export const EmailGatewaySettings = sequelize.define('EmailGatewaySettings', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false, unique: true },
  smtp_host: { type: DataTypes.STRING, allowNull: true },
  smtp_port: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 587 },
  smtp_secure: { type: DataTypes.BOOLEAN, defaultValue: false }, // true = TLS on connect (port 465), false = STARTTLS (port 587)
  smtp_username: { type: DataTypes.STRING, allowNull: true },
  smtp_password: { type: DataTypes.STRING, allowNull: true },
  from_email: { type: DataTypes.STRING, allowNull: true },
  from_name: { type: DataTypes.STRING, allowNull: true },
  // The platform's sender, for password-reset and subscription emails. Optional: until set, the
  // school's own from_email / from_name are used (see services/emailService.js gatewayFromAddress).
  system_from_email: { type: DataTypes.STRING, allowNull: true },
  system_from_name: { type: DataTypes.STRING, allowNull: true },
  is_active: { type: DataTypes.BOOLEAN, defaultValue: false },
}, {
  tableName: 'email_gateway_settings',
  timestamps: true,
});

// ═══════════════════════════════════════════════════════════════════════════
// NOTIFICATION SETTINGS — which automatic system events send a
// notification (and through which channels), per tenant.
// ═══════════════════════════════════════════════════════════════════════════
export const NotificationSetting = sequelize.define('NotificationSetting', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  /** e.g. 'payment_recorded', 'exam_results_published', 'student_absent',
   * 'timetable_published' — see notificationEvents.js for the full list. */
  event_key: { type: DataTypes.STRING, allowNull: false },
  enabled: { type: DataTypes.BOOLEAN, defaultValue: true },
  channels: { type: DataTypes.JSONB, defaultValue: ['in_app'] }, // subset of ['in_app','sms','email'] — used by events with no parties (password reset)
  /** Who is notified and how: { partyKey: [channels] }. A party that is missing is not notified. null = the event's defaults.
   * See notificationEvents.js for each event's parties. */
  audience: { type: DataTypes.JSONB, allowNull: true },
}, {
  tableName: 'notification_settings',
  timestamps: true,
  indexes: [{ unique: true, fields: ['tenant_id', 'event_key'] }],
});