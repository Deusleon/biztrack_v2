import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Subject = sequelize.define('Subject', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  code: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  campus_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'campuses',
      key: 'id',
    },
  },
  credits: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_elective: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive'),
    defaultValue: 'active',
  },
}, {
  tableName: 'subjects',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['code'] },
    { fields: ['status'] },
  ],
});

export default Subject;
