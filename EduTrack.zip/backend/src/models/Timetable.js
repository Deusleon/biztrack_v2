import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

/**
 * Timetable module — 3 models, rebuilt from scratch.
 *
 * TimetableSettings — one row per campus PER education level (Primary,
 *   O-Level, A-Level each keep their own school week, since real schools
 *   commonly run different period counts/lengths per level). Describes
 *   what the week looks like: start time, period length, periods/day,
 *   Friday's shorter day, where the tea/lunch breaks fall, and the fixed
 *   end-of-day activity label(s) for each day. The period grid itself
 *   (start/end clock time of every period and break) is computed from
 *   these numbers on the fly — there is no separate table to keep in
 *   sync with it.
 *
 * ClassSubject — "this class studies this subject N times a week,
 *   usually taught by this teacher." The only planning input Auto-Fill
 *   needs, and also read by other modules (Subject stats, Staff teaching
 *   load) to know what a class studies / what a teacher teaches.
 *
 * TimetableEntry — one placed lesson: a class + section, a day, a period
 *   number, a subject, and optionally a teacher. A double period is
 *   simply two adjacent entries with the same subject/teacher. There is
 *   no draft/published version — a section's timetable is just its
 *   current set of entries, edited directly.
 */

export const TimetableSettings = sequelize.define('TimetableSettings', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  campus_id: { type: DataTypes.UUID, allowNull: false },
  /** Primary/O-Level and A-Level commonly run different school weeks —
   * each level gets its own settings row, chosen automatically from
   * whichever class is being viewed/edited. */
  education_level: {
    type: DataTypes.ENUM('primary', 'o_level', 'a_level'),
    allowNull: false,
    defaultValue: 'o_level',
  },
  start_time: {
    type: DataTypes.STRING(5),
    allowNull: false,
    defaultValue: '07:30',
    validate: { is: /^([01]\d|2[0-3]):[0-5]\d$/ },
  }, // "HH:MM", when Period 1 begins
  period_duration: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 40,
    validate: { min: 10, max: 180 },
  }, // minutes
  periods_per_day: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 8,
    validate: { min: 1, max: 15 },
  }, // Monday–Thursday
  friday_periods: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 4,
    validate: { min: 0, max: 15 },
  }, // Friday is commonly a shorter day
  break_after_period: {
    type: DataTypes.INTEGER,
    allowNull: true,
    validate: { min: 1, max: 15 },
  }, // null = no tea break
  break_duration: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 20 },
  lunch_after_period: {
    type: DataTypes.INTEGER,
    allowNull: true,
    validate: { min: 1, max: 15 },
  }, // null = no lunch break
  lunch_duration: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 40 },
  /** Fixed non-academic activity slot(s) at the end of each day, e.g.
   * { monday: ["Cleanliness"], friday: ["Mosque", "Debate", "Sport & Games"] }.
   * A label only — no subject/teacher — shown as trailing row(s) on the grid. */
  daily_activities: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
}, {
  tableName: 'timetable_settings',
  timestamps: true,
  indexes: [{ unique: true, fields: ['campus_id', 'education_level'], name: 'timetable_settings_campus_id_education_level' }],
});

export const ClassSubject = sequelize.define('ClassSubject', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  class_id: { type: DataTypes.UUID, allowNull: false },
  subject_id: { type: DataTypes.UUID, allowNull: false },
  teacher_id: { type: DataTypes.UUID, allowNull: true }, // null = not assigned yet
  periods_per_week: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 1,
    validate: { min: 1, max: 40 },
  },
  academic_year: { type: DataTypes.STRING, allowNull: false },
}, {
  tableName: 'class_subjects',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'], name: 'class_subjects_tenant_id' },
    { fields: ['class_id'], name: 'class_subjects_class_id' },
    { fields: ['teacher_id'], name: 'class_subjects_teacher_id' },
    { unique: true, fields: ['class_id', 'subject_id', 'academic_year'], name: 'class_subjects_class_id_subject_id_academic_year' },
  ],
});

export const TimetableEntry = sequelize.define('TimetableEntry', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  class_id: { type: DataTypes.UUID, allowNull: false },
  section_id: { type: DataTypes.UUID, allowNull: false },
  academic_year: { type: DataTypes.STRING, allowNull: false },
  day: {
    type: DataTypes.ENUM('monday', 'tuesday', 'wednesday', 'thursday', 'friday'),
    allowNull: false,
  },
  period_number: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: { min: 1, max: 15 },
  }, // 1-based, matches TimetableSettings' computed grid
  subject_id: { type: DataTypes.UUID, allowNull: true }, // null = empty/free period
  teacher_id: { type: DataTypes.UUID, allowNull: true },
}, {
  tableName: 'timetable_entries',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'], name: 'timetable_entries_tenant_id' },
    { fields: ['class_id', 'section_id', 'academic_year'], name: 'timetable_entries_class_id_section_id_academic_year' },
    { fields: ['teacher_id'], name: 'timetable_entries_teacher_id' },
    { fields: ['subject_id'], name: 'timetable_entries_subject_id' },
    { unique: true, fields: ['section_id', 'academic_year', 'day', 'period_number'], name: 'timetable_entries_section_id_academic_year_day_period_number' },
  ],
});
