// FILE PATH: backend/src/models/ContactInquiry.js
import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const ContactInquiry = sequelize.define('ContactInquiry', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: { model: 'tenants', key: 'id' },
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: { isEmail: { msg: 'Enter a valid email address' } },
  },
  phone: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  subject: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  message: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM('new', 'read', 'replied'),
    allowNull: false,
    defaultValue: 'new',
  },
  staff_notes: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  source: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'website',
  },
}, {
  tableName: 'contact_inquiries',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id', 'status'] },
    { fields: ['tenant_id', 'created_at'] },
  ],
});

export default ContactInquiry;