// backend/src/models/Library.js
import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Book = sequelize.define('Book', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  isbn: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  author: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  publisher: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  publication_year: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  category: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  total_copies: {
    type: DataTypes.INTEGER,
    defaultValue: 1,
  },
  available_copies: {
    type: DataTypes.INTEGER,
    defaultValue: 1,
  },
  location: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  /** What it costs the school to replace one copy. Charged to the borrower
   * when a copy is written off as lost — without it, losing a book costs
   * the borrower nothing and the school absorbs the whole loss. */
  replacement_cost: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive', 'damaged', 'lost'),
    defaultValue: 'active',
  },
}, {
  tableName: 'books',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['isbn'] },
    { fields: ['category'] },
  ],
});

const BookIssue = sequelize.define('BookIssue', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  book_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'books',
      key: 'id',
    },
  },
  user_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id',
    },
  },
  /** Which physical copy (1..total_copies) was handed out — lets the
   * librarian confirm a returned book is actually the same copy that
   * went out, not a different one being swapped in as a substitute. */
  copy_number: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  issue_date: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  due_date: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  return_date: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  /** Total owed on this loan: overdue fine + replacement charge. Kept as
   * the single figure to collect, with the two components stored
   * separately below so a borrower can see what they're being charged for. */
  fine_amount: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0,
  },
  /** Accrued at a flat daily rate for every day past the due date. */
  overdue_fine: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0,
  },
  /** The book's replacement cost, charged only when a copy is written off
   * as lost. Snapshotted here so later re-pricing of the book doesn't
   * retroactively change what a borrower was told they owe. */
  replacement_charge: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0,
  },
  /** How much of `fine_amount` has actually been collected. Previously
   * fines accumulated with no way to ever clear them. */
  fine_paid: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0,
  },
  fine_status: {
    type: DataTypes.ENUM('none', 'pending', 'partial', 'paid', 'waived'),
    defaultValue: 'none',
  },
  /** Set when a fine is written off, so a waiver is an auditable decision
   * rather than a silent edit. */
  fine_waived_by: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id',
    },
  },
  fine_waiver_reason: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('issued', 'returned', 'overdue', 'lost'),
    defaultValue: 'issued',
  },
  remarks: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
}, {
  tableName: 'book_issues',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['book_id'] },
    { fields: ['user_id'] },
    { fields: ['status'] },
  ],
});

/**
 * LibrarySettings — the lending rules for one school.
 *
 * The loan period and the overdue fine rate were constants in
 * libraryController.js, which meant every school on the platform charged
 * TZS 500 a day and lent for exactly 14 days, with no way to change either
 * short of editing code. Fines were being shown to parents that nobody at
 * the school had ever agreed to.
 *
 * One row per tenant, created on first read.
 */
const LibrarySettings = sequelize.define('LibrarySettings', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: {
    type: DataTypes.UUID, allowNull: false, unique: true,
    references: { model: 'tenants', key: 'id' },
  },

  /** How long a book is lent for when no due date is given explicitly. */
  default_loan_days: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 14 },

  /** Charged for each day past the due date. Set to 0 to run a library
   * that doesn't fine at all — some schools don't. */
  fine_per_day: { type: DataTypes.DECIMAL(10, 2), allowNull: false, defaultValue: 500 },

  /** Lateness stops accruing after this many days. Without a cap, a book
   * forgotten over a long holiday reaches a fine nobody can pay, and the
   * debt just gets written off — which teaches everyone that fines aren't
   * real. */
  max_fine_days: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 60 },

  /** Charged when a book has no replacement cost of its own recorded. */
  default_replacement_cost: { type: DataTypes.DECIMAL(10, 2), allowNull: false, defaultValue: 0 },

  /** How many books one borrower may hold at once. Null means no limit. */
  max_books_per_borrower: { type: DataTypes.INTEGER, allowNull: true },
}, {
  tableName: 'library_settings',
  timestamps: true,
  indexes: [{ fields: ['tenant_id'] }],
});

export { Book, BookIssue, LibrarySettings };