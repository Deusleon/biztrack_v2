import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

/** One row: how the automatic full-database backup behaves, and the Google Drive link. Platform-level (not per school). */
export const DatabaseBackupSettings = sequelize.define('DatabaseBackupSettings', {
  id: { type: DataTypes.INTEGER, primaryKey: true, defaultValue: 1 },
  enabled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
  run_at_hour: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 2 },
  retention_days: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 14 },
  protect_risky_actions: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
  drive_enabled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
  drive_client_id: { type: DataTypes.TEXT },
  drive_client_secret_enc: { type: DataTypes.TEXT },
  drive_refresh_token_enc: { type: DataTypes.TEXT },
  drive_account_email: { type: DataTypes.STRING },
  drive_folder_id: { type: DataTypes.STRING },
  drive_connected_at: { type: DataTypes.DATE },
  drive_last_error: { type: DataTypes.TEXT },
}, { tableName: 'database_backup_settings', timestamps: true });

/** One backup attempt: when, why, how big, whether the restore test passed, and whether it reached Drive. */
export const DatabaseBackup = sequelize.define('DatabaseBackup', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  trigger: { type: DataTypes.STRING(20), allowNull: false, defaultValue: 'manual' }, // scheduled | manual | before_action | command_line
  reason: { type: DataTypes.TEXT },
  status: { type: DataTypes.STRING(20), allowNull: false, defaultValue: 'running' }, // running | success | failed
  file_name: { type: DataTypes.STRING },
  size_bytes: { type: DataTypes.BIGINT },
  sha256: { type: DataTypes.STRING(64) },
  table_count: { type: DataTypes.INTEGER },
  row_count: { type: DataTypes.BIGINT },
  duration_ms: { type: DataTypes.INTEGER },
  verify_status: { type: DataTypes.STRING(20), allowNull: false, defaultValue: 'pending' }, // pending | passed | failed
  verify_detail: { type: DataTypes.JSONB },
  verified_at: { type: DataTypes.DATE },
  drive_status: { type: DataTypes.STRING(20), allowNull: false, defaultValue: 'skipped' }, // skipped | pending | uploaded | failed
  drive_file_id: { type: DataTypes.STRING },
  drive_error: { type: DataTypes.TEXT },
  error: { type: DataTypes.TEXT },
  warnings: { type: DataTypes.JSONB },
  file_deleted: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
  triggered_by: { type: DataTypes.UUID },
}, { tableName: 'database_backups', timestamps: true, indexes: [{ fields: ['created_at'] }] });
