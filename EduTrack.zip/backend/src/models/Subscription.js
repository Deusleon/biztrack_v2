import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

/**
 * SubscriptionPlan — what a school can buy.
 *
 * Pricing is per BILLING CYCLE rather than a single monthly figure divided
 * up, because Tanzanian schools think in terms, not months, and a term is
 * not three months. Each cycle carries its own price so a school buying a
 * year can be given a genuine discount instead of paying 12 × monthly.
 *
 * `student_limit` is null for unlimited. It is enforced on admission, so a
 * school on Basic cannot quietly grow to 900 students.
 */
export const SubscriptionPlan = sequelize.define('SubscriptionPlan', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },

  /** Stable machine key ('basic', 'standard', 'premium') — safe to
   * reference in code even if the display name is later reworded. */
  code: { type: DataTypes.STRING, allowNull: false, unique: true },
  name: { type: DataTypes.STRING, allowNull: false },
  description: { type: DataTypes.TEXT, allowNull: true },

  /** Maximum enrolled students. Null means unlimited. */
  student_limit: { type: DataTypes.INTEGER, allowNull: true },

  price_monthly: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  price_termly: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  price_yearly: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },

  /** Modules included at no extra cost. Anything not listed here can still
   * be bought as an add-on. */
  included_modules: { type: DataTypes.JSONB, defaultValue: [] },

  /** Controls the order plans are shown in, cheapest first. Also decides
   * what counts as an UPGRADE versus a downgrade. */
  tier: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },

  status: { type: DataTypes.ENUM('active', 'inactive'), defaultValue: 'active' },
}, {
  tableName: 'subscription_plans',
  timestamps: true,
  indexes: [{ fields: ['code'] }, { fields: ['status'] }],
});

/**
 * SubscriptionAddOn — an optional module a school can pay extra for.
 *
 * Kept as its own table rather than a JSON blob on the plan so prices can
 * change without rewriting every plan, and so an add-on can be retired
 * without breaking subscriptions that already reference it.
 */
export const SubscriptionAddOn = sequelize.define('SubscriptionAddOn', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  code: { type: DataTypes.STRING, allowNull: false, unique: true },
  name: { type: DataTypes.STRING, allowNull: false },
  description: { type: DataTypes.TEXT, allowNull: true },
  price_monthly: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  price_termly: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  price_yearly: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  status: { type: DataTypes.ENUM('active', 'inactive'), defaultValue: 'active' },
}, {
  tableName: 'subscription_addons',
  timestamps: true,
  indexes: [{ fields: ['code'] }, { fields: ['status'] }],
});

/**
 * Subscription — one row per tenant holding their CURRENT entitlement.
 *
 * `status` drives access to the whole system:
 *   trial    → free evaluation period, full access
 *   active   → paid and inside the paid window
 *   grace    → the window has closed but the short grace period hasn't;
 *              still working, warned loudly
 *   expired  → locked out except for logging in and paying
 *   cancelled→ deliberately ended
 *
 * The grace period exists because a payment can be a day late for
 * blameless reasons (a bank holiday, a failed USSD push). It is measured
 * in days from `ends_at`.
 */
export const Subscription = sequelize.define('Subscription', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false, unique: true, references: { model: 'tenants', key: 'id' } },
  plan_id: { type: DataTypes.UUID, allowNull: true, references: { model: 'subscription_plans', key: 'id' } },

  billing_cycle: { type: DataTypes.ENUM('monthly', 'termly', 'yearly'), defaultValue: 'monthly' },

  status: {
    type: DataTypes.ENUM('trial', 'active', 'grace', 'expired', 'cancelled'),
    defaultValue: 'trial',
  },

  starts_at: { type: DataTypes.DATE, allowNull: true },
  /** End of the PAID window. Access continues until ends_at + grace_days. */
  ends_at: { type: DataTypes.DATE, allowNull: true },
  grace_days: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 2 },
  /** Expiry reminders already sent for the current paid window — see migration 20261030000000. */
  reminders_sent: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },

  /** What was actually charged for the current window, kept so an upgrade
   * can work out how much of it is unused. */
  amount_paid: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },

  /** Add-on codes currently active on this subscription. */
  addons: { type: DataTypes.JSONB, defaultValue: [] },

  /** Enrolled students at the time of purchase — useful when a school
   * outgrows its plan and needs to be shown why. */
  student_count_at_purchase: { type: DataTypes.INTEGER, allowNull: true },

  auto_renew: { type: DataTypes.BOOLEAN, defaultValue: false },
  cancelled_at: { type: DataTypes.DATE, allowNull: true },
}, {
  tableName: 'subscriptions',
  timestamps: true,
  indexes: [{ fields: ['tenant_id'] }, { fields: ['status'] }, { fields: ['ends_at'] }],
});

/**
 * SubscriptionInvoice — one row per attempt to pay.
 *
 * Kept separate from Subscription because a school may try to pay several
 * times before one succeeds, and every attempt has to be auditable. An
 * invoice is what a payment gateway reference points at.
 */
export const SubscriptionInvoice = sequelize.define('SubscriptionInvoice', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false, references: { model: 'tenants', key: 'id' } },
  subscription_id: { type: DataTypes.UUID, allowNull: true, references: { model: 'subscriptions', key: 'id' } },
  plan_id: { type: DataTypes.UUID, allowNull: true, references: { model: 'subscription_plans', key: 'id' } },

  invoice_number: { type: DataTypes.STRING, allowNull: false, unique: true },

  /** Human-readable breakdown: plan price, each add-on, any proration
   * credit. Stored so a receipt reads the same a year later even if prices
   * have since changed. */
  line_items: { type: DataTypes.JSONB, defaultValue: [] },

  billing_cycle: { type: DataTypes.ENUM('monthly', 'termly', 'yearly'), allowNull: false },
  subtotal: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  /** Unused value carried over from the plan being replaced, on upgrade. */
  proration_credit: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  total: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  currency: { type: DataTypes.STRING, allowNull: false, defaultValue: 'TZS' },

  status: {
    type: DataTypes.ENUM('pending', 'processing', 'paid', 'failed', 'cancelled'),
    defaultValue: 'pending',
  },

  /** Whether this invoice buys a new window or extends/upgrades one. */
  kind: { type: DataTypes.ENUM('new', 'renewal', 'upgrade'), defaultValue: 'new' },

  // ── Gateway ───────────────────────────────────────────────────────────
  /** Our own reference, sent to the gateway and echoed back on webhooks.
   * This is what ties an incoming payment notification to this invoice. */
  order_reference: { type: DataTypes.STRING, allowNull: false, unique: true },
  gateway: { type: DataTypes.STRING, allowNull: true },
  gateway_payment_id: { type: DataTypes.STRING, allowNull: true },
  gateway_status: { type: DataTypes.STRING, allowNull: true },
  /** The full gateway response, kept verbatim for dispute resolution. */
  gateway_response: { type: DataTypes.JSONB, allowNull: true },
  payer_phone: { type: DataTypes.STRING, allowNull: true },
  paid_at: { type: DataTypes.DATE, allowNull: true },
  failure_reason: { type: DataTypes.STRING, allowNull: true },

  /** The window this invoice pays for, so a late payment still credits the
   * period it was meant for. */
  period_start: { type: DataTypes.DATE, allowNull: true },
  period_end: { type: DataTypes.DATE, allowNull: true },
}, {
  tableName: 'subscription_invoices',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['status'] },
    { fields: ['order_reference'] },
    { fields: ['invoice_number'] },
  ],
});
