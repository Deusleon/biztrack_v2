import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

/**
 * Expenses — a straightforward ledger, not an approval workflow (per
 * product decision: Accountant/Admin records an expense directly, the
 * same way they'd log a transaction in a cashbook). Two models:
 *
 *   ExpenseCategory — simple labels ("Utilities", "Salaries",
 *     "Maintenance", "Supplies", ...) for grouping and reporting.
 *
 *   Expense — one recorded expense: amount, category, who it was paid
 *     to, how, and an optional receipt photo (reuses the same upload
 *     infrastructure as Vehicle photos).
 */

export const ExpenseCategory = sequelize.define('ExpenseCategory', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  name: { type: DataTypes.STRING, allowNull: false },
  description: { type: DataTypes.STRING, allowNull: true },
  status: { type: DataTypes.ENUM('active', 'inactive'), defaultValue: 'active' },
}, {
  tableName: 'expense_categories',
  timestamps: true,
  indexes: [{ fields: ['tenant_id'] }],
});

export const Expense = sequelize.define('Expense', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  campus_id: { type: DataTypes.UUID, allowNull: true },
  category_id: { type: DataTypes.UUID, allowNull: false },
  amount: { type: DataTypes.DECIMAL(12, 2), allowNull: false },
  expense_date: { type: DataTypes.DATEONLY, allowNull: false },
  payee: { type: DataTypes.STRING, allowNull: true },
  description: { type: DataTypes.TEXT, allowNull: true },
  payment_method: {
    type: DataTypes.ENUM('cash', 'bank_transfer', 'mobile_money', 'cheque', 'other'),
    defaultValue: 'cash',
  },
  reference_number: { type: DataTypes.STRING, allowNull: true },
  receipt_url: { type: DataTypes.STRING, allowNull: true },
  recorded_by: { type: DataTypes.UUID, allowNull: false },
  status: { type: DataTypes.ENUM('recorded', 'void'), defaultValue: 'recorded' },
}, {
  tableName: 'expenses',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['category_id'] },
    { fields: ['expense_date'] },
  ],
});
