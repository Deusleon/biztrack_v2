import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

/**
 * Payroll — kept to 2 models, deliberately simple:
 *
 *   PayrollPeriod — one payroll run for a month/year. Lifecycle:
 *     draft (being prepared/edited) -> processed (locked, ready to pay)
 *     -> paid (payslips finalized; on marking paid, a single Expense
 *     entry is created under "Salaries & Wages" for the total, linking
 *     payroll to the expense ledger instead of duplicating bookkeeping).
 *
 *   PayrollItem — one staff member's payslip within a period. Starts
 *     pre-filled from Staff.salary as the basic salary; allowances and
 *     deductions are simple named line items (JSONB arrays) rather than
 *     a separate types system — e.g. [{ "label": "Housing", "amount":
 *     100000 }] — flexible without adding more models.
 */

export const PayrollPeriod = sequelize.define('PayrollPeriod', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  campus_id: { type: DataTypes.UUID, allowNull: true },
  month: { type: DataTypes.INTEGER, allowNull: false },
  year: { type: DataTypes.INTEGER, allowNull: false },
  status: {
    type: DataTypes.ENUM('draft', 'processed', 'paid'),
    defaultValue: 'draft',
  },
  processed_by: { type: DataTypes.UUID, allowNull: true },
  processed_at: { type: DataTypes.DATE, allowNull: true },
  paid_by: { type: DataTypes.UUID, allowNull: true },
  paid_at: { type: DataTypes.DATE, allowNull: true },
  expense_id: { type: DataTypes.UUID, allowNull: true },
}, {
  tableName: 'payroll_periods',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { unique: true, fields: ['tenant_id', 'campus_id', 'month', 'year'] },
  ],
});

export const PayrollItem = sequelize.define('PayrollItem', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  payroll_period_id: { type: DataTypes.UUID, allowNull: false },
  staff_id: { type: DataTypes.UUID, allowNull: false },
  user_id: { type: DataTypes.UUID, allowNull: false },
  basic_salary: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  allowances: { type: DataTypes.JSONB, defaultValue: [] },
  deductions: { type: DataTypes.JSONB, defaultValue: [] },
  gross_pay: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  total_deductions: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  net_pay: { type: DataTypes.DECIMAL(12, 2), allowNull: false, defaultValue: 0 },
  notes: { type: DataTypes.STRING, allowNull: true },
}, {
  tableName: 'payroll_items',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['payroll_period_id'] },
    { unique: true, fields: ['payroll_period_id', 'staff_id'] },
  ],
});
