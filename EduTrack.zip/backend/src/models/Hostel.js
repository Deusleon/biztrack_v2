import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Hostel = sequelize.define('Hostel', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  campus_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'campuses',
      key: 'id',
    },
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  type: {
    type: DataTypes.ENUM('boys', 'girls', 'mixed'),
    allowNull: false,
  },
  warden_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id',
    },
  },
  total_rooms: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  address: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive'),
    defaultValue: 'active',
  },
}, {
  tableName: 'hostels',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['campus_id'] },
  ],
});

const Room = sequelize.define('Room', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  hostel_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'hostels',
      key: 'id',
    },
  },
  room_number: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  capacity: {
    type: DataTypes.INTEGER,
    defaultValue: 1,
  },
  occupied: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
  floor: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('available', 'occupied', 'maintenance'),
    defaultValue: 'available',
  },
}, {
  tableName: 'rooms',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['hostel_id'] },
  ],
});

const HostelAllocation = sequelize.define('HostelAllocation', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  student_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'students',
      key: 'id',
    },
  },
  room_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'rooms',
      key: 'id',
    },
  },
  allocation_date: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  fee: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive', 'vacated'),
    defaultValue: 'active',
  },
}, {
  tableName: 'hostel_allocations',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['student_id'] },
    { fields: ['room_id'] },
  ],
});

export { Hostel, Room, HostelAllocation };
