import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

/**
 * StudentPromotion — the record of what happened to one student at the end
 * of an academic year.
 *
 * Promotion moves a student between class rows, and a class row belongs to
 * a specific academic year. Doing that without a record would make the
 * change untraceable: nobody could later answer "which class was she in
 * last year?", and a promotion run applied to the wrong class would be
 * impossible to undo.
 *
 * `batch_id` groups every row created by a single promotion run, which is
 * what makes reverting possible — a mistake is undone as one operation
 * rather than student by student.
 */
const StudentPromotion = sequelize.define('StudentPromotion', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },

  tenant_id: {
    type: DataTypes.UUID, allowNull: false,
    references: { model: 'tenants', key: 'id' },
  },
  student_id: {
    type: DataTypes.UUID, allowNull: false,
    references: { model: 'students', key: 'id' },
  },

  /** Groups one promotion run. Shared by every student processed together. */
  batch_id: { type: DataTypes.UUID, allowNull: false },

  /**
   * What was decided for this student:
   *   promoted    → moved up to the next class
   *   retained    → stays in the same grade, in the new year's class
   *   graduated   → finished the final form; status becomes 'graduated'
   *   transferred → left the school; status becomes 'transferred'
   */
  action: {
    type: DataTypes.ENUM('promoted', 'retained', 'graduated', 'transferred'),
    allowNull: false,
  },

  from_class_id: { type: DataTypes.UUID, allowNull: true },
  to_class_id: { type: DataTypes.UUID, allowNull: true },
  from_section_id: { type: DataTypes.UUID, allowNull: true },
  to_section_id: { type: DataTypes.UUID, allowNull: true },

  from_academic_year: { type: DataTypes.STRING, allowNull: true },
  to_academic_year: { type: DataTypes.STRING, allowNull: true },

  /** The student's status before the run, so a revert restores it exactly
   * rather than assuming everyone was 'active'. */
  previous_status: { type: DataTypes.STRING, allowNull: true },

  notes: { type: DataTypes.TEXT, allowNull: true },

  performed_by: {
    type: DataTypes.UUID, allowNull: true,
    references: { model: 'users', key: 'id' },
  },

  /** Set when a batch is rolled back, so the history shows both that the
   * promotion happened and that it was undone. */
  reverted_at: { type: DataTypes.DATE, allowNull: true },
  reverted_by: { type: DataTypes.UUID, allowNull: true },
}, {
  tableName: 'student_promotions',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['student_id'] },
    { fields: ['batch_id'] },
    { fields: ['to_academic_year'] },
  ],
});

export default StudentPromotion;
