import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

/**
 * Leave — two-step approval (Step 1 → Step 2 → Approved), works for both
 * staff and student leave/excuse requests:
 *
 *   Staff:   Step 1 = their reports_to (Staff.reports_to_id), falls back
 *            to the Principal directly if not set. Step 2 = Principal.
 *   Student: Step 1 = their class's class teacher. Step 2 = Principal.
 *
 * Kept to 3 models: LeaveType (what kinds of leave exist, and whether
 * they draw from a yearly balance), LeaveBalance (days allocated/used per
 * person per type per year — staff only), LeaveRequest (one request, its
 * dates, and the two approval decisions).
 */

export const LeaveType = sequelize.define('LeaveType', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  name: { type: DataTypes.STRING, allowNull: false },
  applies_to: {
    type: DataTypes.ENUM('staff', 'student', 'both'),
    defaultValue: 'staff',
  },
  has_balance: { type: DataTypes.BOOLEAN, defaultValue: true },
  default_days_per_year: { type: DataTypes.INTEGER, allowNull: true },
  status: { type: DataTypes.ENUM('active', 'inactive'), defaultValue: 'active' },
}, {
  tableName: 'leave_types',
  timestamps: true,
  indexes: [{ fields: ['tenant_id'] }],
});

export const LeaveBalance = sequelize.define('LeaveBalance', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  user_id: { type: DataTypes.UUID, allowNull: false },
  leave_type_id: { type: DataTypes.UUID, allowNull: false },
  year: { type: DataTypes.INTEGER, allowNull: false },
  allocated_days: { type: DataTypes.DECIMAL(5, 1), allowNull: false, defaultValue: 0 },
  used_days: { type: DataTypes.DECIMAL(5, 1), allowNull: false, defaultValue: 0 },
}, {
  tableName: 'leave_balances',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { unique: true, fields: ['user_id', 'leave_type_id', 'year'] },
  ],
});

export const LeaveRequest = sequelize.define('LeaveRequest', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  user_id: { type: DataTypes.UUID, allowNull: false },
  requester_role: { type: DataTypes.ENUM('staff', 'student'), allowNull: false },
  leave_type_id: { type: DataTypes.UUID, allowNull: false },
  start_date: { type: DataTypes.DATEONLY, allowNull: false },
  end_date: { type: DataTypes.DATEONLY, allowNull: false },
  days_count: { type: DataTypes.DECIMAL(5, 1), allowNull: false },
  reason: { type: DataTypes.TEXT, allowNull: true },
  attachment_url: { type: DataTypes.STRING, allowNull: true },

  current_step: { type: DataTypes.INTEGER, defaultValue: 1 },
  status: {
    type: DataTypes.ENUM('pending', 'approved', 'rejected', 'cancelled'),
    defaultValue: 'pending',
  },

  step1_approver_id: { type: DataTypes.UUID, allowNull: true },
  step1_decision: { type: DataTypes.ENUM('approved', 'rejected'), allowNull: true },
  step1_comment: { type: DataTypes.STRING, allowNull: true },
  step1_at: { type: DataTypes.DATE, allowNull: true },

  step2_approver_id: { type: DataTypes.UUID, allowNull: true },
  step2_decision: { type: DataTypes.ENUM('approved', 'rejected'), allowNull: true },
  step2_comment: { type: DataTypes.STRING, allowNull: true },
  step2_at: { type: DataTypes.DATE, allowNull: true },
}, {
  tableName: 'leave_requests',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['user_id'] },
    { fields: ['status'] },
  ],
});
