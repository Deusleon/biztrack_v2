import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const FeeStructure = sequelize.define('FeeStructure', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  campus_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'campuses',
      key: 'id',
    },
  },
  class_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'classes',
      key: 'id',
    },
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  frequency: {
    type: DataTypes.ENUM('one_time', 'monthly', 'quarterly', 'annually'),
    defaultValue: 'one_time',
  },
  /**
   * How many times this fee is actually charged across the academic year.
   * Matters most for "monthly"/"quarterly" fees that don't run the full
   * calendar year — e.g. a transport fee only charged for the ~9 months
   * school is in session, not the 3 holiday months. Defaults to the
   * "full year" count for each frequency (12 for monthly, 4 for
   * quarterly) so existing data behaves the same as before this field
   * existed; one_time/annually always charge once regardless of this value.
   */
  billing_cycles: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  academic_year: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  /** Who this fee actually applies to. 'all' (the default) charges
   * every student in the class — for genuinely universal fees like
   * Tuition or Exam Fee. 'transport'/'hostel' charge ONLY students who
   * actually have an active Transport/Hostel allocation — for optional
   * services, so a student who doesn't use the bus never accrues a
   * permanent "balance" for a fee they were never really meant to pay.
   * 'selected_students' charges ONLY the students hand-picked for this
   * structure (rows in fee_structure_students). */
  applies_to: {
    type: DataTypes.ENUM('all', 'transport', 'hostel', 'selected_students'),
    defaultValue: 'all',
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive'),
    defaultValue: 'active',
  },
}, {
  tableName: 'fee_structures',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['campus_id'] },
    { fields: ['class_id'] },
  ],
});

const Payment = sequelize.define('Payment', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  student_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'students',
      key: 'id',
    },
  },
  fee_structure_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'fee_structures',
      key: 'id',
    },
  },
  amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  /**
   * Per-fee-item breakdown when ONE payment settles SEVERAL fee items at
   * once (e.g. a parent clearing Tuition + Uniform + Exam in a single
   * cash hand-over) — so it produces ONE receipt listing every item,
   * instead of forcing one payment/receipt per item.
   *
   * Shape: [{ fee_structure_id, name, amount }, ...] where the amounts
   * always sum to this payment's `amount`. `name` is snapshotted at
   * payment time so an old receipt still reads correctly even if the fee
   * structure is later renamed or deleted.
   *
   * Null/empty for single-item and general payments — those keep using
   * `fee_structure_id` exactly as before, so every payment recorded
   * before this column existed still behaves identically.
   */
  allocations: {
    type: DataTypes.JSONB,
    allowNull: true,
  },
  /**
   * The receipt exactly as it stood the moment this payment was taken —
   * what was owed, what had already been settled, and the per-item
   * breakdown printed on the paper the parent walked away with.
   *
   * Without this, reprinting an old receipt would recompute against
   * TODAY's figures: yesterday's receipt and last term's would both show
   * the current balance, and editing a fee structure would silently
   * rewrite the history of every receipt that referenced it. A receipt is
   * a financial record, so it's frozen at issue rather than derived.
   *
   * Shape: { expected, paid_to_date, balance, extra, fee_checklist:
   *          [{ name, amount, charged, paid_to_date, status }] }
   * Null for payments recorded before this column existed — those are
   * reconstructed on first view (see getPaymentById).
   */
  receipt_snapshot: {
    type: DataTypes.JSONB,
    allowNull: true,
  },
  payment_method: {
    type: DataTypes.ENUM('cash', 'card', 'bank_transfer', 'online', 'cheque'),
    allowNull: false,
  },
  payment_date: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  transaction_id: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('pending', 'completed', 'failed', 'refunded'),
    defaultValue: 'completed',
  },
  remarks: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  received_by: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id',
    },
  },
}, {
  tableName: 'payments',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['student_id'] },
    { fields: ['payment_date'] },
    { fields: ['status'] },
  ],
});

/**
 * StudentCharge — a one-off amount owed by ONE specific student, on top of
 * the fee structures their whole class is billed.
 *
 * Fee structures are class-wide by design ("every Form 2 pays Tuition"),
 * so they cannot express "this particular student owes for the library
 * book they lost". Without this, such debts lived only inside their own
 * module and never reached the student's actual balance — the bursar
 * collecting fees had no idea they existed.
 *
 * `description` is deliberately required and human-readable: a receipt
 * line reading "Charge — 25,000" tells a parent nothing about what they
 * are being asked to pay for.
 */
const StudentCharge = sequelize.define('StudentCharge', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: {
    type: DataTypes.UUID, allowNull: false,
    references: { model: 'tenants', key: 'id' },
  },
  student_id: {
    type: DataTypes.UUID, allowNull: false,
    references: { model: 'students', key: 'id' },
  },
  /** What this debt is FOR, in plain words — printed verbatim on the
   * receipt and in the payment form, e.g.
   * "Library — Lost book: Things Fall Apart (Copy #2)". */
  description: { type: DataTypes.STRING, allowNull: false },
  category: {
    type: DataTypes.ENUM('library', 'damage', 'other'),
    defaultValue: 'other',
  },
  amount: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
  academic_year: { type: DataTypes.STRING, allowNull: true },
  /** Which module raised this, so the owning module can keep its own
   * record and this charge in step instead of creating duplicates.
   * e.g. source_type 'book_issue' + the BookIssue's id. */
  source_type: { type: DataTypes.STRING, allowNull: true },
  source_id: { type: DataTypes.UUID, allowNull: true },
  /** 'waived' and 'cancelled' both stop counting towards what's owed;
   * kept apart so a written-off debt is distinguishable from one raised
   * in error. */
  status: {
    type: DataTypes.ENUM('active', 'waived', 'cancelled'),
    defaultValue: 'active',
  },
  waived_by: {
    type: DataTypes.UUID, allowNull: true,
    references: { model: 'users', key: 'id' },
  },
  waiver_reason: { type: DataTypes.TEXT, allowNull: true },
}, {
  tableName: 'student_charges',
  timestamps: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['student_id'] },
    { fields: ['status'] },
    { fields: ['source_type', 'source_id'] },
  ],
});

/** One row per (fee_structure, student) pair — who a 'selected_students'
 * FeeStructure actually applies to. Only meaningful for that one
 * applies_to value; a structure that's 'all'/'transport'/'hostel' never
 * has rows here and doesn't need any (see feeController.js's
 * applicableStructures for how each applies_to type decides who's
 * billed). */
const FeeStructureStudent = sequelize.define('FeeStructureStudent', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID, allowNull: false,
    references: { model: 'tenants', key: 'id' },
  },
  fee_structure_id: {
    type: DataTypes.UUID, allowNull: false,
    references: { model: 'fee_structures', key: 'id' },
  },
  student_id: {
    type: DataTypes.UUID, allowNull: false,
    references: { model: 'students', key: 'id' },
  },
  assigned_by: {
    type: DataTypes.UUID, allowNull: true,
    references: { model: 'users', key: 'id' },
  },
}, {
  tableName: 'fee_structure_students',
  timestamps: true,
  underscored: true,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['student_id'] },
    { unique: true, fields: ['fee_structure_id', 'student_id'] },
  ],
});

export { FeeStructure, Payment, StudentCharge, FeeStructureStudent };