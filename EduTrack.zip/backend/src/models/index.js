// FILE PATH: backend/src/models/index.js
import sequelize from '../config/database.js';
import Tenant from './Tenant.js';
import User from './User.js';
import Campus from './Campus.js';
import Student from './Student.js';
import StudentDocument from './StudentDocument.js';
import StudentPromotion from './StudentPromotion.js';
import Staff from './Staff.js';
import { Class, Section } from './Academic.js';
import Subject from './Subject.js';
import Attendance from './Attendance.js';
import { Exam, Grade } from './Exam.js';
import { FeeStructure, Payment, StudentCharge, FeeStructureStudent } from './Fee.js';
import {
  TimetableSettings,
  ClassSubject,
  TimetableEntry,
} from './Timetable.js';
import { Book, BookIssue, LibrarySettings } from './Library.js';
import Notification from './Notification.js';
import { SubscriptionPlan, SubscriptionAddOn, Subscription, SubscriptionInvoice } from './Subscription.js';
import { Route, TransportAllocation, Vehicle, VehicleMaintenanceRecord } from './Transport.js';
import { LeaveType, LeaveBalance, LeaveRequest } from './Leave.js';
import AdmissionInquiry from './AdmissionInquiry.js';
import ContactInquiry from './ContactInquiry.js';
import { ExpenseCategory, Expense } from './Expense.js';
import { PayrollPeriod, PayrollItem } from './Payroll.js';
import { InventoryItem, InventoryTransaction } from './Inventory.js';
import RolePermission from './Permission.js';
import PasswordReset from './PasswordReset.js';
import { DatabaseBackup, DatabaseBackupSettings } from './DatabaseBackup.js';
import { Hostel, Room as HostelRoom, HostelAllocation } from './Hostel.js';
import {
  Contact, ContactGroup, ContactGroupMember, MessageTemplate,
  Message, MessageRecipient, SmsBalance, SmsTransaction,
  SmsGatewaySettings, EmailGatewaySettings, NotificationSetting,
} from './Messaging.js';
import AuditLog from '../middleware/auditLog.js';

// Define Relationships

// Tenant relationships
Tenant.hasMany(User, { foreignKey: 'tenant_id', as: 'users' });
Tenant.hasMany(Campus, { foreignKey: 'tenant_id', as: 'campuses' });
Tenant.hasMany(Student, { foreignKey: 'tenant_id', as: 'students' });
Tenant.hasMany(StudentDocument, { foreignKey: 'tenant_id', as: 'studentDocuments' });
Tenant.hasMany(Staff, { foreignKey: 'tenant_id', as: 'staffMembers' });
Tenant.hasMany(Class, { foreignKey: 'tenant_id', as: 'classes' });
Tenant.hasMany(Section, { foreignKey: 'tenant_id', as: 'sections' });
Tenant.hasMany(Subject, { foreignKey: 'tenant_id', as: 'subjects' });
Tenant.hasMany(Attendance, { foreignKey: 'tenant_id', as: 'attendances' });
Tenant.hasMany(Exam, { foreignKey: 'tenant_id', as: 'exams' });
Tenant.hasMany(Grade, { foreignKey: 'tenant_id', as: 'grades' });
Tenant.hasMany(FeeStructure, { foreignKey: 'tenant_id', as: 'feeStructures' });
Tenant.hasMany(Payment, { foreignKey: 'tenant_id', as: 'payments' });
Tenant.hasMany(TimetableEntry, { foreignKey: 'tenant_id', as: 'timetableEntries' });
Tenant.hasMany(ClassSubject, { foreignKey: 'tenant_id', as: 'classSubjects' });
Tenant.hasMany(Book, { foreignKey: 'tenant_id', as: 'books' });
Tenant.hasMany(BookIssue, { foreignKey: 'tenant_id', as: 'bookIssues' });
Tenant.hasMany(Notification, { foreignKey: 'tenant_id', as: 'notifications' });
Tenant.hasMany(Route, { foreignKey: 'tenant_id', as: 'routes' });
Tenant.hasMany(TransportAllocation, { foreignKey: 'tenant_id', as: 'transportAllocations' });
Tenant.hasMany(Hostel, { foreignKey: 'tenant_id', as: 'hostels' });
Tenant.hasMany(HostelRoom, { foreignKey: 'tenant_id', as: 'hostelRooms' });
Tenant.hasMany(HostelAllocation, { foreignKey: 'tenant_id', as: 'hostelAllocations' });
Tenant.hasMany(AuditLog, { foreignKey: 'tenant_id', as: 'auditLogs' });

// User relationships
User.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
User.hasOne(Student, { foreignKey: 'user_id', as: 'studentProfile' });
User.hasOne(Staff, { foreignKey: 'user_id', as: 'staffProfile' });
User.hasMany(AuditLog, { foreignKey: 'user_id', as: 'auditLogs' });

// Campus relationships
Campus.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Campus.belongsTo(User, { foreignKey: 'principal_id', as: 'principal' });
Campus.hasMany(Student, { foreignKey: 'campus_id', as: 'students' });
Campus.hasMany(Staff, { foreignKey: 'campus_id', as: 'staffMembers' });
Campus.hasMany(Class, { foreignKey: 'campus_id', as: 'classes' });
Campus.hasMany(FeeStructure, { foreignKey: 'campus_id', as: 'feeStructures' });
Campus.hasMany(Exam, { foreignKey: 'campus_id', as: 'exams' });
Campus.hasMany(Route, { foreignKey: 'campus_id', as: 'routes' });
Campus.hasMany(Hostel, { foreignKey: 'campus_id', as: 'hostels' });

// Student relationships
Student.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Student.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
Student.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
Student.belongsTo(Class, { foreignKey: 'class_id', as: 'class' });
Student.belongsTo(Section, { foreignKey: 'section_id', as: 'section' });
Student.belongsTo(User, { foreignKey: 'parent_id', as: 'parent' });
Student.hasMany(Attendance, { foreignKey: 'student_id', as: 'attendances' });
Student.hasMany(Grade, { foreignKey: 'student_id', as: 'grades' });
Student.hasMany(Payment, { foreignKey: 'student_id', as: 'payments' });
Student.hasMany(TransportAllocation, { foreignKey: 'student_id', as: 'transportAllocations' });
Student.hasMany(HostelAllocation, { foreignKey: 'student_id', as: 'hostelAllocations' });
Student.hasMany(StudentDocument, { foreignKey: 'student_id', as: 'documents' });

// StudentDocument relationships
StudentDocument.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
StudentDocument.belongsTo(Student, { foreignKey: 'student_id', as: 'student' });
StudentDocument.belongsTo(User, { foreignKey: 'uploaded_by', as: 'uploader' });

// Staff relationships
Staff.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Staff.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
Staff.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
Staff.belongsTo(User, { foreignKey: 'reports_to_id', as: 'reportsTo' });

// Class relationships
Class.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Class.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
Class.hasMany(Section, { foreignKey: 'class_id', as: 'sections' });
Class.hasMany(Student, { foreignKey: 'class_id', as: 'students' });
Class.hasMany(Attendance, { foreignKey: 'class_id', as: 'attendances' });
Class.hasMany(FeeStructure, { foreignKey: 'class_id', as: 'feeStructures' });
Class.hasMany(TimetableEntry, { foreignKey: 'class_id', as: 'timetableEntries' });
Class.hasMany(ClassSubject, { foreignKey: 'class_id', as: 'classSubjects' });

// Section relationships
Section.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Section.belongsTo(Class, { foreignKey: 'class_id', as: 'class' });
Section.belongsTo(User, { foreignKey: 'class_teacher_id', as: 'classTeacher' });
Section.hasMany(Student, { foreignKey: 'section_id', as: 'students' });
Section.hasMany(Attendance, { foreignKey: 'section_id', as: 'attendances' });
Section.hasMany(TimetableEntry, { foreignKey: 'section_id', as: 'timetableEntries' });

// Subject relationships
Subject.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Subject.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
Subject.hasMany(Grade, { foreignKey: 'subject_id', as: 'grades' });
Subject.hasMany(TimetableEntry, { foreignKey: 'subject_id', as: 'timetableEntries' });
Subject.hasMany(ClassSubject, { foreignKey: 'subject_id', as: 'classSubjects' });

Campus.hasMany(Subject, { foreignKey: 'campus_id', as: 'subjects' });
Campus.hasOne(TimetableSettings, { foreignKey: 'campus_id', as: 'timetableSettings' });

// Attendance relationships
Attendance.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Attendance.belongsTo(Student, { foreignKey: 'student_id', as: 'student' });
Attendance.belongsTo(Class, { foreignKey: 'class_id', as: 'class' });
Attendance.belongsTo(Section, { foreignKey: 'section_id', as: 'section' });
Attendance.belongsTo(User, { foreignKey: 'initial_marked_by', as: 'initialMarker' });
Attendance.belongsTo(User, { foreignKey: 'latest_marked_by', as: 'latestMarker' });
Attendance.belongsTo(User, { foreignKey: 'marked_by', as: 'markedBy' });

// Exam relationships
Exam.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Exam.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
Exam.hasMany(Grade, { foreignKey: 'exam_id', as: 'grades' });

// Grade relationships
Grade.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Grade.belongsTo(Exam, { foreignKey: 'exam_id', as: 'exam' });
Grade.belongsTo(Student, { foreignKey: 'student_id', as: 'student' });
Grade.belongsTo(Subject, { foreignKey: 'subject_id', as: 'subject' });

// Fee relationships
FeeStructure.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
FeeStructure.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
FeeStructure.belongsTo(Class, { foreignKey: 'class_id', as: 'class' });
FeeStructure.hasMany(Payment, { foreignKey: 'fee_structure_id', as: 'payments' });

// Who a 'selected_students' FeeStructure actually applies to (see
// controllers/feeController.js applicableStructures) — a plain
// hasMany/belongsTo pair rather than belongsToMany, since the join row
// itself carries useful info (assigned_by) beyond just the link.
FeeStructure.hasMany(FeeStructureStudent, { foreignKey: 'fee_structure_id', as: 'studentAssignments' });
FeeStructureStudent.belongsTo(FeeStructure, { foreignKey: 'fee_structure_id', as: 'feeStructure' });
FeeStructureStudent.belongsTo(Student, { foreignKey: 'student_id', as: 'student' });
FeeStructureStudent.belongsTo(User, { foreignKey: 'assigned_by', as: 'assignedBy' });
Student.hasMany(FeeStructureStudent, { foreignKey: 'student_id', as: 'feeStructureAssignments' });

Payment.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Payment.belongsTo(Student, { foreignKey: 'student_id', as: 'student' });
Payment.belongsTo(FeeStructure, { foreignKey: 'fee_structure_id', as: 'feeStructure' });
Payment.belongsTo(User, { foreignKey: 'received_by', as: 'receivedBy' });

StudentCharge.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });

StudentPromotion.belongsTo(Student, { foreignKey: 'student_id', as: 'student' });
StudentPromotion.belongsTo(User, { foreignKey: 'performed_by', as: 'performedBy' });
StudentPromotion.belongsTo(Class, { foreignKey: 'from_class_id', as: 'fromClass' });
StudentPromotion.belongsTo(Class, { foreignKey: 'to_class_id', as: 'toClass' });
Student.hasMany(StudentPromotion, { foreignKey: 'student_id', as: 'promotions' });

// ── Subscriptions ───────────────────────────────────────────────────────
Subscription.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Subscription.belongsTo(SubscriptionPlan, { foreignKey: 'plan_id', as: 'plan' });
Tenant.hasOne(Subscription, { foreignKey: 'tenant_id', as: 'subscription' });

SubscriptionInvoice.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
SubscriptionInvoice.belongsTo(Subscription, { foreignKey: 'subscription_id', as: 'subscription' });
SubscriptionInvoice.belongsTo(SubscriptionPlan, { foreignKey: 'plan_id', as: 'plan' });
Subscription.hasMany(SubscriptionInvoice, { foreignKey: 'subscription_id', as: 'invoices' });
StudentCharge.belongsTo(Student, { foreignKey: 'student_id', as: 'student' });
StudentCharge.belongsTo(User, { foreignKey: 'waived_by', as: 'waivedBy' });
Student.hasMany(StudentCharge, { foreignKey: 'student_id', as: 'charges' });

// Timetable relationships (simplified: 3 models — TimetableSettings,
// ClassSubject, TimetableEntry — replacing the old 7-model design)
TimetableSettings.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
TimetableSettings.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });

ClassSubject.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
ClassSubject.belongsTo(Class, { foreignKey: 'class_id', as: 'class' });
ClassSubject.belongsTo(Subject, { foreignKey: 'subject_id', as: 'subject' });
ClassSubject.belongsTo(User, { foreignKey: 'teacher_id', as: 'teacher' });

TimetableEntry.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
TimetableEntry.belongsTo(Class, { foreignKey: 'class_id', as: 'class' });
TimetableEntry.belongsTo(Section, { foreignKey: 'section_id', as: 'section' });
TimetableEntry.belongsTo(Subject, { foreignKey: 'subject_id', as: 'subject' });
TimetableEntry.belongsTo(User, { foreignKey: 'teacher_id', as: 'teacher' });

User.hasMany(TimetableEntry, { foreignKey: 'teacher_id', as: 'timetableEntries' });
User.hasMany(ClassSubject, { foreignKey: 'teacher_id', as: 'subjectAssignments' });

// Library relationships
Book.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Book.hasMany(BookIssue, { foreignKey: 'book_id', as: 'issues' });

BookIssue.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
BookIssue.belongsTo(Book, { foreignKey: 'book_id', as: 'book' });
BookIssue.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// Notification relationships
Notification.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Notification.belongsTo(User, { foreignKey: 'recipient_id', as: 'recipient' });

// Transport relationships
Route.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Route.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
Route.belongsTo(Vehicle, { foreignKey: 'vehicle_id', as: 'vehicle' });
Route.hasMany(TransportAllocation, { foreignKey: 'route_id', as: 'allocations' });

TransportAllocation.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
TransportAllocation.belongsTo(Student, { foreignKey: 'student_id', as: 'student' });
TransportAllocation.belongsTo(Route, { foreignKey: 'route_id', as: 'route' });

Vehicle.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Vehicle.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
Vehicle.hasMany(Route, { foreignKey: 'vehicle_id', as: 'routes' });
Vehicle.hasMany(VehicleMaintenanceRecord, { foreignKey: 'vehicle_id', as: 'maintenanceRecords' });

VehicleMaintenanceRecord.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
VehicleMaintenanceRecord.belongsTo(Vehicle, { foreignKey: 'vehicle_id', as: 'vehicle' });
VehicleMaintenanceRecord.belongsTo(User, { foreignKey: 'created_by', as: 'creator' });

// Leave relationships
LeaveType.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });

LeaveBalance.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
LeaveBalance.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
LeaveBalance.belongsTo(LeaveType, { foreignKey: 'leave_type_id', as: 'leaveType' });

LeaveRequest.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
LeaveRequest.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
LeaveRequest.belongsTo(LeaveType, { foreignKey: 'leave_type_id', as: 'leaveType' });
LeaveRequest.belongsTo(User, { foreignKey: 'step1_approver_id', as: 'step1Approver' });
LeaveRequest.belongsTo(User, { foreignKey: 'step2_approver_id', as: 'step2Approver' });

// Expense relationships
ExpenseCategory.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
ExpenseCategory.hasMany(Expense, { foreignKey: 'category_id', as: 'expenses' });

Expense.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Expense.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
Expense.belongsTo(ExpenseCategory, { foreignKey: 'category_id', as: 'category' });
Expense.belongsTo(User, { foreignKey: 'recorded_by', as: 'recordedBy' });

// Payroll relationships
PayrollPeriod.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
PayrollPeriod.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
PayrollPeriod.belongsTo(User, { foreignKey: 'processed_by', as: 'processedBy' });
PayrollPeriod.belongsTo(User, { foreignKey: 'paid_by', as: 'paidBy' });
PayrollPeriod.hasMany(PayrollItem, { foreignKey: 'payroll_period_id', as: 'items' });

PayrollItem.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
PayrollItem.belongsTo(PayrollPeriod, { foreignKey: 'payroll_period_id', as: 'period' });
PayrollItem.belongsTo(Staff, { foreignKey: 'staff_id', as: 'staff' });
PayrollItem.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// Inventory relationships
InventoryItem.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
InventoryItem.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
InventoryItem.hasMany(InventoryTransaction, { foreignKey: 'item_id', as: 'transactions' });

InventoryTransaction.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
InventoryTransaction.belongsTo(InventoryItem, { foreignKey: 'item_id', as: 'item' });
InventoryTransaction.belongsTo(User, { foreignKey: 'recorded_by', as: 'recordedBy' });

// Role permissions
RolePermission.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });

// Hostel relationships
Hostel.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Hostel.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
Hostel.belongsTo(User, { foreignKey: 'warden_id', as: 'warden' });
Hostel.hasMany(HostelRoom, { foreignKey: 'hostel_id', as: 'rooms' });

HostelRoom.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
HostelRoom.belongsTo(Hostel, { foreignKey: 'hostel_id', as: 'hostel' });
HostelRoom.hasMany(HostelAllocation, { foreignKey: 'room_id', as: 'allocations' });

HostelAllocation.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
HostelAllocation.belongsTo(Student, { foreignKey: 'student_id', as: 'student' });
HostelAllocation.belongsTo(HostelRoom, { foreignKey: 'room_id', as: 'room' });

// AuditLog relationships
AuditLog.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });

AdmissionInquiry.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Tenant.hasMany(AdmissionInquiry, { foreignKey: 'tenant_id', as: 'admissionInquiries' });

ContactInquiry.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Tenant.hasMany(ContactInquiry, { foreignKey: 'tenant_id', as: 'contactInquiries' });
AuditLog.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// ── Messaging relationships ──────────────────────────────────────────────
Contact.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Contact.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
Contact.belongsTo(User, { foreignKey: 'linked_user_id', as: 'linkedUser' });
Contact.belongsToMany(ContactGroup, { through: ContactGroupMember, foreignKey: 'contact_id', otherKey: 'group_id', as: 'groups' });

ContactGroup.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
ContactGroup.belongsTo(ContactGroup, { foreignKey: 'parent_group_id', as: 'parentGroup' });
ContactGroup.hasMany(ContactGroup, { foreignKey: 'parent_group_id', as: 'subgroups' });
ContactGroup.belongsToMany(Contact, { through: ContactGroupMember, foreignKey: 'group_id', otherKey: 'contact_id', as: 'members' });
ContactGroup.hasMany(ContactGroupMember, { foreignKey: 'group_id', as: 'memberships' });

ContactGroupMember.belongsTo(ContactGroup, { foreignKey: 'group_id', as: 'group' });
ContactGroupMember.belongsTo(Contact, { foreignKey: 'contact_id', as: 'contact' });

MessageTemplate.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
MessageTemplate.belongsTo(User, { foreignKey: 'created_by', as: 'creator' });

Message.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
Message.belongsTo(Campus, { foreignKey: 'campus_id', as: 'campus' });
Message.belongsTo(User, { foreignKey: 'sender_id', as: 'sender' });
Message.belongsTo(MessageTemplate, { foreignKey: 'template_id', as: 'template' });
Message.hasMany(MessageRecipient, { foreignKey: 'message_id', as: 'recipients' });

MessageRecipient.belongsTo(Message, { foreignKey: 'message_id', as: 'message' });
MessageRecipient.belongsTo(Contact, { foreignKey: 'contact_id', as: 'contact' });

SmsBalance.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
SmsTransaction.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
SmsTransaction.belongsTo(User, { foreignKey: 'created_by', as: 'creator' });
SmsGatewaySettings.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
EmailGatewaySettings.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });
NotificationSetting.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });

export {
  sequelize,
  Tenant,
  User,
  Campus,
  Student,
  StudentDocument,
  Staff,
  Class,
  Section,
  Subject,
  Attendance,
  Exam,
  Grade,
  FeeStructure,
  Payment,
  StudentCharge,
  FeeStructureStudent,
  StudentPromotion,
  SubscriptionPlan,
  SubscriptionAddOn,
  Subscription,
  SubscriptionInvoice,
  TimetableSettings,
  ClassSubject,
  TimetableEntry,
  Book,
  BookIssue,
  LibrarySettings,
  Notification,
  Route,
  TransportAllocation,
  Vehicle,
  VehicleMaintenanceRecord,
  LeaveType,
  LeaveBalance,
  LeaveRequest,
  ExpenseCategory,
  Expense,
  PayrollPeriod,
  PayrollItem,
  InventoryItem,
  InventoryTransaction,
  RolePermission,
  PasswordReset,
  DatabaseBackup,
  DatabaseBackupSettings,
  Hostel,
  HostelRoom,
  HostelAllocation,
  AuditLog,
  Contact,
  ContactGroup,
  ContactGroupMember,
  MessageTemplate,
  Message,
  MessageRecipient,
  SmsBalance,
  SmsTransaction,
  SmsGatewaySettings,
  EmailGatewaySettings,
  NotificationSetting,
  AdmissionInquiry,
  ContactInquiry,
};