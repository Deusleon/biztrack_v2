import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

/**
 * Inventory — school assets/consumables tracking. Kept to 2 models,
 * matching the pattern that worked for Vehicles (item + history log):
 *
 *   InventoryItem — one stock line: furniture, equipment, lab supplies,
 *     stationery, etc. Tracks current quantity_on_hand directly (not
 *     recomputed from transactions each time) for fast reads; every
 *     change to it happens through a transaction below, so the two never
 *     drift apart as long as all changes go through the API.
 *
 *   InventoryTransaction — one stock movement: received (new stock in),
 *     issued (given out to a class/department/person), damaged, lost, or
 *     a manual adjustment (correcting a miscount). A running ledger, the
 *     same idea as Expense's ledger or Vehicle's maintenance history.
 */

/**
 * Inventory — school assets/consumables tracking. Kept to 2 models,
 * matching the pattern that worked for Vehicles (item + history log):
 *
 *   InventoryItem — one stock line: furniture, equipment, lab supplies,
 *     stationery, etc. quantity_on_hand is the total across every
 *     condition; condition_breakdown splits that same total by
 *     condition (e.g. { new: 10, good: 30, fair: 4, poor: 1 }) so a
 *     batch that arrives partly damaged doesn't get silently blended
 *     into "45 pcs" with no way to tell which ones are which. Every
 *     change to either happens through a transaction below, so they
 *     never drift apart as long as all changes go through the API.
 *
 *   InventoryTransaction — one stock movement: received (new stock in),
 *     issued (given out to a class/department/person), damaged, lost, or
 *     a manual adjustment (correcting a miscount) — each tagged with
 *     which condition bucket it affected. A running ledger, the same
 *     idea as Expense's ledger or Vehicle's maintenance history.
 */

const CONDITIONS = ['new', 'good', 'fair', 'poor'];
export const INVENTORY_CONDITIONS = CONDITIONS;

/**
 * The two kinds of stock a school keeps, which behave differently:
 *
 *   asset       — fixed assets: desks, projectors, microscopes. They are
 *                 not "used up"; what matters is how many there are and
 *                 what CONDITION they are in. Tracked per condition
 *                 bucket; reorder levels don't apply.
 *
 *   consumable  — things that run down and run out: chalk, exercise
 *                 books, cleaning supplies. What matters is the quantity
 *                 left and when to restock (reorder_level). Condition is
 *                 not tracked — the whole quantity sits in one bucket.
 */
export const INVENTORY_ITEM_TYPES = ['asset', 'consumable'];

const emptyBreakdown = () => ({ new: 0, good: 0, fair: 0, poor: 0 });

export const InventoryItem = sequelize.define('InventoryItem', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  campus_id: { type: DataTypes.UUID, allowNull: true },
  name: { type: DataTypes.STRING, allowNull: false },
  item_type: { type: DataTypes.ENUM(...INVENTORY_ITEM_TYPES), allowNull: false, defaultValue: 'consumable' },
  category: { type: DataTypes.STRING, allowNull: true },
  unit: { type: DataTypes.STRING, allowNull: false, defaultValue: 'pcs' },
  quantity_on_hand: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
  /** Same total as quantity_on_hand, split by condition — the source of
   * truth for "how many of these are actually in good shape". */
  condition_breakdown: { type: DataTypes.JSONB, defaultValue: emptyBreakdown },
  reorder_level: { type: DataTypes.INTEGER, allowNull: true },
  location: { type: DataTypes.STRING, allowNull: true },
  notes: { type: DataTypes.TEXT, allowNull: true },
  status: { type: DataTypes.ENUM('active', 'inactive'), defaultValue: 'active' },
}, {
  tableName: 'inventory_items',
  timestamps: true,
  indexes: [{ fields: ['tenant_id'] }, { fields: ['campus_id'] }, { fields: ['category'] }, { fields: ['item_type'] }],
});

export const InventoryTransaction = sequelize.define('InventoryTransaction', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  tenant_id: { type: DataTypes.UUID, allowNull: false },
  item_id: { type: DataTypes.UUID, allowNull: false },
  type: {
    type: DataTypes.ENUM('received', 'issued', 'damaged', 'lost', 'adjusted'),
    allowNull: false,
  },
  quantity: { type: DataTypes.INTEGER, allowNull: false },
  /** Which condition bucket this movement affected — e.g. 20 "good"
   * chairs received, or 3 "fair" chairs issued out. Required for every
   * type except a rare legacy/blank case, kept nullable only so old
   * rows created before this field existed don't break. */
  condition: { type: DataTypes.ENUM(...CONDITIONS), allowNull: true },
  issued_to: { type: DataTypes.STRING, allowNull: true },
  transaction_date: { type: DataTypes.DATEONLY, allowNull: false },
  notes: { type: DataTypes.STRING, allowNull: true },
  recorded_by: { type: DataTypes.UUID, allowNull: false },
}, {
  tableName: 'inventory_transactions',
  timestamps: true,
  indexes: [{ fields: ['tenant_id'] }, { fields: ['item_id'] }],
});
