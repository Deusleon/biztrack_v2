import { validationResult } from 'express-validator';

export const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation error',
      errors: errors.array(),
    });
  }
  next();
};

export const validateCampus = (req, res, next) => {
  const { name, code } = req.body;
  const errors = [];

  if (!name || name.trim().length === 0) {
    errors.push({ field: 'name', message: 'Campus name is required' });
  }

  if (!code || code.trim().length === 0) {
    errors.push({ field: 'code', message: 'Campus code is required' });
  }

  if (code && !/^[A-Z0-9_-]+$/.test(code)) {
    errors.push({ field: 'code', message: 'Campus code must contain only uppercase letters, numbers, hyphens, and underscores' });
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Validation error',
      errors,
    });
  }

  next();
};

export const validateStudent = (req, res, next) => {
  // email & password are no longer supplied by the client — they're
  // auto-generated server-side from the student's name + admission number
  // (see utils/studentCredentials.js), so they're not validated here.
  const { first_name, last_name, gender, date_of_birth, admission_number, admission_date, campus_id, parent_email } = req.body;
  const errors = [];

  if (!first_name || first_name.trim().length === 0) {
    errors.push({ field: 'first_name', message: 'First name is required' });
  }

  if (!last_name || last_name.trim().length === 0) {
    errors.push({ field: 'last_name', message: 'Last name is required' });
  }

  if (!gender || !['male', 'female', 'other'].includes(gender)) {
    errors.push({ field: 'gender', message: 'Gender is required' });
  }

  if (!date_of_birth) {
    errors.push({ field: 'date_of_birth', message: 'Date of birth is required' });
  }

  if (!admission_number || admission_number.trim().length === 0) {
    errors.push({ field: 'admission_number', message: 'Admission number is required' });
  }

  if (!admission_date) {
    errors.push({ field: 'admission_date', message: 'Admission date is required' });
  }

  if (!campus_id || campus_id.trim().length === 0) {
    errors.push({ field: 'campus_id', message: 'Campus is required' });
  }

  if (parent_email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(parent_email)) {
    errors.push({ field: 'parent_email', message: 'Guardian email must be a valid email address' });
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Validation error',
      errors,
    });
  }

  next();
};

export const validateStaff = (req, res, next) => {
  const { email, first_name, last_name, employee_number, campus_id, role } = req.body;
  const errors = [];

  if (!role) errors.push({ field: 'role', message: 'Role is required — choose what this person does' });

  // The email IS the staff member's login — they're issued a shared default
  // password and forced to change it, so no password is collected here.
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    errors.push({ field: 'email', message: 'Valid email is required — this is their login' });
  }

  if (!first_name || first_name.trim().length === 0) {
    errors.push({ field: 'first_name', message: 'First name is required' });
  }

  if (!last_name || last_name.trim().length === 0) {
    errors.push({ field: 'last_name', message: 'Last name is required' });
  }

  if (!employee_number || employee_number.trim().length === 0) {
    errors.push({ field: 'employee_number', message: 'Employee number is required' });
  }

  if (!campus_id || campus_id.trim().length === 0) {
    errors.push({ field: 'campus_id', message: 'Campus is required' });
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Validation error',
      errors,
    });
  }

  next();
};

export const validateClass = (req, res, next) => {
  const { campus_id, name, grade, academic_year } = req.body;
  const errors = [];

  if (!campus_id || campus_id.trim().length === 0) {
    errors.push({ field: 'campus_id', message: 'Campus is required' });
  }
  if (!name || name.trim().length === 0) {
    errors.push({ field: 'name', message: 'Class name is required' });
  }
  if (!grade || grade.trim().length === 0) {
    errors.push({ field: 'grade', message: 'Grade is required' });
  }
  if (!academic_year || academic_year.trim().length === 0) {
    errors.push({ field: 'academic_year', message: 'Academic year is required' });
  }

  if (errors.length > 0) {
    return res.status(400).json({ success: false, message: 'Validation error', errors });
  }
  next();
};

export const validateSubject = (req, res, next) => {
  const { name, code } = req.body;
  const errors = [];

  if (!name || name.trim().length === 0) {
    errors.push({ field: 'name', message: 'Subject name is required' });
  }
  if (!code || code.trim().length === 0) {
    errors.push({ field: 'code', message: 'Subject code is required' });
  }

  if (errors.length > 0) {
    return res.status(400).json({ success: false, message: 'Validation error', errors });
  }
  next();
};
