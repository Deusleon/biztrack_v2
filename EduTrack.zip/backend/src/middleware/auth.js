import jwt from 'jsonwebtoken';
import { literal } from 'sequelize';
import { checkSubscription } from './subscriptionGuard.js';
import { User } from '../models/index.js';

// While a person still has to choose their own password (first sign-in with the
// shared starting password), the ONLY things they may do are look at who they
// are and change it. Everything else is refused here — not just hidden in the
// screen — so the API can't be used to skip the step.
const ALLOWED_WHILE_PASSWORD_CHANGE_PENDING = [
  ['GET', '/api/v1/auth/me'],
  ['PUT', '/api/v1/auth/change-password'],
];
// Same fingerprint as utils/passwords.js passwordVersion(), computed in SQL so the
// hash itself never leaves the database.
const PASSWORD_VERSION_SQL = literal(`substr(encode(sha256(convert_to("User"."password", 'UTF8')), 'hex'), 1, 12)`);

export const authenticate = async (req, res, next) => {
  try {
    let token;

    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith('Bearer')
    ) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Not authorized to access this route',
      });
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findByPk(decoded.id, {
        attributes: { exclude: ['password'], include: [[PASSWORD_VERSION_SQL, 'pwv']] },
      });

      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'User not found',
        });
      }

      // A token carries the fingerprint of the password it was issued under; once
      // the password changes (or is reset) older tokens no longer match. Tokens
      // issued before this existed have no fingerprint and keep working until
      // they expire.
      const currentVersion = req.user.getDataValue('pwv');
      delete req.user.dataValues.pwv;
      if (decoded.pwv && decoded.pwv !== currentVersion) {
        return res.status(401).json({
          success: false,
          code: 'SESSION_EXPIRED',
          message: 'Your password was changed. Please sign in again.',
        });
      }

      if (req.user.status !== 'active') {
        return res.status(403).json({
          success: false,
          message: 'User account is not active',
        });
      }

      if (req.user.must_change_password) {
        const path = req.originalUrl.split('?')[0];
        const allowed = ALLOWED_WHILE_PASSWORD_CHANGE_PENDING.some(([m, p]) => m === req.method && p === path);
        if (!allowed) {
          return res.status(403).json({
            success: false,
            code: 'PASSWORD_CHANGE_REQUIRED',
            message: 'You must choose a new password before you can continue.',
          });
        }
      }

      next();
    } catch (error) {
      return res.status(401).json({
        success: false,
        message: 'Not authorized to access this route',
      });
    }
  } catch (error) {
    next(error);
  }
};

export const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Not authenticated',
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `User role '${req.user.role}' is not authorized to access this route`,
      });
    }

    next();
  };
};

export const checkTenant = async (req, res, next) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Not authenticated',
      });
    }

    // Ensure user has a tenant_id
    if (!req.user.tenant_id) {
      return res.status(403).json({
        success: false,
        message: 'User is not associated with any tenant',
      });
    }

    const tenantId = req.params.tenantId || req.body?.tenant_id || req.query?.tenant_id;

    if (tenantId && req.user.tenant_id !== tenantId && req.user.role !== 'super_admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to access this tenant',
      });
    }

    req.tenantId = req.user.tenant_id;

    // Subscription gating runs HERE rather than as an app-level middleware,
    // because it needs req.user and req.tenantId — mounted globally it
    // would run before authenticate and silently pass everything through.
    return checkSubscription(req, res, next);
  } catch (error) {
    next(error);
  }
};

