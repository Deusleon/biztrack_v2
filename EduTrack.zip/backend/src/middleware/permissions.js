import { perm } from './access.js';

/** Kept for older imports — identical to perm(). */
export const requirePermission = perm;
