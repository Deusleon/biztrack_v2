// FILE PATH: backend/src/middleware/access.js
/**
 * Who may use what — shared by every route file.
 *
 * The rule of thumb behind the groups below: a route is open to the roles whose
 * screens actually use it (the sidebar in the frontend is the reference), and
 * anything a student or parent may do for THEMSELVES is checked inside the
 * controller, because there the question is "is this their own record?" — which
 * a role list can't answer.
 *
 * What a person may DO is decided by permissions (perm() below — see
 * utils/permissionCatalog.js), not by role lists. The role groups here remain
 * for the few places that need to ask "is this a member of staff at all?".
 */
import { can } from '../utils/permissionEngine.js';

export const ADMINS = ['super_admin', 'admin'];
export const ADMIN_TIER = [...ADMINS, 'principal'];
/** Everyone who works at the school (not a student or parent). */
export const STAFF_ROLES = [...ADMIN_TIER, 'teacher', 'accountant', 'librarian', 'hr', 'transport_manager', 'hostel_warden'];
/** Who manages staff records and accounts. */
export const STAFF_MANAGERS = [...ADMIN_TIER, 'hr'];
/** Who sees the school's money: fees, expenses, financial reports. */
export const FINANCE_ROLES = [...ADMIN_TIER, 'accountant'];
/** Who runs payroll (the Payroll screen shows everyone else only their own payslips). */
export const PAYROLL_MANAGERS = ['super_admin', 'admin', 'accountant', 'hr'];
/** Who works with attendance and class registers. */
export const ACADEMIC_STAFF = [...ADMIN_TIER, 'teacher'];
export const SELF_SERVICE_ROLES = ['student', 'parent'];
export const ALL_ROLES = [...STAFF_ROLES, ...SELF_SERVICE_ROLES];

/**
 * Route guard: the person must hold this permission — through their role, or
 * granted to them personally. Admins and super admins always do. Administrators
 * change what each role holds in Settings → Permissions.
 */
export const perm = (permissionKey) => async (req, res, next) => {
  try {
    if (!req.user) return res.status(401).json({ success: false, message: 'Not authenticated' });
    if (await can(req.user, req.tenantId, permissionKey)) return next();
    return res.status(403).json({
      success: false,
      code: 'PERMISSION_REQUIRED',
      permission: permissionKey,
      message: `You don't have permission to do this (${permissionKey}). Ask an administrator to grant it.`,
    });
  } catch (error) { return next(error); }
};

export { can };

/** True when a student/parent request is for their own record — see the
 * controllers that call it. `student` is a Student row (with user_id / parent_id). */
export const isOwnStudentRecord = (user, student) =>
  Boolean(student) && (
    (user.role === 'student' && student.user_id === user.id)
    || (user.role === 'parent' && student.parent_id === user.id)
  );
