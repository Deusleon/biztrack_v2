// FILE PATH: backend/src/middleware/rateLimiter.js
import rateLimit from 'express-rate-limit';

// General API rate limiter — generous limit for authenticated app usage
export const apiLimiter = rateLimit({
  windowMs: (process.env.RATE_LIMIT_WINDOW || 15) * 60 * 1000, // 15 minutes
  max: process.env.RATE_LIMIT_MAX_REQUESTS || 2000, // 2000 requests per 15 min per IP
  message: {
    success: false,
    message: 'Too many requests from this IP, please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => {
    // Delivery reports come from the SMS provider's servers, often many at
    // once right after a broadcast, from one IP and with no login. Throttling
    // them would silently lose delivery results.
    if (req.originalUrl.startsWith('/api/v1/webhooks/dlr/')) return true;
    // Skip rate limiting for authenticated users making normal app requests
    return Boolean(req.headers.authorization);
  },
});

// Strict rate limiter for authentication endpoints
// The test suite signs in and fails to sign in dozens of times from one address;
// real limiting is switched off there (and only there).
const skipUnderTest = () => process.env.NODE_ENV === 'test' && process.env.TEST_RATE_LIMITS !== '1';

/**
 * The public "Scan to pay" page sends a mobile-money prompt to whatever number is typed in, with
 * no login. To stop it being used to spam a stranger's phone, each invoice allows only a few
 * attempts per 15 minutes, whoever is asking.
 */
export const payLinkLimiter = rateLimit({
  skip: () => process.env.NODE_ENV === 'test' && process.env.TEST_RATE_LIMITS !== '1',
  windowMs: 15 * 60 * 1000,
  max: 6,
  keyGenerator: (req) => `pay:${String(req.params.invoiceNumber || '').toUpperCase()}`,
  message: { success: false, message: 'Too many payment attempts for this invoice. Please wait 15 minutes and try again.' },
  standardHeaders: true,
  legacyHeaders: false,
});

export const authLimiter = rateLimit({
  skip: skipUnderTest,
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20, // 20 login attempts per 15 minutes per IP
  message: {
    success: false,
    message: 'Too many authentication attempts, please try again after 15 minutes.',
  },
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true, // Don't count successful requests
});

// Rate limiter for public, unauthenticated form submissions (website
// admission inquiries, contact forms). Generous enough for a genuine
// family submitting from a shared school/office network, tight enough
// to blunt a spam bot.
export const publicFormLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  message: {
    success: false,
    message: 'Too many submissions from this network. Please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});
export const modifyLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 50, // Limit each IP to 50 requests per window
  message: {
    success: false,
    message: 'Too many modification requests, please slow down.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// "Forgot password" answers 200 every time (so it can't reveal which accounts
// exist), which means authLimiter — which ignores successful requests — would
// never count it. This one counts every request: each can cost an SMS.
export const passwordResetLimiter = rateLimit({
  skip: skipUnderTest,
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: {
    success: false,
    message: 'Too many password reset attempts from this network. Please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});
