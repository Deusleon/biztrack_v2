import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

/**
 * Generic image upload handler. Files are saved to disk under
 * UPLOAD_PATH (defaults to ./uploads) and served statically at /uploads
 * (wired up in server.js). Kept intentionally simple — local disk
 * storage, no cloud bucket — swap the multer storage engine here later
 * if the deployment needs S3/GCS instead.
 */
const uploadRoot = process.env.UPLOAD_PATH || './uploads';

const ensureDir = (dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const subdir = req.uploadSubdir || 'misc';
    const dest = path.join(uploadRoot, subdir);
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const unique = crypto.randomBytes(8).toString('hex');
    cb(null, `${Date.now()}-${unique}${ext}`);
  },
});

const imageFileFilter = (req, file, cb) => {
  const allowed = ['.jpg', '.jpeg', '.png', '.webp'];
  const ext = path.extname(file.originalname).toLowerCase();
  if (!allowed.includes(ext)) return cb(new Error('Only JPG, PNG, and WEBP images are allowed'));
  cb(null, true);
};

export const uploadImage = multer({
  storage,
  fileFilter: imageFileFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
});

/** Broader filter for student documents (medical forms, certificates,
 * report cards, etc) — accepts PDFs and Word docs in addition to
 * images, since these are scanned/attached files, not just photos. */
const documentFileFilter = (req, file, cb) => {
  const allowed = ['.jpg', '.jpeg', '.png', '.webp', '.pdf', '.doc', '.docx'];
  const ext = path.extname(file.originalname).toLowerCase();
  if (!allowed.includes(ext)) return cb(new Error('Only JPG, PNG, WEBP, PDF, DOC, and DOCX files are allowed'));
  cb(null, true);
};

export const uploadDocument = multer({
  storage,
  fileFilter: documentFileFilter,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
});

/** Sets which subdirectory under UPLOAD_PATH this request's file goes
 * into — call as middleware before uploadImage.single(...), e.g.
 * router.post('/photo', setUploadSubdir('vehicles'), uploadImage.single('photo'), handler) */
export const setUploadSubdir = (subdir) => (req, res, next) => {
  req.uploadSubdir = subdir;
  next();
};

/** Builds the public URL for a file multer just saved.
 *
 * Prefers an explicit BACKEND_PUBLIC_URL env var when set — the robust
 * choice for real deployments, since req.protocol/req.get('host') can't
 * be trusted behind most reverse proxies (Render, Railway, nginx, etc.)
 * without `app.set('trust proxy', ...)`, which itself only fixes half
 * the problem. Falls back to the request-derived URL for local dev
 * where no such proxy sits in front of the server. */
export const publicUrlFor = (req, subdir, filename) => {
  const base = process.env.BACKEND_PUBLIC_URL?.replace(/\/$/, '') || `${req.protocol}://${req.get('host')}`;
  return `${base}/uploads/${subdir}/${filename}`;
};
