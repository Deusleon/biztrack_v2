import { DataTypes, Op } from 'sequelize';
import sequelize from '../config/database.js';
import { auditStore, newAuditStore } from '../utils/auditContext.js';
import {
  snapshotInstance, diffInstance, cleanObject, cleanValue, humanizeModel, recordName,
  describeChanges, describeRequest,
} from '../utils/auditDescribe.js';

const AuditLog = sequelize.define('AuditLog', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'tenants',
      key: 'id',
    },
  },
  user_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id',
    },
  },
  action: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  resource_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  resource_id: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  details: {
    type: DataTypes.JSONB,
    defaultValue: {},
  },
  ip_address: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  user_agent: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
}, {
  tableName: 'audit_logs',
  timestamps: true,
  updatedAt: false,
  indexes: [
    { fields: ['tenant_id'] },
    { fields: ['user_id'] },
    { fields: ['action'] },
    { fields: ['resource_type'] },
    { fields: ['created_at'] },
  ],
});

// ═══════════════════════════════════════════════════════════════════════════
// What gets recorded
//
// Every create / update / delete that a request causes is noticed by a
// database hook (below) and filed into that request's store; when the
// response goes out, the store becomes ONE audit entry holding a readable
// title and the exact before → after values. So the log says "Updated class
// "Form 1": capacity 40 → 45", not "PUT /5d3a…".
// ═══════════════════════════════════════════════════════════════════════════

// Never audited: the log itself (it would record itself forever) and
// notifications (system chatter, not something anyone did).
const SKIP_MODELS = new Set(['AuditLog', 'Notification']);
const MAX_CHANGES = 40;          // detailed changes kept per request
const PER_MODEL_DETAILED = 5;    // …and per model/operation — a 200-row import is "200 created", not 200 entries

const note = (change) => {
  const store = auditStore.getStore();
  if (!store) return; // not inside a request (seed, script, job) — nothing to attach it to
  const same = store.changes.filter((c) => c.model === change.model && c.op === change.op).length;
  if (same >= PER_MODEL_DETAILED || store.changes.length >= MAX_CHANGES) {
    const key = `${change.model}:${change.op}`;
    store.overflow[key] = (store.overflow[key] || 0) + 1;
    return;
  }
  store.changes.push(change);
};

/** A Sequelize `where` (which can hold Symbol operators) → plain, short, safe JSON. */
const serializeWhere = (value, depth = 0) => {
  if (depth > 4) return '[…]';
  if (Array.isArray(value)) {
    const items = value.slice(0, 10).map((v) => serializeWhere(v, depth + 1));
    return value.length > 10 ? [...items, `… and ${value.length - 10} more`] : items;
  }
  if (value && typeof value === 'object' && !(value instanceof Date)) {
    const out = {};
    for (const key of Reflect.ownKeys(value)) {
      out[typeof key === 'symbol' ? String(key.description) : key] = serializeWhere(value[key], depth + 1);
    }
    return out;
  }
  return cleanValue('', value);
};

const modelName = (x) => (typeof x === 'function' ? x.name : x?.constructor?.name);

const describeCreated = (instance) => {
  const name = modelName(instance);
  if (SKIP_MODELS.has(name)) return;
  note({
    op: 'create', model: name, label: humanizeModel(name), id: instance.get('id') || null,
    name: recordName(instance.dataValues), data: snapshotInstance(instance),
  });
};

export const registerAuditHooks = (db) => {
  db.addHook('afterCreate', (instance) => { describeCreated(instance); });

  db.addHook('afterBulkCreate', (instances) => { (instances || []).forEach(describeCreated); });

  db.addHook('afterUpdate', (instance) => {
    const name = modelName(instance);
    if (SKIP_MODELS.has(name)) return;
    const fields = diffInstance(instance);
    if (fields.length === 0) return;
    note({
      op: 'update', model: name, label: humanizeModel(name), id: instance.get('id') || null,
      name: recordName(instance.dataValues), fields,
    });
  });

  db.addHook('afterDestroy', (instance) => {
    const name = modelName(instance);
    if (SKIP_MODELS.has(name)) return;
    note({
      op: 'delete', model: name, label: humanizeModel(name), id: instance.get('id') || null,
      name: recordName(instance.dataValues), data: snapshotInstance(instance),
    });
  });

  // Model.update(values, { where }) / Model.destroy({ where }) never load the
  // rows, so there are no "before" values to report — what was changed and
  // where it was applied is the most that can be said.
  db.addHook('afterBulkUpdate', (options) => {
    const name = modelName(options?.model);
    if (!name || SKIP_MODELS.has(name)) return;
    const ids = options.where?.id?.[Op.in];
    note({
      op: 'bulk_update', model: name, label: humanizeModel(name), count: Array.isArray(ids) ? ids.length : null,
      set: cleanObject(options.attributes || {}), where: serializeWhere(options.where || {}),
    });
  });

  db.addHook('afterBulkDestroy', (options) => {
    const name = modelName(options?.model);
    if (!name || SKIP_MODELS.has(name)) return;
    const ids = options.where?.id?.[Op.in];
    note({ op: 'bulk_delete', model: name, label: humanizeModel(name), count: Array.isArray(ids) ? ids.length : null, where: serializeWhere(options.where || {}) });
  });
};

registerAuditHooks(sequelize);

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const writeAuditEntry = (req, data, store) => {
  try {
    const resource = (req.baseUrl || '').split('/').pop();
    const path = String(req.originalUrl || req.path || '').split('?')[0];
    const isSignIn = /\/login$/.test(path);
    const isSignOut = /\/logout$/.test(path);
    const isReset = /\/reset-password$/.test(path);

    // "Forgot password" is public and answers before it does its work, so there is
    // nothing true to record — and it may name an account that doesn't exist.
    if (/\/forgot-password$/.test(path)) return;

    // Signing in updates the user's last-login columns; that is not what
    // anybody wants to read as "Updated user".
    const changes = (isSignIn || isSignOut) ? [] : store.changes;
    const overflow = (isSignIn || isSignOut) ? {} : store.overflow;

    const fromRequest = describeRequest({ method: req.method, resource, path, body: req.body });
    const fromChanges = fromRequest.kind === 'auth' ? null : describeChanges(changes, overflow, resource);
    const summary = fromChanges || { ...fromRequest, record: null, changed_fields: [] };

    const primaryId = summary.record?.id;
    const resourceId = [primaryId, req.params?.id, data?.data?.id].find((v) => typeof v === 'string' && UUID.test(v)) || null;

    const details = {
      version: 2,
      kind: summary.kind,
      title: summary.title,
      record: summary.record,
      changed_fields: summary.changed_fields,
      changes,
      overflow: Object.entries(overflow).map(([key, count]) => {
        const [model, op] = key.split(':');
        return { model, label: humanizeModel(model), op, count };
      }),
      method: req.method,
      path,
      request: {
        method: req.method,
        path,
        query: cleanObject(req.query || {}),
        // The submitted form is only kept when no record change explains the
        // request — otherwise it just repeats the before/after.
        ...(changes.length === 0 ? { body: cleanObject(req.body || {}) } : {}),
      },
    };

    const entry = {
      tenant_id: req.user?.tenant_id || (isSignIn ? data?.data?.tenant_id : null) || null,
      user_id: req.user?.id || (isSignIn ? data?.data?.id : null) || null,
      action: String(summary.title).slice(0, 255),
      resource_type: resource,
      resource_id: resourceId,
      details,
      ip_address: req.ip || req.connection?.remoteAddress,
      user_agent: req.get('user-agent'),
    };

    // A password reset is done without being signed in, so the account it belongs
    // to is read from the change itself — that is what makes it appear in that
    // school's activity history.
    const resetUserId = isReset ? changes.find((c) => c.model === 'User' && c.op === 'update')?.id : null;
    const write = resetUserId
      ? sequelize.models.User.findByPk(resetUserId, { attributes: ['id', 'tenant_id'] })
        .then((u) => AuditLog.create({ ...entry, tenant_id: u?.tenant_id || null, user_id: u?.id || null }))
      : AuditLog.create(entry);
    write.catch((err) => console.error('Audit log error:', err));
  } catch (err) {
    // Auditing must never be the reason a request fails.
    console.error('Audit log error:', err);
  }
};

/**
 * Records a sign-in event that did NOT succeed — a wrong password, a lockout, a
 * refused account — so an administrator can see someone trying to get in. (The
 * automatic audit only records requests that succeed, so these would otherwise
 * leave no trace.) It needs to know whose account it was: an attempt on an email
 * that doesn't exist can't be attributed to any school, so it isn't recorded.
 * The password that was tried is never kept.
 */
export const logAuthEvent = ({ req, user, title, reason, outcome = 'failed' }) => {
  if (!user?.tenant_id) return Promise.resolve();
  const path = String(req.originalUrl || req.path || '').split('?')[0];
  return AuditLog.create({
    tenant_id: user.tenant_id,
    user_id: user.id,
    action: String(title).slice(0, 255),
    resource_type: 'auth',
    resource_id: null,
    details: {
      version: 2, kind: 'auth', outcome, title, reason: reason || null,
      record: null, changed_fields: [], changes: [], overflow: [],
      method: req.method, path, request: { method: req.method, path, query: {} },
    },
    ip_address: req.ip || req.connection?.remoteAddress,
    user_agent: req.get('user-agent'),
  }).catch((err) => console.error('Audit log error:', err));
};

/**
 * Records something the SYSTEM did, or that happened outside an ordinary request — a payment
 * confirmed by the gateway's webhook, a subscription locking at midnight, a reminder going
 * out. The automatic audit only sees changes made inside a signed-in request, so these
 * would otherwise leave no trace. Shown in Settings → Audit Log under "Other actions".
 *
 *   userId   who did it, or null when nobody did (the webhook, the daily job)
 */
export const logSystemEvent = ({ tenantId, userId = null, title, resourceType = 'subscription', resourceId = null, reason = null, record = null, extra = {} }) => {
  if (!tenantId) return Promise.resolve();
  return AuditLog.create({
    tenant_id: tenantId,
    user_id: userId,
    action: String(title).slice(0, 255),
    resource_type: resourceType,
    resource_id: resourceId && UUID.test(resourceId) ? resourceId : null,
    details: {
      version: 2, kind: 'action', system: !userId, title, reason, record,
      changed_fields: [], changes: [], overflow: [], method: 'SYSTEM', path: null, request: { method: 'SYSTEM', path: null, query: {} },
      ...extra,
    },
    ip_address: null,
    user_agent: null,
  }).catch((err) => console.error('Audit log error:', err));
};

export const auditLog = (req, res, next) => {
  const store = newAuditStore();
  const originalJson = res.json;

  res.json = function auditedJson(data) {
    // Only log successful state-changing operations
    if (data?.success !== false && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
      writeAuditEntry(req, data, store);
    }
    return originalJson.call(this, data);
  };

  // Everything this request goes on to do runs inside the store, which is
  // how the database hooks know which request a change belongs to.
  auditStore.run(store, () => next());
};

export default AuditLog;
