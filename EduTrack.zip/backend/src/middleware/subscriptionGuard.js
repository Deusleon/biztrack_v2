import { Subscription } from '../models/index.js';
import { evaluateSubscription } from '../controllers/subscriptionController.js';
import { bypassesSubscription } from '../utils/developerAccess.js';

/**
 * Blocks a tenant whose subscription has lapsed past its grace period.
 *
 * Two things this deliberately does NOT block:
 *
 *   1. Reading the subscription and paying for it. Locking a school out of
 *      the page they need in order to pay would make the lock permanent.
 *   2. Logging in and logging out. A locked school still needs to get in
 *      far enough to see WHY it is locked.
 *
 * Writes are blocked before reads are, so a school in the last hours of
 * grace is warned rather than surprised. Once past grace, everything
 * outside the allow-list returns 402 Payment Required.
 *
 * The PLATFORM DEVELOPER is never locked out — otherwise a billing bug would be
 * unfixable. That means someone whose email is listed in DEVELOPER_EMAILS and who
 * holds the super_admin role. A super_admin account that belongs to a school (for
 * example the one created by the seed) is a school user like any other: when the
 * subscription lapses, it is locked too.
 */


/** Paths that must keep working even when locked. Matched as prefixes
 * against the mounted path (req.baseUrl + req.path). */
const ALWAYS_ALLOWED = [
  '/api/v1/auth',
  '/api/v1/subscription',
  '/api/v1/webhooks',
  '/api/v1/notifications',
];

const isAllowedPath = (fullPath) => ALWAYS_ALLOWED.some((prefix) => fullPath.startsWith(prefix));

export const checkSubscription = async (req, res, next) => {
  try {
    // No tenant context (unauthenticated or platform-level) — nothing to check.
    if (!req.tenantId || !req.user) return next();
    if (bypassesSubscription(req.user)) return next();

    const fullPath = `${req.baseUrl || ''}${req.path || ''}`;
    if (isAllowedPath(fullPath)) return next();

    const subscription = await Subscription.findOne({ where: { tenant_id: req.tenantId } });

    // A tenant with no subscription row yet is mid-onboarding, not
    // delinquent. It gets created on first visit to the subscription page.
    if (!subscription) return next();

    const evaluation = evaluateSubscription(subscription);

    if (evaluation.locked) {
      return res.status(402).json({
        success: false,
        code: 'SUBSCRIPTION_EXPIRED',
        message: evaluation.status === 'cancelled'
          ? 'This subscription has been cancelled. Renew it to continue using EduTrack.'
          : 'Your EduTrack subscription has expired and the grace period has passed. Renew it to restore access.',
        data: { evaluation },
      });
    }

    // Still working, but on borrowed time — surfaced as a header so the
    // frontend can warn on every page without a separate request.
    if (evaluation.inGrace) {
      res.set('X-Subscription-Grace', String(evaluation.graceHoursLeft ?? 0));
    }

    req.subscription = subscription;
    req.subscriptionEvaluation = evaluation;
    return next();
  } catch (error) {
    // A failure to READ the subscription must not lock a paying school
    // out. Failing open is the lesser harm: the worst case is a lapsed
    // school gets a few more minutes, versus a paid one losing a day.
    console.error('[subscription] check failed, allowing request:', error.message);
    return next();
  }
};

/**
 * Blocks admitting students beyond the plan's limit.
 *
 * Applied on student creation only. A school that outgrows its plan keeps
 * full access to the students it already has — cutting off a school
 * mid-year because it enrolled one student too many would punish the
 * children, not the customer.
 */
export const checkStudentLimit = async (req, res, next) => {
  try {
    if (!req.tenantId || !req.user) return next();
    if (bypassesSubscription(req.user)) return next();

    const { SubscriptionPlan, Student } = await import('../models/index.js');
    const subscription = await Subscription.findOne({ where: { tenant_id: req.tenantId } });
    if (!subscription?.plan_id) return next();

    const plan = await SubscriptionPlan.findByPk(subscription.plan_id);
    if (!plan || plan.student_limit === null) return next();

    const count = await Student.count({ where: { tenant_id: req.tenantId, status: 'active' } });
    if (count >= plan.student_limit) {
      return res.status(402).json({
        success: false,
        code: 'STUDENT_LIMIT_REACHED',
        message: `The ${plan.name} plan allows ${plan.student_limit} active students and you have ${count}. Upgrade your plan to admit more.`,
      });
    }

    return next();
  } catch (error) {
    console.error('[subscription] student limit check failed, allowing request:', error.message);
    return next();
  }
};
