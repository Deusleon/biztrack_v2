import express from 'express';
import { staffController } from '../controllers/staffController.js';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { validateStaff } from '../middleware/validator.js';
import { uploadDocument, uploadImage, setUploadSubdir } from '../middleware/upload.js';

const router = express.Router();

// All routes require authentication
router.use(authenticate);
router.use(checkTenant);

// Staff records hold salaries, national ID and bank details. Anyone who works at
// the school can look people up (pick-lists need it) but the sensitive columns
// are removed for everyone except staff managers and the person themself — see
// staffController.redactStaff. Students and parents have no access at all.
// Changing staff is for administrators, the principal and HR; hard delete is
// super admin only.


// Get all staff with filters and pagination
router.get('/', perm('staff.view'), staffController.getAll);

// Get staff statistics
router.get('/:id/stats', perm('staff.view_sensitive'), staffController.getStats);

// Get single staff member
router.get('/:id', perm('staff.view'), staffController.getById);

// Create new staff member (admin only)
router.post('/', perm('staff.create'), validateStaff, staffController.create);

// Update staff member
router.put('/:id', perm('staff.update'), staffController.update);

// Profile picture
router.post('/:id/photo', perm('staff.update'), setUploadSubdir('avatars'), uploadImage.single('photo'), staffController.uploadPhoto);

// Employment documents — ID copy, appointment letter, certificates
router.post('/:id/documents', perm('staff.update'), setUploadSubdir('staff-documents'), uploadDocument.single('document'), staffController.uploadDocument);
router.delete('/:id/documents/:documentId', perm('staff.delete'), staffController.deleteDocument);

// Soft delete staff member
router.delete('/:id', perm('staff.delete'), staffController.delete);

// Hard delete staff member (super admin only)
router.delete('/:id/permanent', perm('staff.delete'), staffController.permanentDelete);

// Reactivate staff member
router.patch('/:id/reactivate', perm('staff.update'), staffController.reactivate);

// Excel import: preview first (saves nothing), then import
router.post('/bulk/preview', perm('staff.create'), staffController.bulkPreview);
router.post('/bulk', perm('staff.create'), staffController.bulkCreate);

// Bulk update status
router.patch('/bulk/status', perm('staff.update'), staffController.bulkUpdateStatus);

export default router;
