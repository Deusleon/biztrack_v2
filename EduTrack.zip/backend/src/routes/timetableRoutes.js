import { Router } from 'express';
import { body, query } from 'express-validator';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { validate } from '../middleware/validator.js';
import {
  getSettings, updateSettings,
  getClassSubjects, saveClassSubjects,
  getClassTimetable, getTeacherTimetable, getMasterTimetable,
  upsertEntry, autoFill, clearClassTimetable,
} from '../controllers/timetableController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

const STAFF_ROLES = ['super_admin', 'admin', 'principal', 'teacher'];
const MANAGE_ROLES = ['super_admin', 'admin', 'principal'];
const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
const LEVELS = ['primary', 'o_level', 'a_level'];

// ── Settings (the school week) ──────────────────────────────────────────
router.get('/settings', perm('timetable.view'), [query('campus_id').notEmpty().withMessage('campus_id is required')],
  validate,
  getSettings,
);

router.put('/settings', perm('timetable.update'), [
    body('campus_id').notEmpty().withMessage('campus_id is required'),
    body('education_level').optional().isIn(LEVELS).withMessage('Invalid education level'),
    body('start_time').optional().matches(/^([01]\d|2[0-3]):[0-5]\d$/).withMessage('start_time must be HH:MM'),
    body('period_duration').optional().isInt({ min: 10, max: 180 }).withMessage('period_duration must be 10-180 minutes'),
    body('periods_per_day').optional().isInt({ min: 1, max: 15 }).withMessage('periods_per_day must be 1-15'),
    body('friday_periods').optional().isInt({ min: 0, max: 15 }).withMessage('friday_periods must be 0-15'),
    body('break_after_period').optional({ nullable: true }).isInt({ min: 1, max: 15 }),
    body('break_duration').optional().isInt({ min: 0, max: 120 }),
    body('lunch_after_period').optional({ nullable: true }).isInt({ min: 1, max: 15 }),
    body('lunch_duration').optional().isInt({ min: 0, max: 120 }),
    body('daily_activities').optional().isObject().withMessage('daily_activities must be an object'),
  ],
  validate,
  updateSettings,
);

// ── Class subjects (what each class studies, and how often) ────────────
router.get('/class-subjects', perm('timetable.view'), [
    query('class_id').notEmpty().withMessage('class_id is required'),
    query('academic_year').notEmpty().withMessage('academic_year is required'),
  ],
  validate,
  getClassSubjects,
);

router.put('/class-subjects', perm('timetable.update'), [
    body('class_id').notEmpty().withMessage('class_id is required'),
    body('academic_year').notEmpty().withMessage('academic_year is required'),
    body('subjects').isArray().withMessage('subjects must be an array'),
    body('subjects.*.subject_id').notEmpty().withMessage('Each subject needs a subject_id'),
    body('subjects.*.periods_per_week').isInt({ min: 1, max: 40 }).withMessage('periods_per_week must be 1-40'),
  ],
  validate,
  saveClassSubjects,
);

// ── Viewing — every authenticated role can view (students/parents
// included); `authenticate` above already requires a valid login. ──────
router.get('/class', [
    query('class_id').notEmpty().withMessage('class_id is required'),
    query('section_id').notEmpty().withMessage('section_id is required'),
    query('academic_year').notEmpty().withMessage('academic_year is required'),
  ],
  validate,
  getClassTimetable,
);

router.get('/teacher', [
    query('teacher_id').notEmpty().withMessage('teacher_id is required'),
    query('academic_year').notEmpty().withMessage('academic_year is required'),
  ],
  validate,
  getTeacherTimetable,
);

router.get('/master', [
    query('campus_id').notEmpty().withMessage('campus_id is required'),
    query('academic_year').notEmpty().withMessage('academic_year is required'),
    query('education_level').optional().isIn(LEVELS),
  ],
  validate,
  getMasterTimetable,
);

// ── Editing ──────────────────────────────────────────────────────────────
router.put('/entry', perm('timetable.entry'), [
    body('class_id').notEmpty().withMessage('class_id is required'),
    body('section_id').notEmpty().withMessage('section_id is required'),
    body('academic_year').notEmpty().withMessage('academic_year is required'),
    body('day').isIn(DAYS).withMessage('Invalid day'),
    body('period_number').isInt({ min: 1, max: 15 }).withMessage('Invalid period_number'),
    body('subject_id').optional({ nullable: true }).isString(),
    body('teacher_id').optional({ nullable: true }).isString(),
  ],
  validate,
  upsertEntry,
);

router.post('/auto-fill', perm('timetable.update'), [
    body('class_id').notEmpty().withMessage('class_id is required'),
    body('section_id').notEmpty().withMessage('section_id is required'),
    body('academic_year').notEmpty().withMessage('academic_year is required'),
    body('regenerate').optional().isBoolean().withMessage('regenerate must be true or false'),
  ],
  validate,
  autoFill,
);

router.delete('/class', perm('timetable.update'), [
    query('class_id').notEmpty().withMessage('class_id is required'),
    query('section_id').notEmpty().withMessage('section_id is required'),
    query('academic_year').notEmpty().withMessage('academic_year is required'),
  ],
  validate,
  clearClassTimetable,
);

export default router;
