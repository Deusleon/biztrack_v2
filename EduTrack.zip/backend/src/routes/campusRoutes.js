import express from 'express';
import { campusController } from '../controllers/campusController.js';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { validateCampus } from '../middleware/validator.js';
import { uploadImage, setUploadSubdir } from '../middleware/upload.js';

const router = express.Router();

// All routes require authentication
router.use(authenticate);
router.use(checkTenant);

// Campus names are needed by every signed-in user (the campus selector), so
// the list and a single campus stay open. Enrolment statistics are staff-only,
// and changing campuses is for administrators.


// Get all campuses with filters and pagination
router.get('/', campusController.getAll);

// Get campus statistics
// Must precede /:id — otherwise "stats" is treated as a campus id.
router.get('/stats/summary', perm('campus.view'), campusController.getSummary);
router.get('/:id/stats', perm('campus.view'), campusController.getStats);

// Get single campus
router.get('/:id', campusController.getById);

// Create new campus (admin only)
router.post('/', perm('campus.create'), validateCampus, campusController.create);

// Update campus (admin only)
router.put('/:id', perm('campus.update'), validateCampus, campusController.update);

// School logo — used as the letterhead on receipts and report cards
router.post('/:id/logo', perm('campus.create'), setUploadSubdir('campus-logos'), uploadImage.single('logo'), campusController.uploadLogo);
router.delete('/:id/logo', perm('campus.delete'), campusController.deleteLogo);

// Soft delete campus (admin only)
router.delete('/:id', perm('campus.delete'), campusController.delete);

// Hard delete campus (super admin only)
router.delete('/:id/permanent', perm('campus.delete'), campusController.permanentDelete);

// Reactivate campus (admin only)
router.patch('/:id/reactivate', perm('campus.update'), campusController.reactivate);

// Bulk update status (admin only)
router.patch('/bulk/status', perm('campus.update'), campusController.bulkUpdateStatus);

export default router;
