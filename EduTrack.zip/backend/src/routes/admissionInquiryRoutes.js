// FILE PATH: backend/src/routes/admissionInquiryRoutes.js
import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { listInquiries, getInquiryCounts, updateInquiryStatus } from '../controllers/admissionInquiryController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

router.get('/', perm('inquiries.view'), listInquiries);
router.get('/counts', perm('inquiries.view'), getInquiryCounts);
router.patch('/:id', perm('inquiries.update'), updateInquiryStatus);

export default router;