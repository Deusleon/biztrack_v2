import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { uploadImage, setUploadSubdir } from '../middleware/upload.js';
import {
  getCategories, createCategory, updateCategory, deleteCategory,
  getExpenses, getExpenseById, createExpense, updateExpense, voidExpense, uploadReceipt,
  getSummary,
} from '../controllers/expenseController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

// Categories — GET open to anyone who can see the ledger; write ops
// gated by expenses.* permissions (see Settings → Permissions)
router.get('/categories', perm('expenses.view'), getCategories);
router.post('/categories', perm('expenses.create'), createCategory);
router.put('/categories/:id', perm('expenses.update'), updateCategory);
router.delete('/categories/:id', perm('expenses.delete'), deleteCategory);

// Expenses
router.get('/', perm('expenses.view'), getExpenses);
router.get('/summary', perm('expenses.view'), getSummary);
router.get('/:id', perm('expenses.view'), getExpenseById);
router.post('/', perm('expenses.create'), createExpense);
router.put('/:id', perm('expenses.update'), updateExpense);
router.delete('/:id', perm('expenses.delete'), voidExpense);
router.post('/:id/receipt', perm('expenses.update'), setUploadSubdir('expenses'), uploadImage.single('receipt'), uploadReceipt);

export default router;
