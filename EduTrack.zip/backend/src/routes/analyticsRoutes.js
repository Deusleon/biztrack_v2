import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { getDashboard, getHighlights } from '../controllers/analyticsController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

router.get('/dashboard', perm('analytics.view'), getDashboard);
router.get('/highlights', perm('analytics.view'), getHighlights);

export default router;
