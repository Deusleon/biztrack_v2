import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getPeriods, getPeriodById, createPeriod, deletePeriod,
  generateItems, processPeriod, markPaid,
  updateItem, deleteItem, getItemById, getMyPayslips,
} from '../controllers/payrollController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

// Periods — viewable/manageable restricted inside controllers (Accountant/Admin)
router.get('/periods', perm('payroll.view'), getPeriods);
router.get('/periods/:id', perm('payroll.view'), getPeriodById);
router.post('/periods', perm('payroll.create'), createPeriod);
router.delete('/periods/:id', perm('payroll.delete'), deletePeriod);
router.post('/periods/:id/generate', perm('payroll.create'), generateItems);
router.put('/periods/:id/process', perm('payroll.update'), processPeriod);
router.put('/periods/:id/pay', perm('payroll.update'), markPaid);

// Payslip items
router.put('/items/:id', perm('payroll.update'), updateItem);
router.delete('/items/:id', perm('payroll.delete'), deleteItem);
router.get('/items/:id', getItemById);

// Self-service
router.get('/my-payslips', getMyPayslips);

export default router;
