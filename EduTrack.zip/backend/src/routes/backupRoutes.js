import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import {
  requireDeveloper, getOverview, updateSettings, runNow, verifyOne, downloadOne, removeOne, retryDriveUpload,
  saveDriveCredentials, driveAuthUrl, driveTest, driveDisconnect,
} from '../controllers/backupController.js';

// Full-database backups hold every school's data: platform developer only (see backupController.js).
const router = Router();
router.use(authenticate);
router.use(checkTenant);
router.use(requireDeveloper);

router.get('/', getOverview);
router.put('/settings', updateSettings);
router.post('/run', runNow);
router.post('/:id/verify', verifyOne);
router.get('/:id/download', downloadOne);
router.post('/:id/drive', retryDriveUpload);
router.delete('/:id', removeOne);

router.put('/drive/credentials', saveDriveCredentials);
router.get('/drive/auth-url', driveAuthUrl);
router.post('/drive/test', driveTest);
router.post('/drive/disconnect', driveDisconnect);

export default router;
