// backend/src/routes/libraryRoutes.js
import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getBooks, getBookById, createBook, updateBook, deleteBook, getAvailableCopies,
  getIssues, getMyBooks, issueBook, returnBook, markLost, settleFine,
  getSettings, updateSettings,
} from '../controllers/libraryController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

// Books — viewable by any logged-in user (browse the catalog); managing
// is restricted inside the controllers (admin/principal/librarian).
router.get('/books', getBooks);
router.get('/books/:id', getBookById);
router.get('/books/:id/available-copies', getAvailableCopies);
router.post('/books', perm('library.create'), createBook);
router.put('/books/:id', perm('library.update'), updateBook);
router.delete('/books/:id', perm('library.delete'), deleteBook);

// Issue / return
router.get('/issues', perm('library.view'), getIssues);
router.get('/my-books', getMyBooks);
router.post('/issue', perm('library.update'), issueBook);
router.put('/issue/:id/return', perm('library.update'), returnBook);
router.put('/issue/:id/lost', perm('library.update'), markLost);
router.put('/issue/:id/fine', perm('library.update'), settleFine);

// Lending rules: loan period, overdue rate, fine cap
router.get('/settings', getSettings);
router.put('/settings', perm('library.update'), updateSettings);

export default router;