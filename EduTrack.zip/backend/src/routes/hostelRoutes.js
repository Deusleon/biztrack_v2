import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getHostels, getHostelById, createHostel, updateHostel, deleteHostel,
  getRooms, createRoom, updateRoom, deleteRoom,
  getRoomStudents, getStudentAllocation, assignStudent, vacateStudent,
} from '../controllers/hostelController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

// Hostels — viewable by any logged-in user; managing restricted inside controllers
router.get('/hostels', getHostels);
router.get('/hostels/:id', getHostelById);
router.post('/hostels', perm('hostel.create'), createHostel);
router.put('/hostels/:id', perm('hostel.update'), updateHostel);
router.delete('/hostels/:id', perm('hostel.delete'), deleteHostel);

// Rooms
router.get('/rooms', getRooms);
router.post('/rooms', perm('hostel.create'), createRoom);
router.put('/rooms/:id', perm('hostel.update'), updateRoom);
router.delete('/rooms/:id', perm('hostel.delete'), deleteRoom);
router.get('/rooms/:id/students', perm('hostel.view'), getRoomStudents);

// Student allocations
router.get('/student/:studentId', getStudentAllocation);
router.post('/allocations', perm('hostel.create'), assignStudent);
router.put('/allocations/:id/vacate', perm('hostel.update'), vacateStudent);

export default router;
