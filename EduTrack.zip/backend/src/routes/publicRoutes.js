// FILE PATH: backend/src/routes/publicRoutes.js
// Mounted in server.js at /api/v1/public — none of these require a JWT.
// Each route takes :tenantSlug so a request can be scoped to the right
// school without authentication. Keep every handler here read-only or
// narrowly-scoped like admission inquiries — never expose anything that
// needs real authorization through this file.
import { Router } from 'express';
import { publicFormLimiter, payLinkLimiter } from '../middleware/rateLimiter.js';
import { getPublicPayInvoice, startPublicPayment, getPublicPayStatus } from '../controllers/subscriptionController.js';
import { submitPublicInquiry } from '../controllers/admissionInquiryController.js';
import { submitPublicContact } from '../controllers/contactInquiryController.js';
import { getPublicFeeStructure } from '../controllers/feeController.js';
import { getPublicClasses } from '../controllers/classController.js';
import { getPublicWebsiteContent } from '../controllers/settingsController.js';

const router = Router();

router.post('/:tenantSlug/admission-inquiry', publicFormLimiter, submitPublicInquiry);
router.post('/:tenantSlug/contact', publicFormLimiter, submitPublicContact);
router.get('/:tenantSlug/fee-structure', getPublicFeeStructure);
router.get('/:tenantSlug/classes', getPublicClasses);
router.get('/:tenantSlug/website-content', getPublicWebsiteContent);

// "Scan to pay" on a subscription invoice. No login: the signed code in the link is the proof.
router.get('/subscription-pay/:invoiceNumber/:code', getPublicPayInvoice);
router.get('/subscription-pay/:invoiceNumber/:code/status', getPublicPayStatus);
router.post('/subscription-pay/:invoiceNumber/:code', payLinkLimiter, startPublicPayment);

export default router;