import { Router } from 'express';
import { classController } from '../controllers/classController.js';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { validateClass } from '../middleware/validator.js';

const router = Router();

router.use(authenticate);
router.use(checkTenant);

// Class and subject NAMES are read by every signed-in user (exam filters, the
// timetable), so lists and single records stay open. Statistics are staff-only,
// and creating / changing / removing is for the admin tier (or a granted
// academics.* permission). Hard delete is super admin only.


router.get('/', classController.getAll);
router.post('/clone-year', perm('academics.create'), classController.cloneClassesForNewYear);
router.get('/:id/stats', perm('academics.view'), classController.getStats);
router.get('/:id', classController.getById);
router.post('/', perm('academics.create'), validateClass, classController.create);
router.put('/:id', perm('academics.update'), classController.update);
router.delete('/:id/permanent', perm('academics.delete'), classController.permanentDelete);
router.delete('/:id', perm('academics.delete'), classController.delete);
router.patch('/:id/reactivate', perm('academics.update'), classController.reactivate);
router.patch('/bulk/status', perm('academics.update'), classController.bulkUpdateStatus);

// Section sub-routes
router.post('/:id/sections', perm('academics.create'), classController.addSection);
router.put('/:id/sections/:sectionId', perm('academics.update'), classController.updateSection);
router.delete('/:id/sections/:sectionId', perm('academics.delete'), classController.deleteSection);

export default router;
