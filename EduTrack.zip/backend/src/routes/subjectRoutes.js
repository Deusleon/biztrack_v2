import { Router } from 'express';
import { subjectController } from '../controllers/subjectController.js';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { validateSubject } from '../middleware/validator.js';

const router = Router();

router.use(authenticate);
router.use(checkTenant);

// Class and subject NAMES are read by every signed-in user (exam filters, the
// timetable), so lists and single records stay open. Statistics are staff-only,
// and creating / changing / removing is for the admin tier (or a granted
// academics.* permission). Hard delete is super admin only.


router.get('/', subjectController.getAll);
router.get('/:id/stats', perm('academics.view'), subjectController.getStats);
router.get('/:id', subjectController.getById);
router.post('/', perm('academics.create'), validateSubject, subjectController.create);
router.put('/:id', perm('academics.update'), subjectController.update);
router.delete('/:id/permanent', perm('academics.delete'), subjectController.permanentDelete);
router.delete('/:id', perm('academics.delete'), subjectController.delete);
router.patch('/:id/reactivate', perm('academics.update'), subjectController.reactivate);
router.patch('/bulk/status', perm('academics.update'), subjectController.bulkUpdateStatus);

export default router;
