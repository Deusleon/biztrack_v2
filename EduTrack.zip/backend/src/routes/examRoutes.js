import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getExams, getExamById, createExam, updateExam, deleteExam,
  getMarksSheet, saveMarks, getClassResults, getReportCard, getMyExams, getTermSummary,
} from '../controllers/examController.js';

const router = Router();

router.use(authenticate);
router.use(checkTenant);

const STAFF_ROLES = ['super_admin', 'admin', 'principal', 'teacher'];
const ADMIN_ROLES = ['super_admin', 'admin', 'principal'];

// Exams (CRUD) — teachers can view, only admin/principal manage
router.get('/', getExams);
router.get('/my-results', getMyExams); // student's own record — must be before /:id
router.get('/term-summary', perm('exams.marks'), getTermSummary); // must be before /:id
router.get('/:id', getExamById);
router.post('/', perm('exams.create'), createExam);
router.put('/:id', perm('exams.update'), updateExam);
router.delete('/:id', perm('exams.delete'), deleteExam);

// Marks entry — teachers and admins
router.get('/:id/marks-sheet', perm('exams.marks'), getMarksSheet);
router.post('/:id/marks', perm('exams.marks'), saveMarks);

// Results — staff can view any class; students/parents restricted to their own via the frontend using report-card with their own student id
router.get('/:id/class-results', perm('exams.marks'), getClassResults);
router.get('/:id/report-card/:studentId', getReportCard);

export default router;
