import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { globalSearch } from '../controllers/searchController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

router.get('/', globalSearch);

export default router;
