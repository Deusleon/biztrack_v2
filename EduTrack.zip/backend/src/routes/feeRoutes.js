import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getFeeStructures, createFeeStructure, updateFeeStructure, deleteFeeStructure,
  getFeeStructureStudents, setFeeStructureStudents,
  getPayments, createPayment, getPaymentById, deletePayment,
  getStudentFeeSummary, getClassFeeStatus, getMyChildrenFees,
} from '../controllers/feeController.js';

const router = Router();

router.use(authenticate);
router.use(checkTenant);

const FINANCE_ROLES = ['super_admin', 'admin', 'principal', 'accountant'];

// Fee Structures (CRUD)
router.get('/structures', perm('fees.view'), getFeeStructures);
router.post('/structures', perm('fees.create'), createFeeStructure);
router.put('/structures/:id', perm('fees.update'), updateFeeStructure);
router.delete('/structures/:id', perm('fees.delete'), deleteFeeStructure);

// "Selected Students" — who a fee with applies_to='selected_students' bills
router.get('/structures/:id/students', perm('fees.view'), getFeeStructureStudents);
router.put('/structures/:id/students', perm('fees.update'), setFeeStructureStudents);

// Payments
router.get('/payments', perm('fees.view'), getPayments);
router.post('/payments', perm('fees.create'), createPayment);
router.get('/payments/:id', getPaymentById); // access-checked inside the controller (staff / own / parent)
router.delete('/payments/:id', perm('fees.delete'), deletePayment);

// Status / summaries
router.get('/my-children', getMyChildrenFees); // parent's own children
router.get('/class-status', perm('fees.view'), getClassFeeStatus);
router.get('/student/:studentId/summary', getStudentFeeSummary); // access-checked inside the controller

export default router;