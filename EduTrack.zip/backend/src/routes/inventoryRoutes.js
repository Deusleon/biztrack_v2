import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getItems, getItemById, createItem, updateItem, deleteItem,
  getTransactions, createTransaction, bulkReceive,
} from '../controllers/inventoryController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

// Items — GET stays open to any logged-in user (browsing was never
// restricted); create/update/delete gated by inventory.* permissions
// (admin-tier roles always pass; everyone else needs the matching
// permission granted via their role or an individual override — see
// Settings → Permissions).
router.get('/items', perm('inventory.view'), getItems);
router.get('/items/:id', perm('inventory.view'), getItemById);
router.post('/items', perm('inventory.create'), createItem);
router.put('/items/:id', perm('inventory.update'), updateItem);
router.delete('/items/:id', perm('inventory.delete'), deleteItem);

// Stock movements — treated as "creating" inventory activity
router.get('/transactions', perm('inventory.view'), getTransactions);
router.post('/transactions', perm('inventory.update'), createTransaction);
router.post('/receive', perm('inventory.create'), bulkReceive);

export default router;
