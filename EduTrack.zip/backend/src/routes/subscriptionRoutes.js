import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getPlans, getMySubscription, getQuote, checkout, checkInvoiceStatus,
  getInvoices, getInvoiceDetail, payInvoice, cancelInvoice, previewInvoiceCleanup, runInvoiceCleanup, cancelSubscription, testGateway, upsertPlan, getAllSubscriptions,
} from '../controllers/subscriptionController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

// Readable by any signed-in user: a school that has lapsed still needs to
// see what it owes and what it can buy.
router.get('/plans', perm('subscription.manage'), getPlans);
router.get('/me', getMySubscription);
router.get('/invoices', perm('subscription.manage'), getInvoices);
router.get('/invoice-cleanup', perm('subscription.manage'), previewInvoiceCleanup);
router.post('/invoice-cleanup', perm('subscription.manage'), runInvoiceCleanup);
router.get('/invoices/:reference/status', perm('subscription.manage'), checkInvoiceStatus);
router.get('/invoices/:reference', perm('subscription.manage'), getInvoiceDetail);

// Admin actions — the role check lives in the controller so the error
// message can explain itself.
router.post('/quote', perm('subscription.manage'), getQuote);
router.post('/checkout', perm('subscription.manage'), checkout);
router.post('/invoices/:reference/pay', perm('subscription.manage'), payInvoice);
router.post('/invoices/:reference/cancel', perm('subscription.manage'), cancelInvoice);
router.post('/cancel', perm('subscription.manage'), cancelSubscription);

// Platform developer only
router.post('/gateway/test', testGateway);
router.put('/plans/:id', upsertPlan);
router.get('/tenants', getAllSubscriptions);

export default router;
