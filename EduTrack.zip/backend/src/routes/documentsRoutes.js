import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { uploadImage, uploadDocument, setUploadSubdir } from '../middleware/upload.js';
import {
  uploadStudentPhoto,
  listStudentDocuments,
  uploadStudentDocument,
  deleteStudentDocument,
} from '../controllers/documentsController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

router.post('/students/:id/photo', perm('students.documents'), setUploadSubdir('students'), uploadImage.single('photo'), uploadStudentPhoto);

router.get('/students/:id/documents', perm('students.documents'), listStudentDocuments);
router.post('/students/:id/documents', perm('students.documents'), setUploadSubdir('student-documents'), uploadDocument.single('file'), uploadStudentDocument);
router.delete('/students/:id/documents/:docId', perm('students.documents'), deleteStudentDocument);

export default router;
