import { Router } from 'express';
import { handleClickPesaWebhook } from '../controllers/subscriptionController.js';
import { driveCallback, cronRun } from '../controllers/backupController.js';
import { beemAfricaDlr, nextSmsDlr, nextSmsDlrForSchool, mesejiDlr, swalaSmsDlrForSchool } from '../controllers/webhookController.js';

// Deliberately NOT behind `authenticate` — SMS providers call these
// directly, not as a logged-in app user. See webhookController.js for
// the full explanation and the exact URLs to register with each provider.
const router = Router();

router.post('/dlr/beem_africa', beemAfricaDlr);
router.post('/dlr/nextsms/:tenantId/:signature', nextSmsDlrForSchool); // the one to register — see webhookController.js
router.post('/dlr/nextsms', nextSmsDlr);
router.post('/dlr/meseji', mesejiDlr);
router.post('/dlr/swalasms/:tenantId/:signature', swalaSmsDlrForSchool); // the one to register with SwalaSMS — see webhookController.js

// Subscription payments — the gateway has no session, so this sits
// outside the authenticated routes and verifies a shared secret instead.
router.post('/clickpesa', handleClickPesaWebhook);

// Database backups: Google redirects the browser here after the owner approves Drive access (the signed
// `state` proves who started it), and a hosting cron job can ping the second one (needs BACKUP_CRON_TOKEN).
router.get('/google-drive/callback', driveCallback);
router.post('/backup-cron', cronRun);

export default router;
