import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getMyNotifications, getUnreadCount, markAsRead, markAllAsRead,
  getNotificationSettings, updateNotificationSetting,
} from '../controllers/notificationController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

// Every authenticated user has their own notification feed
router.get('/', getMyNotifications);
router.get('/unread-count', getUnreadCount);
router.put('/:id/read', markAsRead);
router.put('/read-all', markAllAsRead);

// Settings — admin-only, enforced inside the controller
router.get('/settings/events', perm('notifications.manage'), getNotificationSettings);
router.put('/settings/events', perm('notifications.manage'), updateNotificationSetting);

export default router;
