// FILE PATH: backend/src/routes/contactInquiryRoutes.js
import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { listContactInquiries, getContactInquiryCounts, updateContactInquiryStatus } from '../controllers/contactInquiryController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

router.get('/', perm('inquiries.view'), listContactInquiries);
router.get('/counts', perm('inquiries.view'), getContactInquiryCounts);
router.patch('/:id', perm('inquiries.update'), updateContactInquiryStatus);

export default router;