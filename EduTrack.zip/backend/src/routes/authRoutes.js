import express from 'express';
import { body } from 'express-validator';
import {
  register,
  login,
  getMe,
  updateProfile,
  uploadAvatar,
  changePassword,
  forgotPassword,
  forgotPasswordOptions,
  resetPassword,
} from '../controllers/authController.js';
import { authenticate } from '../middleware/auth.js';
import { validate } from '../middleware/validator.js';
import { newPasswordError } from '../utils/passwords.js';
import { authLimiter, modifyLimiter, passwordResetLimiter } from '../middleware/rateLimiter.js';
import { uploadImage, setUploadSubdir } from '../middleware/upload.js';

const router = express.Router();

router.post(
  '/register',
  authenticate, // was open to anyone — see authController.register
  authLimiter,
  [
    body('email').isEmail().withMessage('Please provide a valid email'),
    body('password').custom((value) => { const problem = newPasswordError(value); if (problem) throw new Error(problem); return true; }),
    body('first_name').notEmpty().withMessage('First name is required'),
    body('last_name').notEmpty().withMessage('Last name is required'),
    body('role').notEmpty().withMessage('Role is required'),
    body('tenant_id').notEmpty().withMessage('Tenant ID is required'),
  ],
  validate,
  register
);

router.post(
  '/login',
  authLimiter,
  [
    body('email').isEmail().withMessage('Please provide a valid email'),
    body('password').notEmpty().withMessage('Password is required'),
  ],
  validate,
  login
);

// Public — someone who has forgotten their password cannot sign in. See
// services/passwordResetService.js for how it is kept safe.
router.get('/forgot-password/options', passwordResetLimiter, forgotPasswordOptions);

router.post(
  '/forgot-password',
  passwordResetLimiter,
  [body('identifier').trim().notEmpty().withMessage('Enter your email address or phone number')],
  validate,
  forgotPassword
);

router.post(
  '/reset-password',
  authLimiter,
  [
    body('identifier').trim().notEmpty().withMessage('Enter your email address or phone number'),
    body('code').trim().notEmpty().withMessage('Enter the 6-digit code you received'),
    body('new_password').notEmpty().withMessage('Enter a new password'),
  ],
  validate,
  resetPassword
);

router.get('/me', authenticate, getMe);

router.put(
  '/profile',
  authenticate,
  modifyLimiter,
  [
    body('first_name').optional().notEmpty().withMessage('First name cannot be empty'),
    body('last_name').optional().notEmpty().withMessage('Last name cannot be empty'),
    body('phone').optional().isMobilePhone().withMessage('Please provide a valid phone number'),
  ],
  validate,
  updateProfile
);

router.put(
  '/change-password',
  authenticate,
  authLimiter,
  [
    body('current_password').notEmpty().withMessage('Current password is required'),
    body('new_password').notEmpty().withMessage('New password is required'), // the full strength rule is applied by the handler
  ],
  validate,
  changePassword
);

router.post(
  '/profile/avatar',
  authenticate,
  modifyLimiter,
  setUploadSubdir('avatars'),
  uploadImage.single('avatar'),
  uploadAvatar
);

export default router;
