import { Router } from 'express';
import { verifyReceiptById, verifyReceiptByCode } from '../controllers/feeController.js';
import { authLimiter } from '../middleware/rateLimiter.js';
import { verifySubscriptionReceipt } from '../controllers/subscriptionController.js';

// Deliberately NOT behind `authenticate` — this exists so anyone holding
// a physical/scanned receipt (a parent, an auditor, the school itself
// checking a submitted copy) can confirm it's real, without needing an
// EduTrack login. Security comes from the HMAC verification code itself
// (see utils/receiptSecurity.js), not from requiring a session. Reusing
// authLimiter as a defense-in-depth brute-force guard, even though a
// 10-character HMAC code isn't realistically guessable.
const router = Router();

router.get('/receipt/:paymentId/:code', authLimiter, verifyReceiptById);
router.get('/receipt', authLimiter, verifyReceiptByCode);
// Subscription receipts (what a school pays EduTrack) — same idea, own code namespace.
router.get('/subscription-receipt/:invoiceNumber/:code', authLimiter, verifySubscriptionReceipt);
router.get('/subscription-receipt', authLimiter, verifySubscriptionReceipt);

export default router;
