import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getSettingsOverview, updateAcademicYearSettings, updateSessionPolicy,
  updateBackupSchedule, exportData, getAuditLogs, getAuditLogResourceTypes, getAuditLogById, updateDisplaySettings, getWebsiteContent, updateWebsiteContent } from '../controllers/settingsController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

router.get('/', getSettingsOverview);
router.put('/academic-year', perm('settings.academic_year'), updateAcademicYearSettings);
router.put('/session-policy', perm('settings.login_policy'), updateSessionPolicy);
router.put('/display', perm('settings.display'), updateDisplaySettings);
router.get('/website-content', perm('settings.website'), getWebsiteContent);
router.put('/website-content', perm('settings.website'), updateWebsiteContent);
router.put('/backup-schedule', perm('settings.backup'), updateBackupSchedule);
router.get('/export', perm('settings.backup'), exportData);
router.get('/audit-logs', perm('audit.view'), getAuditLogs);
router.get('/audit-logs/resource-types', perm('audit.view'), getAuditLogResourceTypes);
router.get('/audit-logs/:id', perm('audit.view'), getAuditLogById);

export default router;
