import express from 'express';
import { checkStudentLimit } from '../middleware/subscriptionGuard.js';
import { studentController } from '../controllers/studentController.js';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { validateStudent } from '../middleware/validator.js';

const router = express.Router();

// All routes require authentication
router.use(authenticate);
router.use(checkTenant);

// Reading: every role can reach the list and a record, but a STUDENT sees only
// themselves and a PARENT only their own children — enforced in the controller
// (the parent portal itself loads `?parent_id=<me>`). Changing records is for
// the admin tier, or anyone an administrator has granted students.* in
// Settings → Permissions. Hard delete is super admin only.


// Get all students with filters and pagination
router.get('/', studentController.getAll);

// Get student statistics
router.get('/:id/stats', studentController.getStats);

// Get single student
router.get('/:id', studentController.getById);

// Create new student (admin/principal only)
router.post('/', perm('students.create'), checkStudentLimit, validateStudent, studentController.create);

// Update student
router.put('/:id', perm('students.update'), studentController.update);

// Soft delete student
router.delete('/:id', perm('students.delete'), studentController.delete);

// Hard delete student (super admin only)
router.delete('/:id/permanent', perm('students.delete'), studentController.permanentDelete);

// Reactivate student
router.patch('/:id/reactivate', perm('students.update'), studentController.reactivate);

// Bulk update status
router.patch('/bulk/status', perm('students.update'), studentController.bulkUpdateStatus);

// Bulk admission from an uploaded Excel template (see utils/studentBulkTemplate.js on the frontend)
router.post('/bulk/preview', perm('students.create'), studentController.bulkPreview);
router.post('/bulk', perm('students.create'), checkStudentLimit, studentController.bulkCreate);

export default router;
