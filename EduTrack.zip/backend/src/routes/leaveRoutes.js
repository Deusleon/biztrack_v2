import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getLeaveTypes, createLeaveType, updateLeaveType, deleteLeaveType,
  getMyBalances, getUserBalances, adjustBalance,
  createRequest, getMyRequests, getPendingApprovals, getAllRequests, decideRequest, cancelRequest,
} from '../controllers/leaveController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);


// Leave types — viewable by anyone (to populate the request form); managing restricted inside controllers
router.get('/types', perm('leave.request'), getLeaveTypes);
router.post('/types', perm('leave.create'), createLeaveType);
router.put('/types/:id', perm('leave.update'), updateLeaveType);
router.delete('/types/:id', perm('leave.delete'), deleteLeaveType);

// Balances
router.get('/balances/me', perm('leave.request'), getMyBalances);
router.get('/balances/:userId', perm('leave.view'), getUserBalances);
router.put('/balances/:id', perm('leave.update'), adjustBalance);

// Requests — order matters: static paths before the /:id decide/cancel
router.post('/requests', perm('leave.request'), createRequest);
router.get('/requests/me', perm('leave.request'), getMyRequests);
router.get('/requests/pending-approvals', perm('leave.request'), getPendingApprovals);
router.get('/requests', perm('leave.view'), getAllRequests);
router.put('/requests/:id/decide', perm('leave.request'), decideRequest);
router.put('/requests/:id/cancel', perm('leave.request'), cancelRequest);

export default router;
