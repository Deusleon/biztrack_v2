import express from 'express';
import { body } from 'express-validator';
import {
  markAttendance,
  bulkMarkAttendance,
  getAttendance,
  getAttendanceReport,
  getAttendanceById,
  updateAttendance,
  getAttendanceSessions,
} from '../controllers/attendanceController.js';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { validate } from '../middleware/validator.js';
import { modifyLimiter } from '../middleware/rateLimiter.js';

const router = express.Router();

// Protect all routes
router.use(authenticate);
router.use(checkTenant);

router.post('/mark', perm('attendance.create'), modifyLimiter,
  [
    body('student_id').notEmpty().withMessage('Student ID is required'),
    body('class_id').notEmpty().withMessage('Class ID is required'),
    body('date').isDate().withMessage('Valid date is required'),
    body('status').isIn(['present', 'absent', 'late', 'excused', 'half_day']).withMessage('Invalid status'),
  ],
  validate,
  markAttendance
);

router.post('/bulk-mark', perm('attendance.create'), modifyLimiter,
  [
    body('class_id').notEmpty().withMessage('Class ID is required'),
    body('date').isDate().withMessage('Valid date is required'),
    body('attendance_records').isArray().withMessage('Attendance records must be an array'),
  ],
  validate,
  bulkMarkAttendance
);

router.get('/sessions', perm('attendance.view'), getAttendanceSessions
);

router.get('/', perm('attendance.view'), getAttendance
);

router.get('/report', perm('attendance.view'), getAttendanceReport
);

router.get('/:id', perm('attendance.view'), getAttendanceById
);

router.put('/:id', perm('attendance.update'), modifyLimiter,
  [
    body('status').isIn(['present', 'absent', 'late', 'excused', 'half_day']).withMessage('Invalid status'),
    body('remarks').trim().notEmpty().withMessage('Remarks are required when updating attendance'),
  ],
  validate,
  updateAttendance
);

export default router;
