import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getFinancialSummary, getFeeCollectionReport, getAttendanceSummaryReport, getEnrollmentReport,
  getYearRange, getDetailedPayments, getDetailedExpenses,
} from '../controllers/reportsController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

const REPORT_ROLES = ['super_admin', 'admin', 'principal', 'accountant'];

router.get('/year-range', perm('reports.view'), getYearRange);
router.get('/financial-summary', perm('reports.view'), getFinancialSummary);
router.get('/fee-collection', perm('reports.view'), getFeeCollectionReport);
router.get('/attendance-summary', perm('reports.view'), getAttendanceSummaryReport);
router.get('/enrollment', perm('reports.view'), getEnrollmentReport);
router.get('/detailed-payments', perm('reports.view'), getDetailedPayments);
router.get('/detailed-expenses', perm('reports.view'), getDetailedExpenses);

export default router;
