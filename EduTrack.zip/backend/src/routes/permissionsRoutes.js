import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getAvailablePermissions, getStaffPermissions, updateUserPermissions,
  getRolePermissions, updateRolePermissions,
} from '../controllers/permissionsController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

router.get('/available', perm('permissions.manage'), getAvailablePermissions);
router.get('/roles', perm('permissions.manage'), getRolePermissions);
router.put('/roles/:role', perm('permissions.manage'), updateRolePermissions);
router.get('/staff', perm('permissions.manage'), getStaffPermissions);
router.put('/users/:userId', perm('permissions.manage'), updateUserPermissions);

export default router;
