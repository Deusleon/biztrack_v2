// FILE PATH: backend/src/routes/messagingRoutes.js
import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getContacts, createContact, updateContact, deleteContact, syncContactsFromSystem,
  getGroups, createGroup, updateGroup, deleteGroup, setGroupMembers, getGroupMembers,
} from '../controllers/contactController.js';
import {
  getTemplates, createTemplate, updateTemplate, deleteTemplate,
  previewRecipients, getMessages, getMessageById, getMessageRecipients, saveDraft, deleteMessage, sendMessage, retryFailedRecipients,
  refreshMessageDelivery,
} from '../controllers/messageController.js';
import {
  getBalance, purchaseBalance, updateCostPerSms, getTransactions,
  getGatewaySettings, updateGatewaySettings, testGatewayConnection,
  getProviderSenderIds, getBatchDeliveryStats, topUpProviderBalance, checkTopUpStatus,
  getWalletOptions, quoteWalletTopUp, getSenderIdRequirements, requestSenderId,
} from '../controllers/smsController.js';
import { getEmailGatewaySettings, updateEmailGatewaySettings, testEmailGateway } from '../controllers/emailGatewayController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

const STAFF_ROLES = ['super_admin', 'admin', 'principal', 'teacher', 'accountant', 'librarian', 'hr', 'transport_manager', 'hostel_warden'];

// Any staff member can LOOK (contacts, groups, templates, history). Changing
// them — or deleting a draft — takes the same permission as sending: the admin
// tier, or `send_messages` granted in Settings → Permissions. Editing and
// deleting templates and contacts used to have no check at all.

// Contacts — any staff-tier role can view; creating/editing is open to
// anyone with the send-permission check enforced inside the controller
// where it matters (sending). Viewing/managing contacts is kept to staff.
router.get('/contacts', perm('messages.view'), getContacts);
router.post('/contacts', perm('messages.manage_contacts'), createContact);
router.put('/contacts/:id', perm('messages.manage_contacts'), updateContact);
router.delete('/contacts/:id', perm('messages.manage_contacts'), deleteContact);
router.post('/contacts/sync', perm('messages.manage_contacts'), syncContactsFromSystem);

// Groups & subgroups
router.get('/groups', perm('messages.view'), getGroups);
router.post('/groups', perm('messages.manage_contacts'), createGroup);
router.put('/groups/:id', perm('messages.manage_contacts'), updateGroup);
router.delete('/groups/:id', perm('messages.manage_contacts'), deleteGroup);
router.put('/groups/:id/members', perm('messages.manage_contacts'), setGroupMembers);
router.get('/groups/:id/members', perm('messages.view'), getGroupMembers);

// Templates
router.get('/templates', perm('messages.view'), getTemplates);
router.post('/templates', perm('messages.manage_templates'), createTemplate);
router.put('/templates/:id', perm('messages.manage_templates'), updateTemplate);
router.delete('/templates/:id', perm('messages.manage_templates'), deleteTemplate);

// Messages
router.post('/preview-recipients', perm('messages.view'), previewRecipients);
router.get('/messages', perm('messages.view'), getMessages);
router.get('/messages/:id', perm('messages.view'), getMessageById);
router.get('/messages/:id/recipients', perm('messages.view'), getMessageRecipients);
router.post('/messages/draft', perm('send_messages'), saveDraft);
router.delete('/messages/:id', perm('send_messages'), deleteMessage);
router.post('/messages/send', perm('send_messages'), sendMessage);
router.post('/messages/:id/retry', perm('send_messages'), retryFailedRecipients);

// SMS balance & gateway (admin-only enforced inside the controllers)
router.get('/sms/balance', perm('messages.view'), getBalance);
router.post('/sms/purchase', perm('messages.billing'), purchaseBalance);
router.put('/sms/cost', perm('messages.billing'), updateCostPerSms);
router.get('/sms/transactions', perm('messages.view'), getTransactions);
router.get('/sms/gateway', getGatewaySettings);
router.post('/sms/gateway/test', testGatewayConnection);
router.get('/sms/gateway/sender-ids', getProviderSenderIds);
router.post('/sms/top-up', perm('messages.billing'), topUpProviderBalance);
router.get('/sms/top-up/:orderId', perm('messages.view'), checkTopUpStatus);
router.get('/sms/batch/:batchId', perm('messages.view'), getBatchDeliveryStats);
// SwalaSMS: what credits can be bought and what they cost (billing permission), and sender-ID requests (developer-only, enforced in the controllers)
router.get('/sms/wallet/options', perm('messages.billing'), getWalletOptions);
router.post('/sms/wallet/quote', perm('messages.billing'), quoteWalletTopUp);
router.get('/sms/gateway/sender-requirements', getSenderIdRequirements);
router.post('/sms/gateway/sender-ids', requestSenderId);

// Re-checks delivery for one message against the provider
router.post('/messages/:id/refresh-delivery', perm('messages.view'), refreshMessageDelivery);
router.put('/sms/gateway', updateGatewaySettings);

// Email gateway (developer-only, enforced inside the controllers)
router.get('/email/gateway', getEmailGatewaySettings);
router.put('/email/gateway', updateEmailGatewaySettings);
router.post('/email/gateway/test', testEmailGateway);

export default router;