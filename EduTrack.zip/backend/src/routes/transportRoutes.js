import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import { uploadImage, setUploadSubdir } from '../middleware/upload.js';
import {
  getRoutes, getRouteById, createRoute, updateRoute, deleteRoute,
  getRouteStudents, getStudentAllocation, assignStudent, updateAllocation, removeAllocation,
} from '../controllers/transportController.js';
import {
  getVehicles, getVehicleById, createVehicle, updateVehicle, deleteVehicle, uploadVehiclePhoto,
  getMaintenanceRecords, createMaintenanceRecord, updateMaintenanceRecord, deleteMaintenanceRecord,
} from '../controllers/vehicleController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

const MANAGE_ROLES = ['super_admin', 'admin', 'principal', 'transport_manager'];

// Routes — viewable by any logged-in user (parents/students can see which
// route their child/they are on); managing is restricted.
router.get('/routes', getRoutes);
router.get('/routes/:id', getRouteById);
router.post('/routes', perm('transport.create'), createRoute);
router.put('/routes/:id', perm('transport.update'), updateRoute);
router.delete('/routes/:id', perm('transport.delete'), deleteRoute);
router.get('/routes/:id/students', perm('transport.view'), getRouteStudents);

// Student allocations
router.get('/student/:studentId', getStudentAllocation); // parents/students can check their own
router.post('/allocations', perm('transport.create'), assignStudent);
router.put('/allocations/:id', perm('transport.update'), updateAllocation);
router.delete('/allocations/:id', perm('transport.delete'), removeAllocation);

// Vehicles — viewable by any logged-in user; managing is restricted.
router.get('/vehicles', getVehicles);
router.get('/vehicles/:id', getVehicleById);
router.post('/vehicles', perm('transport.create'), createVehicle);
router.put('/vehicles/:id', perm('transport.update'), updateVehicle);
router.delete('/vehicles/:id', perm('transport.delete'), deleteVehicle);
router.post('/vehicles/:id/photo', perm('transport.create'), setUploadSubdir('vehicles'), uploadImage.single('photo'), uploadVehiclePhoto);

// Vehicle maintenance records
router.get('/vehicles/:id/maintenance', perm('transport.view'), getMaintenanceRecords);
router.post('/vehicles/:id/maintenance', perm('transport.create'), createMaintenanceRecord);
router.put('/vehicles/:id/maintenance/:recordId', perm('transport.update'), updateMaintenanceRecord);
router.delete('/vehicles/:id/maintenance/:recordId', perm('transport.delete'), deleteMaintenanceRecord);

export default router;
