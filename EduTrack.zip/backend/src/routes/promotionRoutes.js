import { Router } from 'express';
import { authenticate, checkTenant } from '../middleware/auth.js';
import { perm } from '../middleware/access.js';
import {
  getPromotionPreview, runPromotion, revertPromotion, promoteIndividualStudent,
  getPromotionHistory, getClassSections,
} from '../controllers/promotionController.js';

const router = Router();
router.use(authenticate);
router.use(checkTenant);

// Role checks live in the controller so the message can explain itself.
router.get('/', perm('promotions.manage'), getPromotionHistory);
router.get('/preview', perm('promotions.manage'), getPromotionPreview);
router.get('/sections', perm('promotions.manage'), getClassSections);
router.post('/run', perm('promotions.manage'), runPromotion);
router.post('/individual', perm('promotions.manage'), promoteIndividualStudent);
router.post('/:batchId/revert', perm('promotions.manage'), revertPromotion);

export default router;
