// FILE PATH: backend/src/jobs/libraryJobs.js
/**
 * A loan flips to "overdue" the first time anyone looks at the library page after its due date — which is also when the
 * "Library Book Overdue" notification goes out. This sweep does the same thing for every school a few times a day, so a school
 * where nobody opens the library page still gets its notices (Settings → Notifications → Library Book Overdue).
 * It starts a couple of minutes after the server boots (a cPanel app that was asleep catches up as soon as it wakes) and then
 * every six hours. Set LIBRARY_JOBS=off to switch it off.
 */
import { refreshOverdueStatus, tenantsWithOverdueLoans } from '../controllers/libraryController.js';

const SIX_HOURS = 6 * 60 * 60 * 1000;

export const sweepOverdueLoans = async () => {
  let flipped = 0;
  for (const tenantId of await tenantsWithOverdueLoans()) {
    try { flipped += await refreshOverdueStatus(tenantId); } catch (err) { console.error(`[library] overdue sweep failed for ${tenantId}:`, err.message); }
  }
  return flipped;
};

export const startLibraryJobs = () => {
  if (process.env.LIBRARY_JOBS === 'off' || process.env.NODE_ENV === 'test' || process.env.NODE_TEST_CONTEXT) return;
  const tick = () => sweepOverdueLoans().catch((e) => console.error('Overdue sweep failed:', e.message));
  setTimeout(tick, 2 * 60 * 1000).unref();
  setInterval(tick, SIX_HOURS).unref();
};
