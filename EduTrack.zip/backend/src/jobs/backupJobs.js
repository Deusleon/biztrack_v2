// FILE PATH: backend/src/jobs/backupJobs.js
/**
 * Starts the daily database backup. Every 10 minutes it asks "is today's backup due?" (see runDueBackup), and it also
 * asks a minute after the server starts — so if the host put the app to sleep at the scheduled hour, the backup is
 * made as soon as the app wakes up. Set BACKUP_JOBS=off to switch it off (e.g. on a second server).
 * For hosts that stop idle apps, you can also run `npm run db:backup` from a cron job.
 */
import { runDueBackup, runningUnderTests } from '../services/backup/backupService.js';

const TICK_MS = 10 * 60 * 1000;

export const startBackupJobs = () => {
  if (process.env.BACKUP_JOBS === 'off' || runningUnderTests()) return;
  const tick = () => runDueBackup().catch((e) => console.error('Scheduled backup check failed:', e.message));
  setTimeout(tick, 60 * 1000).unref();
  setInterval(tick, TICK_MS).unref();
  console.log('🗄️  Daily database backup is on (see Settings → Database Backup).');
};
