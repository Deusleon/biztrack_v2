// FILE PATH: backend/src/jobs/subscriptionJobs.js
/**
 * The subscription housekeeping that must happen without anyone clicking anything:
 *
 *   1. Bring stored statuses in line with the calendar, and record the moment a school LOCKS.
 *   2. Remind the school before the subscription ends (7 and 3 days before), the day it ends,
 *      and when it has locked. Each reminder is sent once per paid window — the marker lives in
 *      subscriptions.reminders_sent and restarts when the school renews.
 *   3. Cancel invoices nobody paid within 30 days (their pay links stop working), and remove invoices
 *      that have been cancelled for over 90 days, so the list does not fill with dead ones.
 *      Paid invoices are never touched. (Admins can also clean up on demand from the Subscription page.)
 *
 * `runSubscriptionMaintenance` is safe to run as often as you like (it is idempotent).
 * `startSubscriptionJobs` runs it every hour; set SUBSCRIPTION_JOBS=off to disable.
 */
import { Op } from 'sequelize';
import { Subscription, SubscriptionInvoice, SubscriptionPlan } from '../models/index.js';
import { evaluateSubscription } from '../controllers/subscriptionController.js';
import { emailSubscriptionReminder } from '../services/subscriptionNotifier.js';
import { logSystemEvent } from '../middleware/auditLog.js';

const DAY = 86400000;
export const STALE_INVOICE_DAYS = 30;
export const PURGE_CANCELLED_AFTER_DAYS = 90;
const RETRY_FAILED_EMAIL_AFTER_MS = 24 * 3600000;

/**
 * Which reminder, if any, is due for this subscription right now — and has not been sent for
 * the current paid window. Pure, so it can be tested without a database or a clock.
 */
export const dueReminder = (subscription, evaluation, now = Date.now()) => {
  if (!subscription?.ends_at || evaluation.status === 'cancelled' || evaluation.status === 'none') return null;
  const window = new Date(subscription.ends_at).toISOString();
  const sent = subscription.reminders_sent?.window === window ? subscription.reminders_sent : {};

  let kind = null;
  if (evaluation.locked) kind = 'locked';
  else if (evaluation.inGrace) kind = 'd0';
  else if (evaluation.daysLeft <= 3) kind = 'd3';
  else if (evaluation.daysLeft <= 7) kind = 'd7';
  if (!kind || sent[kind]) return null;

  // A send that failed is tried again, but not every hour.
  const failedAt = sent[`${kind}_failed_at`];
  if (failedAt && now - new Date(failedAt).getTime() < RETRY_FAILED_EMAIL_AFTER_MS) return null;
  return { kind, window, sent };
};


/** Invoices unpaid for STALE_INVOICE_DAYS are cancelled (they stay listed as "Cancelled"). Returns how many. */
export const cancelStaleInvoices = async (now = Date.now()) => {
  const cutoff = new Date(now - STALE_INVOICE_DAYS * DAY);
  const stale = await SubscriptionInvoice.findAll({ where: { status: { [Op.in]: ['pending', 'failed'] }, createdAt: { [Op.lt]: cutoff } } });
  const perTenant = new Map();
  for (const invoice of stale) {
    await invoice.update({ status: 'cancelled', failure_reason: `Cancelled automatically: unpaid for ${STALE_INVOICE_DAYS} days` });
    perTenant.set(invoice.tenant_id, (perTenant.get(invoice.tenant_id) || 0) + 1);
  }
  for (const [tenantId, count] of perTenant) {
    await logSystemEvent({
      tenantId,
      title: `${count} unpaid invoice${count === 1 ? '' : 's'} cancelled automatically after ${STALE_INVOICE_DAYS} days`,
      reason: 'Invoices that stay unpaid for 30 days are closed. A new invoice can be created at any time.',
    });
  }
  return stale.length;
};

/** Cancelled invoices older than PURGE_CANCELLED_AFTER_DAYS are removed for good. Returns how many. */
export const purgeOldCancelledInvoices = async (now = Date.now()) => {
  const cutoff = new Date(now - PURGE_CANCELLED_AFTER_DAYS * DAY);
  const old = await SubscriptionInvoice.findAll({ where: { status: 'cancelled', updatedAt: { [Op.lt]: cutoff } }, attributes: ['id', 'tenant_id', 'invoice_number'] });
  if (old.length === 0) return 0;
  await SubscriptionInvoice.destroy({ where: { id: old.map((i) => i.id), status: 'cancelled' } });
  const perTenant = new Map();
  for (const invoice of old) perTenant.set(invoice.tenant_id, [...(perTenant.get(invoice.tenant_id) || []), invoice.invoice_number]);
  for (const [tenantId, numbers] of perTenant) {
    await logSystemEvent({
      tenantId,
      title: `${numbers.length} old cancelled invoice${numbers.length === 1 ? '' : 's'} removed automatically (cancelled over ${PURGE_CANCELLED_AFTER_DAYS} days ago)`,
      reason: 'Paid invoices and receipts are never removed.',
      extra: { invoices: numbers.slice(0, 200), count: numbers.length },
    });
  }
  return old.length;
};

export const runSubscriptionMaintenance = async () => {
  const summary = { locked: 0, reminders: 0, invoicesCancelled: 0, invoicesPurged: 0 };

  // 1 ── statuses + the moment of locking
  const lapsed = await Subscription.findAll({
    where: { status: { [Op.in]: ['active', 'trial', 'grace'] }, ends_at: { [Op.lt]: new Date() } },
  });
  for (const subscription of lapsed) {
    const evaluation = evaluateSubscription(subscription);
    if (evaluation.status === subscription.status) continue;
    await subscription.update({ status: evaluation.status });
    if (evaluation.status === 'expired') {
      summary.locked += 1;
      await logSystemEvent({
        tenantId: subscription.tenant_id,
        title: 'Subscription locked: the paid period and the grace period have ended',
        resourceId: subscription.id,
        reason: 'EduTrack is closed for this school until a payment is confirmed.',
      });
    }
  }

  // 2 ── reminders
  const candidates = await Subscription.findAll({
    where: { status: { [Op.ne]: 'cancelled' }, ends_at: { [Op.ne]: null, [Op.lt]: new Date(Date.now() + 8 * DAY) } },
  });
  for (const subscription of candidates) {
    const evaluation = evaluateSubscription(subscription);
    const due = dueReminder(subscription, evaluation);
    if (!due) continue;

    const plan = subscription.plan_id ? await SubscriptionPlan.findByPk(subscription.plan_id, { attributes: ['name'] }) : null;
    const result = await emailSubscriptionReminder(subscription.tenant_id, subscription, due.kind, plan?.name || (subscription.status === 'trial' ? 'Free trial' : null));

    const next = { ...due.sent, window: due.window };
    if (result.sent || result.reason === 'no_recipient') {
      next[due.kind] = new Date().toISOString();
      delete next[`${due.kind}_failed_at`];
      summary.reminders += result.sent ? 1 : 0;
    } else {
      next[`${due.kind}_failed_at`] = new Date().toISOString();
    }
    await subscription.update({ reminders_sent: next });
  }

  // 3 ── invoices nobody paid, and tidying cancelled ones
  summary.invoicesCancelled = await cancelStaleInvoices();
  summary.invoicesPurged = await purgeOldCancelledInvoices();

  return summary;
};

let timer = null;
let running = false;

export const startSubscriptionJobs = () => {
  if (String(process.env.SUBSCRIPTION_JOBS || '').toLowerCase() === 'off' || timer) return;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      const s = await runSubscriptionMaintenance();
      if (s.locked || s.reminders || s.invoicesCancelled) console.log('[subscription jobs]', s);
    } catch (err) {
      console.error('[subscription jobs] failed:', err);
    } finally {
      running = false;
    }
  };
  setTimeout(tick, 60 * 1000).unref();                 // shortly after start-up
  timer = setInterval(tick, 60 * 60 * 1000);           // then hourly
  timer.unref();                                       // never keeps the process alive on its own
  console.log('⏰ Subscription reminders and clean-up are scheduled (hourly).');
};
