// FILE PATH: backend/src/migrations/20260909000000-fee-structure-selected-students.js
/**
 * Adds a fourth `applies_to` option to fee_structures: 'selected_students'.
 *
 * 'all', 'transport' and 'hostel' all decide who's charged by a RULE
 * (everyone / uses transport / uses hostel) — there was no way to just
 * hand-pick an arbitrary set of students for a fee that doesn't follow
 * any of those rules (an extra tuition class only some students take,
 * a trip fee only for those going, a personalized rate group). This
 * migration adds that fourth option and the join table
 * (fee_structure_students) that records exactly who was picked for a
 * given structure — one row per (fee_structure, student) pair.
 *
 * A useful side effect for the ORIGINAL "same fee name, different
 * amount" question this was built for: nothing stops a school creating
 * several FeeStructure rows that all share the same NAME (e.g.
 * "Transport") but different amounts, each with applies_to =
 * 'selected_students' and its own hand-picked group — students never
 * see three different-looking fees, each just ends up billed the one
 * "Transport" amount that matches the group they were put in.
 */
export async function up(queryInterface, Sequelize, transaction) {
  await queryInterface.sequelize.query(
    "ALTER TYPE enum_fee_structures_applies_to ADD VALUE IF NOT EXISTS 'selected_students'",
    { transaction },
  );

  await queryInterface.createTable('fee_structure_students', {
    id: {
      type: Sequelize.DataTypes.UUID,
      defaultValue: Sequelize.DataTypes.UUIDV4,
      primaryKey: true,
    },
    tenant_id: {
      type: Sequelize.DataTypes.UUID,
      allowNull: false,
      references: { model: 'tenants', key: 'id' },
      onDelete: 'CASCADE',
    },
    fee_structure_id: {
      type: Sequelize.DataTypes.UUID,
      allowNull: false,
      references: { model: 'fee_structures', key: 'id' },
      onDelete: 'CASCADE',
    },
    student_id: {
      type: Sequelize.DataTypes.UUID,
      allowNull: false,
      references: { model: 'students', key: 'id' },
      onDelete: 'CASCADE',
    },
    assigned_by: {
      type: Sequelize.DataTypes.UUID,
      allowNull: true,
      references: { model: 'users', key: 'id' },
    },
    created_at: { type: Sequelize.DataTypes.DATE, allowNull: false, defaultValue: Sequelize.DataTypes.NOW },
    updated_at: { type: Sequelize.DataTypes.DATE, allowNull: false, defaultValue: Sequelize.DataTypes.NOW },
  }, { transaction });

  await queryInterface.addIndex('fee_structure_students', ['fee_structure_id', 'student_id'], {
    unique: true, name: 'fee_structure_students_unique', transaction,
  });
  await queryInterface.addIndex('fee_structure_students', ['tenant_id'], { transaction });
  await queryInterface.addIndex('fee_structure_students', ['student_id'], { transaction });
}

export async function down(queryInterface, Sequelize, transaction) {
  await queryInterface.dropTable('fee_structure_students', { transaction });
}