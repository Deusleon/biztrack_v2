// FILE PATH: backend/src/migrations/20260903000003-create-contact-inquiries.js
/**
 * Contact inquiries — general messages submitted through a tenant's
 * public website contact form (see routes/publicRoutes.js), separate
 * from AdmissionInquiry since these aren't tied to a prospective
 * student and don't go through an admission workflow — just something
 * staff need to read and reply to.
 *
 * NOTE: created_at/updated_at (snake_case), matching config/database.js's
 * global `underscored: true` — see the admission_inquiries migrations
 * for the bug this avoids if you use createdAt/updatedAt instead.
 */
export async function up(queryInterface, Sequelize, transaction) {
  await queryInterface.createTable('contact_inquiries', {
    id: {
      type: Sequelize.DataTypes.UUID,
      defaultValue: Sequelize.DataTypes.UUIDV4,
      primaryKey: true,
    },
    tenant_id: {
      type: Sequelize.DataTypes.UUID,
      allowNull: false,
      references: { model: 'tenants', key: 'id' },
      onDelete: 'CASCADE',
    },
    name: { type: Sequelize.DataTypes.STRING, allowNull: false },
    email: { type: Sequelize.DataTypes.STRING, allowNull: false },
    phone: { type: Sequelize.DataTypes.STRING, allowNull: true },
    subject: { type: Sequelize.DataTypes.STRING, allowNull: false },
    message: { type: Sequelize.DataTypes.TEXT, allowNull: false },
    status: {
      // new: unread. read: a staff member has opened it. replied: the
      // school has responded (by email/phone, outside EduTrack).
      type: Sequelize.DataTypes.ENUM('new', 'read', 'replied'),
      allowNull: false,
      defaultValue: 'new',
    },
    staff_notes: { type: Sequelize.DataTypes.TEXT, allowNull: true },
    source: { type: Sequelize.DataTypes.STRING, allowNull: false, defaultValue: 'website' },
    created_at: { type: Sequelize.DataTypes.DATE, allowNull: false, defaultValue: Sequelize.DataTypes.NOW },
    updated_at: { type: Sequelize.DataTypes.DATE, allowNull: false, defaultValue: Sequelize.DataTypes.NOW },
  }, { transaction });

  await queryInterface.addIndex('contact_inquiries', ['tenant_id', 'status'], { transaction });
  await queryInterface.addIndex('contact_inquiries', ['tenant_id', 'created_at'], { transaction });
}

export async function down(queryInterface, Sequelize, transaction) {
  await queryInterface.dropTable('contact_inquiries', { transaction });
}