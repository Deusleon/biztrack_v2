// backend/src/migrations/20260821000000-baseline-schema.js
/**
 * 20260821000000-baseline-schema.js
 *
 * Creates every table exactly as the current Sequelize MODELS define them
 * (backend/src/models/*.js) — it is generated FROM those models rather
 * than hand-written, so it can't drift from what the app actually expects
 * to find in the database. If a brand-new column, table, or index is
 * added later, add a NEW migration for it (see MIGRATIONS_GUIDE.md) —
 * this file should not be edited again once anyone has run it.
 *
 * EXISTING INSTALLATIONS: this is safe to run against a database whose
 * tables were already created by the old `sequelize.sync()` approach. It
 * creates only what is missing — tables use CREATE TABLE IF NOT EXISTS,
 * and foreign keys and indexes that already exist are skipped rather than
 * re-added. (sync() names its foreign keys `<table>_<column>_fkey` and its
 * indexes `<table>_<column>`, so both spellings are checked.)
 *
 * It will NOT add columns missing from a table that already exists. If
 * your synced database predates recent model changes, either recreate it
 * (`npm run db:empty`, fine while still in testing) or write a follow-up
 * migration for the missing columns.
 *
 * To record it as applied WITHOUT running it — for a database you have
 * already verified matches:
 *   npm run db:migrate:adopt
 *
 * How it works: importing models/index.js registers every model (and its
 * associations) on the shared `sequelize` instance in memory — no DB
 * connection is required just to read their attribute/index definitions.
 *   1. Create every table with its plain columns (no FK constraints yet).
 *   2. Add every FK constraint, now that all tables exist (this order
 *      avoids ever having to work out a manual dependency ordering).
 *   3. Add every explicit index each model declares.
 */
import '../models/index.js';
import sequelize from '../config/database.js';

const isPlainAttribute = (attr) => attr && typeof attr === 'object' && 'type' in attr;

/** Strips Sequelize-internal bookkeeping fields down to what
 * `queryInterface.createTable` actually understands, and removes
 * `references` (added back separately as real FK constraints in step 2,
 * once every table is guaranteed to already exist). */
const toColumnDefinition = (attr) => {
  const {
    type, allowNull, defaultValue, primaryKey, autoIncrement, unique, comment, field,
  } = attr;
  const def = { type };
  if (allowNull !== undefined) def.allowNull = allowNull;
  if (defaultValue !== undefined) def.defaultValue = defaultValue;
  if (primaryKey) def.primaryKey = true;
  if (autoIncrement) def.autoIncrement = true;
  if (unique) def.unique = unique;
  if (comment) def.comment = comment;
  if (field) def.field = field;
  return def;
};

/**
 * Names of the constraints that already exist, so we never try to add one
 * twice. Checked UP FRONT rather than catching the error, because in
 * Postgres a failed statement aborts the whole transaction — there is no
 * "try it and carry on".
 */
const existingConstraintNames = async (queryInterface, transaction) => {
  const [rows] = await queryInterface.sequelize.query(
    `SELECT conname FROM pg_constraint c
     JOIN pg_namespace n ON n.oid = c.connamespace
     WHERE n.nspname = 'public'`,
    { transaction },
  );
  return new Set(rows.map((r) => r.conname));
};

/** Same, for indexes. */
const existingIndexNames = async (queryInterface, transaction) => {
  const [rows] = await queryInterface.sequelize.query(
    `SELECT indexname FROM pg_indexes WHERE schemaname = 'public'`,
    { transaction },
  );
  return new Set(rows.map((r) => r.indexname));
};

/** Sequelize's default index name when none is given: table_field_field. */
const defaultIndexName = (tableName, fields) =>
  `${tableName}_${fields.map((f) => (typeof f === 'string' ? f : f.name || f.attribute)).join('_')}`;

export async function up(queryInterface, Sequelize, transaction) {
  const models = Object.values(sequelize.models);

  // A database created by the old sequelize.sync() already has most of
  // this. Rather than failing on the first thing that exists, skip what is
  // already there and create only what is missing.
  // Named with an `existing` prefix on purpose: step 3 below declares its
  // own `indexes` for each model's declared indexes, and a bare `indexes`
  // here was shadowed by it — the Set silently became an array and
  // `.has()` stopped existing.
  const existingConstraints = await existingConstraintNames(queryInterface, transaction);
  const existingIndexes = await existingIndexNames(queryInterface, transaction);

  // 1) Tables, columns only — no FK constraints yet.
  for (const model of models) {
    const tableName = model.getTableName();
    const columns = {};
    for (const [name, attr] of Object.entries(model.rawAttributes)) {
      if (!isPlainAttribute(attr)) continue;
      columns[attr.field || name] = toColumnDefinition(attr);
    }
    await queryInterface.createTable(tableName, columns, { transaction });
  }

  // 2) FK constraints, now that every referenced table exists.
  for (const model of models) {
    const tableName = model.getTableName();
    for (const [name, attr] of Object.entries(model.rawAttributes)) {
      if (!isPlainAttribute(attr) || !attr.references) continue;
      const columnName = attr.field || name;
      const refTable = typeof attr.references.model === 'string'
        ? attr.references.model
        : attr.references.model?.tableName;
      if (!refTable) continue;

      const constraintName = `fk_${tableName}_${columnName}`;
      // sync() names its foreign keys <table>_<column>_fkey. Adding ours
      // alongside would leave the column with two identical constraints.
      if (existingConstraints.has(constraintName) || existingConstraints.has(`${tableName}_${columnName}_fkey`)) continue;

      await queryInterface.addConstraint(tableName, {
        fields: [columnName],
        type: 'foreign key',
        name: constraintName,
        references: { table: refTable, field: attr.references.key || 'id' },
        onDelete: attr.onDelete || 'CASCADE',
        onUpdate: attr.onUpdate || 'CASCADE',
        transaction,
      });
    }
  }

  // 3) Explicit indexes each model declares (define({...}, { indexes: [...] })).
  for (const model of models) {
    const tableName = model.getTableName();
    const declaredIndexes = model.options?.indexes || [];
    for (const index of declaredIndexes) {
      if (!index.fields || index.fields.length === 0) continue;

      const indexName = index.name || defaultIndexName(tableName, index.fields);
      // A column declared `unique: true` already produced an index under
      // this exact name, either from sync() or from the CREATE TABLE above.
      if (existingIndexes.has(indexName)) continue;

      await queryInterface.addIndex(tableName, index.fields, {
        unique: Boolean(index.unique),
        name: index.name,
        transaction,
      });
      // Track it, so two models declaring the same index don't collide
      // within this single run.
      existingIndexes.add(indexName);
    }
  }
}

export async function down(queryInterface, Sequelize, transaction) {
  const models = Object.values(sequelize.models);
  // FK constraints reference each other, so CASCADE drop avoids needing a
  // manual reverse dependency order.
  for (const model of models) {
    await queryInterface.dropTable(model.getTableName(), { cascade: true, transaction });
  }
}