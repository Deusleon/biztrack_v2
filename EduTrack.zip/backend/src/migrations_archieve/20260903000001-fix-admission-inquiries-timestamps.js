// FILE PATH: backend/src/migrations/20260903000001-fix-admission-inquiries-timestamps.js
/**
 * Fixes a bug in 20260903000000-create-admission-inquiries.js: it created
 * literal `createdAt`/`updatedAt` columns, but config/database.js sets
 * `underscored: true` globally, so every model — including
 * AdmissionInquiry — actually queries `created_at`/`updated_at`. That
 * mismatch is what produced "column created_at does not exist".
 *
 * Safe to run whether or not you already had the broken migration applied:
 * it checks the actual column names first and only renames what's needed.
 */
export async function up(queryInterface, Sequelize, transaction) {
  const table = await queryInterface.describeTable('admission_inquiries');

  if (table.createdAt && !table.created_at) {
    await queryInterface.renameColumn('admission_inquiries', 'createdAt', 'created_at', { transaction });
  }
  if (table.updatedAt && !table.updated_at) {
    await queryInterface.renameColumn('admission_inquiries', 'updatedAt', 'updated_at', { transaction });
  }
}

export async function down(queryInterface, Sequelize, transaction) {
  const table = await queryInterface.describeTable('admission_inquiries');

  if (table.created_at && !table.createdAt) {
    await queryInterface.renameColumn('admission_inquiries', 'created_at', 'createdAt', { transaction });
  }
  if (table.updated_at && !table.updatedAt) {
    await queryInterface.renameColumn('admission_inquiries', 'updated_at', 'updatedAt', { transaction });
  }
}