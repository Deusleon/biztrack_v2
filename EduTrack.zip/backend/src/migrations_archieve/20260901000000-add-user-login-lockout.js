// backend/src/migrations/20260901000000-add-user-login-lockout.js

export async function up(queryInterface, Sequelize) {
  const table = await queryInterface.describeTable('users');

  if (!table.failed_login_attempts) {
    await queryInterface.addColumn('users', 'failed_login_attempts', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 0,
    });
  }

  if (!table.locked_until) {
    await queryInterface.addColumn('users', 'locked_until', {
      type: Sequelize.DATE,
      allowNull: true,
    });
  }
}

export async function down(queryInterface, Sequelize) {
  await queryInterface.removeColumn('users', 'failed_login_attempts');
  await queryInterface.removeColumn('users', 'locked_until');
}
