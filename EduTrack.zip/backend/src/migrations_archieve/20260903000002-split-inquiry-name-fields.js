// FILE PATH: backend/src/migrations/20260903000002-split-inquiry-name-fields.js
/**
 * Aligns admission_inquiries with pages/Student/AdmissionForm.jsx, which
 * asks for first/middle/last name separately, not one combined name.
 * Also drops the NOT NULL constraint on email — only name and phone are
 * required of a family applying (see admissionInquiryController.js).
 *
 * student_name is dropped rather than split programmatically: any row
 * already sitting in this table predates the fix in this same session,
 * so there's nothing in production yet to preserve.
 */
export async function up(queryInterface, Sequelize, transaction) {
  await queryInterface.addColumn('admission_inquiries', 'first_name', {
    type: Sequelize.DataTypes.STRING,
    allowNull: true, // filled in immediately below, then locked down
  }, { transaction });
  await queryInterface.addColumn('admission_inquiries', 'middle_name', {
    type: Sequelize.DataTypes.STRING,
    allowNull: true,
  }, { transaction });
  await queryInterface.addColumn('admission_inquiries', 'last_name', {
    type: Sequelize.DataTypes.STRING,
    allowNull: true, // filled in immediately below, then locked down
  }, { transaction });

  // Best-effort backfill for any row that already exists, splitting on
  // the first space so nothing is silently dropped.
  await queryInterface.sequelize.query(
    `UPDATE admission_inquiries
     SET first_name = COALESCE(NULLIF(split_part(student_name, ' ', 1), ''), 'Unknown'),
         last_name = COALESCE(NULLIF(substring(student_name from position(' ' in student_name) + 1), ''), 'Applicant')
     WHERE student_name IS NOT NULL`,
    { transaction },
  );

  await queryInterface.changeColumn('admission_inquiries', 'first_name', {
    type: Sequelize.DataTypes.STRING,
    allowNull: false,
  }, { transaction });
  await queryInterface.changeColumn('admission_inquiries', 'last_name', {
    type: Sequelize.DataTypes.STRING,
    allowNull: false,
  }, { transaction });

  await queryInterface.removeColumn('admission_inquiries', 'student_name', { transaction });

  await queryInterface.changeColumn('admission_inquiries', 'email', {
    type: Sequelize.DataTypes.STRING,
    allowNull: true,
  }, { transaction });
}

export async function down(queryInterface, Sequelize, transaction) {
  await queryInterface.addColumn('admission_inquiries', 'student_name', {
    type: Sequelize.DataTypes.STRING,
    allowNull: true,
  }, { transaction });
  await queryInterface.sequelize.query(
    `UPDATE admission_inquiries
     SET student_name = TRIM(CONCAT_WS(' ', first_name, middle_name, last_name))`,
    { transaction },
  );
  await queryInterface.changeColumn('admission_inquiries', 'student_name', {
    type: Sequelize.DataTypes.STRING,
    allowNull: false,
  }, { transaction });

  await queryInterface.removeColumn('admission_inquiries', 'first_name', { transaction });
  await queryInterface.removeColumn('admission_inquiries', 'middle_name', { transaction });
  await queryInterface.removeColumn('admission_inquiries', 'last_name', { transaction });

  await queryInterface.changeColumn('admission_inquiries', 'email', {
    type: Sequelize.DataTypes.STRING,
    allowNull: false,
  }, { transaction });
}