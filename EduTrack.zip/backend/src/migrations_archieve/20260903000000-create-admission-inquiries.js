// FILE PATH: backend/src/migrations/20260903000000-create-admission-inquiries.js
/**
 * Admission inquiries — applications submitted through a tenant's public
 * website (see routes/publicRoutes.js), before any staff review. These
 * are intentionally NOT Students yet: the Student model's status enum
 * (active/inactive/graduated/transferred/expelled) has no "applicant"
 * state, and a stranger submitting a public form shouldn't create a real
 * student/user record without a staff member reviewing it first. Staff
 * review these under Students → Online Applications and, once ready,
 * admit the child through the existing Admission Form (pages/Student/
 * AdmissionForm.jsx) — this table just tracks the inquiry up to that point.
 */
export async function up(queryInterface, Sequelize, transaction) {
  await queryInterface.createTable('admission_inquiries', {
    id: {
      type: Sequelize.DataTypes.UUID,
      defaultValue: Sequelize.DataTypes.UUIDV4,
      primaryKey: true,
    },
    tenant_id: {
      type: Sequelize.DataTypes.UUID,
      allowNull: false,
      references: { model: 'tenants', key: 'id' },
      onDelete: 'CASCADE',
    },
    reference: {
      // Shown to the applicant as a follow-up code, e.g. "RF-M5X2-9K3P".
      type: Sequelize.DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    student_name: { type: Sequelize.DataTypes.STRING, allowNull: false },
    date_of_birth: { type: Sequelize.DataTypes.DATEONLY, allowNull: true },
    gender: { type: Sequelize.DataTypes.ENUM('male', 'female', 'other'), allowNull: true },
    desired_class: { type: Sequelize.DataTypes.STRING, allowNull: true },
    parent_name: { type: Sequelize.DataTypes.STRING, allowNull: false },
    email: { type: Sequelize.DataTypes.STRING, allowNull: false },
    phone: { type: Sequelize.DataTypes.STRING, allowNull: false },
    address: { type: Sequelize.DataTypes.TEXT, allowNull: true },
    message: { type: Sequelize.DataTypes.TEXT, allowNull: true },
    status: {
      // new: just submitted, nobody has looked at it yet.
      // contacted: a staff member has reached out to the family.
      // enrolled: staff went ahead and admitted the child via the normal
      //   Admission Form; kept for the office's own record-keeping.
      // declined: the school isn't taking this application further.
      type: Sequelize.DataTypes.ENUM('new', 'contacted', 'enrolled', 'declined'),
      allowNull: false,
      defaultValue: 'new',
    },
    staff_notes: { type: Sequelize.DataTypes.TEXT, allowNull: true },
    source: {
      // Always 'website' today; kept open in case a walk-in or phone
      // inquiry ever needs logging the same way.
      type: Sequelize.DataTypes.STRING,
      allowNull: false,
      defaultValue: 'website',
    },
    // NOTE: named created_at/updated_at (snake_case), not createdAt/
    // updatedAt — config/database.js sets `underscored: true` globally,
    // so every model (AdmissionInquiry included) expects snake_case
    // timestamp columns even though the JS-side attribute is camelCase.
    created_at: { type: Sequelize.DataTypes.DATE, allowNull: false, defaultValue: Sequelize.DataTypes.NOW },
    updated_at: { type: Sequelize.DataTypes.DATE, allowNull: false, defaultValue: Sequelize.DataTypes.NOW },
  }, { transaction });

  await queryInterface.addIndex('admission_inquiries', ['tenant_id', 'status'], { transaction });
  await queryInterface.addIndex('admission_inquiries', ['tenant_id', 'created_at'], { transaction });
}

export async function down(queryInterface, Sequelize, transaction) {
  await queryInterface.dropTable('admission_inquiries', { transaction });
}