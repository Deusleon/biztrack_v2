// FILE PATH: backend/tests/setup.js
/**
 * Loaded before every test file (see the "test" script in package.json: node --import ./tests/setup.js --test).
 *
 * It makes the suite behave the same on every machine, whatever is in the developer's own .env:
 *   - NODE_ENV=test switches off the login/reset rate limiters and the automatic safety backups, which would
 *     otherwise answer 429 or slow every test down;
 *   - the two "standard starting password" settings are pinned to their documented defaults, because tests check
 *     that those exact passwords are handled correctly (an .env that changes them must not change the tests).
 * Real database settings still come from .env (use a TEST database — the suite creates and deletes rows).
 */
process.env.NODE_ENV = 'test';
process.env.STAFF_DEFAULT_PASSWORD = 'Staff@2026';
process.env.STUDENT_DEFAULT_PASSWORD = 'Student@2026';
