/**
 * reports-academic-year.test.js
 *
 * - Enrollment report: previously counted every class from every year
 *   together with no year filter at all, AND used a plain
 *   `Student.where({class_id})` for the roster (wrong for a past year's
 *   class once promotion has moved students on — the same bug already
 *   fixed for Fee Status / Marks Sheet / Class Results).
 * - Attendance Summary: previously always defaulted to "the last 30
 *   days" regardless of the selected academic year.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import { Class, Student, User, StudentPromotion, Attendance } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';
import { randomUUID } from 'crypto';

describe('Reports — scoped to the selected academic year', () => {
  let fixture;
  let form1_2026;
  let form2_2027;
  let movedStudent;

  before(async () => {
    fixture = await buildTenantFixture('reportsyear');
    const { tenant, campus } = fixture;
    await tenant.update({ settings: { academic_records_start_year: 2020 } });

    form1_2026 = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form I', grade: '1',
      education_level: 'o_level', academic_year: '2026', status: 'active',
    });
    form2_2027 = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form II', grade: '2',
      education_level: 'o_level', academic_year: '2027', status: 'active',
    });

    const user = await User.create({
      tenant_id: tenant.id, email: `moved-${tenant.slug}@example.test`, password: 'Password123!',
      first_name: 'Moved', last_name: 'Pupil', role: 'student', status: 'active',
    });
    movedStudent = await Student.create({
      tenant_id: tenant.id, user_id: user.id, campus_id: campus.id,
      admission_number: `ADM-moved-${tenant.slug}`, class_id: form2_2027.id,
      gender: 'female', status: 'active',
    });

    await StudentPromotion.create({
      tenant_id: tenant.id, student_id: movedStudent.id, batch_id: randomUUID(), action: 'promoted',
      from_class_id: form1_2026.id, to_class_id: form2_2027.id,
      from_academic_year: '2026-2027', to_academic_year: '2027-2028',
    });

    await Attendance.create({
      tenant_id: tenant.id, student_id: movedStudent.id, class_id: form1_2026.id,
      date: '2026-10-05', status: 'present',
    });
  });

  after(closeDb);

  test('Enrollment report for 2026 still counts the student under Form I, even though they are now in Form II', async () => {
    const res = await request(app)
      .get('/api/v1/reports/enrollment')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2026-2027' });

    assert.equal(res.status, 200);
    const form1Row = res.body.data.rows.find((r) => r.class_name === 'Form I');
    assert.ok(form1Row, 'Form I missing from the 2026 enrollment report');
    assert.equal(form1Row.total, 1);
    assert.equal(form1Row.female, 1);
    // Form II (2027) must NOT appear at all when viewing 2026 — it's a
    // different year's class row entirely.
    assert.equal(res.body.data.rows.find((r) => r.class_name === 'Form II'), undefined);
  });

  test('Enrollment report for 2027 counts the SAME student under Form II instead', async () => {
    const res = await request(app)
      .get('/api/v1/reports/enrollment')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2027-2028' });

    assert.equal(res.status, 200);
    const form2Row = res.body.data.rows.find((r) => r.class_name === 'Form II');
    assert.ok(form2Row, 'Form II missing from the 2027 enrollment report');
    assert.equal(form2Row.total, 1);
    assert.equal(res.body.data.rows.find((r) => r.class_name === 'Form I'), undefined);
  });

  test('Attendance Summary with no explicit dates defaults to the SELECTED academic year\'s window, not the last 30 days', async () => {
    const res = await request(app)
      .get('/api/v1/reports/attendance-summary')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2026-2027' });

    assert.equal(res.status, 200);
    // School years run January–December, and the base year of a span label is used.
    assert.equal(res.body.data.start_date, '2026-01-01');
    assert.equal(res.body.data.end_date, '2026-12-31');
    const row = res.body.data.rows.find((r) => r.class_name === 'Form I');
    assert.ok(row, 'Form I attendance missing from the report');
    assert.equal(row.present, 1);
  });

  test('An explicit date range still overrides the academic-year default', async () => {
    const res = await request(app)
      .get('/api/v1/reports/attendance-summary')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2026-2027', start_date: '2026-01-01', end_date: '2026-01-31' });

    assert.equal(res.status, 200);
    assert.equal(res.body.data.start_date, '2026-01-01');
    assert.equal(res.body.data.end_date, '2026-01-31');
  });
});
