/**
 * The gateway endpoints save, return and remember the system sender next to the school sender.
 * (Gateway settings are developer-only, so the test admin's email is listed in DEVELOPER_EMAILS.)
 */
import '../helpers/noMail.js';
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import request from 'supertest';
import app from '../../src/server.js';
import { buildTenantFixture, closeDb } from '../helpers/testFixture.js';

const bearer = (user) => ({ Authorization: `Bearer ${jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '2h' })}` });

describe('system sender ids through the API', () => {
  let admin;
  before(async () => {
    ({ admin } = await buildTenantFixture('senders'));
    process.env.DEVELOPER_EMAILS = admin.email;
  });
  after(async () => { delete process.env.DEVELOPER_EMAILS; await closeDb(); });

  test('SMS: both senders are saved, returned, and remembered per provider', async () => {
    const put = await request(app).put('/api/v1/messaging/sms/gateway').set(bearer(admin))
      .send({ provider: 'meseji', api_key: 'key-1', sender_id: 'MYSCHOOL', system_sender_id: 'EDUTRACK' });
    assert.equal(put.status, 200);
    assert.equal(put.body.data.sender_id, 'MYSCHOOL');
    assert.equal(put.body.data.system_sender_id, 'EDUTRACK');

    // switch to another provider and back: the meseji pair must still be there
    await request(app).put('/api/v1/messaging/sms/gateway').set(bearer(admin)).send({ provider: 'nextsms', api_key: 'u', api_secret: 'p', sender_id: 'NEXTA', system_sender_id: 'NEXTSYS' });
    const mid = await request(app).get('/api/v1/messaging/sms/gateway').set(bearer(admin));
    assert.equal(mid.body.data.saved_credentials.meseji.system_sender_id, 'EDUTRACK');
    const back = await request(app).put('/api/v1/messaging/sms/gateway').set(bearer(admin)).send({ provider: 'meseji' });
    assert.equal(back.body.data.sender_id, 'MYSCHOOL');
    assert.equal(back.body.data.system_sender_id, 'EDUTRACK');
  });

  test('SMS: clearing the system sender makes system messages use the school sender again', async () => {
    const put = await request(app).put('/api/v1/messaging/sms/gateway').set(bearer(admin)).send({ system_sender_id: '' });
    assert.equal(put.body.data.system_sender_id, '');
  });

  test('email: the system From address is saved and returned', async () => {
    const put = await request(app).put('/api/v1/messaging/email/gateway').set(bearer(admin))
      .send({ from_email: 'news@school.test', from_name: 'My School', system_from_email: 'no-reply@edutrack.test', system_from_name: 'EduTrack' });
    assert.equal(put.status, 200);
    const get = await request(app).get('/api/v1/messaging/email/gateway').set(bearer(admin));
    assert.equal(get.body.data.system_from_email, 'no-reply@edutrack.test');
    assert.equal(get.body.data.system_from_name, 'EduTrack');
    assert.equal(get.body.data.from_email, 'news@school.test');
  });

  test('only the platform developer can see or change any of it', async () => {
    delete process.env.DEVELOPER_EMAILS;
    assert.equal((await request(app).get('/api/v1/messaging/sms/gateway').set(bearer(admin))).status, 403);
    assert.equal((await request(app).put('/api/v1/messaging/email/gateway').set(bearer(admin)).send({ system_from_name: 'x' })).status, 403);
    process.env.DEVELOPER_EMAILS = admin.email;
  });
});
