/**
 * The production seed: only what a real installation needs, safe to repeat, never a default password.
 */
import '../helpers/noMail.js';
import { test, describe, after } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { seedProduction, seedPasswordProblem, slugify, SeedError } from '../../src/utils/seedProduction.js';
import { Tenant, Campus, User, Student, Staff, Class, SubscriptionPlan } from '../../src/models/index.js';
import { closeDb } from '../helpers/testFixture.js';

const KEYS = ['SEED_SCHOOL_NAME', 'SEED_SCHOOL_SLUG', 'SEED_ADMIN_EMAIL', 'SEED_ADMIN_PASSWORD', 'SEED_DEVELOPER_EMAIL', 'SEED_DEVELOPER_PASSWORD', 'SEED_SCHOOL_EMAIL'];
const withEnv = async (values, fn) => {
  const saved = Object.fromEntries(KEYS.map((k) => [k, process.env[k]]));
  KEYS.forEach((k) => delete process.env[k]);
  Object.assign(process.env, values);
  try { return await fn(); } finally { KEYS.forEach((k) => { if (saved[k] === undefined) delete process.env[k]; else process.env[k] = saved[k]; }); }
};
// the test database is shared, so use a throwaway console
const quiet = async (fn) => { const log = console.log; console.log = () => {}; try { return await fn(); } finally { console.log = log; } };

describe('production seed', () => {
  after(closeDb);

  test('passwords: nothing short, simple or well-known is accepted', () => {
    assert.match(seedPasswordProblem(''), /missing/);
    assert.match(seedPasswordProblem('short1'), /at least 10/);
    assert.match(seedPasswordProblem('onlyletterslong'), /letters and numbers/);
    assert.match(seedPasswordProblem('Admin@12345'), /default/);
    assert.match(seedPasswordProblem('password12345'), /default/);
    assert.equal(seedPasswordProblem('a-long-pass-2026'), null);
  });

  test('a school name becomes a clean slug', () => {
    assert.equal(slugify('Lucy Lameck Secondary School'), 'lucy-lameck-secondary-school');
    assert.equal(slugify('  St. Mary\'s & Co. — Kinondoni  '), 'st-mary-s-co-kinondoni');
  });

  test('creates the school, its campus and its administrator — and nothing else', async () => {
    const id = randomUUID().slice(0, 8);
    const slug = `prodseed-${id}`;
    const email = `admin-${id}@prodseed.test`;
    await quiet(() => withEnv({ SEED_SCHOOL_NAME: `Prod Seed ${id}`, SEED_SCHOOL_SLUG: slug, SEED_ADMIN_EMAIL: email, SEED_ADMIN_PASSWORD: 'a-long-pass-2026' }, seedProduction));

    const tenant = await Tenant.findOne({ where: { slug } });
    assert.ok(tenant);
    assert.equal(await Campus.count({ where: { tenant_id: tenant.id } }), 1);
    const admin = await User.findOne({ where: { email } });
    assert.equal(admin.role, 'admin');
    assert.equal(admin.must_change_password, true, 'the first login must choose its own password');
    assert.notEqual(admin.password, 'a-long-pass-2026', 'stored hashed');
    for (const model of [Student, Staff, Class]) assert.equal(await model.count({ where: { tenant_id: tenant.id } }), 0, `${model.name} must start empty`);
    assert.ok(await SubscriptionPlan.count() >= 3, 'the subscription plans exist');

    // again: nothing duplicated, no password needed, nothing changed
    await quiet(() => withEnv({ SEED_SCHOOL_NAME: `Prod Seed ${id}`, SEED_SCHOOL_SLUG: slug, SEED_ADMIN_EMAIL: email }, seedProduction));
    assert.equal(await Tenant.count({ where: { slug } }), 1);
    assert.equal(await Campus.count({ where: { tenant_id: tenant.id } }), 1);
    assert.equal(await User.count({ where: { email } }), 1);
  });

  test('refuses to create an administrator with a weak password, and creates nothing', async () => {
    const id = randomUUID().slice(0, 8);
    const slug = `prodseed-weak-${id}`;
    await assert.rejects(
      quiet(() => withEnv({ SEED_SCHOOL_NAME: `Weak ${id}`, SEED_SCHOOL_SLUG: slug, SEED_ADMIN_EMAIL: `weak-${id}@prodseed.test`, SEED_ADMIN_PASSWORD: 'Admin@123' }, seedProduction)),
      (err) => err instanceof SeedError && /SEED_ADMIN_PASSWORD/.test(err.message),
    );
    assert.equal(await Tenant.count({ where: { slug } }), 0);
  });

  test('without a school name it only makes sure the plans exist', async () => {
    const before = await Tenant.count();
    await quiet(() => withEnv({}, seedProduction));
    assert.equal(await Tenant.count(), before);
  });
});
