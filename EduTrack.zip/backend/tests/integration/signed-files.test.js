/**
 * signed-files.test.js
 *
 * Uploaded files (photos, certificates, receipts) are served only with a valid,
 * unexpired signature — and the API puts that signature on every file address it
 * returns, so screens keep working without changes.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'crypto';
import request from 'supertest';
import app from '../../src/server.js';
import { User } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';
import { signUploadUrl } from '../../src/utils/signedFiles.js';

const root = path.resolve(process.env.UPLOAD_PATH || './uploads');

describe('Uploaded files need a signed link', () => {
  let fx; let dir; let name; let file; let urlPath;
  const sign = (pathname, exp) => crypto.createHmac('sha256', process.env.JWT_SECRET).update(`${pathname}|${exp}`).digest('hex').slice(0, 32);

  before(async () => {
    fx = await buildTenantFixture('files');
    dir = path.join(root, 'zz-test-signed');
    fs.mkdirSync(dir, { recursive: true });
    name = `${Date.now()}-${randomUUID().slice(0, 8)}.txt`;
    file = path.join(dir, name);
    fs.writeFileSync(file, 'the contents of a private document');
    urlPath = `/uploads/zz-test-signed/${name}`;
  });
  after(async () => { fs.rmSync(dir, { recursive: true, force: true }); await closeDb(); });

  test('without a signature the file is refused — never served', async () => {
    const res = await request(app).get(urlPath);
    assert.equal(res.status, 403);
    assert.ok(!res.text.includes('private document'));
  });

  test('with the signature the API gives out, it is served', async () => {
    const signed = signUploadUrl(`http://localhost:5000${urlPath}`).replace('http://localhost:5000', '');
    const res = await request(app).get(signed);
    assert.equal(res.status, 200);
    assert.equal(res.text, 'the contents of a private document');
  });

  test('an altered, expired, or someone-else\'s signature is refused', async () => {
    const good = signUploadUrl(urlPath);
    const [base, query] = good.split('?');
    const params = new URLSearchParams(query);

    const tampered = new URLSearchParams(params); tampered.set('sig', `${params.get('sig').slice(0, -1)}${params.get('sig').endsWith('0') ? '1' : '0'}`);
    assert.equal((await request(app).get(`${base}?${tampered}`)).status, 403, 'edited signature');

    const longer = new URLSearchParams(params); longer.set('exp', String(Number(params.get('exp')) + 86400000));
    assert.equal((await request(app).get(`${base}?${longer}`)).status, 403, 'extended expiry');

    const past = Date.now() - 1000;
    assert.equal((await request(app).get(`${base}?exp=${past}&sig=${sign(urlPath, past)}`)).status, 403, 'correct but expired');

    const other = signUploadUrl('/uploads/zz-test-signed/another-file.txt');
    assert.equal((await request(app).get(`${base}?${other.split('?')[1]}`)).status, 403, 'a signature made for a different file');
  });

  test('it cannot be used to read other files on the server', async () => {
    for (const attack of ['/uploads/../.env', '/uploads/%2e%2e/package.json', '/uploads/zz-test-signed/../../package.json']) {
      const res = await request(app).get(attack);
      assert.ok([403, 404].includes(res.status), `${attack} → ${res.status}`);
      assert.ok(!res.text.includes('"name"'), attack);
    }
  });

  test('the same file gets the same link through the day, so the browser can cache it', () => {
    const a = signUploadUrl(urlPath, Date.UTC(2026, 9, 20, 7, 0));
    const b = signUploadUrl(urlPath, Date.UTC(2026, 9, 20, 11, 59));
    assert.equal(a, b);
    assert.notEqual(a, signUploadUrl(urlPath, Date.UTC(2026, 9, 20, 13, 0)));
  });

  test('every file address in an API response arrives already signed', async () => {
    const user = await User.create({
      tenant_id: fx.tenant.id, email: `p-${randomUUID().slice(0, 8)}@example.test`, password: 'Photo#12345', first_name: 'With', last_name: 'Photo',
      role: 'teacher', status: 'active', avatar: `http://localhost:5000${urlPath}`,
    });
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    const me = await request(app).get('/api/v1/auth/me').set({ Authorization: `Bearer ${token}` });
    assert.match(me.body.data.avatar, /\?exp=\d+&sig=[0-9a-f]{32}$/);
    // …and the link it came with actually opens the file.
    const fetched = await request(app).get(me.body.data.avatar.replace('http://localhost:5000', ''));
    assert.equal(fetched.status, 200);
  });

  test('text that merely looks like a file address is not turned into a link', async () => {
    const user = await User.create({
      tenant_id: fx.tenant.id, email: `n-${randomUUID().slice(0, 8)}@example.test`, password: 'Photo#12345', first_name: urlPath, last_name: 'Typed',
      role: 'teacher', status: 'active',
    });
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    const me = await request(app).get('/api/v1/auth/me').set({ Authorization: `Bearer ${token}` });
    assert.equal(me.body.data.first_name, urlPath, 'a name field is left exactly as typed');
  });

  test('a signed link does not need a login — but getting one does', async () => {
    assert.equal((await request(app).get('/api/v1/auth/me')).status, 401);
  });
});
