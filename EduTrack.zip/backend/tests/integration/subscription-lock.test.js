/**
 * subscription-lock.test.js
 *
 * What an expired or cancelled subscription does, and what a payment undoes:
 *   - every area closes (402) except the ones a school needs in order to pay;
 *   - that applies to a school's super_admin too — only the platform developer is exempt;
 *   - a confirmed payment unlocks at once, and is applied exactly once however many
 *     confirmations arrive;
 *   - the invoice's pay link and the receipt's verification code, public and signed;
 *   - cancelling an invoice, and the school-wide display settings.
 */
import '../helpers/noMail.js';
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import request from 'supertest';
import app from '../../src/server.js';
import { User, Subscription, SubscriptionInvoice, SubscriptionPlan, AuditLog } from '../../src/models/index.js';
import { seedSubscriptionPlans } from '../../src/utils/seedSubscriptionPlans.js';
import { applyPaidInvoice } from '../../src/controllers/subscriptionController.js';
import { generateSubscriptionReceiptCode, generateSubscriptionPayCode } from '../../src/utils/receiptSecurity.js';
import { moneyFormatterFor, invalidateTenantDisplay } from '../../src/utils/tenantDisplay.js';
import { buildTenantFixture, closeDb } from '../helpers/testFixture.js';

const DAY = 86400000;
const bearer = (user) => ({ Authorization: `Bearer ${jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '2h' })}` });

describe('subscription lock and payments', () => {
  let tenant, admin, superAdmin, teacher, subscription, plan;
  let nextInvoice = 1;

  const setWindow = (status, endsInDays) => subscription.update({ status, ends_at: new Date(Date.now() + endsInDays * DAY), grace_days: 2, cancelled_at: null });
  const makeInvoice = (over = {}) => SubscriptionInvoice.create({
    tenant_id: tenant.id, subscription_id: subscription.id, plan_id: plan.id,
    invoice_number: `INV-LOCKTEST-${Date.now()}-${nextInvoice++}`, order_reference: `EDULOCK${Date.now()}${nextInvoice++}`,
    line_items: [{ label: 'Standard plan — termly', amount: 320000 }], billing_cycle: 'termly',
    subtotal: 320000, proration_credit: 0, total: 320000, currency: 'TZS', status: 'pending', kind: 'new',
    gateway: null, period_start: new Date(), period_end: new Date(Date.now() + 120 * DAY), ...over,
  });

  before(async () => {
    await seedSubscriptionPlans();
    plan = await SubscriptionPlan.findOne({ where: { code: 'standard' } });
    const fx = await buildTenantFixture('sublock');
    tenant = fx.tenant; admin = fx.admin;
    const uniq = tenant.slug;
    superAdmin = await User.create({ tenant_id: tenant.id, email: `super-${uniq}@example.test`, password: 'Password123!', first_name: 'School', last_name: 'Super', role: 'super_admin', status: 'active' });
    teacher = await User.create({ tenant_id: tenant.id, email: `teacher-${uniq}@example.test`, password: 'Password123!', first_name: 'Tea', last_name: 'Cher', role: 'teacher', status: 'active' });
    subscription = await Subscription.create({ tenant_id: tenant.id, status: 'expired', plan_id: plan.id, billing_cycle: 'monthly', ends_at: new Date(Date.now() - 10 * DAY), grace_days: 2 });
  });
  after(async () => { delete process.env.DEVELOPER_EMAILS; await closeDb(); });

  describe('the lock', () => {
    const CLOSED = ['/api/v1/students', '/api/v1/classes', '/api/v1/fees/structures', '/api/v1/exams', '/api/v1/staff'];
    const OPEN = ['/api/v1/subscription/me', '/api/v1/notifications', '/api/v1/auth/me'];

    test('an expired subscription closes every area with 402 for the school admin', async () => {
      await setWindow('expired', -10);
      for (const url of CLOSED) {
        const res = await request(app).get(url).set(bearer(admin));
        assert.equal(res.status, 402, `${url} should be closed`);
        assert.equal(res.body.code, 'SUBSCRIPTION_EXPIRED');
      }
    });

    test('but the school can still reach what it needs to pay', async () => {
      for (const url of OPEN) {
        const res = await request(app).get(url).set(bearer(admin));
        assert.notEqual(res.status, 402, `${url} must stay open`);
      }
      const me = await request(app).get('/api/v1/subscription/me').set(bearer(admin));
      assert.equal(me.body.data.evaluation.locked, true);
      assert.equal(me.body.data.enforced, true);
    });

    test('a school\'s own super_admin is locked too; so is everyone else', async () => {
      assert.equal((await request(app).get('/api/v1/students').set(bearer(superAdmin))).status, 402);
      assert.equal((await request(app).get('/api/v1/classes').set(bearer(teacher))).status, 402);
    });

    test('only the platform developer (super_admin listed in DEVELOPER_EMAILS) is never locked', async () => {
      process.env.DEVELOPER_EMAILS = superAdmin.email;
      try {
        assert.notEqual((await request(app).get('/api/v1/students').set(bearer(superAdmin))).status, 402);
        const me = await request(app).get('/api/v1/subscription/me').set(bearer(superAdmin));
        assert.equal(me.body.data.enforced, false);
        // the same email on an ordinary admin account does NOT bypass: the role must be super_admin
        process.env.DEVELOPER_EMAILS = admin.email;
        assert.equal((await request(app).get('/api/v1/students').set(bearer(admin))).status, 402);
      } finally { delete process.env.DEVELOPER_EMAILS; }
    });

    test('active and grace-period subscriptions are open; a cancelled one is locked at once', async () => {
      await setWindow('active', 30);
      assert.notEqual((await request(app).get('/api/v1/students').set(bearer(admin))).status, 402);
      await setWindow('active', -1);               // ended yesterday, 2-day grace
      assert.notEqual((await request(app).get('/api/v1/students').set(bearer(admin))).status, 402);
      await setWindow('cancelled', 30);            // paid until next month, but cancelled
      assert.equal((await request(app).get('/api/v1/students').set(bearer(admin))).status, 402);
    });
  });

  describe('a payment unlocks, exactly once', () => {
    test('confirming a payment reopens the school immediately and starts a new window', async () => {
      await setWindow('expired', -10);
      await subscription.update({ reminders_sent: { window: 'old', d3: 'x' } });
      const invoice = await makeInvoice();
      assert.equal((await request(app).get('/api/v1/students').set(bearer(admin))).status, 402);

      await applyPaidInvoice(invoice, { source: 'test' });

      assert.notEqual((await request(app).get('/api/v1/students').set(bearer(admin))).status, 402);
      await subscription.reload();
      assert.equal(subscription.status, 'active');
      assert.deepEqual(subscription.reminders_sent, {}, 'a new paid window starts with no reminders sent');
      await invoice.reload();
      assert.equal(invoice.status, 'paid');
    });

    test('ten confirmations at once apply the payment once and leave one audit entry', async () => {
      await setWindow('expired', -10);
      const invoice = await makeInvoice();
      await Promise.all(Array.from({ length: 10 }, () => applyPaidInvoice(invoice, { source: 'race' })));
      await new Promise((r) => setTimeout(r, 400)); // the audit entry is written in the background
      const entries = await AuditLog.count({ where: { tenant_id: tenant.id, action: `Payment confirmed: invoice ${invoice.invoice_number} (TZS 320,000) paid` } });
      assert.equal(entries, 1);
      const paidAt = (await invoice.reload()).paid_at;
      await applyPaidInvoice(invoice, { source: 'late' });
      assert.equal(new Date((await invoice.reload()).paid_at).getTime(), new Date(paidAt).getTime(), 'a late confirmation must not change the payment');
    });
  });

  describe('invoices, receipts and their links', () => {
    test('checkout while payments are off still creates the invoice', async () => {
      await setWindow('expired', -10);
      const res = await request(app).post('/api/v1/subscription/checkout').set(bearer(admin)).send({ plan_id: plan.id, billing_cycle: 'termly' });
      assert.equal(res.status, 201);
      assert.equal(res.body.data.payment_started, false);
      assert.equal(res.body.data.invoice.status, 'pending');
    });

    test('an unpaid invoice carries a pay code, a paid one a verification code', async () => {
      const unpaid = await makeInvoice();
      const a = await request(app).get(`/api/v1/subscription/invoices/${unpaid.invoice_number}`).set(bearer(admin));
      assert.equal(a.status, 200);
      assert.equal(a.body.data.pay_code, generateSubscriptionPayCode(unpaid));
      assert.equal(a.body.data.verification_code, null);

      const paid = await makeInvoice({ status: 'paid', paid_at: new Date() });
      const b = await request(app).get(`/api/v1/subscription/invoices/${paid.invoice_number}`).set(bearer(admin));
      assert.equal(b.body.data.verification_code, generateSubscriptionReceiptCode(paid));
      assert.equal(b.body.data.pay_code, null);
      assert.match(b.body.data.receipt_number, /^RCT-LOCKTEST-/);
    });

    test('the public receipt check says valid for the real code and invalid for anything else', async () => {
      const paid = await makeInvoice({ status: 'paid', paid_at: new Date() });
      const code = generateSubscriptionReceiptCode(paid);
      const ok = await request(app).get(`/api/v1/verify/subscription-receipt/${paid.invoice_number}/${code}`);
      assert.equal(ok.body.data.valid, true);
      assert.equal(ok.body.data.amount, 320000);
      assert.equal((await request(app).get(`/api/v1/verify/subscription-receipt/${paid.invoice_number}/AAAAAAAAAA`)).body.data.valid, false);
      assert.equal((await request(app).get(`/api/v1/verify/subscription-receipt?receipt_no=${paid.invoice_number.replace('INV-', 'RCT-')}&code=${code}`)).body.data.valid, true);
      // the same code cannot vouch for a different invoice, or for an unpaid one
      const other = await makeInvoice({ status: 'paid', paid_at: new Date() });
      assert.equal((await request(app).get(`/api/v1/verify/subscription-receipt/${other.invoice_number}/${code}`)).body.data.valid, false);
      const unpaid = await makeInvoice();
      assert.equal((await request(app).get(`/api/v1/verify/subscription-receipt/${unpaid.invoice_number}/${generateSubscriptionReceiptCode(unpaid)}`)).body.data.valid, false);
    });

    test('the public pay page needs the signed code; it never sends a prompt when payments are off', async () => {
      const inv = await makeInvoice();
      const code = generateSubscriptionPayCode(inv);
      const view = await request(app).get(`/api/v1/public/subscription-pay/${inv.invoice_number}/${code}`);
      assert.equal(view.body.data.valid, true);
      assert.equal(view.body.data.amount, 320000);
      assert.equal(view.body.data.payments_available, false);
      assert.equal((await request(app).get(`/api/v1/public/subscription-pay/${inv.invoice_number}/BBBBBBBBBBBBBBBB`)).body.data.valid, false);
      const pay = await request(app).post(`/api/v1/public/subscription-pay/${inv.invoice_number}/${code}`).send({ phone: '0712345678' });
      assert.equal(pay.status, 400);
      assert.equal((await request(app).post(`/api/v1/public/subscription-pay/${inv.invoice_number}/BBBBBBBBBBBBBBBB`).send({ phone: '0712345678' })).status, 404);
    });

    test('a pay link is tied to the amount: re-pricing the invoice kills the old link', async () => {
      const inv = await makeInvoice();
      const code = generateSubscriptionPayCode(inv);
      await inv.update({ total: 1 });
      assert.equal((await request(app).get(`/api/v1/public/subscription-pay/${inv.invoice_number}/${code}`)).body.data.valid, false);
    });

    test('cancelling: an unpaid invoice can be cancelled, a paid or waiting one cannot', async () => {
      const unpaid = await makeInvoice();
      const code = generateSubscriptionPayCode(unpaid);
      assert.equal((await request(app).post(`/api/v1/subscription/invoices/${unpaid.invoice_number}/cancel`).set(bearer(admin))).status, 200);
      assert.equal((await request(app).get(`/api/v1/public/subscription-pay/${unpaid.invoice_number}/${code}`)).body.data.status, 'cancelled');
      assert.equal((await request(app).post(`/api/v1/subscription/invoices/${unpaid.invoice_number}/cancel`).set(bearer(admin))).status, 400);

      const paid = await makeInvoice({ status: 'paid', paid_at: new Date() });
      assert.equal((await request(app).post(`/api/v1/subscription/invoices/${paid.invoice_number}/cancel`).set(bearer(admin))).status, 400);
      const waiting = await makeInvoice({ status: 'processing', gateway: 'clickpesa' });
      assert.equal((await request(app).post(`/api/v1/subscription/invoices/${waiting.invoice_number}/cancel`).set(bearer(admin))).status, 400);
      assert.equal((await request(app).post(`/api/v1/subscription/invoices/${unpaid.invoice_number}/cancel`).set(bearer(teacher))).status, 403);
    });
  });

  describe('school-wide display settings', () => {
    test('an administrator saves them; a teacher cannot; bad values are refused', async () => {
      await setWindow('active', 30);
      const ok = await request(app).put('/api/v1/settings/display').set(bearer(admin)).send({ money_decimals: 2, date_format: 'D MMM YYYY' });
      assert.equal(ok.status, 200);
      assert.equal(ok.body.data.display.money_decimals, 2);
      const read = await request(app).get('/api/v1/settings').set(bearer(teacher));
      assert.equal(read.body.data.display.date_format, 'D MMM YYYY', 'everyone at the school reads the same setting');

      assert.equal((await request(app).put('/api/v1/settings/display').set(bearer(teacher)).send({ money_decimals: 0 })).status, 403);
      assert.equal((await request(app).put('/api/v1/settings/display').set(bearer(admin)).send({ money_decimals: 3 })).status, 400);
      assert.equal((await request(app).put('/api/v1/settings/display').set(bearer(admin)).send({ date_format: 'nonsense' })).status, 400);
      assert.equal((await request(app).put('/api/v1/settings/display').set(bearer(admin)).send({})).status, 400);
    });

    test('text the server writes follows the setting, and a change applies at once', async () => {
      await request(app).put('/api/v1/settings/display').set(bearer(admin)).send({ money_decimals: 2 });
      assert.equal((await moneyFormatterFor(tenant.id))(12345), '12,345.00');
      await request(app).put('/api/v1/settings/display').set(bearer(admin)).send({ money_decimals: 0 });
      assert.equal((await moneyFormatterFor(tenant.id))(12345), '12,345');
      invalidateTenantDisplay(tenant.id);
    });
  });
});
