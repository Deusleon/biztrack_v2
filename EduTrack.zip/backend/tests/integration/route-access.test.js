/**
 * route-access.test.js
 *
 * An access-control audit that stays in the suite. EduTrack used to check only
 * that you were logged in for most modules, so a student or parent could read
 * other students' phone numbers and addresses, staff salaries and bank details,
 * the school's expenses, and so on — and anyone at all could register as a
 * super admin. These tests keep that from coming back:
 *
 *   1. every route × every role is checked against the table in
 *      helpers/routePolicy.js (and every route must be in that table);
 *   2. the "your own record only" rules that a role list can't express;
 *   3. account creation and the payment webhook, which have no login.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'crypto';
import request from 'supertest';
import app from '../../src/server.js';
import {
  User, Student, Staff, Class, Campus, SubscriptionInvoice, Subscription, SubscriptionPlan,
} from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';
import { listRoutes, withIds } from '../helpers/routeInventory.js';
import { POLICY, ROLES } from '../helpers/routePolicy.js';

const bearer = (user) => ({ Authorization: `Bearer ${jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '2h' })}` });
// Routes that are public on purpose (no login) — each has its own tests below or elsewhere.
const PUBLIC = /^\/api\/v1\/(auth|webhooks|public|verify)(\/|$)/;
const reached = (status) => status !== 401 && status !== 403 && status !== 429;

describe('Access control', () => {
  let fx; let users; let other;
  const mkUser = (role, extra = {}) => User.create({
    tenant_id: fx.tenant.id, email: `${role}-${randomUUID().slice(0, 8)}@example.test`, password: 'Password123!',
    first_name: role, last_name: 'Tester', role, status: 'active',
    phone: `07${Math.floor(10000000 + Math.random() * 89999999)}`, ...extra,
  });

  before(async () => {
    fx = await buildTenantFixture('access');
    other = await buildTenantFixture('access-other');
    users = { admin: fx.admin };
    for (const role of ROLES) if (role !== 'admin') users[role] = await mkUser(role);
  });
  after(closeDb);

  describe('every route, every role', () => {
    test('the app and the policy table describe the same routes', async () => {
      const routes = (await listRoutes()).filter((r) => !PUBLIC.test(r.path));
      const actual = new Set(routes.map((r) => `${r.method} ${r.path.replace('/api/v1', '')}`));
      const declared = new Set(POLICY.map(([key]) => key));
      const unlisted = [...actual].filter((k) => !declared.has(k));
      const stale = [...declared].filter((k) => !actual.has(k));
      assert.deepEqual(unlisted, [], `Routes with no access policy — add them to tests/helpers/routePolicy.js: ${unlisted.join(', ')}`);
      assert.deepEqual(stale, [], `Policy lines for routes that no longer exist: ${stale.join(', ')}`);
    });

    test('nothing except the public routes works without signing in', async () => {
      const failures = [];
      for (const r of (await listRoutes()).filter((x) => !PUBLIC.test(x.path))) {
        const res = await request(app)[r.method.toLowerCase()](withIds(r.path, randomUUID())).send(r.method === 'GET' ? undefined : {});
        if (res.status !== 401) failures.push(`${r.method} ${r.path} → ${res.status}`);
      }
      assert.deepEqual(failures, []);
    });

    test('each role gets through exactly the routes the policy gives it', { timeout: 600000 }, async () => {
      const policy = new Map(POLICY);
      const failures = [];
      for (const r of (await listRoutes()).filter((x) => !PUBLIC.test(x.path))) {
        const key = `${r.method} ${r.path.replace('/api/v1', '')}`;
        const allowed = policy.get(key);
        if (!allowed) continue; // reported by the first test
        const url = withIds(r.path, randomUUID());
        for (const role of ROLES) {
          const req = request(app)[r.method.toLowerCase()](url).set(bearer(users[role]));
          const res = await (r.method === 'GET' || r.method === 'DELETE' ? req : req.send({}));
          const expected = allowed.includes(role);
          if (reached(res.status) !== expected) {
            failures.push(`${role.padEnd(18)} ${key}  → ${res.status}  (policy says ${expected ? 'allowed' : 'blocked'})`);
          }
        }
      }
      assert.deepEqual(failures, [], `\n${failures.join('\n')}\n`);
    });
  });

  describe('students and parents see only their own records', () => {
    let classRow; let parentA; let parentB; let stuA; let stuB; let uA; let uB;
    before(async () => {
      classRow = await Class.create({ tenant_id: fx.tenant.id, campus_id: fx.campus.id, name: 'Form I', grade: '1', education_level: 'o_level', academic_year: '2026', status: 'active' });
      parentA = await mkUser('parent', { first_name: 'Pa', last_name: 'Mine' });
      parentB = await mkUser('parent', { first_name: 'Pb', last_name: 'Other' });
      uA = await mkUser('student', { first_name: 'Alice', last_name: 'Mine' });
      uB = await mkUser('student', { first_name: 'Bravo', last_name: 'ZZSecretFamily' });
      stuA = await Student.create({ tenant_id: fx.tenant.id, user_id: uA.id, campus_id: fx.campus.id, admission_number: `ADM-OWN-${randomUUID().slice(0, 6)}`, class_id: classRow.id, parent_id: parentA.id, admission_date: '2026-01-10', status: 'active' });
      stuB = await Student.create({ tenant_id: fx.tenant.id, user_id: uB.id, campus_id: fx.campus.id, admission_number: `ADM-ZZB-${randomUUID().slice(0, 6)}`, class_id: classRow.id, parent_id: parentB.id, address: '12 ZZSecret Street', admission_date: '2026-01-10', status: 'active' });
    });
    const get = (user, path) => request(app).get(`/api/v1${path}`).set(bearer(user));

    test('a parent\'s student list is their own children — even if they ask for someone else\'s', async () => {
      for (const query of ['', `?parent_id=${parentA.id}`, `?parent_id=${parentB.id}`, '?search=ZZSecret']) {
        const res = await get(parentA, `/students${query}`);
        assert.equal(res.status, 200);
        assert.deepEqual(res.body.data.map((s) => s.admission_number), query === '?search=ZZSecret' ? [] : [stuA.admission_number], query);
        assert.ok(!JSON.stringify(res.body).includes('ZZSecret'), `leaked on ${query}`);
      }
    });

    test('a student sees only themself', async () => {
      const list = await get(uA, '/students');
      assert.deepEqual(list.body.data.map((s) => s.admission_number), [stuA.admission_number]);
      assert.equal((await get(uA, `/students/${stuA.id}`)).status, 200);
    });

    test('opening someone else\'s record is refused, for the record and its statistics', async () => {
      for (const who of [parentA, uA]) {
        for (const path of [`/students/${stuB.id}`, `/students/${stuB.id}/stats`]) {
          const res = await get(who, path);
          assert.equal(res.status, 403, `${who.role} ${path}`);
          assert.ok(!JSON.stringify(res.body).includes('ZZSecret'));
        }
      }
      assert.equal((await get(parentA, `/students/${stuA.id}`)).status, 200, 'a parent can open their own child');
      assert.equal((await get(parentA, `/students/${stuA.id}/stats`)).status, 200);
    });

    test('staff still see every student', async () => {
      for (const role of ['teacher', 'accountant', 'principal', 'admin']) {
        const res = await get(users[role], '/students?limit=50');
        assert.ok(res.body.data.length >= 2, role);
      }
    });

    test('transport and hostel allocations are visible only for your own child', async () => {
      for (const area of ['transport', 'hostel']) {
        assert.equal((await get(parentA, `/${area}/student/${stuB.id}`)).status, 403, `${area} other`);
        assert.equal((await get(uA, `/${area}/student/${stuB.id}`)).status, 403, `${area} other (student)`);
        assert.equal((await get(parentA, `/${area}/student/${stuA.id}`)).status, 200, `${area} own child`);
        assert.equal((await get(uA, `/${area}/student/${stuA.id}`)).status, 200, `${area} own`);
        assert.equal((await get(users.teacher, `/${area}/student/${stuB.id}`)).status, 200, `${area} staff`);
      }
    });
  });

  describe('staff records hide pay and personal details from people who do not manage staff', () => {
    let staff;
    before(async () => {
      const u = await mkUser('accountant', { first_name: 'Sam', last_name: 'ZZStaffer' });
      staff = await Staff.create({
        tenant_id: fx.tenant.id, user_id: u.id, campus_id: fx.campus.id, employee_number: `EMP-${randomUUID().slice(0, 8)}`,
        salary: 7654321, national_id: 'NID-ZZ-999', bank_account_number: 'BANK-ZZ-123', tin_number: 'TIN-ZZ-1',
      });
      staff.userRow = u;
    });
    const view = (user) => request(app).get(`/api/v1/staff/${staff.id}`).set(bearer(user));

    test('colleagues and the list get the directory details only', async () => {
      for (const role of ['teacher', 'librarian', 'accountant']) {
        const res = await (role === 'accountant' ? view(users.teacher) : view(users[role]));
        assert.equal(res.status, 200);
        const text = JSON.stringify(res.body);
        for (const secret of ['7654321', 'NID-ZZ-999', 'BANK-ZZ-123', 'TIN-ZZ-1']) assert.ok(!text.includes(secret), `${role} saw ${secret}`);
        assert.equal(res.body.data.employee_number, staff.employee_number, 'the name/number are still there for pick-lists');
      }
      const list = await request(app).get('/api/v1/staff?limit=50').set(bearer(users.teacher));
      assert.ok(!JSON.stringify(list.body).includes('7654321'));
    });

    test('staff managers and the person themself see everything', async () => {
      for (const who of [users.hr, users.principal, users.admin, staff.userRow]) {
        const res = await view(who);
        assert.equal(Number(res.body.data.salary), 7654321, who.role);
        assert.equal(res.body.data.national_id, 'NID-ZZ-999');
      }
    });

    test('students and parents have no access to staff at all', async () => {
      for (const role of ['student', 'parent']) {
        assert.equal((await view(users[role])).status, 403);
        assert.equal((await request(app).get('/api/v1/staff').set(bearer(users[role]))).status, 403);
      }
    });
  });

  describe('school settings', () => {
    test('everyone gets the settings they need, but the backup schedule is for administrators', async () => {
      const teacher = await request(app).get('/api/v1/settings').set(bearer(users.teacher));
      assert.equal(teacher.status, 200);
      assert.ok(teacher.body.data.session_policy, 'idle sign-out needs this for every role');
      assert.equal('backup_schedule' in teacher.body.data, false);
      const admin = await request(app).get('/api/v1/settings').set(bearer(users.admin));
      assert.ok(admin.body.data.backup_schedule);
    });
  });

  describe('creating accounts (POST /auth/register)', () => {
    const body = (extra = {}) => ({
      email: `new-${randomUUID().slice(0, 8)}@example.test`, password: 'Password123!',
      first_name: 'New', last_name: 'Person', role: 'teacher', tenant_id: fx.tenant.id, ...extra,
    });

    test('is no longer open to the world', async () => {
      // This used to return 201 and a token — for role super_admin, in ANY school.
      const attempt = body({ role: 'super_admin' });
      const res = await request(app).post('/api/v1/auth/register').send(attempt);
      assert.equal(res.status, 401);
      assert.equal(await User.count({ where: { email: attempt.email } }), 0);
    });

    test('teachers, parents and students cannot create accounts', async () => {
      for (const role of ['teacher', 'parent', 'student', 'accountant', 'principal']) {
        assert.equal((await request(app).post('/api/v1/auth/register').set(bearer(users[role])).send(body())).status, 403, role);
      }
    });

    test('a school admin adds accounts to THEIR school only, and cannot make a super admin', async () => {
      const intoOther = await request(app).post('/api/v1/auth/register').set(bearer(users.admin)).send(body({ tenant_id: other.tenant.id }));
      assert.equal(intoOther.status, 201);
      const created = await User.findByPk(intoOther.body.data.id);
      assert.equal(created.tenant_id, fx.tenant.id, 'the tenant_id in the request is ignored — it lands in the caller\'s own school');
      assert.equal(intoOther.body.data.token, undefined, 'no session is handed back');

      assert.equal((await request(app).post('/api/v1/auth/register').set(bearer(users.admin)).send(body({ role: 'super_admin' }))).status, 403);
      assert.equal((await request(app).post('/api/v1/auth/register').set(bearer(users.super_admin)).send(body({ role: 'super_admin' }))).status, 201);
    });

    test('a role that does not exist is refused', async () => {
      assert.equal((await request(app).post('/api/v1/auth/register').set(bearer(users.admin)).send(body({ role: 'emperor' }))).status, 400);
    });

    test('the platform developer can onboard an administrator in any school', async () => {
      const previous = process.env.DEVELOPER_EMAILS;
      process.env.DEVELOPER_EMAILS = users.admin.email;
      try {
        const res = await request(app).post('/api/v1/auth/register').set(bearer(users.admin)).send(body({ tenant_id: other.tenant.id, role: 'admin' }));
        assert.equal(res.status, 201);
        assert.equal((await User.findByPk(res.body.data.id)).tenant_id, other.tenant.id);
        const missing = await request(app).post('/api/v1/auth/register').set(bearer(users.admin)).send(body({ tenant_id: randomUUID() }));
        assert.equal(missing.status, 400);
      } finally {
        if (previous === undefined) delete process.env.DEVELOPER_EMAILS; else process.env.DEVELOPER_EMAILS = previous;
      }
    });
  });

  describe('the payment webhook (no login)', () => {
    test('a forged "SUCCESS" cannot mark an invoice paid', async () => {
      const plan = await SubscriptionPlan.findOne() || await SubscriptionPlan.create({ name: 'Test', code: `T-${randomUUID().slice(0, 6)}`, student_limit: 100, price_monthly: 1, price_termly: 1, price_yearly: 1 });
      const subscription = await Subscription.findOne({ where: { tenant_id: fx.tenant.id } })
        || await Subscription.create({ tenant_id: fx.tenant.id, plan_id: plan.id, status: 'trial', billing_cycle: 'monthly' });
      const invoice = await SubscriptionInvoice.create({
        tenant_id: fx.tenant.id, subscription_id: subscription.id, plan_id: plan.id, invoice_number: `INV-${randomUUID().slice(0, 8)}`,
        billing_cycle: 'monthly', subtotal: 100, total: 100, status: 'pending', order_reference: `ORD${randomUUID().replace(/-/g, '').slice(0, 12)}`,
        period_start: '2026-01-01', period_end: '2026-02-01',
      });
      const res = await request(app).post('/api/v1/webhooks/clickpesa').send({ orderReference: invoice.order_reference, status: 'SUCCESS' });
      assert.equal(res.status, 200, 'the gateway is always answered, so it does not retry forever');
      await invoice.reload();
      assert.notEqual(invoice.status, 'paid', 'a callback body alone is not proof of payment');
    });
  });
});
