/**
 * permission-grants.test.js
 *
 * What a person may DO follows permissions, not job titles. Administrators can
 * give a role — or one person — any permission (a teacher who may delete, an
 * accountant who may not record payments), and can take defaults away again.
 * Admins themselves can never be locked out.
 */
import { test, describe, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'crypto';
import request from 'supertest';
import app from '../../src/server.js';
import { User, Student, Class, RolePermission } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';
import { DEFAULT_ROLE_PERMISSIONS } from '../../src/utils/permissionCatalog.js';

describe('Permissions decide what people can do', () => {
  let fx; let admin; let classRow;
  const bearer = (u) => ({ Authorization: `Bearer ${jwt.sign({ id: u.id }, process.env.JWT_SECRET, { expiresIn: '1h' })}` });
  const mk = (role, extra = {}) => User.create({
    tenant_id: fx.tenant.id, email: `${role}-${randomUUID().slice(0, 8)}@example.test`, password: 'Password123!',
    first_name: role, last_name: 'Tester', role, status: 'active', ...extra,
  });
  const mkStudent = async () => {
    const u = await mk('student', { first_name: 'Kid', last_name: randomUUID().slice(0, 5) });
    return Student.create({ tenant_id: fx.tenant.id, user_id: u.id, campus_id: fx.campus.id, admission_number: `ADM-${randomUUID().slice(0, 8)}`, class_id: classRow.id, admission_date: '2026-01-10', status: 'active' });
  };
  const setRole = (role, permissions) => request(app).put(`/api/v1/permissions/roles/${role}`).set(admin).send({ permissions });
  const setUser = (id, permissions) => request(app).put(`/api/v1/permissions/users/${id}`).set(admin).send({ permissions });

  before(async () => {
    fx = await buildTenantFixture('grants'); admin = authHeader(fx.token);
    classRow = await Class.create({ tenant_id: fx.tenant.id, campus_id: fx.campus.id, name: 'Form I', grade: '1', education_level: 'o_level', academic_year: '2026', status: 'active' });
  });
  after(closeDb);
  // every test starts from the standard permissions
  beforeEach(async () => { await RolePermission.destroy({ where: { tenant_id: fx.tenant.id } }); });

  test('a teacher cannot delete a student — until a role grant says they can', async () => {
    const teacher = await mk('teacher');
    const s1 = await mkStudent();
    assert.equal((await request(app).delete(`/api/v1/students/${s1.id}`).set(bearer(teacher))).status, 403);

    assert.equal((await setRole('teacher', [...DEFAULT_ROLE_PERMISSIONS.teacher, 'students.delete'])).status, 200);
    assert.equal((await request(app).delete(`/api/v1/students/${s1.id}`).set(bearer(teacher))).status, 200);

    const s2 = await mkStudent(); // other teachers get it too — it was granted to the ROLE
    const another = await mk('teacher');
    assert.equal((await request(app).delete(`/api/v1/students/${s2.id}`).set(bearer(another))).status, 200);
  });

  test('anyone holding the delete permission may delete for good — it is not left to the super admin', async () => {
    const teacher = await mk('teacher');
    const s = await mkStudent();
    assert.equal((await request(app).delete(`/api/v1/students/${s.id}/permanent`).set(bearer(teacher))).status, 403);
    await setUser(teacher.id, ['students.delete']);
    assert.equal((await request(app).delete(`/api/v1/students/${s.id}/permanent`).set(bearer(teacher))).status, 200);
    assert.equal(await Student.count({ where: { id: s.id } }), 0);
  });

  test('a grant to one person does not reach their colleagues', async () => {
    const lucky = await mk('teacher'); const other = await mk('teacher');
    await setUser(lucky.id, ['students.delete']);
    const a = await mkStudent(); const b = await mkStudent();
    assert.equal((await request(app).delete(`/api/v1/students/${a.id}`).set(bearer(lucky))).status, 200);
    assert.equal((await request(app).delete(`/api/v1/students/${b.id}`).set(bearer(other))).status, 403);
  });

  test('a default can be taken away from a role — and restored', async () => {
    const accountant = await mk('accountant');
    const attempt = () => request(app).post('/api/v1/fees/payments').set(bearer(accountant)).send({});
    assert.notEqual((await attempt()).status, 403, 'accountants record payments by default');

    await setRole('accountant', DEFAULT_ROLE_PERMISSIONS.accountant.filter((k) => k !== 'fees.create'));
    assert.equal((await attempt()).status, 403, 'now refused');
    assert.notEqual((await request(app).get('/api/v1/fees/payments').set(bearer(accountant))).status, 403, 'everything else they had is untouched');

    assert.equal((await request(app).put('/api/v1/permissions/roles/accountant').set(admin).send({ reset: true })).status, 200);
    assert.notEqual((await attempt()).status, 403, 'back to the standard set');
  });

  test('what the permissions screen shows is what the role can really do', async () => {
    const before = (await request(app).get('/api/v1/permissions/roles').set(admin)).body.data.find((r) => r.role === 'teacher');
    assert.deepEqual(before.permissions, [...DEFAULT_ROLE_PERMISSIONS.teacher].sort());
    assert.equal(before.customised, false);
    await setRole('teacher', ['attendance.view']);
    const after = (await request(app).get('/api/v1/permissions/roles').set(admin)).body.data.find((r) => r.role === 'teacher');
    assert.deepEqual(after.permissions, ['attendance.view']);
    assert.equal(after.customised, true);
  });

  test('older saved settings (which only ever listed extras) keep the defaults', async () => {
    const teacher = await mk('teacher');
    await RolePermission.create({ tenant_id: fx.tenant.id, role: 'teacher', permissions: ['expenses.view'] }); // the old format: no marker
    assert.notEqual((await request(app).get('/api/v1/expenses').set(bearer(teacher))).status, 403, 'the extra works');
    assert.notEqual((await request(app).get('/api/v1/attendance').set(bearer(teacher))).status, 403, 'and so does what teachers always had');
  });

  test('administrators can never be locked out, whatever is saved', async () => {
    assert.equal((await setRole('admin', [])).status, 400);
    await RolePermission.create({ tenant_id: fx.tenant.id, role: 'admin', permissions: ['*saved'] });
    assert.equal((await request(app).get('/api/v1/settings/audit-logs').set(admin)).status, 200);
    assert.equal((await request(app).get('/api/v1/permissions/roles').set(admin)).status, 200);
  });

  test('the principal is held to permissions too — and can be given or denied more', async () => {
    const principal = await mk('principal');
    assert.equal((await request(app).get('/api/v1/settings/audit-logs').set(bearer(principal))).status, 403, 'not by default');
    await setUser(principal.id, ['audit.view']);
    assert.equal((await request(app).get('/api/v1/settings/audit-logs').set(bearer(principal))).status, 200);
    await setRole('principal', DEFAULT_ROLE_PERMISSIONS.principal.filter((k) => k !== 'students.create'));
    assert.equal((await request(app).post('/api/v1/students').set(bearer(principal)).send({})).status, 403);
  });

  test('a permission works all the way down — no hidden job-title check inside the module', async () => {
    const teacher = await mk('teacher');
    // each of these used to stop non-library / non-hostel / non-HR people inside the controller
    const probes = [
      ['library.create', () => request(app).post('/api/v1/library/books').set(bearer(teacher)).send({})],
      ['hostel.create', () => request(app).post('/api/v1/hostel/hostels').set(bearer(teacher)).send({})],
      ['leave.create', () => request(app).post('/api/v1/leave/types').set(bearer(teacher)).send({})],
      ['payroll.view', () => request(app).get('/api/v1/payroll/periods').set(bearer(teacher))],
      ['promotions.manage', () => request(app).get('/api/v1/promotions').set(bearer(teacher))],
      ['audit.view', () => request(app).get('/api/v1/settings/audit-logs').set(bearer(teacher))],
      ['inquiries.update', () => request(app).patch(`/api/v1/admission-inquiries/${randomUUID()}`).set(bearer(teacher)).send({})],
      ['subscription.manage', () => request(app).get('/api/v1/subscription/invoices').set(bearer(teacher))],
    ];
    for (const [key, call] of probes) {
      assert.equal((await call()).status, 403, `${key}: refused without it`);
    }
    await setUser(teacher.id, probes.map(([k]) => k));
    for (const [key, call] of probes) {
      const res = await call();
      assert.notEqual(res.status, 403, `${key}: allowed once granted (got ${res.status}: ${res.body.message || ''})`);
    }
  });

  test('without students.view you see only yourself (parent / student) or nothing (staff)', async () => {
    const parent = await mk('parent'); const kid = await mkStudent();
    await kid.update({ parent_id: parent.id });
    await mkStudent();
    const list = async (u) => request(app).get('/api/v1/students?limit=50').set(bearer(u));
    assert.deepEqual((await list(parent)).body.data.map((s) => s.id), [kid.id]);

    const librarian = await mk('librarian');
    assert.equal((await list(librarian)).status, 200);
    await setRole('librarian', DEFAULT_ROLE_PERMISSIONS.librarian.filter((k) => k !== 'students.view'));
    assert.equal((await list(librarian)).status, 403, 'a staff member whose students.view was taken away');

    await setUser(parent.id, ['students.view']);
    assert.ok((await list(parent)).body.data.length >= 2, 'a parent explicitly granted students.view sees everyone');
  });

  test('the browser is told what the person can do', async () => {
    const teacher = await mk('teacher');
    await setUser(teacher.id, ['students.delete']);
    const me = await request(app).get('/api/v1/auth/me').set(bearer(teacher));
    assert.ok(me.body.data.effective_permissions.includes('students.delete'));
    assert.ok(me.body.data.effective_permissions.includes('attendance.create'));
    assert.ok(!me.body.data.effective_permissions.includes('fees.create'));
    const asAdmin = await request(app).get('/api/v1/auth/me').set(admin);
    assert.deepEqual(asAdmin.body.data.effective_permissions, ['*']);
  });

  test('every role is shown exactly the modules it is shown today — by default', async () => {
    const perms = async (role) => (await request(app).get('/api/v1/auth/me').set(bearer(await mk(role)))).body.data.effective_permissions;
    const teacher = await perms('teacher');
    for (const k of ['students.access', 'attendance.access', 'subjects.access', 'timetable.access', 'payroll.access']) assert.ok(teacher.includes(k), k);
    for (const k of ['fees.access', 'staff.access', 'campus.access', 'inventory.access', 'classes.access']) assert.ok(!teacher.includes(k), `a teacher doesn't see ${k}`);
    const accountant = await perms('accountant');
    assert.ok(accountant.includes('fees.access') && accountant.includes('expenses.access'));
    assert.ok(!accountant.includes('students.access'), 'an accountant can still PICK a student in fees, but does not see the Students module');
    const parent = await perms('parent');
    assert.deepEqual(parent.filter((k) => k.endsWith('.access')).sort(), ['fees.access', 'hostel.access', 'library.access', 'notifications.access', 'results.access', 'transport.access']);
    const student = await perms('student');
    assert.ok(student.includes('timetable.access') && student.includes('leave.access') && !student.includes('fees.access'));
  });

  test('taking away a module\'s "Open" permission removes the module for that role — and giving it to one person adds it for them', async () => {
    const teacher = await mk('teacher'); const other = await mk('teacher');
    const mine = async (u) => (await request(app).get('/api/v1/auth/me').set(bearer(u))).body.data.effective_permissions;
    assert.ok((await mine(teacher)).includes('students.access'));

    await setRole('teacher', DEFAULT_ROLE_PERMISSIONS.teacher.filter((k) => k !== 'students.access'));
    assert.ok(!(await mine(teacher)).includes('students.access'), 'gone from the menu');
    assert.ok((await mine(teacher)).includes('students.view'), 'what they could DO is untouched — only the door is shut');

    await setUser(other.id, ['students.access']);
    assert.ok((await mine(other)).includes('students.access'), 'one person can be given the door back');
    assert.ok(!(await mine(await mk('teacher'))).includes('students.access'), 'their colleagues still can not');
  });

  test('the parent and student menus can be changed too', async () => {
    const parent = await mk('parent');
    await setRole('parent', DEFAULT_ROLE_PERMISSIONS.parent.filter((k) => k !== 'hostel.access'));
    const perms = (await request(app).get('/api/v1/auth/me').set(bearer(parent))).body.data.effective_permissions;
    assert.ok(!perms.includes('hostel.access') && perms.includes('fees.access'));
  });

  test('Dashboard and Notifications have their own permissions', async () => {
    const perms = async (role) => (await request(app).get('/api/v1/auth/me').set(bearer(await mk(role)))).body.data.effective_permissions;
    assert.ok((await perms('principal')).includes('dashboard.access'), 'the principal gets the full dashboard');
    for (const role of ['teacher', 'accountant', 'parent', 'student']) {
      assert.ok(!(await perms(role)).includes('dashboard.access'), `${role} gets the simple personal dashboard`);
      assert.ok((await perms(role)).includes('notifications.access'), `${role} has notifications`);
    }
    await setRole('teacher', DEFAULT_ROLE_PERMISSIONS.teacher.filter((k) => k !== 'notifications.access'));
    assert.ok(!(await perms('teacher')).includes('notifications.access'));
  });

  test('Messages: managing contacts, managing templates and sending are three different permissions', async () => {
    const teacher = await mk('teacher');
    const newContact = () => request(app).post('/api/v1/messaging/contacts').set(bearer(teacher)).send({});
    const newTemplate = () => request(app).post('/api/v1/messaging/templates').set(bearer(teacher)).send({});
    assert.equal((await newContact()).status, 403);
    await setUser(teacher.id, ['send_messages']);
    assert.equal((await newContact()).status, 403, 'being allowed to send does not allow editing the contact book');
    assert.equal((await newTemplate()).status, 403, 'or the templates');
    await setUser(teacher.id, ['send_messages', 'messages.manage_contacts']);
    assert.notEqual((await newContact()).status, 403);
    assert.equal((await newTemplate()).status, 403);
    await setUser(teacher.id, ['messages.manage_templates']);
    assert.notEqual((await newTemplate()).status, 403);
  });

  test('Settings: each setting has its own permission', async () => {
    const principal = await mk('principal'); const p = bearer(principal);
    const year = () => request(app).put('/api/v1/settings/academic-year').set(p).send({});
    const exportData = () => request(app).get('/api/v1/settings/export').set(p);
    const policy = () => request(app).put('/api/v1/settings/session-policy').set(p).send({});
    assert.deepEqual([(await year()).status, (await exportData()).status, (await policy()).status], [403, 403, 403]);
    await setUser(principal.id, ['settings.academic_year']);
    assert.notEqual((await year()).status, 403);
    assert.equal((await exportData()).status, 403, 'changing the academic year does not allow exporting the school\'s data');
    assert.equal((await policy()).status, 403);
  });

  test('managing permissions is itself a permission (admins only by default)', async () => {
    const principal = await mk('principal');
    assert.equal((await request(app).get('/api/v1/permissions/roles').set(bearer(principal))).status, 403);
  });
});
