/**
 * students-academic-year-floor.test.js
 *
 * A school shouldn't be able to "see" student data from before it ever
 * started using the system — projecting a grade for a year the system
 * has no way of actually knowing about is fabrication, not an estimate.
 * The floor defaults to the tenant's signup date (Tenant.created_at) and
 * can be overridden via tenant.settings.academic_records_start_year for
 * a school that migrated in real history from elsewhere.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import { Class, Student, User } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';

describe('GET /api/v1/students?academic_year= — system-start floor', () => {
  let fixture;

  before(async () => {
    fixture = await buildTenantFixture('floortest');
    const { tenant, campus } = fixture;

    // Tenant.created_at defaults to "now" (this test run's real year) —
    // exactly the scenario reported: the school only started using the
    // system this year, so a student currently in Form III has no
    // legitimate earlier history for the system to show.
    const currentCalendarYear = new Date().getFullYear();

    const form3 = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form III', grade: '3',
      education_level: 'o_level', academic_year: String(currentCalendarYear), status: 'active',
    });

    const user = await User.create({
      tenant_id: tenant.id, email: `nohistory-${tenant.slug}@example.test`, password: 'Password123!',
      first_name: 'NoHistory', last_name: 'Student', role: 'student', status: 'active',
    });
    // No admission_date recorded at all — the ONLY thing standing between
    // this student and an incorrect guess for a year before the school
    // ever signed up is the system-start floor.
    await Student.create({
      tenant_id: tenant.id, user_id: user.id, campus_id: campus.id,
      admission_number: `ADM-nohistory-${tenant.slug}`, class_id: form3.id, status: 'active',
    });

    fixture.currentCalendarYear = currentCalendarYear;
  });

  after(closeDb);

  test('a year before the tenant ever signed up is refused, not guessed at', async () => {
    const priorYear = fixture.currentCalendarYear - 1;
    const res = await request(app)
      .get('/api/v1/students')
      .set(authHeader(fixture.token))
      .query({ academic_year: `${priorYear}-${priorYear + 1}`, limit: 50 });

    assert.equal(res.status, 200);
    const found = res.body.data.find((s) => s.user?.first_name === 'NoHistory');
    assert.equal(found, undefined, 'a student should not appear for a year before the school ever used the system');
  });

  test('the signup year itself still shows the student normally', async () => {
    const res = await request(app)
      .get('/api/v1/students')
      .set(authHeader(fixture.token))
      .query({ academic_year: `${fixture.currentCalendarYear}-${fixture.currentCalendarYear + 1}`, limit: 50 });

    assert.equal(res.status, 200);
    const found = res.body.data.find((s) => s.user?.first_name === 'NoHistory');
    assert.ok(found, 'the student should be visible in the year the school actually started using the system');
    assert.equal(found.class.grade, '3');
  });

  test('an explicit tenant override lets an earlier year through, for a school that migrated in real history', async () => {
    await fixture.tenant.update({ settings: { academic_records_start_year: fixture.currentCalendarYear - 5 } });

    const priorYear = fixture.currentCalendarYear - 1;
    const res = await request(app)
      .get('/api/v1/students')
      .set(authHeader(fixture.token))
      .query({ academic_year: `${priorYear}-${priorYear + 1}`, limit: 50 });

    assert.equal(res.status, 200);
    const found = res.body.data.find((s) => s.user?.first_name === 'NoHistory');
    assert.ok(found, 'the override should allow projecting back beyond the tenant\'s signup date');
    assert.equal(found.class.grade, '2');
  });
});
