/**
 * student-stats-by-year.test.js
 *
 * The user's exact scenario: a student was Form I in 2026 and Form II in
 * 2027. Selecting 2026 must show ONLY 2026's attendance/exam/payment
 * records; selecting 2027 must show ONLY 2027's — each year's records
 * are independent of the others, not a running lifetime total.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import {
  Class, Student, User, StudentPromotion, FeeStructure, Payment, Attendance, Exam, Grade, Subject,
} from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';
import { randomUUID } from 'crypto';

describe('GET /api/v1/students/:id/stats — scoped to the selected academic year', () => {
  let fixture;
  let student;
  let form1_2026;
  let form2_2027;

  before(async () => {
    fixture = await buildTenantFixture('statsyear');
    const { tenant, campus } = fixture;
    await tenant.update({ settings: { academic_records_start_year: 2020 } });

    form1_2026 = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form I', grade: '1',
      education_level: 'o_level', academic_year: '2026', status: 'active',
    });
    form2_2027 = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form II', grade: '2',
      education_level: 'o_level', academic_year: '2027', status: 'active',
    });

    const user = await User.create({
      tenant_id: tenant.id, email: `statspupil-${tenant.slug}@example.test`, password: 'Password123!',
      first_name: 'Stats', last_name: 'Pupil', role: 'student', status: 'active',
    });
    student = await Student.create({
      tenant_id: tenant.id, user_id: user.id, campus_id: campus.id,
      admission_number: `ADM-stats-${tenant.slug}`, class_id: form2_2027.id,
      admission_date: '2026-01-10', status: 'active',
    });

    await StudentPromotion.create({
      tenant_id: tenant.id, student_id: student.id, batch_id: randomUUID(), action: 'promoted',
      from_class_id: form1_2026.id, to_class_id: form2_2027.id,
      from_academic_year: '2026-2027', to_academic_year: '2027-2028',
    });

    // ── 2026 (Form I) records ──
    await Attendance.create({
      tenant_id: tenant.id, student_id: student.id, class_id: form1_2026.id,
      date: '2026-10-05', status: 'present',
    });
    await Attendance.create({
      tenant_id: tenant.id, student_id: student.id, class_id: form1_2026.id,
      date: '2026-10-06', status: 'absent',
    });
    const feeForm1 = await FeeStructure.create({
      tenant_id: tenant.id, campus_id: campus.id, class_id: form1_2026.id,
      name: 'Tuition', amount: 100000, academic_year: '2026', status: 'active',
    });
    await Payment.create({
      tenant_id: tenant.id, student_id: student.id, fee_structure_id: feeForm1.id,
      amount: 40000, payment_method: 'cash', payment_date: '2026-10-10', status: 'completed',
    });
    const subject = await Subject.create({ tenant_id: tenant.id, name: 'Mathematics', code: `MATH-${tenant.slug}` });
    const exam2026 = await Exam.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Mid Term 2026', academic_year: '2026-2027',
      class_ids: [form1_2026.id], status: 'completed',
    });
    await Grade.create({
      tenant_id: tenant.id, exam_id: exam2026.id, student_id: student.id, subject_id: subject.id,
      marks_obtained: 60, max_marks: 100,
    });

    // ── 2027 (Form II) records ──
    await Attendance.create({
      tenant_id: tenant.id, student_id: student.id, class_id: form2_2027.id,
      date: '2027-10-05', status: 'present',
    });
    const feeForm2 = await FeeStructure.create({
      tenant_id: tenant.id, campus_id: campus.id, class_id: form2_2027.id,
      name: 'Tuition', amount: 150000, academic_year: '2027', status: 'active',
    });
    await Payment.create({
      tenant_id: tenant.id, student_id: student.id, fee_structure_id: feeForm2.id,
      amount: 90000, payment_method: 'cash', payment_date: '2027-10-10', status: 'completed',
    });
    const exam2027 = await Exam.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Mid Term 2027', academic_year: '2027-2028',
      class_ids: [form2_2027.id], status: 'completed',
    });
    await Grade.create({
      tenant_id: tenant.id, exam_id: exam2027.id, student_id: student.id, subject_id: subject.id,
      marks_obtained: 85, max_marks: 100,
    });
  });

  after(closeDb);

  test('2026: shows ONLY the Form I attendance, fees, and exam results', async () => {
    const res = await request(app)
      .get(`/api/v1/students/${student.id}/stats`)
      .set(authHeader(fixture.token))
      .query({ academic_year: '2026-2027' });

    assert.equal(res.status, 200);
    assert.equal(res.body.data.attendance.total, 2);
    assert.equal(res.body.data.attendance.present, 1);
    assert.equal(res.body.data.attendance.absent, 1);
    assert.equal(res.body.data.fees.total, 100000);
    assert.equal(res.body.data.fees.paid, 40000);
    assert.equal(res.body.data.exams.total, 1);
    assert.equal(res.body.data.exams.average, 60);
  });

  test('2027: shows ONLY the Form II attendance, fees, and exam results — independent of 2026', async () => {
    const res = await request(app)
      .get(`/api/v1/students/${student.id}/stats`)
      .set(authHeader(fixture.token))
      .query({ academic_year: '2027-2028' });

    assert.equal(res.status, 200);
    assert.equal(res.body.data.attendance.total, 1);
    assert.equal(res.body.data.attendance.present, 1);
    assert.equal(res.body.data.fees.total, 150000);
    assert.equal(res.body.data.fees.paid, 90000);
    assert.equal(res.body.data.exams.total, 1);
    assert.equal(res.body.data.exams.average, 85);
  });

  test('no academic_year param falls back to the student\'s CURRENT class year (2027)', async () => {
    const res = await request(app)
      .get(`/api/v1/students/${student.id}/stats`)
      .set(authHeader(fixture.token));

    assert.equal(res.status, 200);
    assert.equal(res.body.data.fees.total, 150000);
    assert.equal(res.body.data.exams.average, 85);
  });
});
