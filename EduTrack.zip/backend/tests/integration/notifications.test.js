/**
 * notifications.test.js — Settings → Notifications: who is told (parties) and how (channels), and that every automatic
 * notification really arrives. Real Postgres and real endpoints; SwalaSMS is stubbed, nothing leaves the machine.
 */
import '../helpers/noMail.js';
import { test, describe, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import { Sequelize } from 'sequelize';
import app from '../../src/server.js';
import sequelize from '../../src/config/database.js';
import { User, Student, Class, Contact, Book, BookIssue, Notification, NotificationSetting, SmsGatewaySettings, Message, MessageRecipient } from '../../src/models/index.js';
import { notifyEvent } from '../../src/services/notificationService.js';
import { NOTIFICATION_EVENTS } from '../../src/utils/notificationEvents.js';
import { familyContactsFor } from '../../src/utils/familyContacts.js';
import { SWALASMS_BASE_URL } from '../../src/services/smsService.js';
import { refreshOverdueStatus } from '../../src/controllers/libraryController.js';
import * as audienceMigration from '../../src/migrations/20261035000000-notification-audience.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';

const uid = () => Math.random().toString(36).slice(2, 8);
const realFetch = globalThis.fetch;
const SWALA_HOST = new URL(SWALASMS_BASE_URL).host;

describe('Notifications', () => {
  let f; let tid;
  const mkUser = (role, extra = {}) => User.create({ tenant_id: tid, email: `${role}-${uid()}@school.co.tz`, password: 'Password123!', first_name: role, last_name: 'Tester', role, status: 'active', ...extra });
  const inbox = (where = {}) => Notification.findAll({ where: { tenant_id: tid, ...where } });
  const roles = async (where = {}) => (await inbox(where)).map((r) => r.recipient_role).filter(Boolean).sort();
  const get = () => request(app).get('/api/v1/notifications/settings/events').set(authHeader(f.token));
  const put = (body) => request(app).put('/api/v1/notifications/settings/events').set(authHeader(f.token)).send(body);
  const setAudience = (event_key, audience, enabled = true) => NotificationSetting.upsert({ tenant_id: tid, event_key, enabled, audience, channels: [...new Set(Object.values(audience).flat())] });

  /** A stand-in for SwalaSMS that records who was texted. */
  const sms = { sent: [], balance: 1000 };
  const stubSms = () => {
    sms.sent = []; sms.balance = 1000;
    const json = (b, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { 'content-type': 'application/json' } });
    globalThis.fetch = async (url, init = {}) => {
      const u = new URL(String(url));
      if (u.host !== SWALA_HOST) return realFetch(url, init);
      const body = init.body ? JSON.parse(init.body) : {};
      if (u.pathname === '/v1/balance') return json({ success: true, mode: 'live', data: { balance: sms.balance, countries: [] } });
      if (u.pathname === '/v1/sms/messages') { sms.sent.push(body.recipient); return json({ success: true, data: { uid: `u-${uid()}`, status: 'queued', units: 1 } }, 202); }
      if (u.pathname === '/v2/sms/send-bulk') {
        body.recipients.forEach((r) => sms.sent.push(r));
        return json({ success: true, data: { messages: body.recipients.map((to) => ({ to, message_uid: `m-${uid()}`, status: 'queued', units: 1 })), failures: [] } }, 202);
      }
      return json({ success: false, message: 'unexpected' }, 500);
    };
    return SmsGatewaySettings.upsert({ tenant_id: tid, provider: 'swalasms', api_key: 'swl_live_test', sender_id: 'TEST', is_active: true });
  };

  before(async () => { f = await buildTenantFixture('notif'); tid = f.tenant.id; });
  beforeEach(async () => {
    globalThis.fetch = realFetch;
    await Notification.destroy({ where: { tenant_id: tid } });
    await NotificationSetting.destroy({ where: { tenant_id: tid } });
    await SmsGatewaySettings.destroy({ where: { tenant_id: tid } });
  });
  after(async () => { globalThis.fetch = realFetch; await closeDb(); });

  describe('the settings screen', () => {
    test('every notification lists who it can reach, with the defaults', async () => {
      const res = await get();
      assert.equal(res.status, 200);
      const by = Object.fromEntries(res.body.data.map((e) => [e.event_key, e]));
      NOTIFICATION_EVENTS.filter((e) => e.key !== 'password_reset').forEach((e) => assert.ok(by[e.key].parties.length >= 1, `${e.key} has recipients`));
      assert.deepEqual(by.payment_recorded.parties.map((p) => [p.key, p.enabled]), [['family', true], ['staff', true]]);
      assert.deepEqual(by.leave_request_submitted.parties.map((p) => [p.key, p.enabled]), [['approvers', true], ['requester', false]], 'a confirmation to the requester is opt-in');
      assert.deepEqual(by.student_admitted.parties.find((p) => p.key === 'family').channels, ['sms']);
      assert.equal(by.payment_received_staff, undefined, 'merged into Payment Recorded');
      assert.equal(by.admission_completed, undefined, 'merged into New Student Admitted');
      assert.deepEqual(by.password_reset.parties, []);
    });

    test('a school can pick the parent only, or the finance office only, each with its own channels', async () => {
      assert.equal((await put({ event_key: 'payment_recorded', audience: { family: ['in_app', 'sms'] } })).status, 200);
      let p = (await get()).body.data.find((e) => e.event_key === 'payment_recorded').parties;
      assert.deepEqual(p.map((x) => [x.key, x.enabled, x.channels]), [['family', true, ['in_app', 'sms']], ['staff', false, ['in_app']]]);
      await put({ event_key: 'payment_recorded', audience: { staff: ['email'] } });
      p = (await get()).body.data.find((e) => e.event_key === 'payment_recorded').parties;
      assert.deepEqual(p.map((x) => [x.key, x.enabled]), [['family', false], ['staff', true]]);
    });

    test('bad choices are refused with a clear reason', async () => {
      const bad = async (body, re) => { const r = await put({ event_key: 'payment_recorded', ...body }); assert.equal(r.status, 400); assert.match(r.body.message, re); };
      await bad({ audience: { nobody: ['in_app'] } }, /not someone this notification can reach/);
      await bad({ audience: { family: [] } }, /at least one way/);
      await bad({ audience: { family: ['pigeon'] } }, /In-App, SMS or Email/);
      await bad({ audience: {} }, /at least one person/);
      assert.equal((await put({ event_key: 'payment_recorded', enabled: false, audience: {} })).status, 200, 'allowed once the notification is switched off');
      assert.equal((await put({ event_key: 'nope', enabled: true })).status, 404);
    });

    test('an older client that only sends channels still works', async () => {
      await put({ event_key: 'payment_recorded', audience: { family: ['in_app'] } });
      await put({ event_key: 'payment_recorded', channels: ['in_app', 'email'] });
      const p = (await get()).body.data.find((e) => e.event_key === 'payment_recorded').parties;
      assert.deepEqual(p.find((x) => x.key === 'family').channels, ['in_app', 'email']);
      assert.equal(p.find((x) => x.key === 'staff').enabled, false, 'a recipient that was off stays off');
    });

    test('the password-reset choice is untouched', async () => {
      assert.equal((await put({ event_key: 'password_reset', channels: ['sms'] })).status, 200);
      assert.equal((await put({ event_key: 'password_reset', channels: ['in_app'] })).status, 400);
    });
  });

  describe('who gets it', () => {
    test('by default a payment tells the parent AND the finance office', async () => {
      const parent = await mkUser('parent');
      const out = await notifyEvent(tid, 'payment_recorded', { parties: { staff: { title: 'S', message: 'staff copy' }, family: { recipientUserId: parent.id, title: 'F', message: 'family copy' } } });
      assert.equal(out.in_app, 'sent');
      assert.equal((await inbox({ recipient_id: parent.id })).length, 1);
      assert.deepEqual(await roles({ title: 'S' }), ['accountant', 'admin']);
    });

    test('parent only: the finance office hears nothing', async () => {
      const parent = await mkUser('parent');
      await setAudience('payment_recorded', { family: ['in_app'] });
      const out = await notifyEvent(tid, 'payment_recorded', { parties: { staff: { title: 'S', message: 'x' }, family: { recipientUserId: parent.id, title: 'F', message: 'y' } } });
      assert.equal((await inbox({ recipient_id: parent.id })).length, 1);
      assert.equal((await inbox({ title: 'S' })).length, 0);
      assert.match(out.parties.staff.skipped, /switched off/);
    });

    test('finance office only: the parent hears nothing', async () => {
      const parent = await mkUser('parent');
      await setAudience('payment_recorded', { staff: ['in_app'] });
      await notifyEvent(tid, 'payment_recorded', { parties: { staff: { title: 'S', message: 'x' }, family: { recipientUserId: parent.id, title: 'F', message: 'y' } } });
      assert.equal((await inbox({ recipient_id: parent.id })).length, 0);
      assert.deepEqual(await roles({ title: 'S' }), ['accountant', 'admin']);
    });

    test('switched off means nothing at all, and an unknown recipient is ignored without an error', async () => {
      await NotificationSetting.create({ tenant_id: tid, event_key: 'expense_recorded', enabled: false, channels: ['in_app'], audience: { accountants: ['in_app'] } });
      const off = await notifyEvent(tid, 'expense_recorded', { parties: { accountants: { title: 'E', message: 'x' } } });
      assert.equal(off.enabled, false); assert.equal((await inbox()).length, 0);
      await NotificationSetting.update({ enabled: true }, { where: { tenant_id: tid, event_key: 'expense_recorded' } });
      const odd = await notifyEvent(tid, 'expense_recorded', { parties: { martians: { title: 'E', message: 'x' }, accountants: { title: 'E', message: 'x' } } });
      assert.equal(odd.in_app, 'sent'); assert.deepEqual(await roles(), ['accountant']);
    });

    test('older-style callers still work, using the event\'s channels', async () => {
      const u = await mkUser('teacher');
      const out = await notifyEvent(tid, 'timetable_published', { recipientUserId: u.id, title: 'T', message: 'legacy' });
      assert.equal(out.in_app, 'sent');
      assert.equal((await inbox({ recipient_id: u.id })).length, 1);
    });

    test('EVERY notification reaches EVERY one of its recipient groups, one at a time', async () => {
      const person = await mkUser('parent');
      for (const evt of NOTIFICATION_EVENTS.filter((e) => e.parties.length)) {
        for (const party of evt.parties) {
          await Notification.destroy({ where: { tenant_id: tid } });
          await setAudience(evt.key, { [party.key]: ['in_app'] });
          const spec = party.roles ? { title: evt.label, message: 'm' } : { recipientUserId: person.id, title: evt.label, message: 'm' };
          const others = Object.fromEntries(evt.parties.filter((p) => p.key !== party.key).map((p) => [p.key, p.roles ? { title: 'other', message: 'm' } : { recipientUserId: person.id, title: 'other', message: 'm' }]));
          const out = await notifyEvent(tid, evt.key, { parties: { [party.key]: spec, ...others } });
          assert.equal(out.parties[party.key].in_app, 'sent', `${evt.key} → ${party.key}`);
          if (party.roles) assert.deepEqual(await roles({ title: evt.label }), [...party.roles].sort(), `${evt.key} → ${party.key} roles`);
          else assert.equal((await inbox({ recipient_id: person.id, title: evt.label })).length, 1, `${evt.key} → ${party.key}`);
          assert.equal((await inbox({ title: 'other' })).length, 0, `${evt.key}: the other recipients stay out`);
        }
      }
    });
  });

  describe('SMS and email', () => {
    test('staff are texted on their own phones, once each, and people with no phone are skipped', async () => {
      const a = await mkUser('accountant', { phone: '255700000011' });
      await mkUser('accountant', { phone: '255700000012' });
      await mkUser('accountant');                                   // no phone
      await mkUser('accountant', { phone: a.phone });               // same number as the first
      await setAudience('payment_recorded', { staff: ['sms'] });
      const out = await notifyEvent(tid, 'payment_recorded', { parties: { staff: { title: 'S', message: 'Payment received' } } });
      assert.equal(out.parties.staff.sms, 'simulated');
      assert.equal(out.parties.staff.counts.sms, 2);
      assert.equal(out.parties.staff.in_app, 'skipped', 'only the channel chosen is used');
    });

    test('In-App and SMS together; a failing email never stops the others and never throws', async () => {
      await mkUser('accountant', { phone: '255700000021', email: `acc-${uid()}@school.co.tz` });
      await setAudience('expense_recorded', { accountants: ['in_app', 'sms', 'email'] });
      const out = await notifyEvent(tid, 'expense_recorded', { parties: { accountants: { title: 'E', message: 'Expense recorded' } } });
      assert.equal(out.parties.accountants.in_app, 'sent');
      assert.equal(out.parties.accountants.sms, 'simulated');
      assert.equal(out.parties.accountants.email, 'failed', 'the mail server is unreachable in tests');
      assert.ok(out.errors.length > 0 && out.errors.every((e) => e.startsWith('email')));
    });

    test('a generated login address (…@school.local) is never emailed', async () => {
      const parent = await mkUser('parent', { email: `p-${uid()}@school.local` });
      await setAudience('payment_recorded', { family: ['email'] });
      const out = await notifyEvent(tid, 'payment_recorded', { parties: { family: { recipientUserId: parent.id, title: 'F', message: 'x' } } });
      assert.equal(out.parties.family.email, 'skipped');
    });

    test('a channel the caller already used itself is not repeated (fee reminders: no second SMS)', async () => {
      const parent = await mkUser('parent', { phone: '255712300001' });
      await setAudience('fee_balance_reminder', { family: ['in_app', 'sms'] });
      const out = await notifyEvent(tid, 'fee_balance_reminder', { parties: { family: { recipientUserId: parent.id, skipChannels: ['sms'], title: 'R', message: 'x' } } });
      assert.equal(out.parties.family.in_app, 'sent'); assert.equal(out.parties.family.sms, 'skipped');
    });
  });

  describe('real actions', () => {
    let cls; let parent; let student; let studentUser;
    before(async () => {
      cls = await Class.create({ tenant_id: tid, campus_id: f.campus.id, name: 'Standard 5', grade: '5', education_level: 'primary', academic_year: '2026' });
      parent = await mkUser('parent', { phone: '255712000001' });
      studentUser = await mkUser('student', { phone: '255799999999' });
      student = await Student.create({ tenant_id: tid, user_id: studentUser.id, parent_id: parent.id, campus_id: f.campus.id, class_id: cls.id, admission_number: `ADM-${uid()}`, admission_date: '2026-01-15', date_of_birth: '2014-03-03', gender: 'female', status: 'active' });
    });

    test('recording a payment texts the PARENT\'s phone (not the student\'s) and tells the finance office', async () => {
      await stubSms();
      await setAudience('payment_recorded', { family: ['in_app', 'sms'], staff: ['in_app'] });
      const res = await request(app).post('/api/v1/fees/payments').set(authHeader(f.token)).send({ student_id: student.id, amount: 50000, payment_method: 'cash', payment_date: '2026-10-01' });
      assert.equal(res.status, 201, JSON.stringify(res.body));
      assert.deepEqual(sms.sent, ['+255712000001'], 'only the parent\'s number');
      assert.equal((await inbox({ recipient_id: parent.id })).length, 1);
      assert.deepEqual(await roles({ title: 'Payment Received' }), ['accountant', 'admin']);
    });

    test('bulk admission: the parent notice and the leadership notice follow Settings', async () => {
      const row = (n, over = {}) => ({ __row: n + 1, first_name: `Neema${n}`, last_name: `Test${uid()}`, gender: 'Female', date_of_birth: '2014-04-18', admission_number: `ADM-N-${uid()}`, admission_date: '2026-01-15', campus_name: 'Main Campus', parent_name: 'Juma', parent_phone: '255713555001', ...over });
      let res = await request(app).post('/api/v1/students/bulk').set(authHeader(f.token)).send({ academic_year: '2026', students: [row(1)] });
      assert.equal(res.body.data.results[0].status, 'created', JSON.stringify(res.body));
      assert.equal(res.body.data.results[0].parent_notification, 'simulated', 'no gateway is active, and it says so');
      assert.deepEqual(await roles({ title: 'New Student Admitted' }), ['admin', 'principal']);
      await put({ event_key: 'student_admitted', audience: { admins: ['in_app'] } });
      await Notification.destroy({ where: { tenant_id: tid } });
      res = await request(app).post('/api/v1/students/bulk').set(authHeader(f.token)).send({ academic_year: '2026', students: [row(2)] });
      assert.equal(res.body.data.results[0].parent_notification, 'skipped', 'parent switched off');
      assert.deepEqual(await roles({ title: 'New Student Admitted' }), ['admin', 'principal']);
    });

    test('adding staff tells admins and HR, or just one of them', async () => {
      const row = (n) => ({ __row: n + 1, first_name: `Staff${n}`, last_name: `Member${uid()}`, email: `s${uid()}@school.co.tz`, phone: `2557${String(10000000 + Math.floor(Math.random() * 8e7))}`, role: 'Teacher', employee_number: `EMP-${uid()}`, campus_name: 'Main Campus', contract_type: 'Permanent' });
      let res = await request(app).post('/api/v1/staff/bulk').set(authHeader(f.token)).send({ staff: [row(1)] });
      assert.equal(res.body.data.summary.created, 1, JSON.stringify(res.body));
      assert.deepEqual(await roles({ title: 'Staff Added' }), ['admin', 'hr']);
      await Notification.destroy({ where: { tenant_id: tid } });
      await put({ event_key: 'staff_added', audience: { hr: ['in_app'] } });
      res = await request(app).post('/api/v1/staff/bulk').set(authHeader(f.token)).send({ staff: [row(2)] });
      assert.equal(res.body.data.summary.created, 1);
      assert.deepEqual(await roles({ title: 'Staff Added' }), ['hr']);
    });

    test('exam marks and fee reminders are addressed from the parent\'s details too', async () => {
      const m = (await familyContactsFor(tid, [student.id])).get(student.id);
      assert.equal(m.phone, '255712000001'); assert.equal(m.userId, parent.id); assert.equal(m.source, 'parent account');
    });
  });

  describe('who to reach about a student', () => {
    test('the parent\'s account wins, then the admission form, then the student\'s own phone; made-up emails are dropped', async () => {
      const parent = await mkUser('parent', { phone: '255712100001', email: `p-${uid()}@gmail.com` });
      const mkStudent = async (extra = {}, userExtra = {}) => {
        const u = await mkUser('student', { email: `s-${uid()}@school.local`, ...userExtra });
        return Student.create({ tenant_id: tid, user_id: u.id, campus_id: f.campus.id, admission_number: `ADM-${uid()}`, date_of_birth: '2013-01-01', gender: 'male', status: 'active', ...extra });
      };
      const a = await mkStudent({ parent_id: parent.id, parent_phone: '255799000000' }, { phone: '255788000000' });
      const b = await mkStudent({ parent_phone: '255713100002', parent_name: 'Mama Neema' }, { phone: '255788000001' });
      const c = await mkStudent({}, { phone: '255788000002' });
      const d = await mkStudent({});
      const m = await familyContactsFor(tid, [a, b, c, d]);
      assert.deepEqual([m.get(a.id).phone, m.get(a.id).source], ['255712100001', 'parent account']);
      assert.equal(m.get(a.id).email, parent.email);
      assert.deepEqual([m.get(b.id).phone, m.get(b.id).source, m.get(b.id).name], ['255713100002', 'admission form', 'Mama Neema']);
      assert.deepEqual([m.get(c.id).phone, m.get(c.id).source], ['255788000002', 'student account']);
      assert.equal(m.get(c.id).email, null, 'a …@school.local login is not an email address');
      assert.equal(m.get(d.id).phone, null); assert.equal(m.get(d.id).source, 'none');
    });
  });

  describe('fee reminders from Fee Status', () => {
    let ids; let parent;
    const reminder = (studentIds, balances = {}) => request(app).post('/api/v1/messaging/messages/send').set(authHeader(f.token))
      .send({ channel: 'sms', body: 'Dear Parent, {{student_name}} owes {{balance}}.', recipient_type: 'student_parents', student_ids: studentIds, student_balances: balances });
    before(async () => {
      parent = await mkUser('parent', { phone: '255712200001' });
      // The way every admission saved the parent's contact: NOT tied to the parent's login — which is what broke reminders.
      await Contact.create({ tenant_id: tid, name: 'Parent One', phone: '255712200001', type: 'parent', status: 'active' });
      const mk = async (extra) => { const u = await mkUser('student'); return Student.create({ tenant_id: tid, user_id: u.id, campus_id: f.campus.id, admission_number: `ADM-${uid()}`, date_of_birth: '2013-01-01', gender: 'female', status: 'active', ...extra }); };
      const s1 = await mk({ parent_id: parent.id });
      const s2 = await mk({ parent_phone: '255713200002', parent_name: 'Parent Two' });
      const s3 = await mk({ parent_id: parent.id });          // a sibling: one parent, two children
      const s4 = await mk({});                                // nobody to call
      ids = { s1: s1.id, s2: s2.id, s3: s3.id, s4: s4.id };
    });
    beforeEach(async () => { await stubSms(); });

    test('preview finds the parent by account and by the admission form, and names who cannot be reached', async () => {
      const res = await request(app).post('/api/v1/messaging/preview-recipients').set(authHeader(f.token)).send({ recipient_type: 'student_parents', channel: 'sms', student_ids: Object.values(ids) });
      assert.equal(res.body.data.count, 3);
      assert.equal(res.body.data.skipped.length, 1);
      assert.equal(res.body.data.skipped[0].reason, 'no parent phone number on file');
      assert.ok(res.body.data.skipped[0].student_name);
    });

    test('sending reaches every reachable parent (a sibling gets their own text) and reports who was left out', async () => {
      const res = await reminder(Object.values(ids), { [ids.s1]: 120000, [ids.s2]: 80000, [ids.s3]: 45000 });
      assert.equal(res.status, 200, JSON.stringify(res.body));
      assert.match(res.body.message, /Sent to 3 of 3/); assert.match(res.body.message, /1 student\(s\) were left out/);
      assert.equal(res.body.skipped_students.length, 1);
      assert.deepEqual([...new Set(sms.sent)].sort(), ['+255712200001', '+255713200002']);
      assert.equal(sms.sent.filter((n) => n === '+255712200001').length, 2, 'one parent, two children, two texts');
      const rows = await MessageRecipient.findAll({ where: { message_id: res.body.data.id } });
      assert.equal(rows.length, 3); assert.ok(rows.every((r) => r.status !== 'failed'));
    });

    test('the parent also gets an in-app copy (Outstanding Fee Reminder), and no second SMS', async () => {
      await setAudience('fee_balance_reminder', { family: ['in_app', 'sms'] });
      await reminder([ids.s1]);
      const mine = await inbox({ recipient_id: parent.id, title: 'Fee Reminder' });
      assert.equal(mine.length, 1);
      assert.equal(sms.sent.length, 1, 'the reminder SMS itself, only');
    });

    test('when nobody can be reached the message says who and why, not a generic error', async () => {
      const res = await reminder([ids.s4]);
      assert.equal(res.status, 400);
      assert.match(res.body.message, /None of the 1 selected student\(s\) can be reached: no parent phone number on file/);
      assert.equal(res.body.data.skipped_students.length, 1);
    });
  });

  describe('students without a class', () => {
    test('are listed (with no class) from their admission year, and not before it', async () => {
      const u = await mkUser('student');
      const s = await Student.create({ tenant_id: tid, user_id: u.id, campus_id: f.campus.id, admission_number: `ADM-${uid()}`, admission_date: '2026-01-10', date_of_birth: '2013-05-05', gender: 'male', status: 'active' });
      const list = async (year) => (await request(app).get('/api/v1/students').set(authHeader(f.token)).query({ academic_year: year, limit: 500 })).body.data;
      const mine = (await list('2026-2027')).find((x) => x.id === s.id);
      assert.ok(mine, 'a student admitted without a class must still be listed');
      assert.equal(mine.class, null); assert.equal(mine.historical_view.source, 'unassigned');
      assert.equal((await list('2025-2026')).find((x) => x.id === s.id), undefined, 'not yet admitted that year');
      assert.ok((await request(app).get('/api/v1/students').set(authHeader(f.token)).query({ limit: 500 })).body.data.find((x) => x.id === s.id), 'and without a year selected');
    });
  });

  describe('overdue library books', () => {
    const day = (offset) => new Date(Date.now() + offset * 86400000).toISOString().slice(0, 10);
    const lend = async (userId, dueOffset, bookId) => BookIssue.create({ tenant_id: tid, book_id: bookId, user_id: userId, issue_date: day(dueOffset - 14), due_date: day(dueOffset), status: 'issued' });
    let book;
    before(async () => { book = await Book.create({ tenant_id: tid, title: 'Physics Form 3', total_copies: 5, available_copies: 3 }); });

    test('the librarian is told once, when a loan first goes overdue', async () => {
      const borrower = await mkUser('teacher');
      const loan = await lend(borrower.id, -2, book.id);
      assert.equal(await refreshOverdueStatus(tid), 1);
      assert.equal((await loan.reload()).status, 'overdue');
      assert.deepEqual(await roles({ title: 'Library Book Overdue' }), ['librarian']);
      assert.equal(await refreshOverdueStatus(tid), 0);
      assert.equal((await inbox({ title: 'Library Book Overdue' })).length, 1, 'exactly once');
    });

    test('a staff borrower, or a student\'s parent, can be told as well when the school chooses', async () => {
      await setAudience('book_overdue', { librarian: ['in_app'], borrower: ['in_app'] });
      const teacher = await mkUser('teacher');
      await lend(teacher.id, -1, book.id);
      const parent = await mkUser('parent', { phone: '255712400001' });
      const su = await mkUser('student');
      await Student.create({ tenant_id: tid, user_id: su.id, parent_id: parent.id, campus_id: f.campus.id, admission_number: `ADM-${uid()}`, date_of_birth: '2013-01-01', gender: 'male', status: 'active' });
      await lend(su.id, -1, book.id);
      await refreshOverdueStatus(tid);
      assert.equal((await inbox({ recipient_id: teacher.id })).length, 1, 'the staff member');
      assert.equal((await inbox({ recipient_id: parent.id })).length, 1, 'the student\'s parent, not the student');
      assert.equal((await inbox({ recipient_id: su.id })).length, 0);
    });

    test('a loan that has been overdue for weeks is flipped quietly, not announced', async () => {
      const borrower = await mkUser('teacher');
      await lend(borrower.id, -40, book.id);
      await refreshOverdueStatus(tid);
      assert.equal((await inbox()).length, 0);
    });
  });

  describe('upgrading from the old settings', () => {
    test('existing choices carry over; the two merged pairs fold into one notification each; running it twice changes nothing', async () => {
      await NotificationSetting.destroy({ where: { tenant_id: tid } });
      const row = (event_key, enabled, channels) => ({ tenant_id: tid, event_key, enabled, channels, audience: null });
      await NotificationSetting.bulkCreate([
        row('payment_recorded', true, ['in_app', 'sms']), row('payment_received_staff', false, ['in_app']),
        row('admission_completed', true, ['sms', 'email']), row('student_admitted', false, ['in_app']),
        row('leave_request_submitted', true, ['in_app', 'email']), row('expense_recorded', false, ['in_app']),
        row('timetable_published', true, ['sms']),
      ]);
      const migrate = () => audienceMigration.up(sequelize.getQueryInterface(), Sequelize, undefined);
      await migrate();
      const rows = Object.fromEntries((await NotificationSetting.findAll({ where: { tenant_id: tid } })).map((r) => [r.event_key, r]));
      assert.equal(rows.payment_received_staff, undefined); assert.equal(rows.admission_completed, undefined);
      assert.deepEqual([rows.payment_recorded.enabled, rows.payment_recorded.audience], [true, { family: ['in_app', 'sms'] }], 'staff copy was off, so only the parent stays');
      assert.deepEqual([rows.student_admitted.enabled, rows.student_admitted.audience], [true, { family: ['sms', 'email'] }], 'parent notice was on, leadership notice off');
      assert.deepEqual(rows.leave_request_submitted.audience, { approvers: ['in_app', 'email'] });
      assert.equal(rows.expense_recorded.enabled, false);
      assert.deepEqual(Object.keys(rows.expense_recorded.audience).sort(), ['accountants', 'admins'], 'switched off, but ready to switch on again');
      assert.deepEqual(rows.timetable_published.audience, { teachers: ['sms'], students: ['sms'] });
      const before = JSON.stringify(Object.values(rows).map((r) => [r.event_key, r.enabled, r.audience]).sort());
      await migrate();
      const after = Object.fromEntries((await NotificationSetting.findAll({ where: { tenant_id: tid } })).map((r) => [r.event_key, r]));
      assert.equal(JSON.stringify(Object.values(after).map((r) => [r.event_key, r.enabled, r.audience]).sort()), before);
    });
  });
});
