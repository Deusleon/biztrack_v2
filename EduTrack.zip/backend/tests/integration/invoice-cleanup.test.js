/**
 * Invoice numbers and clean-up.
 *   - a number is never issued twice, even after invoices are deleted;
 *   - the clean-up removes cancelled and long-unpaid invoices and nothing else
 *     (a paid invoice, one awaiting approval, a recent unpaid one, or another school's);
 *   - the automatic job does the same on a schedule.
 */
import '../helpers/noMail.js';
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import request from 'supertest';
import { QueryTypes } from 'sequelize';
import sequelize from '../../src/config/database.js';
import app from '../../src/server.js';
import { User, Subscription, SubscriptionInvoice, SubscriptionPlan, AuditLog } from '../../src/models/index.js';
import { seedSubscriptionPlans } from '../../src/utils/seedSubscriptionPlans.js';
import { cancelStaleInvoices, purgeOldCancelledInvoices } from '../../src/jobs/subscriptionJobs.js';
import { nextInvoiceNumber } from '../../src/utils/invoiceNumber.js';
import { buildTenantFixture, closeDb } from '../helpers/testFixture.js';

const DAY = 86400000;
const bearer = (user) => ({ Authorization: `Bearer ${jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '2h' })}` });
const serial = (n) => Number(n.match(/-(\d+)$/)[1]);

describe('invoice numbers and clean-up', () => {
  let tenant, admin, teacher, other, subscription, plan, seq = 1;

  const make = (t, sub, over = {}) => SubscriptionInvoice.create({
    tenant_id: t.id, subscription_id: sub.id, plan_id: plan.id,
    invoice_number: `INV-CLEANTEST-${Date.now()}-${seq++}`, order_reference: `EDUCLEAN${Date.now()}${seq++}`,
    line_items: [{ label: 'Standard plan', amount: 1000 }], billing_cycle: 'monthly', subtotal: 1000, proration_credit: 0, total: 1000,
    currency: 'TZS', status: 'pending', kind: 'new', gateway: null, period_start: new Date(), period_end: new Date(Date.now() + 30 * DAY), ...over,
  });
  /** Moves an invoice's dates into the past (the model won't let you set them directly). */
  const age = (invoice, days) => sequelize.query(
    'UPDATE subscription_invoices SET created_at = :d, updated_at = :d WHERE id = :id',
    { replacements: { d: new Date(Date.now() - days * DAY), id: invoice.id }, type: QueryTypes.UPDATE },
  );
  const exists = async (invoice) => Boolean(await SubscriptionInvoice.findByPk(invoice.id));

  before(async () => {
    await seedSubscriptionPlans();
    plan = await SubscriptionPlan.findOne({ where: { code: 'standard' } });
    const fx = await buildTenantFixture('invclean');
    tenant = fx.tenant; admin = fx.admin;
    teacher = await User.create({ tenant_id: tenant.id, email: `t-${tenant.slug}@example.test`, password: 'Password123!', first_name: 'T', last_name: 'T', role: 'teacher', status: 'active' });
    subscription = await Subscription.create({ tenant_id: tenant.id, status: 'active', plan_id: plan.id, billing_cycle: 'monthly', ends_at: new Date(Date.now() + 30 * DAY), grace_days: 2 });
    const fx2 = await buildTenantFixture('invclean-other');
    other = { tenant: fx2.tenant, subscription: await Subscription.create({ tenant_id: fx2.tenant.id, status: 'active', plan_id: plan.id, billing_cycle: 'monthly', ends_at: new Date(Date.now() + 30 * DAY), grace_days: 2 }) };
  });
  after(closeDb);

  describe('numbers are never reused', () => {
    test('they only go up, including after the newest invoice is deleted', async () => {
      const made = [];
      for (let i = 0; i < 3; i += 1) {
        const res = await request(app).post('/api/v1/subscription/checkout').set(bearer(admin)).send({ plan_id: plan.id, billing_cycle: 'monthly' });
        assert.equal(res.status, 201);
        made.push(res.body.data.invoice.invoice_number);
      }
      assert.deepEqual([...made].sort(), made, 'in order');
      assert.equal(new Set(made).size, 3);

      // cancel the newest and clean it up, then create another: it must NOT take the freed number
      assert.equal((await request(app).post(`/api/v1/subscription/invoices/${made[2]}/cancel`).set(bearer(admin))).status, 200);
      assert.equal((await request(app).post('/api/v1/subscription/invoice-cleanup').set(bearer(admin))).status, 200);
      assert.equal(await SubscriptionInvoice.count({ where: { invoice_number: made[2] } }), 0, 'the invoice is gone');
      const again = await request(app).post('/api/v1/subscription/checkout').set(bearer(admin)).send({ plan_id: plan.id, billing_cycle: 'monthly' });
      assert.ok(serial(again.body.data.invoice.invoice_number) > serial(made[2]), 'the freed number is not reused');
    });

    test('creating many at once never collides', async () => {
      const numbers = await Promise.all(Array.from({ length: 12 }, () => nextInvoiceNumber()));
      assert.equal(new Set(numbers).size, 12);
    });
  });

  describe('the clean-up', () => {
    test('shows what it would remove, removes exactly that, and records it', async () => {
      const cancelled = await make(tenant, subscription, { status: 'cancelled' });
      const oldPending = await make(tenant, subscription); await age(oldPending, 31);
      const oldFailed = await make(tenant, subscription, { status: 'failed' }); await age(oldFailed, 45);
      // these must survive
      const recentPending = await make(tenant, subscription);
      const recentFailed = await make(tenant, subscription, { status: 'failed' }); await age(recentFailed, 5);
      const waiting = await make(tenant, subscription, { status: 'processing', gateway: 'clickpesa' }); await age(waiting, 60);
      const paid = await make(tenant, subscription, { status: 'paid', paid_at: new Date(Date.now() - 90 * DAY) }); await age(paid, 90);
      const othersCancelled = await make(other.tenant, other.subscription, { status: 'cancelled' });

      const preview = await request(app).get('/api/v1/subscription/invoice-cleanup').set(bearer(admin));
      assert.equal(preview.status, 200);
      assert.ok(preview.body.data.cancelled >= 1 && preview.body.data.unpaid_old >= 2);
      assert.equal(await exists(cancelled), true, 'a preview removes nothing');

      const done = await request(app).post('/api/v1/subscription/invoice-cleanup').set(bearer(admin));
      assert.equal(done.status, 200);
      assert.ok(done.body.data.removed >= 3);

      assert.equal(await exists(cancelled), false);
      assert.equal(await exists(oldPending), false);
      assert.equal(await exists(oldFailed), false);
      for (const kept of [recentPending, recentFailed, waiting, paid, othersCancelled]) assert.equal(await exists(kept), true, `${kept.invoice_number} must be kept`);

      const entries = await AuditLog.findAll({ where: { tenant_id: tenant.id, user_id: admin.id }, order: [['createdAt', 'DESC']], limit: 20 });
      const entry = entries.find((e) => /^Cleaned up \d+ old invoice/.test(e.action));
      assert.ok(entry, 'the clean-up is in the audit log, under the person who ran it');
      assert.ok(entry.details.invoices.some((s) => s.startsWith(cancelled.invoice_number)), 'it lists which invoices went');
    });

    test('running it again finds nothing; only an administrator can run it', async () => {
      const again = await request(app).post('/api/v1/subscription/invoice-cleanup').set(bearer(admin));
      assert.equal(again.body.data.removed, 0);
      assert.equal((await request(app).get('/api/v1/subscription/invoice-cleanup').set(bearer(teacher))).status, 403);
      assert.equal((await request(app).post('/api/v1/subscription/invoice-cleanup').set(bearer(teacher))).status, 403);
    });
  });

  describe('the automatic job', () => {
    test('cancels invoices unpaid for 30 days, and removes ones cancelled for over 90', async () => {
      const stale = await make(tenant, subscription); await age(stale, 31);
      const fresh = await make(tenant, subscription); await age(fresh, 20);
      const longCancelled = await make(tenant, subscription, { status: 'cancelled' }); await age(longCancelled, 100);
      const recentlyCancelled = await make(tenant, subscription, { status: 'cancelled' }); await age(recentlyCancelled, 10);
      const paid = await make(tenant, subscription, { status: 'paid', paid_at: new Date() }); await age(paid, 400);

      await cancelStaleInvoices();
      await purgeOldCancelledInvoices();

      assert.equal((await SubscriptionInvoice.findByPk(stale.id)).status, 'cancelled', 'cancelled, not deleted');
      assert.equal((await SubscriptionInvoice.findByPk(fresh.id)).status, 'pending');
      assert.equal(await exists(longCancelled), false);
      assert.equal(await exists(recentlyCancelled), true);
      assert.equal(await exists(paid), true, 'a paid invoice is never touched, however old');
    });
  });
});
