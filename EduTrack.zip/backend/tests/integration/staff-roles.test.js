/**
 * staff-roles.test.js
 *
 * Changing a staff member's role used to look like it saved but never did (the
 * update handler ignored `role`), and the add form started with "Teacher"
 * already chosen. Now the chosen role is what is stored — and, because the
 * update handler now accepts it, only people allowed to hand out roles can.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'crypto';
import request from 'supertest';
import app from '../../src/server.js';
import { User, Staff } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';

let counter = 0;
describe('Staff — creating and changing roles', () => {
  let f; let admin;
  const tokenFor = (user) => ({ Authorization: `Bearer ${jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' })}` });

  const addStaff = (headers, role, extra = {}) => {
    counter += 1;
    const n = `${Date.now()}${counter}`;
    return request(app).post('/api/v1/staff').set(headers).send({
      email: `staff-${n}@example.test`, first_name: 'Asha', last_name: 'Mwita', phone: `0712${n.slice(-6)}`,
      employee_number: `EMP-${n}`, campus_id: f.campus.id, ...(role !== undefined ? { role } : {}), ...extra,
    });
  };
  const roleOf = async (res) => (await User.findByPk(res.body.data.user_id)).role;
  const makeUser = (role) => User.create({
    tenant_id: f.tenant.id, email: `${role}-${randomUUID().slice(0, 6)}@example.test`, password: 'Password123!',
    first_name: role, last_name: 'User', role, status: 'active',
  });

  before(async () => { f = await buildTenantFixture('staff-roles'); admin = authHeader(f.token); });
  after(closeDb);

  test('the role chosen when adding is the role stored', async () => {
    for (const role of ['accountant', 'librarian', 'hr', 'transport_manager', 'hostel_warden', 'teacher']) {
      const res = await addStaff(admin, role);
      assert.equal(res.status, 201, `${role}: ${res.body.message}`);
      assert.equal(await roleOf(res), role);
    }
  });

  test('no role chosen is refused — nothing is silently assumed', async () => {
    const res = await addStaff(admin, undefined);
    assert.equal(res.status, 400);
    assert.ok(res.body.errors.some((e) => e.field === 'role'));
  });

  test('roles that do not exist (support_staff) or cannot be handed out (super_admin) are refused cleanly', async () => {
    assert.equal((await addStaff(admin, 'support_staff')).status, 400);
    assert.equal((await addStaff(admin, 'super_admin')).status, 400);
  });

  test('editing a staff member CAN change their role', async () => {
    const created = await addStaff(admin, 'accountant');
    const res = await request(app).put(`/api/v1/staff/${created.body.data.id}`).set(admin).send({ role: 'librarian', first_name: 'Asha2' });
    assert.equal(res.status, 200);
    assert.equal(await roleOf(created), 'librarian');
    assert.equal((await User.findByPk(created.body.data.user_id)).first_name, 'Asha2', 'other fields still save with it');
  });

  test('an edit that leaves the role alone does not touch it', async () => {
    const created = await addStaff(admin, 'hr');
    await request(app).put(`/api/v1/staff/${created.body.data.id}`).set(admin).send({ role: 'hr', department: 'People' });
    assert.equal(await roleOf(created), 'hr');
    await request(app).put(`/api/v1/staff/${created.body.data.id}`).set(admin).send({ department: 'People 2' }); // no role sent at all
    assert.equal(await roleOf(created), 'hr');
  });

  test('a non-existent role in an edit is refused and nothing else is saved', async () => {
    const created = await addStaff(admin, 'accountant');
    const res = await request(app).put(`/api/v1/staff/${created.body.data.id}`).set(admin).send({ role: 'support_staff', first_name: 'ShouldNotSave' });
    assert.equal(res.status, 400);
    const user = await User.findByPk(created.body.data.user_id);
    assert.equal(user.role, 'accountant');
    assert.notEqual(user.first_name, 'ShouldNotSave');
  });

  test('you cannot change your own role', async () => {
    const me = await makeUser('admin');
    const staff = await Staff.create({ tenant_id: f.tenant.id, user_id: me.id, campus_id: f.campus.id, employee_number: `SELF-${randomUUID().slice(0, 6)}` });
    const res = await request(app).put(`/api/v1/staff/${staff.id}`).set(tokenFor(me)).send({ role: 'teacher' });
    assert.equal(res.status, 403);
    assert.match(res.body.message, /own role/);
    assert.equal((await User.findByPk(me.id)).role, 'admin');
  });

  test('a super admin\'s role cannot be changed here', async () => {
    const boss = await makeUser('super_admin');
    const staff = await Staff.create({ tenant_id: f.tenant.id, user_id: boss.id, campus_id: f.campus.id, employee_number: `SA-${randomUUID().slice(0, 6)}` });
    const res = await request(app).put(`/api/v1/staff/${staff.id}`).set(admin).send({ role: 'teacher' });
    assert.equal(res.status, 403);
    assert.equal((await User.findByPk(boss.id)).role, 'super_admin');
  });

  test('a principal can reassign everyday roles but cannot make anyone an admin', async () => {
    const principal = await makeUser('principal');
    const p = tokenFor(principal);
    const created = await addStaff(admin, 'teacher');
    assert.equal((await request(app).put(`/api/v1/staff/${created.body.data.id}`).set(p).send({ role: 'accountant' })).status, 200);
    assert.equal(await roleOf(created), 'accountant');

    const escalate = await request(app).put(`/api/v1/staff/${created.body.data.id}`).set(p).send({ role: 'admin' });
    assert.equal(escalate.status, 403);
    assert.equal(await roleOf(created), 'accountant');
    assert.equal((await addStaff(p, 'admin')).status, 403, 'nor create one');
  });

  test('a teacher cannot promote themselves or anyone else', async () => {
    const teacher = await makeUser('teacher');
    const t = tokenFor(teacher);
    const mine = await Staff.create({ tenant_id: f.tenant.id, user_id: teacher.id, campus_id: f.campus.id, employee_number: `T-${randomUUID().slice(0, 6)}` });
    assert.equal((await request(app).put(`/api/v1/staff/${mine.id}`).set(t).send({ role: 'admin' })).status, 403);
    assert.equal((await User.findByPk(teacher.id)).role, 'teacher');

    const other = await addStaff(admin, 'accountant');
    assert.equal((await request(app).put(`/api/v1/staff/${other.body.data.id}`).set(t).send({ role: 'admin' })).status, 403);
    assert.equal((await addStaff(t, 'admin')).status, 403);
  });
});
