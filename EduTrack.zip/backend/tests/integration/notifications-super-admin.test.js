/**
 * notifications-super-admin.test.js
 *
 * Every role-broadcast notification in the codebase (student admitted,
 * payment received, staff added, leave submitted, ...) targets roles
 * like 'admin', 'principal', 'accountant' — never 'super_admin'
 * specifically. Without the fix, a super_admin's bell was empty for
 * every event that ever fires, since the query only ever matched
 * notifications addressed exactly to their own role.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import { User, Notification } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';
import jwt from 'jsonwebtoken';

describe('Notifications — super_admin sees admin-broadcast notifications', () => {
  let fixture;
  let superAdminToken;

  before(async () => {
    fixture = await buildTenantFixture('notifsuper');
    const { tenant } = fixture;

    const superAdminUser = await User.create({
      tenant_id: tenant.id, email: `superadmin-${tenant.slug}@example.test`, password: 'Password123!',
      first_name: 'Super', last_name: 'Admin', role: 'super_admin', status: 'active',
    });
    superAdminToken = jwt.sign({ id: superAdminUser.id }, process.env.JWT_SECRET, { expiresIn: '1h' });

    // Simulates what notifyEvent produces for e.g. 'student_admitted'
    // (recipientRoles: ['admin', 'principal']) — broadcast to 'admin',
    // never to 'super_admin' by name.
    await Notification.create({
      tenant_id: tenant.id, recipient_role: 'admin', recipient_id: null,
      title: 'New Student Admitted', message: 'Test Pupil has been admitted.',
      type: 'info', channel: 'in_app', status: 'sent', sent_at: new Date(), is_read: false,
    });
    // A notification for a role super_admin should NOT inherit, to prove
    // the fix isn't just "show everything".
    await Notification.create({
      tenant_id: tenant.id, recipient_role: 'teacher', recipient_id: null,
      title: 'Timetable Updated', message: 'Your timetable changed.',
      type: 'info', channel: 'in_app', status: 'sent', sent_at: new Date(), is_read: false,
    });
  });

  after(closeDb);

  test('GET /notifications includes the admin-broadcast notification for a super_admin', async () => {
    const res = await request(app)
      .get('/api/v1/notifications')
      .set(authHeader(superAdminToken));

    assert.equal(res.status, 200);
    const titles = res.body.data.map((n) => n.title);
    assert.ok(titles.includes('New Student Admitted'), 'super_admin should see admin-targeted notifications');
    assert.ok(!titles.includes('Timetable Updated'), 'super_admin should NOT see teacher-only notifications');
  });

  test('GET /notifications/unread-count counts the admin-broadcast notification too', async () => {
    const res = await request(app)
      .get('/api/v1/notifications/unread-count')
      .set(authHeader(superAdminToken));

    assert.equal(res.status, 200);
    assert.equal(res.body.data.count, 1);
  });

  test('a plain admin (not super_admin) still only sees their own role\'s notifications, unaffected', async () => {
    const adminUser = await User.create({
      tenant_id: fixture.tenant.id, email: `plainadmin-${fixture.tenant.slug}@example.test`, password: 'Password123!',
      first_name: 'Plain', last_name: 'Admin', role: 'admin', status: 'active',
    });
    const adminToken = jwt.sign({ id: adminUser.id }, process.env.JWT_SECRET, { expiresIn: '1h' });

    const res = await request(app)
      .get('/api/v1/notifications')
      .set(authHeader(adminToken));

    assert.equal(res.status, 200);
    const titles = res.body.data.map((n) => n.title);
    assert.ok(titles.includes('New Student Admitted'));
    assert.ok(!titles.includes('Timetable Updated'));
  });
});
