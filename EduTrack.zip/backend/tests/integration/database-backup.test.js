/**
 * database-backup.test.js — the full-database backup, its restore test, the Google Drive link, the daily schedule,
 * and the "back up before a risky action" guard. Real Postgres, real files, real restore — Google itself is stubbed.
 */
import { test, describe, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs';
import os from 'os';
import path from 'path';
import zlib from 'zlib';
import request from 'supertest';
import app from '../../src/server.js';
import sequelize from '../../src/config/database.js';
import { User, DatabaseBackup, DatabaseBackupSettings } from '../../src/models/index.js';
import { createDump, verifyBackupFile } from '../../src/services/backup/dumpEngine.js';
import * as svc from '../../src/services/backup/backupService.js';
import * as drive from '../../src/services/backup/driveStorage.js';
import { readState } from '../../src/services/backup/secretBox.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';
import jwt from 'jsonwebtoken';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'edutrack-backup-test-'));
process.env.BACKUP_DIR = tmp;
const realFetch = globalThis.fetch;

describe('Full database backup', () => {
  let school; let dev; let devToken;

  before(async () => {
    school = await buildTenantFixture('backup');
    const unique = Date.now();
    dev = await User.create({ tenant_id: school.tenant.id, email: `dev-${unique}@example.test`, password: 'Password123!', first_name: 'Dev', last_name: 'Owner', role: 'super_admin', status: 'active' });
    process.env.DEVELOPER_EMAILS = dev.email;
    devToken = jwt.sign({ id: dev.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
  });
  beforeEach(async () => {
    globalThis.fetch = realFetch;
    await DatabaseBackup.destroy({ where: {} });
    await DatabaseBackupSettings.destroy({ where: {} });
  });
  after(async () => { globalThis.fetch = realFetch; fs.rmSync(tmp, { recursive: true, force: true }); await closeDb(); });

  const tablesInDb = async () => (await sequelize.query("SELECT relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind='r' AND NOT EXISTS (SELECT 1 FROM pg_depend d WHERE d.objid = c.oid AND d.deptype = 'e') ORDER BY 1", { type: 'SELECT' })).map((r) => r.relname);

  describe('the dump and the restore test', () => {
    test('includes EVERY table in the database, and restores to identical contents', async () => {
      const file = path.join(tmp, 'all.sql.gz');
      const d = await createDump(file, { label: 'test' });
      assert.deepEqual(Object.keys(d.manifest.tables).sort(), await tablesInDb(), 'every table must be in the backup');
      assert.ok(d.manifest.tables.users.rows > 0);
      const v = await verifyBackupFile(file, { expectedSha256: d.sha256 });
      assert.equal(v.ok, true, v.problems.join('; '));
      const left = await sequelize.query("SELECT 1 FROM pg_namespace WHERE nspname='edutrack_restore_test'", { type: 'SELECT' });
      assert.equal(left.length, 0, 'the restore test must leave nothing behind');
    });

    test('a value changed inside the file is caught by the checksum', async () => {
      const file = path.join(tmp, 'tamper.sql.gz');
      await createDump(file);
      const lines = zlib.gunzipSync(fs.readFileSync(file)).toString('utf8').split('\n');
      const i = lines.findIndex((l) => l.startsWith('INSERT INTO "users"'));
      const m = lines[i].match(/E'([A-Z][a-z]{3,})'/);
      lines[i] = lines[i].replace(m[0], "E'Zzzzz'");
      const bad = path.join(tmp, 'tampered.sql.gz');
      fs.writeFileSync(bad, zlib.gzipSync(lines.join('\n')));
      const v = await verifyBackupFile(bad);
      assert.equal(v.ok, false);
      assert.match(v.problems.join(' '), /contents differ/);
    });

    test('a file that was cut short is rejected', async () => {
      const file = path.join(tmp, 'cut.sql.gz');
      await createDump(file);
      const lines = zlib.gunzipSync(fs.readFileSync(file)).toString('utf8').split('\n');
      const bad = path.join(tmp, 'cut2.sql.gz');
      fs.writeFileSync(bad, zlib.gzipSync(lines.slice(0, Math.floor(lines.length / 2)).join('\n')));
      const v = await verifyBackupFile(bad);
      assert.equal(v.ok, false);
      assert.match(v.problems.join(' '), /incomplete/);
    });

    test('a backup that names the live schema is refused, never run', async () => {
      const file = path.join(tmp, 'evil.sql.gz');
      await createDump(file);
      const lines = zlib.gunzipSync(fs.readFileSync(file)).toString('utf8').split('\n');
      lines.splice(6, 0, 'DROP TABLE public.users;');
      const bad = path.join(tmp, 'evil2.sql.gz');
      fs.writeFileSync(bad, zlib.gzipSync(lines.join('\n')));
      assert.equal((await verifyBackupFile(bad)).ok, false);
      assert.ok(await User.count() > 0, 'live data untouched');
    });

    test('a table that belongs to an extension (PostGIS\'s spatial_ref_sys) is left out whole — table, keys and indexes — and the restore test still passes', async (t) => {
      // plpgsql is an extension that is always installed; making a table a member of it is exactly how PostGIS owns spatial_ref_sys.
      try {
        await sequelize.query('DROP TABLE IF EXISTS zz_ext_owned CASCADE');
        await sequelize.query('CREATE TABLE zz_ext_owned (srid integer PRIMARY KEY CHECK (srid > 0), auth_name varchar(50))');
        await sequelize.query('CREATE INDEX zz_ext_owned_auth_idx ON zz_ext_owned (auth_name)');
        await sequelize.query('ALTER EXTENSION plpgsql ADD TABLE zz_ext_owned');
      } catch (err) { t.skip(`needs a database user allowed to alter extensions: ${err.message}`); return; }
      try {
        const file = path.join(tmp, 'ext.sql.gz');
        const d = await createDump(file);
        assert.ok(!('zz_ext_owned' in d.manifest.tables), 'not backed up as a table');
        assert.ok(!zlib.gunzipSync(fs.readFileSync(file)).toString('utf8').includes('zz_ext_owned'), 'and nothing else in the file mentions it either');
        const v = await verifyBackupFile(file, { expectedSha256: d.sha256 });
        assert.equal(v.ok, true, v.problems.join('; '));
      } finally {
        await sequelize.query('ALTER EXTENSION plpgsql DROP TABLE zz_ext_owned').catch(() => {});
        await sequelize.query('DROP TABLE IF EXISTS zz_ext_owned CASCADE');
      }
    });

    test('a backup that changes a table it never creates is refused (it would otherwise act on the live table)', async () => {
      const file = path.join(tmp, 'sneaky.sql.gz');
      await createDump(file);
      const lines = zlib.gunzipSync(fs.readFileSync(file)).toString('utf8').split('\n');
      lines.splice(6, 0, 'ALTER TABLE "users" ADD CONSTRAINT zz_sneaky CHECK (true);');
      const bad = path.join(tmp, 'sneaky2.sql.gz');
      fs.writeFileSync(bad, zlib.gzipSync(lines.join('\n')));
      const v = await verifyBackupFile(bad);
      assert.equal(v.ok, false);
      assert.match(v.problems.join(' '), /never creates it/);
      const [c] = await sequelize.query("SELECT count(*)::int n FROM pg_constraint WHERE conname = 'zz_sneaky'", { type: 'SELECT' });
      assert.equal(c.n, 0, 'the live table was not touched');
    });

    test('special characters, newlines and quotes survive the round trip', async () => {
      const weird = "O'Brien \\ \"quoted\"\nsecond line\ttab; DROP TABLE x; -- ☃ 日本語";
      const u = await User.create({ tenant_id: school.tenant.id, email: `weird-${Date.now()}@example.test`, password: 'Password123!', first_name: weird, last_name: 'Test', role: 'teacher', status: 'active' });
      const file = path.join(tmp, 'weird.sql.gz');
      const d = await createDump(file);
      assert.equal((await verifyBackupFile(file, { expectedSha256: d.sha256 })).ok, true);
      await u.destroy();
    });
  });

  describe('running a backup', () => {
    test('runBackup makes a tested backup and records it', async () => {
      const row = await svc.runBackup({ trigger: 'manual', reason: 'test' });
      assert.equal(row.status, 'success', row.error);
      assert.equal(row.verify_status, 'passed');
      assert.equal(row.drive_status, 'skipped');
      assert.ok(fs.existsSync(path.join(tmp, row.file_name)));
      assert.equal(row.table_count, (await tablesInDb()).length);
    });

    test('a failure is recorded as failed, not hidden', async () => {
      const real = process.env.BACKUP_DIR;
      const blocker = path.join(tmp, 'a-file');
      fs.writeFileSync(blocker, 'x');
      process.env.BACKUP_DIR = path.join(blocker, 'sub'); // a folder cannot be made inside a file
      try {
        const row = await svc.runBackup({ trigger: 'manual' });
        assert.equal(row.status, 'failed');
        assert.ok(row.error && row.error.length > 5, 'the reason is kept');
      } finally { process.env.BACKUP_DIR = real; }
    });

    test('old backups are removed after the retention period, but the newest good ones are always kept', async () => {
      const s = await drive.getSettings();
      await s.update({ retention_days: 3 });
      const rows = [];
      for (let i = 0; i < 5; i += 1) {
        const name = `old-${i}.sql.gz`;
        fs.writeFileSync(path.join(tmp, name), 'x');
        const r = await DatabaseBackup.create({ trigger: 'scheduled', status: 'success', verify_status: 'passed', file_name: name });
        await sequelize.query('UPDATE database_backups SET created_at = :d WHERE id = :id', { replacements: { d: new Date(Date.now() - (10 + i) * 86400000), id: r.id } });
        rows.push(r);
      }
      const removed = await svc.pruneOld();
      assert.equal(removed, 2, 'three newest good backups stay, the rest go');
      const gone = await DatabaseBackup.count({ where: { file_deleted: true } });
      assert.equal(gone, 2);
    });
  });

  describe('the daily schedule', () => {
    test('runs once when due, then not again the same day', async () => {
      const s = await drive.getSettings();
      await s.update({ enabled: true, run_at_hour: 0 });
      const first = await svc.runDueBackup();
      assert.ok(first && first.status === 'success', first?.error);
      assert.equal(first.trigger, 'scheduled');
      assert.equal(await svc.runDueBackup(), null, 'already backed up today');
    });
    test('does nothing when switched off', async () => {
      const s = await drive.getSettings();
      await s.update({ enabled: false, run_at_hour: 0 });
      assert.equal(await svc.runDueBackup(), null);
    });
    test('waits for the set hour', async () => {
      const s = await drive.getSettings();
      const hourNow = svc.localParts().hour;
      if (hourNow >= 23) return; // cannot construct a later hour right at midnight edge
      await s.update({ enabled: true, run_at_hour: hourNow + 1 });
      assert.equal(await svc.runDueBackup(), null);
    });
    test('a backup that failed a moment ago is not retried straight away', async () => {
      const s = await drive.getSettings();
      await s.update({ enabled: true, run_at_hour: 0 });
      await DatabaseBackup.create({ trigger: 'scheduled', status: 'failed', error: 'x' });
      assert.equal(await svc.runDueBackup(), null);
    });
  });

  describe('backup before a risky action', () => {
    // the guard is normally off under tests; these cases switch it on
    const asProduction = async (fn) => { process.env.BACKUP_FORCE_IN_TESTS = '1'; try { return await fn(); } finally { delete process.env.BACKUP_FORCE_IN_TESTS; } };

    test('makes a fresh tested backup first', async () => {
      const row = await asProduction(() => svc.ensureBackupBeforeRiskyAction({ reason: 'running a student promotion' }));
      assert.equal(row.status, 'success');
      assert.equal(row.trigger, 'before_action');
      assert.match(row.reason, /promotion/);
    });
    test('reuses a good backup made minutes ago instead of repeating', async () => {
      const a = await asProduction(() => svc.ensureBackupBeforeRiskyAction({ reason: 'x' }));
      const b = await asProduction(() => svc.ensureBackupBeforeRiskyAction({ reason: 'y' }));
      assert.equal(a.id, b.id);
    });
    test('blocks the action when the backup cannot be made', async () => {
      const real = process.env.BACKUP_DIR;
      const blocker = path.join(tmp, 'blocker-file');
      fs.writeFileSync(blocker, 'x');
      process.env.BACKUP_DIR = path.join(blocker, 'sub');
      try {
        await asProduction(async () => {
          await assert.rejects(() => svc.ensureBackupBeforeRiskyAction({ reason: 'running a student promotion' }), (e) => e.code === 'BACKUP_REQUIRED');
        });
      } finally { process.env.BACKUP_DIR = real; }
    });
    test('can be switched off by the owner', async () => {
      const s = await drive.getSettings();
      await s.update({ protect_risky_actions: false });
      assert.equal(await asProduction(() => svc.ensureBackupBeforeRiskyAction({ reason: 'x' })), null);
    });
    test('the promotion screen is stopped with a clear message when no backup can be made', async () => {
      const real = process.env.BACKUP_DIR;
      const blocker = path.join(tmp, 'blocker-file-2');
      fs.writeFileSync(blocker, 'x');
      process.env.BACKUP_DIR = path.join(blocker, 'sub');
      try {
        await asProduction(async () => {
          const res = await request(app).post('/api/v1/promotions/run').set(authHeader(school.token)).send({});
          assert.equal(res.status, 503);
          assert.match(res.body.message, /backup/i);
        });
      } finally { process.env.BACKUP_DIR = real; }
    });
  });

  describe('who can use it (API)', () => {
    test('a school admin gets 403 — a full backup holds every school', async () => {
      for (const [m, p] of [['get', '/api/v1/backups'], ['post', '/api/v1/backups/run'], ['get', '/api/v1/backups/drive/auth-url']]) {
        const res = await request(app)[m](p).set(authHeader(school.token));
        assert.equal(res.status, 403, `${m} ${p}`);
      }
    });
    test('the developer sees status, can change settings, and bad values are refused', async () => {
      const res = await request(app).get('/api/v1/backups').set(authHeader(devToken));
      assert.equal(res.status, 200);
      assert.equal(res.body.data.settings.run_at_hour, 2);
      assert.equal(res.body.data.drive.connected, false);
      const ok = await request(app).put('/api/v1/backups/settings').set(authHeader(devToken)).send({ run_at_hour: 4, retention_days: 30 });
      assert.equal(ok.status, 200);
      assert.equal((await request(app).put('/api/v1/backups/settings').set(authHeader(devToken)).send({ run_at_hour: 25 })).status, 400);
      assert.equal((await request(app).put('/api/v1/backups/settings').set(authHeader(devToken)).send({ retention_days: 1 })).status, 400);
      assert.equal((await request(app).put('/api/v1/backups/settings').set(authHeader(devToken)).send({ drive_enabled: true })).status, 400, 'cannot upload before connecting');
    });
    test('Back up now starts a backup, which finishes with a passed restore test, and can be downloaded', async () => {
      const start = await request(app).post('/api/v1/backups/run').set(authHeader(devToken));
      assert.equal(start.status, 202);
      let row;
      for (let i = 0; i < 60; i += 1) {
        const o = await request(app).get('/api/v1/backups').set(authHeader(devToken));
        row = o.body.data.backups[0];
        if (row.status !== 'running') break;
        await new Promise((r) => setTimeout(r, 500));
      }
      assert.equal(row.status, 'success', row.error);
      assert.equal(row.verify_status, 'passed');
      const dl = await request(app).get(`/api/v1/backups/${row.id}/download`).set(authHeader(devToken)).buffer(true).parse((res, cb) => { const c = []; res.on('data', (d) => c.push(d)); res.on('end', () => cb(null, Buffer.concat(c))); });
      assert.equal(dl.status, 200);
      assert.ok(zlib.gunzipSync(dl.body).toString('utf8').startsWith('-- EduTrack full database backup'));
      assert.equal((await request(app).delete(`/api/v1/backups/${row.id}`).set(authHeader(devToken))).status, 200);
      assert.equal((await request(app).get(`/api/v1/backups/${row.id}/download`).set(authHeader(devToken))).status, 404);
    });
    test('the cron endpoint needs its secret token', async () => {
      process.env.BACKUP_CRON_TOKEN = 'a-long-enough-secret-token';
      assert.equal((await request(app).post('/api/v1/webhooks/backup-cron')).status, 401);
      assert.equal((await request(app).post('/api/v1/webhooks/backup-cron').set('x-backup-token', 'wrong-wrong-wrong-wrong')).status, 401);
      const ok = await request(app).post('/api/v1/webhooks/backup-cron').set('x-backup-token', 'a-long-enough-secret-token');
      assert.equal(ok.status, 200);
      delete process.env.BACKUP_CRON_TOKEN;
      assert.equal((await request(app).post('/api/v1/webhooks/backup-cron').set('x-backup-token', 'a-long-enough-secret-token')).status, 401, 'disabled when no token is configured');
    });
  });

  describe('Google Drive link', () => {
    const stubGoogle = (log = []) => {
      globalThis.fetch = async (url, init = {}) => {
        const u = String(url); log.push({ url: u, init });
        const json = (body, status = 200, headers = {}) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', ...headers } });
        if (u.startsWith('https://oauth2.googleapis.com/token')) {
          const p = new URLSearchParams(String(init.body));
          if (p.get('grant_type') === 'authorization_code') return json({ access_token: 'AT', refresh_token: 'RT-secret', expires_in: 3600 });
          return json({ access_token: 'AT2', expires_in: 3600 });
        }
        if (u.includes('/oauth2/v3/userinfo')) return json({ email: 'owner@gmail.test' });
        if (u.includes('/drive/v3/files?q=')) return json({ files: [] });
        if (u.endsWith('/drive/v3/files?fields=id') && init.method === 'POST') return json({ id: 'FOLDER1' });
        if (u.includes('/drive/v3/files/FOLDER1')) return json({ id: 'FOLDER1', trashed: false });
        if (u.includes('uploadType=resumable')) return new Response('{}', { status: 200, headers: { location: 'https://upload.example/session1' } });
        if (u === 'https://upload.example/session1') { if (init.body?.destroy) init.body.destroy(); return json({ id: 'FILE1' }); }
        if (u.includes('/drive/v3/files/FILE1') && init.method === 'DELETE') return new Response(null, { status: 204 });
        if (u.includes('oauth2.googleapis.com/revoke')) return json({});
        return json({ error: { message: `unexpected ${u}` } }, 500);
      };
      return log;
    };

    test('credentials are stored encrypted and the secret is never sent back', async () => {
      const save = await request(app).put('/api/v1/backups/drive/credentials').set(authHeader(devToken)).send({ client_id: 'cid.apps.googleusercontent.com', client_secret: 'GOCSPX-supersecret' });
      assert.equal(save.status, 200);
      const [row] = await sequelize.query('SELECT drive_client_secret_enc FROM database_backup_settings', { type: 'SELECT' });
      assert.ok(row.drive_client_secret_enc && !row.drive_client_secret_enc.includes('supersecret'));
      const o = await request(app).get('/api/v1/backups').set(authHeader(devToken));
      assert.equal(o.body.data.drive.has_secret, true);
      assert.ok(!JSON.stringify(o.body).includes('supersecret'));
      assert.match(o.body.data.drive.redirect_uri, /\/api\/v1\/webhooks\/google-drive\/callback$/);
    });

    test('Connect needs credentials first, then builds a Google link carrying a signed state', async () => {
      const no = await request(app).get('/api/v1/backups/drive/auth-url').set(authHeader(devToken));
      assert.equal(no.status, 400);
      await request(app).put('/api/v1/backups/drive/credentials').set(authHeader(devToken)).send({ client_id: 'cid', client_secret: 'sec' });
      const res = await request(app).get('/api/v1/backups/drive/auth-url').set(authHeader(devToken));
      const url = new URL(res.body.data.url);
      assert.equal(url.origin + url.pathname, 'https://accounts.google.com/o/oauth2/v2/auth');
      assert.equal(url.searchParams.get('access_type'), 'offline');
      assert.equal(url.searchParams.get('scope').includes('drive.file'), true);
      assert.equal(url.searchParams.get('scope').includes('auth/drive '), false, 'never the full-Drive scope');
      assert.equal(readState(url.searchParams.get('state')).uid, dev.id);
      assert.equal(readState(`${url.searchParams.get('state')}x`), null, 'a tampered state is rejected');
    });

    test('the callback rejects a made-up state, and connects with a valid one', async () => {
      await request(app).put('/api/v1/backups/drive/credentials').set(authHeader(devToken)).send({ client_id: 'cid', client_secret: 'sec' });
      const bad = await request(app).get('/api/v1/webhooks/google-drive/callback?code=abc&state=forged');
      assert.equal(bad.status, 302);
      assert.match(bad.headers.location, /drive=error/);
      stubGoogle();
      const auth = await request(app).get('/api/v1/backups/drive/auth-url').set(authHeader(devToken));
      const state = new URL(auth.body.data.url).searchParams.get('state');
      const ok = await request(app).get(`/api/v1/webhooks/google-drive/callback?code=good&state=${encodeURIComponent(state)}`);
      assert.match(ok.headers.location, /drive=connected/);
      const o = await request(app).get('/api/v1/backups').set(authHeader(devToken));
      assert.equal(o.body.data.drive.connected, true);
      assert.equal(o.body.data.drive.account_email, 'owner@gmail.test');
      const [row] = await sequelize.query('SELECT drive_refresh_token_enc FROM database_backup_settings', { type: 'SELECT' });
      assert.ok(!row.drive_refresh_token_enc.includes('RT-secret'), 'the refresh token is stored encrypted');
    });

    test('once connected, a backup is copied to Drive after it passes its restore test, and old ones are removed from Drive too', async () => {
      await request(app).put('/api/v1/backups/drive/credentials').set(authHeader(devToken)).send({ client_id: 'cid', client_secret: 'sec' });
      const log = stubGoogle();
      const auth = await request(app).get('/api/v1/backups/drive/auth-url').set(authHeader(devToken));
      await request(app).get(`/api/v1/webhooks/google-drive/callback?code=good&state=${encodeURIComponent(new URL(auth.body.data.url).searchParams.get('state'))}`);
      const row = await svc.runBackup({ trigger: 'manual' });
      assert.equal(row.status, 'success', row.error);
      assert.equal(row.drive_status, 'uploaded', row.drive_error);
      assert.equal(row.drive_file_id, 'FILE1');
      const folderCreate = log.find((l) => l.url.endsWith('/drive/v3/files?fields=id') && l.init.method === 'POST');
      assert.match(folderCreate.init.body, /EduTrack Backups/);
      assert.equal(await svc.deleteBackup(row.id), true);
      assert.ok(log.some((l) => l.url.includes('/drive/v3/files/FILE1') && l.init.method === 'DELETE'));
    });

    test('if Google revokes the link, backups still succeed locally and the owner is told to reconnect', async () => {
      const s = await drive.getSettings();
      await request(app).put('/api/v1/backups/drive/credentials').set(authHeader(devToken)).send({ client_id: 'cid', client_secret: 'sec' });
      stubGoogle();
      const auth = await request(app).get('/api/v1/backups/drive/auth-url').set(authHeader(devToken));
      await request(app).get(`/api/v1/webhooks/google-drive/callback?code=good&state=${encodeURIComponent(new URL(auth.body.data.url).searchParams.get('state'))}`);
      globalThis.fetch = async (u) => (String(u).includes('oauth2.googleapis.com/token')
        ? new Response(JSON.stringify({ error: 'invalid_grant' }), { status: 400, headers: { 'content-type': 'application/json' } })
        : new Response('{}', { status: 500 }));
      const row = await svc.runBackup({ trigger: 'manual' });
      assert.equal(row.status, 'success', 'the local backup is still good');
      assert.equal(row.drive_status, 'failed');
      assert.match(row.drive_error, /Connect Google Drive again/);
      await s.reload();
      assert.equal(s.drive_enabled, false);
      assert.match(s.drive_last_error, /no longer accepts/);
    });

    test('disconnect clears the link', async () => {
      const res = await request(app).post('/api/v1/backups/drive/disconnect').set(authHeader(devToken));
      assert.equal(res.status, 200);
      const o = await request(app).get('/api/v1/backups').set(authHeader(devToken));
      assert.equal(o.body.data.drive.connected, false);
    });
  });
});
