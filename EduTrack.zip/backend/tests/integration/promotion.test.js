/**
 * promotion.test.js
 *
 * Promotion reads Class rows by academic_year to find the classes being
 * "closed" and "opened". Before the fix, this was an exact-string match
 * against the global selector's SPAN format — so a Primary/O-Level class
 * (stored as a single year) was invisible to a promotion run entirely.
 * This test drives the real preview → run → revert flow for a mixed
 * school (Primary + O-Level + A-Level) using only the span format, the
 * way the UI's year pickers actually send it.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import { Class, Student, User } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';

describe('Promotion — across mixed Primary/O-Level/A-Level classes', () => {
  let fixture;
  let stdFrom;
  let stdTo;
  let oFrom;
  let oTo;
  let studentInStd;
  let studentInO;

  before(async () => {
    fixture = await buildTenantFixture('promo');
    const { tenant, campus } = fixture;

    // Primary: single-year format both sides.
    stdFrom = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Standard 4', grade: '4',
      education_level: 'primary', academic_year: '2026',
    });
    stdTo = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Standard 5', grade: '5',
      education_level: 'primary', academic_year: '2027',
    });

    // O-Level: also single-year format.
    oFrom = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form 1', grade: '1',
      education_level: 'o_level', academic_year: '2026',
    });
    oTo = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form 2', grade: '2',
      education_level: 'o_level', academic_year: '2027',
    });

    const makeStudent = async (label, classId) => {
      const unique = `${label}-${fixture.tenant.slug}`;
      const user = await User.create({
        tenant_id: tenant.id, email: `${unique}@example.test`, password: 'Password123!',
        first_name: label, last_name: 'Student', role: 'student', status: 'active',
      });
      return Student.create({
        tenant_id: tenant.id, user_id: user.id, campus_id: campus.id,
        admission_number: `ADM-${unique}`, class_id: classId, status: 'active',
      });
    };

    studentInStd = await makeStudent('std4pupil', stdFrom.id);
    studentInO = await makeStudent('form1pupil', oFrom.id);
  });

  after(closeDb);

  test('preview finds BOTH the Primary and O-Level source classes using only the span-format years', async () => {
    const res = await request(app)
      .get('/api/v1/promotions/preview')
      .set(authHeader(fixture.token))
      // The UI's year picker only ever sends the span format, even for
      // schools whose Primary/O-Level classes are stored as a single year.
      .query({ from_academic_year: '2026-2027', to_academic_year: '2027-2028' });

    assert.equal(res.status, 200);
    const classNames = res.body.data.groups.map((g) => g.from_class.name).sort();
    assert.deepEqual(classNames, ['Form 1', 'Standard 4']);
    assert.equal(res.body.data.summary.total, 2);

    // Each group must have correctly found its OWN target class too —
    // this is the second half of the same bug (target classes were
    // looked up with the same broken exact-match).
    const stdGroup = res.body.data.groups.find((g) => g.from_class.name === 'Standard 4');
    const oGroup = res.body.data.groups.find((g) => g.from_class.name === 'Form 1');
    assert.equal(stdGroup.to_class?.name, 'Standard 5');
    assert.equal(oGroup.to_class?.name, 'Form 2');
    assert.equal(stdGroup.issue, null);
    assert.equal(oGroup.issue, null);
  });

  test('running the promotion moves both students into their new classes, and it can be reverted', async () => {
    const decisions = [
      { student_id: studentInStd.id, action: 'promoted', to_class_id: stdTo.id },
      { student_id: studentInO.id, action: 'promoted', to_class_id: oTo.id },
    ];

    const runRes = await request(app)
      .post('/api/v1/promotions/run')
      .set(authHeader(fixture.token))
      .send({ from_academic_year: '2026-2027', to_academic_year: '2027-2028', decisions });

    assert.equal(runRes.status, 201);
    assert.equal(runRes.body.data.promoted, 2);

    const refreshedStd = await Student.findByPk(studentInStd.id);
    const refreshedO = await Student.findByPk(studentInO.id);
    assert.equal(refreshedStd.class_id, stdTo.id);
    assert.equal(refreshedO.class_id, oTo.id);

    // Revert must put both back exactly where they came from.
    const batchId = runRes.body.data.batch_id;
    const revertRes = await request(app)
      .post(`/api/v1/promotions/${batchId}/revert`)
      .set(authHeader(fixture.token));

    assert.equal(revertRes.status, 200);
    const revertedStd = await Student.findByPk(studentInStd.id);
    const revertedO = await Student.findByPk(studentInO.id);
    assert.equal(revertedStd.class_id, stdFrom.id);
    assert.equal(revertedO.class_id, oFrom.id);
  });
});
