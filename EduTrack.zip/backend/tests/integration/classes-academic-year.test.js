/**
 * classes-academic-year.test.js
 *
 * The bug this whole round of fixes was about: filtering /api/v1/classes
 * by academic_year using the global selector's format ("2026-2027") must
 * still find Primary/O-Level classes stored as a single year ("2026").
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import { Class } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';

describe('GET /api/v1/classes — academic year filtering across levels', () => {
  let fixture;

  before(async () => {
    fixture = await buildTenantFixture('classyear');
    const { tenant, campus } = fixture;

    await Class.bulkCreate([
      {
        tenant_id: tenant.id, campus_id: campus.id, name: 'Standard 5', grade: '5',
        education_level: 'primary', academic_year: '2026',
      },
      {
        tenant_id: tenant.id, campus_id: campus.id, name: 'Form 2', grade: '2',
        education_level: 'o_level', academic_year: '2026',
      },
      {
        tenant_id: tenant.id, campus_id: campus.id, name: 'Form 5', grade: '5',
        education_level: 'a_level', academic_year: '2026-2027',
      },
      {
        tenant_id: tenant.id, campus_id: campus.id, name: 'Form 2 (old)', grade: '2',
        education_level: 'o_level', academic_year: '2025',
      },
    ]);
  });

  after(closeDb);

  test('filtering with the SPAN format ("2026-2027") returns Primary, O-Level AND A-Level classes for that year', async () => {
    const res = await request(app)
      .get('/api/v1/classes')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2026-2027', limit: 50 });

    assert.equal(res.status, 200);
    const names = res.body.data.map((c) => c.name).sort();
    assert.deepEqual(names, ['Form 2', 'Form 5', 'Standard 5']);
  });

  test('filtering with the SINGLE-YEAR format ("2026") returns the exact same set', async () => {
    const res = await request(app)
      .get('/api/v1/classes')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2026', limit: 50 });

    assert.equal(res.status, 200);
    const names = res.body.data.map((c) => c.name).sort();
    assert.deepEqual(names, ['Form 2', 'Form 5', 'Standard 5']);
  });

  test('a different year excludes everything from 2026', async () => {
    const res = await request(app)
      .get('/api/v1/classes')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2025', limit: 50 });

    assert.equal(res.status, 200);
    const names = res.body.data.map((c) => c.name);
    assert.deepEqual(names, ['Form 2 (old)']);
  });

  test('no filter returns every class regardless of year', async () => {
    const res = await request(app)
      .get('/api/v1/classes')
      .set(authHeader(fixture.token))
      .query({ limit: 50 });

    assert.equal(res.status, 200);
    assert.equal(res.body.data.length, 4);
  });
});
