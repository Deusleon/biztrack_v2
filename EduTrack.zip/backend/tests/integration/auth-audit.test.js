/**
 * auth-audit.test.js
 *
 * Failed and refused sign-ins must show up in the school's activity history, so
 * an administrator can see someone trying to get in — without ever recording the
 * password that was tried.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'crypto';
import request from 'supertest';
import app from '../../src/server.js';
import { User, AuditLog } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

describe('Sign-in attempts in the activity history', () => {
  let fx; let admin; let other;
  const login = (email, password) => request(app).post('/api/v1/auth/login').send({ email, password });
  const mk = (tenant, extra = {}) => User.create({
    tenant_id: tenant.id, email: `u-${randomUUID().slice(0, 8)}@example.test`, password: 'RightOne#1', first_name: 'Target', last_name: 'Person',
    role: 'teacher', status: 'active', ...extra,
  });
  const rows = async (userId) => { await sleep(150); return AuditLog.findAll({ where: { user_id: userId }, order: [['createdAt', 'ASC']] }); };

  before(async () => { fx = await buildTenantFixture('authaudit'); other = await buildTenantFixture('authaudit-other'); admin = authHeader(fx.token); });
  after(closeDb);

  test('a wrong password is recorded, with how many attempts that makes', async () => {
    const u = await mk(fx.tenant);
    assert.equal((await login(u.email, 'WrongOne#9')).status, 401);
    assert.equal((await login(u.email, 'WrongTwo#9')).status, 401);
    const log = await rows(u.id);
    assert.equal(log.length, 2);
    assert.match(log[0].action, /^Failed sign-in — wrong password \(attempt 1 of \d+\)$/);
    assert.match(log[1].action, /attempt 2 of/);
    assert.equal(log[0].details.outcome, 'failed');
    assert.equal(log[0].details.kind, 'auth');
    assert.ok(log[0].ip_address);
  });

  test('the password that was tried is nowhere in the log', async () => {
    const u = await mk(fx.tenant);
    await login(u.email, 'SecretGuess#77');
    const text = JSON.stringify((await rows(u.id)).map((r) => r.toJSON()));
    assert.ok(!text.includes('SecretGuess#77'));
  });

  test('the attempt that locks the account is recorded, and so is each refusal while it is locked', async () => {
    const u = await mk(fx.tenant);
    let last;
    for (let i = 0; i < 12 && (!last || last.status !== 423); i += 1) last = await login(u.email, 'Nope#12345');
    assert.equal(last.status, 423);
    assert.equal((await login(u.email, 'RightOne#1')).status, 423, 'even the right password is refused while locked');
    const actions = (await rows(u.id)).map((r) => r.action);
    assert.ok(actions.some((a) => /account locked for \d+ min after \d+ wrong passwords/.test(a)), actions.join(' | '));
    assert.ok(actions.some((a) => /^Sign-in refused — account is locked/.test(a)), actions.join(' | '));
  });

  test('a refused deactivated account is recorded', async () => {
    const u = await mk(fx.tenant, { status: 'inactive' });
    assert.equal((await login(u.email, 'RightOne#1')).status, 403);
    assert.ok((await rows(u.id)).some((r) => r.action === 'Sign-in refused — account is not active'));
  });

  test('a wrong current password on the change-password form is recorded too', async () => {
    const u = await mk(fx.tenant);
    const token = (await login(u.email, 'RightOne#1')).body.data.token;
    await request(app).put('/api/v1/auth/change-password').set({ Authorization: `Bearer ${token}` }).send({ current_password: 'NotMine#1', new_password: 'Another#1234' });
    assert.ok((await rows(u.id)).some((r) => r.action === 'Failed password change — wrong current password'));
  });

  test('a successful sign-in is still recorded, as before', async () => {
    const u = await mk(fx.tenant);
    await login(u.email, 'RightOne#1');
    const log = await rows(u.id);
    assert.ok(log.some((r) => r.action === `Signed in (${u.email})` && !r.details.outcome));
  });

  test('an email that does not belong to anyone leaves nothing behind (there is no school to show it to)', async () => {
    const before = await AuditLog.count();
    assert.equal((await login(`nobody-${randomUUID().slice(0, 8)}@example.test`, 'Whatever#1')).status, 401);
    await sleep(150);
    assert.equal(await AuditLog.count(), before);
  });

  test('administrators see them in the Audit Log, marked as failed, under "Sign-ins"', async () => {
    const u = await mk(fx.tenant);
    await login(u.email, 'WrongOne#9');
    await sleep(150);
    const res = await request(app).get('/api/v1/settings/audit-logs?kind=auth&limit=100').set(admin);
    assert.equal(res.status, 200);
    const entry = res.body.data.find((r) => r.user?.id === u.id);
    assert.ok(entry, 'listed under Sign-ins');
    assert.equal(entry.kind, 'auth');
    assert.equal(entry.outcome, 'failed');
    assert.match(entry.action, /Failed sign-in/);
  });

  test('another school cannot see them', async () => {
    const u = await mk(fx.tenant);
    await login(u.email, 'WrongOne#9');
    await sleep(150);
    const res = await request(app).get('/api/v1/settings/audit-logs?kind=auth&limit=100').set(authHeader(other.token));
    assert.ok(!res.body.data.some((r) => r.user?.id === u.id));
  });
});
