/**
 * students-academic-year.test.js
 *
 * The reported bug: switching the academic year on the Students page kept
 * showing the same students in the same grade — the endpoint never even
 * looked at the year. This drives the exact scenarios from the report:
 *
 *  - A student currently in Form II (2026) must show Form I for 2025,
 *    and disappear entirely for 2024 (not yet admitted).
 *  - A student who finished Form IV (O-Level) in 2025 must disappear
 *    from 2026 onward (graduated), but still show as Form III for 2024.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import { Class, Student, User } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';

describe('GET /api/v1/students?academic_year= — historical/projected grade', () => {
  let fixture;

  before(async () => {
    fixture = await buildTenantFixture('studenthist');
    const { tenant, campus } = fixture;

    // This suite exercises the projection logic itself (not the
    // system-start floor, covered separately in
    // students-academic-year-floor.test.js) — so give it a start year
    // early enough that 2024–2026 are all fair game, regardless of when
    // this test tenant actually happened to be created just now.
    await tenant.update({ settings: { academic_records_start_year: 2015 } });

    const form2 = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form II', grade: '2',
      education_level: 'o_level', academic_year: '2026', status: 'active',
    });
    const form4 = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form IV', grade: '4',
      education_level: 'o_level', academic_year: '2025', status: 'active',
    });

    const makeStudent = async (label, classId, admissionDate) => {
      const user = await User.create({
        tenant_id: tenant.id, email: `${label}-${tenant.slug}@example.test`, password: 'Password123!',
        first_name: label, last_name: 'Student', role: 'student', status: 'active',
      });
      return Student.create({
        tenant_id: tenant.id, user_id: user.id, campus_id: campus.id,
        admission_number: `ADM-${label}-${tenant.slug}`, class_id: classId,
        admission_date: admissionDate, status: 'active',
      });
    };

    await makeStudent('FormTwoPupil', form2.id, '2025-01-15');
    await makeStudent('StudentZ', form4.id, '2022-01-15');
  });

  after(closeDb);

  const findByName = (body, firstName) => body.data.find((s) => s.user?.first_name === firstName);

  test('2026 (current year): both students show their current class as-is', async () => {
    const res = await request(app)
      .get('/api/v1/students')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2026-2027', limit: 50 });

    assert.equal(res.status, 200);
    const formTwo = findByName(res.body, 'FormTwoPupil');
    assert.equal(formTwo.class.grade, '2');
    assert.equal(formTwo.historical_view.source, 'current');
    // StudentZ's current class is dated 2025, so 2026 is one year past it —
    // by the projection rule they've already finished Form IV.
    assert.equal(findByName(res.body, 'StudentZ'), undefined);
  });

  test('2025: the Form II pupil shows as Form I (projected), StudentZ shows their real Form IV', async () => {
    const res = await request(app)
      .get('/api/v1/students')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2025-2026', limit: 50 });

    assert.equal(res.status, 200);
    const formTwo = findByName(res.body, 'FormTwoPupil');
    assert.equal(formTwo.class.grade, '1');
    assert.equal(formTwo.historical_view.source, 'projected');

    const studentZ = findByName(res.body, 'StudentZ');
    assert.equal(studentZ.class.grade, '4');
    assert.equal(studentZ.historical_view.source, 'current');
  });

  test('2024: the Form II pupil is gone entirely (not yet admitted); StudentZ shows Form III', async () => {
    const res = await request(app)
      .get('/api/v1/students')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2024-2025', limit: 50 });

    assert.equal(res.status, 200);
    assert.equal(findByName(res.body, 'FormTwoPupil'), undefined);

    const studentZ = findByName(res.body, 'StudentZ');
    assert.equal(studentZ.class.grade, '3');
    assert.equal(studentZ.historical_view.source, 'projected');
  });

  test('no academic_year param: unchanged, original behaviour (both show current class)', async () => {
    const res = await request(app)
      .get('/api/v1/students')
      .set(authHeader(fixture.token))
      .query({ limit: 50 });

    assert.equal(res.status, 200);
    assert.ok(findByName(res.body, 'FormTwoPupil'));
    assert.ok(findByName(res.body, 'StudentZ'));
    assert.equal(findByName(res.body, 'FormTwoPupil').historical_view, undefined);
  });
});
