/**
 * fees.test.js
 *
 * Two spots that used to break for Primary/O-Level:
 *  1. GET /api/v1/fees/structures?academic_year= — listing fee structures
 *     for a given year.
 *  2. GET /api/v1/reports/fee-collection?academic_year= — the report the
 *     school actually uses to see expected vs collected fees, which
 *     starts from EVERY active class and filters ITS fee structures by
 *     year (this was the one report Reports.jsx didn't even expose a
 *     year picker for at all — also fixed as part of this round).
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import { Class, FeeStructure } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';

describe('Fees — academic year filtering across levels', () => {
  let fixture;
  let primaryClass;
  let aLevelClass;

  before(async () => {
    fixture = await buildTenantFixture('fees');
    const { tenant, campus } = fixture;

    primaryClass = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Standard 3', grade: '3',
      education_level: 'primary', academic_year: '2026',
    });
    aLevelClass = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form 6', grade: '6',
      education_level: 'a_level', academic_year: '2026-2027',
    });

    await FeeStructure.bulkCreate([
      {
        tenant_id: tenant.id, campus_id: campus.id, class_id: primaryClass.id,
        name: 'Tuition', amount: 100000, academic_year: '2026', status: 'active',
      },
      {
        tenant_id: tenant.id, campus_id: campus.id, class_id: aLevelClass.id,
        name: 'Tuition', amount: 250000, academic_year: '2026-2027', status: 'active',
      },
    ]);
  });

  after(closeDb);

  test('GET /fees/structures?academic_year=2026-2027 (span) finds the Primary structure too', async () => {
    const res = await request(app)
      .get('/api/v1/fees/structures')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2026-2027', limit: 50 });

    assert.equal(res.status, 200);
    const names = res.body.data.map((s) => `${s.name}:${s.amount}`).sort();
    assert.deepEqual(names, ['Tuition:100000.00', 'Tuition:250000.00']);
  });

  test('GET /reports/fee-collection?academic_year=2026-2027 includes BOTH classes\' expected totals', async () => {
    const res = await request(app)
      .get('/api/v1/reports/fee-collection')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2026-2027' });

    assert.equal(res.status, 200);
    const rowByClass = Object.fromEntries(res.body.data.rows.map((r) => [r.class_name, r]));
    assert.ok(rowByClass['Standard 3'], 'Primary class row missing from the report');
    assert.ok(rowByClass['Form 6'], 'A-Level class row missing from the report');
  });

  test('GET /fees/structures?academic_year=2025-2026 returns nothing — neither class has fees for that year', async () => {
    const res = await request(app)
      .get('/api/v1/fees/structures')
      .set(authHeader(fixture.token))
      .query({ academic_year: '2025-2026', limit: 50 });

    assert.equal(res.status, 200);
    assert.equal(res.body.data.length, 0);
  });
});
