/**
 * clone-year.test.js
 *
 * POST /api/v1/classes/clone-year — a school's grade structure repeats
 * every year, so instead of forcing the admin to hand-create next year's
 * classes before Promotion will work, they can be cloned automatically
 * from this year's. Covers: cloning across mixed Primary/O-Level formats,
 * sections coming along for the ride, and re-running being a no-op for
 * classes that already exist (idempotency — the UI calls this blindly
 * whenever "Create missing classes" is clicked, possibly more than once).
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import { Class, Section } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';

describe('POST /api/v1/classes/clone-year', () => {
  let fixture;
  let form1;
  let form2Existing;

  before(async () => {
    fixture = await buildTenantFixture('cloneyear');
    const { tenant, campus } = fixture;

    form1 = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form I', grade: '1',
      education_level: 'o_level', academic_year: '2026', status: 'active',
    });
    await Section.create({ tenant_id: tenant.id, class_id: form1.id, name: 'A', capacity: 40, status: 'active' });
    await Section.create({ tenant_id: tenant.id, class_id: form1.id, name: 'B', capacity: 40, status: 'active' });

    // Form II already exists for next year — must be left untouched, not duplicated.
    form2Existing = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form II', grade: '2',
      education_level: 'o_level', academic_year: '2027', status: 'active',
    });
  });

  after(closeDb);

  test('clones Form I into next year, resolved to the single-year format for O-Level, with its sections', async () => {
    const res = await request(app)
      .post('/api/v1/classes/clone-year')
      .set(authHeader(fixture.token))
      .send({ from_academic_year: '2026-2027', to_academic_year: '2027-2028' });

    assert.equal(res.status, 201);
    assert.equal(res.body.data.created.length, 1);
    assert.equal(res.body.data.created[0].name, 'Form I');
    assert.equal(res.body.data.created[0].academic_year, '2027'); // resolved DOWN, not left as a span
    // Form II isn't a SOURCE class for 2026 at all (it only exists for
    // 2027 already) — so it's simply not touched, not reported as "skipped".
    assert.equal(res.body.data.skipped.length, 0);

    const clonedForm1 = await Class.findOne({ where: { tenant_id: fixture.tenant.id, name: 'Form I', academic_year: '2027' } });
    assert.ok(clonedForm1, 'cloned Form I not found for 2027');

    const sections = await Section.findAll({ where: { class_id: clonedForm1.id } });
    assert.deepEqual(sections.map((s) => s.name).sort(), ['A', 'B']);

    // Original Form II for 2027 must be untouched — no duplicate created.
    const form2Count = await Class.count({ where: { tenant_id: fixture.tenant.id, name: 'Form II', academic_year: '2027' } });
    assert.equal(form2Count, 1);
  });

  test('running it again creates nothing new — fully idempotent', async () => {
    const res = await request(app)
      .post('/api/v1/classes/clone-year')
      .set(authHeader(fixture.token))
      .send({ from_academic_year: '2026-2027', to_academic_year: '2027-2028' });

    assert.equal(res.status, 201);
    assert.equal(res.body.data.created.length, 0);
    // Only Form I is a source class for 2026; it now already exists for
    // 2027 from the previous run, so it's the one skipped.
    assert.equal(res.body.data.skipped.length, 1);
    assert.equal(res.body.data.skipped[0].name, 'Form I');

    const totalClasses = await Class.count({ where: { tenant_id: fixture.tenant.id } });
    assert.equal(totalClasses, 3); // Form I 2026, Form I 2027, Form II 2027 — no duplicates
  });
});
