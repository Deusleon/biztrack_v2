/**
 * forgot-password.test.js
 *
 * A person who has forgotten their password resets it themself with a 6-digit
 * code sent to their EMAIL. The code must be single-use, short-lived,
 * guess-limited, and the form must never reveal which accounts exist.
 */
import { test, describe, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'crypto';
import request from 'supertest';
import app from '../../src/server.js';
import { User, Student, PasswordReset, AuditLog, NotificationSetting } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';
import { setDeliveryForTests, MAX_ATTEMPTS } from '../../src/services/passwordResetService.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

describe('Forgot password', () => {
  let fx; let sent;
  const phone = () => `07${Math.floor(10000000 + Math.random() * 89999999)}`;
  const mkUser = (extra = {}) => User.create({
    tenant_id: fx.tenant.id, email: `u-${randomUUID().slice(0, 8)}@example.test`, password: 'OldPassword#1',
    first_name: 'Forgetful', last_name: 'Person', role: 'teacher', status: 'active', phone: phone(), ...extra,
  });
  const forgot = (identifier) => request(app).post('/api/v1/auth/forgot-password').send({ identifier });
  const reset = (identifier, code, new_password = 'BrandNew#2026') => request(app).post('/api/v1/auth/reset-password').send({ identifier, code, new_password });
  const login = (email, password) => request(app).post('/api/v1/auth/login').send({ email, password });
  /** The code is sent after the answer, so wait for it to be "delivered". */
  const codeFor = async (identifier, afterCount = sent.length) => {
    await forgot(identifier);
    for (let i = 0; i < 60 && sent.length === afterCount; i += 1) await sleep(25);
    return sent[sent.length - 1];
  };

  before(async () => { fx = await buildTenantFixture('forgot'); });
  after(() => { setDeliveryForTests(); return closeDb(); });
  /** Where this school sends codes: ['email'] (the default), ['sms'] or both. */
  const setChannels = async (channels) => {
    await NotificationSetting.destroy({ where: { tenant_id: fx.tenant.id, event_key: 'password_reset' } });
    if (channels) await NotificationSetting.create({ tenant_id: fx.tenant.id, event_key: 'password_reset', enabled: true, channels });
  };
  beforeEach(async () => {
    await setChannels(null);
    sent = [];
    setDeliveryForTests(async ({ user, destinations, code }) => { sent.push({ userId: user.id, destinations, code }); return ['sms']; });
  });

  test('a code arrives and resets the password; the old password stops working', async () => {
    const user = await mkUser();
    const got = await codeFor(user.email);
    assert.match(got.code, /^\d{6}$/);
    assert.equal(got.userId, user.id);

    const res = await reset(user.email, got.code);
    assert.equal(res.status, 200);
    assert.equal((await login(user.email, 'OldPassword#1')).status, 401);
    assert.equal((await login(user.email, 'BrandNew#2026')).status, 200);
  });

  test('by default codes go by EMAIL only — and only an email address is accepted', async () => {
    const local = phone();
    const user = await mkUser({ phone: local });
    const byPhone = await codeFor(local);
    assert.equal(byPhone, undefined, 'a phone number is not accepted when the school uses email');
    const got = await codeFor(user.email);
    assert.equal(got.destinations.email, user.email);
    assert.equal(got.destinations.phone, null, 'no SMS');
  });

  test('SMS-only schools: only a phone number is accepted, any common format, and the code goes by SMS', async () => {
    await setChannels(['sms']);
    const local = phone();
    const user = await mkUser({ phone: local });
    assert.equal(await codeFor(user.email), undefined, 'an email address is not accepted');
    for (const typed of [`+255 ${local.slice(1, 4)} ${local.slice(4, 7)} ${local.slice(7)}`, local, `255${local.slice(1)}`]) {
      const got = await codeFor(typed);
      assert.equal(got.userId, user.id, typed);
      assert.equal(got.destinations.phone, `255${local.slice(1)}`);
      assert.equal(got.destinations.email, null, 'no email');
      await PasswordReset.destroy({ where: { user_id: user.id } }); // lift the one-a-minute throttle between tries
    }
    const { code } = await codeFor(local);
    assert.equal((await reset(local, code)).status, 200);
    assert.equal((await reset(user.email, code, 'Another#2026')).status, 400, 'and the email is not accepted when resetting either');
  });

  test('"either" schools: email or phone is accepted, and the code goes to every place the account has', async () => {
    await setChannels(['email', 'sms']);
    const local = phone();
    const user = await mkUser({ phone: local });
    const byEmail = await codeFor(user.email);
    assert.deepEqual([byEmail.destinations.email, byEmail.destinations.phone], [user.email, `255${local.slice(1)}`]);
    await PasswordReset.destroy({ where: { user_id: user.id } });
    const byPhone = await codeFor(local);
    assert.equal(byPhone.userId, user.id);
    assert.equal(byPhone.destinations.email, user.email);
  });

  test('"either" with an account that only has one of them still sends to that one', async () => {
    await setChannels(['email', 'sms']);
    const noPhone = await mkUser({ phone: null });
    const got = await codeFor(noPhone.email);
    assert.deepEqual([got.destinations.email, got.destinations.phone], [noPhone.email, null]);
  });

  test('a school\'s own choice is applied even when the form accepts both', async () => {
    const user = await mkUser({ phone: phone() });
    await setChannels(['sms']);
    assert.equal(await codeFor(user.email), undefined);
    await setChannels(null);
    assert.ok(await codeFor(user.email));
  });

  test('a code works only once', async () => {
    const user = await mkUser();
    const { code } = await codeFor(user.email);
    assert.equal((await reset(user.email, code, 'FirstReset#1')).status, 200);
    const again = await reset(user.email, code, 'SecondReset#2');
    assert.equal(again.status, 400);
    assert.equal((await login(user.email, 'FirstReset#1')).status, 200, 'the first reset stands');
  });

  test('a wrong code is refused, and five wrong guesses kill even the right code', async () => {
    const user = await mkUser();
    const { code } = await codeFor(user.email);
    const wrong = code === '000000' ? '000001' : '000000';
    for (let i = 0; i < MAX_ATTEMPTS; i += 1) assert.equal((await reset(user.email, wrong)).status, 400);
    const late = await reset(user.email, code);
    assert.equal(late.status, 400, 'too many wrong guesses — the real code no longer works');
    assert.equal((await login(user.email, 'OldPassword#1')).status, 200, 'the password was never changed');
  });

  test('a code expires after 15 minutes', async () => {
    const user = await mkUser();
    const { code } = await codeFor(user.email);
    await PasswordReset.update({ expires_at: new Date(Date.now() - 1000) }, { where: { user_id: user.id } });
    assert.equal((await reset(user.email, code)).status, 400);
  });

  test('asking again replaces the earlier code', async () => {
    const user = await mkUser();
    const first = await codeFor(user.email);
    await PasswordReset.update({ createdAt: new Date(Date.now() - 5 * 60 * 1000) }, { where: { user_id: user.id }, silent: true });
    const second = await codeFor(user.email);
    assert.notEqual(second.code, first.code);
    assert.equal((await reset(user.email, first.code)).status, 400, 'the older code is void');
    assert.equal((await reset(user.email, second.code)).status, 200);
  });

  test('the code is never stored — only a hash of it', async () => {
    const user = await mkUser();
    const { code } = await codeFor(user.email);
    const row = await PasswordReset.findOne({ where: { user_id: user.id } });
    assert.ok(!row.code_hash.includes(code));
    assert.match(row.code_hash, /^[0-9a-f]{64}$/);
  });

  test('the answer is identical whether or not the account exists', async () => {
    const user = await mkUser();
    const known = await forgot(user.email);
    const unknown = await forgot(`nobody-${randomUUID().slice(0, 8)}@example.test`);
    const unreachable = await forgot('0799000000');
    for (const r of [known, unknown, unreachable]) assert.equal(r.status, 200);
    assert.deepEqual(unknown.body, known.body);
    assert.deepEqual(unreachable.body, known.body);
    const badCode = await reset(`nobody-${randomUUID().slice(0, 8)}@example.test`, '123456');
    const wrongForReal = await reset(user.email, '123456');
    assert.deepEqual(badCode.body, wrongForReal.body, 'a wrong code reveals nothing either');
  });

  test('requests are throttled per account (one a minute)', async () => {
    const user = await mkUser();
    await codeFor(user.email);
    const before = sent.length;
    await forgot(user.email);
    await sleep(150);
    assert.equal(sent.length, before, 'a second request straight away sends nothing');
  });

  test('a locked-out account can reset, which also lifts the lock', async () => {
    const user = await mkUser();
    await user.update({ locked_until: new Date(Date.now() + 10 * 60000), failed_login_attempts: 3 });
    assert.equal((await login(user.email, 'OldPassword#1')).status, 423);
    const { code } = await codeFor(user.email);
    assert.equal((await reset(user.email, code)).status, 200);
    assert.equal((await login(user.email, 'BrandNew#2026')).status, 200);
  });

  test('a reset signs out every earlier session', async () => {
    const user = await mkUser();
    const token = (await login(user.email, 'OldPassword#1')).body.data.token;
    assert.equal((await request(app).get('/api/v1/classes').set({ Authorization: `Bearer ${token}` })).status, 200);
    const { code } = await codeFor(user.email);
    await reset(user.email, code);
    assert.equal((await request(app).get('/api/v1/classes').set({ Authorization: `Bearer ${token}` })).status, 401);
  });

  test('the new password has to be acceptable — and a refused one does not use up the code', async () => {
    const user = await mkUser();
    const { code } = await codeFor(user.email);
    assert.equal((await reset(user.email, code, 'abc')).status, 400);
    assert.equal((await reset(user.email, code, 'abcdefghij')).status, 400, 'letters only');
    assert.equal((await reset(user.email, code, '1234567890')).status, 400, 'numbers only');
    assert.equal((await reset(user.email, code, 'Ab1')).status, 400, 'too short');
    assert.equal((await reset(user.email, code, 'Staff@2026')).status, 400, 'not the standard starting password');
    assert.equal((await reset(user.email, code, 'GoodOne#2026')).status, 200, 'the same code still works');
  });

  test('someone who had to change their starting password is not asked again after resetting', async () => {
    const user = await mkUser({ must_change_password: true });
    const { code } = await codeFor(user.email);
    await reset(user.email, code);
    assert.equal((await login(user.email, 'BrandNew#2026')).body.data.must_change_password, false);
  });

  test('a student (who only has a made-up address) gets the code on their parent\'s email', async () => {
    const parent = await mkUser({ role: 'parent' });
    const studentUser = await mkUser({ role: 'student', phone: null, email: `kid-${randomUUID().slice(0, 6)}@school.local` });
    await Student.create({
      tenant_id: fx.tenant.id, user_id: studentUser.id, campus_id: fx.campus.id, admission_number: `ADM-${randomUUID().slice(0, 8)}`,
      parent_id: parent.id, admission_date: '2026-01-10', status: 'active',
    });
    const got = await codeFor(studentUser.email);
    assert.equal(got.userId, studentUser.id);
    assert.equal(got.destinations.email, parent.email);
    assert.notEqual(got.destinations.email, studentUser.email, 'a made-up school address is not somewhere mail can go');
  });

  test('with email AND SMS a student\'s code goes to their parent\'s email and phone', async () => {
    await setChannels(['email', 'sms']);
    const parent = await mkUser({ role: 'parent', phone: '0755111222' });
    const studentUser = await mkUser({ role: 'student', phone: null, email: `kid-${randomUUID().slice(0, 6)}@school.local` });
    await Student.create({
      tenant_id: fx.tenant.id, user_id: studentUser.id, campus_id: fx.campus.id, admission_number: `ADM-${randomUUID().slice(0, 8)}`,
      parent_id: parent.id, admission_date: '2026-01-10', status: 'active',
    });
    const got = await codeFor(studentUser.email);
    assert.equal(got.userId, studentUser.id);
    assert.deepEqual([got.destinations.email, got.destinations.phone], [parent.email, '255755111222']);
  });

  test('in SMS-only mode a student with no phone of their own cannot reset by themself (their only login name is a made-up address)', async () => {
    await setChannels(['sms']);
    const parent = await mkUser({ role: 'parent', phone: '0755111333' });
    const studentUser = await mkUser({ role: 'student', phone: null, email: `kid-${randomUUID().slice(0, 6)}@school.local` });
    await Student.create({
      tenant_id: fx.tenant.id, user_id: studentUser.id, campus_id: fx.campus.id, admission_number: `ADM-${randomUUID().slice(0, 8)}`,
      parent_id: parent.id, admission_date: '2026-01-10', status: 'active',
    });
    assert.equal(await codeFor(studentUser.email), undefined);
  });

  test('an account nobody can reach, and a deactivated one, get nothing', async () => {
    const unreachable = await mkUser({ phone: null, email: `x-${randomUUID().slice(0, 6)}@school.local` });
    const off = await mkUser({ status: 'inactive' });
    await forgot(unreachable.email); await forgot(off.email);
    await sleep(150);
    assert.equal(sent.length, 0);
  });

  test('a phone number shared by two accounts is not guessed at', async () => {
    const shared = phone();
    await mkUser({ phone: shared }); await mkUser({ phone: shared });
    await forgot(shared);
    await sleep(150);
    assert.equal(sent.length, 0);
  });

  test('a reset is recorded for that school, and the code is nowhere in the log', async () => {
    const user = await mkUser();
    const { code } = await codeFor(user.email);
    await reset(user.email, code);
    await sleep(300);
    const rows = await AuditLog.findAll({ where: { tenant_id: fx.tenant.id, user_id: user.id } });
    assert.ok(rows.some((r) => /Reset password/i.test(r.action)), rows.map((r) => r.action).join(' | '));
    assert.ok(!JSON.stringify(rows.map((r) => r.toJSON())).includes(code));
    assert.ok(!JSON.stringify(rows.map((r) => r.toJSON())).includes('BrandNew#2026'));
    const asked = await AuditLog.count({ where: { action: 'Asked for a password reset code' } });
    assert.equal(asked, 0, 'the public "forgot" request is not logged');
  });

  test('administrators choose where codes go in Settings → Notifications; it cannot be switched off or left empty', async () => {
    const admin = authHeader(fx.token);
    const put = (body) => request(app).put('/api/v1/notifications/settings/events').set(admin).send({ event_key: 'password_reset', ...body });
    const read = async () => (await request(app).get('/api/v1/notifications/settings/events').set(admin)).body.data.find((e) => e.event_key === 'password_reset');

    const standard = await read();
    assert.deepEqual([standard.channels, standard.enabled], [['email'], true], 'email by default');

    assert.equal((await put({ channels: ['sms'] })).status, 200);
    assert.deepEqual((await read()).channels, ['sms']);
    assert.equal((await put({ channels: ['email', 'sms'] })).status, 200);
    assert.deepEqual((await read()).channels.sort(), ['email', 'sms']);

    assert.equal((await put({ channels: [] })).status, 400, 'at least one');
    assert.equal((await put({ channels: ['in_app'] })).status, 400, 'in-app means nothing here');
    assert.equal((await put({ enabled: false })).status, 200);
    assert.equal((await read()).enabled, true, 'switching it off is ignored — people would be unable to recover their account');
  });

  test('the form asks for what the school allows', async () => {
    await NotificationSetting.destroy({ where: { event_key: 'password_reset' } }); // every school on this test server: standard
    const mode = async () => (await request(app).get('/api/v1/auth/forgot-password/options')).body.data.mode;
    assert.equal(await mode(), 'email');
    await setChannels(['sms']);
    assert.equal(await mode(), 'either', 'schools disagree, so the form accepts both and each school\'s rule is applied afterwards');
    await setChannels(null);
    assert.equal(await mode(), 'email');
  });

  test('the two endpoints are public — signing in is not needed', async () => {
    assert.equal((await forgot('someone@example.test')).status, 200);
    assert.equal((await reset('someone@example.test', '123456')).status, 400);
    assert.equal((await request(app).post('/api/v1/auth/forgot-password').send({})).status, 400);
  });
});
