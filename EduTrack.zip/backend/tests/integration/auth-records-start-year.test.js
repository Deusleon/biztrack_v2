/**
 * auth-records-start-year.test.js
 *
 * The frontend year-picker needs `academic_records_start_year` on the
 * user object to know how far back it's allowed to offer — this checks
 * it's present (and correct) right after login, not only after a later
 * getMe() refresh, since AuthContext sets the user straight from the
 * login response and may not call getMe() again for a while.
 */
import { test, describe, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import { buildTenantFixture, closeDb } from '../helpers/testFixture.js';

describe('academic_records_start_year — surfaced on login and getMe', () => {
  after(closeDb);

  test('login response includes the tenant\'s signup year by default', async () => {
    const fixture = await buildTenantFixture('authyear');
    const currentCalendarYear = new Date().getFullYear();

    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: fixture.admin.email, password: 'Password123!' });

    assert.equal(res.status, 200);
    assert.equal(res.body.data.academic_records_start_year, currentCalendarYear);
  });

  test('an explicit tenant override is reflected on both login and /auth/me', async () => {
    const fixture = await buildTenantFixture('authyearoverride');
    await fixture.tenant.update({ settings: { academic_records_start_year: 2020 } });

    const loginRes = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: fixture.admin.email, password: 'Password123!' });
    assert.equal(loginRes.body.data.academic_records_start_year, 2020);

    const meRes = await request(app)
      .get('/api/v1/auth/me')
      .set('Authorization', `Bearer ${fixture.token}`);
    assert.equal(meRes.body.data.academic_records_start_year, 2020);
  });
});
