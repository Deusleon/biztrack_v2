/**
 * audit-log.test.js
 *
 * The Activity History must say WHAT happened — "Updated class "Form 1A"",
 * with the exact before → after values — not "PUT /5d3a…", and must never
 * store a password. Runs the real app against the real database.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'crypto';
import request from 'supertest';
import app from '../../src/server.js';
import { AuditLog, User } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** The audit row is written just after the response goes out. */
const waitForAudit = async (tenantId, atLeast) => {
  for (let i = 0; i < 60; i += 1) {
    if (await AuditLog.count({ where: { tenant_id: tenantId } }) >= atLeast) return;
    await sleep(50);
  }
};

describe('Audit log — readable activity with before/after values', () => {
  let fixture; let other; let h; let classId;
  const list = (query = '') => request(app).get(`/api/v1/settings/audit-logs?limit=100${query}`).set(h);

  before(async () => {
    fixture = await buildTenantFixture('audit');
    other = await buildTenantFixture('audit-other');
    h = authHeader(fixture.token);
  });
  after(closeDb);

  test('creating a record is logged in plain words, with what was created', async () => {
    const res = await request(app).post('/api/v1/classes').set(h)
      .send({ campus_id: fixture.campus.id, name: 'Form 1', grade: '1', education_level: 'o_level', academic_year: '2026', capacity: 40 });
    assert.equal(res.status, 201);
    classId = res.body.data.id;
    await waitForAudit(fixture.tenant.id, 1);

    const row = await AuditLog.findOne({ where: { tenant_id: fixture.tenant.id }, order: [['createdAt', 'ASC']] });
    assert.equal(row.action, 'Created class "Form 1"');
    assert.equal(row.resource_id, classId);
    assert.equal(row.details.kind, 'create');
    assert.equal(row.details.changes[0].data.capacity, 40);
    assert.ok(!('tenant_id' in row.details.changes[0].data), 'internal ids are noise, not shown');
  });

  test('updating a record keeps the exact before → after for each changed field', async () => {
    const res = await request(app).put(`/api/v1/classes/${classId}`).set(h).send({ name: 'Form 1A', capacity: 45 });
    assert.equal(res.status, 200);
    await waitForAudit(fixture.tenant.id, 2);

    const row = await AuditLog.findOne({ where: { tenant_id: fixture.tenant.id, action: 'Updated class "Form 1A"' } });
    assert.ok(row, 'titled by what it did, using the NEW name');
    assert.equal(row.details.kind, 'update');
    assert.deepEqual(row.details.changed_fields.sort(), ['capacity', 'name']);
    const byField = Object.fromEntries(row.details.changes[0].fields.map((f) => [f.field, f]));
    assert.deepEqual([byField.name.before, byField.name.after], ['Form 1', 'Form 1A']);
    assert.deepEqual([byField.capacity.before, byField.capacity.after], [40, 45]);
  });

  test('deactivating and permanently deleting are told apart', async () => {
    await request(app).delete(`/api/v1/classes/${classId}`).set(h);
    // Deleting for good follows the delete permission, which an admin always holds.
    assert.equal((await request(app).delete(`/api/v1/classes/${classId}/permanent`).set(h)).status, 200);
    await waitForAudit(fixture.tenant.id, 4);

    const actions = (await AuditLog.findAll({ where: { tenant_id: fixture.tenant.id }, order: [['createdAt', 'ASC']] })).map((r) => r.action);
    assert.deepEqual(actions, ['Created class "Form 1"', 'Updated class "Form 1A"', 'Deactivated class "Form 1A"', 'Deleted class "Form 1A"']);

    const deleted = await AuditLog.findOne({ where: { tenant_id: fixture.tenant.id, action: 'Deleted class "Form 1A"' } });
    assert.equal(deleted.details.changes[0].data.capacity, 45, 'a delete keeps what the record looked like');
  });

  test('a bulk update says how many rows and what was set', async () => {
    const created = await request(app).post('/api/v1/classes').set(h)
      .send({ campus_id: fixture.campus.id, name: 'Form 2', grade: '2', education_level: 'o_level', academic_year: '2026' });
    const id = created.body.data.id;
    const res = await request(app).patch('/api/v1/classes/bulk/status').set(h).send({ ids: [id], status: 'inactive' });
    assert.equal(res.status, 200);
    await waitForAudit(fixture.tenant.id, 6);

    const row = await AuditLog.findOne({ where: { tenant_id: fixture.tenant.id, action: 'Updated 1 class record (status → inactive)' } });
    assert.ok(row);
    assert.equal(row.details.changes[0].op, 'bulk_update');
  });

  test('signing in is "Signed in" — and the password is never stored', async () => {
    const res = await request(app).post('/api/v1/auth/login').send({ email: fixture.admin.email, password: 'Password123!' });
    assert.equal(res.status, 200);
    await waitForAudit(fixture.tenant.id, 7);

    const row = await AuditLog.findOne({ where: { tenant_id: fixture.tenant.id, action: `Signed in (${fixture.admin.email})` } });
    assert.ok(row, 'attributed to the school even though the request had no token');
    assert.equal(row.user_id, fixture.admin.id);
    assert.equal(row.details.kind, 'auth');
    assert.ok(!JSON.stringify(row.toJSON()).includes('Password123!'), 'password must not appear anywhere in the row');
  });

  test('requests that fail or only read leave nothing behind', async () => {
    const before = await AuditLog.count({ where: { tenant_id: fixture.tenant.id } });
    await request(app).put(`/api/v1/classes/${randomUUID()}`).set(h).send({ name: 'x' }); // 404
    await request(app).get('/api/v1/classes').set(h);
    await sleep(300);
    assert.equal(await AuditLog.count({ where: { tenant_id: fixture.tenant.id } }), before);
  });

  test('the list is light: a title, the kind, and which fields changed — no raw details', async () => {
    const res = await list();
    assert.equal(res.status, 200);
    const updated = res.body.data.find((r) => r.action === 'Updated class "Form 1A"');
    assert.ok(updated);
    assert.equal(updated.kind, 'update');
    assert.deepEqual(updated.changed_fields.sort(), ['capacity', 'name']);
    assert.equal(updated.details, undefined);
    assert.ok(res.body.data.every((r) => !/^(POST|PUT|PATCH|DELETE) \//.test(r.action)), 'no route/method as the action');
  });

  test('the detail returns the full before → after, and names instead of ids', async () => {
    const createdRow = (await list()).body.data.find((r) => r.action === 'Created class "Form 1"');
    const res = await request(app).get(`/api/v1/settings/audit-logs/${createdRow.id}`).set(h);
    assert.equal(res.status, 200);
    assert.equal(res.body.data.details.changes[0].data.name, 'Form 1');
    assert.equal(res.body.data.lookups[fixture.campus.id], 'Main Campus', 'campus id resolved to its name');
    assert.equal(res.body.data.user.email, fixture.admin.email);

    const updRow = (await list()).body.data.find((r) => r.action === 'Updated class "Form 1A"');
    const upd = await request(app).get(`/api/v1/settings/audit-logs/${updRow.id}`).set(h);
    assert.deepEqual(upd.body.data.details.changes[0].fields.map((f) => f.field).sort(), ['capacity', 'name']);
  });

  test('filtering by kind', async () => {
    const titles = async (kind) => (await list(`&kind=${kind}`)).body.data.map((r) => r.action);
    assert.ok((await titles('create')).every((t) => t.startsWith('Created')));
    assert.ok((await titles('update')).some((t) => t.startsWith('Updated class')));
    assert.deepEqual((await titles('delete')), ['Deleted class "Form 1A"']);
    assert.deepEqual((await titles('auth')), [`Signed in (${fixture.admin.email})`]);
  });

  test('older entries (route only) still read as sentences, and their stored passwords are scrubbed on the way out', async () => {
    const legacy = await AuditLog.create({
      tenant_id: fixture.tenant.id, user_id: fixture.admin.id, action: `PUT /${randomUUID()}`, resource_type: 'students',
      details: { method: 'PUT', path: `/${randomUUID()}`, body: { first_name: 'Amina', last_name: 'Juma', password: 'old-stored-secret' }, query: {}, params: {} },
    });
    const rows = (await list()).body.data;
    const row = rows.find((r) => r.id === legacy.id);
    assert.equal(row.action, 'Updated students "Amina Juma"');
    assert.equal(row.kind, 'update');
    assert.equal(row.legacy, true);

    const detail = await request(app).get(`/api/v1/settings/audit-logs/${legacy.id}`).set(h);
    assert.equal(detail.body.data.details.request.body.password, '[hidden]');
    assert.ok(!JSON.stringify(detail.body).includes('old-stored-secret'));

    assert.ok((await list('&kind=update')).body.data.some((r) => r.id === legacy.id), 'old PUT entries are found under "update"');
  });

  test('one school can never read another school\'s entries', async () => {
    const mine = (await list()).body.data[0];
    const res = await request(app).get(`/api/v1/settings/audit-logs/${mine.id}`).set(authHeader(other.token));
    assert.equal(res.status, 404);
    const theirList = await request(app).get('/api/v1/settings/audit-logs?limit=100').set(authHeader(other.token));
    assert.ok(theirList.body.data.every((r) => r.id !== mine.id));
  });

  test('only admins can open the audit log', async () => {
    const teacher = await User.create({
      tenant_id: fixture.tenant.id, email: `t-${randomUUID().slice(0, 6)}@example.test`, password: 'Password123!',
      first_name: 'Tee', last_name: 'Cher', role: 'teacher', status: 'active',
    });
    const t = { Authorization: `Bearer ${jwt.sign({ id: teacher.id }, process.env.JWT_SECRET, { expiresIn: '1h' })}` };
    assert.equal((await request(app).get('/api/v1/settings/audit-logs').set(t)).status, 403);
    const some = (await list()).body.data[0];
    assert.equal((await request(app).get(`/api/v1/settings/audit-logs/${some.id}`).set(t)).status, 403);
  });
});
