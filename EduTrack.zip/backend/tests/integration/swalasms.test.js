/**
 * swalasms.test.js — the SwalaSMS gateway end to end: settings, connection test, sender IDs, sending (bulk and
 * single), delivery tracking, the signed webhook, and buying credits. SwalaSMS itself is stubbed from its published
 * API: nothing here touches the network or sends a real SMS.
 */
import '../helpers/noMail.js';
import { test, describe, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import request from 'supertest';
import app from '../../src/server.js';
import { Message, MessageRecipient, SmsGatewaySettings, SmsTransaction, User } from '../../src/models/index.js';
import { sendSmsViaGateway, swalaKeyMode, SWALASMS_BASE_URL } from '../../src/services/smsService.js';
import { webhookSignature } from '../../src/utils/webhookSignature.js';
import { buildTenantFixture, closeDb } from '../helpers/testFixture.js';

process.env.SWALASMS_RETRY_DELAY_MS = '0';
const SWALA_HOST = new URL(SWALASMS_BASE_URL).host; // whichever address the app is configured to call
const realFetch = globalThis.fetch;
const bearer = (user) => ({ Authorization: `Bearer ${jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '2h' })}` });
const LIVE_KEY = 'swl_live_abcdef123456';
const SANDBOX_KEY = 'swl_test_abcdef123456';

/** A stand-in for api.swalasms.com. `swala.calls` records every request; `swala.on(...)` overrides one endpoint. */
const swala = { calls: [], overrides: {}, statuses: {}, balance: 1000, mode: 'live' };
// SwalaSMS message ids are globally unique, so the stub's are too (a counter would collide with rows left by earlier runs)
const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const stub = async (url, init = {}) => {
  const u = new URL(String(url));
  if (u.host !== SWALA_HOST) return realFetch(url, init);
  const call = { method: init.method || 'GET', path: u.pathname, query: Object.fromEntries(u.searchParams), headers: init.headers || {}, body: init.body ? JSON.parse(init.body) : undefined };
  swala.calls.push(call);
  const key = `${call.method} ${call.path}`;
  const override = swala.overrides[key] || swala.overrides[`${call.method} ${call.path.replace(/\/[0-9a-f-]{8,}$/i, '/:uid')}`];
  if (override) { const r = await override(call); if (r) return r; }
  if (key === 'GET /v1/balance') return json({ success: true, mode: swala.mode, data: { balance: swala.balance, currency: 'SMS', countries: [{ wallet_uid: 'w-1', country: 'TZ', calling_code: '+255', balance: String(swala.balance) }] } });
  if (key === 'GET /v1/sender-ids') return json({ success: true, data: [
    { uid: 's1', sender_id: 'MYSCHOOL', status: 'approved', is_usable: true, is_trial: false, is_default: true, country_name: 'Tanzania', purpose: 'Notification' },
    { uid: 's2', sender_id: 'SWALATECH', status: 'approved', is_usable: true, is_trial: true, is_default: false, country_name: 'Tanzania' },
    { uid: 's3', sender_id: 'BADNAME', status: 'rejected', is_usable: false, is_trial: false, rejection_reason: 'Brand not verifiable' }] });
  if (key === 'POST /v2/sms/send-bulk') {
    const messages = []; const failures = [];
    call.body.recipients.forEach((to) => { if (to.includes('0000')) failures.push({ to, reason: 'Invalid number' }); else messages.push({ to, message_uid: `uid-${crypto.randomUUID()}-${to.replace('+', '')}`, status: 'queued', units: call.body.message.length > 160 ? 2 : 1 }); });
    return json({ success: true, mode: swala.mode, data: { uid: 'camp-1', status: 'queued', recipient_count: call.body.recipients.length, queued_count: messages.length, failed_count: failures.length, messages, failures } }, 202);
  }
  if (key === 'POST /v1/sms/messages') return json({ success: true, mode: swala.mode, data: { uid: `uid-single-${call.body.recipient.replace('+', '')}`, recipient: call.body.recipient, status: 'queued', units: 1 } }, 202);
  if (call.method === 'GET' && call.path.startsWith('/v1/sms/messages/')) {
    const uid = call.path.split('/').pop(); const st = swala.statuses[uid];
    if (st === 'missing') return json({ success: false, message: 'SMS message was not found for this API key.' }, 404);
    return json({ success: true, data: { uid, status: st?.status || 'queued', failure_reason: st?.reason || null, delivered_at: st?.status === 'delivered' ? '2026-10-31T09:15:00+03:00' : null, units: 1 } });
  }
  if (key === 'GET /v1/wallet/packages') return json({ success: true, data: { countries: [{ uid: 'c-tz', name: 'Tanzania', iso2: 'TZ', calling_code: '+255' }], selected_country: { uid: 'c-tz', name: 'Tanzania' }, packages: [{ uid: 'p-1', name: 'Starter', units: 1000, amount: 25000, currency: 'TZS' }], tiers: [{ min_units: 1, price_per_unit: 25 }], account_price: null } });
  if (key === 'GET /v1/wallet/payment-methods') return json({ success: true, data: [{ code: 'snippe', name: 'Mobile money', requires_phone: true }, { code: 'card', name: 'Card', requires_phone: false }] });
  if (key === 'POST /v1/wallet/quote') return json({ success: true, data: { units: call.body.units, amount: call.body.units * 25, currency: 'TZS' } });
  if (key === 'POST /v1/wallet/topups') return json({ success: true, mode: swala.mode, idempotent_replay: false, existing_order: false, data: { order: { uid: 'order-1', reference: '20261031-ABC123', units: call.body.units || 1000, amount: 25000, currency: 'TZS', status: swala.mode === 'sandbox' ? 'paid' : 'pending', ...(swala.mode === 'sandbox' ? { sandbox: true } : {}) }, payment: { uid: 'pay-1', mode: call.body.payment_gateway === 'card' ? 'redirect' : 'prompt', redirect_url: call.body.payment_gateway === 'card' ? 'https://pay.example/checkout' : null, reference: 'snp_1', status: 'pending' } } }, 201);
  if (key === 'GET /v1/wallet/topups/order-1') return json({ success: true, data: { order: { uid: 'order-1', reference: '20261031-ABC123', units: 1000, amount: 25000, currency: 'TZS', status: 'paid' }, payment: { uid: 'pay-1', mode: 'prompt', status: 'succeeded' } } });
  if (key === 'GET /v1/sender-ids/requirements') return json({ success: true, data: { eligibility: { can_request: true }, purposes: ['Notification', 'Alerts & Reminders'], sender_id_rules: { min_length: 3, max_length: 11 } } });
  if (key === 'POST /v1/sender-ids') return json({ success: true, message: 'Sender ID request submitted for review.', data: { uid: 'new-1', sender_id: call.body.sender_id, status: 'pending' } }, 201);
  return json({ success: false, message: `unexpected call ${key}` }, 500);
};

const uidOf = async (messageId, phone) => (await MessageRecipient.findOne({ where: { message_id: messageId, phone_snapshot: phone } })).provider_message_id;

describe('SwalaSMS gateway', () => {
  let f; let admin;
  const put = (body) => request(app).put('/api/v1/messaging/sms/gateway').set(bearer(admin)).send(body);
  const send = (body) => request(app).post('/api/v1/messaging/messages/send').set(bearer(admin)).send({ channel: 'sms', recipient_type: 'custom_numbers', ...body });
  const activate = (over = {}) => put({ provider: 'swalasms', api_key: LIVE_KEY, api_secret: 'whsec_test_secret', sender_id: 'MYSCHOOL', system_sender_id: 'EDUTRACK', is_active: true, ...over });

  before(async () => {
    f = await buildTenantFixture('swala'); admin = f.admin;
    process.env.DEVELOPER_EMAILS = admin.email;
    globalThis.fetch = stub;
  });
  beforeEach(async () => {
    Object.assign(swala, { calls: [], overrides: {}, statuses: {}, balance: 1000, mode: 'live' });
    await SmsGatewaySettings.destroy({ where: { tenant_id: f.tenant.id } });
  });
  after(async () => { globalThis.fetch = realFetch; delete process.env.DEVELOPER_EMAILS; await closeDb(); });

  describe('settings', () => {
    test('SwalaSMS is a choosable provider; the signing secret is masked and the webhook URL is returned', async () => {
      const res = await activate();
      assert.equal(res.status, 200, JSON.stringify(res.body));
      assert.equal(res.body.data.provider, 'swalasms');
      assert.equal(res.body.data.api_secret, '••••••••');
      assert.ok(!JSON.stringify(res.body).includes('whsec_test_secret'), 'the secret never travels back');
      assert.match(res.body.data.swalasms_webhook_path, new RegExp(`^/webhooks/dlr/swalasms/${f.tenant.id}/[0-9a-f]{32}$`));
    });
    test('refuses to switch on without a key, with a key of the wrong shape, or without a sender ID', async () => {
      assert.match((await activate({ api_key: '' })).body.message, /needs an API key/);
      assert.match((await activate({ api_key: 'abc123' })).body.message, /swl_live_.*swl_test_/);
      assert.match((await activate({ sender_id: '' })).body.message, /Sender ID.*SWALATECH/);
      for (const r of [await activate({ api_key: '' }), await activate({ api_key: 'abc123' }), await activate({ sender_id: '' })]) assert.equal(r.status, 400);
    });
    test('its credentials are remembered when switching to another gateway and back', async () => {
      await activate();
      await put({ provider: 'meseji', api_key: 'zs_key', sender_id: 'OTHER', is_active: false });
      const back = await put({ provider: 'swalasms' });
      assert.equal(back.body.data.api_key, LIVE_KEY);
      assert.equal(back.body.data.sender_id, 'MYSCHOOL');
    });
    test('the key mode is read from the key: live or sandbox', () => {
      assert.equal(swalaKeyMode(LIVE_KEY), 'live'); assert.equal(swalaKeyMode(SANDBOX_KEY), 'sandbox'); assert.equal(swalaKeyMode('nope'), null);
    });
    test('only the platform developer can see or change it', async () => {
      const teacher = await User.create({ tenant_id: f.tenant.id, email: `t-${Date.now()}@example.test`, password: 'Password123!', first_name: 'T', last_name: 'T', role: 'teacher', status: 'active' });
      assert.equal((await request(app).get('/api/v1/messaging/sms/gateway').set(bearer(teacher))).status, 403);
    });
  });

  describe('connection test, sender IDs and balance', () => {
    test('Test Connection proves the key and shows the live balance, without sending anything', async () => {
      await activate(); swala.balance = 4200;
      const res = await request(app).post('/api/v1/messaging/sms/gateway/test').set(bearer(admin));
      assert.equal(res.status, 200); assert.match(res.body.message, /Connected to swalasms/); assert.match(res.body.message, /4,200/);
      assert.equal(res.body.data.key_mode, 'live');
      assert.ok(swala.calls.every((c) => c.method === 'GET'), 'a test never sends or spends');
      assert.equal(swala.calls[0].headers.Authorization, `Bearer ${LIVE_KEY}`);
    });
    test('a sandbox key is clearly flagged as sending nothing real', async () => {
      await activate({ api_key: SANDBOX_KEY }); swala.mode = 'sandbox';
      const res = await request(app).post('/api/v1/messaging/sms/gateway/test').set(bearer(admin));
      assert.match(res.body.message, /SANDBOX/); assert.equal(res.body.data.key_mode, 'sandbox');
    });
    test('a rejected key gives an actionable message with the reference to quote', async () => {
      await activate();
      swala.overrides['GET /v1/balance'] = () => json({ success: false, request_uid: 'req-123', message: 'Unauthorized API key.', error_code: 'AUTHENTICATION_FAILED', acceptance_state: 'DEFINITELY_NOT_ACCEPTED' }, 401);
      const res = await request(app).post('/api/v1/messaging/sms/gateway/test').set(bearer(admin));
      assert.equal(res.status, 400); assert.match(res.body.message, /rejected the API key/); assert.match(res.body.message, /req-123/);
    });
    test('sender IDs are listed with their approval state, and the test sender is marked', async () => {
      await activate();
      const res = await request(app).get('/api/v1/messaging/sms/gateway/sender-ids').set(bearer(admin));
      assert.equal(res.status, 200);
      const by = Object.fromEntries(res.body.data.map((s) => [s.sender_id, s]));
      assert.equal(by.MYSCHOOL.is_usable, true); assert.equal(by.SWALATECH.is_trial, true); assert.match(by.SWALATECH.description, /test numbers/);
      assert.equal(by.BADNAME.status, 'rejected'); assert.match(by.BADNAME.description, /Brand not verifiable/);
    });
    test('requirements can be read and a sender ID requested', async () => {
      await activate();
      assert.equal((await request(app).get('/api/v1/messaging/sms/gateway/sender-requirements').set(bearer(admin))).body.data.purposes[0], 'Notification');
      const ok = await request(app).post('/api/v1/messaging/sms/gateway/sender-ids').set(bearer(admin)).send({ sender_id: 'LUCYLAMECK', purpose: 'Notification', sample_message: 'Dear parent, your child was marked present today at Lucy Lameck school.' });
      assert.equal(ok.status, 201); assert.equal(ok.body.data.status, 'pending');
      assert.equal(swala.calls.at(-1).body.sender_id, 'LUCYLAMECK');
      assert.equal((await request(app).post('/api/v1/messaging/sms/gateway/sender-ids').set(bearer(admin)).send({ sender_id: 'X' })).status, 400);
    });
    test('the balance page reports the real credits, per wallet, and the key mode', async () => {
      await activate(); swala.balance = 777;
      const res = await request(app).get('/api/v1/messaging/sms/balance').set(bearer(admin));
      assert.equal(res.body.data.provider, 'swalasms'); assert.equal(res.body.data.provider_credits, 777);
      assert.equal(res.body.data.provider_wallets[0].country, 'TZ'); assert.equal(res.body.data.provider_mode, 'live');
    });
  });

  describe('sending', () => {
    test('one request carries the whole message: E.164 numbers, the sender ID, a bearer key and an Idempotency-Key', async () => {
      await activate();
      const res = await send({ body: 'Hello parents', custom_numbers: ['0712345678', '0755000111'] });
      assert.equal(res.status, 200, JSON.stringify(res.body));
      const bulk = swala.calls.filter((c) => c.path === '/v2/sms/send-bulk');
      assert.equal(bulk.length, 1, 'one bulk request, not one per parent');
      assert.deepEqual(bulk[0].body.recipients, ['+255712345678', '+255755000111']);
      assert.equal(bulk[0].body.sender_id, 'MYSCHOOL'); assert.equal(bulk[0].body.message, 'Hello parents');
      assert.equal(bulk[0].headers.Authorization, `Bearer ${LIVE_KEY}`);
      assert.match(bulk[0].headers['Idempotency-Key'], /^[0-9a-f-]{36}$/);
    });
    test('each recipient keeps its own message id, and a refused number fails alone', async () => {
      await activate();
      const res = await send({ body: 'Hello', custom_numbers: ['0712345678', '0700000000', '0755000111'] });
      assert.equal(res.body.data.status, 'partially_sent'); assert.equal(res.body.data.sent_count, 2); assert.equal(res.body.data.failed_count, 1);
      const rows = await MessageRecipient.findAll({ where: { message_id: res.body.data.id } });
      const by = Object.fromEntries(rows.map((r) => [r.phone_snapshot, r]));
      assert.match(by['0712345678'].provider_message_id, /^uid-[0-9a-f-]{36}-255712345678$/); assert.equal(by['0712345678'].status, 'pending');
      assert.equal(by['0700000000'].status, 'failed'); assert.match(by['0700000000'].error_message, /Invalid number/); assert.equal(by['0700000000'].provider_message_id, null);
    });
    test('personalised messages are sent as separate texts, each recipient getting their own', async () => {
      await activate();
      await send({ body: 'Hi {{name}}', custom_numbers: ['0712345678', '0755000111'] });
      // for typed numbers the number stands in for the name, so the two texts differ and cannot share a request
      const texts = swala.calls.filter((c) => c.path === '/v2/sms/send-bulk').map((c) => c.body.message).sort();
      assert.deepEqual(texts, ['Hi 0712345678', 'Hi 0755000111']);
    });
    test('the cost follows the units SwalaSMS charged (a long message costs more parts)', async () => {
      await activate();
      const res = await send({ body: 'x'.repeat(200), custom_numbers: ['0712345678'] });
      assert.equal(Number(res.body.data.cost), 2);
    });
    test('a send that cannot be covered is stopped before anything is sent', async () => {
      await activate(); swala.balance = 1;
      const res = await send({ body: 'Hello', custom_numbers: ['0712345678', '0755000111', '0766000222'] });
      assert.equal(res.status, 400); assert.match(res.body.message, /Not enough SMS credits at SwalaSMS/);
      assert.equal(swala.calls.filter((c) => c.path === '/v2/sms/send-bulk').length, 0);
    });
    test('if SwalaSMS itself refuses for credit, the reason is recorded on every recipient', async () => {
      await activate();
      swala.overrides['POST /v2/sms/send-bulk'] = () => json({ success: false, request_uid: 'r9', error_code: 'INSUFFICIENT_BALANCE', acceptance_state: 'DEFINITELY_NOT_ACCEPTED', message: 'Needs 5 units, 2 available.' }, 422);
      const res = await send({ body: 'Hello', custom_numbers: ['0712345678'] });
      assert.equal(res.body.data.status, 'failed');
      const row = await MessageRecipient.findOne({ where: { message_id: res.body.data.id } });
      assert.match(row.error_message, /Not enough SMS credit at SwalaSMS.*Needs 5 units/);
    });
    test('an unconfirmed outcome (503) is retried ONCE with the SAME Idempotency-Key, so it can never go out twice', async () => {
      await activate(); let first = true;
      swala.overrides['POST /v2/sms/send-bulk'] = () => { if (first) { first = false; return json({ success: false, request_uid: 'r5', error_code: 'TEMPORARY_UNAVAILABLE', acceptance_state: 'UNKNOWN', message: 'Submission outcome is unknown.' }, 503); } return null; };
      const res = await send({ body: 'Hello', custom_numbers: ['0712345678'] });
      assert.equal(res.body.data.status, 'sent');
      const bulk = swala.calls.filter((c) => c.path === '/v2/sms/send-bulk');
      assert.equal(bulk.length, 2); assert.equal(bulk[0].headers['Idempotency-Key'], bulk[1].headers['Idempotency-Key']);
    });
    test('a refusal that would never succeed on retry is not retried', async () => {
      await activate();
      swala.overrides['POST /v2/sms/send-bulk'] = () => json({ success: false, error_code: 'POLICY_BLOCKED', message: 'Sender ID not approved.' }, 422);
      await send({ body: 'Hello', custom_numbers: ['0712345678'] });
      assert.equal(swala.calls.filter((c) => c.path === '/v2/sms/send-bulk').length, 1);
    });
    test('the generic sender (admission SMS, reset codes) works, and system messages use the system sender', async () => {
      const settings = { provider: 'swalasms', is_active: true, api_key: LIVE_KEY, sender_id: 'MYSCHOOL', system_sender_id: 'EDUTRACK' };
      const user = await sendSmsViaGateway(settings, { to: '0712345678', message: 'Hi' });
      assert.equal(user.provider, 'swalasms'); assert.equal(user.messageId, 'uid-single-255712345678');
      await sendSmsViaGateway(settings, { to: '0712345678', message: 'Code 123456', purpose: 'system' });
      const singles = swala.calls.filter((c) => c.path === '/v1/sms/messages');
      assert.equal(singles[0].body.sender_id, 'MYSCHOOL'); assert.equal(singles[1].body.sender_id, 'EDUTRACK');
      assert.equal(singles[0].body.recipient, '+255712345678');
    });
  });

  describe('delivery tracking', () => {
    const sendTwo = async () => {
      const res = await send({ body: 'Hello', custom_numbers: ['0712345678', '0755000111'] });
      return res.body.data.id;
    };
    test('Refresh Delivery asks SwalaSMS about each recipient and records delivered and failed', async () => {
      await activate(); const id = await sendTwo();
      swala.statuses[await uidOf(id, '0712345678')] = { status: 'delivered' };
      swala.statuses[await uidOf(id, '0755000111')] = { status: 'failed', reason: 'Number not reachable' };
      const res = await request(app).post(`/api/v1/messaging/messages/${id}/refresh-delivery`).set(bearer(admin));
      assert.equal(res.status, 200); assert.equal(res.body.delivery_check.delivered, 1); assert.equal(res.body.delivery_check.failed, 1);
      const rows = Object.fromEntries((await MessageRecipient.findAll({ where: { message_id: id } })).map((r) => [r.phone_snapshot, r]));
      assert.equal(rows['0712345678'].status, 'delivered'); assert.ok(rows['0712345678'].delivered_at);
      assert.equal(rows['0755000111'].status, 'failed'); assert.match(rows['0755000111'].error_message, /Number not reachable/);
      const msg = await Message.findByPk(id); assert.equal(msg.delivered_count, 1); assert.equal(msg.provider_failed_count, 1);
    });
    test('recipients still on their way stay pending, and the message page keeps polling', async () => {
      await activate(); const id = await sendTwo();
      swala.statuses[await uidOf(id, '0712345678')] = { status: 'sent' };
      const view = await request(app).get(`/api/v1/messaging/messages/${id}`).set(bearer(admin));
      assert.equal(view.body.data.delivery_provider, 'swalasms'); assert.equal(view.body.data.delivery_polling, true);
      assert.equal((await MessageRecipient.count({ where: { message_id: id, status: 'pending' } })), 2);
    });
    test('an unknown message id is "no report yet", not an error', async () => {
      await activate(); const id = await sendTwo();
      swala.statuses[await uidOf(id, '0712345678')] = 'missing'; swala.statuses[await uidOf(id, '0755000111')] = 'missing';
      const res = await request(app).post(`/api/v1/messaging/messages/${id}/refresh-delivery`).set(bearer(admin));
      assert.equal(res.status, 200); assert.equal(res.body.delivery_check.no_report, 2);
    });
  });

  describe('delivery-report webhook', () => {
    const sig = (tenantId = f.tenant.id) => webhookSignature(tenantId, 'swalasms-dlr');
    const post = (payload, { secret = 'whsec_test_secret', tenantId = f.tenant.id, pathSig = sig(tenantId), tamper = false } = {}) => {
      const raw = JSON.stringify(payload);
      const mac = crypto.createHmac('sha256', secret).update(tamper ? `${raw} ` : raw).digest('hex');
      return request(app).post(`/api/v1/webhooks/dlr/swalasms/${tenantId}/${pathSig}`).set('Content-Type', 'application/json').set('X-SwalaSMS-Signature', mac).send(raw);
    };
    const sentMessage = async () => {
      const res = await send({ body: 'Hello', custom_numbers: ['0712345678'] });
      return { id: res.body.data.id, uid: await uidOf(res.body.data.id, '0712345678') };
    };
    test('a correctly signed "delivered" report finishes the recipient and updates the counts', async () => {
      await activate(); const { id, uid } = await sentMessage();
      const res = await post({ event: 'sms.delivered', message_id: uid, to: '0712345678', status: 'delivered', delivered_at: '2026-10-31T09:15:00+03:00' });
      assert.equal(res.status, 200);
      const row = await MessageRecipient.findOne({ where: { message_id: id } });
      assert.equal(row.status, 'delivered'); assert.equal((await Message.findByPk(id)).delivered_count, 1);
    });
    test('a "failed" report records the reason; a repeated callback changes nothing more', async () => {
      await activate(); const { id, uid } = await sentMessage();
      const payload = { event: 'sms.failed', message_id: uid, status: 'failed', error: 'Handset switched off' };
      await post(payload); await post(payload);
      const row = await MessageRecipient.findOne({ where: { message_id: id } });
      assert.equal(row.status, 'failed'); assert.match(row.error_message, /Handset switched off/);
      assert.equal((await Message.findByPk(id)).provider_failed_count, 1);
    });
    test('a body that does not match the signature is refused, and nothing changes', async () => {
      await activate(); const { id, uid } = await sentMessage();
      assert.equal((await post({ event: 'sms.delivered', message_id: uid }, { tamper: true })).status, 401);
      assert.equal((await post({ event: 'sms.delivered', message_id: uid }, { secret: 'someone-elses-secret' })).status, 401);
      assert.equal((await MessageRecipient.findOne({ where: { message_id: id } })).status, 'pending');
    });
    test('a forged URL is not found, and another school cannot touch this school\'s messages', async () => {
      await activate(); const { id, uid } = await sentMessage();
      assert.equal((await post({ event: 'sms.delivered', message_id: uid }, { pathSig: 'f'.repeat(32) })).status, 404);
      const other = await buildTenantFixture('swala-other');
      await post({ event: 'sms.delivered', message_id: uid }, { tenantId: other.tenant.id });
      assert.equal((await MessageRecipient.findOne({ where: { message_id: id } })).status, 'pending');
    });
    test('without a saved signing secret the signed URL alone is accepted (as with NextSMS)', async () => {
      await activate({ api_secret: '' }); const { id, uid } = await sentMessage();
      const raw = JSON.stringify({ event: 'sms.delivered', message_id: uid });
      const res = await request(app).post(`/api/v1/webhooks/dlr/swalasms/${f.tenant.id}/${sig()}`).set('Content-Type', 'application/json').send(raw);
      assert.equal(res.status, 200);
      assert.equal((await MessageRecipient.findOne({ where: { message_id: id } })).status, 'delivered');
    });
    test('a completed top-up is recorded once in the SMS history; other events are acknowledged and ignored', async () => {
      await activate();
      const ev = { event: 'wallet.topup.completed', order_uid: 'order-77', reference: '20261031-K4Q9ZD', units: 5000, amount: 100000, currency: 'TZS', status: 'paid', balance_after: 6250 };
      await post(ev); await post(ev);
      const rows = await SmsTransaction.findAll({ where: { tenant_id: f.tenant.id, reference: 'swalasms:order-77' } });
      assert.equal(rows.length, 1); assert.equal(Number(rows[0].amount), 5000); assert.equal(rows[0].type, 'purchase');
      assert.equal((await post({ event: 'something.else' })).status, 200);
      assert.equal((await post({ event: 'wallet.topup.failed', order_uid: 'order-78' })).status, 200);
    });
  });

  describe('buying credits', () => {
    test('options list the markets, packages, prices and payment methods', async () => {
      await activate();
      const res = await request(app).get('/api/v1/messaging/sms/wallet/options').set(bearer(admin));
      assert.equal(res.status, 200); assert.equal(res.body.data.country_uid, 'c-tz');
      assert.equal(res.body.data.packages[0].uid, 'p-1'); assert.deepEqual(res.body.data.payment_methods.map((m) => m.code), ['snippe', 'card']);
      assert.equal(swala.calls.find((c) => c.path === '/v1/wallet/payment-methods').query.country_uid, 'c-tz');
    });
    test('a custom quantity can be priced before paying', async () => {
      await activate();
      const res = await request(app).post('/api/v1/messaging/sms/wallet/quote').set(bearer(admin)).send({ country_uid: 'c-tz', units: 2000 });
      assert.equal(res.body.data.amount, 50000);
      assert.equal((await request(app).post('/api/v1/messaging/sms/wallet/quote').set(bearer(admin)).send({ units: 5 })).status, 400);
    });
    test('mobile money: a payment prompt is sent to the phone, and the order can be followed until paid', async () => {
      await activate();
      const res = await request(app).post('/api/v1/messaging/sms/top-up').set(bearer(admin)).send({ units: 1000, payment_gateway: 'snippe', phone: '0712345678', country_uid: 'c-tz' });
      assert.equal(res.status, 200, JSON.stringify(res.body));
      assert.match(res.body.message, /payment prompt has been sent to 0712345678/); assert.equal(res.body.data.orderUid, 'order-1'); assert.equal(res.body.data.payment.mode, 'prompt');
      const call = swala.calls.find((c) => c.path === '/v1/wallet/topups');
      assert.deepEqual({ units: call.body.units, gw: call.body.payment_gateway, phone: call.body.billing_phone, country: call.body.country_uid }, { units: 1000, gw: 'snippe', phone: '+255712345678', country: 'c-tz' });
      assert.ok(call.headers['Idempotency-Key']);
      const poll = await request(app).get('/api/v1/messaging/sms/top-up/order-1').set(bearer(admin));
      assert.equal(poll.body.data.status, 'paid');
    });
    test('card: the answer is a link to open', async () => {
      await activate();
      const res = await request(app).post('/api/v1/messaging/sms/top-up').set(bearer(admin)).send({ units: 1000, payment_gateway: 'card' });
      assert.match(res.body.message, /payment link/); assert.equal(res.body.data.payment.redirectUrl, 'https://pay.example/checkout');
    });
    test('a fixed package can be bought instead of a quantity', async () => {
      await activate();
      await request(app).post('/api/v1/messaging/sms/top-up').set(bearer(admin)).send({ package_uid: 'p-1', payment_gateway: 'snippe', phone: '0712345678' });
      const call = swala.calls.find((c) => c.path === '/v1/wallet/topups');
      assert.equal(call.body.package_uid, 'p-1'); assert.equal(call.body.units, undefined);
    });
    test('a sandbox key says so and charges nothing', async () => {
      await activate({ api_key: SANDBOX_KEY }); swala.mode = 'sandbox';
      const res = await request(app).post('/api/v1/messaging/sms/top-up').set(bearer(admin)).send({ units: 1000, payment_gateway: 'snippe', phone: '0712345678' });
      assert.match(res.body.message, /Sandbox top-up/); assert.equal(res.body.data.sandbox, true);
    });
    test('bad requests are refused before anything is ordered', async () => {
      await activate();
      const post = (b) => request(app).post('/api/v1/messaging/sms/top-up').set(bearer(admin)).send(b);
      assert.equal((await post({ units: 0, payment_gateway: 'snippe' })).status, 400);
      assert.equal((await post({ units: 1.5, payment_gateway: 'snippe' })).status, 400);
      assert.equal((await post({ units: 5000000, payment_gateway: 'snippe' })).status, 400);
      assert.equal((await post({ units: 100 })).status, 400);
      assert.equal(swala.calls.filter((c) => c.path === '/v1/wallet/topups').length, 0);
    });
    test('a key without the wallet permission gets a clear message', async () => {
      await activate();
      swala.overrides['POST /v1/wallet/topups'] = () => json({ success: false, message: 'Unauthorized API key.', error_code: 'AUTHENTICATION_FAILED' }, 401);
      const res = await request(app).post('/api/v1/messaging/sms/top-up').set(bearer(admin)).send({ units: 1000, payment_gateway: 'snippe', phone: '0712345678' });
      assert.equal(res.status, 400); assert.match(res.body.message, /wallet:topup/);
    });
    test('the wallet endpoints refuse a school that is not on SwalaSMS', async () => {
      await put({ provider: 'simulated', is_active: false });
      assert.equal((await request(app).get('/api/v1/messaging/sms/wallet/options').set(bearer(admin))).status, 400);
    });
  });
});
