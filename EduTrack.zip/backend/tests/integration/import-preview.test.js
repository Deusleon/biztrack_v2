/**
 * import-preview.test.js — the Excel import PREVIEW for students and staff, and that the real import
 * follows the very same rules. Real Postgres, real HTTP (supertest).
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import { Class, Section, Student, Staff, User } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';
import jwt from 'jsonwebtoken';

describe('Excel import preview', () => {
  let f; let campus; let cls;
  const tag = Date.now().toString(36);

  const studentRow = (n, over = {}) => ({
    __row: n + 1, first_name: `Amina${n}`, last_name: `Juma${tag}`, gender: 'Female', date_of_birth: '2014-04-18',
    admission_number: `ADM-${tag}-${n}`, admission_date: '2026-01-15', campus_name: 'Main Campus', ...over,
  });
  const staffRow = (n, over = {}) => ({
    __row: n + 1, first_name: `Neema${n}`, last_name: `Mushi${tag}`, email: `neema${n}-${tag}@example.test`, phone: `07${String(10000000 + n + Number.parseInt(tag.slice(-4), 36) % 80000).slice(0, 8)}`,
    role: 'Teacher', employee_number: `EMP-${tag}-${n}`, campus_name: 'Main Campus', contract_type: 'Permanent', salary: '800,000', ...over,
  });
  const post = (path, body, token = f.token) => request(app).post(path).set(authHeader(token)).send(body);

  before(async () => {
    f = await buildTenantFixture('import');
    campus = f.campus;
    cls = await Class.create({ tenant_id: f.tenant.id, campus_id: campus.id, name: 'Standard 4', grade: '4', education_level: 'primary', academic_year: '2026' });
    await Section.create({ tenant_id: f.tenant.id, class_id: cls.id, name: 'A', capacity: 40 }).catch(() => {});
    // someone already in the school
    const u = await User.create({ tenant_id: f.tenant.id, email: `old-${tag}@example.test`, password: 'Password123!', first_name: 'Baraka', last_name: 'Existing', role: 'student', status: 'active' });
    await Student.create({ tenant_id: f.tenant.id, user_id: u.id, campus_id: campus.id, admission_number: `ADM-OLD-${tag}`, date_of_birth: '2013-05-05', gender: 'male', status: 'active' });
  });
  after(closeDb);

  describe('students', () => {
    test('a clean file is all ready, and nothing is saved by previewing', async () => {
      const before = await Student.count({ where: { tenant_id: f.tenant.id } });
      const res = await post('/api/v1/students/bulk/preview', { academic_year: '2026', students: [studentRow(1), studentRow(2), studentRow(3, { class_name: 'Standard 4' })] });
      assert.equal(res.status, 200);
      assert.equal(res.body.data.summary.ready, 3);
      assert.equal(res.body.data.summary.errors, 0);
      assert.equal(await Student.count({ where: { tenant_id: f.tenant.id } }), before, 'preview must not save anything');
      assert.equal(res.body.data.rows[2].class_name, 'Standard 4');
    });

    test('every kind of problem is reported on the right row with the real Excel row number', async () => {
      const rows = [
        studentRow(10, { __row: 5, first_name: '' }),
        studentRow(11, { __row: 9, gender: 'Robot' }),
        studentRow(12, { date_of_birth: '2012-02-31' }),
        studentRow(13, { date_of_birth: '2999-01-01' }),
        studentRow(14, { campus_name: 'Nowhere' }),
        studentRow(15, { class_name: 'Standard 9' }),
        studentRow(16, { parent_email: 'not-an-email' }),
        studentRow(17, { admission_number: '' }),
      ];
      const res = await post('/api/v1/students/bulk/preview', { academic_year: '2026', students: rows });
      const by = Object.fromEntries(res.body.data.rows.map((r) => [r.row, r]));
      assert.equal(by[5].status, 'error'); assert.match(by[5].errors[0], /First name is required/);
      assert.equal(by[9].status, 'error'); assert.match(by[9].errors.join(), /Gender/);
      assert.match(by[13].errors.join(), /not a real date/, '31 February is not a date');
      assert.match(by[14].errors.join(), /in the future/);
      assert.match(by[15].errors.join(), /Campus "Nowhere" was not found/);
      assert.match(by[16].errors.join(), /Class "Standard 9" was not found/);
      assert.match(by[17].errors.join(), /Parent email/);
      assert.match(by[18].errors.join(), /Admission number is required/);
      assert.equal(res.body.data.summary.errors, 8);
    });

    test('duplicate admission numbers are caught — already in the school, and repeated inside the file', async () => {
      const res = await post('/api/v1/students/bulk/preview', { academic_year: '2026', students: [
        studentRow(20, { admission_number: `ADM-OLD-${tag}` }),
        studentRow(21, { admission_number: `ADM-DUP-${tag}` }),
        studentRow(22, { admission_number: `adm-dup-${tag}` }),
      ] });
      const [a, b, c] = res.body.data.rows;
      assert.equal(a.status, 'error'); assert.equal(a.duplicate.kind, 'existing');
      assert.equal(b.status, 'ready', 'the first use of a number is fine');
      assert.equal(c.status, 'error'); assert.equal(c.duplicate.kind, 'in_file'); assert.equal(c.duplicate.of_row, b.row);
      assert.equal(res.body.data.summary.blocked_duplicates, 2);
    });

    test('the same person (name + date of birth) is flagged as a POSSIBLE duplicate, not blocked', async () => {
      const res = await post('/api/v1/students/bulk/preview', { academic_year: '2026', students: [
        studentRow(30, { first_name: 'Baraka', last_name: 'Existing', date_of_birth: '2013-05-05' }),
        studentRow(31, { first_name: 'Zawadi', last_name: `Twin${tag}`, date_of_birth: '2015-01-01' }),
        studentRow(32, { first_name: 'zawadi', last_name: `TWIN${tag}`, date_of_birth: '2015-01-01' }),
      ] });
      const [a, b, c] = res.body.data.rows;
      assert.equal(a.status, 'possible_duplicate'); assert.equal(a.duplicate.kind, 'possible_existing');
      assert.equal(b.status, 'ready');
      assert.equal(c.status, 'possible_duplicate'); assert.equal(c.duplicate.kind, 'possible_in_file');
      assert.equal(res.body.data.summary.possible_duplicates, 2);
      assert.equal(res.body.data.summary.errors, 0);
    });

    test('unusual ages and a missing class are warnings, not errors', async () => {
      const res = await post('/api/v1/students/bulk/preview', { academic_year: '2026', students: [studentRow(40, { date_of_birth: '1980-01-01' }), studentRow(41)] });
      assert.equal(res.body.data.rows[0].status, 'ready');
      assert.match(res.body.data.rows[0].warnings.join(), /Age .* unusual/);
      assert.match(res.body.data.rows[1].warnings.join(), /No class given/);
    });

    test('the preview and the real import agree row for row', async () => {
      const rows = [studentRow(50), studentRow(51, { first_name: '' }), studentRow(52, { admission_number: `ADM-OLD-${tag}` }), studentRow(53, { campus_name: 'Nowhere' }), studentRow(54)];
      const preview = (await post('/api/v1/students/bulk/preview', { academic_year: '2026', students: rows })).body.data.rows;
      const done = (await post('/api/v1/students/bulk', { academic_year: '2026', students: rows })).body.data.results;
      for (const p of preview) {
        const d = done.find((x) => x.row === p.row);
        assert.equal(d.status === 'created', p.status === 'ready', `row ${p.row}: preview said ${p.status}, import said ${d.status} (${d.message})`);
      }
      assert.equal(done.filter((d) => d.status === 'created').length, 2);
    });

    test('rows beyond the plan limit are shown as errors in the preview', async () => {
      // tenant fixture has no subscription row, so the limit is unlimited: the field says so
      const res = await post('/api/v1/students/bulk/preview', { academic_year: '2026', students: [studentRow(60)] });
      assert.equal(res.body.data.summary.slots_left, null);
    });

    test('empty and oversized files are refused; other roles cannot preview', async () => {
      assert.equal((await post('/api/v1/students/bulk/preview', { students: [] })).status, 400);
      assert.equal((await post('/api/v1/students/bulk/preview', { students: Array.from({ length: 501 }, (_, i) => studentRow(i)) })).status, 400);
      const teacher = await User.create({ tenant_id: f.tenant.id, email: `t-${tag}@example.test`, password: 'Password123!', first_name: 'T', last_name: 'T', role: 'teacher', status: 'active' });
      const tok = jwt.sign({ id: teacher.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
      assert.equal((await post('/api/v1/students/bulk/preview', { students: [studentRow(1)] }, tok)).status, 403);
    });
  });

  describe('staff', () => {
    test('a clean file is ready and saves nothing', async () => {
      const before = await Staff.count({ where: { tenant_id: f.tenant.id } });
      const res = await post('/api/v1/staff/bulk/preview', { staff: [staffRow(1), staffRow(2, { role: 'hr manager' }), staffRow(3, { contract_type: 'Part-Time' })] });
      assert.equal(res.status, 200);
      assert.equal(res.body.data.summary.ready, 3, JSON.stringify(res.body.data.rows.map((r) => r.errors)));
      assert.equal(await Staff.count({ where: { tenant_id: f.tenant.id } }), before);
      assert.equal(res.body.data.rows[1].role, 'hr', '"HR Manager" is understood');
    });

    test('problems are reported per row', async () => {
      const rows = [
        staffRow(10, { __row: 4, email: 'nope' }),
        staffRow(11, { __row: 5, role: 'wizard' }),
        staffRow(12, { __row: 6, employee_number: '' }),
        staffRow(13, { __row: 7, campus_name: 'Mars' }),
        staffRow(14, { __row: 8, joining_date: '2025-13-40' }),
        staffRow(15, { __row: 9, salary: 'lots' }),
        staffRow(16, { __row: 10, contract_type: 'Forever' }),
        staffRow(17, { __row: 11, joining_date: '2025-06-01', contract_end_date: '2025-01-01' }),
      ];
      const res = await post('/api/v1/staff/bulk/preview', { staff: rows });
      const by = Object.fromEntries(res.body.data.rows.map((r) => [r.row, r]));
      assert.match(by[4].errors.join(), /valid email/);
      assert.match(by[5].errors.join(), /not a staff role/);
      assert.match(by[6].errors.join(), /Employee number is required/);
      assert.match(by[7].errors.join(), /Campus "Mars"/);
      assert.match(by[8].errors.join(), /Joining date is not a real date/);
      assert.match(by[9].errors.join(), /Salary must be a number/);
      assert.match(by[10].errors.join(), /Contract type/);
      assert.match(by[11].errors.join(), /before the joining date/);
    });

    test('duplicates: existing employee number / email, and repeats inside the file', async () => {
      const first = await post('/api/v1/staff/bulk', { staff: [staffRow(20)] });
      assert.equal(first.body.data.summary.created, 1, JSON.stringify(first.body));
      const res = await post('/api/v1/staff/bulk/preview', { staff: [
        staffRow(21, { employee_number: `EMP-${tag}-20` }),
        staffRow(22, { email: `neema20-${tag}@example.test` }),
        staffRow(23, { employee_number: `EMP-${tag}-X`, email: `x-${tag}@example.test` }),
        staffRow(24, { employee_number: `emp-${tag}-x`, email: `y-${tag}@example.test` }),
        staffRow(25, { employee_number: `EMP-${tag}-Z`, email: `x-${tag}@example.test` }),
      ] });
      const [a, b, c, d, e] = res.body.data.rows;
      assert.equal(a.duplicate.kind, 'existing'); assert.equal(b.duplicate.kind, 'existing');
      assert.equal(c.status, 'ready');
      assert.equal(d.duplicate.kind, 'in_file'); assert.equal(e.duplicate.kind, 'in_file');
      assert.equal(res.body.data.summary.blocked_duplicates, 4);
    });

    test('a head of school cannot hand out Admin or Principal unless they are an administrator', async () => {
      const hr = await User.create({ tenant_id: f.tenant.id, email: `hr-${tag}@example.test`, password: 'Password123!', first_name: 'H', last_name: 'R', role: 'hr', status: 'active' });
      const tok = jwt.sign({ id: hr.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
      const res = await post('/api/v1/staff/bulk/preview', { staff: [staffRow(30, { role: 'Admin' }), staffRow(31, { role: 'Teacher' })] }, tok);
      assert.equal(res.status, 200);
      assert.equal(res.body.data.rows[0].status, 'error'); assert.match(res.body.data.rows[0].errors.join(), /Only an administrator/);
      assert.equal(res.body.data.rows[1].status, 'ready');
    });

    test('possible duplicate by national ID or name + birth date; not blocked', async () => {
      await post('/api/v1/staff/bulk', { staff: [staffRow(40, { national_id: '19900101-12345-00001-1', date_of_birth: '1990-01-01' })] });
      const res = await post('/api/v1/staff/bulk/preview', { staff: [
        staffRow(41, { national_id: '19900101123450000 11'.replace(/ /g, '') }),
        staffRow(42, { first_name: 'Neema40', last_name: `Mushi${tag}`, date_of_birth: '1990-01-01' }),
      ] });
      assert.equal(res.body.data.rows[0].status, 'possible_duplicate');
      assert.equal(res.body.data.rows[1].status, 'possible_duplicate');
    });

    test('the preview and the real import agree, and each person gets a working login', async () => {
      const rows = [staffRow(50), staffRow(51, { email: 'bad' }), staffRow(52, { role: 'accountant' }), staffRow(53, { employee_number: `EMP-${tag}-50` })];
      const preview = (await post('/api/v1/staff/bulk/preview', { staff: rows })).body.data.rows;
      const done = (await post('/api/v1/staff/bulk', { staff: rows })).body.data.results;
      for (const p of preview) {
        const d = done.find((x) => x.row === p.row);
        assert.equal(d.status === 'created', p.status === 'ready', `row ${p.row}: preview ${p.status} vs import ${d.status} (${d.message})`);
      }
      const made = await User.findOne({ where: { email: `neema52-${tag}@example.test` } });
      assert.equal(made.role, 'accountant');
      assert.equal(made.must_change_password, true);
      assert.ok(await Staff.findOne({ where: { user_id: made.id } }), 'a login always comes with its staff record');
    });

    test('other roles cannot import staff', async () => {
      const t = await User.create({ tenant_id: f.tenant.id, email: `t2-${tag}@example.test`, password: 'Password123!', first_name: 'T', last_name: 'T', role: 'teacher', status: 'active' });
      const tok = jwt.sign({ id: t.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
      assert.equal((await post('/api/v1/staff/bulk/preview', { staff: [staffRow(60)] }, tok)).status, 403);
      assert.equal((await post('/api/v1/staff/bulk', { staff: [staffRow(60)] }, tok)).status, 403);
    });
  });
});
