/**
 * password-policy.test.js
 *
 * First sign-in with the shared starting password: the person can do nothing
 * except change it (enforced by the API, not just the screen), and once they
 * have, every earlier session is void.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'crypto';
import request from 'supertest';
import app from '../../src/server.js';
import { User } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';
import { DEFAULT_STAFF_PASSWORD } from '../../src/utils/studentCredentials.js';

describe('Starting password and sessions', () => {
  let fx; let admin;
  const staffEmail = () => `new-staff-${randomUUID().slice(0, 8)}@example.test`;
  const login = (email, password) => request(app).post('/api/v1/auth/login').send({ email, password });
  const as = (token) => ({ Authorization: `Bearer ${token}` });

  /** A staff member added the normal way, so they get the starting password. */
  const addStaff = async () => {
    const email = staffEmail();
    const n = randomUUID().slice(0, 8);
    const res = await request(app).post('/api/v1/staff').set(admin).send({
      email, first_name: 'New', last_name: 'Starter', phone: `0713${n.replace(/\D/g, '1').slice(0, 6).padEnd(6, '7')}`,
      role: 'teacher', employee_number: `EMP-${n}`, campus_id: fx.campus.id,
    });
    assert.equal(res.status, 201, res.body.message);
    return email;
  };

  before(async () => { fx = await buildTenantFixture('pwpolicy'); admin = authHeader(fx.token); });
  after(closeDb);

  test('a new staff member signs in with the starting password and is told to change it', async () => {
    const email = await addStaff();
    const res = await login(email, DEFAULT_STAFF_PASSWORD);
    assert.equal(res.status, 200);
    assert.equal(res.body.data.must_change_password, true);
  });

  test('until they do, the API refuses everything except who-am-I and the change itself', async () => {
    const { body } = await login(await addStaff(), DEFAULT_STAFF_PASSWORD);
    const t = as(body.data.token);
    for (const path of ['/students', '/classes', '/notifications', '/settings', '/staff', '/campus']) {
      const res = await request(app).get(`/api/v1${path}`).set(t);
      assert.equal(res.status, 403, path);
      assert.equal(res.body.code, 'PASSWORD_CHANGE_REQUIRED', path);
    }
    assert.equal((await request(app).put('/api/v1/auth/profile').set(t).send({ first_name: 'Hacked' })).status, 403);
    assert.equal((await request(app).get('/api/v1/auth/me').set(t)).status, 200);
    assert.equal((await request(app).get('/api/v1/auth/me').set(t)).body.data.must_change_password, true);
  });

  test('"changing" it to the same or another starting password is refused', async () => {
    const { body } = await login(await addStaff(), DEFAULT_STAFF_PASSWORD);
    const t = as(body.data.token);
    const same = await request(app).put('/api/v1/auth/change-password').set(t).send({ current_password: DEFAULT_STAFF_PASSWORD, new_password: DEFAULT_STAFF_PASSWORD });
    assert.equal(same.status, 400);
    assert.match(same.body.message, /different/i);
    const short = await request(app).put('/api/v1/auth/change-password').set(t).send({ current_password: DEFAULT_STAFF_PASSWORD, new_password: 'abc' });
    assert.equal(short.status, 400);
    // letters AND numbers, at least 8 characters
    for (const weak of ['abcdefghij', '1234567890', 'Abc1234', 'password']) {
      const res = await request(app).put('/api/v1/auth/change-password').set(t).send({ current_password: DEFAULT_STAFF_PASSWORD, new_password: weak });
      assert.equal(res.status, 400, weak);
      assert.match(res.body.message, /letters and numbers/i, weak);
    }
    const wrong = await request(app).put('/api/v1/auth/change-password').set(t).send({ current_password: 'not-it', new_password: 'BrandNew#2026' });
    assert.equal(wrong.status, 400, 'a typo must not look like "not signed in", which would sign the person out');
    assert.equal((await request(app).get('/api/v1/auth/me').set(t)).body.data.must_change_password, true, 'still pending after the refused attempts');
  });

  test('a password with letters and numbers, 8 or more characters, is accepted', async () => {
    const { body } = await login(await addStaff(), DEFAULT_STAFF_PASSWORD);
    const ok = await request(app).put('/api/v1/auth/change-password').set(as(body.data.token)).send({ current_password: DEFAULT_STAFF_PASSWORD, new_password: 'Abcd1234' });
    assert.equal(ok.status, 200);
  });

  test('changing it unlocks the account — and the old password and old session stop working', async () => {
    const email = await addStaff();
    const first = await login(email, DEFAULT_STAFF_PASSWORD);
    const oldToken = first.body.data.token;
    const change = await request(app).put('/api/v1/auth/change-password').set(as(oldToken)).send({ current_password: DEFAULT_STAFF_PASSWORD, new_password: 'BrandNew#2026' });
    assert.equal(change.status, 200);
    assert.ok(change.body.data.token, 'a fresh token comes back');

    assert.equal((await request(app).get('/api/v1/auth/me').set(as(oldToken))).status, 401, 'the session from before the change is void');
    assert.equal((await login(email, DEFAULT_STAFF_PASSWORD)).status, 401, 'the starting password no longer works');

    const second = await login(email, 'BrandNew#2026');
    assert.equal(second.status, 200);
    assert.equal(second.body.data.must_change_password, false);
    assert.equal((await request(app).get('/api/v1/classes').set(as(second.body.data.token))).status, 200, 'the API works normally now');
  });

  test('a normal password change keeps THIS browser signed in with the token it is given', async () => {
    const email = await addStaff();
    const tok = (await login(email, DEFAULT_STAFF_PASSWORD)).body.data.token;
    await request(app).put('/api/v1/auth/change-password').set(as(tok)).send({ current_password: DEFAULT_STAFF_PASSWORD, new_password: 'FirstChoice#1' });
    const t2 = (await login(email, 'FirstChoice#1')).body.data.token;
    const again = await request(app).put('/api/v1/auth/change-password').set(as(t2)).send({ current_password: 'FirstChoice#1', new_password: 'SecondChoice#2' });
    assert.equal(again.status, 200);
    assert.equal((await request(app).get('/api/v1/auth/me').set(as(again.body.data.token))).status, 200);
    assert.equal((await request(app).get('/api/v1/auth/me').set(as(t2))).status, 401);
  });

  test('an account that still has the starting password is caught at sign-in even if it was never marked', async () => {
    const user = await User.create({
      tenant_id: fx.tenant.id, email: staffEmail(), password: DEFAULT_STAFF_PASSWORD, first_name: 'Old', last_name: 'Account',
      role: 'teacher', status: 'active', must_change_password: false,
    });
    const res = await login(user.email, DEFAULT_STAFF_PASSWORD);
    assert.equal(res.body.data.must_change_password, true);
    assert.equal((await request(app).get('/api/v1/classes').set(as(res.body.data.token))).status, 403);
  });

  test('sessions issued before this existed (no fingerprint) keep working until they expire', async () => {
    const u = await User.create({ tenant_id: fx.tenant.id, email: staffEmail(), password: 'Whatever#123', first_name: 'Legacy', last_name: 'Session', role: 'teacher', status: 'active' });
    const legacy = jwt.sign({ id: u.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    assert.equal((await request(app).get('/api/v1/classes').set(as(legacy))).status, 200);
  });

  test('a person who has never needed to change anything is not affected', async () => {
    const res = await login(fx.admin.email, 'Password123!');
    assert.equal(res.status, 200);
    assert.equal(res.body.data.must_change_password, false);
    assert.equal((await request(app).get('/api/v1/classes').set(as(res.body.data.token))).status, 200);
  });
});
