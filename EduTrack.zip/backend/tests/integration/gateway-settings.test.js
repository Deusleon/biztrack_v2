// FILE PATH: backend/tests/unit/emailGateway.test.js
//
// Email gateway Test Connection / Send Test Email — against a real (fake, local)
// SMTP server, so what nodemailer actually reports is what gets checked.
//
//   node --test tests/unit/emailGateway.test.js
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import { verifyEmailGateway, sendGatewayTestEmail, describeSmtpError, gatewayFromAddress } from '../../src/services/emailService.js';
import { startFakeSmtp, closedPort } from '../helpers/fakeSmtp.js';

let smtp;
before(async () => { smtp = await startFakeSmtp({ user: 'mailer', pass: 'right-pass' }); });
after(() => smtp.close());

const gw = (over = {}) => ({
  smtp_host: '127.0.0.1', smtp_port: smtp.port, smtp_secure: false,
  smtp_username: 'mailer', smtp_password: 'right-pass', from_email: 'noreply@school.test', from_name: 'Test School', ...over,
});
/** Runs fn and returns the error it threw. */
const failure = async (fn) => { try { await fn(); } catch (e) { return e; } assert.fail('expected a failure'); };

test('Test Connection logs in without sending anything', async () => {
  const before = smtp.messages.length;
  const result = await verifyEmailGateway(gw());
  assert.equal(result.authenticated, true);
  assert.equal(smtp.messages.length, before, 'verify must not deliver a message');
});

test('a wrong password is explained, not just "Invalid login"', async () => {
  const err = await failure(() => verifyEmailGateway(gw({ smtp_password: 'wrong' })));
  assert.match(describeSmtpError(err, gw()), /rejected the username or password/);
  assert.match(describeSmtpError(err, gw()), /App Password/);
});

test('a closed port says the connection was refused', async () => {
  const port = await closedPort();
  const err = await failure(() => verifyEmailGateway(gw({ smtp_port: port })));
  assert.match(describeSmtpError(err, gw({ smtp_port: port })), /refused the connection on port/);
});

test('TLS ticked against a plain-text port points at the TLS setting', async () => {
  const cfg = gw({ smtp_secure: true });
  const err = await failure(() => verifyEmailGateway(cfg));
  const text = describeSmtpError(err, cfg);
  assert.match(text, /TLS|answer/i);
  assert.match(text, /Use TLS on connect/);
});

test('port 465 without "Use TLS on connect" is called out', () => {
  const text = describeSmtpError(Object.assign(new Error('Connection timeout'), { code: 'ETIMEDOUT' }), { smtp_host: 'mail.x.test', smtp_port: 465, smtp_secure: false });
  assert.match(text, /No answer from mail\.x\.test:465/);
  assert.match(text, /Port 465 expects/);
});

test('an unknown host is reported as such', () => {
  const text = describeSmtpError(Object.assign(new Error('getaddrinfo ENOTFOUND smtp.nope.test'), { code: 'EDNS' }), { smtp_host: 'smtp.nope.test' });
  assert.match(text, /"smtp\.nope\.test" could not be found/);
});

test('a server that never greets times out quickly instead of hanging the page', async (t) => {
  const silent = net.createServer(() => {}); // accepts, says nothing
  await new Promise((r) => silent.listen(0, '127.0.0.1', r));
  t.after(() => new Promise((r) => { silent.close(r); silent.closeAllConnections?.(); }));
  const cfg = gw({ smtp_port: silent.address().port });
  const started = Date.now();
  const err = await failure(() => verifyEmailGateway(cfg));
  assert.ok(Date.now() - started < 20000, 'bounded by the test timeout');
  assert.match(describeSmtpError(err, cfg), /No answer from/);
});

test('Send Test Email delivers one real message from the configured From address', async () => {
  const before = smtp.messages.length;
  const sent = await sendGatewayTestEmail(gw(), 'principal@school.test');
  assert.equal(smtp.messages.length, before + 1);
  const msg = smtp.messages[smtp.messages.length - 1];
  assert.deepEqual(msg.to, ['principal@school.test']);
  assert.equal(msg.from, 'noreply@school.test');
  assert.match(msg.data, /EduTrack email gateway test/);
  assert.equal(sent.from, '"Test School" <noreply@school.test>');
});

test('the From address falls back to the login when none is set', () => {
  assert.equal(gatewayFromAddress({ smtp_username: 'mailer@school.test' }), 'mailer@school.test');
  assert.equal(gatewayFromAddress({}, 'fallback@x.test'), 'fallback@x.test');
});