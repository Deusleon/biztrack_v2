/**
 * class-roster-history.test.js
 *
 * Same underlying bug as the original Students-list report, found in
 * three more places: Fee Status, the exam Marks Sheet, and Class
 * Results all fetched their roster with a plain
 * `Student.where({ class_id })` — which only ever reflects CURRENT
 * enrollment. Once a student has been promoted out of a class, viewing
 * that class's PAST fee status or exam results silently lost them.
 *
 * This drives a student through: enrolled in Form II (2026) → promoted
 * to Form III (2027) — then checks that the 2026 Form II class's fee
 * status, marks sheet, and class results STILL show them, using the
 * shared utils/classRoster.js resolver.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../../src/server.js';
import { Class, Student, User, StudentPromotion, FeeStructure, Exam, Grade, Subject } from '../../src/models/index.js';
import { buildTenantFixture, authHeader, closeDb } from '../helpers/testFixture.js';
import { randomUUID } from 'crypto';

describe('Class roster (Fee Status / Marks Sheet / Class Results) reflects PAST enrollment', () => {
  let fixture;
  let form2_2026;
  let form3_2027;
  let student;
  let subject;
  let exam;

  before(async () => {
    fixture = await buildTenantFixture('rosterhist');
    const { tenant, campus } = fixture;
    await tenant.update({ settings: { academic_records_start_year: 2020 } });

    form2_2026 = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form II', grade: '2',
      education_level: 'o_level', academic_year: '2026', status: 'active',
    });
    form3_2027 = await Class.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Form III', grade: '3',
      education_level: 'o_level', academic_year: '2027', status: 'active',
    });

    const user = await User.create({
      tenant_id: tenant.id, email: `rosterpupil-${tenant.slug}@example.test`, password: 'Password123!',
      first_name: 'Roster', last_name: 'Pupil', role: 'student', status: 'active',
    });
    student = await Student.create({
      tenant_id: tenant.id, user_id: user.id, campus_id: campus.id,
      admission_number: `ADM-roster-${tenant.slug}`, class_id: form3_2027.id,
      admission_date: '2025-01-10', status: 'active',
    });

    // The real promotion record: they WERE in Form II (2026), then moved to Form III (2027).
    await StudentPromotion.create({
      tenant_id: tenant.id, student_id: student.id, batch_id: randomUUID(), action: 'promoted',
      from_class_id: form2_2026.id, to_class_id: form3_2027.id,
      from_academic_year: '2026-2027', to_academic_year: '2027-2028',
    });

    // Fee structure + subject/exam tied to the OLD class (2026).
    await FeeStructure.create({
      tenant_id: tenant.id, campus_id: campus.id, class_id: form2_2026.id,
      name: 'Tuition', amount: 100000, academic_year: '2026', status: 'active',
    });
    subject = await Subject.create({ tenant_id: tenant.id, name: 'Mathematics', code: `MATH-${tenant.slug}` });
    exam = await Exam.create({
      tenant_id: tenant.id, campus_id: campus.id, name: 'Mid Term', academic_year: '2026-2027',
      class_ids: [form2_2026.id], status: 'completed',
    });
    await Grade.create({
      tenant_id: tenant.id, exam_id: exam.id, student_id: student.id, subject_id: subject.id,
      marks_obtained: 78, max_marks: 100,
    });
  });

  after(closeDb);

  test('Fee Status for the 2026 Form II class still shows the student, even though they are now in Form III', async () => {
    const res = await request(app)
      .get('/api/v1/fees/class-status')
      .set(authHeader(fixture.token))
      .query({ class_id: form2_2026.id, academic_year: '2026' });

    assert.equal(res.status, 200);
    const row = res.body.data.students.find((s) => s.student_id === student.id);
    assert.ok(row, 'student missing from the 2026 class fee status — roster used current class_id instead of history');
    assert.equal(row.expected, 100000);
  });

  test('the exam Marks Sheet for the 2026 class still lists the student and their real mark', async () => {
    const res = await request(app)
      .get(`/api/v1/exams/${exam.id}/marks-sheet`)
      .set(authHeader(fixture.token))
      .query({ class_id: form2_2026.id, subject_id: subject.id });

    assert.equal(res.status, 200);
    const row = res.body.data.find((s) => s.student_id === student.id);
    assert.ok(row, 'student missing from the marks sheet for their OLD class');
    assert.equal(row.marks_obtained, 78);
  });

  test('Class Results for the 2026 class still lists the student with their score', async () => {
    const res = await request(app)
      .get(`/api/v1/exams/${exam.id}/class-results`)
      .set(authHeader(fixture.token))
      .query({ class_id: form2_2026.id });

    assert.equal(res.status, 200);
    const row = res.body.data.students.find((s) => s.student_id === student.id);
    assert.ok(row, 'student missing from class results for their OLD class');
    assert.equal(row.total_obtained, 78);
  });

  test('the CURRENT class (Form III, 2027) roster is unaffected — the student still shows up there too', async () => {
    const res = await request(app)
      .get('/api/v1/fees/class-status')
      .set(authHeader(fixture.token))
      .query({ class_id: form3_2027.id, academic_year: '2027' });

    assert.equal(res.status, 200);
    const row = res.body.data.students.find((s) => s.student_id === student.id);
    assert.ok(row, 'student missing from their CURRENT class roster');
  });
});
