import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { resolveHistoricalEnrollment } from '../../src/utils/studentHistory.js';

// The exact scenario from the bug report: a student currently in Form II
// (grade 2, o_level) for 2026, with no promotion history at all yet.
const form2In2026 = {
  current: { grade: '2', education_level: 'o_level', academic_year: '2026' },
  admissionBaseYear: 2025,
  promotionEvents: [],
};

describe('resolveHistoricalEnrollment — projection (no promotion history)', () => {
  test('the current year shows the current class, unchanged', () => {
    const r = resolveHistoricalEnrollment({ ...form2In2026, targetBaseYear: 2026 });
    assert.equal(r.visible, true);
    assert.equal(r.grade, '2');
    assert.equal(r.source, 'current');
  });

  test('one year back shows Form I, not Form II', () => {
    const r = resolveHistoricalEnrollment({ ...form2In2026, targetBaseYear: 2025 });
    assert.equal(r.visible, true);
    assert.equal(r.grade, '1');
    assert.equal(r.source, 'projected');
  });

  test('two years back — before admission — the student is not shown at all', () => {
    const r = resolveHistoricalEnrollment({ ...form2In2026, targetBaseYear: 2024 });
    assert.equal(r.visible, false);
    assert.equal(r.reason, 'not yet admitted');
  });

  test('a student finishing Form IV (O-Level) in 2025 disappears from 2026 onward — they graduated', () => {
    const studentZ = {
      current: { grade: '4', education_level: 'o_level', academic_year: '2025' },
      admissionBaseYear: 2022,
      promotionEvents: [],
    };
    const nextYear = resolveHistoricalEnrollment({ ...studentZ, targetBaseYear: 2026 });
    assert.equal(nextYear.visible, false);
    assert.equal(nextYear.reason, 'already graduated by this year');
  });

  test('the SAME student, one year earlier than their final year, correctly shows Form III', () => {
    const studentZ = {
      current: { grade: '4', education_level: 'o_level', academic_year: '2025' },
      admissionBaseYear: 2022,
      promotionEvents: [],
    };
    const prevYear = resolveHistoricalEnrollment({ ...studentZ, targetBaseYear: 2024 });
    assert.equal(prevYear.visible, true);
    assert.equal(prevYear.grade, '3');
    assert.equal(prevYear.source, 'projected');
  });

  test('without an admission date, a grade below 1 still hides the student', () => {
    const noAdmissionDate = {
      current: { grade: '1', education_level: 'primary', academic_year: '2026' },
      admissionBaseYear: null,
      promotionEvents: [],
    };
    const r = resolveHistoricalEnrollment({ ...noAdmissionDate, targetBaseYear: 2024 });
    assert.equal(r.visible, false);
    assert.equal(r.reason, 'not yet admitted');
  });
});

describe('resolveHistoricalEnrollment — real promotion history takes priority', () => {
  test('a REPEATED grade is reflected correctly, where projection alone would get it wrong', () => {
    // Repeated Form II: actually spent TWO years in Form II (2025 and
    // 2026), not one — projection (which assumes 1 grade/year) would
    // wrongly guess Form I for 2025. The real record must win.
    const repeatedStudent = {
      current: { grade: '2', education_level: 'o_level', academic_year: '2026' },
      admissionBaseYear: 2024,
      promotionEvents: [
        {
          action: 'retained', from_base_year: 2025, from_grade: '2', from_education_level: 'o_level',
          to_base_year: 2026, to_grade: '2', to_education_level: 'o_level',
        },
      ],
    };
    const r = resolveHistoricalEnrollment({ ...repeatedStudent, targetBaseYear: 2025 });
    assert.equal(r.visible, true);
    assert.equal(r.grade, '2'); // NOT '1' — projection would have been wrong here
    assert.equal(r.source, 'promotion');
  });

  test('a transfer event makes every later year correctly invisible, even if projection would allow it', () => {
    const transferredStudent = {
      current: { grade: '2', education_level: 'o_level', academic_year: '2025' },
      admissionBaseYear: 2024,
      promotionEvents: [
        {
          action: 'transferred', from_base_year: 2025, from_grade: '2', from_education_level: 'o_level',
          to_base_year: 2026, to_grade: null, to_education_level: null,
        },
      ],
    };
    const r = resolveHistoricalEnrollment({ ...transferredStudent, targetBaseYear: 2026 });
    assert.equal(r.visible, false);
    assert.equal(r.reason, 'left the school before this year');
  });

  test('a cross-level promotion (O-Level → A-Level) is resolved from the record, not guessed', () => {
    const student = {
      current: { grade: '5', education_level: 'a_level', academic_year: '2026' },
      admissionBaseYear: 2023,
      promotionEvents: [
        {
          action: 'promoted', from_base_year: 2025, from_grade: '4', from_education_level: 'o_level',
          to_base_year: 2026, to_grade: '5', to_education_level: 'a_level',
        },
      ],
    };
    const r = resolveHistoricalEnrollment({ ...student, targetBaseYear: 2025 });
    assert.equal(r.visible, true);
    assert.equal(r.grade, '4');
    assert.equal(r.education_level, 'o_level'); // NOT a_level — this is the year BEFORE the level change
    assert.equal(r.source, 'promotion');
  });
});

describe('resolveHistoricalEnrollment — edge cases', () => {
  test('no current class on record at all → not visible for any year', () => {
    const r = resolveHistoricalEnrollment({ current: null, targetBaseYear: 2025 });
    assert.equal(r.visible, false);
  });
});

describe('resolveHistoricalEnrollment — system start floor (a fresh school has no pre-launch history)', () => {
  test('projection math alone would allow an earlier year, but the system-start floor blocks it', () => {
    // Form III in 2026, no promotion history, no admission_date recorded.
    // Pure arithmetic would happily project Form II for 2025 — but this
    // school only started using the system in 2026, so 2025 must be
    // refused rather than guessed at.
    const r = resolveHistoricalEnrollment({
      current: { grade: '3', education_level: 'o_level', academic_year: '2026' },
      admissionBaseYear: null,
      promotionEvents: [],
      targetBaseYear: 2025,
      systemStartBaseYear: 2026,
    });
    assert.equal(r.visible, false);
    assert.equal(r.reason, 'before this school started using the system');
  });

  test('the exact scenario reported: admitted 2027 as Form III, system started 2026 — invisible for 2026', () => {
    // A student who transferred in mid-programme: their FIRST real class
    // row is already dated 2027, so there is truthfully nothing before
    // that to show — even though the system itself has existed since 2026.
    const r = resolveHistoricalEnrollment({
      current: { grade: '3', education_level: 'o_level', academic_year: '2027' },
      admissionBaseYear: 2027,
      promotionEvents: [],
      targetBaseYear: 2026,
      systemStartBaseYear: 2026,
    });
    assert.equal(r.visible, false);
    assert.equal(r.reason, 'not yet admitted');
  });

  test('the year the system started IS shown, and years at/after admission continue to work normally', () => {
    const params = {
      current: { grade: '2', education_level: 'o_level', academic_year: '2027' },
      admissionBaseYear: 2026,
      promotionEvents: [],
      systemStartBaseYear: 2026,
    };
    const startYear = resolveHistoricalEnrollment({ ...params, targetBaseYear: 2026 });
    assert.equal(startYear.visible, true);
    assert.equal(startYear.grade, '1');
    assert.equal(startYear.source, 'projected');
  });

  test('a real promotion record from before the floor is still honoured — it is data, not a guess', () => {
    const r = resolveHistoricalEnrollment({
      current: { grade: '2', education_level: 'o_level', academic_year: '2027' },
      admissionBaseYear: 2025,
      promotionEvents: [
        {
          action: 'promoted', from_base_year: 2025, from_grade: '1', from_education_level: 'o_level',
          to_base_year: 2026, to_grade: '2', to_education_level: 'o_level',
        },
      ],
      targetBaseYear: 2025,
      systemStartBaseYear: 2026, // floor is 2026, but a REAL record exists for 2025
    });
    assert.equal(r.visible, true);
    assert.equal(r.grade, '1');
    assert.equal(r.source, 'promotion');
  });
});
