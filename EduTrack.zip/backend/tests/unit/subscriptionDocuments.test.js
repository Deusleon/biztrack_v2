/**
 * The invoice/receipt engine and the reminder schedule — no database needed.
 *
 *  - the two copies of the document core (browser and server) must be byte-identical;
 *  - an invoice and a receipt draw, follow the school's decimals, and carry their QR codes;
 *  - the PAID watermark is drawn LAST, so it sits on top of the opaque cards;
 *  - which expiry reminder is due, and that none repeats.
 */
import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import QRCode from 'qrcode';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { buildDoc, drawSubscriptionDocument, documentFileName } from '../../src/documents/subscriptionDocumentCore.js';
import { dueReminder } from '../../src/jobs/subscriptionJobs.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const FRONTEND_COPY = path.resolve(here, '../../../frontend/src/utils/subscriptionDocumentCore.js');
const BACKEND_COPY = path.resolve(here, '../../src/documents/subscriptionDocumentCore.js');

describe('document core', () => {
  test('the browser copy and the server copy are identical', { skip: !fs.existsSync(FRONTEND_COPY) && 'frontend not checked out next to the backend' }, () => {
    assert.equal(fs.readFileSync(FRONTEND_COPY, 'utf8'), fs.readFileSync(BACKEND_COPY, 'utf8'),
      'subscriptionDocumentCore.js differs between frontend/src/utils and backend/src/documents — edit one and copy it over the other');
  });

  const invoice = (over = {}) => ({
    id: 'i1', invoice_number: 'INV-2026-00004', order_reference: 'EDU1', billing_cycle: 'termly', currency: 'TZS',
    plan: { name: 'Standard' }, line_items: [{ label: 'Standard plan — termly', amount: 320000 }],
    subtotal: 320000, proration_credit: 0, total: 320000, status: 'pending',
    createdAt: '2026-10-27T10:00:00Z', period_start: '2026-10-27T10:00:00Z', period_end: '2027-02-24T10:00:00Z',
    gateway: 'clickpesa', payer_phone: '255712345678', gateway_payment_id: 'CP-1', paid_at: '2026-10-27T11:00:00Z', ...over,
  });
  const env = (decimals = 0) => ({
    formatDate: (d) => String(d).slice(0, 10), formatNumber: (n) => Number(n).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals }),
    seller: { name: 'EduTrack', lines: ['support@edutrack.test'] }, origin: 'https://app.test',
  });
  const pdfText = async (doc) => {
    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4', compress: false });
    const qr = doc.qr ? await QRCode.toDataURL(doc.qr.url, { margin: 0, width: 120 }) : null;
    drawSubscriptionDocument(pdf, autoTable, doc, { emblem: null, qr, contact: 'x' });
    return pdf.output();
  };
  const school = { name: 'Test School', address: 'Dar es Salaam', phone: '', email: '' };

  test('an unpaid invoice offers scan-to-pay; a paid one and its receipt offer verification', () => {
    const unpaid = buildDoc('invoice', { invoice: invoice(), school, pay_code: 'PAYCODE123456789' }, env());
    assert.equal(unpaid.qr.kind, 'pay');
    assert.equal(unpaid.qr.url, 'https://app.test/pay/INV-2026-00004/PAYCODE123456789');

    const paid = invoice({ status: 'paid' });
    const receipt = buildDoc('receipt', { invoice: paid, school, receipt_number: 'RCT-2026-00004', verification_code: 'ABCDE12345' }, env());
    assert.equal(receipt.qr.kind, 'verify');
    assert.equal(receipt.qr.url, 'https://app.test/verify-subscription-receipt/INV-2026-00004/ABCDE12345');
    assert.equal(buildDoc('invoice', { invoice: paid, school, receipt_number: 'RCT-2026-00004', verification_code: 'ABCDE12345' }, env()).qr.kind, 'verify');

    // no code, no QR (a cancelled invoice must not advertise a way to pay)
    assert.equal(buildDoc('invoice', { invoice: invoice({ status: 'cancelled' }), school, pay_code: 'X' }, env()).qr, null);
    assert.equal(buildDoc('invoice', { invoice: invoice(), school }, env()).qr, null);
  });

  test('amounts follow the school\'s Money Decimals', async () => {
    const d0 = await pdfText(buildDoc('invoice', { invoice: invoice(), school, pay_code: 'P' }, env(0)));
    const d2 = await pdfText(buildDoc('invoice', { invoice: invoice(), school, pay_code: 'P' }, env(2)));
    assert.match(d0, /TZS 320,000\)/);
    assert.doesNotMatch(d0, /320,000\.00/);
    assert.match(d2, /TZS 320,000\.00\)/);
  });

  test('the PAID watermark is drawn after everything else, so it sits on top of the cards', async () => {
    const paid = invoice({ status: 'paid' });
    const text = await pdfText(buildDoc('receipt', { invoice: paid, school, receipt_number: 'RCT-2026-00004', verification_code: 'ABCDE12345' }, env()));
    const amountCard = text.indexOf('(AMOUNT RECEIVED)');
    const watermark = text.lastIndexOf('(PAID)');
    assert.ok(amountCard > 0 && watermark > amountCard, 'the watermark must come after the AMOUNT RECEIVED card in the page content');
    assert.ok(watermark > text.indexOf('(VERIFY THIS RECEIPT)'));
  });

  test('file names pair the invoice and its receipt', () => {
    assert.equal(documentFileName(buildDoc('invoice', { invoice: invoice() }, env())), 'Invoice_INV-2026-00004.pdf');
    assert.equal(documentFileName(buildDoc('receipt', { invoice: invoice({ status: 'paid' }), receipt_number: 'RCT-2026-00004' }, env())), 'Receipt_RCT-2026-00004.pdf');
  });
});

describe('expiry reminders', () => {
  const sub = (over = {}) => ({ ends_at: new Date(Date.now() + 10 * 86400000), reminders_sent: {}, ...over });
  const ev = (over = {}) => ({ status: 'active', daysLeft: 10, inGrace: false, locked: false, ...over });

  test('nothing is due more than 7 days out', () => assert.equal(dueReminder(sub(), ev({ daysLeft: 10 })), null));
  test('7 days, 3 days, the day it ends, and locked are each due in turn', () => {
    assert.equal(dueReminder(sub(), ev({ daysLeft: 7 })).kind, 'd7');
    assert.equal(dueReminder(sub(), ev({ daysLeft: 4 })).kind, 'd7');
    assert.equal(dueReminder(sub(), ev({ daysLeft: 3 })).kind, 'd3');
    assert.equal(dueReminder(sub(), ev({ status: 'grace', daysLeft: 0, inGrace: true })).kind, 'd0');
    assert.equal(dueReminder(sub(), ev({ status: 'expired', daysLeft: 0, locked: true })).kind, 'locked');
  });
  test('a reminder already sent for this paid window is never sent again', () => {
    const s = sub();
    const window = new Date(s.ends_at).toISOString();
    assert.equal(dueReminder({ ...s, reminders_sent: { window, d3: 'x' } }, ev({ daysLeft: 3 })), null);
  });
  test('after a renewal (a new window) the reminders start again', () => {
    const s = sub();
    assert.equal(dueReminder({ ...s, reminders_sent: { window: '2020-01-01T00:00:00.000Z', d3: 'x' } }, ev({ daysLeft: 3 })).kind, 'd3');
  });
  test('a failed send waits a day before it is tried again', () => {
    const s = sub();
    const window = new Date(s.ends_at).toISOString();
    assert.equal(dueReminder({ ...s, reminders_sent: { window, d3_failed_at: new Date().toISOString() } }, ev({ daysLeft: 3 })), null);
    assert.equal(dueReminder({ ...s, reminders_sent: { window, d3_failed_at: new Date(Date.now() - 2 * 86400000).toISOString() } }, ev({ daysLeft: 3 })).kind, 'd3');
  });
  test('cancelled subscriptions and ones without an end date get nothing', () => {
    assert.equal(dueReminder(sub(), ev({ status: 'cancelled' })), null);
    assert.equal(dueReminder({ ends_at: null, reminders_sent: {} }, ev({ daysLeft: 3 })), null);
  });
});
