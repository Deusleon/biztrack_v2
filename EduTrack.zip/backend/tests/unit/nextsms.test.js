// NextSMS integration — request/response handling.
//
// No network and no database: `fetch` is replaced with a scripted fake, so
// these check exactly what EduTrack SENDS to NextSMS and how it reads what
// comes BACK. They cannot prove NextSMS's live API still looks like this —
// that is what Settings → Messages → Test Connection is for.
//
//   npm test            (or)   node --test tests/unit/nextsms.test.js
import { test, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import {
  sendSmsViaGateway, sendManyViaNextSms, getNextSmsBalance, testNextSmsConnection,
  getNextSmsDeliveryReport, nextSmsStatusGroup, normalizeTzPhone,
} from '../../src/services/smsService.js';

const SETTINGS = { provider: 'nextsms', is_active: true, api_key: 'school', api_secret: 's3cret', sender_id: 'EDUTRACK' };

let calls;
const realFetch = globalThis.fetch;
/** Queue the responses fetch should return, in order: [status, body] pairs. */
const script = (...responses) => {
  calls = [];
  globalThis.fetch = async (url, opts) => {
    calls.push({ url, opts, body: opts?.body ? JSON.parse(opts.body) : undefined });
    const [status, body] = responses.shift() || [500, { message: 'unscripted call' }];
    return { ok: status >= 200 && status < 300, status, text: async () => (typeof body === 'string' ? body : JSON.stringify(body)) };
  };
};
beforeEach(() => { calls = []; });
afterEach(() => { globalThis.fetch = realFetch; });

const accepted = (to, id, extra = {}) => ({ to, messageId: id, smsCount: 1, status: { groupName: 'PENDING', name: 'PENDING_ENROUTE', description: 'Message sent' }, ...extra });

test('phone numbers are normalised to 255XXXXXXXXX', () => {
  assert.equal(normalizeTzPhone('0712 345 678'), '255712345678');
  assert.equal(normalizeTzPhone('+255712345678'), '255712345678');
});

test('status vocabulary collapses to delivered / failed / pending', () => {
  assert.equal(nextSmsStatusGroup({ groupName: 'DELIVERED', name: 'DELIVERED_TO_HANDSET' }), 'delivered');
  assert.equal(nextSmsStatusGroup({ groupName: 'PENDING', name: 'PENDING_ENROUTE' }), 'pending');
  for (const g of ['UNDELIVERABLE', 'EXPIRED', 'REJECTED']) assert.equal(nextSmsStatusGroup({ groupName: g }), 'failed');
  assert.equal(nextSmsStatusGroup('DELIVERED'), 'delivered');
  assert.equal(nextSmsStatusGroup(undefined), 'pending');
});

test('one recipient: Basic auth, single `to`, configured sender, message id returned', async () => {
  script([200, { messages: [accepted('255712345678', 'm-1')] }]);
  const r = await sendSmsViaGateway(SETTINGS, { to: '0712345678', message: 'Habari' });

  assert.equal(r.success, true);
  assert.equal(r.messageId, 'm-1');
  assert.equal(r.provider, 'nextsms');
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, 'https://messaging-service.co.tz/api/sms/v1/text/single');
  assert.equal(calls[0].opts.method, 'POST');
  assert.equal(calls[0].opts.headers.Authorization, `Basic ${Buffer.from('school:s3cret').toString('base64')}`);
  assert.deepEqual(calls[0].body, { from: 'EDUTRACK', to: '255712345678', text: 'Habari' });
});

test('no sender id configured falls back to the NextSMS default sender', async () => {
  script([200, { messages: [accepted('255712345678', 'm-1')] }]);
  await sendManyViaNextSms({ ...SETTINGS, sender_id: '' }, { recipients: ['0712345678'], message: 'x' });
  assert.equal(calls[0].body.from, 'NEXTSMS');
});

test('many recipients go in ONE call and each keeps its own message id', async () => {
  script([200, { messages: [accepted('255711111111', 'a'), accepted('255722222222', 'b'), accepted('255733333333', 'c')] }]);
  const { results } = await sendManyViaNextSms(SETTINGS, { recipients: ['0711111111', '0722222222', '0733333333'], message: 'Hello' });

  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0].body.to, ['255711111111', '255722222222', '255733333333']);
  assert.deepEqual(results.map((r) => [r.to, r.status, r.messageId]), [
    ['255711111111', 'pending', 'a'], ['255722222222', 'pending', 'b'], ['255733333333', 'pending', 'c'],
  ]);
});

test('one refused number fails only that recipient, with the provider reason', async () => {
  script([200, { messages: [
    accepted('255711111111', 'a'),
    { to: '255722222222', messageId: 'b', status: { groupName: 'REJECTED', name: 'REJECTED_NOT_ENOUGH_CREDITS', description: 'Invalid destination' } },
  ] }]);
  const { results } = await sendManyViaNextSms(SETTINGS, { recipients: ['0711111111', '0722222222'], message: 'x' });
  assert.equal(results[0].status, 'pending');
  assert.equal(results[1].status, 'failed');
  assert.equal(results[1].error, 'Invalid destination');
});

test('a number missing from the response is NOT reported as sent', async () => {
  script([200, { messages: [accepted('255711111111', 'a')] }]);
  const { results } = await sendManyViaNextSms(SETTINGS, { recipients: ['0711111111', '0722222222'], message: 'x' });
  assert.equal(results[1].status, 'failed');
  assert.match(results[1].error, /no result/i);
});

test('duplicate numbers are sent once', async () => {
  script([200, { messages: [accepted('255711111111', 'a')] }]);
  const { results } = await sendManyViaNextSms(SETTINGS, { recipients: ['0711111111', '+255711111111'], message: 'x' });
  assert.equal(results.length, 1);
  assert.equal(calls[0].body.to, '255711111111');
});

test('more than 100 recipients are split into several calls', async () => {
  const numbers = Array.from({ length: 230 }, (_, i) => `255700${String(100000 + i)}`);
  script(
    [200, { messages: numbers.slice(0, 100).map((n, i) => accepted(n, `m${i}`)) }],
    [200, { messages: numbers.slice(100, 200).map((n, i) => accepted(n, `m${100 + i}`)) }],
    [200, { messages: numbers.slice(200).map((n, i) => accepted(n, `m${200 + i}`)) }],
  );
  const { results } = await sendManyViaNextSms(SETTINGS, { recipients: numbers, message: 'x' });
  assert.equal(calls.length, 3);
  assert.deepEqual(calls.map((c) => c.body.to.length), [100, 100, 30]);
  assert.equal(results.length, 230);
  assert.ok(results.every((r) => r.status === 'pending'));
});

test('a failing call fails only the recipients in that call', async () => {
  const numbers = Array.from({ length: 150 }, (_, i) => `255700${String(100000 + i)}`);
  script([503, { message: 'temporarily unavailable' }], [200, { messages: numbers.slice(100).map((n, i) => accepted(n, `m${i}`)) }]);
  const { results } = await sendManyViaNextSms(SETTINGS, { recipients: numbers, message: 'x' });
  assert.equal(results.slice(0, 100).every((r) => r.status === 'failed'), true);
  assert.equal(results.slice(100).every((r) => r.status === 'pending'), true);
});

test('wrong credentials: 401 becomes an actionable message, single send throws', async () => {
  script([401, { message: 'Unauthorized' }]);
  await assert.rejects(sendSmsViaGateway(SETTINGS, { to: '0712345678', message: 'x' }), /username or password/i);
});

test('insufficient balance is reported as such', async () => {
  script([400, { message: 'Insufficient balance' }]);
  const { results } = await sendManyViaNextSms(SETTINGS, { recipients: ['0712345678'], message: 'x' });
  assert.equal(results[0].status, 'failed');
  assert.match(results[0].error, /insufficient SMS balance/i);
});

test('missing username or password is caught before any request is made', async () => {
  script();
  await assert.rejects(sendSmsViaGateway({ ...SETTINGS, api_secret: '' }, { to: '0712345678', message: 'x' }), /username and password/i);
  assert.equal(calls.length, 0);
});

test('balance is read from sms_balance (and tolerated under other names)', async () => {
  script([200, { sms_balance: 1250 }]);
  assert.equal(await getNextSmsBalance(SETTINGS), 1250);
  assert.equal(calls[0].url, 'https://messaging-service.co.tz/api/sms/v1/balance');
  assert.equal(calls[0].opts.method, 'GET');

  script([200, { balance: '40' }]);
  assert.equal(await getNextSmsBalance(SETTINGS), 40);
});

test('an unrecognised balance body gives null, not a made-up number', async () => {
  script([200, { something: 'else' }]);
  assert.equal(await getNextSmsBalance(SETTINGS), null);
});

test('test connection: success returns the balance, bad credentials are an error', async () => {
  script([200, { sms_balance: 77 }]);
  const ok = await testNextSmsConnection(SETTINGS);
  assert.deepEqual([ok.success, ok.provider, ok.balance], [true, 'nextsms', 77]);

  script([401, {}]);
  await assert.rejects(testNextSmsConnection(SETTINGS), /username or password/i);
});

test('delivery report: delivered, failed with reason, still pending', async () => {
  script([200, { results: [{ messageId: 'a', status: { groupName: 'DELIVERED', name: 'DELIVERED_TO_HANDSET' }, doneAt: '2026-10-01T10:00:00Z' }] }]);
  const ok = await getNextSmsDeliveryReport(SETTINGS, 'a');
  assert.deepEqual([ok.status, ok.detail, ok.doneAt, ok.via], ['delivered', 'DELIVERED_TO_HANDSET', '2026-10-01T10:00:00Z', '/api/sms/v1/reports']);
  assert.match(calls[0].url, /\/api\/sms\/v1\/reports\?messageId=a$/);

  script([200, { results: [{ messageId: 'b', status: { groupName: 'UNDELIVERABLE', description: 'Number not reachable' } }] }]);
  const failed = await getNextSmsDeliveryReport(SETTINGS, 'b');
  assert.equal(failed.status, 'failed');
  assert.equal(failed.error, 'Number not reachable');

  script([200, { results: [{ messageId: 'c', status: { groupName: 'PENDING' } }] }]);
  assert.equal((await getNextSmsDeliveryReport(SETTINGS, 'c')).status, 'pending');
});

test('delivery report: only the entry for THIS message id is used', async () => {
  script([200, { results: [{ messageId: 'other', status: { groupName: 'DELIVERED' } }, { messageId: 'mine', status: { groupName: 'PENDING' } }] }]);
  assert.equal((await getNextSmsDeliveryReport(SETTINGS, 'mine')).status, 'pending');
});

test('delivery report: when /reports has nothing, the sent-message log answers', async () => {
  script([200, { results: [] }], [200, { results: [{ messageId: 'a', status: { groupName: 'DELIVERED' } }] }]);
  const r = await getNextSmsDeliveryReport(SETTINGS, 'a');
  assert.equal(r.status, 'delivered');
  assert.equal(r.via, '/api/sms/v1/logs');
  assert.equal(calls.length, 2);
});

test('delivery report: when /reports refuses, the sent-message log is tried', async () => {
  script([404, { message: 'Not found' }], [200, { results: [{ messageId: 'a', status: { groupName: 'DELIVERED' } }] }]);
  assert.equal((await getNextSmsDeliveryReport(SETTINGS, 'a')).via, '/api/sms/v1/logs');
});

test('delivery report: nothing anywhere is null (not yet reported), not an error', async () => {
  script([200, { results: [] }], [200, { results: [] }]);
  assert.equal(await getNextSmsDeliveryReport(SETTINGS, 'd'), null);
});

test('delivery report: both endpoints failing is an error naming each one', async () => {
  script([404, { message: 'Not found' }], [500, { message: 'boom' }]);
  await assert.rejects(getNextSmsDeliveryReport(SETTINGS, 'a'), (err) => /reports: Not found/.test(err.message) && /logs: boom/.test(err.message));
});
