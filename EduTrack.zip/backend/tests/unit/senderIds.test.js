/**
 * Two senders per gateway — the school's own and the system's — for SMS and email.
 *
 *   user    messages people send from Messages, and automatic notices like admissions
 *   system  password-reset codes and subscription messages
 *
 * Until a system sender is set, system messages use the school's own sender, so nothing
 * changes for a school that has not configured one.
 */
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { settingsForPurpose } from '../../src/services/smsService.js';
import { sendEmail, gatewayFromAddress } from '../../src/services/emailService.js';
import { planGatewayUpdate, summarizeVault } from '../../src/utils/smsCredentialVault.js';
import { startFakeSmtp } from '../helpers/fakeSmtp.js';

const here = path.dirname(fileURLToPath(import.meta.url));

describe('SMS sender by purpose', () => {
  const gateway = { provider: 'meseji', is_active: true, api_key: 'k', sender_id: 'MYSCHOOL', system_sender_id: 'EDUTRACK' };

  test('ordinary messages (the default) use the school sender', () => {
    assert.equal(settingsForPurpose(gateway).sender_id, 'MYSCHOOL');
    assert.equal(settingsForPurpose(gateway, 'user').sender_id, 'MYSCHOOL');
  });
  test('system messages use the system sender', () => {
    assert.equal(settingsForPurpose(gateway, 'system').sender_id, 'EDUTRACK');
  });
  test('with no system sender configured, system messages fall back to the school sender', () => {
    assert.equal(settingsForPurpose({ ...gateway, system_sender_id: null }, 'system').sender_id, 'MYSCHOOL');
    assert.equal(settingsForPurpose({ ...gateway, system_sender_id: '' }, 'system').sender_id, 'MYSCHOOL');
  });
  test('it never changes the settings it is given, and works on a database row', () => {
    const row = { ...gateway, get: () => ({ ...gateway }) };
    const out = settingsForPurpose(row, 'system');
    assert.equal(out.sender_id, 'EDUTRACK');
    assert.equal(row.sender_id, 'MYSCHOOL');
    assert.equal(settingsForPurpose(null, 'system'), null);
  });
});

describe('credential vault remembers both senders per provider', () => {
  test('switching provider keeps each provider\'s own two senders', () => {
    const row = { provider: 'meseji', api_key: 'm', api_secret: null, sender_id: 'MESEJI-A', system_sender_id: 'MESEJI-SYS', saved_credentials: {} };
    // switch to NextSMS and type a fresh set
    const toNext = planGatewayUpdate(row, { provider: 'nextsms', api_key: 'u', api_secret: 'p', sender_id: 'NEXT-A', system_sender_id: 'NEXT-SYS' });
    assert.equal(toNext.live.system_sender_id, 'NEXT-SYS');
    assert.equal(toNext.vault.meseji.system_sender_id, 'MESEJI-SYS', 'the old provider\'s system sender is parked, not lost');
    // and back again
    const back = planGatewayUpdate({ ...row, provider: 'nextsms', api_key: 'u', api_secret: 'p', sender_id: 'NEXT-A', system_sender_id: 'NEXT-SYS', saved_credentials: toNext.vault }, { provider: 'meseji' });
    assert.equal(back.live.sender_id, 'MESEJI-A');
    assert.equal(back.live.system_sender_id, 'MESEJI-SYS');
    assert.equal(summarizeVault(back.vault).nextsms.system_sender_id, 'NEXT-SYS');
  });
  test('a provider switched to for the first time starts with no system sender', () => {
    const row = { provider: 'meseji', api_key: 'm', sender_id: 'A', system_sender_id: 'SYS', saved_credentials: {} };
    assert.equal(planGatewayUpdate(row, { provider: 'beem_africa' }).live.system_sender_id, null);
  });
});

describe('email From address by purpose', () => {
  const gw = { smtp_username: 'mailer@school.test', from_email: 'news@school.test', from_name: 'My School', system_from_email: 'no-reply@edutrack.test', system_from_name: 'EduTrack' };
  test('ordinary mail comes from the school', () => assert.equal(gatewayFromAddress(gw), '"My School" <news@school.test>'));
  test('system mail comes from the system sender', () => assert.equal(gatewayFromAddress(gw, null, 'system'), '"EduTrack" <no-reply@edutrack.test>'));
  test('each part of the system sender falls back on its own', () => {
    assert.equal(gatewayFromAddress({ ...gw, system_from_name: '' }, null, 'system'), '"My School" <no-reply@edutrack.test>');
    assert.equal(gatewayFromAddress({ ...gw, system_from_email: '' }, null, 'system'), '"EduTrack" <news@school.test>');
    assert.equal(gatewayFromAddress({ ...gw, system_from_email: '', system_from_name: '' }, null, 'system'), '"My School" <news@school.test>');
  });
  test('with nothing configured the fallback is used', () => assert.equal(gatewayFromAddress({}, 'fallback@x.test', 'system'), 'fallback@x.test'));
});

describe('what really goes out through a mail server', () => {
  let smtp;
  before(async () => { smtp = await startFakeSmtp({ user: 'mailer', pass: 'right-pass' }); });
  after(() => smtp.close());

  const gateway = () => ({
    is_active: true, smtp_host: '127.0.0.1', smtp_port: smtp.port, smtp_secure: false, smtp_username: 'mailer', smtp_password: 'right-pass',
    from_email: 'news@school.test', from_name: 'My School', system_from_email: 'no-reply@edutrack.test', system_from_name: 'EduTrack',
  });
  const fromHeader = (m) => (m.data.match(/^From: (.*)$/m) || [])[1];

  test('a message people send goes out as the school; a reset code as the system', async () => {
    const before = smtp.messages.length;
    assert.equal((await sendEmail({ to: 'a@b.test', subject: 'Fees', text: 'x' }, gateway())).success, true);
    assert.equal((await sendEmail({ to: 'a@b.test', subject: 'Reset code', text: 'x', purpose: 'system' }, gateway())).success, true);
    const [ordinary, system] = smtp.messages.slice(before);
    assert.match(fromHeader(ordinary), /My School.*news@school\.test/);
    assert.match(fromHeader(system), /EduTrack.*no-reply@edutrack\.test/);
  });
});

describe('the right messages are marked as system', () => {
  const src = (rel) => fs.readFileSync(path.resolve(here, '../../src', rel), 'utf8');
  test('password reset sends both its email and its SMS as system', () => {
    const s = src('services/passwordResetService.js');
    assert.equal((s.match(/purpose: 'system'/g) || []).length, 2);
  });
  test('subscription emails are system emails', () => {
    assert.match(src('services/subscriptionNotifier.js'), /purpose: 'system'/);
  });
  test('nothing else (admissions, payments, messages…) is marked system', () => {
    for (const rel of ['controllers/messageController.js', 'services/notificationService.js', 'controllers/admissionInquiryController.js', 'controllers/contactInquiryController.js']) {
      assert.doesNotMatch(src(rel), /purpose: 'system'/, `${rel} must use the school's own sender`);
    }
  });
});
