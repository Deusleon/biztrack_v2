/**
 * reportCardCalc.test.js
 *
 * The term report card: Test = average of the term's non-Final exams, Exam =
 * the Final, Average = the two averaged. No database needed.
 */
import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { splitTermExams, subjectRowsFor, overallOf, isFinalExam } from '../../src/utils/reportCardCalc.js';

const grade = (p) => (p >= 75 ? 'A' : p >= 65 ? 'B' : p >= 45 ? 'C' : p >= 30 ? 'D' : 'F');
const G = (exam_id, subject_id, name, got, max) => ({ exam_id, subject_id, subject: { name }, marks_obtained: got, max_marks: max });

const exams = [
  { id: 'mid', exam_type: 'Midterm', start_date: '2026-03-01' },
  { id: 'quiz', exam_type: 'Quiz', start_date: '2026-02-01' },
  { id: 'ca', exam_type: 'Continuous Assessment', start_date: '2026-04-01' },
  { id: 'fin-old', exam_type: 'Final', start_date: '2026-05-01' },
  { id: 'fin', exam_type: ' final ', start_date: '2026-06-01' },
];

describe('term report card maths', () => {
  const { tests, finalExam } = splitTermExams(exams);
  const opts = { testIds: new Set(tests.map((t) => t.id)), finalId: finalExam.id, gradeFn: grade };

  test('every non-Final exam is a test; the latest Final is the exam', () => {
    assert.deepEqual(tests.map((t) => t.id), ['mid', 'quiz', 'ca']);
    assert.equal(finalExam.id, 'fin');
    assert.equal(isFinalExam({ exam_type: 'FINAL' }), true);
    assert.equal(isFinalExam({ exam_type: 'Mock' }), false);
  });

  test('Test averages percentages, so a quiz out of 10 counts like a test out of 100', () => {
    const [maths] = subjectRowsFor([G('mid', 's1', 'Maths', 60, 100), G('quiz', 's1', 'Maths', 9, 10), G('ca', 's1', 'Maths', 80, 100), G('fin', 's1', 'Maths', 50, 100)], opts);
    assert.equal(maths.test_average, 76.67);
    assert.equal(maths.test_count, 3);
    assert.equal(maths.exam_percentage, 50);
    assert.equal(maths.average, 63.33);
    assert.equal(maths.grade, 'C');
  });

  test('a final not marked out of 100 keeps its raw marks and is compared as a percentage', () => {
    const [physics] = subjectRowsFor([G('fin', 's3', 'Physics', 90, 120)], opts);
    assert.equal(physics.exam_score, 90);
    assert.equal(physics.exam_max, 120);
    assert.equal(physics.exam_percentage, 75);
  });

  test('only tests, or only the final, averages the one that exists — never counts the other as 0', () => {
    const rows = subjectRowsFor([G('mid', 's2', 'English', 70, 100), G('quiz', 's2', 'English', 5, 10), G('fin', 's3', 'Physics', 90, 120)], opts);
    const english = rows.find((r) => r.subject === 'English');
    const physics = rows.find((r) => r.subject === 'Physics');
    assert.equal(english.average, 60);
    assert.equal(english.exam_percentage, null);
    assert.equal(physics.test_average, null);
    assert.equal(physics.average, 75);
  });

  test('an older Final and unentered marks are ignored', () => {
    const rows = subjectRowsFor([G('fin-old', 's4', 'History', 99, 100), G('mid', 's5', 'Biology', null, 100)], opts);
    assert.equal(rows.length, 0);
  });

  test('overall = sum and mean of the subject averages', () => {
    const rows = subjectRowsFor([
      G('mid', 's1', 'Maths', 60, 100), G('quiz', 's1', 'Maths', 9, 10), G('ca', 's1', 'Maths', 80, 100), G('fin', 's1', 'Maths', 50, 100),
      G('mid', 's2', 'English', 70, 100), G('quiz', 's2', 'English', 5, 10),
      G('fin', 's3', 'Physics', 90, 120),
    ], opts);
    const o = overallOf(rows);
    assert.equal(o.total, 198.33);
    assert.equal(o.total_max, 300);
    assert.ok(Math.abs(o.average - 66.1111) < 0.001);
    assert.deepEqual(overallOf([]), { total: null, total_max: null, average: null });
  });
});
