// Signed delivery-report webhook URLs — no network, no database.
import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { webhookSignature, isValidWebhookSignature } from '../../src/utils/webhookSignature.js';

beforeEach(() => { delete process.env.WEBHOOK_SECRET; process.env.JWT_SECRET = 'test-secret'; });

test('a school\'s signature is stable and accepted', () => {
  const sig = webhookSignature('tenant-1');
  assert.equal(sig, webhookSignature('tenant-1'));
  assert.equal(sig.length, 32);
  assert.equal(isValidWebhookSignature('tenant-1', sig), true);
});

test('a signature is only valid for its own school', () => {
  assert.equal(isValidWebhookSignature('tenant-2', webhookSignature('tenant-1')), false);
});

test('guessed, empty or malformed signatures are rejected', () => {
  for (const bad of ['', undefined, null, 'abc', 'x'.repeat(32), webhookSignature('tenant-1') + 'x']) {
    assert.equal(isValidWebhookSignature('tenant-1', bad), false);
  }
});

test('changing the server secret invalidates existing URLs; WEBHOOK_SECRET takes precedence', () => {
  const before = webhookSignature('tenant-1');
  process.env.JWT_SECRET = 'another-secret';
  assert.equal(isValidWebhookSignature('tenant-1', before), false);
  process.env.WEBHOOK_SECRET = 'dedicated';
  assert.notEqual(webhookSignature('tenant-1'), before);
});

test('with no secret configured nothing validates (and nothing throws)', () => {
  delete process.env.JWT_SECRET;
  assert.equal(isValidWebhookSignature('tenant-1', 'whatever'), false);
});
