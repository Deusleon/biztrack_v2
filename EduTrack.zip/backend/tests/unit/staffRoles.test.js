// Who may give a staff member which role — no database.
import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { STAFF_ROLES, roleAssignmentError } from '../../src/utils/staffRoles.js';

const actor = (role, id = 'actor-1') => ({ id, role });

describe('staff roles', () => {
  test('support_staff is not offered — it is not a role the system has', () => {
    assert.ok(!STAFF_ROLES.includes('support_staff'));
    assert.ok(['teacher', 'accountant', 'librarian', 'hr', 'transport_manager', 'hostel_warden', 'admin', 'principal'].every((r) => STAFF_ROLES.includes(r)));
  });

  test('a role is required and must be a real staff role', () => {
    assert.equal(roleAssignmentError({ canManageStaff: true, actor: actor('admin'), newRole: '' }).status, 400);
    assert.equal(roleAssignmentError({ canManageStaff: true, actor: actor('admin'), newRole: undefined }).status, 400);
    assert.match(roleAssignmentError({ canManageStaff: true, actor: actor('admin'), newRole: 'support_staff' }).message, /not a staff role/);
    assert.equal(roleAssignmentError({ canManageStaff: true, actor: actor('admin'), newRole: 'super_admin' }).status, 400);
    assert.equal(roleAssignmentError({ canManageStaff: true, actor: actor('admin'), newRole: 'student' }).status, 400);
  });

  test('an administrator can assign any staff role', () => {
    for (const role of STAFF_ROLES) assert.equal(roleAssignmentError({ canManageStaff: true, actor: actor('admin'), newRole: role }), null, role);
    assert.equal(roleAssignmentError({ canManageStaff: true, actor: actor('super_admin'), currentRole: 'teacher', newRole: 'admin', targetUserId: 'u2' }), null);
  });

  test('saving without changing the role is always fine — even for someone who can\'t manage roles', () => {
    assert.equal(roleAssignmentError({ actor: actor('teacher'), currentRole: 'accountant', newRole: 'accountant', targetUserId: 'u2' }), null);
    assert.equal(roleAssignmentError({ actor: actor('admin', 'u2'), currentRole: 'admin', newRole: 'admin', targetUserId: 'u2' }), null, 'editing yourself, role untouched');
    assert.equal(roleAssignmentError({ actor: actor('teacher'), currentRole: 'super_admin', newRole: 'super_admin', targetUserId: 'u9' }), null);
  });

  test('principal and HR can manage everyday roles but not hand out Admin/Principal', () => {
    for (const who of ['principal', 'hr']) {
      assert.equal(roleAssignmentError({ canManageStaff: true, actor: actor(who), currentRole: 'teacher', newRole: 'accountant', targetUserId: 'u2' }), null, who);
      assert.equal(roleAssignmentError({ canManageStaff: true, actor: actor(who), currentRole: 'teacher', newRole: 'admin', targetUserId: 'u2' }).status, 403, who);
      assert.equal(roleAssignmentError({ canManageStaff: true, actor: actor(who), currentRole: 'principal', newRole: 'teacher', targetUserId: 'u2' }).status, 403, `${who} demoting a principal`);
      assert.equal(roleAssignmentError({ canManageStaff: true, actor: actor(who), newRole: 'admin' }).status, 403, `${who} creating an admin`);
    }
  });

  test('anyone WITHOUT the staff.update permission cannot assign roles at all (whatever their role)', () => {
    for (const who of ['teacher', 'accountant', 'librarian', 'parent', 'student', undefined]) {
      assert.equal(roleAssignmentError({ actor: actor(who), currentRole: 'teacher', newRole: 'accountant', targetUserId: 'u2' })?.status, 403, String(who));
      assert.equal(roleAssignmentError({ actor: actor(who), newRole: 'teacher' })?.status, 403, `${who} creating`);
    }
  });

  test('nobody changes their own role, and a super admin\'s role is fixed', () => {
    assert.match(roleAssignmentError({ actor: actor('admin', 'me'), currentRole: 'admin', newRole: 'teacher', targetUserId: 'me' }).message, /own role/);
    assert.match(roleAssignmentError({ canManageStaff: true, actor: actor('super_admin'), currentRole: 'super_admin', newRole: 'admin', targetUserId: 'u2' }).message, /super admin/);
  });
});
