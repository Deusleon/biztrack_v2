import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import {
  usesYearSpan,
  formatAcademicYear,
  extractBaseYear,
  resolveAcademicYearForLevel,
  academicYearBaseMatch,
  academicYearDateRange,
} from '../../src/utils/academicYear.js';

describe('usesYearSpan', () => {
  test('only a_level uses a two-year span', () => {
    assert.equal(usesYearSpan('a_level'), true);
    assert.equal(usesYearSpan('o_level'), false);
    assert.equal(usesYearSpan('primary'), false);
  });
});

describe('formatAcademicYear', () => {
  test('formats a_level as a span', () => {
    assert.equal(formatAcademicYear(2026, 'a_level'), '2026-2027');
  });
  test('formats primary and o_level as a single year', () => {
    assert.equal(formatAcademicYear(2026, 'primary'), '2026');
    assert.equal(formatAcademicYear(2026, 'o_level'), '2026');
  });
  test('returns empty string for an unparsable year', () => {
    assert.equal(formatAcademicYear('not-a-year', 'o_level'), '');
  });
});

describe('extractBaseYear — the core of the whole fix', () => {
  test('reads the leading year out of a span', () => {
    assert.equal(extractBaseYear('2026-2027'), 2026);
  });
  test('reads a single year as-is', () => {
    assert.equal(extractBaseYear('2026'), 2026);
  });
  test('falls back to the current year for empty/garbage input', () => {
    const thisYear = new Date().getFullYear();
    assert.equal(extractBaseYear(''), thisYear);
    assert.equal(extractBaseYear(null), thisYear);
    assert.equal(extractBaseYear('not-a-year'), thisYear);
  });
});

describe('resolveAcademicYearForLevel — global selector to per-level format', () => {
  test('a global span selector resolves DOWN to a single year for O-Level/Primary', () => {
    assert.equal(resolveAcademicYearForLevel('2026-2027', 'o_level'), '2026');
    assert.equal(resolveAcademicYearForLevel('2026-2027', 'primary'), '2026');
  });
  test('a global span selector stays a span for A-Level', () => {
    assert.equal(resolveAcademicYearForLevel('2026-2027', 'a_level'), '2026-2027');
  });
  test('works the same even if the global selector were a single year', () => {
    assert.equal(resolveAcademicYearForLevel('2026', 'a_level'), '2026-2027');
    assert.equal(resolveAcademicYearForLevel('2026', 'o_level'), '2026');
  });
});

describe('academicYearBaseMatch — the bug fix itself', () => {
  test('a span-format filter and a single-year filter for the same year produce equivalent SQL', () => {
    const fromSpan = academicYearBaseMatch('2026-2027', 'academic_year');
    const fromSingle = academicYearBaseMatch('2026', 'academic_year');
    // Both must reduce to the SAME base-year comparison — this is exactly
    // what makes a Primary class ("2026") and an A-Level class
    // ("2026-2027") both match the one global selector.
    assert.equal(JSON.stringify(fromSpan), JSON.stringify(fromSingle));
  });
  test('applyAcademicYearFilter is a no-op for empty input (the real guard used everywhere)', async () => {
    const { applyAcademicYearFilter } = await import('../../src/utils/academicYear.js');
    assert.deepEqual(applyAcademicYearFilter({ tenant_id: 'x' }, ''), { tenant_id: 'x' });
    assert.deepEqual(applyAcademicYearFilter({ tenant_id: 'x' }, null), { tenant_id: 'x' });
  });
});

// Tanzanian school years run January to December. (These used to expect
// September–August, the Northern-hemisphere convention — which made the
// reports count March attendance and February fees as zero. The function was
// corrected; the tests had been left behind.)
describe('academicYearDateRange — real calendar window for a school year', () => {
  test('a span-format year (A-Level) covers the calendar year of its BASE year only', () => {
    // Form V sits in calendar 2026 and Form VI in 2027, each stored under its own
    // label, so widening this to two years would double-count a student.
    assert.deepEqual(academicYearDateRange('2026-2027'), { start: '2026-01-01', end: '2026-12-31' });
  });
  test('a single-year (Primary/O-Level) format resolves to the same window as its base year', () => {
    assert.deepEqual(academicYearDateRange('2026'), { start: '2026-01-01', end: '2026-12-31' });
    assert.deepEqual(academicYearDateRange('2026'), academicYearDateRange('2026-2027'));
  });
  test('accepts a plain base-year number directly', () => {
    assert.deepEqual(academicYearDateRange(2026), { start: '2026-01-01', end: '2026-12-31' });
  });
});
