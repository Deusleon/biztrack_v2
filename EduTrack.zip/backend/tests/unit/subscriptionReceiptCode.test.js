/**
 * Verification codes for subscription receipts: stable for a genuine receipt,
 * different the moment the amount, date or number is changed, and never
 * interchangeable with a fee-receipt code.
 */
import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import {
  generateSubscriptionReceiptCode, isValidSubscriptionReceiptCode,
  generateVerificationCode,
} from '../../src/utils/receiptSecurity.js';

const invoice = {
  id: '3a6f7692-5b2f-4e1e-874c-2d7d9708df7a', tenant_id: 'cd425789-6948-4258-b51b-2a4944b21023',
  invoice_number: 'INV-2026-00004', total: '2355000.00', paid_at: '2026-10-27T11:20:00.000Z',
};

describe('subscription receipt verification code', () => {
  test('is 10 uppercase characters and stable', () => {
    const code = generateSubscriptionReceiptCode(invoice);
    assert.match(code, /^[0-9A-F]{10}$/);
    assert.equal(generateSubscriptionReceiptCode({ ...invoice }), code);
  });

  test('accepts the right code, any case and spacing', () => {
    const code = generateSubscriptionReceiptCode(invoice);
    assert.equal(isValidSubscriptionReceiptCode(invoice, code), true);
    assert.equal(isValidSubscriptionReceiptCode(invoice, ` ${code.toLowerCase()} `), true);
  });

  test('a doctored amount, date, number or school fails', () => {
    const code = generateSubscriptionReceiptCode(invoice);
    assert.equal(isValidSubscriptionReceiptCode({ ...invoice, total: '235500.00' }, code), false);
    assert.equal(isValidSubscriptionReceiptCode({ ...invoice, paid_at: '2026-10-28T11:20:00.000Z' }, code), false);
    assert.equal(isValidSubscriptionReceiptCode({ ...invoice, invoice_number: 'INV-2026-00005' }, code), false);
    assert.equal(isValidSubscriptionReceiptCode({ ...invoice, tenant_id: 'other' }, code), false);
    assert.equal(isValidSubscriptionReceiptCode(invoice, ''), false);
    assert.equal(isValidSubscriptionReceiptCode(invoice, undefined), false);
  });

  test('is a different namespace from fee-receipt codes', () => {
    const asPayment = { id: invoice.id, tenant_id: invoice.tenant_id, student_id: invoice.invoice_number, amount: invoice.total, payment_date: invoice.paid_at };
    assert.notEqual(generateVerificationCode(asPayment), generateSubscriptionReceiptCode(invoice));
  });
});
