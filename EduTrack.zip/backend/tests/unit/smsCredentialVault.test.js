// FILE PATH: backend/tests/unit/smsCredentialVault.test.js
//
// Per-provider SMS credentials — pure logic, no database.
//
//   node --test tests/unit/smsCredentialVault.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  planGatewayUpdate, missingCredentials, summarizeVault, SECRET_MASK,
} from '../../src/utils/smsCredentialVault.js';

const row = (over = {}) => ({
  provider: 'simulated', api_key: null, api_secret: null, sender_id: null, saved_credentials: {}, ...over,
});

test('the credentials typed for a provider are saved under that provider', () => {
  const plan = planGatewayUpdate(row(), { provider: 'meseji', api_key: 'zs_1', sender_id: 'SCHOOL' });
  assert.equal(plan.provider, 'meseji');
  assert.deepEqual(plan.live, { api_key: 'zs_1', api_secret: null, sender_id: 'SCHOOL', system_sender_id: null });
  assert.deepEqual(plan.vault.meseji, plan.live);
});

test('switching provider keeps the old provider\'s credentials and loads the new one\'s', () => {
  const meseji = row({ provider: 'meseji', api_key: 'zs_1', sender_id: 'SCHOOL' });
  const toNext = planGatewayUpdate(meseji, { provider: 'nextsms', api_key: 'user', api_secret: 'pw' });
  assert.equal(toNext.vault.meseji.api_key, 'zs_1', 'Meseji key survives');
  assert.deepEqual(toNext.live, { api_key: 'user', api_secret: 'pw', sender_id: null, system_sender_id: null });

  // …and back again with NOTHING retyped.
  const stored = row({ provider: 'nextsms', ...toNext.live, saved_credentials: toNext.vault });
  const back = planGatewayUpdate(stored, { provider: 'meseji' });
  assert.deepEqual(back.live, { api_key: 'zs_1', api_secret: null, sender_id: 'SCHOOL', system_sender_id: null });
  assert.equal(back.vault.nextsms.api_secret, 'pw', 'NextSMS password survives too');
});

test('a provider never inherits another provider\'s key', () => {
  const meseji = row({ provider: 'meseji', api_key: 'zs_1' });
  const plan = planGatewayUpdate(meseji, { provider: 'beem_africa' });
  assert.deepEqual(plan.live, { api_key: null, api_secret: null, sender_id: null, system_sender_id: null });
});

test('the masked secret placeholder keeps the saved secret of THAT provider', () => {
  const stored = row({
    provider: 'meseji', api_key: 'zs_1',
    saved_credentials: { nextsms: { api_key: 'user', api_secret: 'pw', sender_id: null } },
  });
  const plan = planGatewayUpdate(stored, { provider: 'nextsms', api_key: 'user', api_secret: SECRET_MASK });
  assert.equal(plan.live.api_secret, 'pw');
  // an empty string, by contrast, is a deliberate clear
  assert.equal(planGatewayUpdate(stored, { provider: 'nextsms', api_secret: '' }).live.api_secret, '');
});

test('a partial update (only is_active, say) changes no credentials', () => {
  const stored = row({ provider: 'meseji', api_key: 'zs_1', sender_id: 'SCHOOL', saved_credentials: { meseji: { api_key: 'zs_1', api_secret: null, sender_id: 'SCHOOL' } } });
  const plan = planGatewayUpdate(stored, {});
  assert.equal(plan.provider, 'meseji');
  assert.deepEqual(plan.live, { api_key: 'zs_1', api_secret: null, sender_id: 'SCHOOL', system_sender_id: null });
});

test('a row that pre-dates the vault is not lost on the first switch', () => {
  const legacy = row({ provider: 'nextsms', api_key: 'user', api_secret: 'pw' }); // saved_credentials still {}
  const plan = planGatewayUpdate(legacy, { provider: 'meseji', api_key: 'zs_1' });
  assert.deepEqual(plan.vault.nextsms, { api_key: 'user', api_secret: 'pw', sender_id: null, system_sender_id: null });
});

test('simulated has no credentials of its own and leaves the vault untouched', () => {
  const stored = row({ provider: 'meseji', api_key: 'zs_1' });
  const plan = planGatewayUpdate(stored, { provider: 'simulated' });
  assert.deepEqual(plan.live, { api_key: null, api_secret: null, sender_id: null, system_sender_id: null });
  assert.equal(plan.vault.meseji.api_key, 'zs_1');
  assert.equal(plan.vault.simulated, undefined);
});

test('a provider cannot be switched on without what it needs', () => {
  assert.match(missingCredentials('nextsms', { api_key: 'user' }), /username and a password/);
  assert.match(missingCredentials('beem_africa', { api_key: 'k' }), /Secret Key/);
  assert.match(missingCredentials('meseji', { api_key: '' }), /API key/);
  assert.equal(missingCredentials('meseji', { api_key: 'zs_1' }), null);
  assert.equal(missingCredentials('simulated', {}), null);
});

test('the summary sent to the browser never contains a secret', () => {
  const summary = summarizeVault({
    nextsms: { api_key: 'user', api_secret: 'pw-secret', sender_id: 'S' },
    meseji: { api_key: null, api_secret: null, sender_id: null },
  });
  assert.deepEqual(summary, { nextsms: { api_key: 'user', sender_id: 'S', system_sender_id: '', has_secret: true } });
  assert.ok(!JSON.stringify(summary).includes('pw-secret'));
});