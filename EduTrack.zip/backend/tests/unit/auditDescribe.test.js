// Audit-log wording and scrubbing — no database, no network.
import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import {
  cleanValue, cleanObject, isHiddenField, describeChange, describeChanges, describeRequest,
  humanizeModel, humanizeField, recordName, snapshotInstance, diffInstance,
} from '../../src/utils/auditDescribe.js';

describe('secrets never reach the log', () => {
  test('credential-looking fields are hidden, whatever they are called', () => {
    for (const field of ['password', 'new_password', 'api_secret', 'access_token', 'api_key', 'otp', 'pin', 'password_hash', 'Authorization']) {
      assert.equal(isHiddenField(field), true, field);
      assert.equal(cleanValue(field, 'hunter2'), '[hidden]', field);
    }
    for (const field of ['name', 'status', 'capacity', 'phone', 'class_id']) assert.equal(isHiddenField(field), false, field);
  });

  test('nested request bodies are scrubbed all the way down', () => {
    const cleaned = cleanObject({ email: 'a@b.c', password: 'x', profile: { name: 'A', token: 'abc' }, list: [{ api_key: 'k' }] });
    assert.equal(cleaned.password, '[hidden]');
    assert.equal(cleaned.profile.token, '[hidden]');
    assert.equal(cleaned.list[0].api_key, '[hidden]');
    assert.equal(cleaned.email, 'a@b.c');
    assert.ok(!JSON.stringify(cleaned).includes('"x"') || cleaned.password === '[hidden]');
  });
});

describe('values are made safe to store', () => {
  test('long text, files and dates', () => {
    assert.equal(cleanValue('notes', 'x'.repeat(400)).length, 301);
    assert.equal(cleanValue('photo', 'data:image/png;base64,AAAA'), '[file data]');
    assert.equal(cleanValue('when', new Date('2026-10-01T10:00:00Z')), '2026-10-01T10:00:00.000Z');
    assert.equal(cleanValue('x', undefined), null);
    assert.equal(cleanValue('n', 0), 0);
    assert.equal(cleanValue('flag', false), false);
  });
});

describe('wording', () => {
  test('names for models and fields', () => {
    assert.equal(humanizeModel('FeeStructure'), 'fee structure');
    assert.equal(humanizeField('class_teacher_id'), 'Class teacher');
    assert.equal(humanizeField('first_name'), 'First name');
  });

  test('a record is named by its most recognisable column', () => {
    assert.equal(recordName({ first_name: 'Amina', last_name: 'Juma', admission_number: 'RF1' }), 'Amina Juma');
    assert.equal(recordName({ name: 'Form 1', code: 'F1' }), 'Form 1');
    assert.equal(recordName({ receipt_number: 'RCP-9' }), 'RCP-9');
    assert.equal(recordName({ foo: 1 }), null);
    assert.equal(recordName(null), null);
  });

  test('create / update / delete / deactivate / reactivate', () => {
    const base = { model: 'Class', label: 'class', name: 'Form 1' };
    assert.equal(describeChange({ ...base, op: 'create' }), 'Created class "Form 1"');
    assert.equal(describeChange({ ...base, op: 'delete' }), 'Deleted class "Form 1"');
    assert.equal(describeChange({ ...base, op: 'update', fields: [{ field: 'capacity', before: 40, after: 45 }] }), 'Updated class "Form 1"');
    assert.equal(describeChange({ ...base, op: 'update', fields: [{ field: 'status', before: 'active', after: 'inactive' }] }), 'Deactivated class "Form 1"');
    assert.equal(describeChange({ ...base, op: 'update', fields: [{ field: 'status', before: 'inactive', after: 'active' }] }), 'Reactivated class "Form 1"');
    assert.equal(describeChange({ ...base, op: 'update', fields: [{ field: 'status', before: 'a', after: 'b' }, { field: 'name', before: 'x', after: 'y' }] }), 'Updated class "Form 1"');
    assert.equal(describeChange({ model: 'Student', label: 'student', op: 'create' }), 'Created student');
  });

  test('bulk operations say how many and what', () => {
    assert.equal(describeChange({ op: 'bulk_update', label: 'class', count: 3, set: { status: 'inactive' } }), 'Updated 3 class records (status → inactive)');
    assert.equal(describeChange({ op: 'bulk_update', label: 'class', count: 1, set: {} }), 'Updated 1 class record');
    assert.equal(describeChange({ op: 'bulk_delete', label: 'class', count: null }), 'Deleted several class records');
  });
});

describe('a request that changed several records', () => {
  const payment = { op: 'create', model: 'Payment', label: 'payment', name: 'RCP-1' };
  const student = { op: 'update', model: 'Student', label: 'student', name: 'Amina Juma', fields: [{ field: 'balance', before: 10, after: 0 }] };

  test('is named after the record the user was working on', () => {
    const d = describeChanges([student, payment], {}, 'payments');
    assert.equal(d.title, 'Created payment "RCP-1" (+1 related change)');
    assert.equal(d.kind, 'create');
    assert.equal(d.record.model, 'Payment');
  });

  test('counts records beyond the detailed ones', () => {
    const d = describeChanges([payment], { 'MessageRecipient:create': 25 }, 'payments');
    assert.equal(d.title, 'Created payment "RCP-1" (+25 related changes)');
  });

  test('matches the module to its record whatever the plural (classes → Class)', () => {
    const section = { op: 'update', model: 'Section', label: 'section', name: 'A', fields: [{ field: 'capacity', before: 1, after: 2 }] };
    const cls = { op: 'update', model: 'Class', label: 'class', name: 'Form 1', fields: [{ field: 'name', before: 'a', after: 'b' }] };
    assert.equal(describeChanges([section, cls], {}, 'classes').record.model, 'Class');
    assert.equal(describeChanges([section, cls], {}, 'sections').record.model, 'Section');
    assert.equal(describeChanges([section, cls], {}, 'something-else').record.model, 'Section'); // no match → first change
  });

  test('lists the changed fields of an update', () => {
    assert.deepEqual(describeChanges([student], {}, 'students').changed_fields, ['balance']);
  });

  test('no changes → null (the caller falls back to the request)', () => {
    assert.equal(describeChanges([], {}, 'x'), null);
  });
});

describe('describing a request from its route (older entries and non-record actions)', () => {
  test('sign-in / sign-out / password', () => {
    assert.deepEqual(describeRequest({ method: 'POST', path: '/login', body: { email: 'a@b.c' } }), { title: 'Signed in (a@b.c)', kind: 'auth' });
    assert.equal(describeRequest({ method: 'POST', path: '/api/v1/auth/logout' }).title, 'Signed out');
    assert.equal(describeRequest({ method: 'PUT', path: '/change-password' }).title, 'Changed own password');
  });

  test('plain create / update / delete', () => {
    const id = '5d3a1f0e-1111-4222-8333-444455556666';
    assert.equal(describeRequest({ method: 'POST', resource: 'classes', path: '/', body: { name: 'Form 1' } }).title, 'Created classes "Form 1"');
    assert.equal(describeRequest({ method: 'PUT', resource: 'students', path: `/${id}`, body: { first_name: 'Amina', last_name: 'Juma' } }).title, 'Updated students "Amina Juma"');
    assert.equal(describeRequest({ method: 'DELETE', resource: 'students', path: `/${id}` }).kind, 'delete');
  });

  test('an id in the path is never shown as the action', () => {
    const t = describeRequest({ method: 'PUT', resource: 'students', path: '/5d3a1f0e-1111-4222-8333-444455556666' }).title;
    assert.ok(!/5d3a/.test(t), t);
  });

  test('verbs such as send / refund are shown as actions', () => {
    const r = describeRequest({ method: 'POST', resource: 'messaging', path: '/messages/send' });
    assert.equal(r.kind, 'action');
    assert.match(r.title, /^Send — messages/);
    assert.equal(describeRequest({ method: 'POST', resource: 'fees', path: '/payments/5d3a1f0e-1111-4222-8333-444455556666/refund' }).kind, 'action');
  });
});

describe('reading a record instance', () => {
  // A minimal stand-in for a Sequelize instance.
  const fake = (current, previous, changed) => ({
    constructor: { rawAttributes: Object.fromEntries(Object.keys(current).map((k) => [k, {}])) },
    get: (k) => current[k], previous: (k) => previous[k], changed: () => changed, dataValues: current,
  });

  test('snapshot skips ids, timestamps, tenant and empty columns, and hides secrets', () => {
    const inst = fake({ id: 'i', tenant_id: 't', name: 'Form 1', notes: null, password: 'secret', created_at: new Date() }, {}, []);
    assert.deepEqual(snapshotInstance(inst), { name: 'Form 1', password: '[hidden]' });
  });

  test('diff reports only what changed, with both values', () => {
    const inst = fake({ name: 'B', capacity: 45, updated_at: 'x' }, { name: 'A', capacity: 45, updated_at: 'y' }, ['name', 'capacity', 'updated_at']);
    assert.deepEqual(diffInstance(inst), [{ field: 'name', before: 'A', after: 'B' }]);
  });

  test('a changed secret shows as changed without showing either value', () => {
    const inst = fake({ password: 'new' }, { password: 'old' }, ['password']);
    assert.deepEqual(diffInstance(inst), [{ field: 'password', before: '[hidden]', after: '[hidden]' }]);
  });
});
