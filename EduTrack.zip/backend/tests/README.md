# Backend tests

Real integration tests against a real Postgres database (via `supertest`
driving the actual Express app), plus a small set of dependency-free unit
tests for the academic-year utilities. No mocking of the database — these
tests exercise the same Sequelize models, the same migrations, and the
same controllers the app runs in production.

## One-time setup

1. Create a **disposable** test database — never point this at a database
   with real school data:
   ```bash
   createdb edutrack_test
   ```
2. In `backend/.env` (or exported in your shell), point at it:
   ```
   DB_NAME=edutrack_test
   DB_USER=postgres
   DB_PASSWORD=postgres
   DB_HOST=localhost
   DB_PORT=5432
   JWT_SECRET=any_value_for_local_testing
   ```
3. Apply the schema:
   ```bash
   npm run db:migrate
   ```

## Running

```bash
npm test
```

This runs Node's built-in test runner (`node --test`) over everything
under `tests/`. It needs no extra dependencies beyond `supertest`, already
listed in `devDependencies`.

## What's covered so far

- `tests/unit/academicYear.test.js` — the base-year matching logic itself
  (no database needed).
- `tests/integration/classes-academic-year.test.js` — the original bug
  report: listing classes by academic year across Primary/O-Level
  (single-year) and A-Level (span) formats.
- `tests/integration/promotion.test.js` — preview → run → revert, across
  a school with mixed Primary and O-Level classes.
- `tests/integration/fees.test.js` — fee structure listing and the Fee
  Collection report, across Primary and A-Level.

Fees, promotion, and exams are the highest-stakes modules in this app —
get one wrong and either money or a student's academic record is affected —
so they're the priority for coverage. This is a starting point, not
complete coverage: as a rule of thumb, any bug fix or new feature in
these three modules (or in anything else academic-year-scoped) should
come with a test in the same style, in the same folder.

## Test data lifecycle

Each test file creates its own tenant (school) with a randomized,
unique slug/email — so test files never collide with each other OR with
a previous run's leftover rows, and nothing needs to be truncated between
runs. The trade-off: rows accumulate in `edutrack_test` over time. That's
fine for a disposable test database; if it ever needs a fresh start,
just drop and recreate it (`dropdb edutrack_test && createdb edutrack_test`
then `npm run db:migrate` again).
- `tests/unit/nextsms.test.js` — the NextSMS integration: request format, per-recipient results, batching,
  balance parsing, connection test and delivery reports, against a scripted fake `fetch` (no network, no database).
- `tests/unit/auditDescribe.test.js` — audit-log wording and secret scrubbing (no database).
- `tests/integration/audit-log.test.js` — the Activity History end to end: create / update / delete / bulk / sign-in
  entries with before → after values, no passwords stored, older entries, filters, school isolation and permissions.
- `tests/integration/route-access.test.js` (+ `helpers/routePolicy.js`, `helpers/routeInventory.js`) — the access-control audit:
  every route × every role against a written policy, the "own record only" rules, account creation and the payment webhook.
- `tests/integration/password-policy.test.js` — first sign-in with the starting password, the API gate, session invalidation.
- `tests/integration/forgot-password.test.js` — reset codes: single-use, expiry, guess limit, no account enumeration.
- `tests/integration/permission-grants.test.js` — permissions really decide what people can do: grants by role and by person, taking defaults away, "reset to standard", admins never locked out.
- `tests/integration/signed-files.test.js` — uploaded files only open with a valid, unexpired, untampered signature.
- `tests/integration/auth-audit.test.js` — failed and refused sign-ins appear in the school's activity history.
