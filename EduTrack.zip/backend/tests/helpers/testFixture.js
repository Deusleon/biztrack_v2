/**
 * testFixture.js — shared setup for integration tests.
 *
 * Integration tests run the real Express app (via supertest) against a
 * REAL Postgres database — set DB_NAME to a disposable test database
 * (never the one with real school data) before running `npm test`.
 * See backend/tests/README.md for one-time setup.
 *
 * Each test file gets its own isolated tenant (school), so tests in
 * different files never see each other's data even though they share one
 * database — no truncation/reset needed between files.
 */
import jwt from 'jsonwebtoken';
import { randomUUID } from 'crypto';
import sequelize from '../../src/config/database.js';
import { Tenant, User, Campus } from '../../src/models/index.js';

/** Builds one throwaway tenant + campus + admin user, and a valid auth
 * token for that admin — everything a test needs to call the real API
 * as a logged-in school admin. `label` just keeps tenant/campus/admin
 * emails unique per test file so parallel test files never collide. */
export async function buildTenantFixture(label = randomUUID().slice(0, 8)) {
  // Suffix with a short random id even when the caller passes a fixed,
  // readable label — otherwise re-running the suite against a database
  // that still has a PREVIOUS run's rows (nothing here truncates between
  // runs, by design — see the file header) hits a duplicate tenant
  // slug / user email and fails with a constraint error unrelated to
  // whatever the test is actually checking.
  const unique = `${label}-${randomUUID().slice(0, 8)}`;
  const tenant = await Tenant.create({
    name: `Test School ${unique}`,
    slug: `test-school-${unique}`,
    email: `school-${unique}@example.test`,
  });

  const campus = await Campus.create({
    tenant_id: tenant.id,
    name: 'Main Campus',
    code: `MAIN-${unique}`,
  });

  const admin = await User.create({
    tenant_id: tenant.id,
    email: `admin-${unique}@example.test`,
    password: 'Password123!', // hashed by the User model's beforeCreate hook
    first_name: 'Test',
    last_name: 'Admin',
    role: 'admin',
    status: 'active',
  });

  const token = jwt.sign({ id: admin.id }, process.env.JWT_SECRET, { expiresIn: '1h' });

  return { tenant, campus, admin, token };
}

/** Express requires an Authorization header on every protected route —
 * this is the one line every test needs to attach it. */
export const authHeader = (token) => ({ Authorization: `Bearer ${token}` });

/** Closes the shared Sequelize connection pool. Call once, in an
 * `after()` hook, per test FILE — not per test — so the process can
 * exit cleanly instead of hanging on an open DB connection. */
export const closeDb = () => sequelize.close();
