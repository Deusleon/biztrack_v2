// FILE PATH: backend/tests/helpers/fakeSmtp.js
/**
 * fakeSmtp.js — a tiny in-process SMTP server for tests.
 *
 * Speaks just enough SMTP (greeting, EHLO, AUTH PLAIN, MAIL/RCPT/DATA, QUIT)
 * for nodemailer to log in and deliver a message, so the email gateway's
 * Test Connection / Send Test Email can be exercised against something real
 * — no mail account, no internet, nothing leaves the machine.
 *
 *   const smtp = await startFakeSmtp({ user: 'mailer', pass: 'right-pass' });
 *   smtp.port       // the port it listens on
 *   smtp.messages   // every message it accepted: { from, to: [], data }
 *   await smtp.close();
 */
import net from 'node:net';

export const startFakeSmtp = ({ user = 'mailer', pass = 'right-pass' } = {}) => new Promise((resolve) => {
  const messages = [];
  const sockets = new Set();

  const server = net.createServer((sock) => {
    sockets.add(sock);
    sock.on('close', () => sockets.delete(sock));
    sock.on('error', () => {});

    let buf = '';
    let inData = false;
    let current = { from: null, to: [], data: '' };
    const send = (line) => sock.write(`${line}\r\n`);

    send('220 fake.smtp ESMTP ready');
    sock.on('data', (chunk) => {
      buf += chunk.toString('utf8');
      let idx;
      while ((idx = buf.indexOf('\r\n')) !== -1) {
        const line = buf.slice(0, idx);
        buf = buf.slice(idx + 2);

        if (inData) {
          if (line === '.') {
            inData = false;
            messages.push(current);
            current = { from: null, to: [], data: '' };
            send('250 OK queued');
          } else {
            current.data += `${line}\n`;
          }
          continue;
        }

        const cmd = line.toUpperCase();
        if (cmd.startsWith('EHLO') || cmd.startsWith('HELO')) {
          send('250-fake.smtp');
          send('250 AUTH PLAIN');
        } else if (cmd.startsWith('AUTH PLAIN')) {
          const [, u, p] = Buffer.from(line.split(' ')[2] || '', 'base64').toString('utf8').split('\0');
          if (u === user && p === pass) send('235 2.7.0 Authentication successful');
          else send('535 5.7.8 Authentication credentials invalid');
        } else if (cmd.startsWith('MAIL FROM')) {
          current.from = (line.match(/<([^>]*)>/) || [])[1] || null;
          send('250 OK');
        } else if (cmd.startsWith('RCPT TO')) {
          current.to.push((line.match(/<([^>]*)>/) || [])[1]);
          send('250 OK');
        } else if (cmd === 'DATA') {
          inData = true;
          send('354 End data with <CR><LF>.<CR><LF>');
        } else if (cmd === 'QUIT') {
          send('221 Bye');
          sock.end();
        } else {
          send('250 OK'); // RSET, NOOP, …
        }
      }
    });
  });

  server.listen(0, '127.0.0.1', () => resolve({
    port: server.address().port,
    messages,
    close: () => new Promise((done) => {
      sockets.forEach((s) => s.destroy());
      server.close(() => done());
    }),
  }));
});

/** A port nothing is listening on (for "connection refused"). */
export const closedPort = () => new Promise((resolve) => {
  const s = net.createServer();
  s.listen(0, '127.0.0.1', () => { const { port } = s.address(); s.close(() => resolve(port)); });
});