/**
 * routeInventory.js — every route the API exposes, read from the app itself.
 *
 * Used by the access-control test (route-access.test.js): it lists each
 * method + path from the real routers, so a route added tomorrow shows up here
 * automatically and must be given an access policy before the suite passes.
 *
 * Mount points are read from server.js (`app.use('/api/v1/students', studentRoutes)`)
 * and each router's own stack is walked, so nothing is maintained by hand.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const srcDir = path.resolve(here, '../../src');

export async function listRoutes() {
  const server = fs.readFileSync(path.join(srcDir, 'server.js'), 'utf8');
  const files = Object.fromEntries([...server.matchAll(/import\s+(\w+)\s+from\s+'\.\/routes\/([^']+)'/g)].map((m) => [m[1], m[2]]));
  const mounts = [...server.matchAll(/app\.use\('(\/api\/v1\/[^']*)',\s*(\w+)\)/g)].map((m) => ({ mount: m[1], file: files[m[2]] }));

  const routes = [];
  for (const { mount, file } of mounts) {
    if (!file) continue;
    const router = (await import(pathToFileURL(path.join(srcDir, 'routes', file)).href)).default;
    for (const layer of router.stack) {
      if (!layer.route) continue; // router-level middleware (router.use) — applies to the routes below it
      for (const method of Object.keys(layer.route.methods)) {
        const sub = layer.route.path === '/' ? '' : layer.route.path;
        routes.push({ method: method.toUpperCase(), path: `${mount}${sub}`, file, module: mount.replace('/api/v1/', '') });
      }
    }
  }
  return routes;
}

/** '/students/:id/photo' → '/students/<uuid>/photo' — a well-formed but unknown id. */
export const withIds = (routePath, id) => routePath.replace(/:[A-Za-z_]+\??/g, id);
