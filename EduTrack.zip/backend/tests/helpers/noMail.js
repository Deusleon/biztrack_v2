// Import this FIRST in a test that triggers emails: it points the platform's mail server at a
// closed port, so a send fails instantly instead of waiting on a real network connection.
process.env.SMTP_HOST = '127.0.0.1';
process.env.SMTP_PORT = '1';
process.env.SUBSCRIPTION_JOBS = 'off';
