# Database migrations

## Why this changed

Previously the app relied entirely on Sequelize's `sync()`:
- `sync({ alter: true })` ran automatically every time the server started in
  development. `alter` *guesses* at the SQL needed to match the models —
  for anything more than adding a plain column (a rename, a type change, a
  new constraint) it can guess wrong, or drop and recreate a column and
  silently lose the data in it.
- `sync({ force: true })` — wired up as `npm run db:empty`, the documented
  way to provision a *real* school's database — **drops and recreates
  every table**. There was no safe way to evolve an existing school's
  schema at all; the only tool available deletes their data.

This is now replaced with ordinary, one-way-forward **migration files**,
the same approach used by virtually every production Rails/Django/Node
app. Each migration is a small, reviewable file; applying it is safe to
run repeatedly (already-applied migrations are skipped); and unlike
`alter`, nothing runs unless a person wrote and reviewed the SQL/queryInterface
call for it.

The runner itself (`backend/src/utils/migrate.js`) is intentionally
dependency-free — about 100 lines you can read start to finish — rather
than pulling in `sequelize-cli` or `umzug`. It tracks applied migrations
in a `SequelizeMeta` table (one row per applied filename), same idea both
of those tools use.

## Everyday commands (run from `backend/`)

```bash
npm run db:migrate          # apply every pending migration
npm run db:migrate:status   # show which have run / are pending
npm run db:migrate:undo     # revert the single most recent migration
```

## Adopting migrations on an existing database

If your school's database already has its tables (created previously by
`sync()` / `npm run db:empty`), **do not** just run `npm run db:migrate` —
the baseline migration would try to `CREATE TABLE` things that already
exist and fail partway through.

Instead, tell the migration runner the baseline is already effectively
applied, by inserting its row directly:

```bash
# from backend/, with your real DB_* env vars loaded
node -e "
import('./src/config/database.js').then(async ({ default: sequelize }) => {
  await sequelize.getQueryInterface().createTable('SequelizeMeta', {
    name: { type: sequelize.Sequelize.DataTypes.STRING, primaryKey: true, allowNull: false, unique: true },
    applied_at: { type: sequelize.Sequelize.DataTypes.DATE, allowNull: false },
  }).catch(() => {}); // ignore if it already exists
  await sequelize.query(\`INSERT INTO \"SequelizeMeta\" (name, applied_at) VALUES ('20260821000000-baseline-schema.js', NOW()) ON CONFLICT DO NOTHING\`);
  console.log('Baseline marked as applied.');
  process.exit(0);
});
"
```

After that, `npm run db:migrate:status` should show the baseline as
`[x]` (applied), and from then on you only ever add *new* migration files
for *new* changes — the baseline file itself is never edited or re-run.

## Adding a new migration

1. Create a new file in `backend/src/migrations/`, named
   `YYYYMMDDHHMMSS-short-description.js` (the timestamp prefix is what
   keeps migrations running in the right order — always pick a name that
   sorts after every existing file).
2. Export `up` and `down`:

   ```js
   // 20260901120000-add-student-blood-type.js
   export async function up(queryInterface, Sequelize, transaction) {
     await queryInterface.addColumn('students', 'blood_type', {
       type: Sequelize.DataTypes.STRING,
       allowNull: true,
     }, { transaction });
   }

   export async function down(queryInterface, Sequelize, transaction) {
     await queryInterface.removeColumn('students', 'blood_type', { transaction });
   }
   ```
3. Also update the matching model in `backend/src/models/*.js` so the
   Sequelize model and the real table agree (the migration changes the
   database; the model definition is what the rest of the app code reads
   against — they need to describe the same thing).
4. Run `npm run db:migrate` locally against your own database to confirm
   it applies cleanly before committing.

A migration that has already been applied anywhere (your machine, a
teammate's, production) should never be edited afterwards — write a new
migration instead, even to fix a mistake in an old one. Editing an
already-run file only changes what NEW databases see; anyone who already
ran the old version silently drifts out of sync with no record of it.

## What server.js does now

`sync({ alter: true })` still runs automatically in `NODE_ENV=development`
purely as a local convenience (so a fresh clone "just works" without
extra steps) — it is never run in production. For anything beyond quick
local experimentation, prefer `npm run db:migrate` even in development,
so what you're testing against matches what production will actually get.

`npm run db:empty` (`resetDatabase.js`) is for spinning up a **brand-new,
empty** installation only — it still uses `force: true` because there is
by definition no existing data to protect yet. It must never be run
against a school that already has real data in it.
