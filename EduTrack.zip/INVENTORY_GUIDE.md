# Inventory — Guide

School assets and consumables tracking. Kept to a stock ledger, the same
pattern as Vehicle maintenance history and the Expenses ledger.

## How it works

### Inventory (`/inventory`)
Every item with its current quantity on hand, category, location, and
condition. Anyone logged in can browse; only Admin can manage items and
record movements.

Quantity is never edited directly on the item -- it's always the result
of a Record Movement entry, so the item's number and its history never
drift apart:

- Received -- new stock in (increases quantity)
- Issued -- given out to a class/department/person (decreases; optional
  "Issued To" note)
- Damaged / Lost -- decreases, with a reason on record
- Adjusted -- sets the quantity to an exact new total, for correcting a
  miscount after a physical inventory check

Items with a Reorder Level set show as "Low" once quantity on hand drops
to or below it -- filterable with "Low stock only".

View History on any item shows its full movement log.

## How to test

The seed script adds 6 items with realistic starting stock and a couple
of follow-up "issued" movements.

1. Log in as admin -> Inventory -> confirm 6 items appear.
2. Check "Low stock only" -> confirm Whiteboard Markers and Footballs
   show (both below their reorder level).
3. Open an item's actions -> Record Movement -> Received, add 20 ->
   confirm the quantity on hand increases immediately.
4. Record Movement -> Issued, more than what's on hand -> confirm it's
   blocked with a clear message.
5. View History on Student Desks -> confirm both the initial "received"
   and the later "issued to Form I Classrooms" entries appear.
6. Try Adjusted with a specific number (e.g. after a stock count) ->
   confirm quantity on hand is set to exactly that number, not added to
   it.
