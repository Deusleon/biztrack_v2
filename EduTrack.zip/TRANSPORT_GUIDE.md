# Transport — Guide

Bus routes and student assignments. Kept deliberately small — routes with
a driver/vehicle/capacity/ordered stops, and which students ride which
route. No live GPS tracking, no maintenance scheduling, no separate fee
automation (transport fees are handled the same way as any other fee, via
Fees -> Fee Structures).

## How it works

### 1. Transport (`/transport`)
List of routes with driver, vehicle, and occupancy (e.g. "24/40 seats").
Admin/Principal/Transport Manager can create, edit, and delete routes.
Anyone logged in can view the list (parents/students can see routes, but
managing is restricted).

Creating/editing a route:
- Name, route number, driver name/phone, vehicle number, seat capacity
  (optional -- leave blank for no capacity limit)
- Stops, added one at a time in order (shown as a numbered list on the
  route)

### 2. Manage Students (per route)
From a route's action menu -> Manage Students -> shows everyone currently
assigned, with their pickup/drop point and an optional fee note. "+
Assign Student" picks a class -> section -> student, sets pickup/drop
point, and assigns them -- replacing any other route they were previously
on (a student rides one route at a time). "Remove" takes them off the
route (soft-removed, doesn't delete history).

If a route has a capacity set, assigning past that limit is blocked with
a clear "route is full" message.

## How to test

The seed script creates 3 routes (Kariakoo, Mbezi, Tabata) with drivers,
vehicles, and stops, and assigns roughly a third of Form I Section A's
students across them.

1. Log in as admin -> Transport -> confirm 3 routes appear with occupancy
   numbers.
2. Click a route's actions -> Manage Students -> confirm assigned
   students show with their pickup/drop stop.
3. "+ Assign Student" -> pick Form I, Section A -> pick a student not yet
   on this route -> assign -> confirm they appear immediately.
4. Try assigning a student who's already on a different route -> confirm
   they move over (no longer on the old route, now on the new one).
5. If you set a low capacity on a route, try assigning past that number
   -> confirm it's blocked with a clear message.
6. Log in as a parent linked to an assigned Form I A student -> confirm
   they can view the Transport route list but don't see a "Manage
   Students" action.

## Vehicles (`/transport/vehicles`)

The school's fleet, separate from Routes — a vehicle can be linked to a
route (or not yet assigned to one). Each vehicle has:

- Registration number, make, model, year, seat capacity, description
- **A photo** — upload from the vehicle's detail page (JPG/PNG/WEBP, up
  to 5MB). Files are stored on the server under `UPLOAD_PATH` (`./uploads`
  by default) and served at `/uploads/vehicles/...`.
- Driver name, phone, license number
- Insurance and inspection expiry dates
- Status: Active / In Maintenance / Inactive
- **Service & maintenance history** — a simple log: date, service type
  (Oil Change, Full Service, Tire Replacement, Repair, ...), cost,
  who performed it, an optional "next service due" date, and notes.
  Not a scheduling system — just a running history you can scan.

When creating/editing a **Route**, you can pick an existing Vehicle from
a dropdown instead of typing driver/vehicle details by hand — picking one
auto-fills the route's driver/vehicle fields from that Vehicle record
(still editable manually if a route uses a vehicle that isn't formally
registered yet).

### Testing Vehicles

1. **Transport → Vehicles** → confirm 3 seeded vehicles appear with
   photos-placeholder icons (no real photos are seeded — upload one
   yourself to test).
2. Open a vehicle → **Upload Photo** → pick an image → confirm it appears
   immediately on both the detail page and the fleet grid.
3. Confirm 2 of the 3 vehicles already have a maintenance record; **+ Add
   Record** on the third → confirm it appears in the history and the
   "Total Spent" stat updates.
4. **Transport → Routes** → edit a route → confirm its linked Vehicle
   shows in the dropdown, and that driver/vehicle fields are locked
   (greyed out) since they come from the Vehicle record.
5. Try deleting a Vehicle that's linked to a route — confirm it's blocked
   with a clear message until the route is unlinked first.
