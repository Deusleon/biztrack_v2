# Security Policy

## Supported Versions

We release patches for security vulnerabilities for the following versions:

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |
| < 1.0   | :x:                |

## Reporting a Vulnerability

We take the security of EduTrack seriously. If you believe you have found a security vulnerability, please report it to us as described below.

### Please DO NOT:

- Open a public GitHub issue about the vulnerability
- Disclose the vulnerability publicly before it has been addressed

### Please DO:

1. **Email us directly** at security@edutrack.com with:
   - A description of the vulnerability
   - Steps to reproduce the issue
   - Potential impact of the vulnerability
   - Any suggested fixes (if you have them)

2. **Allow time for us to respond:**
   - We will acknowledge your email within 48 hours
   - We will provide a detailed response within 7 days
   - We will work on a fix and keep you updated on progress

3. **Give us reasonable time to fix the issue** before making it public

## Security Best Practices

### For Developers

1. **Never commit sensitive data:**
   - API keys
   - Passwords
   - Private keys
   - Database credentials
   - JWT secrets

2. **Use environment variables:**
   - All configuration should use environment variables
   - Use `.env.example` as a template
   - Never commit `.env` files

3. **Input Validation:**
   - Validate all user inputs
   - Use express-validator for API endpoints
   - Sanitize data before database operations

4. **Authentication & Authorization:**
   - Use bcrypt for password hashing
   - Implement JWT properly
   - Check user permissions for all protected routes
   - Enforce multi-tenancy isolation

5. **Database Security:**
   - Use parameterized queries (Sequelize ORM)
   - Implement proper indexing
   - Regular backups
   - Principle of least privilege for database users

6. **Dependencies:**
   - Regularly update dependencies
   - Use `npm audit` to check for vulnerabilities
   - Review security advisories

### For System Administrators

1. **Production Environment:**
   - Use HTTPS/SSL certificates
   - Configure proper firewall rules
   - Enable rate limiting
   - Regular security updates

2. **Database:**
   - Use strong passwords
   - Restrict database access
   - Enable SSL for database connections
   - Regular backups

3. **Monitoring:**
   - Monitor application logs
   - Set up alerts for suspicious activities
   - Regular security audits

4. **Access Control:**
   - Implement strong password policies
   - Use multi-factor authentication where possible
   - Regular access reviews
   - Principle of least privilege

## Known Security Considerations

### JWT Tokens

- Tokens expire after 7 days by default
- Use refresh tokens for extended sessions
- Store tokens securely (httpOnly cookies recommended for web)
- Never share tokens

### Password Policy

- Minimum 6 characters (should be increased to 8+ in production)
- Must contain letters and numbers (recommended)
- Passwords are hashed using bcrypt
- Password reset tokens expire after 1 hour

### Session Management

- Sessions are stateless using JWT
- Tokens should be invalidated on logout
- Implement token refresh mechanism

### File Uploads

- Validate file types
- Limit file sizes (default: 10MB)
- Scan for malware
- Store in secure location

### SQL Injection

- Sequelize ORM prevents SQL injection
- Always use parameterized queries
- Never concatenate user input in queries

### XSS Prevention

- Sanitize all user inputs
- Use Content Security Policy headers
- Escape output in templates

### CSRF Protection

- Implement CSRF tokens for state-changing operations
- Use SameSite cookie attribute

## Access control — permissions, not job titles

What a person may **do** is decided by *permissions* (`utils/permissionCatalog.js` lists all 77), never by their role name:

- **Each menu item has an "Open …" permission** (`students.access`, `fees.access`, …): untick it and the module leaves that role's menu and its pages are closed (`ProtectedRoute` + `utils/moduleAccess.js`). View/Create/Update/Delete are what a person may do inside. Defaults equal today's menu for every role, students and parents included. See `PERMISSIONS_GUIDE.md` (Swahili, for beginners).
- **Admin and super admin can always do everything** — so a school can't lock itself out by editing permissions.
- **Every other role, the principal included, can do exactly what its permission set says.** The set starts as the role's
  *standard* permissions (`DEFAULT_ROLE_PERMISSIONS`, equal to what each role could already do) and an administrator edits it
  per role in **Settings → Permissions** — ticking adds, unticking really takes away. "Reset to standard" undoes it.
- **A single person can be given extra permissions** on top of their role (Individual Overrides).
- So a teacher *can* be allowed to delete — or an accountant forbidden to record payments — just by changing permissions.
  Deleting (including permanent deletion) follows the module's `*.delete` permission; it is not reserved for the super admin.
- **Your own record is not a permission.** A parent's children, a student's own results, your own payslip and leave requests are
  checked against ownership. Without `students.view` a parent sees only their children and a student only themself.
- Routes are guarded with `perm('students.update')` (`middleware/access.js`); the browser is sent the person's
  `effective_permissions` (`*` = everything) to decide which buttons to show — the server still decides every action.
- Older saved role settings (which only ever listed *extra* permissions) keep the standard set; the first time an
  administrator saves a role in the new screen it becomes the complete set.

**Who may reach which route** is written in `backend/tests/helpers/routePolicy.js`, and `tests/integration/route-access.test.js`
runs *every* route as *every* role against the standard permissions. It fails if a role gets through that shouldn't (a leak), if one is
blocked that shouldn't be (a broken screen), or if a route exists with no policy line — **a new route cannot ship without one**.
`permission-grants.test.js` proves that granting and removing permissions really changes what people can do.

Other rules:
- Staff pay, national ID, tax/pension numbers and bank details need `staff.view_sensitive` (or being the person themself).
- `POST /auth/register` needs a signed-in administrator (the school's own, for their school only) or the platform
  developer (`DEVELOPER_EMAILS`) — it used to be open to anyone.
- `POST /webhooks/clickpesa` never trusts the body: it asks ClickPesa whether the order was paid. Set
  `CLICKPESA_WEBHOOK_SECRET` too.

## Passwords and sessions

- **First sign-in.** A new staff member or student has a shared starting password and `must_change_password`. Until
  they choose their own, the API refuses everything except `GET /auth/me` and `PUT /auth/change-password`
  (`403` with `code: PASSWORD_CHANGE_REQUIRED`) and the app shows only the "choose a new password" screen; then they are
  signed out and sign in again. A sign-in with the starting password sets the flag even if it was never set.
- **Sessions end when the password changes.** Every token carries a fingerprint of the password hash it was issued
  under (`pwv`); change or reset the password and older tokens stop working. Tokens issued before this existed have no
  fingerprint and keep working until they expire.
- **Forgot password.** `POST /auth/forgot-password` sends a 6-digit code; `POST /auth/reset-password` sets the new password.
  **Where the code goes is the school's choice** — Settings → Notifications → *Password reset codes* (stored as the
  `password_reset` notification setting): **email only (the default)**, SMS only, or either/both. The form asks only for what
  that allows (`GET /auth/forgot-password/options`); each school's rule is enforced again once the account is found, so an email
  is refused in SMS-only mode and a phone number in email-only mode. It can't be switched off or left empty.
  The code is stored only as an HMAC, lasts 15 minutes, works once, and dies after 5 wrong guesses; requests are throttled per
  account (1/minute, 5/hour) and per network address; answers never reveal whether an account exists. A student's code goes to
  their parent's email/phone. If no real email/phone is recorded, nobody receives a code (in `NODE_ENV=development` it is
  printed in the server log). SMS needs an active SMS gateway. Needs the `password_resets` table: run `npm run db:migrate`.
- **A new password** needs at least 8 characters with both letters and numbers, must differ from the current one, and
  must not be a starting password (`utils/passwords.js`; the same rule on change, first sign-in, reset and registration).

## Uploaded files

Files under `/uploads` (photos, certificates, receipts) are served **only with a signature**
(`utils/signedFiles.js`): `…/uploads/x/y.png?exp=…&sig=…`. The API adds it to every file address it returns, so
nothing in the screens changes. A link is tied to one file, lasts 6–12 hours, and stops working after that; without a
valid one the server answers `403`. `FILE_URL_SECRET` may be set to use a secret other than `JWT_SECRET`.

## Sign-in attempts

Successful sign-ins, wrong passwords (with the attempt count), lockouts, refused locked/inactive accounts and a wrong
current password on the change-password form are all written to the school's activity history (Settings → Audit Log →
"Sign-ins", failed ones in red) with the time, device and network address — never the password. An attempt on an email
that belongs to no one can't be attributed to a school, so it isn't recorded.

## Security Features

### Implemented

- ✅ Password hashing with bcrypt
- ✅ JWT authentication
- ✅ Input validation with express-validator
- ✅ Helmet.js security headers
- ✅ CORS configuration
- ✅ Rate limiting (configurable)
- ✅ Audit logging
- ✅ Multi-tenancy isolation
- ✅ Role-based access control (RBAC)

### Recommended for Production

- [ ] HTTPS/SSL certificates
- [ ] Security scanning tools
- [ ] Web Application Firewall (WAF)
- [ ] DDoS protection
- [ ] Regular penetration testing
- [ ] Security training for staff
- [ ] Incident response plan

## Compliance

EduTrack is designed to help meet various compliance requirements:

- **FERPA** (Family Educational Rights and Privacy Act)
- **COPPA** (Children's Online Privacy Protection Act)
- **GDPR** (General Data Protection Regulation) - for EU users

Note: Compliance is the responsibility of the institution using the software. Consult with legal experts for your specific requirements.

## Data Protection

### Personal Data

- Minimize data collection
- Obtain consent where required
- Implement data retention policies
- Provide data export functionality
- Support data deletion requests

### Encryption

- Passwords: bcrypt hashing
- In transit: HTTPS/TLS
- At rest: Database encryption (recommended)
- Backups: Encrypted storage

## Incident Response

If a security incident occurs:

1. **Contain:** Isolate affected systems
2. **Assess:** Determine scope and impact
3. **Notify:** Inform affected parties
4. **Remediate:** Fix the vulnerability
5. **Review:** Learn and improve

## Security Updates

- Security patches will be released promptly
- Critical vulnerabilities: Within 48 hours
- High severity: Within 1 week
- Medium/Low severity: Next release cycle

## Contact

For security concerns, contact:
- Email: security@edutrack.com
- Response time: 48 hours

## Credits

We appreciate security researchers who report vulnerabilities responsibly. With your permission, we will:
- Credit you in release notes
- Add you to our security hall of fame
- Provide a token of appreciation (if applicable)

---

**Last Updated:** December 2024

**Note:** This security policy may be updated periodically. Please check back regularly.
