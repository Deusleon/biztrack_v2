# Library — Guide

Book catalog, issue/return, and fines. Kept small — no reservations
queue, no barcode scanning, no digital/ebook tracking.

## How it works

### 1. Library (`/library`)
Book catalog with title, author, ISBN, category, shelf location, and
copies (available/total). Admin/Principal/Librarian can add, edit, and
delete books; anyone logged in can browse the catalog.

Issue Book (from a book's action menu, disabled when no copies are
available): pick Student or Staff, then the person, and an optional due
date (defaults to 14 days from today).

### 2. Loans (`/library/loans`)
Every loan, filterable by status (Issued / Overdue / Returned / Lost).
Mark Returned calculates any late fine automatically (TZS 500/day
overdue) and frees up the copy. Mark Lost removes that copy from the
book's total count permanently (doesn't return it to available stock).

Overdue status and fines are computed live -- no background job needed;
opening the Loans list or My Books always reflects the current day.

### 3. My Books (`/library/my-books`)
For students, staff, and parents (of a student) -- their own current and
past loans, including any outstanding fine. Reachable from the Library
page's "My Books" button for anyone without management permissions.

## How to test

The seed script adds 8 books and issues 5 copies to Form I Section A
students -- one deliberately overdue.

1. Log in as admin -> Library -> confirm 8 books with realistic
   available/total counts (5 copies are checked out).
2. Library -> Loans -> filter by "Overdue" -> confirm exactly 1 loan
   shows, with a nonzero fine.
3. Open a book with available copies -> Issue Book -> Student -> Form I,
   Section A -> pick someone without an existing loan -> Issue -> confirm
   available count drops by 1 and the loan appears in Loans.
4. Loans -> Mark Returned on the overdue loan -> confirm the fine amount
   in the success message matches (days late x 500) and the book's
   available count goes back up by 1.
5. Try issuing a book with 0 available copies -> confirm "Issue Book" is
   disabled/blocked.
6. Log in as a parent of a Form I A student who has a book issued ->
   Library -> My Books -> confirm their child's loan appears with the
   due date.
