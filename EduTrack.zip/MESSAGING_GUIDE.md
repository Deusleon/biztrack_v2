# Notifications & Messages — Guide

A full contact/messaging system (SMS-focused, with email support too), plus
in-app notifications that fire automatically off real events elsewhere in
the app.

## Important: SMS sending is simulated

There's no real SMS provider connected (no network/API keys available
while building this). Every "send" is fully tracked in the database
(history, per-recipient status, balance deduction) exactly as it would be
with a real provider — it just doesn't leave the system. Settings →
Messages lets you plug in real credentials later; the "Simulated" provider
is what's active by default everywhere.

## How it works

### 1. Contacts (`/messages/contacts`)
Anyone reachable by message — parents, staff, suppliers, others. Add them
manually, or click **"↻ Sync from System"** to auto-import every parent
and staff member already in the app (skips anyone already synced).
Contacts can optionally link to a real user account (most parents/staff
do) or stand alone (e.g. a supplier who never logs in).

### 2. Groups (`/messages/groups`)
Two kinds:
- **Static** — hand-pick members via "Manage Members".
- **Smart (dynamic)** — membership computes automatically from a filter
  (e.g. "every parent of Form I"). New students admitted to that class are
  included automatically, no manual work.

Groups can nest one level as **subgroups** (e.g. "All Parents" →
"Form I Parents").

### 3. Compose (`/messages/compose`)
Pick who it's for — a single contact, a group/subgroup, everyone of a
type (broadcast), or custom phone numbers typed in directly. **Preview
recipients** before sending to see exactly who and how many. Use
`{{name}}` in the message to personalize each copy. Pick a template to
start from, or write from scratch.

### 4. Message History (`/messages/history`)
Every message ever sent, with status (sent/partially sent/failed) and a
detail view showing exactly who received it and whether each one
succeeded.

### 5. Templates (`/messages/templates`)
Reusable messages by category (fee reminder, exam result, general,
event...).

### 6. SMS Balance (`/messages/balance`)
An internal credit ledger. **Top Up** records a manual credit (there's no
payment processor connected — it's the same as an admin logging a bank
deposit received outside the system). Every SMS sent deducts credits;
failed sends aren't charged.

### 7. Notifications (bell icon + `/notifications`)
In-app alerts. Automatically fires for:
- A payment is recorded (Fees)
- Exam marks are entered/updated (Exams)
- A timetable is published (Timetable)

**Settings → Notifications** lets an admin turn any of these on/off and
choose which channel(s) — in-app, SMS, or email — each one uses.

## Permissions
Sending a message requires either an admin-tier role (super_admin, admin,
principal) **or** the `send_messages` permission explicitly granted on a
user's account (via the existing `permissions` field on User — not yet
exposed in a dedicated UI in this round; can be set directly via the
`users` table or a future Staff-permissions screen). Viewing
contacts/groups/history is open to any staff-tier role.

## How to test

The seed script now creates real **parent accounts** (previously missing
entirely — see below), ~400 contacts, 3 groups (2 of them "smart"), 4
templates, 1000 SMS credits, and one already-sent example message.

1. Log in as admin → **Messages** → confirm contacts are already
   populated (parents + staff + 2 sample suppliers).
2. **Messages → Groups** → open "All Parents" and "Form I Parents" —
   confirm the member counts look right (Form I Parents should be roughly
   3 sections' worth of parents).
3. **Messages → Compose** → Send To: Group → "Form I Parents" → **Preview
   recipients** → confirm the count and names look right → write a
   message → **Send**. Confirm it redirects to the message detail page
   showing per-recipient "sent" status, and that your SMS balance
   decreased by the recipient count.
4. **Messages → History** → confirm your new message appears alongside
   the seeded "welcome" message.
5. **Messages → Balance** → **Top Up** → add credits → confirm the
   balance and transaction log update.
6. **Settings → Notifications** → toggle "Payment Recorded" off → go
   record a fee payment (Fees module) → confirm no notification appears
   for that student's parent. Toggle it back on and repeat — confirm a
   notification now appears (bell icon badge increases).
7. **Settings → Messages** → confirm the SMS Gateway panel shows
   "Simulated" and explains real providers aren't wired in yet.
8. Log in as the seeded parent account (see credentials below) — confirm
   they see their own Fees/Results but **cannot** see Messages/Contacts in
   the sidebar (staff-only feature).

## Important fix made along the way

While building this, seed data was found to **never have created real
parent accounts** — students only had `parent_name`/`parent_phone` as
plain text, with no linked `User` and no `Student.parent_id`. This meant
the "parent" role could never actually be logged into or tested, and
smart parent-groups here would have had zero members. Fixed: every
student now gets a real linked parent account.

## SMS Gateways — Beem Africa, NextSMS, Meseji.co.tz

Three real Tanzanian SMS providers are now wired into `smsService.js`.

**Confidence level**: these were built from each provider's published API
documentation — this environment has no internet access or live
credentials to test against. **Beem Africa** is the most reliable (their
API format is stable and widely documented). **Meseji**
is lower-confidence — send one real test message with a trial/sandbox
account before relying on either in production; if a send fails, check
the endpoint URL and field names against that provider's current docs (in
`sendViaNextSms` / `sendViaMeseji` inside `backend/src/services/smsService.js`).

### NextSMS — how it works

Settings → Messages → Provider **NextSMS**:

| Field | What to enter |
|---|---|
| API Key | your NextSMS **username** |
| API Secret | your NextSMS **password** |
| Sender ID | your registered, approved sender (empty = NextSMS's default sender) |

- **Test Connection** calls NextSMS's balance endpoint: it proves the credentials work and shows your live balance
  without sending an SMS or spending a credit. Save before testing — it uses the saved settings.
- **Sending**: a broadcast goes out as one call per message text (up to 100 numbers per call). NextSMS answers with a
  result and a message id *per recipient*, so one refused number fails only that recipient, and every recipient keeps
  its own id for delivery tracking. Two contacts that share a phone number get a single SMS between them.
- **Balance**: the credits held at NextSMS are the real balance — the local counter is only a usage log. A send is
  refused up front only if the account holds fewer credits than recipients; NextSMS itself refuses anything it can't cover.
  The SMS Balance page and the Compose sidebar show the NextSMS figure. Buy credits on nextsms.co.tz.
- **Delivery**: "sent" only means NextSMS accepted it. Until NextSMS reports back, a recipient stays **Queued** — it
  is never guessed to have been delivered or to have failed, however long that takes. Real results arrive two ways:
  1. **Webhook (automatic).** Settings → Messages shows this school's delivery-report URL, already complete
     (`<api>/webhooks/dlr/nextsms/<school id>/<signature>`) with a Copy button. Paste it into the NextSMS dashboard
     as the delivery-report callback. It needs no setup on the server: the signature is computed from the school's id
     and `WEBHOOK_SECRET` (or `JWT_SECRET` if that isn't set), so it exists from the start and can't be forged; a
     report sent to it can only ever touch that school's own messages, repeated callbacks are harmless, and it is
     exempt from the API rate limit so a burst after a broadcast isn't lost. Changing the secret changes the URL.
     The older token-less `/webhooks/dlr/nextsms` still works (optionally guarded by `NEXTSMS_WEBHOOK_TOKEN`).
  2. **On demand.** Opening a message asks NextSMS for the report of each still-waiting recipient (re-checked every
     15 s, and the page keeps checking by itself for about 3 minutes while anyone is waiting). **Refresh Delivery**
     does it immediately and always says what happened — "2 delivered, 1 still on the way", the exact error from
     NextSMS, or why nothing was checked (e.g. the gateway isn't active). This is what works on a local/dev machine,
     which NextSMS can't call back.
- **Activating** NextSMS is refused until both username and password are saved.

Automated checks (no network, no database): `node --test tests/unit/nextsms.test.js`. They verify what EduTrack sends
and how it reads the responses; only Test Connection and a real message prove NextSMS's live API still matches.

### Gateway configuration is developer-only

Nobody — not even a `super_admin` — can view or edit SMS Gateway
credentials except whoever's email is listed in the `DEVELOPER_EMAILS`
environment variable. This is deliberately **not** a role; it's a direct
email allowlist, checked server-side on every gateway request, so it
can't be bypassed by changing a user's role in the database.

**You must set this yourself** — it's empty by default, which means
*nobody* can access it until you do:

```
# backend/.env
DEVELOPER_EMAILS=your.email@example.com
```

Comma-separate multiple addresses if more than one person needs access.
Restart the backend after changing it. When set correctly, log in as that
exact email and a new **"Messages"** tab appears in Settings — invisible
to every other account, and the underlying API returns 403 even if
someone tries to call it directly.

## Message Detail — pagination

The recipient list on a message's detail page (`/messages/history/:id`)
is now paginated server-side (15 per page) with a status filter, instead
of loading every recipient into one giant table — matters once a
broadcast reaches hundreds of people.



## Drafts, Retry, and Navigation

- **Save as Draft**: Compose has a "Save as Draft" button next to "Send
  Message" — safely park a message and resume it later.
- **Resume a draft**: In Message History, drafts show an "Edit Draft"
  action instead of "View" — reopens Compose with everything filled back
  in (recipient selection included) so you can finish and send it.
- **Retry failed recipients**: On a message's detail page, if any
  recipient failed, a "Retry Failed (N)" button re-attempts just those —
  successful ones are left untouched.
- **MessagesNav**: every page under Messages now shares one tab bar
  (Contacts | Groups | Compose | History | Templates | SMS Balance) so
  it's always one click to reach any of them, including sending to a
  custom number not saved as a contact (Compose -> Send To -> Custom
  Numbers).
- **Pick from contacts**: Under Compose -> Send To -> Custom Numbers, a
  switch offers **Type numbers** (the original free-text box) or **Pick
  from contacts**. The second lists every saved contact with a checkbox, a
  search box, a type filter, "Select all shown" and "Selected only", so you
  can message, say, 15 people out of 370 without typing each number.
  Contacts that cannot be reached on the chosen channel (no phone for SMS,
  no email for Email) are shown greyed out and cannot be ticked. These
  sends are recorded as `selected_contacts` in message history. This needs
  migration `20261022000000-messages-selected-contacts` (`npm run db:migrate`).

## Email Gateway (SMTP)

Settings -> Messages now also has an **Email Gateway** panel below SMS
Gateway -- same developer-only restriction. Configure SMTP host/port/
username/password/from-address for the Messages module's "Email" channel.
Leave it inactive to keep using the server's default `.env`-based SMTP
config (`SMTP_HOST`, `SMTP_USER`, etc.) -- nothing breaks if you never
touch this panel.

## Demo login credentials (new)

| Role | Email | Password |
|---|---|---|
| Parent | printed at the end of `npm run seed` (first parent created) | Student@123 |

All other credentials are unchanged from the previous guides.
