# Expenses — Guide

A simple operational spending ledger. Per product decision: no approval
workflow -- Accountant/Admin records an expense directly, the same as
writing it into a cashbook.

## How it works

### Ledger (`/expenses`)
Every recorded expense: date, category, amount, who it was paid to,
payment method, and an optional receipt photo. Filter by category,
payment method, or date range; search by payee/reference. The header
shows the total for whatever filter is currently applied.

Voiding an expense (instead of deleting) keeps it in the ledger marked
"Void" for audit purposes, and it stops counting toward totals -- the
same as striking through an entry in a paper cashbook rather than tearing
the page out.

### Categories tab
Manage expense categories (Utilities, Maintenance, Supplies, Transport,
Salaries & Wages, Food & Catering, ...). Categories in use can't be
deleted -- deactivate them instead.

## How to test

The seed script adds 6 categories and 8 sample January/February 2026
expenses.

1. Log in as admin -> Expenses -> confirm 8 entries with a total shown at
   the top.
2. Filter by category "Utilities" -> confirm only the 2 utility bills
   show and the total updates to match.
3. Record Expense -> fill in a new one -> confirm it appears immediately
   and the total increases.
4. Open an expense's actions -> Upload Receipt -> pick an image -> confirm
   a "View" link appears in the Receipt column.
5. Void an expense -> confirm it disappears from the default (non-void)
   view and the total decreases accordingly.
6. Categories tab -> try deleting a category that's in use -> confirm
   it's blocked with a clear message.
