# Mabadiliko ya raundi hii

**Mobile / UI**
- Search ya top bar kwenye simu inabofyeka (backdrop ilikuwa juu ya header).
- Notifications zinafungwa kwa kubonyeza nje / Escape.
- Search, Academic year & campus, Reload zimo kwenye dropdown moja ya "⋯" kwenye simu.
- `Button` na `ActionLink` (ui/) zinaonyesha icon tu kwenye simu; submit na buttons ndani ya dialogs zinabaki na maneno.
- Headers za pages (`.page-header`) zinaweka CTA kulia hata zikishuka line ya pili.

**Stats**
- Dashboard: "Present Today" na "Collected Today" (backend: `attendance_today.present`).
- Students: Total/Active/Inactive ni za shule nzima (`stats` kwenye `GET /students`).

**Fees / kasi**
- API timeout ya sekunde 30 (`utils/api.js`), routes zinaitwa kwa mahitaji (`App.jsx`), arrears zinahesabiwa kwa pamoja, "Try again" kwenye Fee Summary.

**Website content**
- Settings → Website (ruhusa mpya `settings.website`; admin/super_admin wanayo moja kwa moja).
- `GET/PUT /api/v1/settings/website-content`, `GET /api/v1/public/:slug/website-content`.
- `website/` inasoma content hii; weka `VITE_TENANT_SLUG` na `VITE_EDUTRACK_API_URL`.

**Ukubwa**
- Zimeondolewa: `public/docs/guides/*.docx` (masters ziko `tools/guide-generator/word-editable`), `public/docs/EduTrack_User_Guide.pdf` (haikutumika), `backend/backups/*.sql.gz`, file tupu `rm`.
- PNG zimebanwa (palette 256), PDFs zimerekebishwa bila kupoteza ubora, favicon.ico ndogo, logo ya website 800px.

**Kingine**
- `ClassView.jsx`: "remaining seats" haitoi tena NaN.

**Website → Admissions → Fee Structure (marekebisho ya ziada)**
- Bug: ukurasa ulikagua "loading" kabla ya "error", kwa hiyo request ikifeli ilibaki "Loading fee structure…" milele. Sasa inaonyesha ujumbe + kitufe cha "Try again".
- `services/api.js` ya website: timeout ya sekunde 20.
- Backend `GET /public/:slug/fee-structure`: bila `academic_year`, kama mwaka wa sasa hauna ada, inaonyesha mwaka wa karibuni wenye ada.
- `website/.env.example` mpya: `VITE_EDUTRACK_API_URL` (pamoja na `/api/v1`) na `VITE_TENANT_SLUG` (slug halisi ya shule).
