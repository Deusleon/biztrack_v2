# Updates This Round

## Round 4: students, Fee Status, fee reminders and who gets each notification

### Students admitted without a class now show in the list
The Students list (the year-based one your academic-year picker always uses) hid any student with no current class. Such a student is now listed from their
admission year onward, with **No class set**, until a class is given. (Not before their admission year.)

### Fee Status: search
The disabled year box is replaced by a wide **Search** box (student name or admission number). The table, "Select All Defaulters" and who a reminder goes to
all follow what the search shows.

### Fee reminder: "No recipients matched your selection" fixed
Cause: admissions saved the parent's messaging Contact without tying it to the parent's login, but the reminder looked contacts up by that tie, so no admitted
student ever matched. Now:
- the parent is found by their account, then by the parent phone/email typed on the admission form (and new admissions tie the contact properly);
- students with no usable parent number are no longer dropped silently: a partial send says "N student(s) were left out" and names them; if nobody can be reached the
  error lists who and why;
- the parent also gets an in-app "Fee Reminder" copy (Settings → Notifications → Outstanding Fee Reminder), never a second SMS.

### Notifications: choose who is told, and how, for each one
Settings → Notifications: each notification lists the people it can reach, each with a tick box and its own **In-App / SMS / Email** choices, e.g. Payment Recorded →
Parent / student and Accountants & admins; Leave Request → HR/principal/admins and the person who asked; Library Book Overdue → librarians and the borrower. At least one
recipient must stay ticked (or switch the notification off).
- "Payment Received (Staff Copy)" is now the *Accountants & admins* recipient of **Payment Recorded**, and "Admission Completed (Parent Notice)" is the *Parent / guardian*
  recipient of **New Student Admitted**. Migration `20261035000000-notification-audience.js` carries every school's current on/off and channel choices across
  (run `npm run db:migrate`; it takes a safety backup first). Safe to run twice.
- New, off by default: a confirmation to the person who submitted a leave request, a copy of decisions to HR/admins, and the borrower for overdue books.

### Notification bugs found and fixed while checking that every notification works
- Payment and exam-result SMS went to the **student's** phone while the in-app notice went to the parent. They now use the parent's number (account → admission form → student).
- For staff recipients (accountants, admins, HR, teachers…) ticking SMS or Email did nothing; only the in-app bell worked. They now really send, to each person in the role who has
  a phone / email on their profile (made-up `…@school.local` login addresses are never emailed). **A school that had ticked SMS/Email on a staff notification will start
  receiving them.** Names in email bodies are now escaped.
- "Library Book Overdue" was never sent by anything. It now goes out once, when a loan first turns overdue (only loans that went overdue in the last 7 days, so old data cannot flood
  anyone), and a sweep every six hours (`jobs/libraryJobs.js`, `LIBRARY_JOBS=off` to disable) covers schools where nobody opens the library page.
- One failing channel (e.g. the mail server is down) never stops the others and never breaks the action that triggered it; the result says what happened for each recipient.

### Tests
29 new tests (`tests/integration/notifications.test.js`): every notification × every recipient group, staff SMS/email, the settings screen and its validation, real payment /
admission / staff flows, fee reminders (parent by account, by admission form, siblings, nobody reachable), class-less students, overdue books, and the settings migration.
Checked that they fail when the fixes are switched off. Backend suite: **428 of 428 pass**.

### User guides
Rebuilt with the new notification options, reminder behaviour and "No class set". Fixed blank pages that could appear in a guide when a chapter or table ended exactly at the bottom of a page.

---

## Hotfix: backups on a database that has PostGIS (reported from the live server)

`npm run db:migrate` stopped with *"Safety backup failed its restore test (must be owner of table spatial_ref_sys)"*. Cause: PostGIS owns the
`spatial_ref_sys` table. The backup correctly left that table out, but still wrote down its keys and indexes, so the restore test tried to alter
the live PostGIS table. Fixed in `backend/src/services/backup/dumpEngine.js` (the only file you need to replace on the server):
- Tables, sequences and types that belong to an extension (PostGIS and anything like it) are skipped completely — including their keys and indexes.
- `CREATE EXTENSION` is written to a backup only when one of the app's own tables really needs it (a column type or default). An extension that is merely
  installed (PostGIS) is never required to restore, which matters on shared hosting where you cannot create extensions.
- A new guard refuses any line in a backup file that changes a table the file does not itself create, in both the restore test and a real restore.
- `npm run db:restore -- … --wipe` now removes only the app's own tables, sequences and types instead of dropping the whole schema, so PostGIS and the
  schema's permissions survive. It refuses (and changes nothing) if the database holds views, functions or triggers of its own that a backup does not cover.
- A database whose only table is PostGIS's counts as empty for a plain restore.
Tested with a PostGIS-style table (a table registered as an extension member): backup, restore test, restore and replace-everything all pass and the
extension table keeps its data. 2 new tests; backend suite 399 of 399.
Until you have the new file you can run the migration once with `SKIP_BACKUP=1 npm run db:migrate` (no safety backup is taken that time).

---

## Round 3 (this update)

### The 20 failing backend tests — fixed (397 of 397 now pass with `npm test`)
- **3 "Signed files" tests were a real security gap.** `utils/signedFiles.js` existed but `server.js` never used it, so every uploaded file
  (student photos, birth certificates, receipts) was served to anyone with the address. Now `/uploads` only serves a file with a valid,
  unexpired signed link, and the API signs every file address it returns (screens and PDFs work unchanged). A bare address answers 403.
- **17 "Forgot password" tests were environment, not code.** They need `NODE_ENV=test` (it switches off the rate limiters) and the standard
  starting passwords at their documented defaults. The suite now sets both itself: `tests/setup.js`, loaded by the `test` script
  (`node --import ./tests/setup.js --test`, which also works on Node 22 — the old `node --test tests/` did not).

### Mobile and tablet
- **Header:** on phones and tablets it shows the page name, a search icon (opens a full-width search), a sliders icon (academic year and campus,
  which were unreachable on a phone before), notifications and your picture. The full search box and pickers appear from wide desktop screens.
- **Buttons:** long labels become icons on phones ("Bulk Upload" → upload icon, "New Admission" → plus…). `ui/Button` does this automatically
  (icon picked from the words, tooltip and screen-reader label kept; submit buttons keep their words), and 17 header buttons across the pages were converted.
  Short labels like "Add Staff" stay as text.
- **Lists:** every `DataTable` shows one card per row on phones (first column as the title, the rest as label/value pairs) and a simpler pager.
- **Layouts:** 282 grid declarations became 1–2 columns on phones (calendars keep 7), two-column screens such as Settings stack, stat tiles are two-up,
  page-header rows wrap, dialogs never exceed the screen height, fields are 16px so iPhones do not zoom in, and notched phones get safe-area padding.
- Checked at 390 px (phone) and 820 px (tablet) on 14 key pages: no page scrolls sideways.

### Install on Android and iPhone
- Chrome's own installability check reports **no errors** (manifest, service worker, icons), including a new Android **maskable** icon.
- A slim **Install** bar appears on phones/tablets that have not installed the app. Android: one tap opens the system install dialog. iPhone/iPad: it shows
  Share → Add to Home Screen → Add. (Parents and students cannot open Settings, so the card there was not enough.) Dismissed for 14 days. The Settings card now lists steps for Android, iPhone and computers.
- iOS extras: `viewport-fit=cover`, status-bar and telephone-detection tags.

### Reload in the installed app
A reload button (circular arrow) appears in the top bar only when EduTrack runs as an installed app. On iPhone/iPad (which have no reload at all)
pulling the page down from the top reloads it. (Android's installed app already pulls to refresh; F5 / Ctrl+R still work on desktop.)

### Title bar vs sidebar
The title bar colour is now 32% deeper than the sidebar's top colour in every theme, and the sidebar gets a light top edge with an inner shadow,
so the two bars read as separate where they meet.

### Phone numbers
Seed data, templates, placeholders and examples now use the country code without "+" (`255712345678`). The code already stored numbers that way and still
accepts `07…` and `+255…` typed by hand. (SwalaSMS's API requires `+255…`, so that one request field keeps its "+"; the school website under `website/` is unchanged.)

### User guides
Rebuilt: the top-bar and "Using EduTrack as an app" sections now cover phones, installing on Android/iPhone and the reload button.

### Test status
Backend suite: 397 tests, 397 pass.

---

## Round 2

### Title bar follows the theme
The installed app's title bar (the blue bar) now takes the selected theme's dark shade and is set before the page loads (no blue flash).
`manifest.webmanifest` keeps the blue `theme_color` only for the very first launch splash; it cannot be dynamic.

### Desktop icon
`icon-192/256/384/512.png` now fill 100% of the canvas width (the maximum for the full logo in a square). Uninstall and reinstall the app to see it.
A bigger look would need a crop (for example the emblem only) — say if you want that.

### User guides
- Cover matches the original guide (large logo, green tagline, navy band, green bar, edition), plus a clear **"FOR <ROLE>"** line.
- The logo mark + "EduTrack" is back in the header of every page; font is Carlito (the open version of the original's Lato); button names are navy bold.
- A faint EduTrack **logo watermark** sits behind the text on every page (7% opacity, drawn first so it never covers a word), with a copyright line in the footer.
- **PDF only** is published and offered in the app. The editable Word masters moved to `tools/guide-generator/word-editable/` (same design, watermark in the header) and are not downloadable.

### Desktop app opens large
`src/utils/desktopWindow.js`: when EduTrack runs as the installed desktop app it fills the screen's usable area (below the taskbar) once per launch.
Not true full screen (that hides the title bar and window buttons) — `display: "fullscreen"` in the manifest would do that if you prefer it.

### SwalaSMS gateway (new, alongside Beem Africa, NextSMS and Meseji)
Built from the SwalaSMS OpenAPI file; choose it in Settings → Messages → SMS Gateway.
- **Sending:** bulk (up to 1000 per request, one message id per recipient) and single sends; every send carries an `Idempotency-Key`; an unconfirmed outcome (503) is retried once with the SAME key so it can never double-send. System messages (reset codes, subscription) use the System Sender ID.
- **Delivery:** per-recipient status checks (Refresh Delivery, and the message page keeps checking) plus a signed webhook: `POST /api/v1/webhooks/dlr/swalasms/<tenantId>/<signature>` (URL shown in Settings). SwalaSMS signs the raw body with HMAC-SHA256; paste the webhook signing secret into **API Secret** and bad signatures are refused.
- **Account:** Test Connection (balance, live vs sandbox key), live balance with per-country wallets, pre-send credit check, sender IDs with approval state (the `SWALATECH` test sender is marked), and requesting a new sender ID.
- **Credits:** Messages → Info → Buy Credits: package or custom quantity, price check, mobile-money prompt or card link, order followed until paid; completed top-ups (webhook) are recorded in the SMS history.
- **Setup notes:** the API key goes in **API Key** (`swl_live_…` real, `swl_test_…` sandbox — a sandbox key never sends or charges, and the screens say so); **Sender ID is required** (use `SWALATECH` until yours is approved); the key needs `sms:send`, `sms:read`, `sender-ids:read` and, to buy credits here, `wallet:read` + `wallet:topup`.
- New: migration `20261034000000-swalasms-provider.js` (run `npm run db:migrate`; it takes its automatic safety backup first), 38 tests in `tests/integration/swalasms.test.js`.
- **Unverified against a real account:** the wallet endpoints' published examples are empty, so their responses are read tolerantly — check the first real top-up. Nothing was tested against live SwalaSMS (a stub of its API was used).

### Test status
Backend suite: 397 tests, 374 pass; the 20 that fail are the same pre-existing "Forgot password" and "Signed files" failures as on the original zip.

---

## Round 1

Built on the uploaded `EduTrack.zip`. Backend suite: 359 tests, 339 pass. The 20 that fail are the same 20 that fail on the
untouched zip ("Forgot password" and "Signed files") — see *Things to know* below.

## 1. Cancelling an invoice uses our confirmation modal
`Subscription.jsx` no longer uses `window.confirm`. It was the only native confirm in the app (searched the whole frontend).

## 2 & 3. Favicon and logo
Every icon is rebuilt from the **full EduTrack logo** (with the wordmark), **transparent, no background**:
`favicon.ico` (7 sizes up to 256 px), `favicon-16/32/48/64/128.png`, and the install / desktop-shortcut icons
`icon-192/256/384/512.png`, which now fill ~96% of the canvas (they were ~41% wide-padding before, which is why the shortcut looked small).
The iPhone home-screen icon keeps a white tile (iOS paints transparency black). `?v=2` is added to the icon links to bust caches —
to see the new shortcut icon at once, uninstall and reinstall the app.
**Honest note:** the browser *tab* slot is fixed at 16 px (32 px on high-DPI) and the old favicon already filled its width, so the
tab icon cannot be made 50% bigger with the full logo; the declared sizes were increased instead (PNG up to 128, ICO up to 256).

## 4. User guides by role
One guide per role, each as **PDF and editable Word (.docx)**, in `frontend/public/docs/guides/`:
Super Admin, Administrator, Principal, Teacher, Accountant, Librarian, HR Manager, Transport Manager, Hostel Warden, Student, Parent.
Help → User Guide now shows **the signed-in person's own guide**, with Download PDF / Download Word. They were written from the product's
tested default permissions, so a parent never sees admin steps and a student never sees teacher steps. The old single 63-page guide was removed.
Source + generator: `tools/guide-generator/` (see its README).

## 5. Daily full-database backup with a restore test, and Google Drive
Settings → **Database Backup** (platform developer only: an email in `DEVELOPER_EMAILS`).
- Backs up **every table** (found from the database itself), in one consistent snapshot. No `pg_dump` needed.
- **Restore test** after every backup: replays the file into a scratch schema inside a transaction that is always rolled back, comparing
  each table's row count and content checksum. Only a backup that passes counts as good.
- **Daily** at the chosen hour (default 02:00 Africa/Dar_es_Salaam), with catch-up when the server wakes (cPanel can idle-kill Node).
  Cron option: `npm run db:backup:due`, or `POST /api/v1/webhooks/backup-cron` with header `x-backup-token` (`BACKUP_CRON_TOKEN`).
- **Before risky actions** (student promotion / individual promotion / revert, bulk imports, `db:migrate`, `db:empty`) a fresh tested backup is made first;
  if it cannot be made, the action is refused. Switch off in Settings or with `BACKUP_BEFORE_ACTIONS=off` / `SKIP_BACKUP=1`.
- **Google Drive**: paste a Client ID/Secret, click Connect (scope `drive.file` only; folder "EduTrack Backups"; credentials stored encrypted).
  **Set the Google consent screen to "In production"** or Google expires the link after 7 days.
- Failures email the addresses in `DEVELOPER_EMAILS`.
- Recover: `npm run db:restore -- latest --wipe` (one all-or-nothing transaction; asks you to type the database name).
- **Not included:** `backend/uploads` (student photos and documents are files, not database rows). Back that folder up separately.
New: migration `20261033000000-database-backups.js` (two tables), `services/backup/*`, `jobs/backupJobs.js`, `utils/backupCli.js`.
Env: see the new section in `backend/.env.example`. **Run `npm run db:migrate` after deploying** (it takes a safety backup first).

## 6. Import checks (students and staff)
Bulk Upload now **checks every row before saving anything**, then lets you choose what to import:
errors (with the reason and the real Excel row number), duplicates blocked (admission/employee number, email, phone — already in the school or repeated in the file),
possible duplicates (same name + date of birth / national ID — left unticked for you to decide), warnings, and your plan's student limit.
"Download the problems (Excel)" gives a fix-list. The preview and the real import share one validation function. Dates must now be real dates (31 Feb is refused).
**Staff Excel import is new** (it did not exist): Staff → Bulk Upload, same flow. Teaching subjects/documents are added afterwards on the record.
The two preview endpoints accept up to 5 MB (500 rows); everything else keeps the default limit.

## Things to know
- **Expenses:** by the product's own tested defaults an **accountant can only view expenses** (not record/edit/void). The old guide said accountants record them.
  The new guides follow the defaults. To let accountants record expenses, grant "Create Expenses" in Settings → Permissions.
- **Principal menu:** by default the principal has no Fee Management, Expenses, Staff, Library, Transport, Hostel or Inventory door; the new guide says so.
- **The 20 failing tests** ("Forgot password", "Signed files") fail on the untouched zip too. The signed-files tests expect uploaded files to need a signed link,
  but this snapshot's `server.js` serves `/uploads` openly — check your live code has those features.
- `npm test` (`node --test tests/`) does not run on Node 22; use `node --test "tests/**/*.test.js"`.
- Guide files are static, so the URL of another role's guide can be opened by anyone who knows it. The guides hold no secrets; this is about relevance, not security.
